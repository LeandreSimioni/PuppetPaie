# Avant le premier commit

Ce dossier est destiné à un dépôt public.

**Le nettoyage est fait** (09/09/2026). `python outils/verifier_avant_commit.py`
répond « Rien de personnel dans le code. C'est publiable. », et un test de la
suite refait le même contrôle à chaque passage.

Restent trois décisions, en bas de page.

---

## 1. Ce qui a été retiré, et comment

Le principe : **retirer les identités, garder les chiffres.** Les montants
sont ce qui prouve que le moteur est calé au centime ; les noms n'apportent
rien. Un test qui perd ses valeurs réelles perd sa valeur de preuve — c'était
le piège à éviter.

| Fichier | Ce qu'il portait | Ce qui a été fait |
|---|---|---|
| `tests/test_retours.py` | les deux NIR complets, le SIRET, un compte-rendu DGFiP réel | le CRM réel est devenu un **gabarit** : sa structure est intacte, ses NIR sont des marqueurs remplacés **au moment du test** par ceux de la configuration, qui n'est pas versionnée |
| `tests/test_interface.py` | deux NIR en dur pour tester la clé | le test lit désormais les fiches et vérifie que **chaque clé déclarée correspond à son NIR** — plus fort qu'avant |
| `tests/test_non_regression.py` | une adresse de courriel réelle | lue depuis la configuration |
| `moteur/retours.py` | un NIR réel dans deux exemples | NIR fabriqué |
| `moteur/champs.py` | une adresse réelle en exemple | adresse inventée |
| `moteur/conges_spectacles.py` | le SIRET en exemple | SIRET fabriqué (clé de Luhn juste) |
| `moteur/netentreprises.py` | « NOM PRÉNOM » du déclarant | formulation générique |

Les valeurs fabriquées ont **des clés qui se vérifient** : un test ne doit pas
pouvoir passer sur un numéro impossible. Elles sont listées, avec leur raison
d'être, en tête de `outils/verifier_avant_commit.py`.

Vérifié après nettoyage : **117 tests verts**, et `python -m moteur calibrer`
rend exactement le même rapport qu'avant.

## 2. Le garde-fou, en place

`outils/verifier_avant_commit.py` cherche NIR, IBAN, BIC, SIRET, identités et
adresses dans tout ce qui partirait. Il **ne contient aucune donnée
sensible** : il lit ce qu'il faut protéger dans `prive/config/`, hors du
dépôt. Un garde-fou qui porterait la liste des NIR à protéger serait
exactement ce qu'il prétend empêcher.

Deux façons de s'en servir, et il en faut deux — un hook s'installe, et peut
ne pas l'être :

```bash
git config core.hooksPath .githooks     # refuse le commit fautif
python outils/verifier_avant_commit.py  # à la demande, sur tout le dépôt
```

Le test `test_le_code_ne_porte_aucune_donnee_personnelle` fait le même
contrôle et part avec le dépôt.

Deux pièges rencontrés en l'écrivant, corrigés, à ne pas réapprendre :

- le motif du BIC (`[A-Z]{4}FR…`) trouvait le mot **« chiffres »** dans une
  phrase française — 56 fausses alertes. Un BIC est en capitales : la
  recherche ne doit pas ignorer la casse ;
- le motif du NIR acceptait un mois `60` et lisait l'horodatage
  `20260906080000` comme un numéro de sécurité sociale.

Un garde-fou qui crie au loup à chaque passage finit ignoré le jour où il a
raison. C'est pour cela que ces deux corrections comptent.

## 3. Ce qui reste à décider

- **La licence.** Aucune n'est choisie.
- **Le `client_secret` Google** (`moteur/google.py`). Il peut rester : Google
  l'assume pour les applications de bureau, qui ne peuvent rien garder
  secret, et il ne donne accès à rien sans l'autorisation d'un utilisateur. Ce
  qu'il porte, c'est notre quota et le plafond de 100 comptes — publié, il
  s'use plus vite. Décision à prendre en connaissance de cause, pas par défaut.
- **Le nom du dépôt** : `puppetpaie`, sans doute.

## 4. Le jour du premier commit

L'historique d'un dépôt est définitif : une donnée poussée puis effacée reste
consultable. Donc, dans cet ordre :

```bash
cd claude/logiciel          # JAMAIS le dossier parent : il porte les données
git init
git config core.hooksPath .githooks
python outils/verifier_avant_commit.py
git add .
git status                  # relire la liste AVANT de commiter
git commit -m "PuppetPaie"
```

`git status` avant le premier commit n'est pas une formalité : c'est le
dernier moment où la liste de ce qui part se lit en entier.
