"""Fenetre de lancement de l'interface PuppetPaie.

Se lance en double-cliquant sur « PuppetPaie.cmd », a la racine de `claude/`.

CE QU'ELLE RESOUT. L'interface est un serveur local : `python -m moteur
interface` bloque tant qu'on ne l'arrete pas, et il meurt avec le terminal qui
l'a lance. Le 11/09/2026, Leandre a laisse sa page ouverte apres que le
terminal eut servi a autre chose : le navigateur a affiche « Failed to fetch »,
et une fiche en cours d'edition n'a pas ete enregistree. Une page qui survit a
son serveur est pire qu'une page fermee -- elle a l'air de marcher.

D'ou cette fenetre, qui est le PROPRIETAIRE du serveur :

    on l'ouvre      -> la seance s'ouvre si besoin, le serveur demarre,
                       le navigateur s'ouvre sur la bonne adresse ;
    on la ferme     -> le serveur s'arrete, et la page n'a plus a faire
                       semblant. C'est la fenetre qui dit si ca tourne.

LA SEANCE D'ABORD. Si un mot de passe du logiciel est pose et que la seance est
fermee, elle est demandee ici, dans un champ masque -- avant meme que le
serveur ne demarre. Voir moteur/coffre.py : c'est cette seance qui autorisera
un depot. Sans mot de passe pose, rien n'est demande.

ET LA SEANCE DURE CE QUE DURE CETTE FENETRE. Elle n'a pas d'echeance depuis le
12/09/2026 : cette fenetre l'ouvre en demarrant et la referme en se fermant.
Le billet porte le numero de CE processus -- si le logiciel meurt sans pouvoir
refermer, le billet cesse de valoir tout seul. C'etait la demande de Leandre :
<< tant que la fenetre est ouverte on laisse le jeton, pas de limite de temps
-- la seance dure tant que la fenetre a ete ouverte et pas refermee >>.

LA MISE A JOUR SE FAIT ICI (16/09/2026). Si l'ouverture precedente a prepare
une nouvelle version (prive/maj/prete.json), cette fenetre l'applique AVANT de
demarrer le serveur : c'est le seul moment ou aucun code du moteur ne tourne.
Ce processus-ci a charge l'ancien `coffre` et l'ancien `contexte`, et c'est
sans importance : le serveur, lui, part sur le nouveau code. Voir moteur/maj.py.

Aucune dependance : tkinter et subprocess.
"""
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import scrolledtext

CODE = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE))
from moteur import coffre                                      # noqa: E402
from moteur.contexte import Contexte, racine_donnees           # noqa: E402

FOND = "#1e1e24"
FOND_CHAMP = "#2a2a33"
TEXTE = "#e8e8ec"
DISCRET = "#9a9aa8"
ACCENT = "#c9a227"
ALERTE = "#d05353"
SUCCES = "#6aa84f"

MINUTES_VEILLE = 20


class Fenetre(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("PuppetPaie")
        self.configure(bg=FOND)
        self.minsize(680, 520)
        self.file = queue.Queue()
        self.processus = None
        self.adresse = None
        self.ctx = Contexte()
        self._construire()
        self.protocol("WM_DELETE_WINDOW", self.fermer)
        self.after(100, self._vider_file)
        # La seance d'abord, le serveur ensuite : si le mot de passe est
        # refuse, rien ne demarre.
        self.after(200, self.demarrer)

    # ------------------------------------------------------------- interface
    def _construire(self):
        cadre = tk.Frame(self, bg=FOND, padx=22, pady=18)
        cadre.pack(fill="both", expand=True)

        tk.Label(cadre, text="PuppetPaie", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 18, "bold")).pack(anchor="w")
        tk.Label(cadre, text="paies d'intermittents - Compagnia UEUEUE",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9)).pack(anchor="w")
        self.version = tk.Label(cadre, text="", bg=FOND, fg=DISCRET,
                                font=("Segoe UI", 9))
        self.version.pack(anchor="w")
        tk.Label(cadre, text="donnees : %s" % racine_donnees(),
                 bg=FOND, fg=DISCRET, font=("Consolas", 8)).pack(anchor="w",
                                                                 pady=(2, 16))

        self.etat = tk.Label(cadre, text="Demarrage...", bg=FOND, fg=ACCENT,
                             font=("Segoe UI", 11, "bold"))
        self.etat.pack(anchor="w")
        self.detail = tk.Label(cadre, text="", bg=FOND, fg=DISCRET,
                               font=("Segoe UI", 9), justify="left")
        self.detail.pack(anchor="w", pady=(2, 14))

        barre = tk.Frame(cadre, bg=FOND)
        barre.pack(anchor="w", pady=(0, 4))
        self.bouton = tk.Button(barre, text="Ouvrir dans le navigateur",
                                command=self.ouvrir_navigateur, bg=ACCENT,
                                fg="#1e1e24", relief="flat", state="disabled",
                                font=("Segoe UI", 11, "bold"), padx=18, pady=8,
                                cursor="hand2")
        self.bouton.pack(side="left")
        tk.Button(barre, text="Fermer PuppetPaie", command=self.fermer,
                  bg=FOND_CHAMP, fg=TEXTE, relief="flat",
                  font=("Segoe UI", 10), padx=14, pady=8,
                  cursor="hand2").pack(side="left", padx=8)

        tk.Label(cadre,
                 text="Fermer cette fenetre arrete le serveur. Tant qu'elle est\n"
                      "ouverte, la page du navigateur repond ; une fois fermee,\n"
                      "elle affichera « Failed to fetch » -- c'est normal.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8),
                 justify="left").pack(anchor="w", pady=(10, 0))

        self.sortie = scrolledtext.ScrolledText(
            cadre, bg="#141418", fg=TEXTE, relief="flat", height=10,
            font=("Consolas", 9), insertbackground=TEXTE, wrap="word")
        self.sortie.pack(fill="both", expand=True, pady=(14, 0))
        self.sortie.tag_config("erreur", foreground=ALERTE)
        self.sortie.tag_config("succes", foreground=SUCCES)
        self.sortie.tag_config("discret", foreground=DISCRET)

    # --------------------------------------------------------------- seance
    def _ouvrir_seance(self) -> bool:
        """Le mot de passe du logiciel, si un est pose et la seance fermee.

        Rend True si l'on peut continuer -- y compris quand rien n'est
        demande, parce qu'aucun verrou n'a ete pose.
        """
        if not coffre.ouverture_exigee(self.ctx):
            self._ecrire("Aucun mot de passe du logiciel : la seance est "
                         "ouverte en permanence.\n", "discret")
            return True
        s = coffre.seance(self.ctx)
        if s.ouverte:
            self._ecrire("Seance deja ouverte.\n", "succes")
            return True

        boite = tk.Toplevel(self)
        boite.title("PuppetPaie")
        boite.configure(bg=FOND)
        boite.transient(self)
        boite.grab_set()
        tk.Label(boite, text="Mot de passe PuppetPaie", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=24,
                                                     pady=(20, 4))
        tk.Label(boite, text="Celui du logiciel, pas celui d'un organisme.\n"
                             "Il ouvre la seance -- c'est elle qui autorisera\n"
                             "un depot. Elle dure tant que cette fenetre\n"
                             "reste ouverte.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9),
                 justify="left").pack(anchor="w", padx=24)
        champ = tk.Entry(boite, show="*", bg=FOND_CHAMP, fg=TEXTE, relief="flat",
                         insertbackground=TEXTE, font=("Segoe UI", 13), width=26)
        champ.pack(anchor="w", padx=24, pady=14, ipady=7)
        champ.focus_force()
        erreur = tk.Label(boite, text="", bg=FOND, fg=ALERTE,
                          font=("Segoe UI", 9))
        erreur.pack(anchor="w", padx=24)
        reponse = {"ok": False}

        def valider(*_):
            try:
                # Le proprietaire, c'est CETTE fenetre : la seance ne doit
                # pas lui survivre.
                coffre.ouvrir_seance(self.ctx, champ.get(),
                                     proprietaire=os.getpid())
            except coffre.ErreurCoffre as e:
                erreur.config(text=str(e))
                champ.delete(0, "end")
                champ.focus_set()
                return
            reponse["ok"] = True
            champ.delete(0, "end")
            boite.destroy()

        champ.bind("<Return>", valider)
        barre = tk.Frame(boite, bg=FOND)
        barre.pack(anchor="e", padx=24, pady=16)
        tk.Button(barre, text="Quitter", command=boite.destroy, bg=FOND_CHAMP,
                  fg=TEXTE, relief="flat", font=("Segoe UI", 10), padx=14,
                  pady=6, cursor="hand2").pack(side="left", padx=6)
        tk.Button(barre, text="Ouvrir", command=valider, bg=ACCENT,
                  fg="#1e1e24", relief="flat", font=("Segoe UI", 10, "bold"),
                  padx=18, pady=6, cursor="hand2").pack(side="left")
        self.wait_window(boite)
        return reponse["ok"]

    # -------------------------------------------------------------- serveur
    def demarrer(self):
        if not self._ouvrir_seance():
            self._ecrire("\nSeance non ouverte : PuppetPaie ne demarre pas.\n",
                         "erreur")
            self.etat.config(text="Arrete", fg=ALERTE)
            self.detail.config(text="Fermer et relancer pour reessayer.")
            return
        self._appliquer_maj()
        self.etat.config(text="Demarrage du serveur...", fg=ACCENT)
        threading.Thread(target=self._servir, daemon=True).start()

    def _appliquer_maj(self):
        """La version prete, s'il y en a une, prend la place de celle-ci --
        maintenant, avant le serveur. Ce qui echoue est dit, et l'ancienne
        version demarre : une mise a jour ne doit jamais empecher une paie."""
        from moteur import operations as ops
        try:
            v = ops.version(self.ctx)
        except Exception as exc:                                  # noqa: BLE001
            self._ecrire("Version : %s\n" % exc, "erreur")
            return
        if v["prete"]:
            try:
                r = ops.appliquer_maj(self.ctx)
                v["courante"] = r["version"]
                self._ecrire("Mise a jour appliquee : PuppetPaie %s (la precedente "
                             "est gardee dans .avant/).\n" % r["version"], "succes")
            except Exception as exc:                              # noqa: BLE001
                self._ecrire("Mise a jour non appliquee : %s\n" % exc, "erreur")
        self.version.config(text="version %s" % v["courante"])

    def _servir(self):
        """Lance `moteur interface` et lit sa sortie pour trouver l'adresse."""
        exe = sys.executable
        if exe.lower().endswith("pythonw.exe"):
            exe = exe[:-len("pythonw.exe")] + "python.exe"
        try:
            self.processus = subprocess.Popen(
                [exe, "-u", "-m", "moteur", "interface", "--sans-navigateur",
                 "--veille", str(MINUTES_VEILLE)],
                cwd=str(CODE),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as exc:                                  # noqa: BLE001
            self.file.put(("\nEchec du lancement : %s\n" % exc, "erreur"))
            return
        for ligne in self.processus.stdout:
            self.file.put((ligne, None))
            if "http://" in ligne and "jeton=" in ligne and not self.adresse:
                self.adresse = ligne.strip()
                self.file.put((None, "adresse"))
        self.file.put((None, "fini"))

    def ouvrir_navigateur(self):
        if self.adresse:
            webbrowser.open(self.adresse)

    def fermer(self):
        """Ferme la fenetre, le serveur ET la seance.

        La seance en fait partie depuis le 12/09/2026 : elle n'a plus
        d'echeance, et c'est donc cette fermeture-ci qui la referme. Elle
        passe AVANT l'arret du serveur -- si `taskkill` echouait, on aurait
        au moins retire ce qui autorise un depot.
        """
        try:
            coffre.fermer_seance(self.ctx)
        except Exception:                                         # noqa: BLE001
            pass
        p = self.processus
        self.processus = None
        if p and p.poll() is None:
            try:
                # /T : les enfants aussi. Un serveur laisse derriere garderait
                # le port et la page continuerait de repondre sans proprietaire.
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)],
                               capture_output=True,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except Exception:                                     # noqa: BLE001
                try:
                    p.kill()
                except Exception:                                 # noqa: BLE001
                    pass
        self.destroy()

    # ---------------------------------------------------------------- sortie
    def _vider_file(self):
        while True:
            try:
                texte, marque = self.file.get_nowait()
            except queue.Empty:
                break
            if marque == "adresse":
                self.etat.config(text="PuppetPaie tourne", fg=SUCCES)
                self.detail.config(
                    text="Sauvegarde du dossier prive et releve des retours a\n"
                         "l'ouverture, puis toutes les %d minutes." % MINUTES_VEILLE)
                self.bouton.config(state="normal")
                webbrowser.open(self.adresse)
            elif marque == "fini":
                self.etat.config(text="Serveur arrete", fg=ALERTE)
                self.bouton.config(state="disabled")
            elif texte is not None:
                self._ecrire(texte, marque)
        self.after(100, self._vider_file)

    def _ecrire(self, texte, marque=None):
        self.sortie.insert("end", texte, marque or ())
        self.sortie.see("end")


if __name__ == "__main__":
    Fenetre().mainloop()
