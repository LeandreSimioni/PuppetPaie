@echo off
rem ---------------------------------------------------------------
rem  Retours DSN - Compagnia UEUEUE
rem  Ouvre la fenetre de recuperation des retours net-entreprises.
rem  Le mot de passe se tape dans la fenetre. Il n'est stocke nulle part.
rem ---------------------------------------------------------------
cd /d "%~dp0"

where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "lanceur.pyw"
    exit /b 0
)

where py >nul 2>nul
if %errorlevel%==0 (
    start "" pyw "lanceur.pyw"
    exit /b 0
)

echo.
echo   Python est introuvable sur cette machine.
echo   Installer Python 3 depuis https://www.python.org/downloads/
echo   en cochant "Add Python to PATH", puis relancer ce raccourci.
echo.
pause
