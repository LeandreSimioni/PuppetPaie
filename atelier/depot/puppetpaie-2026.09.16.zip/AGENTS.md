Les instructions pour un agent sont dans [CLAUDE.md](CLAUDE.md) — elles valent
pour tout assistant, quel qu'il soit.

Le point le plus important, pour n'avoir pas à ouvrir le fichier : **on ne lit
jamais `prive/config/coffre.bin`, `google-jeton.bin` ni `.seance`**, et **un
dépôt exige une séance ouverte par un humain**.
