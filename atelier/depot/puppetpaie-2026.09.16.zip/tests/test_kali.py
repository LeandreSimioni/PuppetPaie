"""La veille des conventions collectives par les livraisons open data KALI.

Sans reseau : les livraisons sont des archives fabriquees ici, servies par
un faux `telecharger` qui compte ses appels. Ce qu'on verrouille :

  - la lecture d'une livraison : la fiche d'une convention (IDCC, textes
    attaches) et un texte modifie (titre, date, etat, extension) ;
  - l'amorce : a la premiere veille, on remonte l'index jusqu'a la derniere
    fiche de chaque convention suivie, une fois ;
  - un texte nouveau attache, un texte modifie : signales, avec leur titre,
    rattaches a la bonne convention -- y compris un texte que le manifeste
    ne cite pas, grace a la liste de reference ;
  - une livraison lue n'est jamais retelechargee, et un signal ne
    disparait pas parce qu'on relance ;
  - `--relever` pose le XML du texte touche ;
  - les livraisons sorties de l'index sans avoir ete lues sont dites ;
  - `sources.verifier` traduit : un texte SALAIRES qui bouge = `changee`,
    un autre mouvement = `inchangee` mais montre.
"""
import io
import json
import shutil
import sys
import tarfile
import tempfile
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import kali, sources   # noqa: E402

CONT = "KALICONT000000000001"
TXT_SAL = "KALITEXT000000000010"      # le texte salaires cite par le manifeste
TXT_PREV = "KALITEXT000000000020"     # un texte de la convention, non cite
TXT_NEUF = "KALITEXT000000000030"     # un avenant salaires nouveau
AUTRE_CONT = "KALICONT000000000009"


# ----------------------------------------------------------- les archives
def _conteneur(ident, idcc, textes):
    liens = "".join('<LIEN_TXT idtxt="%s" titretxt="%s"/>' % kv for kv in textes.items())
    return ('<?xml version="1.0" encoding="UTF-8"?><IDCC><META><META_COMMUN><ID>%s</ID>'
            '</META_COMMUN><META_SPEC><META_CONTENEUR><TITRE>CCN de test</TITRE>'
            '<ETAT>VIGUEUR_ETEN</ETAT><NUM>%s</NUM></META_CONTENEUR></META_SPEC></META>'
            '<STRUCTURE_TXT><TM niv="1"><TITRE_TM>Textes Attaches</TITRE_TM>%s</TM>'
            '</STRUCTURE_TXT></IDCC>' % (ident, idcc, liens))


def _texte(ident, titre, date, etat="VIGUEUR_NON_ETEN", extension=""):
    return ('<?xml version="1.0" encoding="UTF-8"?><TEXTE_VERSION><META><META_COMMUN>'
            '<ID>%s</ID></META_COMMUN><META_SPEC><META_TEXTE_CHRONICLE><DATE_TEXTE>%s'
            '</DATE_TEXTE><DERNIERE_MODIFICATION>2026-01-01</DERNIERE_MODIFICATION>'
            '</META_TEXTE_CHRONICLE><META_TEXTE_VERSION><TITRE>%s</TITRE><ETAT>%s</ETAT>'
            '<LIBELLE_EXTENSION>%s</LIBELLE_EXTENSION></META_TEXTE_VERSION></META_SPEC>'
            '</META><CONTENU><p>le texte</p></CONTENU></TEXTE_VERSION>'
            % (ident, date, titre, etat, extension))


def _archive(estampille, conteneurs=(), textes=()):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for ident, xml in conteneurs:
            _ajouter(tar, "%s/kali/global/conteneur/KALI/CONT/00/%s.xml" % (estampille, ident), xml)
        for ident, xml in textes:
            _ajouter(tar, "%s/kali/global/texte/version/KALI/TEXT/00/%s.xml" % (estampille, ident), xml)
        _ajouter(tar, "%s/kali/global/article/KALI/ARTI/00/KALIARTI1.xml" % estampille,
                 "<ARTICLE><META><META_COMMUN><ID>KALIARTI1</ID></META_COMMUN></META></ARTICLE>")
    return buf.getvalue()


def _ajouter(tar, nom, contenu):
    octets = contenu.encode("utf-8")
    info = tarfile.TarInfo(nom)
    info.size = len(octets)
    tar.addfile(info, io.BytesIO(octets))


class Serveur:
    """L'index et les archives, servis de memoire ; compte les appels."""
    def __init__(self, livraisons: dict):
        self.livraisons = livraisons     # estampille -> octets
        self.appels = []

    def __call__(self, url):
        self.appels.append(url)
        if url == kali.INDEX:
            return "".join('<a href="KALI_%s.tar.gz">x</a>\n' % l
                           for l in sorted(self.livraisons)).encode()
        est = url[len(kali.INDEX) + 5:-7]
        return self.livraisons[est]


SUIVIS = {CONT: {"idcc": "1285", "textes": [TXT_SAL]}}
REFERENCE = {TXT_SAL: "Accord du 2 mai 2024 relatif aux salaires",
             TXT_PREV: "Prevoyance"}


def _monde():
    """Trois livraisons avant le releve (dont la fiche de la convention et
    une fiche d'une autre convention), rien apres."""
    return {
        "20260801-210000": _archive("20260801-210000",
                                    conteneurs=[(AUTRE_CONT, _conteneur(AUTRE_CONT, "9999", {"KALITEXT9": "Rien"}))]),
        "20260810-210000": _archive("20260810-210000",
                                    conteneurs=[(CONT, _conteneur(CONT, "1285", REFERENCE))],
                                    textes=[(TXT_PREV, _texte(TXT_PREV, "Prevoyance", "2020-01-01"))]),
        "20260901-210000": _archive("20260901-210000"),
    }


def _dossier():
    return Path(tempfile.mkdtemp(prefix="puppetpaie-kali-")) / "sources"


# ------------------------------------------------------------- les tests
def test_livraisons_lit_l_index():
    html = '<a href="KALI_20260914-210916.tar.gz">a</a> <a href="KALI_20250710-213429.tar.gz">b</a> ' \
           '<a href="Freemium_kali_global_20250713-140000.tar.gz">c</a>'
    assert kali.livraisons(html) == ["20250710-213429", "20260914-210916"]


def test_lire_livraison_donne_fiche_et_texte():
    lu = kali.lire_livraison(_archive(
        "20260914-210916",
        conteneurs=[(CONT, _conteneur(CONT, "1285", REFERENCE))],
        textes=[(TXT_SAL, _texte(TXT_SAL, "Accord salaires", "2024-05-02", "VIGUEUR_ETEN",
                                 "Etendu par arrete du 23 juillet 2024"))]))
    assert lu["conteneurs"][CONT]["idcc"] == "1285"
    assert lu["conteneurs"][CONT]["textes"] == REFERENCE
    t = lu["textes"][TXT_SAL]
    assert (t["titre"], t["date_texte"], t["etat"]) == ("Accord salaires", "2024-05-02", "VIGUEUR_ETEN")
    assert t["extension"].startswith("Etendu")


def test_premiere_veille_amorce_puis_rien_a_signaler():
    d = _dossier()
    srv = Serveur(_monde())
    r = kali.veiller(d, SUIVIS, "2026-08-20", "test", telecharger=srv)
    assert r["evenements"] == {CONT: []}
    assert r["livraisons_lues"] == ["2026-09-01"] and r["nouvelles"] == ["2026-09-01"]
    assert r["trou"] is None
    # L'amorce : on est remonte jusqu'a la fiche du 10/08, pas plus loin.
    assert r["amorces"][CONT]["livraison"] == "2026-08-10" and r["amorces"][CONT]["textes"] == 2
    archives = [u for u in srv.appels if u.endswith(".tar.gz")]
    assert "20260801" not in "".join(archives)
    cache = json.loads((d / kali.CACHE).read_text(encoding="utf-8"))
    assert set(cache["textes_connus"][CONT]) == {TXT_SAL, TXT_PREV}
    shutil.rmtree(d.parent, ignore_errors=True)


def test_un_texte_nouveau_et_un_texte_modifie_sont_rattaches():
    d = _dossier()
    monde = _monde()
    reference2 = dict(REFERENCE, **{TXT_NEUF: "Avenant du 1er juillet 2026 relatif aux salaires"})
    monde["20260910-210000"] = _archive(
        "20260910-210000",
        conteneurs=[(CONT, _conteneur(CONT, "1285", reference2))],
        textes=[(TXT_NEUF, _texte(TXT_NEUF, "Avenant du 1er juillet 2026 relatif aux salaires", "2026-07-01")),
                (TXT_PREV, _texte(TXT_PREV, "Prevoyance", "2020-01-01", "VIGUEUR_ETEN", "Etendu")),
                ("KALITEXT9", _texte("KALITEXT9", "Rien", "2000-01-01"))])
    srv = Serveur(monde)
    r = kali.veiller(d, SUIVIS, "2026-08-20", "test", telecharger=srv, relever=True)
    evts = r["evenements"][CONT]
    genres = [(x["genre"], x["ident"]) for x in evts]
    assert ("convention", CONT) in genres
    assert ("texte", TXT_NEUF) in genres
    assert ("texte", TXT_PREV) in genres          # non cite, mais dans la liste de reference
    assert ("texte", "KALITEXT9") not in genres   # une autre convention
    conv = next(x for x in evts if x["genre"] == "convention")
    assert conv["nouveaux"] == {TXT_NEUF: "Avenant du 1er juillet 2026 relatif aux salaires"}
    # --relever : le XML des deux textes touches est pose
    poses = sorted(p.name for p in (d / "kali").iterdir())
    assert poses == ["%s-2026-09-10.xml" % TXT_PREV, "%s-2026-09-10.xml" % TXT_NEUF]
    assert b"<p>le texte</p>" in (d / "kali" / poses[0]).read_bytes()

    # Relance : rien n'est retelecharge, le signal est toujours la.
    n = len(srv.appels)
    r2 = kali.veiller(d, SUIVIS, "2026-08-20", "test", telecharger=srv)
    assert [u for u in srv.appels[n:] if u.endswith(".tar.gz")] == []
    assert [x["ident"] for x in r2["evenements"][CONT]] == [x["ident"] for x in evts]
    assert r2["nouvelles"] == []

    # Un nouveau releve de la source : les evenements d'avant ne comptent plus.
    r3 = kali.veiller(d, SUIVIS, "2026-09-12", "test", telecharger=srv)
    assert r3["evenements"] == {CONT: []}
    shutil.rmtree(d.parent, ignore_errors=True)


def test_les_livraisons_sorties_de_l_index_sont_dites():
    d = _dossier()
    monde = _monde()
    srv = Serveur(monde)
    kali.veiller(d, SUIVIS, "2026-08-20", "test", telecharger=srv)
    # Un an passe : l'index ne remonte plus qu'au 01/03/2027, sans qu'on ait
    # lu ce qui est sorti entre le 01/09/2026 et cette date.
    monde.clear()
    monde["20270301-210000"] = _archive("20270301-210000")
    r = kali.veiller(d, SUIVIS, "2026-08-20", "test", telecharger=srv)
    assert r["trou"] and "2026-09-01" in r["trou"] and "2027-03-01" in r["trou"]
    # Et la premiere veille d'une installation tardive le dit aussi.
    d2 = _dossier()
    r = kali.veiller(d2, SUIVIS, "2026-08-20", "test", telecharger=Serveur(monde))
    assert r["trou"] and "2026-08-20" in r["trou"]
    assert CONT not in r["amorces"]                 # pas de fiche trouvee : dit
    shutil.rmtree(d.parent, ignore_errors=True)
    shutil.rmtree(d2.parent, ignore_errors=True)


def test_verifier_classe_salaires_et_autres_mouvements():
    """`sources.verifier` sur la source 1285 reelle, avec un rapport KALI
    joue : un texte salaires = A RELIRE, un autre mouvement = OK mais montre."""
    from moteur.contexte import Contexte
    ctx = Contexte()
    e = next(x for x in sources.etats(ctx) if x.ident == "legifrance-1285-accord-salaires-20240502")
    assert e.kali and e.kali["idcc"] == "1285"
    cont = e.kali["conteneur"]

    def rapport(evts):
        return {"livraisons_lues": ["2026-09-14", "2026-09-15"], "nouvelles": [], "trou": None,
                "amorces": {cont: {"livraison": "2026-07-16", "textes": 133, "titre": "CCN"}},
                "evenements": {cont: evts}}

    sources._etat_kali(e, rapport([]))
    assert e.en_ligne == "inchangee" and "2 livraison(s)" in e.detail and "133 textes" in e.detail

    sources._etat_kali(e, rapport([
        {"livraison": "2026-09-15", "genre": "texte", "ident": "KALITEXT1", "titre": "Reglement CPPNI",
         "date_texte": "2018-10-03", "modifie_le": "", "etat": "VIGUEUR_NON_ETEN", "extension": ""}]))
    assert e.en_ligne == "inchangee" and "Reglement CPPNI" in e.detail and "rien qui parle de salaires" in e.detail

    sources._etat_kali(e, rapport([
        {"livraison": "2026-09-15", "genre": "convention", "ident": cont, "titre": "fiche relivree",
         "premiere": False, "nouveaux": {"KALITEXT2": "Accord du 1er juillet 2026 relatif aux salaires"}},
        {"livraison": "2026-09-15", "genre": "texte", "ident": "KALITEXT1", "titre": "Reglement CPPNI",
         "date_texte": "2018-10-03", "modifie_le": "", "etat": "VIGUEUR_NON_ETEN", "extension": ""}]))
    assert e.en_ligne == "changee"
    assert "SALAIRES" in e.detail and "1er juillet 2026" in e.detail
    assert "minima-conventionnels.json" in e.detail
    assert "Autres mouvements" in e.detail and "Reglement CPPNI" in e.detail

    # Le texte cite lui-meme, quel que soit son titre
    sources._etat_kali(e, rapport([
        {"livraison": "2026-09-15", "genre": "texte", "ident": e.kali["texte"], "titre": "Accord",
         "date_texte": "2024-05-02", "modifie_le": "", "etat": "VIGUEUR_ETEN", "extension": "Etendu"}]))
    assert e.en_ligne == "changee" and "Etendu" in e.detail

    sources._etat_kali(e, OSError("pas de reseau"))
    assert e.en_ligne == "injoignable" and "DILA" in e.detail


def test_le_manifeste_cite_conteneur_et_texte_de_l_url():
    for ident, s in sources.manifeste()["sources"].items():
        if "kali" in s:
            assert s["kali"]["conteneur"] in s["url"] and s["kali"]["texte"] in s["url"], ident
            assert s["kali"]["idcc"] in s["titre"], ident
            assert s["verification"] == "manuelle", ident


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("ok   ", nom)
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            import traceback
            print("ECHEC", nom, "->", e)
            traceback.print_exc()
    print("\n%d test(s), %d echec(s)" % (
        len([n for n in globals() if n.startswith("test_")]), echecs))
    sys.exit(1 if echecs else 0)
