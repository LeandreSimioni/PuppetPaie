"""Tests de la sortie machine -- la troisieme facon d'appeler le logiciel.

Ni un humain devant un terminal, ni un humain devant une page : un PROGRAMME.
C'est par la que passeront l'interface et une eventuelle API.

Ce que ces tests protegent, c'est la promesse que `--json` fait le MEME
travail avec les MEMES garde-fous. La tentation, le jour ou l'interface
pressera, sera d'appeler `dsn.ecrire` directement pour aller plus vite : ces
tests sont la pour que le raccourci se voie.

Ils verifient aussi trois details de forme qui n'ont l'air de rien et qui
mordent : les montants en chaines (un flottant perd des centimes), l'UTF-8
force (la console Windows ecrit en cp1252), et le NIR absent des sorties de
paie (une sortie machine finit journalisee quelque part).
"""
import io
import json
import sys
from contextlib import redirect_stdout
from decimal import Decimal
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent    # logiciel/ : le depot public
sys.path.insert(0, str(CODE))

from moteur import cli, operations as ops, sortie_json as js   # noqa: E402
from moteur.contexte import Contexte                           # noqa: E402

ctx = Contexte()
RACINE = ctx.racine        # prive/ : les donnees
SAISIE = "paies/2026-08.json"


def _appeler(*argv):
    """Lance une commande et rend (code de sortie, charge JSON)."""
    tampon = io.StringIO()
    with redirect_stdout(tampon):
        code = cli.main(list(argv))
    texte = tampon.getvalue()
    try:
        return code, json.loads(texte)
    except json.JSONDecodeError as e:
        raise AssertionError("sortie non-JSON de %s :\n%s" % (argv, texte[:400])) from e


# ------------------------------------------------- la forme de la reponse
def test_toute_commande_rend_du_json_valide():
    for argv in (["fiche", "--json"], ["droits", "--json"],
                 ["mois", SAISIE, "--json"]):
        code, d = _appeler(*argv)
        assert "commande" in d and "ok" in d, "enveloppe incomplete pour %s" % argv


def test_le_code_de_sortie_dit_la_meme_chose_que_ok():
    """Un script shell lit le code de retour, un programme lit `ok` : les deux
    doivent concorder, sinon l'un des deux appelants se trompe."""
    code, d = _appeler("fiche", "--json")
    assert d["ok"] and code == 0
    code, d = _appeler("mois", SAISIE, "--json")
    assert not d["ok"] and code == 2


def test_une_erreur_metier_est_une_reponse_pas_un_plantage():
    """Un appelant automatique ne lit pas un message d'arret : il lui faut un
    `type` sur lequel brancher son comportement."""
    code, d = _appeler("mois", SAISIE, "--json")
    assert d["erreur"]["type"] == "UrssafManquant"
    assert d["erreur"]["estimation"], "de quoi redemander le montant"
    assert d["erreur"]["apercu"]["paies"], "et de quoi montrer le mois quand meme"


# --------------------------------------------------- les memes garde-fous
def test_json_ne_contourne_pas_le_garde_fou_audiens():
    """Le point qui compte : `--json` ne doit pas etre une porte derobee."""
    fichier = ctx._fichier_compteurs()
    avant = fichier.read_bytes()
    code, d = _appeler("mois", SAISIE, "--json")
    assert not d["ok"], "une DSN a ete produite sans montant URSSAF"
    assert fichier.read_bytes() == avant, "un refus en JSON a consomme un numero"


def _branche_json(nom_commande: str) -> str:
    """Le corps du `if _json(args):` d'une commande, et lui seul.

    Decoupe par indentation : le bloc s'arrete des qu'une ligne non vide
    revient au niveau du corps de fonction. Prendre tout ce qui suit, comme le
    faisait la premiere version de ce test, ramassait aussi le chemin humain
    et faisait echouer le test pour la mauvaise raison.
    """
    source = (CODE / "moteur" / "cli.py").read_text(encoding="utf-8")
    debut = source.index("def %s" % nom_commande)
    corps = source[debut:]
    # Au niveau du CORPS de fonction (4 espaces), pas dans un `except` : d'ou
    # le saut de ligne en tete du motif. Sans lui on attrape le premier
    # `if _json` venu, qui est un gestionnaire d'erreur.
    lignes = corps[corps.index("\n    if _json(args):") + 1:].splitlines()
    bloc = [lignes[0]]
    for ligne in lignes[1:]:
        if ligne.strip() and not ligne.startswith(" " * 8):
            break
        bloc.append(ligne)
    return "\n".join(bloc)


def test_l_envoi_en_json_ne_fait_que_preparer():
    """Un envoi demande une confirmation humaine, et un programme ne confirme
    pas. C'est la seule commande ou `--json` fait MOINS, et c'est voulu."""
    bloc = _branche_json("cmd_envoi")
    assert "envoye=False" in bloc, "la reponse ne dit pas que rien n'est parti"
    assert "return" in bloc, "la branche JSON n'interrompt pas la commande"
    assert "confirmer_et_envoyer" not in bloc, (
        "cmd_envoi expedie depuis la branche JSON : aucun humain n'a confirme")


# ------------------------------------------------------ les pieges de forme
def test_les_montants_sont_des_chaines():
    """201.32 en flottant vaut 201.31999999999999. Sur une paie, ca se voit."""
    code, d = _appeler("mois", SAISIE, "--json")
    p = d["erreur"]["apercu"]["paies"][0]
    for champ in ("brut", "net_a_payer", "cout_employeur", "base_csg"):
        assert isinstance(p[champ], str), "%s n'est pas une chaine" % champ
        Decimal(p[champ])          # et reste convertible sans perte


def test_les_dates_sont_en_format_de_donnees():
    code, d = _appeler("mois", SAISIE, "--json")
    p = d["erreur"]["apercu"]["paies"][0]
    assert p["debut"][:4].isdigit() and p["debut"][4] == "-", (
        "une date en JSON s'ecrit AAAA-MM-JJ, pas JJ/MM/AAAA")


def test_le_nir_n_est_pas_dans_une_sortie_de_paie():
    """Une sortie machine finit journalisee quelque part. La fiche d'identite
    le porte -- c'est son role -- une paie n'en a pas besoin."""
    code, d = _appeler("mois", SAISIE, "--json")
    texte = json.dumps(d)
    for s in ctx.salaries.values():
        assert s["nir"] not in texte, "un NIR est sorti dans une paie"


def test_la_fiche_porte_le_nir_elle():
    """Symetrique du precedent : l'interface doit pouvoir l'afficher pour le
    verifier. Si ce test tombe, la configuration devient inverifiable."""
    code, d = _appeler("fiche", "--json")
    nirs = {s["nir"] for s in d["resultat"]["salaries"].values()}
    assert nirs and all(nirs), "la fiche ne montre plus les NIR"


def test_les_cles_techniques_ne_sortent_pas():
    """Les cles prefixees `_` sont des notes de travail dans les JSON de
    config (`_taux_carsat`, `_abattement_artistes`...), pas des donnees."""
    code, d = _appeler("fiche", "--json")
    for bloc in (d["resultat"]["entreprise"], d["resultat"]["salaries"]):
        assert not [k for k in bloc if k.startswith("_")]


# ------------------------------------------------------- la conversion brute
def test_la_conversion_ne_perd_pas_les_decimales():
    assert js.brut(Decimal("201.32")) == "201.32"
    assert js.brut(Decimal("0.00")) == "0.00"


def test_la_conversion_accepte_une_dataclasse_imbriquee():
    e = ops.Etape("dsn", "DSN", "passer dans DSN-VAL", commande="x")
    assert js.brut([e])[0]["cle"] == "dsn"


def test_la_conversion_ne_boucle_pas_sur_un_objet_inconnu():
    class Bizarre:
        pass
    assert isinstance(js.brut(Bizarre()), str)


# ----------------------------------------------------------------- execution
def _lancer():
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    echecs = 0
    for nom, fn in tests:
        try:
            fn()
            print("  OK     %s" % nom)
        except AssertionError as e:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    print()
    print("Tous les tests passent." if not echecs
          else "%d test(s) en echec." % echecs)
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(_lancer())
