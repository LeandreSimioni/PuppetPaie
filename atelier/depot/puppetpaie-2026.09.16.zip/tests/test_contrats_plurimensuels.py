"""Un contrat qui deborde du mois -- octobre a decembre, un seul CDDU.

Decide le 15/09/2026 (option B1 de prive/journal/CONTRATS-PLURIMENSUELS.md) :
un contrat signe une fois pour une tournee de trois mois est TROIS
engagements, un par fichier de mois, qui portent tous `debut`, `fin` et --
des le deuxieme -- le `numero` que le premier a declare. Le role du mois se
deduit des dates :

    premier mois     contrat imprime, DPAE, pas de certificat CS
    mois du milieu   ni contrat, ni DPAE, ni certificat -- bulletin et DSN
    dernier mois     bloc 62 en DSN, certificat CS du contrat ENTIER

Ce fichier rejoue ce contrat fictif de bout en bout, dans une copie jetable
des donnees, et lit les trois DSN produites. Aucun contrat a cheval dans
cinq ans d'historique CoolPaie : `calibrer` ne couvrira jamais ce cas, et
c'est ici qu'il se prouve. Deposees en test le 15/09/2026 : les trois roles
conformes (ETAT.md §26.8).

LE MOIS SANS CACHET (15/09/2026, Leandre : << il faut toujours des DSN,
meme les mois sans paye >>) : un mois du contrat ou rien ne se joue s'ecrit
`lignes: []` avec les bornes du contrat. Sa DSN porte le contrat avec un
versement a zero -- blocs 50, 51 x 4, 53, 58, 78 << 31 >> et 81 << 059 >>
par affiliation, tous a 0.00, ni 54 ni autre base -- et il n'a pas de
bulletin. Depose en test le 15/09/2026 : conforme, Urssaf OK (§26.10).

LA QUOTITE (40.012/013) est celle du contrat entier, identique chaque mois
et jamais zero -- cahier technique 2026.1, bloc 40 CCH-11/12, bloc 41.007.
"""
import io
import json
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from decimal import Decimal
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import operations as ops                     # noqa: E402
from moteur.contexte import Contexte                     # noqa: E402

ctx = Contexte()

DEBUT, FIN = "2026-10-12", "2026-12-20"
CACHETS = {"2026-10": ["2026-10-12", "2026-10-13"],
           "2026-11": ["2026-11-05"],
           "2026-12": ["2026-12-18", "2026-12-19", "2026-12-20"]}


# ---------------------------------------------------------------- le bac
def _bac():
    """Une copie jetable de la configuration, sans les secrets."""
    racine = Path(tempfile.mkdtemp())
    shutil.copytree(ctx.racine / "config", racine / "config",
                    ignore=shutil.ignore_patterns("*.bin", ".seance", "avant"))
    (racine / "paies").mkdir()
    return racine


def _saisie(mois, cle, spec, numero=None, planning=False, **extra):
    e = {"salarie": cle, "spectacle": spec, "debut": DEBUT, "fin": FIN,
         "lignes": [{"rubrique": "cachet", "quantite": len(CACHETS[mois]),
                     "taux": 130, "dates": list(CACHETS[mois])}]}
    if planning:
        # Le premier mois coche d'avance les jours des mois suivants : c'est
        # le calendrier de l'ecran (15/09/2026), et le contrat les liste.
        e["lignes"][0]["planning"] = [x for m, xs in CACHETS.items() if m > mois for x in xs]
        del e["fin"]                     # deduite du dernier jour du planning
    if numero:
        e["numero"] = numero
    e.update(extra)
    return {"mois": mois, "taux_cachet": 130.0,
            "date_paiement": "%s-28" % mois, "engagements": [e]}


def _ecrire(racine, saisie):
    p = racine / "paies" / ("%s.json" % saisie["mois"])
    p.write_text(json.dumps(saisie, ensure_ascii=False, indent=2), encoding="utf-8")
    return p


def _dsn(r):
    f = next(x for x in r.fichiers if x.suffix == ".dsn")
    return f.read_bytes().decode("latin-1").splitlines()


def _valeurs(lignes, rubrique):
    return [l.split(",", 1)[1].strip("'") for l in lignes if l.startswith(rubrique + ",")]


def _noms(r):
    return {x.name.split("_")[0] for x in r.fichiers}


class Tournee:
    """Le contrat fictif produit mois par mois, une fois pour tout le fichier."""
    _fait = None

    @classmethod
    def faire(cls):
        if cls._fait:
            return cls._fait
        racine = _bac()
        bac = Contexte(racine)
        cle = next(iter(bac.salaries_actifs))
        spec = next(iter(bac.spectacles_actifs))
        produits, saisies = {}, {}
        # OCTOBRE : le premier mois, sans numero -- c'est la production qui
        # l'attribue et le fige dans le fichier.
        saisies["2026-10"] = _ecrire(racine, _saisie("2026-10", cle, spec, planning=True))
        produits["2026-10"] = ops.produire_mois(Contexte(racine), saisies["2026-10"],
                                                urssaf=100.0, qui="test")
        # NOVEMBRE et DECEMBRE : sans numero non plus, dans le fichier -- le
        # moteur doit le recopier d'octobre.
        for m in ("2026-11", "2026-12"):
            saisies[m] = _ecrire(racine, _saisie(m, cle, spec))
            produits[m] = ops.produire_mois(Contexte(racine), saisies[m],
                                            urssaf=100.0, qui="test")
        cls._fait = {"racine": racine, "cle": cle, "spec": spec,
                     "produits": produits, "saisies": saisies}
        return cls._fait


# ------------------------------------------------- le premier mois : octobre
def test_le_premier_mois_imprime_le_contrat_et_la_dpae_mais_pas_le_certificat():
    t = Tournee.faire()
    noms = _noms(t["produits"]["2026-10"])
    assert {"Contrats", "DPAE", "Bulletins", "DSN"} <= noms, noms
    assert "CertificatsCS" not in noms, "un certificat CS au premier mois d'un contrat en cours"
    etapes = {e.cle for e in t["produits"]["2026-10"].etapes}
    assert {"dpae", "contrat", "dsn"} <= etapes and "cs" not in etapes


def test_le_numero_est_fige_dans_la_saisie_a_la_production():
    t = Tournee.faire()
    data = json.loads(t["saisies"]["2026-10"].read_text(encoding="utf-8"))
    assert data.get("numeros_figes") is True
    numero = data["engagements"][0].get("numero")
    assert numero, "le numero de contrat n'a pas ete ecrit dans paies/2026-10.json"
    assert t["produits"]["2026-10"].saisie.paies[0].engagement.numero == numero
    # Une copie de sauvegarde a ete faite avant de reecrire le fichier.
    assert list((t["racine"] / "paies" / "avant").glob("2026-10*"))


def test_la_dsn_d_octobre_declare_le_contrat_entier_sans_fin_de_contrat():
    t = Tournee.faire()
    dsn = _dsn(t["produits"]["2026-10"])
    assert _valeurs(dsn, "S21.G00.40.001") == ["12102026"]
    assert _valeurs(dsn, "S21.G00.40.010") == ["20122026"]
    assert not _valeurs(dsn, "S21.G00.62.001"), "bloc 62 (fin de contrat) emis au premier mois"
    # La periode de paie est celle du mois, bornee au contrat.
    assert set(_valeurs(dsn, "S21.G00.51.001")) == {"12102026"}
    assert set(_valeurs(dsn, "S21.G00.51.002")) == {"31102026"}
    assert _valeurs(dsn, "S21.G00.50.001") == ["31102026"]
    assert set(_valeurs(dsn, "S21.G00.78.003")) == {"31102026"}
    # L'activite du mois : 2 cachets, 2 jours.
    assert "2.00" in _valeurs(dsn, "S21.G00.53.002")


# ------------------------------------------------ le mois du milieu : novembre
def test_le_mois_du_milieu_recopie_le_numero_et_n_imprime_rien_de_plus():
    t = Tournee.faire()
    r = t["produits"]["2026-11"]
    numero_oct = t["produits"]["2026-10"].saisie.paies[0].engagement.numero
    assert r.saisie.paies[0].engagement.numero == numero_oct
    noms = _noms(r)
    assert noms == {"Bulletins", "DSN"}, noms
    assert any("en cours depuis octobre 2026" in a for a in r.avertissements), r.avertissements
    assert any("se poursuit en decembre 2026" in a for a in r.avertissements), r.avertissements
    # Et le fichier de novembre porte desormais le numero, fige.
    data = json.loads(t["saisies"]["2026-11"].read_text(encoding="utf-8"))
    assert data["engagements"][0]["numero"] == numero_oct
    assert data.get("numeros_figes") is True


def test_la_dsn_de_novembre_porte_le_meme_bloc_40_et_la_periode_du_mois():
    t = Tournee.faire()
    oct_, nov = _dsn(t["produits"]["2026-10"]), _dsn(t["produits"]["2026-11"])
    for rub in ("S21.G00.40.001", "S21.G00.40.009", "S21.G00.40.010"):
        assert _valeurs(oct_, rub) == _valeurs(nov, rub), rub
    assert not _valeurs(nov, "S21.G00.62.001")
    assert set(_valeurs(nov, "S21.G00.51.001")) == {"01112026"}
    assert set(_valeurs(nov, "S21.G00.51.002")) == {"30112026"}
    assert "1.00" in _valeurs(nov, "S21.G00.53.002")


def test_un_contrat_en_cours_n_est_pas_une_embauche_du_mois():
    t = Tournee.faire()
    bac = Contexte(t["racine"])
    refuse = False
    try:
        ops.produire_dpae(bac, t["saisies"]["2026-11"])
    except ops.ErreurOperation as e:
        refuse = "en cours" in str(e)
    assert refuse, "produire_dpae a accepte de redeclarer un contrat en cours"
    assert ops.embauches_a_declarer(bac, "2026-11") == []
    # Le bilan ne reclame ni DPAE ni contrat pour novembre.
    b = ops.bilan_du_mois(bac, "2026-11")
    assert b["dpae"]["couleur"] == "bien" and "en cours" in b["dpae"]["phrase"], b["dpae"]
    assert b["contrat-signature"]["couleur"] == "bien", b["contrat-signature"]
    etat = ops.etat_par_paie(bac, "2026-11")[0]
    assert etat["contrat"] == {"premier_mois": False, "dernier_mois": False,
                               "depuis": "2026-10", "jusqu_a": "2026-12"}


# ---------------------------------------------- le dernier mois : decembre
def test_le_dernier_mois_emet_la_fin_de_contrat_et_le_certificat_du_contrat_entier():
    t = Tournee.faire()
    r = t["produits"]["2026-12"]
    noms = _noms(r)
    assert noms == {"Bulletins", "DSN", "CertificatsCS"}, noms
    dsn = _dsn(r)
    assert _valeurs(dsn, "S21.G00.62.001") == ["20122026"]
    assert set(_valeurs(dsn, "S21.G00.51.001")) == {"01122026"}
    assert set(_valeurs(dsn, "S21.G00.51.002")) == {"20122026"}
    assert _valeurs(dsn, "S21.G00.40.009") == [r.saisie.paies[0].engagement.numero]
    # Le certificat : du 12/10 au 20/12, 6 cachets, le brut des trois mois.
    recap = next(x for x in r.fichiers if x.name.startswith("CertificatsCS")
                 and x.suffix == ".txt").read_text(encoding="utf-8")
    assert "12/10/2026 -> 20/12/2026" in recap, recap
    assert " 6 jour(s)/cachet(s)" in recap, recap
    assert "brut   780" in recap, recap                     # 6 x 130
    assert r.numeros.cs_dernier == r.numeros.cs_premier    # un seul certificat


def test_le_certificat_du_contrat_entier_vaut_la_somme_des_mois():
    t = Tournee.faire()
    bac = Contexte(t["racine"])
    p = t["produits"]["2026-12"].saisie.paies[0]
    entier, manquants = ops.paie_du_contrat_entier(bac, p)
    assert manquants == []
    bruts = sum((t["produits"][m].saisie.paies[0].brut for m in CACHETS), Decimal("0.00"))
    assert entier.brut == bruts == Decimal("780.00")
    assert entier.engagement.cachets == 6 and entier.engagement.jours == 6
    assert str(entier.engagement.debut) == DEBUT and str(entier.engagement.fin) == FIN


def test_le_bulletin_de_novembre_dit_la_periode_du_mois_et_le_contrat():
    t = Tournee.faire()
    p = t["produits"]["2026-11"].saisie.paies[0]
    e = p.engagement
    assert str(e.debut_periode) == "2026-11-01" and str(e.fin_periode) == "2026-11-30"
    assert e.a_cheval and not e.premier_mois and not e.dernier_mois
    assert e.mois_du_contrat == ["2026-10", "2026-11", "2026-12"]


# --------------------------------------------------- reprendre un contrat
def test_les_contrats_en_cours_se_proposent_au_mois_suivant():
    t = Tournee.faire()
    bac = Contexte(t["racine"])
    numero = t["produits"]["2026-10"].saisie.paies[0].engagement.numero
    # Janvier : le contrat est fini le 20/12, rien a reprendre.
    assert ops.contrats_en_cours(bac, "2027-01") == []
    # Novembre : le contrat d'octobre court encore, et novembre le porte deja.
    c, = ops.contrats_en_cours(bac, "2026-11")
    assert (c.salarie, c.debut, c.fin, c.numero, c.depuis) == (t["cle"], DEBUT, FIN, numero, "2026-10")
    assert c.deja_repris is True and c.taux_cachet == 130
    # Dans un bac ou novembre n'existe pas encore : pas encore repris.
    (t["racine"] / "paies" / "2026-11.json").rename(t["racine"] / "paies" / "2026-11.json.x")
    try:
        c, = ops.contrats_en_cours(Contexte(t["racine"]), "2026-11")
        assert c.deja_repris is False
    finally:
        (t["racine"] / "paies" / "2026-11.json.x").rename(t["racine"] / "paies" / "2026-11.json")


def test_nouveau_reprendre_ecrit_le_contrat_en_cours_avec_son_planning():
    """La ligne de commande : `nouveau 2026-11 --reprendre` pose le contrat
    d'octobre dans le fichier de novembre -- bornes, numero, metier -- et,
    puisque octobre a coche le planning, la ligne de cachets de novembre
    deja datee, le reste du planning (decembre) a sa suite."""
    t = Tournee.faire()
    bac = Contexte(t["racine"])
    numero = t["produits"]["2026-10"].saisie.paies[0].engagement.numero
    p = ops.nouvelle_saisie(bac, "2026-11", force=True, reprendre=True)
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        e, = data["engagements"]
        assert (e["salarie"], e["debut"], e["fin"], e["numero"]) == (t["cle"], DEBUT, FIN, numero)
        assert e["lignes"] == [{"rubrique": "cachet", "taux": 130, "quantite": 1.0,
                                "dates": CACHETS["2026-11"],
                                "planning": CACHETS["2026-12"]}]
        assert "spectacle" not in data and e["spectacle"] == t["spec"]
        # Sans planning (un contrat ouvert a l'ancienne) : une ligne vide.
        c, = ops.contrats_en_cours(bac, "2026-11")
        c.lignes = [{"rubrique": "cachet", "quantite": 2, "taux": 130, "dates": CACHETS["2026-10"]}]
        vide = ops.engagement_de_reprise(c, "2026-11", bac)
        assert vide["lignes"] == [{"rubrique": "cachet", "quantite": 0, "taux": 130, "dates": []}]
    finally:
        # On remet le fichier de novembre tel que la tournee l'a produit.
        _ecrire(t["racine"], _saisie("2026-11", t["cle"], t["spec"], numero=numero))
        json_ = json.loads(t["saisies"]["2026-11"].read_text(encoding="utf-8"))
        json_["numeros_figes"] = True
        t["saisies"]["2026-11"].write_text(json.dumps(json_, ensure_ascii=False, indent=2),
                                           encoding="utf-8")


def test_enregistrer_depuis_l_ecran_garde_le_numero_fige():
    """L'interface renvoie ce qu'elle affiche ; une saisie sans `numero` ne
    doit pas effacer celui que la production a fige."""
    t = Tournee.faire()
    bac = Contexte(t["racine"])
    numero = t["produits"]["2026-10"].saisie.paies[0].engagement.numero
    ops.enregistrer_saisie(bac, "2026-10", _saisie("2026-10", t["cle"], t["spec"], planning=True))
    data = json.loads(t["saisies"]["2026-10"].read_text(encoding="utf-8"))
    assert data["engagements"][0]["numero"] == numero
    assert data.get("numeros_figes") is True


# ------------------------------------------------------------- les refus
def test_un_mois_du_milieu_sans_premier_mois_produit_est_refuse():
    racine = _bac()
    bac = Contexte(racine)
    cle = next(iter(bac.salaries_actifs))
    spec = next(iter(bac.spectacles_actifs))
    _ecrire(racine, _saisie("2026-11", cle, spec))
    refuse = False
    try:
        ops.charger(bac, racine / "paies" / "2026-11.json")
    except ops.ErreurOperation as e:
        refuse = "n'a pas ete produit" in str(e) and "octobre 2026" in str(e)
        assert "Produire octobre 2026 d'abord" in str(e), str(e)
    assert refuse, "un contrat en cours sans numero connu a ete accepte"
    shutil.rmtree(racine, ignore_errors=True)


def test_une_date_hors_du_mois_ou_hors_du_contrat_est_refusee():
    cle = next(iter(ctx.salaries_actifs))
    spec = next(iter(ctx.spectacles_actifs))
    # Un jour de novembre dans le fichier d'octobre.
    s = _saisie("2026-10", cle, spec)
    s["engagements"][0]["lignes"][0]["dates"].append("2026-11-02")
    s["engagements"][0]["lignes"][0]["quantite"] = 3
    try:
        ops.charger(ctx, s)
    except ValueError as e:
        assert "n'est pas dans le mois 2026-10" in str(e), str(e)
    else:
        raise AssertionError("une date hors du mois a ete acceptee")
    # Un jour joue avant le debut du contrat.
    s = _saisie("2026-10", cle, spec)
    s["engagements"][0]["lignes"][0]["dates"] = ["2026-10-02", "2026-10-13"]
    try:
        ops.charger(ctx, s)
    except ValueError as e:
        assert "hors du contrat" in str(e), str(e)
    else:
        raise AssertionError("un jour hors du contrat a ete accepte")
    # Une fin avant le debut.
    s = _saisie("2026-10", cle, spec)
    s["engagements"][0]["fin"] = "2026-10-01"
    try:
        ops.charger(ctx, s)
    except ValueError as e:
        assert "la fin precede le debut" in str(e), str(e)
    else:
        raise AssertionError("une fin avant le debut a ete acceptee")


def test_le_planning_donne_la_fin_et_les_dates_du_contrat_imprime():
    """Octobre coche le 5/11 et les 18-20/12 : `fin` se cale sur le 20/12
    sans qu'on l'ecrive, le contrat liste les six dates, l'article
    remuneration dit ce qui est du planning. Le planning ne se paie pas ce
    mois-ci : deux cachets, 260 EUR."""
    from moteur import contrat
    cle = next(iter(ctx.salaries_actifs))
    spec = next(iter(ctx.spectacles_actifs))
    s = _saisie("2026-10", cle, spec, planning=True)
    s["engagements"][0]["lignes"][0]["lieu"] = "Varzy"
    p = ops.charger(ctx, s).paies[0]
    e = p.engagement
    assert str(e.fin) == FIN and not e.dernier_mois and e.premier_mois
    assert [str(x) for x in e.planning] == CACHETS["2026-11"] + CACHETS["2026-12"]
    assert e.cachets == 2 and p.brut == Decimal("260.00")
    assert [str(x) for x in e.dates_du_contrat()] == sum(CACHETS.values(), [])
    assert e.lieu_de("2026-12-18") == "Varzy"
    vals = contrat.marqueurs(p, dict(ctx.entreprise, licence_spectacle="L"))
    assert "05/11/2026" in vals["contrat.dates_travail"] and "20/12/2026" in vals["contrat.dates_travail"]
    assert "planning jusqu'au" not in vals["contrat.dates_travail"]
    assert "les 4 dates suivantes du planning" in vals["remuneration.detail"], vals["remuneration.detail"]
    assert vals["remuneration.periode"] == " pour le mois d'octobre 2026"
    # Un contrat dans son mois : la phrase ne change pas.
    s = _saisie("2026-10", cle, spec)
    del s["engagements"][0]["fin"]
    assert contrat.marqueurs(ops.charger(ctx, s).paies[0],
                             dict(ctx.entreprise, licence_spectacle="L"))["remuneration.periode"] == ""
    # Un jour de planning dans le mois : c'est un jour joue, refus.
    s = _saisie("2026-10", cle, spec, planning=True)
    s["engagements"][0]["lignes"][0]["planning"].append("2026-10-20")
    try:
        ops.charger(ctx, s)
    except ValueError as exc:
        assert "jour de planning" in str(exc), str(exc)
    else:
        raise AssertionError("un planning dans le mois a ete accepte")
    # Un planning au-dela d'une fin ecrite : refus.
    s = _saisie("2026-10", cle, spec, planning=True)
    s["engagements"][0]["fin"] = "2026-11-30"
    try:
        ops.charger(ctx, s)
    except ValueError as exc:
        assert "ne depasse pas la fin" in str(exc), str(exc)
    else:
        raise AssertionError("un planning au-dela de la fin a ete accepte")


# ------------------------------------------------------ la quotite du contrat
def test_la_quotite_est_celle_du_contrat_entier_et_la_meme_chaque_mois():
    t = Tournee.faire()
    total = sum(len(x) for x in CACHETS.values())       # 6 jours signes
    for m in ("2026-10", "2026-11", "2026-12"):
        dsn = _dsn(t["produits"][m])
        assert _valeurs(dsn, "S21.G00.40.012") == ["%d.00" % total], (m, _valeurs(dsn, "S21.G00.40.012"))
        assert _valeurs(dsn, "S21.G00.40.013") == ["%d.00" % total], m
    # Et pas les jours du mois (2, 1, 3), qui etaient trois changements de
    # contrat non declares et tombaient a zero sur un mois creux.
    assert set(_valeurs(_dsn(t["produits"]["2026-11"]), "S21.G00.53.002")) == {"1.00"}


def test_un_contrat_de_plus_de_31_jours_est_refuse_en_dsn():
    cle = next(iter(ctx.salaries_actifs))
    spec = next(iter(ctx.spectacles_actifs))
    s = _saisie("2026-10", cle, spec)
    e = s["engagements"][0]
    e["lignes"][0]["planning"] = ["2026-11-%02d" % j for j in range(1, 31)]
    del e["fin"]
    from moteur import dsn
    refuse = False
    try:
        dsn.generer(ctx, ops.charger(ctx, s).paies, "2026-10", versement_urssaf=100.0)
    except ValueError as exc:
        refuse = "31" in str(exc) and "CCH-12" in str(exc)
    assert refuse, "32 jours de contrat declares en quotite journee"


# ------------------------------------------------------- le mois sans cachet
class Creux:
    """Janvier -> mars 2026, et fevrier sans aucun cachet."""
    _fait = None
    CACHETS = {"2026-01": ["2026-01-12", "2026-01-13"], "2026-02": [],
               "2026-03": ["2026-03-18", "2026-03-19", "2026-03-20"]}

    @classmethod
    def faire(cls):
        if cls._fait:
            return cls._fait
        racine = _bac()
        bac = Contexte(racine)
        cle = next(iter(bac.salaries_actifs))
        spec = next(iter(bac.spectacles_actifs))
        produits = {}
        for m, jours in cls.CACHETS.items():
            e = {"salarie": cle, "spectacle": spec, "debut": "2026-01-12",
                 "lignes": [{"rubrique": "cachet", "quantite": len(jours),
                             "taux": 130, "dates": jours}] if jours else []}
            suite = [x for mm, xs in cls.CACHETS.items() if mm > m for x in xs]
            if suite and jours:
                e["lignes"][0]["planning"] = suite
            else:
                e["fin"] = "2026-03-20"
            chemin = _ecrire(racine, {"mois": m, "taux_cachet": 130.0,
                                      "date_paiement": "%s-28" % m, "engagements": [e]})
            produits[m] = ops.produire_mois(Contexte(racine), chemin,
                                            urssaf=100.0 if jours else 0.0, qui="test")
        cls._fait = {"racine": racine, "produits": produits}
        return cls._fait


def test_le_mois_sans_cachet_n_a_que_sa_dsn_et_le_dit():
    c = Creux.faire()
    r = c["produits"]["2026-02"]
    assert _noms(r) == {"DSN"}, _noms(r)
    assert any("aucun cachet en fevrier 2026" in a and "pas de bulletin" in a
               for a in r.avertissements), r.avertissements
    p = r.saisie.paies[0]
    assert p.engagement.sans_paie and p.brut == 0 and p.numero_bulletin is None
    assert r.numeros.bulletin_premier == 0
    # Le numero de contrat est celui de janvier, comme pour toute reprise.
    assert p.engagement.numero == c["produits"]["2026-01"].saisie.paies[0].engagement.numero


def test_la_dsn_du_mois_sans_cachet_porte_le_contrat_avec_un_versement_a_zero():
    c = Creux.faire()
    jan, fev, mar = (_dsn(c["produits"][m]) for m in ("2026-01", "2026-02", "2026-03"))
    for rub in ("S21.G00.40.001", "S21.G00.40.009", "S21.G00.40.010",
                "S21.G00.40.012", "S21.G00.40.013"):
        assert _valeurs(jan, rub) == _valeurs(fev, rub) == _valeurs(mar, rub), rub
    assert _valeurs(fev, "S21.G00.40.012") == ["5.00"]         # 2 + 3 jours signes
    assert not _valeurs(fev, "S21.G00.62.001")
    assert _valeurs(mar, "S21.G00.62.001") == ["20032026"]
    # Le versement : present, date du dernier jour du mois, tout a zero.
    assert _valeurs(fev, "S21.G00.50.001") == ["28022026"]
    assert _valeurs(fev, "S21.G00.50.002") == ["0.00"]
    assert _valeurs(fev, "S21.G00.50.004") == ["0.00"]
    assert _valeurs(fev, "S21.G00.51.011") == ["001", "002", "003", "010"]
    assert set(_valeurs(fev, "S21.G00.51.013")) == {"0.00"}
    assert set(_valeurs(fev, "S21.G00.51.001")) == {"01022026"}
    assert set(_valeurs(fev, "S21.G00.51.002")) == {"28022026"}
    # L'activite, obligatoire en unite journee (bloc 40 CCH-15) : 0 jour.
    assert _valeurs(fev, "S21.G00.53.002") == ["0.00"]
    assert _valeurs(fev, "S21.G00.53.003") == ["12"]
    assert _valeurs(fev, "S21.G00.58.004") == ["0.00"]
    # Une base 31 et sa cotisation 059 a zero par affiliation, rien d'autre.
    affiliations = _valeurs(fev, "S21.G00.70.012")
    assert len(affiliations) == 2
    assert _valeurs(fev, "S21.G00.78.001") == ["31"] * len(affiliations)
    assert _valeurs(fev, "S21.G00.78.005") == affiliations
    assert set(_valeurs(fev, "S21.G00.78.004")) == {"0.00"}
    assert _valeurs(fev, "S21.G00.81.001") == ["059"] * len(affiliations)
    assert set(_valeurs(fev, "S21.G00.81.004")) == {"0.00"}
    assert not _valeurs(fev, "S21.G00.54.001")
    # Les totaux du mois : rien n'est du a personne.
    assert set(_valeurs(fev, "S21.G00.20.005")) == {"0.00"}


def test_le_certificat_du_contrat_avec_un_mois_creux_compte_tous_les_cachets():
    c = Creux.faire()
    r = c["produits"]["2026-03"]
    assert "CertificatsCS" in _noms(r)
    recap = next(x for x in r.fichiers if x.name.endswith("_recapitulatif.txt"))
    texte = recap.read_text(encoding="utf-8")
    assert "12/01/2026" in texte and "20/03/2026" in texte, texte
    assert "650" in texte.replace(",", "."), texte      # 5 cachets a 130


def test_un_engagement_sans_ligne_doit_dire_ses_bornes_et_deborder_du_mois():
    cle = next(iter(ctx.salaries_actifs))
    spec = next(iter(ctx.spectacles_actifs))
    base = {"mois": "2026-02", "taux_cachet": 130.0, "date_paiement": "2026-02-28"}
    # Sans bornes : rien ne permet de les deduire.
    try:
        ops.charger(ctx, dict(base, engagements=[{"salarie": cle, "spectacle": spec, "lignes": []}]))
        assert False, "un mois sans cachet sans bornes a ete accepte"
    except ValueError as e:
        assert "`debut` et `fin`" in str(e), str(e)
    # Un contrat qui tient dans son mois sans rien jouer n'a pas de sens.
    try:
        ops.charger(ctx, dict(base, engagements=[{
            "salarie": cle, "spectacle": spec, "lignes": [],
            "debut": "2026-02-10", "fin": "2026-02-20"}]))
        assert False, "un contrat vide dans son mois a ete accepte"
    except ValueError as e:
        assert "n'a pas de sens" in str(e), str(e)
    # Une ligne sans date reste une saisie incomplete, pas un mois creux.
    try:
        ops.charger(ctx, dict(base, engagements=[{
            "salarie": cle, "spectacle": spec, "debut": "2026-01-12", "fin": "2026-03-20",
            "lignes": [{"rubrique": "cachet", "quantite": 1, "taux": 130}]}]))
        assert False, "une ligne sans date a ete acceptee"
    except ops.ErreurOperation as e:
        assert "aucun jour joue" in str(e) and "lignes: []" in str(e), str(e)


def test_un_contrat_dans_son_mois_ne_change_pas():
    """Tout l'historique : premier et dernier mois a la fois, periodes =
    contrat, bloc 62 present. C'est ce que `calibrer` verifie sur 75 DSN ;
    ici la propriete elle-meme."""
    cle = next(iter(ctx.salaries_actifs))
    spec = next(iter(ctx.spectacles_actifs))
    s = _saisie("2026-10", cle, spec)
    del s["engagements"][0]["debut"], s["engagements"][0]["fin"]
    e = ops.charger(ctx, s).paies[0].engagement
    assert e.premier_mois and e.dernier_mois and not e.a_cheval
    assert (e.debut_periode, e.fin_periode) == (e.debut, e.fin)
    assert e.mois_du_contrat == ["2026-10"]


def _lancer():
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    echecs = 0
    for nom, fn in tests:
        try:
            with redirect_stdout(io.StringIO()):
                fn()
            print("  OK     %s" % nom)
        except AssertionError as e:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    for cls in (Tournee, Creux):
        if cls._fait:
            shutil.rmtree(cls._fait["racine"], ignore_errors=True)
    print()
    print("Tous les tests passent." if not echecs
          else "%d test(s) en echec." % echecs)
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(_lancer())
