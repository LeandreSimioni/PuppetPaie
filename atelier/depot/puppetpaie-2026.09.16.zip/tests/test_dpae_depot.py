"""Tests de la DPAE et de son depot.

Ce qui fait foi ici : le gabarit `gabarits/due_tel_gabarit.txt` est un
enregistrement REELLEMENT depose et accepte par le SI DPAE (aout 2026). Tout
ce qu'on en deduit -- notamment que l'indicateur vaut 120 pour un envoi reel
-- s'appuie sur ce fait, pas sur une lecture de specification.

Les tests du depot n'ouvrent aucune connexion : ils verifient que les
garde-fous arretent la commande AVANT le reseau. C'est precisement ce qu'on
veut prouver d'un code qui envoie des declarations.
"""
import io
import sys
from contextlib import redirect_stdout
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent    # logiciel/ : le depot public
sys.path.insert(0, str(CODE))

from moteur import dpae, dpae_api                        # noqa: E402
from moteur.operations import charger                    # noqa: E402
from moteur.commandes_dpae import cmd_deposer_dpae       # noqa: E402
from moteur.contexte import Contexte, racine_donnees                     # noqa: E402

ctx = Contexte()
RACINE = ctx.racine        # prive/ : les donnees
GABARIT = (RACINE / "gabarits" / "due_tel_gabarit.txt").read_bytes()


class Args:
    """Ce que argparse aurait construit."""
    def __init__(self, fichier, reel=False, confirmer=None, heure="1900",
                 test=False, majuscules=False):
        self.fichier = str(fichier)
        self.reel = reel
        self.confirmer = confirmer
        self.heure = heure
        self.test = test
        self.majuscules = majuscules


def _lancer(args) -> tuple:
    sortie = io.StringIO()
    with redirect_stdout(sortie):
        code = cmd_deposer_dpae(ctx, args)
    return code, sortie.getvalue()


# ------------------------------------------------------- l'enregistrement
def test_indicateur_du_gabarit_vaut_reel():
    """Le gabarit vient d'un depot accepte : son indicateur est celui du reel."""
    assert dpae_api.indicateur(GABARIT) == dpae_api.INDICATEUR_REEL
    assert dpae_api.est_reel(GABARIT)


def test_heure_dembauche_est_celle_demandee():
    """Elle circule jusque dans l'enregistrement, pas seulement a l'ecran."""
    paies = charger(ctx, RACINE / "paies" / "2026-09.json").paies
    ligne = dpae.enregistrement(paies[0], _horodatage(), heure_embauche="0800")
    a, b = dpae.CHAMPS["heure_embauche"]
    assert ligne[a:b] == "0800"


def test_recapitulatif_porte_la_meme_heure_que_le_fichier():
    """Le recapitulatif sert a saisir en ligne : il doit dire la meme chose."""
    paies = charger(ctx, RACINE / "paies" / "2026-09.json").paies
    assert "a 19h00" in dpae.recapitulatif(paies, "1900")
    # Le defaut est 08h00 depuis le 12/09/2026 (dpae.HEURE_EMBAUCHE).
    assert "a 08h00" in dpae.recapitulatif(paies)


def _horodatage():
    import datetime as dt
    return dt.datetime(2026, 9, 4, 21, 0, 0)


# -------------------------------------------------------- les garde-fous
def test_essai_a_blanc_par_defaut(tmp=None):
    """Sans --reel, la commande n'envoie rien et le dit."""
    code, txt = _lancer(Args(_fichier_dpae()))
    assert code == 0
    assert "ESSAI A BLANC" in txt and "rien n'a ete envoye" in txt


def test_reel_exige_une_confirmation_du_mois():
    code, txt = _lancer(Args(_fichier_dpae(), reel=True))
    assert code == 2
    assert "--confirmer" in txt


def test_mois_confirme_faux_arrete_tout():
    code, txt = _lancer(Args(_fichier_dpae(), reel=True, confirmer="2026-12"))
    assert code == 2
    assert "different des embauches" in txt


def test_archive_zip_refusee():
    """Le SI DPAE refuse les archives ; on ne les propose meme pas."""
    zip_ = _fichier_dpae().with_suffix(".txt.zip")
    if not zip_.exists():
        return
    code, txt = _lancer(Args(zip_))
    assert code == 1 and "archives" in txt


def test_fichier_qui_nest_pas_un_flux_a_plat_refuse():
    recap = _fichier_dpae().parent / (_fichier_dpae().stem + "_recapitulatif.txt")
    if not recap.exists():
        return
    code, txt = _lancer(Args(recap))
    assert code == 1 and "multiple de 990" in txt


def test_embauche_a_plus_de_huit_jours_refusee(tmp_path=None):
    """La DPAE ne s'envoie pas plus de 8 jours avant l'embauche."""
    import datetime as dt
    loin = dt.date.today() + dt.timedelta(days=40)
    ligne = list(GABARIT.decode("latin-1")[:dpae.LONGUEUR])
    a, b = dpae.CHAMPS["date_embauche"]
    ligne[a:b] = list(loin.strftime("%d%m%Y"))
    f = RACINE / "sorties" / "_essai_dpae_trop_tot.txt"
    f.write_bytes("".join(ligne).encode("latin-1"))
    try:
        code, txt = _lancer(Args(f))
        assert code == 2
        assert "trop tot" in txt or "8 jours" in txt
    finally:
        f.unlink()


def test_bascule_en_test_ne_touche_que_c_version():
    """TST et 120 font trois caracteres : rien ne se decale."""
    flux = _fichier_dpae().read_bytes()
    t = dpae_api.basculer_en_test(flux, dpae.LONGUEUR)
    assert len(t) == len(flux)
    n = len(flux) // dpae.LONGUEUR
    a, b = dpae_api.INDICATEUR
    for i in range(n):
        assert t[i * dpae.LONGUEUR + a:i * dpae.LONGUEUR + b] == b"TST"
    assert sum(1 for i in range(len(flux)) if flux[i] != t[i]) == 3 * n


def test_le_fichier_sur_disque_reste_reel():
    """La bascule est en memoire : ce qui dort sur le disque reste declarable."""
    f = _fichier_dpae()
    avant = f.read_bytes()
    dpae_api.basculer_en_test(avant, dpae.LONGUEUR)
    assert f.read_bytes() == avant
    assert dpae_api.est_reel(f.read_bytes())


def test_test_et_reel_sexcluent():
    code, txt = _lancer(Args(_fichier_dpae(), reel=True, test=True,
                             confirmer="2026-09"))
    assert code == 2
    assert "s'excluent" in txt


def test_code_service_25_est_configure():
    """FAQ Urssaf : « pour un declarant, il convient de parametrer le service 25 »."""
    assert (ctx.entreprise.get("api_dpae") or {}).get("service") == "25"
    client = dpae_api.ClientDpae(ctx)
    assert client.adresses["service"] == "25"


def test_declarant_dpae_distinct_du_declarant_dsn():
    """Deux comptes : Urssaf pour la DPAE, net-entreprises pour la DSN."""
    from moteur.netentreprises import Client, VARIABLE_MOTDEPASSE
    dpae_c, dsn_c = dpae_api.ClientDpae(ctx), Client(ctx)
    assert dpae_c.variable_motdepasse == dpae_api.VARIABLE_MOTDEPASSE_DPAE
    assert dsn_c.variable_motdepasse == VARIABLE_MOTDEPASSE
    assert dpae_c.variable_motdepasse != dsn_c.variable_motdepasse
    assert dpae_c.declarant["nom"] == "Simioni"      # sans accent, casse normale


def _fichier_dpae() -> Path:
    trouves = sorted((RACINE / "sorties").glob("*/DPAE_*.txt"), reverse=True)
    flux = [f for f in trouves if not f.stem.endswith("_recapitulatif")]
    assert flux, "aucun flux DPAE produit dans sorties/"
    return flux[0]


# ------------------------------------------ ce que l'Urssaf repond (Format 120)
def _certificat(*lignes) -> bytes:
    """Un certificat 41 comme l'Urssaf le renvoie : 989 caracteres + LF par
    DPAE, avec les zones de retour remplies. `lignes` : (nom, embauche
    JJMMAAAA, dossier, code, formalites a O)."""
    out = []
    for nom, emb, dossier, code, formalites in lignes:
        rec = [" "] * 989
        def poser(a, b, v):
            rec[a:b] = list(v.ljust(b - a)[:b - a])
        poser(*dpae.CHAMPS["nom"], nom)
        poser(*dpae.CHAMPS["nir"], "1000000000000")
        poser(*dpae.CHAMPS["date_embauche"], emb)
        poser(*dpae.ZONES_RETOUR["ret_ar_lot"], "00")
        poser(*dpae.ZONES_RETOUR["dossier"], dossier)
        poser(*dpae.ZONES_RETOUR["retour_ar"], code)
        for k, nomf in dpae.FORMALITES.items():
            poser(*dpae.ZONES_RETOUR[k], "O" if nomf in formalites else "N")
        out.append("".join(rec) + "\n")
    return "".join(out).encode("latin-1")


def test_le_certificat_se_lit_dpae_par_dpae():
    """Le 41 est NOTRE enregistrement renvoye, 989 caracteres et un saut de
    ligne, avec la reference de dossier et le code retour du Format 120.
    Le 99 avec un dossier est l'etat nominal observe sur 16 certificats sur
    16 depuis juin 2026 ; le 98 dit qu'il existait deja, rien de cree."""
    c = _certificat(("SIMIONI", "13092026", "11CVH", "99", ["CERTIF", "MT"]),
                    ("PUPPIS", "13092026", "11C9B", "98", []))
    l = dpae.lire_certificat(c)
    assert len(l) == 2
    assert l[0]["embauche"] == "2026-09-13" and l[0]["dossier"] == "11CVH"
    assert l[0]["enregistree"] and not l[0]["deja_existante"]
    assert l[0]["formalites"] == ["CERTIF", "MT"]
    assert l[1]["deja_existante"] and not l[1]["enregistree"]
    assert "existante" in l[1]["libelle"]
    # Et `relire`, qui sert a la reprise du journal, lit la meme chose : il
    # ne doit pas decaler d'un caractere a chaque ligne a cause du LF.
    recs = dpae._enregistrements(c)
    assert len(recs) == 2 and all(len(x) == 990 for x in recs)
    assert recs[1][dpae.CHAMPS["nom"][0]:].startswith("PUPPIS")


def test_un_flux_colle_se_lit_toujours():
    """Ce qu'on emet n'a pas de separateur : deux fois 990 caracteres."""
    rec = [" "] * 990
    a, b = dpae.CHAMPS["nom"]
    rec[a:b] = list("SIMIONI".ljust(b - a))
    recs = dpae._enregistrements(("".join(rec) * 2).encode("latin-1"))
    assert len(recs) == 2 and recs[1][a:b].strip() == "SIMIONI"


def test_le_journal_nomme_ce_que_dit_le_certificat():
    """Le verdict d'un 41 : OK avec les dossiers, ou KO avec le code nomme
    par le Format 120 -- et le resume cite la reference de dossier, c'est
    elle qu'on donne si l'Urssaf demande de quelle DPAE on parle."""
    from moteur import journal
    v = journal._verdict_du_certificat(
        _certificat(("SIMIONI", "13092026", "11CVH", "99", ["CERTIF", "MT"]),
                    ("PUPPIS", "13092026", "11C9B", "99", ["CERTIF", "MT"])))
    assert v["verdict"] == "OK" and v["anomalies"] == []
    assert [x["dossier"] for x in v["dpae"]] == ["11CVH", "11C9B"]
    ligne = {"quand": "2026-09-12T18:18:08", "mode": "reel", "accepte": True,
             "retours": [{"nature": "11", "verdict": "OK", "anomalies": []},
                         {"nature": "41", **v}]}
    r = journal.resume(ligne)
    assert "passée" in r and "11CVH" in r and "11C9B" in r

    ko = journal._verdict_du_certificat(
        _certificat(("SIMIONI", "13092026", "", "02", [])))
    assert ko["verdict"] == "KO"
    assert ko["anomalies"] == ["Code URSSAF invalide - n'appartenant pas à la liste des codes Urssaf -- SIMIONI"]

    deja = journal._verdict_du_certificat(
        _certificat(("SIMIONI", "13092026", "111AL", "98", [])))
    assert deja["verdict"] == "OK"        # l'embauche est declaree, par la premiere
    assert "existante" in journal.resume(dict(ligne, retours=[{"nature": "41", **deja}]))


def test_l_etat_des_embauches_porte_la_reference_de_dossier():
    from moteur import journal
    assert journal._meme_nom("PERE-LAHAILLE", "PERE LAHAILLE")
    assert journal._meme_nom("SIMIONI", "SIMIONI")
    assert not journal._meme_nom("SIMIONI", "PUPPIS")
    d = journal.dossiers_urssaf([{"nature": "41", "dpae": [
        {"nom": "SIMIONI", "embauche": "2026-09-13", "dossier": "11CVH"}]}])
    assert d[("SIMIONI", "2026-09-13")]["dossier"] == "11CVH"


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("  OK     %s" % nom)
        except AssertionError as exc:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, exc))
    print("\n%s" % ("Tous les tests passent." if not echecs
                    else "%d test(s) en echec." % echecs))
    sys.exit(1 if echecs else 0)
