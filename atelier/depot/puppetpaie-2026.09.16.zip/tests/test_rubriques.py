"""La COPIE du catalogue de CoolPaie -- 81 rubriques, gardee pour comprendre.

Ce n'est pas le catalogue qui paie. Celui-la est `moteur/rubriques-base.json`,
construit depuis les textes, et il a ses propres tests (test_catalogue.py).
Celui-ci est un releve : ce que CoolPaie porte, tel qu'il le porte, y compris
ses valeurs perimees.

Ce fichier ne teste pas du code, il teste une COMPREHENSION. Si l'un de ces
tests tombe, c'est soit que le releve a change, soit que la lecture qu'on en
avait faite etait fausse.

Le catalogue etant une donnee privee, ces tests se sautent proprement quand
`config/rubriques.json` est absent : un clone du depot public doit passer.
"""
import io
import sys
from contextlib import redirect_stdout
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent    # logiciel/ : le depot public
sys.path.insert(0, str(CODE))

from moteur import operations as ops                          # noqa: E402
from moteur.contexte import Contexte                           # noqa: E402

ctx = Contexte()
CATALOGUE = ctx.rubriques()

# Les cinq constantes, et d'ou elles viennent.
CACHET_ISOLE = 12       # reglement d'assurance chomage, annexe X, art. 3
CACHET_GROUPE = 8       # PERIME : supprime par le decret du 13 juillet 2016
JOUR = 7                # base journaliere de la profession
MOIS_JOURS = 21.67      # 5 x 52 / 12
MOIS_HEURES = 151.67    # 35 x 52 / 12


def _r(code):
    return CATALOGUE[code]


# ------------------------------------------------------- le catalogue existe
def test_le_catalogue_est_complet():
    assert len(CATALOGUE) == 81, (
        "81 rubriques attendues, %d trouvees" % len(CATALOGUE))


def test_le_catalogue_copie_de_coolpaie_ne_sert_pas_au_calcul():
    """Il y a DEUX catalogues, et un seul a le droit de calculer.

      - `config/rubriques.json`, la copie de CoolPaie : 81 rubriques dont
        `soumis` et `imposable` valent null. Elle sert a comprendre et a
        verifier, jamais a payer -- une paie en sortirait avec une assiette
        devinee.
      - `moteur/rubriques-base.json`, le catalogue de PuppetPaie : construit
        depuis les textes, chaque rubrique portant sa source. Celui-la
        calcule, depuis le 10/09/2026.

    Ce test garde la frontiere : aucun module de production ne consulte la
    copie."""
    for module in ("calcul.py", "dsn.py", "aem.py", "bulletin.py"):
        source = (CODE / "moteur" / module).read_text(encoding="utf-8")
        for interdit in ("ctx.rubriques(", "ctx.rubrique(",
                         "contexte.rubriques(", "contexte.rubrique("):
            assert interdit not in source, (
                "%s consulte %s -- c'est la copie de CoolPaie, ou soumis et "
                "imposable sont inconnus. Le catalogue qui calcule est "
                "moteur/catalogue.py." % (module, interdit))


def test_ce_qui_calcule_porte_un_assujettissement_connu():
    """La contrepartie de l'autorisation ci-dessus : toute rubrique que le
    calcul peut atteindre doit savoir si elle cotise et si elle est imposable.
    Aucune ne doit valoir null, faute de quoi on aurait juste deplace le
    probleme d'un fichier a l'autre."""
    sys.path.insert(0, str(CODE))
    from moteur import catalogue as base_cat
    for r in base_cat.catalogue():
        assert isinstance(r.soumis, bool), "%s.soumis inconnu" % r.code
        assert isinstance(r.imposable, bool), "%s.imposable inconnu" % r.code


def test_ce_qui_manque_est_dit_et_non_devine():
    """Ce qui n'est pas dans l'export CSV se RELEVE dans l'editeur de CoolPaie,
    il ne se devine pas. La regle : une rubrique ne porte de valeur sur ces
    champs que si elle porte aussi `releve_le`, la date ou quelqu'un a ouvert
    l'editeur et l'a lue. Sans cette date, tout doit rester a `null`.

    C'est le garde-fou qui a deja servi le 10/09/2026 : deux rubriques avaient
    recu `soumis: true` d'apres une colonne lue sur une capture d'ecran, sans
    que l'editeur soit ouvert. Il les a refusees."""
    A_RELEVER = ("soumis", "imposable", "calcul_automatique", "plafond",
                 "aem", "dsn_type", "dsn_autres_bruts", "dsn_specificite",
                 "bases")
    for code, r in CATALOGUE.items():
        if r.get("releve_le"):
            continue
        for champ in A_RELEVER:
            assert r.get(champ) is None, (
                "%s.%s a une valeur alors que %s n'a pas de `releve_le` : "
                "d'ou vient-elle ?" % (code, champ, code))


def test_la_rubrique_relevee_est_complete():
    """Une rubrique relevee porte les champs que l'editeur montre. A moitie
    relevee, elle serait pire que pas relevee du tout : on la croirait sue."""
    for code, r in CATALOGUE.items():
        if not r.get("releve_le"):
            continue
        for champ in ("soumis", "imposable", "calcul_automatique",
                      "plafond", "dsn_type", "bases"):
            assert r.get(champ) is not None, (
                "%s est marquee relevee le %s mais %s manque"
                % (code, r["releve_le"], champ))


def test_le_cachet_isole_est_releve():
    """`ci` est la premiere rubrique lue dans l'editeur, le 10/09/2026, et la
    seule dont on sache produire une paie aujourd'hui."""
    ci = _r("ci")
    assert ci["releve_le"] == "2026-09-10"
    assert ci["soumis"] is True and ci["imposable"] is True
    assert ci["plafond"] == "Cachet"       # parmi Heure/Jour/Cachet/Semaine/Mois
    assert ci["aem"] == "Cachet isole"     # parmi Cachet groupe / Cachet isole
    assert ci["dsn_type"] == "Salaire de base"   # S21.G00.51.011 = 010


# ------------------------------------------------- les cinq constantes
def test_le_cachet_isole_vaut_douze_heures():
    """Toujours vrai. Depuis 2016 c'est meme la SEULE valeur : tous les
    cachets valent 12 heures."""
    assert _r("ci")["heures"] == CACHET_ISOLE
    assert _r("ci")["jours"] == 1


def test_le_cachet_groupe_de_coolpaie_porte_une_valeur_perimee():
    """`cg` vaut 8 h dans leur catalogue. C'est FAUX depuis le decret du
    13 juillet 2016, qui a supprime la distinction isole / groupe : tous les
    cachets valent 12 heures. Ce test ne valide pas la regle, il constate que
    la copie porte l'erreur -- et c'est pour cela qu'elle ne paie pas.

    Le catalogue qui paie n'a qu'une rubrique `cachet`, a 12 h."""
    assert _r("cg")["heures"] == CACHET_GROUPE == 8
    assert _r("cg")["jours"] == 1


def test_la_journee_vaut_sept_heures():
    """Verifie par les semaines, qui ne sont que des journees empilees."""
    assert _r("s5")["jours"] == 5 and _r("s5")["heures"] == 5 * JOUR
    assert _r("s6")["jours"] == 6 and _r("s6")["heures"] == 6 * JOUR
    assert _r("absj")["jours"] == -1 and _r("absj")["heures"] == -JOUR


def test_le_mois_est_la_duree_legale_mensualisee():
    assert round(5 * 52 / 12, 2) == MOIS_JOURS
    assert round(35 * 52 / 12, 2) == MOIS_HEURES
    for code in ("m35", "grs", "sa53", "sa93"):
        assert _r(code)["jours"] == MOIS_JOURS
        assert _r(code)["heures"] == MOIS_HEURES


def test_l_absence_maladie_se_compte_au_trentieme():
    assert round(MOIS_JOURS / 30, 3) == 0.722
    assert round(MOIS_HEURES / 30, 3) == 5.056
    assert _r("absma")["jours"] == -0.722
    assert _r("absma")["heures"] == -5.056


def test_une_heure_vaut_un_septieme_de_journee():
    assert round(1 / 7, 3) == 0.143
    assert _r("ihap60#")["jours"] == 0.143
    assert _r("ahap#")["jours"] == -0.143


def test_les_journees_portent_leurs_heures_reelles():
    for code, heures in (("j8", 8), ("j10", 10), ("j12", 12)):
        assert _r(code)["jours"] == 1 and _r(code)["heures"] == heures


def test_les_repetitions_portent_leurs_heures_reelles():
    assert _r("srp3")["heures"] == 3 and _r("srp")["heures"] == 4
    # Le service ISOLE fait exception : demi-journee, mais cachet plein.
    assert _r("sri")["jours"] == 0.5 and _r("sri")["heures"] == CACHET_ISOLE


def test_les_absences_sont_les_presences_en_negatif():
    """Rien de nouveau a comprendre : une absence retire ce qu'une presence
    aurait apporte."""
    paires = [("absj", 1, JOUR), ("absm", MOIS_JOURS, MOIS_HEURES),
              ("acap#", 1, JOUR)]
    for code, jours, heures in paires:
        assert _r(code)["jours"] == -jours
        assert _r(code)["heures"] == -heures


# -------------------------------------------- ce qui n'est pas elucide
def test_le_diese_reste_une_question_ouverte():
    """21 codes finissent par '#'. Son sens n'est pas etabli -- ce test le
    constate plutot que de laisser croire qu'on sait."""
    marques = [c for c, r in CATALOGUE.items() if r["marque_diese"]]
    assert len(marques) == 21
    assert all(c.endswith("#") for c in marques)


def test_cinq_rubriques_seulement_portent_un_code_dsn():
    """Les autres alimentent le brut, declare globalement. Si ce nombre change,
    c'est que la correspondance avec la norme NEODeS a avance."""
    avec = {c for c, r in CATALOGUE.items() if r["dsn"]}
    assert avec == {"AENa", "co2", "co5", "dns", "tre"}


# ------------------------------------------------------------ l'acces
def test_une_rubrique_inconnue_leve():
    """Mieux vaut s'arreter que produire une paie avec un coefficient invente."""
    essai = False
    try:
        ctx.rubrique("cette-rubrique-n-existe-pas")
    except KeyError:
        essai = True
    assert essai


def test_la_commande_rubriques_montre_le_catalogue_qui_paie():
    """`ops.rubriques` ne rend plus la copie de CoolPaie mais le catalogue de
    base -- celui dont chaque rubrique porte sa source et son assujettissement.
    C'est ce que la ligne de commande affiche et ce que la saisie proposera."""
    liste = ops.rubriques(ctx)
    codes = {r["code"] for r in liste}
    assert "cachet" in codes and "journee" in codes
    assert "ci" not in codes and "j12" not in codes, (
        "ce sont les codes de CoolPaie : la commande montre le mauvais catalogue")
    for r in liste:
        assert isinstance(r["soumis"], bool) and r["source"]


# ----------------------------------------------------------------- execution
def _lancer():
    if not CATALOGUE:
        print("  (catalogue absent : config/rubriques.json n'est pas la)")
        print("\nTous les tests passent.")
        return 0
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    echecs = 0
    for nom, fn in tests:
        try:
            with redirect_stdout(io.StringIO()):
                fn()
            print("  OK     %s" % nom)
        except AssertionError as e:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    print()
    print("Tous les tests passent." if not echecs
          else "%d test(s) en echec." % echecs)
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(_lancer())
