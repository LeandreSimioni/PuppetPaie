"""Tests de l'interface -- la seconde face, et de ce qui la rend sure.

L'interface est la face la plus dangereuse du logiciel : c'est celle qui
ecrit la configuration, celle par ou l'on paie sans lire un fichier JSON, et
celle qu'un navigateur ouvre. Trois familles de tests, dans l'ordre du
risque :

  1. **Le jeton.** Le serveur n'ecoute que sur 127.0.0.1, mais un navigateur
     ouvre d'autres pages, et l'une d'elles pourrait parler a ce serveur.
  2. **Les memes garde-fous que la ligne de commande.** L'interface ne doit
     pas etre une porte derobee vers `dsn.ecrire`.
  3. **La resolution des noms.** Le bug le plus vicieux rencontre en
     construisant cet ecran : le fichier de saisie dit « Ana », la liste
     deroulante propose des cles, aucune ne correspond, et le navigateur
     retombe sur sa premiere option. L'interface changeait silencieusement
     QUI est paye. Deux tests le verrouillent.

Le serveur est demarre pour de vrai, sur un port ephemere : un test qui
n'appellerait que `_traiter` ne verrait ni le jeton ni le routage.
"""
import io
import json
import sys
import threading
import time
import urllib.error
import urllib.request
from contextlib import redirect_stdout
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent    # logiciel/ : le depot public
sys.path.insert(0, str(CODE))

from moteur import champs, operations as ops, web                # noqa: E402
from moteur.contexte import Contexte                             # noqa: E402

ctx = Contexte()
RACINE = ctx.racine        # prive/ : les donnees


# ------------------------------------------------------------- le serveur
class Serveur:
    """Demarre l'interface sur un port ephemere, le temps d'un test."""

    def __enter__(self):
        from http.server import ThreadingHTTPServer
        import secrets
        self.jeton = secrets.token_urlsafe(16)
        self.http = ThreadingHTTPServer(("127.0.0.1", 0),
                                        web._poignee(ctx, self.jeton))
        self.port = self.http.server_address[1]
        self.fil = threading.Thread(target=self.http.serve_forever, daemon=True)
        self.fil.start()
        return self

    def __exit__(self, *a):
        self.http.shutdown()
        self.http.server_close()

    def url(self, chemin, avec_jeton=True):
        return "http://127.0.0.1:%d%s%s" % (
            self.port, chemin, ("?jeton=" + self.jeton) if avec_jeton else "")

    # UNE SECONDE TENTATIVE SUR UNE SOCKET COUPEE, ET RIEN D'AUTRE. Vu le
    # 15/09/2026 : un test sur trente, jamais le meme, echoue en
    # ConnectionResetError (WinError 10054) -- Windows ferme parfois la
    # connexion d'un serveur qui vient de demarrer sur un port ephemere,
    # a l'ouverture (urllib l'enveloppe alors dans URLError) ou en pleine
    # lecture. Ce n'est pas le code teste ; la reponse d'une seconde requete
    # l'est. Une erreur HTTP ou une reponse fausse ne se rejouent pas.
    def _lire(self, req):
        for essai in (1, 2, 3):
            try:
                with urllib.request.urlopen(req, timeout=20) as r:
                    return r.status, r.read()
            except urllib.error.HTTPError as e:
                return e.code, e.read()
            except ConnectionResetError:
                if essai == 3:
                    raise
            except urllib.error.URLError as e:
                if essai == 3 or not isinstance(e.reason, ConnectionResetError):
                    raise
            time.sleep(0.1)

    def poster(self, route, charge, avec_jeton=True):
        req = urllib.request.Request(
            self.url("/api/" + route, avec_jeton),
            data=json.dumps(charge).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST")
        code, corps = self._lire(req)
        return code, json.loads(corps or b"{}")

    def obtenir(self, chemin, avec_jeton=True):
        return self._lire(self.url(chemin, avec_jeton))


# ------------------------------------------------------------- 1. le jeton

def _cachet(*dates, taux=130.0):
    """Une ligne de paie d'un cachet par date : la saisie minimale."""
    return {"rubrique": "cachet", "quantite": len(dates), "taux": taux,
            "dates": list(dates)}

def test_la_page_exige_le_jeton():
    with Serveur() as s:
        code, _ = s.obtenir("/", avec_jeton=False)
        assert code == 403, "la page s'ouvre sans jeton"


def test_l_api_exige_le_jeton():
    with Serveur() as s:
        code, d = s.poster("etat", {}, avec_jeton=False)
        assert code == 403 and not d["ok"]


def test_un_mauvais_jeton_ne_passe_pas():
    with Serveur() as s:
        req = urllib.request.Request(
            "http://127.0.0.1:%d/api/etat?jeton=faux" % s.port,
            data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
        try:
            urllib.request.urlopen(req, timeout=20)
            raise AssertionError("un jeton faux a ete accepte")
        except urllib.error.HTTPError as e:
            assert e.code == 403


def test_le_serveur_n_ecoute_que_la_boucle_locale():
    with Serveur() as s:
        assert s.http.server_address[0] == "127.0.0.1"


def test_la_page_porte_le_jeton_et_pas_le_gabarit():
    with Serveur() as s:
        code, corps = s.obtenir("/index.html")
        assert code == 200
        assert b"{{JETON}}" not in corps, "le gabarit n'a pas ete remplace"
        assert s.jeton.encode() in corps


def test_le_jeton_passe_en_cookie_et_quitte_la_barre_d_adresse():
    """15/09/2026 : « un truc plus esthetique, sans les jetons ». L'adresse
    avec jeton pose un cookie HttpOnly et renvoie sur `/` ; le cookie seul
    ouvre ensuite la page et l'API ; sans rien, toujours 403."""
    import http.client
    with Serveur() as s:
        c = http.client.HTTPConnection("127.0.0.1", s.port, timeout=20)
        c.request("GET", "/?jeton=" + s.jeton)
        r = c.getresponse(); r.read()
        assert r.status == 303 and r.getheader("Location") == "/"
        cookie = r.getheader("Set-Cookie")
        assert cookie.startswith("jeton=" + s.jeton) and "HttpOnly" in cookie
        assert "SameSite=Strict" in cookie
        c.request("GET", "/", headers={"Cookie": "jeton=" + s.jeton})
        r = c.getresponse(); corps = r.read()
        assert r.status == 200 and s.jeton.encode() in corps
        c.request("POST", "/api/etat", body=b"{}",
                  headers={"Cookie": "jeton=" + s.jeton,
                           "Content-Type": "application/json"})
        r = c.getresponse(); r.read()
        assert r.status == 200
        c.request("GET", "/", headers={"Cookie": "jeton=faux"})
        r = c.getresponse(); r.read()
        assert r.status == 403
        c.close()


# ------------------------------------------ 2. les memes garde-fous qu'ailleurs
def test_produire_sans_audiens_est_refuse():
    """Le point qui compte : l'interface n'est pas une porte derobee."""
    fichier = ctx._fichier_compteurs()
    avant = fichier.read_bytes()
    chemin_saisie = RACINE / "paies" / "2026-08.json"
    saisie_avant = chemin_saisie.read_bytes()
    copies_avant = len(list((RACINE / "paies" / "avant").glob("*")))         if (RACINE / "paies" / "avant").is_dir() else 0

    with Serveur() as s:
        saisie = ops.lire_saisie(chemin_saisie)
        code, d = s.poster("produire", {"mois": "2026-08", "saisie": saisie})
        assert not d["ok"], "une DSN a ete produite sans montant URSSAF"
        assert d["erreur"]["type"] == "UrssafManquant"
        assert d["erreur"]["estimation"], "de quoi redemander le montant"

    assert fichier.read_bytes() == avant, "un refus a consomme un numero"
    # Un refus ne doit RIEN laisser derriere lui -- pas meme une copie de
    # sauvegarde de la saisie. La premiere version enregistrait le fichier
    # avant de verifier le montant : treize copies en une seance de tests.
    assert chemin_saisie.read_bytes() == saisie_avant, "la saisie a ete reecrite"
    copies_apres = len(list((RACINE / "paies" / "avant").glob("*")))         if (RACINE / "paies" / "avant").is_dir() else 0
    assert copies_apres == copies_avant, "un refus a laisse une copie"


def test_l_apercu_n_ecrit_rien():
    fichier = ctx._fichier_compteurs()
    avant = fichier.read_bytes()
    with Serveur() as s:
        saisie = ops.lire_saisie(RACINE / "paies" / "2026-08.json")
        code, d = s.poster("apercu", {"saisie": saisie})
        assert d["ok"] and d["resultat"]["paies"]
    assert fichier.read_bytes() == avant


def test_une_fiche_fautive_est_refusee():
    """Une erreur bloque l'ecriture. Sans cela, l'interface serait un moyen
    plus rapide de casser la configuration qu'un editeur de texte.

    Le NIR est le bon exemple : personne ne peut le deduire d'autre chose,
    donc c'est bien une saisie -- contrairement au nom, voir le test suivant.
    """
    with Serveur() as s:
        fiche = dict(ctx.salaries["PUPPIS"], nir="123")     # trop court
        code, d = s.poster("enregistrer-fiche",
                           {"nom": "salarie", "cle": "PUPPIS", "donnees": fiche})
        assert not d["ok"] and d["erreur"]["type"] == "FicheRefusee"
        assert any(a["champ"] == "nir" for a in d["erreur"]["anomalies"])
    assert ctx.salaries["PUPPIS"]["nir"] != "123", "la fiche a ete ecrite"


def test_la_casse_n_est_pas_reprochee_a_l_humain():
    """« Père Lahaille » n'est pas une faute : c'est la bonne facon d'ecrire un
    nom. C'est au programme d'en tirer `PERE LAHAILLE` pour la DSN. Un
    formulaire qui exigerait des capitales sans accents ferait faire a
    l'humain le travail de la machine."""
    fiche = dict(ctx.salaries["PUPPIS"], nom_affichage="Père Lahaille",
                 nom="PERE LAHAILLE")
    anomalies = champs.verifier_fiche("salarie", fiche)
    assert not [a for a in anomalies if a["champ"] in ("nom", "nom_affichage")], (
        "la casse d'un nom saisi normalement est signalee comme une erreur")

    neuve = dict(ctx.salaries["PUPPIS"], nom_affichage="Père Lahaille")
    derives = champs.deriver("salarie", neuve, forcer=True)
    assert neuve["nom"] == "PERE LAHAILLE", "la forme declaree n'a pas ete fabriquee"
    assert "nom" in derives, "la derivation n'est pas rapportee a l'appelant"


def test_un_changement_de_forme_declaree_est_annonce():
    """Une derivation qui change ce qui part aux organismes doit se voir.
    C'est ce controle qui a trouve « ST GERORGES D ORQUES »."""
    fiche = {"nom": "PERE LAHAILLE", "nom_affichage": "Père Lahaille",
             "commune": "ST GERORGES D ORQUES",
             "commune_affichage": "Saint-Georges-d'Orques"}
    messages = [a["message"] for a in champs.verifier_fiche("salarie", fiche)
                if a["champ"] == "commune_affichage"]
    assert messages, "l'ecart entre declare et deduit n'est pas signale"
    assert "GERORGES" in messages[0], "le message ne montre pas ce qui est declare"


def test_aucun_champ_declare_n_est_propose_a_la_saisie():
    """Le formulaire ne doit montrer que ce que l'humain ecrit. Si un champ
    `officiel` cessait d'etre derive, il reapparaitrait dans l'ecran et on
    redemanderait des capitales."""
    for nom_fiche in ("entreprise", "salarie"):
        for c in champs.FICHES[nom_fiche]:
            if c.forme == "officiel":
                assert c.calcule, (
                    "%s.%s est un champ declaratif non derive : il serait "
                    "propose a la saisie" % (nom_fiche, c.cle))


def test_l_interface_ne_depose_que_par_operations():
    """Depuis le 11/09/2026 (§19), l'interface a le droit de deposer -- mais
    par `operations` seulement, qui porte la seance, la preuve et le << pas
    deux fois >>. Un appel direct a `dsn_api`, `dpae_api` ou `envoi` depuis
    web.py contournerait tout cela : c'est ce qu'on interdit ici.
    """
    # On regarde les APPELS, pas les mots : la premiere version de ce test
    # echouait sur le commentaire qui explique justement qu'on ne le fait pas.
    import ast
    arbre = ast.parse((CODE / "moteur" / "web.py").read_text(encoding="utf-8"))
    sensibles = {"confirmer_et_envoyer", "preparer_envoi", "relire_et_agir",
                 "expedier", "deposer", "deposer_dsn", "deposer_dpae", "envoyer",
                 "demander_signature"}
    hors_ops = set()
    for n in ast.walk(arbre):
        if not (isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)):
            continue
        if n.func.attr in sensibles and not (
                isinstance(n.func.value, ast.Name) and n.func.value.id == "ops"):
            hors_ops.add(n.func.attr)
    assert not hors_ops, (
        "web.py appelle %s ailleurs que sur `ops` : l'interface ne depose et "
        "n'envoie que par operations.py" % hors_ops)
    # Et les modules de transport ne sont pas importes du tout.
    importes = {a.name for n in ast.walk(arbre) if isinstance(n, ast.ImportFrom)
                for a in n.names}
    assert not (importes & {"dsn_api", "dpae_api", "netentreprises"}), importes


def test_une_route_inconnue_ne_plante_pas():
    with Serveur() as s:
        code, d = s.poster("nimportequoi", {})
        assert not d["ok"] and "inconnue" in d["erreur"]["message"].lower()


# --------------------------------------------- 3. la resolution des noms
def test_les_noms_parles_sont_resolus_en_cles():
    """Le fichier dit « Ana » et « oooh teresina » ; la liste deroulante
    propose des cles. Sans resolution, le navigateur retombe sur sa premiere
    option -- et paie quelqu'un d'autre."""
    saisie = {"mois": "2026-10", "spectacle": "oooh teresina",
              "taux_cachet": 130.0, "date_paiement": "2026-10-28",
              "engagements": [{"salarie": "Ana", "lignes": [_cachet("2026-10-02")]},
                              {"salarie": "Lenadre", "lignes": [_cachet("2026-10-02")]}]}
    r = web._resoudre_noms(ctx, saisie)
    assert [e["salarie"] for e in r["engagements"]] == ["PUPPIS", "SIMIONI"]
    assert r["spectacle"] in ctx.spectacles, "le spectacle n'est pas une cle"


def test_les_cles_resolues_existent_vraiment():
    """Une cle resolue doit correspondre a une option de la liste, sinon le
    probleme est seulement deplace."""
    with Serveur() as s:
        code, d = s.poster("etat", {})
        cles = {x["cle"] for x in d["resultat"]["salaries"]}
        code, d = s.poster("saisie", {"mois": "2026-10"})
        for e in d["resultat"]["saisie"]["engagements"]:
            assert e["salarie"] in cles, (
                "%r n'est pas dans la liste deroulante" % e["salarie"])


def test_une_saisie_irresoluble_est_rendue_telle_quelle():
    """Un salarie inconnu ne doit pas faire disparaitre la saisie : c'est
    l'apercu qui expliquera, avec son message a lui."""
    saisie = {"mois": "2026-10", "spectacle": "oooh teresina",
              "engagements": [{"salarie": "PERSONNE", "lignes": [_cachet("2026-10-02")]}]}
    r = web._resoudre_noms(ctx, saisie)
    assert r["engagements"][0]["salarie"] == "PERSONNE"


# ------------------------------------------------- la description des champs
def test_chaque_champ_decrit_existe_dans_les_donnees_reelles():
    """La description sert a dessiner le formulaire : un champ decrit qui
    n'existe nulle part afficherait une case vide sans raison.

    Exception : les formes lisibles des fiches d'avant. `nom_affichage` et
    `emploi_affichage` n'existent pas dans les donnees -- elles n'y ont
    jamais ete, l'humain tapait des capitales -- et c'est `combler_affichage`
    qui les fournit. Le test verifie donc les fiches COMBLEES, c'est-a-dire
    ce que l'ecran montre reellement.
    """
    reels = set()
    for s in ctx.salaries.values():
        reels |= set(champs.combler_affichage("salarie", s))
    decrits = {c.cle for c in champs.SALARIE}
    orphelins = decrits - reels
    assert not orphelins, "champs decrits mais absents partout : %s" % orphelins


def test_aucun_champ_reel_n_est_oublie_par_la_description():
    """Le symetrique : un champ present dans les donnees mais non decrit
    serait ineditable depuis l'interface, donc invisible."""
    decrits = {c.cle for c in champs.SALARIE}
    for cle, s in ctx.salaries.items():
        oublies = {k for k in s if not k.startswith("_")} - decrits
        assert not oublies, "%s porte %s, que l'interface ne montrerait pas" % (
            cle, oublies)


def test_la_cle_du_nir_se_verifie():
    """La regle : 97 - (NIR mod 97). Elle a deja servi -- c'est elle qui
    permet d'affirmer que notre NIR est bon quand un organisme en affiche un
    autre."""
    # On ne recopie pas de NIR ici : on verifie ceux de la configuration,
    # qui n'est pas dans le depot. Le test est meme plus fort ainsi -- il dit
    # que nos fiches sont coherentes, pas seulement que la formule tourne.
    for cle, s in ctx.salaries.items():
        if s.get("nir_cle"):
            assert champs.cle_nir(s["nir"]) == s["nir_cle"], (
                "la cle declaree de %s ne correspond pas a son NIR" % cle)
    assert champs.cle_nir("trop court") is None


def test_le_siret_de_la_compagnie_passe_luhn():
    assert champs.luhn(ctx.entreprise["siret"])


def test_les_abreviations_ne_font_pas_crier_au_loup():
    """« ST GEORGES » et « Saint-Georges » sont la meme commune ; une faute de
    frappe, non. Un avertissement qui se declenche a chaque fiche finit
    ignore le jour ou il a raison."""
    from moteur.champs import _comparable
    assert _comparable("ST GEORGES D ORQUES") == _comparable("Saint-Georges-d'Orques")
    assert _comparable("PARIS 12") == _comparable("Paris 12e")
    assert _comparable("CHATENAY MALABRY") == _comparable("Châtenay-Malabry")
    assert _comparable("ST GERORGES") != _comparable("Saint-Georges")   # la faute


# ------------------------------- les regles de forme, et d'ou elles viennent
def test_le_tiret_et_l_apostrophe_sont_autorises():
    """Cahier technique DSN 2026.1, section 3.5 : la table des caracteres
    autorises est un sous-ensemble d'ISO 8859-1 ou l'apostrophe (0x27) et le
    trait d'union (0x2D) ne sont PAS grises. Les exemples de la section 4 le
    confirment : 'MARTIN-DUPONT', 'DUBOIS ...--BEAUREGARD DE SAINT HAON'.

    Verifie aussi par les faits : sur 189 enregistrements AEM reellement
    deposes et acceptes, dix portent un trait d'union (dans le nom).
    """
    nom = next(c for c in champs.SALARIE if c.cle == "nom")
    for valeur in ("MARTIN-DUPONT", "O'BRIEN", "SAINT-GEORGES-D'ORQUES",
                   "DUBOIS DE LACIME--BEAUREGARD"):
        assert champs.verifier_champ(nom, valeur) is None, (
            "%r est refuse alors que la norme l'autorise" % valeur)


def test_les_accents_restent_interdits():
    """La table grise les accentues : « Le caractere est alphabetique
    majuscule, non accentue » (section 3.5)."""
    nom = next(c for c in champs.SALARIE if c.cle == "nom")
    assert champs.verifier_champ(nom, "PÈRE LAHAILLE") is not None


def test_les_regles_de_position_sont_appliquees():
    """Section 4 : ces regles ne se voient pas a l'oeil. Un nom finissant par
    un trait d'union passe la relecture et se fait rejeter des semaines plus
    tard, dans un bilan d'identification."""
    nom = next(c for c in champs.SALARIE if c.cle == "nom")
    for mauvais in ("-MARTIN", "MARTIN-", "MARTIN  DUPONT", "MARTIN -DUPONT",
                    "A--B--C", "MR MARTIN", "MARTIN."):
        assert champs.verifier_champ(nom, mauvais) is not None, (
            "%r est accepte alors que la norme le refuse" % mauvais)


def test_la_derivation_produit_une_forme_valide():
    """Ce que la machine fabrique doit passer ses propres controles : sinon
    elle produirait des declarations que le depot rejetterait."""
    nom = next(c for c in champs.SALARIE if c.cle == "nom")
    for saisi in ("Saint-Georges-d'Orques", "Châtenay-Malabry",
                  "Père  Lahaille ", "  Martin  ", "Paris 12e"):
        produit = champs.normaliser(nom, saisi)
        assert champs.verifier_champ(nom, produit) is None, (
            "la derivation de %r donne %r, que la norme refuse"
            % (saisi, produit))


def test_les_aem_deja_deposees_passent_les_controles():
    """Le juge de paix : ce qui a ete accepte par France Travail doit rester
    accepte par nos regles. Une regle trop stricte se verrait ici."""
    nom = next(c for c in champs.SALARIE if c.cle == "nom")
    for s in ctx.salaries.values():
        for cle in ("nom", "prenom", "commune", "lieu_naissance", "adresse"):
            v = s.get(cle)
            if not v:
                continue
            assert champs.verifier_champ(nom, v) is None, (
                "%r est declare depuis des annees et nos regles le refusent"
                % v)


# ----------------------------------------------------------------- execution
def _lancer():
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    echecs = 0
    for nom, fn in tests:
        try:
            with redirect_stdout(io.StringIO()):
                fn()
            print("  OK     %s" % nom)
        except AssertionError as e:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    print()
    print("Tous les tests passent." if not echecs
          else "%d test(s) en echec." % echecs)
    return 1 if echecs else 0


# ------------------------------------------- 4. la saisie par rubrique
def test_l_interface_recoit_le_catalogue_deja_trie():
    """La page ne trie ni ne decide : le moteur lui envoie les rubriques dans
    l'ordre ou les proposer, les cochees en tete."""
    with Serveur() as s:
        code, d = s.poster("etat", {})
    assert code == 200 and d["ok"]
    rub = d["resultat"]["rubriques"]
    assert rub, "le catalogue n'arrive pas dans la page"
    codes = [r["code"] for r in rub]
    assert "cachet" in codes and "journee" in codes
    assert "ci" not in codes, "c'est le catalogue de CoolPaie, pas le notre"
    actives = [i for i, r in enumerate(rub) if r["active"]]
    if actives:
        assert actives == list(range(len(actives))), (
            "les rubriques cochees doivent etre en tete")
    for r in rub:
        assert isinstance(r["soumis"], bool) and r["source"]


def test_une_saisie_par_rubrique_se_calcule_dans_l_interface():
    """Le chemin complet : la page envoie des lignes, le moteur rend une paie.
    Une journee de 5 heures -- ce que CoolPaie ne savait pas saisir."""
    with Serveur() as s:
        code, d = s.poster("apercu", {"saisie": {
            "mois": "2026-09", "spectacle": "oooh teresina",
            "date_paiement": "2026-09-30", "lieu": "",
            "engagements": [{
                "salarie": "Ana", "jours": 1,
                "lignes": [
                    {"rubrique": "cachet", "quantite": 1, "taux": 130.0,
                     "dates": ["2026-09-06"]},
                    {"rubrique": "journee", "quantite": 1, "taux": 90.0,
                     "heures": 5}]}]}})
    assert code == 200 and d["ok"], d
    paies = d["resultat"]["paies"]
    assert len(paies) == 1
    assert str(paies[0]["brut"]) == "220.00", paies[0]


def test_l_ancienne_ecriture_est_refusee_avec_le_chemin_de_la_conversion():
    """Depuis le 13/09/2026 le moteur ne lit plus `dates`/`cachets` sur
    l'engagement : un fichier d'avant se convertit une fois pour toutes
    (outils/convertir_saisies.py), et l'apercu doit le dire, pas planter."""
    ancienne = {"mois": "2026-09", "spectacle": "oooh teresina",
                "date_paiement": "2026-09-30", "lieu": "", "taux_cachet": 130.0,
                "engagements": [{"salarie": "Ana", "dates": ["2026-09-06", "2026-09-07"]}]}
    with Serveur() as s:
        _, a = s.poster("apercu", {"saisie": ancienne})
    assert not a["ok"], a
    assert "convertir_saisies" in a["erreur"]["message"], a["erreur"]


def test_cocher_une_rubrique_inconnue_est_refuse():
    """Une faute de frappe produirait un deroulant qui ne propose pas ce qu'on
    croit. Mieux vaut le dire que l'ignorer."""
    with Serveur() as s:
        code, d = s.poster("rubriques-actives", {"actives": ["cachet", "j12"]})
    assert not d["ok"]
    assert "j12" in d["erreur"]["message"]


def test_l_apercu_dit_ce_qui_est_paye_et_pas_un_nombre_de_cachets():
    """Un contrat d'une journee de 5 h et d'une masterclass n'a aucun cachet.
    L'apercu qui n'aurait que ce nombre l'afficherait « 0 cachet(s) » -- et
    c'est l'ecran qu'on relit avant de produire."""
    saisie = {"mois": "2026-09", "spectacle": "oooh teresina",
              "date_paiement": "2026-09-30", "lieu": "", "taux_cachet": 130.0,
              "engagements": [{
                  "salarie": "Ana", "jours": 1,
                  "lignes": [{"rubrique": "journee", "quantite": 1,
                              "taux": 200.0, "heures": 5, "dates": ["2026-09-06"]},
                             {"rubrique": "enseignement", "quantite": 6,
                              "taux": 40.0}]}]}
    with Serveur() as s:
        code, d = s.poster("apercu", {"saisie": saisie})
    assert code == 200 and d["ok"], d
    paie = d["resultat"]["paies"][0]
    assert paie["cachets"] == 0
    dits = [l["designation"] for l in paie["remuneration"]]
    assert dits[0].startswith("1 Journ")
    assert "Masterclass" in dits[1]


def test_l_apercu_d_un_mois_du_contrat_sans_cachet_calcule_une_paie_a_zero():
    """L'ecran envoie `lignes: []` quand un contrat aux bornes dites n'a
    aucune ligne remplie (15/09/2026) : le moteur en fait un mois sans paie,
    et le dit -- l'apercu doit le montrer, pas le refuser."""
    saisie = {"mois": "2026-11", "spectacle": "oooh teresina",
              "date_paiement": "2026-11-30", "lieu": "", "taux_cachet": 130.0,
              "engagements": [{"salarie": "Ana", "debut": "2026-10-12",
                               "fin": "2026-12-20", "numero": "PU1.26.99",
                               "lignes": []}]}
    with Serveur() as s:
        code, d = s.poster("apercu", {"saisie": saisie})
    assert code == 200 and d["ok"], d
    paie = d["resultat"]["paies"][0]
    assert paie["contrat"]["sans_paie"] is True
    assert paie["brut"] == "0.00" and paie["numero_bulletin"] is None
    assert paie["dates_travail"] == [] and paie["remuneration"] == []
    # Et la page sait ecrire ce cas : un bloc aux bornes dites sans ligne
    # remplie part en `lignes: []`.
    js = (CODE / "moteur" / "interface" / "interface.js").read_text(encoding="utf-8")
    assert "else if (debut && fin) e.lignes = [];" in js


def test_la_page_ne_fabrique_pas_la_phrase_de_remuneration():
    """Elle lit `remuneration` du moteur. Si elle se remettait a composer une
    phrase depuis `cachets`, les deux faces du logiciel finiraient par ne plus
    dire la meme chose du meme contrat."""
    js = (CODE / "moteur" / "interface" / "interface.js").read_text(encoding="utf-8")
    assert "${p.cachets}" not in js      # le nombre ne s'affiche plus seul
    assert "l.designation" in js


def test_les_deroulants_ne_proposent_pas_les_archives():
    """L'ecran de reglages garde tout -- on doit pouvoir relire et reactiver
    une fiche. Les listes ou l'on CHOISIT qui l'on paie, elles, n'ont que le
    courant."""
    from moteur.contexte import Contexte, archivee
    ctx = Contexte()
    archives = {k for k, v in ctx.salaries.items() if archivee(v)}
    if not archives:
        return
    with Serveur() as s:
        code, d = s.poster("etat", {})
    assert code == 200 and d["ok"], d
    etat = d["resultat"]
    proposes = {x["cle"] for x in etat["salaries"]}
    assert not (proposes & archives), proposes & archives
    # Mais elles restent dans la configuration, sinon on ne pourrait plus les
    # rouvrir.
    connues = {f["cle"] for f in etat["configuration"]["salaries"]}
    assert archives <= connues


def test_la_page_ne_demande_plus_les_cachets_a_la_main():
    """La saisie passe par les rubriques : les anciens champs `Cachets` et
    `Heures` de l'engagement n'ont plus lieu d'etre. S'ils reapparaissaient,
    on aurait deux facons de dire la meme chose, et l'une des deux serait
    fausse un jour."""
    js = (CODE / "moteur" / "interface" / "interface.js").read_text(encoding="utf-8")
    assert ".e-cachets" not in js and ".e-taux-horaire" not in js
    assert ".r-code" in js and ".r-quantite" in js


# ---------------------------------------------------- l'ecran par paie
# Ce que ces trois tests tiennent : le moteur savait repondre par paie depuis
# le 11/09/2026, et l'ecran ne le lui demandait pas. Une fonction que personne
# n'appelle est une fonction qui derive sans que rien ne tombe.


def test_l_etat_par_paie_dit_a_quelle_maille_chaque_acte_est_connu():
    """Le coeur de l'ecran par paie, et le seul endroit ou il peut mentir.

    Les quatre actes ne se declarent pas au meme grain -- une DSN est
    mensuelle, les documents partent par salarie -- et l'ecran ecrit cette
    maille a cote de chaque pastille. Si `maille` disparaissait de la reponse,
    la page afficherait << DSN deposee >> sur un bloc de paie sans dire qu'on
    parle du mois, et promettrait une precision que le journal n'a pas.
    """
    mois = "2026-09"
    if not (RACINE / "paies" / ("%s.json" % mois)).exists():
        return
    with Serveur() as s:
        code, d = s.poster("etat-par-paie", {"mois": mois})
    assert code == 200 and d["ok"], d
    paies = d["resultat"]["paies"]
    assert paies, "un mois saisi rend au moins une paie"
    attendues = {"dpae": "paie", "signature": "paie",
                 "documents": "salarie", "dsn": "mois"}
    for p in paies:
        # Ce que l'ecran lit pour designer la paie : sans la cle ET le debut,
        # il ne sait pas a quel bloc coller l'etat.
        assert p["salarie"] and p["debut"] and p["nom"]
        for acte, maille in attendues.items():
            assert p["etats"][acte]["maille"] == maille, (acte, p["etats"][acte])


def test_la_page_lit_l_etat_par_paie_et_ecrit_la_maille():
    """L'ecran par paie s'appuie sur deux routes que rien n'appelait avant le
    12/09/2026. Si un remaniement les debranchait, les pastilles
    disparaitraient sans qu'aucun test ne tombe -- et la page continuerait de
    s'afficher, ce qui est le pire des cas."""
    js = (CODE / "moteur" / "interface"
          / "interface.js").read_text(encoding="utf-8")
    assert '"etat-par-paie"' in js
    # La maille est ECRITE, pas seulement recue : c'est elle qui empeche de
    # lire << DSN deposee >> comme une DSN de cette paie-ci.
    assert "ditLaMaille" in js and "du mois" in js
    # Et la boite DPAE passe bien `paies` -- les embauches COCHEES, precochees
    # sur ce qui reste a declarer (15/09/2026) : sans ce mot, le bouton
    # ecrirait le mois entier et redeclarerait les embauches deja parties.
    assert "paies: choisies.map" in js
    assert "async function boiteDpae" in js
    # Plus de case de selection par carte ni de barre groupee : la boite
    # DPAE et la boite des signatures listent et cochent elles-memes.
    assert "e-choisi" not in js and "g-dpae" not in js
    # Et le retrait d'une paie est un bouton du bandeau, avec avertissement.
    assert "retirer-paie" in js and "Retirer quand même" in js
    # Et la colonne « ce qui part » lit le bilan du MOIS (bilan_du_mois),
    # pas le dernier envoi : « tous les contrats sont signés » en vert, et
    # non « envoyé le … » en orange (Léandre, 13/09/2026).
    assert "e.bilans[a.cle]" in js


def test_une_dpae_partielle_refuse_une_paie_qui_n_existe_pas():
    """Le garde-fou que l'ecran ne doit pas avoir a refaire. Une case cochee
    qu'on ne retrouve pas manquerait en silence, et ce serait justement celle
    qui comptait -- d'ou le refus, sans rien ecrire."""
    mois = "2026-09"
    if not (RACINE / "paies" / ("%s.json" % mois)).exists():
        return
    with Serveur() as s:
        code, d = s.poster("dpae", {
            "mois": mois,
            "paies": [{"salarie": "PERSONNE", "debut": "2026-09-06"}]})
    assert code == 200
    assert not d["ok"], "une selection introuvable doit etre refusee"
    assert "Rien n'est ecrit" in d["erreur"]["message"], d["erreur"]


# Le lanceur DOIT rester en dernier. Place au milieu du fichier -- ou il etait
# jusqu'au 10/09/2026 -- il ne voyait que les tests definis avant lui : les
# sept suivants ne s'executaient pas, et `sys.exit` sortait avant meme de les
# definir. Meme faute que dans test_catalogue.py, ou le bloc manquait tout
# court.
if __name__ == "__main__":
    sys.exit(_lancer())
