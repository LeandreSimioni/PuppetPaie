"""Tests de non-regression.

    python -m pytest tests -q        (si pytest est installe)
    python tests/test_non_regression.py

Les valeurs attendues viennent des documents reellement produits par CoolPaie :
bulletin PUPPIS de juin 2026, DSN de juillet 2026, AEM du 28/08/2026.
"""
import sys
from decimal import Decimal
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent    # logiciel/ : le depot public
sys.path.insert(0, str(CODE))

from moteur.aem import enregistrement as aem_enregistrement  # noqa: E402
from moteur.calcul import Engagement, calculer                # noqa: E402
from moteur.contexte import Contexte, racine_donnees                          # noqa: E402
from moteur.util import d as _d                              # noqa: E402
from moteur.verif import rejouer_dsn                          # noqa: E402

ctx = Contexte()
RACINE = ctx.racine        # prive/ : les donnees


def _ent(date_ref):
    """Entreprise avec la licence en vigueur a cette date.

    Le numero de licence est date (recepisse 2019001116 jusqu'au 31/08/2026,
    puis L-R-24-2). L'AEM refuse une liste non resolue : c'est voulu, pour
    qu'un appelant distrait n'ecrive pas une licence au hasard.
    """
    return dict(ctx.entreprise, licence_spectacle=ctx.licence(date_ref))



def _eng(**kw):
    """Un engagement de test « un cachet par date », en lignes de paie.

    Les tests d'ici decrivent des contrats de cachets par leurs dates et un
    taux ; depuis le 13/09/2026 le moteur ne lit que des lignes. L'assistant
    ecrit la ligne `cachet` que la saisie d'avant sous-entendait -- dans les
    tests seulement, le moteur n'a plus de defaut.
    """
    if not kw.get("lignes"):
        dates = kw.get("dates_travail") or []
        kw["lignes"] = [{"rubrique": "cachet", "quantite": len(dates),
                         "taux": kw.get("taux_cachet", 130.0)}]
    return Engagement(**kw)

def test_bulletin_juin_2026():
    """PUPPIS, 2 cachets a 130 EUR, spectacle Si j'avais un oeuf."""
    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-06-07", "2026-06-20"], taux_cachet=130.0))
    assert p.brut == Decimal("260.00")
    assert p.base_csg == Decimal("258.34")
    assert p.total_pat == Decimal("149.66")
    assert p.total_sal == Decimal("58.68")
    assert p.net_a_payer == Decimal("201.32")
    assert p.net_imposable == Decimal("208.81")
    assert p.plafond == Decimal("172.34")
    assert p.cout_employeur == Decimal("409.66")


def test_arrondis_agreges():
    """La ligne 'autres contributions 0,680 %' vaut 1,95 et non 1,94 :
    deux contributions arrondies separement (0,590 + 0,090)."""
    p = calculer(ctx, _eng(salarie="PUPPIS", spectacle="oooh teresina",
                                 dates_travail=["2026-06-07", "2026-06-20"]))
    assert p.ligne("autres_3").montant_pat == Decimal("1.95")
    assert p.ligne("ccn").montant_pat == Decimal("1.30")
    assert p.ligne("csg_ded").montant_sal == Decimal("17.57")


def test_plafond_suit_le_smic():
    """Plafond DSN = SMIC horaire x 7 h x cachets, SMIC revalorise au 01/06/2026."""
    avant = calculer(ctx, _eng(salarie="Ana", spectacle="oooh teresina",
                                     dates_travail=["2026-02-12"]))
    apres = calculer(ctx, _eng(salarie="Ana", spectacle="oooh teresina",
                                     dates_travail=["2026-07-12"]))
    assert avant.plafond == Decimal("84.14")   # 12,02 x 7
    assert apres.plafond == Decimal("86.17")   # 12,31 x 7


def test_aem_identique_a_coolpaie():
    """L'enregistrement AEM regenere doit etre identique octet pour octet."""
    gabarit = (RACINE / "gabarits" / "aem_v5_gabarit.txt").read_text(
        encoding="latin-1").rstrip("\r\n")
    p = calculer(ctx, _eng(
        salarie="PUPPIS", spectacle="266Z06538765",
        dates_travail=["2026-08-12", "2026-08-29"], taux_cachet=130.0,
        debut="2026-08-12", fin="2026-08-29"))
    assert aem_enregistrement(p, _ent(p.engagement.fin), 132) == gabarit


def test_bulletin_mixte_cotise_par_rubrique():
    """Bulletin 27/2026 : les cotisations se calculent rubrique par rubrique.

    CoolPaie arrondit chaque cotisation sur chaque rubrique de salaire, puis
    somme ; l assiette CSG suit la meme regle, mais les cotisations CSG se
    calculent une seule fois sur l assiette agregee. Sur ce contrat (1 cachet
    a 130 EUR + 12 h a 20 EUR), le calcul global donnerait 213,00 de charges
    patronales au lieu de 212,99, et 367,64 d assiette CSG au lieu de 367,63.
    """
    p = calculer(ctx, _eng(
        salarie="PUPPIS", spectacle="266Z09294456",
        dates_travail=["2026-08-23", "2026-08-24", "2026-08-25", "2026-08-26"],
        lignes=[{"rubrique": "cachet", "quantite": 1, "taux": 130.0},
                {"rubrique": "heure", "quantite": 12, "taux": 20.0}], jours=4,
        debut="2026-08-23", fin="2026-08-26"))
    assert p.brut == Decimal("370.00"), p.brut
    assert p.base_csg == Decimal("367.63"), p.base_csg
    assert p.total_pat == Decimal("212.99"), p.total_pat
    assert p.total_sal == Decimal("83.50"), p.total_sal
    assert p.net_a_payer == Decimal("286.50"), p.net_a_payer
    assert p.cout_employeur == Decimal("582.99"), p.cout_employeur



def test_aem_contrat_mixte_cachets_et_heures():
    """Zone AEM [650:659] : heures (3) + cachets (2) + jours travailles (4).

    Elucide en confrontant le formulaire officiel (affichage/aemV5/aemV501.pdf,
    "Nombre d'HEURES effectuees" / "Nombre de CACHETS" / "Nombre de JOURS
    travailles") aux 189 enregistrements de export/AEM_EDI. Cas reel : le
    contrat du 23 au 26 aout 2026, 1 cachet a 130 EUR et 12 heures a 20 EUR,
    soit 370 EUR de brut sur 4 jours travailles.
    """
    ref = ctx.export / "AEM_EDI" / "_280826_15h26m23s_EDIV5.txt"
    if not ref.exists():
        print("  (ignore : export/AEM_EDI de CoolPaie absent)")
        return
    brut_ref = ref.read_bytes().decode("latin-1")
    attendu = brut_ref.split(chr(13) + chr(10))[2]

    p = calculer(ctx, _eng(
        salarie="PUPPIS", spectacle="266Z09294456",
        dates_travail=["2026-08-23"],
        lignes=[{"rubrique": "cachet", "quantite": 1, "taux": 130.0},
                {"rubrique": "heure", "quantite": 12, "taux": 20.0}], jours=4,
        debut="2026-08-23", fin="2026-08-26"))
    assert p.brut == Decimal("370.00"), p.brut

    refait = aem_enregistrement(p, _ent(p.engagement.fin), 134,
                                date_emission=_d("2026-08-26"),
                                signataire=attendu[866:891])
    assert refait[650:659] == "012010004", refait[650:659]
    assert refait[650:659] == attendu[650:659]
    assert refait == attendu, [j for j in range(999) if refait[j] != attendu[j]][:12]


def test_l_ancienne_ecriture_est_refusee():
    """`cachets`/`heures` sur l'engagement ne se lisent plus : le message
    renvoie a l'outil de conversion, il ne calcule pas faux en silence."""
    try:
        Engagement(salarie="PUPPIS", spectacle="266Z09294456",
                   dates_travail=["2026-08-23"])      # le moteur, pas l'assistant
    except ValueError as e:
        assert "convertir_saisies" in str(e)
        return
    raise AssertionError("un engagement sans ligne a ete accepte")



def test_dsn_juillet_2026_identique():
    """997 lignes identiques a la DSN deposee le 04/08/2026."""
    ref = ctx.export / "DSN" / "Juillet_CCoU_040826_MENSUELLE.dsn"
    if not ref.exists():
        print("  (ignore : export/DSN de CoolPaie absent)")
        return
    ecarts = rejouer_dsn(ctx, ref)
    assert ecarts == [], "\n".join(ecarts)


def test_dpae_identique_a_coolpaie():
    """Les 6 enregistrements DPAE du 28/08/2026 sont reconstitues octet pour octet."""
    import datetime
    from moteur import dpae
    ref = (RACINE / "gabarits" / "due_tel_gabarit.txt").read_text(encoding="latin-1")
    recs = [ref[i * 990:(i + 1) * 990] for i in range(len(ref) // 990)]
    horodatage = datetime.datetime(2026, 8, 28, 15, 12, 11)
    # Les fiches telles qu'elles etaient le jour du depot. Une DPAE porte
    # l'identite du salarie : elle change (demenagement, commune de naissance
    # corrigee), et ce qui est parti ce jour-la ne change plus.
    ctx_depot = Contexte(ctx.racine, date=horodatage.date())
    for i, r in enumerate(recs):
        champs = {k: r[a:b] for k, (a, b) in dpae.CHAMPS.items()}
        sal = next(k for k, s in ctx_depot.salaries.items() if s["nir"] == champs["nir"])
        p = calculer(ctx_depot, _eng(
            salarie=sal, spectacle="266Z06538765",
            dates_travail=[champs["date_embauche"]],
            debut=champs["date_embauche"], fin=champs["date_fin"]))
        refait = dpae.enregistrement(p, horodatage,
                                     heure_embauche=champs["heure_embauche"])
        assert refait == r, "enregistrement %d" % (i + 1)


def test_noms_tolerants():
    assert ctx.salarie("Ana")["nom"] == "PUPPIS"
    assert ctx.salarie("Lenadre")["nom"] == "SIMIONI"       # faute de frappe
    assert ctx.salarie("anastasia")["nom"] == "PUPPIS"
    assert ctx.spectacle("teresina")["numero_objet"] == "266Z06538765"


def test_licence_datee():
    """Le recepisse jusqu'au 31/08/2026, la licence L-R-24-2 ensuite."""
    assert ctx.licence("2026-08-31") == "2019001116"
    assert ctx.licence("2026-09-01") == "L-R-24-2"
    assert ctx.licence("2021-05-04") == "2019001116"


def test_aem_licence_ne_deborde_pas():
    """Poser la nouvelle licence ne doit pas decaler le reste de l'AEM.

    Le champ fait 10 caracteres, deduits des 189 enregistrements historiques ;
    il est suivi de "NN". La licence L-R-24-2 en fait 8, donc completee par des
    espaces. Ce test verifie que l'enregistrement garde sa longueur et que le
    voisin immediat est intact -- le seul controle possible sans le cahier des
    charges EDI de l'AEM.
    """
    from moteur.aem import CHAMPS, LONGUEUR
    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="oooh teresina",
        dates_travail=["2026-09-10", "2026-09-11"], taux_cachet=130.0))
    r = aem_enregistrement(p, _ent("2026-09-01"), 138)
    a, b = CHAMPS["licence"]
    assert len(r) == LONGUEUR
    assert r[a:b] == "L-R-24-2  "
    assert r[b:b + 2] == "NN", "le champ voisin a ete decale : %r" % r[b:b + 4]

    ancien = aem_enregistrement(p, _ent("2026-08-01"), 138)
    assert ancien[a:b] == "2019001116"
    # Hors du champ licence, les deux enregistrements sont identiques.
    assert ancien[:a] == r[:a] and ancien[b:] == r[b:]


def test_plafond_urssaf_six_bulletins_coolpaie():
    """Le « Plafond Urssaf » du bas de bulletin, sur six cas reels.

    Trois annees, trois versions de CoolPaie, et les deux branches de la regle :
    trois cas ou le prorata calendaire l'emporte, trois ou le plancher des
    12 heures par cachet l'emporte.
    """
    from moteur.plafond import plafond_urssaf
    from decimal import Decimal
    cas = [
        # (debut, fin, cachets, attendu, source)
        ("2021-07-01", "2021-07-02", 2, "624.00", "BS 072021 ANASTASIA.pdf"),
        ("2021-01-04", "2021-01-22", 9, "2808.00", "BSSIMIONI012021.pdf"),
        ("2023-11-16", "2023-11-25", 3, "1222.00", "_301123_20h51m10s_Bulletin.pdf"),
        ("2026-05-13", "2026-05-22", 1, "1291.94", "UEUEUE MAI 26.pdf p1"),
        ("2026-05-24", "2026-05-24", 1, "360.00", "UEUEUE MAI 26.pdf p3"),
        ("2026-05-27", "2026-05-28", 2, "720.00", "UEUEUE MAI 26.pdf p4"),
        ("2026-02-12", "2026-02-12", 1, "360.00", "BPFEV2026UEUEUEL.pdf p1"),
        ("2026-02-07", "2026-02-08", 2, "720.00", "BPFEV2026UEUEUEL.pdf p2"),
        # Chez un autre employeur (AKD), meme logiciel : la regle tient aussi.
        ("2023-02-12", "2023-02-14", 3, "972.00", "BP AKD PUPPIS FEV23 p3"),
        ("2021-10-06", "2021-10-08", 3, "936.00", "BP AKD PUPPIS OCT2021 p1"),
        ("2022-03-15", "2022-03-15", 1, "312.00", "BP AKD PUPPIS MARS2022 p1"),
    ]
    for debut, fin, cachets, attendu, source in cas:
        obtenu = plafond_urssaf(debut, fin, cachets)
        assert obtenu == Decimal(attendu), (
            "%s : %s attendu, %s obtenu" % (source, attendu, obtenu))


def test_plafond_urssaf_exception_connue_akd_mars_2023():
    """Le seul contre-exemple rencontre sur 30 bulletins, documente comme tel.

    AKD, 20 au 25/03/2023, 6 cachets : CoolPaie affiche 709,55 (le prorata)
    la ou la regle donne 1 944,00 (le plancher). Ce test fige l'ecart pour
    qu'il reste visible ; si un jour on l'explique, il faudra le reecrire.
    """
    from moteur.plafond import plafond_urssaf, prorata_calendaire
    from decimal import Decimal
    assert plafond_urssaf("2023-03-20", "2023-03-25", 6) == Decimal("1944.00")
    assert prorata_calendaire("2023-03-20", "2023-03-25").quantize(
        Decimal("0.01")) == Decimal("709.55")


def test_plafond_urssaf_refuse_une_annee_inconnue():
    """Sans PSS publie, on ne devine pas : le plafond borne des cotisations."""
    from moteur.plafond import plafond_urssaf, PlafondInconnu
    try:
        plafond_urssaf("2031-05-01", "2031-05-02", 1)
    except PlafondInconnu as exc:
        assert "BOSS" in str(exc)
    else:
        raise AssertionError("PlafondInconnu attendu")


def test_plafond_urssaf_contrat_a_cheval_sur_deux_mois():
    """Chaque mois est proratise par son propre nombre de jours."""
    from moteur.plafond import prorata_calendaire
    from decimal import Decimal
    # 28/02 au 02/03/2026 : 1 jour sur fevrier (28 j) + 2 jours sur mars (31 j)
    attendu = (Decimal(4005) * 1 / 28) + (Decimal(4005) * 2 / 31)
    assert abs(prorata_calendaire("2026-02-28", "2026-03-02") - attendu) < Decimal("0.01")


# --------------------------------------- certificat d'emploi Conges Spectacles
def test_cs_arrondi_a_l_euro():
    """Les cases SALAIRE BRUT et BASE CONGE n'ont pas de decimales.

    Le formulaire l'ecrit sous chaque case : « arrondi a l'euro le plus
    proche ». Moitie superieure, comme tout arrondi de paie.
    """
    from moteur.conges_spectacles import arrondi_euro
    assert arrondi_euro(Decimal("260.00")) == 260
    assert arrondi_euro(Decimal("129.49")) == 129
    assert arrondi_euro(Decimal("129.50")) == 130
    assert arrondi_euro(Decimal("130.50")) == 131   # pas d'arrondi au pair


def test_cs_base_conge_vaut_le_brut():
    """Base conge = brut, faute de minimum conventionnel releve.

    Verifie sur les deux certificats reels en notre possession : Frappaz
    200/200, extranet Audiens 260/260. Le plafonnement au triple du minimum
    conventionnel ne s'applique que si la fiche du salarie le porte.
    """
    from moteur.conges_spectacles import base_conge
    assert base_conge(Decimal("260.00"), {}) == Decimal("260.00")
    assert base_conge(Decimal("900.00"),
                      {"minimum_conventionnel_cachet": 130}) == Decimal("390")


def test_cs_un_certificat_par_contrat():
    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-06-07", "2026-06-20"], taux_cachet=130.0))
    from moteur import conges_spectacles as cs
    assert cs.nombre([p]) == 1
    c, = cs.certificats(p, premier_numero=1)
    assert (c.numero, c.nb_jours_ou_cachets) == (1, 2)
    assert c.brut == Decimal("260.00") and c.base == Decimal("260.00")
    # Emis a la fin du contrat, faute de date d'emission explicite.
    assert c.emission == _d("2026-06-20")


def test_cs_coupure_au_31_mars():
    """Une activite en cours au 31 mars donne DEUX certificats.

    La periode de reference des conges va du 1er avril au 31 mars : le
    certificat de la premiere periode est remis avant le depart en conge,
    celui de la seconde a la fin de l'emploi.
    """
    from moteur import conges_spectacles as cs
    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-03-30", "2026-03-31", "2026-04-01"],
        taux_cachet=130.0))
    a, b = cs.certificats(p, premier_numero=10)
    assert (a.numero, a.nb_jours_ou_cachets, a.brut) == (10, 2, Decimal("260"))
    assert a.debut == _d("2026-03-30") and a.fin == _d("2026-03-31")
    assert (b.numero, b.nb_jours_ou_cachets, b.brut) == (11, 1, Decimal("130"))
    assert b.debut == _d("2026-04-01") and b.fin == _d("2026-04-01")
    assert a.brut + b.brut == p.brut


def test_cs_coupure_refusee_quand_la_repartition_serait_arbitraire():
    """Un document qui vaut cheque sur notre compte ne se repartit pas au juge."""
    from moteur import conges_spectacles as cs
    for eng in (
            _eng(salarie="Ana", spectacle="si j'avais un oeuf",
                       dates_travail=["2026-03-30", "2026-04-01"],
                       lignes=[{"rubrique": "cachet", "quantite": 2, "taux": 130.0},
                               {"rubrique": "heure", "quantite": 12, "taux": 20.0}]),
            _eng(salarie="Ana", spectacle="si j'avais un oeuf",
                       dates_travail=["2026-03-30", "2026-04-01"],
                       lignes=[{"rubrique": "cachet", "quantite": 3, "taux": 130.0}])):
        try:
            cs.decouper(eng)
        except ValueError as exc:
            assert "31 mars" in str(exc)
        else:
            raise AssertionError("decoupage arbitraire accepte")


def test_cs_numero_ce_ne_repart_pas_a_zero_chaque_annee():
    """Le N° CE est une sequence employeur continue, delivree par Audiens.

    Relue annee par annee, elle repartirait a 1 chaque janvier et deux
    certificats porteraient le meme numero.
    """
    from moteur.contexte import Contexte, racine_donnees
    c = Contexte()
    c.compteurs = lambda: {"2026": {"certificat_cs": 4},
                           "_note": "une chaine, pas un compteur"}
    assert c.prochain_continu("certificat_cs", 2027) == 5
    c.enregistrer_compteur("certificat_cs", 2027, 9)
    assert c.prochain_continu("certificat_cs", 2027) == 10
    assert c.prochain_continu("certificat_cs", 2026) == 10


def test_cs_refuse_d_ecrire_sans_numero_de_compte():
    """Sans le numero d'adherent Audiens, la case COMPTE serait vide."""
    from moteur import conges_spectacles as cs
    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-06-07"], taux_cachet=130.0))
    ent = dict(_ent("2026-06-07"), congesspectacles_adherent="")
    try:
        cs.ecrire([p], ent, RACINE / "sorties" / "_jamais_ecrit.pdf",
                  premier_numero=1)
    except ValueError as exc:
        assert "congesspectacles_adherent" in str(exc)
    else:
        raise AssertionError("PDF ecrit sans numero de compte")


# --------------------------------------------- AEM papier et envoi aux salaries
def test_aem_papier_et_edi_portent_le_meme_montant():
    """Le salarie doit retrouver sur son attestation le chiffre depose.

    L'AEM papier et le fichier EDI passent par `aem.contribution` : c'est la
    seule facon de garantir qu'ils ne divergent pas.
    """
    from moteur import aem, aem_pdf
    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-06-07", "2026-06-20"], taux_cachet=130.0))
    v = aem_pdf.valeurs(p, _ent("2026-06-20"), num_attestation=138)
    # 260 EUR a 12,15 % = 31,59 -> 32 EUR, arrondi a l'euro impose par le format
    assert aem.contribution(p) == Decimal("32")
    assert v["contributions"] == "32,00" and v["total"] == "32,00"
    assert v["brut"] == "260,00" and v["taux"] == "12,15"
    # meme numero que dans l'enregistrement EDI
    enr = aem_enregistrement(p, _ent("2026-06-20"), 138)
    assert enr[36:42] == "000138" == v["attestation"]


def test_aem_papier_refuse_une_licence_non_resolue():
    """Meme garde-fou que l'EDI : pas de structure Python sur un formulaire."""
    from moteur import aem_pdf
    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-06-07"], taux_cachet=130.0))
    try:
        aem_pdf.valeurs(p, ctx.entreprise, num_attestation=1)
    except ValueError as exc:
        assert "licence_spectacle" in str(exc)
    else:
        raise AssertionError("licence non resolue acceptee")


def test_envoi_un_seul_message_par_salarie():
    """Deux contrats dans le mois pour la meme personne : un seul message."""
    from moteur import envoi
    paies = [calculer(ctx, _eng(
                 salarie="Ana", spectacle="si j'avais un oeuf",
                 dates_travail=[jour], taux_cachet=130.0))
             for jour in ("2026-06-07", "2026-06-20")]
    messages = envoi.preparer(paies, ctx.entreprise, "2026-06",
                              RACINE / "sorties" / "_inexistant")
    assert len(messages) == 1
    m = messages[0]
    assert m.destinataire == ctx.salaries["PUPPIS"]["email"].lower()
    assert "juin 2026" in m.corps and "Juin 2026" in m.sujet
    # dossier absent : aucune piece jointe inventee
    assert m.pieces == []


def test_envoi_refuse_un_salarie_sans_adresse():
    """Mieux vaut s'arreter que preparer un message qui n'ira nulle part."""
    from moteur import envoi
    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-06-07"], taux_cachet=130.0))
    p.salarie = dict(p.salarie, email="")
    try:
        envoi.preparer([p], ctx.entreprise, "2026-06", RACINE / "sorties")
    except ValueError as exc:
        assert "e-mail" in str(exc)
    else:
        raise AssertionError("salarie sans adresse accepte")


def test_google_ne_demande_que_ce_qui_a_ete_decide():
    """Chaque permission est une decision, et deux sont interdites.

    `gmail.compose` (deposer des brouillons) est RESTREINTE et n'a jamais ete
    reprise : la page de relecture locale en tient lieu. `gmail.modify` non
    plus : le logiciel n'ecrit rien dans la boite. `gmail.readonly`, elle,
    est restreinte aussi et a ete ACCEPTEE le 15/09/2026, pour relever les
    contrats signes d'un clic (« s'il faut ajouter des autorisations Gmail
    pour la lecture, pas de soucis »). Si quelqu'un ajoute un scope un jour,
    ce test doit le lui rappeler.
    """
    from moteur import google
    assert set(google.PERMISSIONS) == {
        "https://www.googleapis.com/auth/gmail.send",
        "https://www.googleapis.com/auth/gmail.readonly",
        "https://www.googleapis.com/auth/drive.file",
        "https://www.googleapis.com/auth/userinfo.email",   # non sensible
    }
    assert not any("compose" in p or "modify" in p or "mail.google.com" in p
                   for p in google.PERMISSIONS)


def test_google_ne_demande_rien_a_l_utilisateur_qui_installe():
    """Une seule application, la notre, embarquee : pas de console par compagnie.

    `config/google.json` reste possible mais n'est qu'une echappatoire ; le
    chemin normal ne doit exiger aucun fichier de configuration.
    """
    import tempfile
    from pathlib import Path as _P
    from moteur import google

    with tempfile.TemporaryDirectory() as tmp:
        class FauxCtx:
            racine = _P(tmp)
        (_P(tmp) / "config").mkdir()
        ancien = dict(google.APPLICATION)
        google.APPLICATION.update(client_id="test.apps.googleusercontent.com",
                                  client_secret="secret")
        try:
            ids = google.identifiants(FauxCtx())
            assert ids["client_id"] == "test.apps.googleusercontent.com"
            assert ids["origine"] == "le logiciel"
            # ... et l'echappatoire l'emporte quand elle existe.
            (_P(tmp) / "config" / "google.json").write_text(
                '{"client_id": "amoi", "client_secret": "s"}', encoding="utf-8")
            assert google.identifiants(FauxCtx())["client_id"] == "amoi"
        finally:
            google.APPLICATION.clear()
            google.APPLICATION.update(ancien)


def test_google_le_jeton_n_est_jamais_ecrit_en_clair():
    """Sur Windows, DPAPI le lie au compte : le fichier seul ne vaut rien."""
    import sys
    import tempfile
    from pathlib import Path as _P
    from moteur import google

    if sys.platform != "win32":
        return
    secret = "1//0g-faux-jeton-de-rafraichissement"
    with tempfile.TemporaryDirectory() as tmp:
        class FauxCtx:
            racine = _P(tmp)
        (_P(tmp) / "config").mkdir()
        chemin = google._ecrire_jeton(FauxCtx(), secret, "qui@gmail.com")
        sur_disque = _P(chemin).read_bytes()
        assert secret.encode() not in sur_disque, "jeton lisible sur disque"
        assert b"qui@gmail.com" not in sur_disque, "adresse lisible sur disque"
        assert google._lire_jeton(FauxCtx())["rafraichissement"] == secret
        assert google.compte_autorise(FauxCtx()) == "qui@gmail.com"
        assert google.autorise(FauxCtx())
        assert google.oublier(FauxCtx()) and not google.autorise(FauxCtx())


def test_envoi_ne_parle_plus_ni_smtp_ni_imap():
    """Le mot de passe d'application a disparu avec eux (09/09/2026)."""
    from pathlib import Path as _P
    from moteur import envoi
    assert not hasattr(envoi, "deposer_brouillons")
    source = _P(envoi.__file__).read_text(encoding="utf-8")
    for mort in ("import smtplib", "import imaplib", "GMAIL_MOTDEPASSE"):
        assert mort not in source, "%s traine encore dans envoi.py" % mort


def test_envoi_dit_ce_qui_est_deja_parti_quand_ca_casse():
    """Un envoi n'est pas une transaction : si le 2e echoue, le 1er est parti.

    Le message d'erreur doit le dire, sinon on renvoie tout et le premier
    salarie recoit deux fois ses documents.
    """
    from moteur import envoi

    class ClientQuiCasseAuDeuxieme:
        def __init__(self):
            self.faits = 0

        def envoyer(self, mime):
            self.faits += 1
            if self.faits == 2:
                raise RuntimeError("HTTP 500")
            return "id%d" % self.faits

    messages = [envoi.Message(cle=c, nom=c, destinataire="%s@ex.fr" % c,
                              sujet="s", corps="c") for c in ("un", "deux")]
    try:
        envoi.envoyer(messages, "moi@ex.fr", ClientQuiCasseAuDeuxieme())
    except RuntimeError as exc:
        assert "deja partis" in str(exc) and "un@ex.fr" in str(exc)
    else:
        raise AssertionError("echec partiel passe sous silence")


def test_page_de_relecture_n_a_plus_qu_un_bouton():
    """Un seul geste possible, et il est explicite."""
    from moteur import envoi
    m = envoi.Message(cle="ana", nom="Ana", destinataire="a@ex.fr",
                      sujet="Juin 2026", corps="Bonjour")
    page = envoi._page([m], "Juin 2026", "JETON", "moi@gmail.com")
    assert page.count("<button") == 1
    assert "brouillon" not in page.lower()
    assert "moi@gmail.com" in page


# ------------------- les documents lisent les lignes, ils ne les redevinent pas
def test_le_bulletin_imprime_chaque_ligne_de_remuneration():
    """Une journee de 5 h et une masterclass ne sont pas des cachets. La
    ligne unique « N Cachets isoles a X » les aurait perdues -- et aurait
    imprime « 0 Cachets isoles a 130,00 » sur un contrat sans cachet."""
    from moteur.bulletin import _bloc_remuneration

    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="oooh teresina",
        dates_travail=["2026-11-05", "2026-11-06"],
        lignes=[{"rubrique": "journee", "quantite": 1, "taux": 200.0,
                 "heures": 5},
                {"rubrique": "enseignement", "quantite": 6, "taux": 40.0}]))
    html = _bloc_remuneration(p)
    assert "Journ&eacute;e de travail" in html or "Journée de travail" in html
    assert "Masterclass" in html
    assert "200,00" in html and "240,00" in html
    assert "SALAIRE BRUT" in html
    assert "Cachet" not in html
    assert p.brut == Decimal("440.00")


def test_un_contrat_de_cachets_garde_sa_ligne_unique():
    """Le bulletin de cinq ans ne change pas de forme : la designation, le
    taux et SALAIRE BRUT sur le meme rang."""
    from moteur.bulletin import _bloc_remuneration

    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-06-07", "2026-06-20"], taux_cachet=130.0))
    html = _bloc_remuneration(p)
    assert html.count("<tr") == 1
    assert "2 Cachets &agrave; 130,00 &mdash; SALAIRE BRUT" in html


def test_le_contrat_dit_la_remuneration_quelle_qu_en_soit_la_forme():
    """Un contrat se signe : « 0 cachet(s) de 130,00 EUR » ne se rattrape pas."""
    from moteur.contrat import _remuneration_detaillee

    pur = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-06-07", "2026-06-20"], taux_cachet=130.0))
    assert _remuneration_detaillee(pur) == "2 cachets à 130,00 €"

    melange = calculer(ctx, _eng(
        salarie="Ana", spectacle="oooh teresina",
        dates_travail=["2026-11-05"],
        lignes=[{"rubrique": "journee", "quantite": 1, "taux": 200.0,
                 "heures": 5},
                {"rubrique": "enseignement", "quantite": 6, "taux": 40.0}]))
    assert _remuneration_detaillee(melange) == (
        "1 journée de travail à 200,00 € et "
        "6 h de masterclass / action culturelle à 40,00 €")


def test_un_lieu_par_cachet_et_le_contrat_nomme_les_villes():
    """Quatre Teresina, un a Berlin, un a Paris, deux a Varzy.

    C'est UNE paie -- meme spectacle, donc meme numero d'objet -- donc UN
    contrat, un bulletin, une AEM. Seul le contrat doit nommer les villes : le
    lieu ne se declare ni en DSN, ni en AEM, ni en DPAE.
    """
    from moteur.contrat import _dates_travail, _lieu_du_contrat

    e = _eng(
        salarie="Ana", spectacle="oooh teresina",
        dates_travail=[{"jour": "2026-10-02", "lieu": "Berlin"},
                       {"jour": "2026-10-09", "lieu": "Paris"},
                       {"jour": "2026-10-16", "lieu": "Varzy"},
                       {"jour": "2026-10-17", "lieu": "Varzy"}],
        taux_cachet=130.0)
    # Rien de ce que lisent l'AEM, la DSN ou le bulletin n'a change de forme.
    assert e.dates_travail == [_d("2026-10-02"), _d("2026-10-09"),
                               _d("2026-10-16"), _d("2026-10-17")]
    assert e.cachets == 4 and e.jours == 4
    assert str(e.debut) == "2026-10-02" and str(e.fin) == "2026-10-17"

    assert _dates_travail(e) == ("02/10/2026 à Berlin, 09/10/2026 à Paris, "
                                 "16/10/2026 et 17/10/2026 à Varzy")
    assert _lieu_du_contrat(e) == "aux lieux indiqués ci-dessus"
    assert e.lieu_de("2026-10-16") == "Varzy"


def test_l_ancienne_ecriture_des_dates_donne_le_meme_contrat_qu_avant():
    """Le rejeu tient le moteur : une saisie ecrite avant le 12/09/2026 ne
    doit pas changer d'un caractere, ni dans le contrat, ni ailleurs."""
    from moteur.contrat import _dates_travail, _lieu_du_contrat

    nu = _eng(salarie="Ana", spectacle="oooh teresina",
                    dates_travail=["2026-10-02", "2026-10-09"],
                    taux_cachet=130.0)
    assert _dates_travail(nu) == "02/10/2026, 09/10/2026"
    assert _lieu_du_contrat(nu) == "au lieu de la représentation"

    # Un lieu d'engagement, comme aujourd'hui : la date ne le repete pas, il
    # est dit une fois a l'article << Lieu de travail >>.
    un = _eng(salarie="Ana", spectacle="oooh teresina",
                    dates_travail=["2026-10-02", "2026-10-09"],
                    taux_cachet=130.0, lieu="Varzy")
    assert _dates_travail(un) == "02/10/2026, 09/10/2026"
    assert _lieu_du_contrat(un) == "à Varzy"
    assert un.lieu_de("2026-10-02") == "Varzy"

    # Et la date l'emporte sur l'engagement, jamais l'inverse.
    mixte = _eng(salarie="Ana", spectacle="oooh teresina",
                       dates_travail=["2026-10-02",
                                      {"jour": "2026-10-09", "lieu": "Paris"}],
                       taux_cachet=130.0, lieu="Varzy")
    assert mixte.lieu_de("2026-10-02") == "Varzy"
    assert mixte.lieu_de("2026-10-09") == "Paris"
    assert _dates_travail(mixte) == "02/10/2026 à Varzy, 09/10/2026 à Paris"


def test_le_modele_de_contrat_n_impose_plus_le_cachet():
    """Le gabarit est une donnee privee : ce test se saute sur un clone du
    depot public."""
    modele = RACINE / "gabarits" / "contrat-cddu.modele"
    if not modele.exists():
        return
    texte = modele.read_text(encoding="utf-8")
    article = next(l for l in texte.splitlines() if "L'artiste per" in l)
    assert "{{remuneration.detail}}" in article
    assert "{{remuneration.cachets}}" not in article


def test_la_dsn_ne_declare_pas_zero_cachet_isole():
    """Un contrat sans cachet -- une journee, une masterclass -- se declarait
    « 37 - cachets isoles : 0 ». La norme (NEODeS 2026.1, S21.G00.53.003) a
    « 35 - heures intermittents du spectacle » pour ce cas.

    Les contrats a cachets, eux, ne bougent pas : le rejeu de 50 DSN le dit.
    """
    from moteur import dsn

    def _mesures(eng):
        """Les couples (unite, mesure) du bloc Activite d'une paie."""
        texte = dsn.generer(ctx, [calculer(ctx, eng)], "2026-11",
                            versement_urssaf=0.0)
        out, mesure = [], None
        for ligne in texte.splitlines():
            cle, _, val = ligne.partition(",")
            if cle == "S21.G00.53.002":
                mesure = val.strip("'")
            elif cle == "S21.G00.53.003":
                out.append((val.strip("'"), mesure))
        return out

    cachets = _mesures(_eng(
        salarie="Ana", spectacle="oooh teresina",
        dates_travail=["2026-11-05", "2026-11-06"], taux_cachet=130.0))
    assert cachets == [("12", "2.00"), ("37", "2.00")], cachets

    sans_cachet = _mesures(_eng(
        salarie="Ana", spectacle="oooh teresina",
        dates_travail=["2026-11-05"],
        lignes=[{"rubrique": "journee", "quantite": 1, "taux": 200.0,
                 "heures": 5}]))
    assert sans_cachet == [("12", "1.00"), ("35", "5.00")], sans_cachet


def test_cs_une_journee_sans_cachet_ne_certifie_pas_zero():
    """La case du formulaire s'intitule « NB JOURS OU CACHETS ». Un contrat
    d'une journee de 5 h n'a aucun cachet : c'est le jour travaille qui va
    dedans. Zero sur un document qui vaut cheque, ce serait un droit perdu."""
    from moteur import conges_spectacles as cs

    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="oooh teresina",
        dates_travail=["2026-11-05"],
        lignes=[{"rubrique": "journee", "quantite": 1, "taux": 200.0,
                 "heures": 5}]))
    c, = cs.certificats(p, premier_numero=1)
    assert c.nb_jours_ou_cachets == 1
    assert c.brut == Decimal("200.00")


def test_dsn_contrat_mixte_declare_les_heures_EN_PLUS_des_cachets():
    """Un contrat a cachets ET heures declare les trois unites d'activite.

    LE BUG QUE CE TEST FIGE, trouve le 10/09/2026 par l'AER d'aout.

    `dsn.py` ecrivait `if cachets: ... elif heures: ...`. Un contrat mixte
    prenait donc la premiere branche et ses HEURES NE PARTAIENT PAS. Rien ne
    le signalait : ni la DSN, ni le compte-rendu metier, ni l'attestation --
    qui affiche simplement une case vide. Les heures comptent dans les 507
    des annexes 8 et 10 : une heure non declaree est un droit perdu.

    Ce n'etait PAS un comportement herite de CoolPaie. CoolPaie declare bien
    les trois unites, et onze contrats de export/DSN le prouvent. Le plus net
    est octobre 2025, PU1.25.14 et SI2.25.17 -- un cachet, quarante heures,
    onze jours :

        11.00 unite 12 (jours)  1.00 unite 37 (cachets)  40.00 unite 35 (heures)

    Le rejeu ne l'avait pas attrape parce qu'il ne rejoue que 2026, faute de
    baremes anterieurs, et que les mois mixtes de 2026 divergent deja pour
    d'autres raisons. D'ou ce test, qui ne depend d'aucun barème ancien.

    Unites de mesure S21.G00.53.003, cahier technique NEODeS :
        12 = journee   35 = heures intermittents du spectacle   37 = cachets
    """
    import re
    from moteur import dsn

    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-08-23", "2026-08-24", "2026-08-25", "2026-08-26"],
        lignes=[{"rubrique": "cachet", "quantite": 1, "taux": 130.0},
                {"rubrique": "heure", "quantite": 12, "taux": 20.0}]))
    assert p.brut == Decimal("370.00"), p.brut     # 130 + 12 x 20

    texte = dsn.generer(ctx, [p], "2026-08", versement_urssaf=782.00)

    quantites, unites = [], []
    for ligne in texte.splitlines():
        m = re.match(r"S21\.G00\.53\.002,'(.+)'", ligne)
        if m:
            quantites.append(m.group(1))
        m = re.match(r"S21\.G00\.53\.003,'(.+)'", ligne)
        if m:
            unites.append(m.group(1))
    active = dict(zip(unites, quantites))

    assert active.get("12") == "4.00", "jours travailles : %r" % active
    assert active.get("37") == "1.00", "cachets : %r" % active
    # LA LIGNE QUI MANQUAIT.
    assert active.get("35") == "12.00", \
        "les heures ne sont pas declarees : %r" % active


def test_dsn_contrat_sans_cachet_declare_ses_heures_seules():
    """Une masterclass sans cachet : les heures, et pas de « 0 cachet »."""
    import re
    from moteur import dsn

    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-08-23", "2026-08-24"],
        lignes=[{"rubrique": "heure", "quantite": 8, "taux": 20.0}]))
    texte = dsn.generer(ctx, [p], "2026-08", versement_urssaf=782.00)
    unites = re.findall(r"S21\.G00\.53\.003,'(.+)'", texte)
    assert "35" in unites, unites
    assert "37" not in unites, "un contrat sans cachet ne declare pas 0 cachet"


def test_dsn_annule_et_remplace_se_code_sans_identifiant():
    """Type 03 + ordre superieur, et SURTOUT pas de S20.G00.05.006.

    Trouve le 10/09/2026 en deposant en test. La plate-forme a rendu deux
    anomalies bloquantes :

        CST-04      Presence de la rubrique interdite S20.G00.05.006.
        B1-208-08   'annule et remplace' ou 'annule' sans normale prealable.

    Le cahier technique decrit cette rubrique comme portant l'identifiant de
    la derniere declaration « relative au meme EVENEMENT » : c'est le
    vocabulaire des signalements, pas celui d'une mensuelle. Pour une DSN
    mensuelle, la plate-forme retrouve seule la declaration a remplacer.
    """
    from moteur import dsn

    p = calculer(ctx, _eng(
        salarie="Ana", spectacle="si j'avais un oeuf",
        dates_travail=["2026-08-23"], taux_cachet=130.0))

    # La rubrique interdite est refusee a la source.
    try:
        dsn.generer(ctx, [p], "2026-08", versement_urssaf=697.00,
                    type_declaration="03", ordre=2, remplace="030920261")
    except ValueError as e:
        assert "CST-04" in str(e), e
    else:
        raise AssertionError("aurait du refuser S20.G00.05.006")

    # Un ordre non superieur aussi.
    try:
        dsn.generer(ctx, [p], "2026-08", versement_urssaf=697.00,
                    type_declaration="03", ordre=1)
    except ValueError:
        pass
    else:
        raise AssertionError("aurait du refuser ordre=1")

    texte = dsn.generer(ctx, [p], "2026-08", versement_urssaf=697.00,
                        type_declaration="03", ordre=2)
    assert "S20.G00.05.002,'03'" in texte
    assert "S20.G00.05.004,'2'" in texte
    assert "S20.G00.05.006" not in texte


# ------------------------------------------ une fiche est une suite d'etats
def test_une_fiche_se_lit_a_la_date_de_la_declaration():
    """Une valeur declaree qui change ne doit pas reecrire le passe.

    C'est le mecanisme qui permet de corriger une commune de naissance ou
    d'enregistrer un demenagement sans que tous les rejeux passent au rouge :
    la declaration de juillet est partie avec ce qu'on savait en juillet.
    """
    from moteur.contexte import telle_qu_au
    fiche = {"adresse": "APRES",
             "historique": [{"champ": "adresse", "valeur": "AVANT",
                             "jusqu_au": "2026-09-10"}]}
    assert telle_qu_au(fiche, "2026-07-31")["adresse"] == "AVANT"
    assert telle_qu_au(fiche, "2026-09-10")["adresse"] == "AVANT"   # borne incluse
    assert telle_qu_au(fiche, "2026-09-11")["adresse"] == "APRES"
    # Les autres champs ne bougent pas, et une fiche sans histoire est rendue
    # telle quelle : le mecanisme ne peut pas modifier une valeur en douce.
    assert telle_qu_au(dict(fiche, nom="X"), "2021-01-01")["nom"] == "X"
    assert telle_qu_au({"nom": "X"}, "2021-01-01") == {"nom": "X"}


def test_une_fiche_empile_plusieurs_changements():
    """Deux demenagements : chaque fenetre rend la valeur de SON epoque."""
    from moteur.contexte import telle_qu_au
    fiche = {"adresse": "TROISIEME",
             "historique": [
                 {"champ": "adresse", "valeur": "PREMIERE", "jusqu_au": "2024-06-30"},
                 {"champ": "adresse", "valeur": "DEUXIEME", "jusqu_au": "2026-09-10"},
             ]}
    assert telle_qu_au(fiche, "2023-01-01")["adresse"] == "PREMIERE"
    assert telle_qu_au(fiche, "2024-06-30")["adresse"] == "PREMIERE"
    assert telle_qu_au(fiche, "2024-07-01")["adresse"] == "DEUXIEME"
    assert telle_qu_au(fiche, "2026-09-11")["adresse"] == "TROISIEME"


def test_le_contexte_date_ne_bouge_que_ce_qui_est_date():
    """Deux contextes a deux dates : seuls les champs a `historique` different.

    Le mecanisme ne coute rien a une compagnie qui n'a jamais rien corrige, et
    il ne peut pas faire bouger un champ dont personne n'a date le changement.
    """
    avant = Contexte(RACINE, date="2021-01-01")
    apres = Contexte(RACINE, date="2030-01-01")
    for cle, a in avant.salaries.items():
        b = apres.salaries[cle]
        dates = {e["champ"] for e in a.get("historique", [])}
        bouges = {k for k in set(a) | set(b) if a.get(k) != b.get(k)}
        assert bouges <= dates, "%s a bouge sans historique : %s" % (cle, bouges)


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("  OK     %s" % nom)
        except AssertionError as exc:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, exc))
    print("\n%s" % ("Tous les tests passent." if not echecs
                    else "%d test(s) en echec." % echecs))
    sys.exit(1 if echecs else 0)
