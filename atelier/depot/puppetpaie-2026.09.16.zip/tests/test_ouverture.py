"""Tests de l'ouverture : le coffre, la seance, et la sauvegarde du prive.

Ce que le logiciel s'est mis a faire seul le 11/09/2026 -- sauvegarder les
donnees, relever les retours -- repose sur un secret garde sur le disque. Ce
fichier verrouille ce qui rend cette entorse tenable :

  1. LE SECRET NE SORT PAS. Ni par `etat()`, ni en clair dans le fichier.
  2. LE TRANSPORT N'OUVRE PAS LE COFFRE. `dsn_api`, `dpae_api` et
     `netentreprises` ne le mentionnent meme pas : ils recoivent un mot de
     passe, ils ne vont jamais le chercher. C'est ce qui garantit qu'un depot
     ne peut pas partir d'un secret ramasse tout seul quelque part.
  3. UN DEPOT SE CONFIRME. `lire(usage=DEPOT)` refuse sans confirmation.
  4. LA SEANCE DURE CE QUE DURE LA FENETRE -- pas une echeance, un
     proprietaire -- et une seance fermee interdit le depot.
  5. LA SAUVEGARDE NE SUPPRIME RIEN et n'envoie que ce qui a change.

Aucun test ne touche au reseau : la sauvegarde est exercee contre un faux
client Drive, qui enregistre ce qu'on lui demande.
"""
import os
import sys
import types
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import coffre, operations as ops, sauvegarde          # noqa: E402


def _ctx(tmp: Path):
    """Un contexte reduit a ce dont le coffre et la sauvegarde ont besoin."""
    (tmp / "config").mkdir(parents=True, exist_ok=True)
    return types.SimpleNamespace(racine=tmp)


def _tmp(nom: str) -> Path:
    import tempfile
    return Path(tempfile.mkdtemp(prefix="puppetpaie-%s-" % nom))


# ---------------------------------------------------- 1. le secret ne sort pas
def test_le_coffre_ne_rend_jamais_la_valeur_dans_son_etat():
    ctx = _ctx(_tmp("etat"))
    coffre.poser(ctx, coffre.NET_ENTREPRISES, "MotDePasseTresSecret42")
    for s in coffre.etat(ctx):
        texte = repr(s)
        assert "MotDePasseTresSecret42" not in texte, \
            "etat() a laisse filtrer un mot de passe : %s" % texte
    assert any(s.pose for s in coffre.etat(ctx)), "il devait pourtant etre pose"


def test_le_fichier_sur_le_disque_ne_contient_pas_le_mot_de_passe_en_clair():
    """Sous Windows, DPAPI. Ailleurs, le test se tait -- et le module le dit."""
    if not coffre.dpapi_disponible():
        return
    ctx = _ctx(_tmp("dpapi"))
    coffre.poser(ctx, coffre.URSSAF, "UnSecretTresReconnaissable")
    octets = coffre.chemin(ctx).read_bytes()
    assert b"UnSecretTresReconnaissable" not in octets
    assert coffre.lire(ctx, coffre.URSSAF,
                       usage=coffre.CONSULTATION) == "UnSecretTresReconnaissable"


def test_un_secret_tronque_a_la_saisie_est_refuse():
    """Le 11/09/2026, la saisie masquee n'a capture qu'UN caractere.

    Le coffre l'a range sans broncher, et la panne est ressortie une heure plus
    tard sous la forme d'un « HTTP 422 parametres invalides » qui ne designait
    rien -- on a d'abord soupconne le compte, puis la configuration. Un secret
    d'un caractere n'est pas un mot de passe court : c'est une saisie perdue.
    """
    ctx = _ctx(_tmp("court"))
    for essai in ("x", "abc", "12345"):
        refuse = False
        try:
            coffre.poser(ctx, coffre.NET_ENTREPRISES, essai)
        except coffre.ErreurCoffre:
            refuse = True
        assert refuse, "un secret de %d caractere(s) a ete accepte" % len(essai)
    assert not coffre.pose(ctx, coffre.NET_ENTREPRISES), "quelque chose a ete ecrit"
    coffre.poser(ctx, coffre.NET_ENTREPRISES, "unvraimotdepasse")
    assert coffre.pose(ctx, coffre.NET_ENTREPRISES)


def test_le_mot_de_passe_du_logiciel_n_est_pas_stocke_mais_condense():
    ctx = _ctx(_tmp("ouverture"))
    coffre.poser_ouverture(ctx, "sesame-ouvre-toi")
    assert coffre.verifier_ouverture(ctx, "sesame-ouvre-toi")
    assert not coffre.verifier_ouverture(ctx, "sesame-ouvre-toi ")
    assert not coffre.verifier_ouverture(ctx, "autre chose")
    # Meme dechiffre, le fichier ne permet pas de retrouver le mot de passe.
    brut = coffre.chemin(ctx).read_bytes()
    if coffre.dpapi_disponible():
        brut = coffre.deproteger(brut)
    assert b"sesame-ouvre-toi" not in brut


# ------------------------------------- 2. le transport n'ouvre pas le coffre
def test_les_modules_de_transport_ignorent_le_coffre():
    """La separation qui tient tout : ils RECOIVENT un secret, ils n'en cherchent pas.

    Si ce test tombe, ce n'est pas un detail de style : cela veut dire qu'un
    module qui parle au reseau peut se servir seul dans le coffre, et que plus
    rien ne garantit qu'un depot a ete voulu par quelqu'un.

    On lit l'ARBRE SYNTAXIQUE, pas le texte. La premiere version cherchait le
    mot « coffre » dans la source et tombait sur les commentaires qui
    expliquent justement pourquoi ces modules n'y touchent pas -- un test qui
    interdit d'ecrire la regle qu'il fait respecter ne sert personne.
    """
    import ast
    for nom in ("dsn_api.py", "dpae_api.py", "netentreprises.py"):
        arbre = ast.parse((CODE / "moteur" / nom).read_text(encoding="utf-8"))
        for noeud in ast.walk(arbre):
            if isinstance(noeud, ast.Import):
                for a in noeud.names:
                    assert "coffre" not in a.name, "%s importe le coffre" % nom
            elif isinstance(noeud, ast.ImportFrom):
                cible = "%s %s" % (noeud.module or "",
                                   " ".join(a.name for a in noeud.names))
                assert "coffre" not in cible, "%s importe le coffre" % nom
            elif isinstance(noeud, ast.Attribute) and \
                    isinstance(noeud.value, ast.Name):
                assert noeud.value.id != "coffre", \
                    "%s appelle le coffre : la separation est rompue" % nom


# ------------------------------------------------- 3. un depot se confirme
def test_lire_pour_un_depot_exige_une_confirmation():
    ctx = _ctx(_tmp("confirme"))
    coffre.poser(ctx, coffre.NET_ENTREPRISES, "secret")
    refuse = False
    try:
        coffre.lire(ctx, coffre.NET_ENTREPRISES, usage=coffre.DEPOT)
    except coffre.ErreurCoffre:
        refuse = True
    assert refuse, "un depot a pu lire le coffre sans confirmation"
    assert coffre.lire(ctx, coffre.NET_ENTREPRISES, usage=coffre.DEPOT,
                       confirme="2026-08") == "secret"


def test_lire_sans_dire_pourquoi_est_refuse():
    ctx = _ctx(_tmp("usage"))
    coffre.poser(ctx, coffre.NET_ENTREPRISES, "secret")
    for usage in (None, "", "autre"):
        refuse = False
        try:
            coffre.lire(ctx, coffre.NET_ENTREPRISES, usage=usage)
        except coffre.ErreurCoffre:
            refuse = True
        assert refuse, "usage=%r aurait du etre refuse" % usage


# --------------------------------------------------------- 4. la seance
def test_sans_mot_de_passe_du_logiciel_la_seance_est_ouverte():
    """On n'invente pas un verrou que personne n'a demande."""
    ctx = _ctx(_tmp("sansverrou"))
    s = coffre.seance(ctx)
    assert s.ouverte and not s.exigee
    assert coffre.autorise_depot(ctx)[0]


def test_une_seance_fermee_interdit_le_depot():
    ctx = _ctx(_tmp("fermee"))
    coffre.poser_ouverture(ctx, "ouvre-toi")
    assert not coffre.seance(ctx).ouverte
    permis, pourquoi = coffre.autorise_depot(ctx)
    assert not permis and "seance" in pourquoi.lower()

    coffre.ouvrir_seance(ctx, "ouvre-toi")
    assert coffre.autorise_depot(ctx)[0]

    coffre.fermer_seance(ctx)
    assert not coffre.autorise_depot(ctx)[0]


def test_une_seance_sans_proprietaire_ne_se_referme_pas_toute_seule():
    """Depuis le 12/09/2026, la seance n'a plus d'echeance.

    Elle dure tant que la fenetre est ouverte, et la ligne de commande n'a pas
    de fenetre : sa seance vaut jusqu'a `--fermer`. Un compte a rebours qui
    coupait au milieu d'un depot n'a jamais protege personne.
    """
    ctx = _ctx(_tmp("sansfin"))
    coffre.poser_ouverture(ctx, "ouvre-toi")
    coffre.ouvrir_seance(ctx, "ouvre-toi")
    s = coffre.seance(ctx)
    assert s.ouverte and s.ouverte_le and not s.proprietaire


def test_une_seance_dont_la_fenetre_est_morte_ne_vaut_plus():
    """Le billet porte le numero du processus qui l'a ouvert.

    Si le logiciel meurt sans pouvoir refermer, plus rien n'efface le billet :
    c'est la disparition de son proprietaire qui le fait cesser de valoir.
    """
    ctx = _ctx(_tmp("orpheline"))
    coffre.poser_ouverture(ctx, "ouvre-toi")
    # Un numero de processus qui n'existe pas : on en prend un qu'on vient de
    # voir mourir, pour ne pas parier sur un nombre au hasard.
    import subprocess, sys
    mort = subprocess.Popen([sys.executable, "-c", ""])
    mort.wait()
    coffre.ouvrir_seance(ctx, "ouvre-toi", proprietaire=mort.pid)
    assert not coffre.seance(ctx).ouverte, "une seance orpheline vaut encore"


def test_une_seance_dont_la_fenetre_vit_vaut_toujours():
    ctx = _ctx(_tmp("vivante"))
    coffre.poser_ouverture(ctx, "ouvre-toi")
    coffre.ouvrir_seance(ctx, "ouvre-toi", proprietaire=os.getpid())
    assert coffre.seance(ctx).ouverte


def test_un_mauvais_mot_de_passe_n_ouvre_pas_la_seance():
    ctx = _ctx(_tmp("refus"))
    coffre.poser_ouverture(ctx, "le-bon")
    refuse = False
    try:
        coffre.ouvrir_seance(ctx, "le-mauvais")
    except coffre.ErreurCoffre:
        refuse = True
    assert refuse and not coffre.seance(ctx).ouverte


# ------------------------------------------------------- 5. la sauvegarde
class FauxDrive:
    """Un Drive qui se souvient, pour eprouver les decisions sans reseau."""

    def __init__(self, contenu=None):
        self.compte = "essai@exemple.fr"
        self.dossiers = {}
        self.fichiers = contenu or {}      # {parent: {nom: {md5, id}}}
        self.deposes = []
        self.supprimes = []                # doit rester vide, toujours

    def chemin(self, *noms):
        cle = "/".join(noms)
        self.dossiers.setdefault(cle, "id-%d" % len(self.dossiers))
        return self.dossiers[cle]

    def lister(self, parent):
        return dict(self.fichiers.get(parent, {}))

    def televerser(self, fichier, parent, nom=None):
        nom = nom or Path(fichier).name
        self.deposes.append((parent, nom))
        self.fichiers.setdefault(parent, {})[nom] = {
            "id": "f%d" % len(self.deposes),
            "md5": sauvegarde.empreinte(Path(fichier))}
        return {"id": "f%d" % len(self.deposes), "name": nom}


def _donnees_d_essai(tmp: Path):
    (tmp / "config").mkdir(parents=True, exist_ok=True)
    (tmp / "paies").mkdir(parents=True, exist_ok=True)
    (tmp / "journal").mkdir(parents=True, exist_ok=True)
    (tmp / "config" / "salaries.json").write_text("{}", encoding="utf-8")
    (tmp / "paies" / "2026-08.json").write_text('{"mois": "2026-08"}',
                                                encoding="utf-8")
    return tmp


def test_la_sauvegarde_envoie_tout_la_premiere_fois_puis_rien():
    ctx = _ctx(_donnees_d_essai(_tmp("drive")))
    drive = FauxDrive()

    premier = sauvegarde.sauvegarder(ctx, client=drive)
    assert len(premier.deposes) == 2, [f.relatif for f in premier.deposes]
    assert all(f.etat == "neuf" for f in premier.deposes)
    assert premier.identiques == 0

    second = sauvegarde.sauvegarder(ctx, client=drive)
    assert not second.deposes, "un fichier inchange est reparti"
    assert second.identiques == 2


def test_un_fichier_modifie_repart_et_lui_seul():
    ctx = _ctx(_donnees_d_essai(_tmp("modif")))
    drive = FauxDrive()
    sauvegarde.sauvegarder(ctx, client=drive)
    (ctx.racine / "paies" / "2026-08.json").write_text('{"mois": "2026-08", "a": 1}',
                                                       encoding="utf-8")
    r = sauvegarde.sauvegarder(ctx, client=drive)
    assert [f.relatif for f in r.deposes] == ["paies/2026-08.json"]
    assert r.deposes[0].etat == "modifie"


def test_la_sauvegarde_ne_supprime_jamais_rien():
    """Un fichier efface ici doit rester la-bas. Une sauvegarde n'est pas un miroir."""
    ctx = _ctx(_donnees_d_essai(_tmp("suppr")))
    drive = FauxDrive()
    sauvegarde.sauvegarder(ctx, client=drive)
    (ctx.racine / "paies" / "2026-08.json").unlink()
    sauvegarde.sauvegarder(ctx, client=drive)
    assert not drive.supprimes
    assert any("2026-08.json" in noms
               for noms in (list(f) for f in drive.fichiers.values()))


def test_les_secrets_et_les_verrous_ne_montent_pas_dans_le_nuage():
    ctx = _ctx(_donnees_d_essai(_tmp("exclus")))
    (ctx.racine / "config" / coffre.FICHIER).write_bytes(b"secret")
    (ctx.racine / "config" / "google-jeton.bin").write_bytes(b"jeton")
    (ctx.racine / "config" / ".seance").write_bytes(b"billet")
    (ctx.racine / "config" / ".compteurs.verrou").write_text("x", encoding="utf-8")
    drive = FauxDrive()
    r = sauvegarde.sauvegarder(ctx, client=drive)
    montes = [nom for _, nom in drive.deposes]
    for interdit in (coffre.FICHIER, "google-jeton.bin", ".seance",
                     ".compteurs.verrou"):
        assert interdit not in montes, "%s est parti dans le Drive" % interdit
    assert r.exclus == 4


def test_rien_n_a_bouge_repond_sans_reseau():
    ctx = _ctx(_donnees_d_essai(_tmp("bouge")))
    assert not sauvegarde.rien_n_a_bouge(ctx), "sans index, on ne peut pas savoir"
    sauvegarde.sauvegarder(ctx, client=FauxDrive())
    assert sauvegarde.rien_n_a_bouge(ctx)
    (ctx.racine / "paies" / "2026-09.json").write_text("{}", encoding="utf-8")
    assert not sauvegarde.rien_n_a_bouge(ctx), "un fichier neuf n'a pas ete vu"


# --------------------------------------------------------- 6. l'ouverture
def test_l_ouverture_ne_leve_jamais_et_dit_ce_qui_manque():
    """Pas de compte Google, pas de secret : elle le NOTE et rend la main.

    Un logiciel de paie qui refuse de s'ouvrir parce que le wifi est coupe est
    un logiciel inutilisable -- et la paie se calcule tres bien hors ligne.
    """
    ctx = _ctx(_donnees_d_essai(_tmp("ouvre")))
    r = ops.ouverture(ctx, sources=False)         # les sources : test suivant, sans reseau
    assert r.quand and not r.tout_va_bien
    # Trois manques : le compte Google, et les DEUX mots de passe de retours
    # -- net-entreprises (DSN) et Urssaf (DPAE), depuis que la veille releve
    # aussi le canal DPAE (12/09/2026).
    assert len(r.manquants) == 3, r.manquants
    assert r.sauvegarde is None and r.releve is None and r.releve_dpae is None
    # La trace est ecrite, et elle ne porte aucun secret.
    trace = (ctx.racine / "config" / ".ouverture.json").read_text(encoding="utf-8")
    assert "motdepasse" not in trace.lower()


def test_l_ouverture_verifie_les_sources_une_fois_par_semaine():
    """Les sources sont verifiees a l'ouverture (16/09/2026), mais pas a
    chaque passage de veille : une fois par semaine, et entre deux on redit
    le dernier etat. Une source A RELIRE est un incident, avec son detail --
    une grille perimee est une paie fausse. Sans reseau : `sources.verifier`
    est joue."""
    import datetime as dt
    import json
    from dataclasses import dataclass
    from moteur import operations_ouverture as oo, sources as _sources

    @dataclass
    class Faux:
        ident: str
        en_ligne: str
        detail: str = ""

    appels = []
    def verifier(ctx, seulement=None, relever=False):
        appels.append(1)
        return [Faux("a", "inchangee"), Faux("b", "changee", "la convention a bouge")]
    vrai = _sources.verifier
    _sources.verifier = verifier
    try:
        ctx = _ctx(_donnees_d_essai(_tmp("sources")))
        # Les sources, c'est chez l'editeur (config/maj.json) ; une compagnie
        # recoit une version, elle ne relit pas Legifrance (test_maj.py).
        (ctx.racine / "config" / "maj.json").write_text('{"editeur": true}', encoding="utf-8")
        r = ops.ouverture(ctx, sauvegarder=False, retours=False, signatures=False)
        assert r.sources.faite_maintenant and r.sources.a_relire == ["b"]
        assert r.sources.total == 2 and "A RELIRE" in r.sources.resume()
        assert any(i.startswith("Source a relire : b -- la convention") for i in r.incidents)
        # Le passage suivant ne retourne pas en ligne, mais redit l'etat.
        r2 = ops.ouverture(ctx, sauvegarder=False, retours=False, signatures=False, veille=True)
        assert len(appels) == 1 and not r2.sources.faite_maintenant
        assert r2.sources.a_relire == ["b"] and any("Source a relire" in i for i in r2.incidents)
        # Huit jours plus tard : on y retourne.
        trace = ctx.racine / "config" / ".ouverture.json"
        d = json.loads(trace.read_text(encoding="utf-8"))
        d["sources_etat"]["le"] = (dt.date.today() - dt.timedelta(days=oo.SOURCES_TOUS_LES)).isoformat()
        trace.write_text(json.dumps(d), encoding="utf-8")
        r3 = ops.ouverture(ctx, sauvegarder=False, retours=False, signatures=False, veille=True)
        assert len(appels) == 2 and r3.sources.faite_maintenant
        # Et une panne de la verification n'empeche pas l'ouverture.
        def casse(ctx, seulement=None, relever=False):
            raise OSError("pas de reseau")
        _sources.verifier = casse
        d["sources_etat"] = {}
        trace.write_text(json.dumps(d), encoding="utf-8")
        r4 = ops.ouverture(ctx, sauvegarder=False, retours=False, signatures=False)
        assert r4.sources is None and any("Sources : pas de reseau" in i for i in r4.incidents)
    finally:
        _sources.verifier = vrai


def test_relever_les_retours_sans_secret_ne_plante_pas():
    ctx = _ctx(_donnees_d_essai(_tmp("releve")))
    r = ops.relever_retours(ctx)
    assert not r.trouves and r.incidents
    assert "coffre" in r.incidents[0]


# ---------------------------------------------------------------- lanceur
def _lancer() -> int:
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    rates = []
    for nom, f in tests:
        try:
            f()
            print("  OK     %s" % nom)
        except AssertionError as e:
            rates.append((nom, e))
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            rates.append((nom, e))
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    print("\n%d test(s), %d echec(s)." % (len(tests), len(rates)))
    if not rates:
        print("\nTous les tests passent.")
    return 1 if rates else 0


if __name__ == "__main__":
    sys.exit(_lancer())
