"""Le bareme cadre, et deux bulletins CoolPaie 2026 rejoues au centime.

Le 13/09/2026, Leandre a fait deux paies d'essai dans CoolPaie, pour
reference, puis les a supprimees : le bulletin n° 31/2026 (artiste CADRE,
metteuse en scene, 1 cachet a 250 EUR, le 14/09/2026) et le n° 32/2026
(chargee de production NON CADRE, 1 journee de 7 h a 100 EUR, le 13/09/2026).
Ils sont dans `reference/exemples/bulletins-reference/`. Ce fichier les
rejoue ligne par ligne : c'est la preuve du bareme cadre et du bareme
technicien 2026, la ou l'export n'offrait que des DSN de 2025.

Une seule ligne ne se retrouve pas : la reduction generale du technicien,
27,18 chez CoolPaie contre 25,50 ici. CoolPaie prend le SMIC du jour (12,31,
revalorise au 1er juin) ; le decret retient celui du 1er janvier (12,02) pour
toute l'annee. Avec 12,31, la formule du moteur redonne 27,17 : ce n'est pas
la formule qui differe, c'est le SMIC. Le moteur suit le decret.
"""
import io
import json
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from decimal import Decimal
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import calcul, dsn, operations as ops          # noqa: E402
from moteur.contexte import Contexte                        # noqa: E402

ctx = Contexte()


def _bac(**maj):
    racine = Path(tempfile.mkdtemp())
    shutil.copytree(ctx.racine / "config", racine / "config")
    f = racine / "config" / "salaries.json"
    d = json.loads(f.read_text(encoding="utf-8"))
    cle = next(iter(ctx.salaries_actifs))
    d[cle].update(maj)
    f.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    return racine, Contexte(racine), cle


def _paie(bac, cle, lignes, dates):
    spec = next(iter(bac.spectacles_actifs))
    return ops.charger(bac, {
        "mois": "2026-09", "date_paiement": "2026-09-30",
        "engagements": [{"salarie": cle, "spectacle": spec,
                         "lignes": [dict(lignes[0], dates=dates)] + list(lignes[1:])}]}).paies[0]


def _ligne(p, id_):
    l = p.ligne(id_)
    assert l is not None, id_
    return (l.base, l.taux_pat, l.montant_pat, l.taux_sal, l.montant_sal)


# --------------------------------------------- bulletin 31/2026 : artiste cadre
def test_le_bulletin_31_2026_artiste_cadre_au_centime():
    racine, bac, cle = _bac(statut_conventionnel="04", statut_categoriel_rc="01",
                            emploi="METTEUSE EN SCENE", code_emploi_ft="MET040")
    try:
        p = _paie(bac, cle, [{"rubrique": "cachet", "quantite": 1, "taux": 250}],
                  ["2026-09-14"])
        D = Decimal
        assert p.brut == D("250.00")
        # SANTE
        assert _ligne(p, "maladie") == (D("250.00"), 9.1, D("22.75"), None, D("0.00"))
        assert _ligne(p, "prevoyance") == (D("220.00"), 1.69, D("3.72"), 0.12, D("0.26"))
        assert _ligne(p, "atmp") == (D("250.00"), 1.05, D("2.63"), None, D("0.00"))
        # RETRAITE -- la CET fondue dans T1 et T2, le brut depassant 220.
        assert _ligne(p, "vieil_plaf") == (D("250.00"), 5.99, D("14.98"), 4.83, D("12.08"))
        assert _ligne(p, "vieil_deplaf") == (D("250.00"), 1.48, D("3.70"), 0.28, D("0.70"))
        assert _ligne(p, "retraite_t1") == (D("220.00"), 5.44, D("11.97"), 4.93, D("10.85"))
        assert _ligne(p, "retraite_t2") == (D("30.00"), 14.78, D("4.44"), 9.86, D("2.96"))
        assert _ligne(p, "famille") == (D("250.00"), 3.68, D("9.20"), None, D("0.00"))
        # CHOMAGE, et l'Apec par tranche
        assert _ligne(p, "chomage") == (D("250.00"), 9.75, D("24.38"), 2.4, D("6.00"))
        assert _ligne(p, "apec_t1") == (D("220.00"), 0.036, D("0.08"), 0.024, D("0.05"))
        assert _ligne(p, "apec_t2") == (D("30.00"), 0.036, D("0.01"), 0.024, D("0.01"))
        # AUTRES, CONGES SPECTACLES, CASC sur la T1
        assert _ligne(p, "autres_1") == (D("250.00"), 2.836, D("7.09"), None, D("0.00"))
        assert _ligne(p, "autres_2") == (D("278.75"), 0.07, D("0.20"), None, D("0.00"))
        assert _ligne(p, "autres_3") == (D("275.00"), 0.68, D("1.87"), None, D("0.00"))
        assert _ligne(p, "conges_spec") == (D("250.00"), 15.5, D("38.75"), None, D("0.00"))
        assert _ligne(p, "ccn") == (D("220.00"), 0.5, D("1.10"), None, D("0.00"))
        # CSG : assiette 249,34 = 245,625 + 3,718 arrondis EN UNE FOIS.
        assert p.base_csg == D("249.34")
        assert _ligne(p, "csg_ded")[4] == D("16.96")
        assert _ligne(p, "csg_crds_nd")[4] == D("7.23")
        # Pas de reduction generale pour un artiste, cadre ou non.
        assert p.reduction_generale is None and p.ligne("reduction_generale") is None
        # Les totaux du bulletin.
        assert p.total_pat == D("146.87")
        assert p.total_sal == D("57.10")
        # CoolPaie imprime 192,91 et 200,14 : il retranche la somme NON
        # ARRONDIE des lignes (57,0897 -> 57,09), alors qu'il affiche 57,10.
        # Le moteur retranche ce qui est reellement du -- les lignes, chacune
        # arrondie, telles qu'elles partent en DSN : 250 - 57,10 = 192,90.
        # Un centime, au salarie chez CoolPaie ; c'est leur incoherence, pas
        # la notre. Sur l'historique artiste les deux calculs coincident.
        assert p.net_a_payer == D("192.90")
        assert p.net_imposable == D("200.13")
        assert p.cout_employeur == D("396.87")
    finally:
        shutil.rmtree(racine, ignore_errors=True)


def test_la_dsn_d_un_cadre_porte_04_01_et_l_agirc_arrco_avec_apec():
    """Comme la DSN CoolPaie de juin 2025 (metteuse en scene, PU1.25.7) :
    40.002 = 04, 40.003 = 01, la prevoyance cadre en 059 et l'Agirc-Arrco
    << y compris Apec >> en 105, somme des lignes arrondies une a une."""
    racine, bac, cle = _bac(statut_conventionnel="04", statut_categoriel_rc="01",
                            emploi="METTEUSE EN SCENE", code_emploi_ft="MET040")
    try:
        spec = next(iter(bac.spectacles_actifs))
        s = ops.charger(bac, {"mois": "2026-09", "date_paiement": "2026-09-30",
                              "engagements": [{"salarie": cle, "spectacle": spec,
                                               "lignes": [{"rubrique": "cachet",
                                                           "quantite": 1, "taux": 250,
                                                           "dates": ["2026-09-14"]}]}]})
        p = s.paies[0]
        texte = dsn.generer(bac, s.paies, "2026-09", versement_urssaf=Decimal("100"))
        assert "S21.G00.40.002,'04'" in texte and "S21.G00.40.003,'01'" in texte
        lignes = texte.splitlines()
        i = next(k for k, l in enumerate(lignes) if "S21.G00.81.001,'105'" in l)
        attendu = sum((p.ligne(x).montant_pat + p.ligne(x).montant_sal
                       for x in ("retraite_t1", "retraite_t2", "apec_t1", "apec_t2")),
                      Decimal("0.00"))
        assert lignes[i + 1] == "S21.G00.81.004,'%s'" % attendu, lignes[i + 1]
        assert attendu == Decimal("30.37")
        # 059 INTERBRANCHE au taux cadre 1,81 (1,00 + 0,81), sur la T1 : 220.
        i = [k for k, l in enumerate(lignes) if "S21.G00.81.001,'059'" in l][-1]
        assert lignes[i + 1] == "S21.G00.81.004,'3.98'", lignes[i + 1]
        # 54.002 : la prevoyance en euros, au taux cadre, sur la T1 (3,98 -> 4).
        assert "S21.G00.54.002,'4.00'" in texte
    finally:
        shutil.rmtree(racine, ignore_errors=True)


def test_un_cadre_sous_la_t1_n_a_ni_t2_ni_cet():
    """Juin 2025 : 2 cachets a 160, T1 = 440 > 320 -- ni T2, ni Apec B, ni
    CET, et la retraite T1 au taux nu 5,23 / 4,79."""
    racine, bac, cle = _bac(statut_conventionnel="04", statut_categoriel_rc="01")
    try:
        p = _paie(bac, cle, [{"rubrique": "cachet", "quantite": 2, "taux": 160}],
                  ["2026-09-03", "2026-09-20"])
        assert p.ligne("retraite_t2") is None and p.ligne("apec_t2") is None
        assert _ligne(p, "retraite_t1") == (Decimal("320.00"), 5.23, Decimal("16.74"),
                                            4.79, Decimal("15.33"))
        assert _ligne(p, "apec_t1")[2:] == (Decimal("0.12"), 0.024, Decimal("0.08"))
        assert p.base_csg == Decimal("319.81")       # 314,40 + 320 x 1,69 %
    finally:
        shutil.rmtree(racine, ignore_errors=True)


def test_un_cadre_sans_section_est_refuse():
    racine, bac, cle = _bac(statut_conventionnel="04", statut_categoriel_rc="01")
    try:
        bar = dict(bac.bareme("2026-09-14"))
        bar["par_categorie"] = {}
        try:
            calcul.bareme_cadre(bar, bac.salaries[cle])
        except ValueError as e:
            assert "cadre" in str(e).lower()
        else:
            raise AssertionError("un cadre a ete calcule sans section cadre")
    finally:
        shutil.rmtree(racine, ignore_errors=True)


# ------------------------------------- bulletin 32/2026 : technicien non cadre
def test_le_bulletin_32_2026_technicien_au_centime_hors_smic():
    racine, bac, cle = _bac(statut="technicien", statut_conventionnel="07",
                            emploi="CHARGEE DE PRODUCTION", pcs_ese="637C",
                            code_emploi_ft="CHA080")
    try:
        p = _paie(bac, cle, [{"rubrique": "journee", "quantite": 1, "taux": 100,
                              "heures": 7}], ["2026-09-13"])
        D = Decimal
        assert p.brut == D("100.00")
        assert _ligne(p, "maladie") == (D("100.00"), 13.0, D("13.00"), None, D("0.00"))
        assert _ligne(p, "prevoyance") == (D("100.00"), 1.11, D("1.11"), 0.12, D("0.12"))
        assert _ligne(p, "atmp") == (D("100.00"), 1.5, D("1.50"), None, D("0.00"))
        assert _ligne(p, "vieil_plaf") == (D("100.00"), 8.55, D("8.55"), 6.9, D("6.90"))
        assert _ligne(p, "vieil_deplaf") == (D("100.00"), 2.11, D("2.11"), 0.4, D("0.40"))
        assert _ligne(p, "retraite_t1") == (D("100.00"), 5.23, D("5.23"), 4.79, D("4.79"))
        assert _ligne(p, "famille") == (D("100.00"), 5.25, D("5.25"), None, D("0.00"))
        assert _ligne(p, "chomage") == (D("100.00"), 9.75, D("9.75"), 2.4, D("2.40"))
        assert _ligne(p, "autres_1") == (D("100.00"), 2.836, D("2.84"), None, D("0.00"))
        assert _ligne(p, "autres_2") == (D("111.50"), 0.1, D("0.11"), None, D("0.00"))
        assert _ligne(p, "autres_3") == (D("110.00"), 0.68, D("0.75"), None, D("0.00"))
        assert _ligne(p, "conges_spec") == (D("100.00"), 15.5, D("15.50"), None, D("0.00"))
        assert _ligne(p, "ccn") == (D("100.00"), 0.5, D("0.50"), None, D("0.00"))
        assert p.base_csg == D("99.36")
        assert _ligne(p, "csg_ded")[4] == D("6.76") and _ligne(p, "csg_crds_nd")[4] == D("2.88")
        assert p.total_sal == D("24.25") and p.net_a_payer == D("75.75")
        assert p.net_imposable == D("78.63")
        # La reduction generale : 25,50 avec le SMIC du 1er janvier (12,02 x
        # 7 h = 84,14), la ou CoolPaie ecrit 27,18 avec le SMIC du jour.
        assert p.reduction_generale["smic_reference"] == D("84.14")
        assert p.reduction_generale["coefficient"] == D("0.2550")
        assert p.ligne("reduction_generale").montant_pat == D("-25.50")
        assert p.total_pat == D("40.70")          # 66,20 - 25,50 ; CoolPaie : 66,20 - 27,18 = 39,02
        assert p.cout_employeur == D("140.70")
        # Avec le SMIC du jour, la formule du moteur redonne CoolPaie a un
        # centime pres : ce n'est pas la formule qui differe, c'est le SMIC.
        b = dict(bac.bareme("2026-09-13"))
        b["reduction_generale"] = dict(b["par_statut"]["technicien"]["reduction_generale"],
                                       smic_horaire_reference=12.31)
        rg = calcul.reduction_generale(b, "technicien", D("100.00"), D("7"))
        assert rg["montant"] in (D("27.17"), D("27.18")), rg
    finally:
        shutil.rmtree(racine, ignore_errors=True)


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            with redirect_stdout(io.StringIO()):
                fn()
            print("  OK     %s" % nom)
        except AssertionError as exc:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, exc))
        except Exception as exc:                                  # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(exc).__name__, exc))
    print("\n%s" % ("Tous les tests passent." if not echecs
                    else "%d test(s) en echec." % echecs))
    sys.exit(1 if echecs else 0)
