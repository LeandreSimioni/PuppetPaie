"""L'import CoolPaie, et la source unique des droits.

Ce qu'on verrouille, sur un export FICTIF fabrique ici (aucune donnee
reelle : les tests tournent dans un bac, avec un salarie invente) :

  - la lecture : une DSN donne l'identite et l'emploi d'un salarie, ses
    numeros d'objet, l'entreprise ; une AEM donne un contrat atteste, un
    enregistrement par ligne, dedoublonne ;
  - l'apercu n'ecrit rien ; une fiche existante n'est jamais modifiee (les
    ecarts sont signales) ; une fiche inconnue est proposee complete ;
  - l'import ecrit fiches et historique, et se rejoue sans rien ajouter ;
  - cumul.lire_engagements lit l'historique ET nos paies, et un mois qui a
    son fichier de paie n'est lu que la -- jamais deux fois.
"""
import datetime as dt
import json
import shutil
import sys
import tempfile
from decimal import Decimal
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import champs, cumul, importation as imp, operations as ops   # noqa: E402
from moteur.aem import CHAMPS                                        # noqa: E402
from moteur.contexte import Contexte                                 # noqa: E402

REEL = Contexte()

# Un salarie qui n'existe pas : le NIR fabrique de outils/verifier_avant_commit
# (FICTIVES), pour que le garde-fou du depot public ne le prenne pas pour vrai.
NIR = "1880275999999"
OBJET_2026 = "266Z00000001"
OBJET_2023 = "236Z00000002"


# ------------------------------------------------------------ le faux export
def _dsn(mois: str, depot: str, nir=NIR, objet=OBJET_2026, emploi=("354C", "ART120", "ARTISTE DRAMATIQUE"),
         email="ARTISTE@EXEMPLE.FR", licence="2019000001") -> str:
    jjmm = lambda iso: iso[8:10] + iso[5:7] + iso[0:4]
    pcs, code_ft, libelle = emploi
    lignes = [
        ("S10.G00.01.001", "123456789"), ("S10.G00.01.002", "00012"),
        ("S10.G00.01.003", "COMPAGNIE DE TEST"), ("S10.G00.01.004", "1 RUE DU TEST"),
        ("S10.G00.01.005", "75001"), ("S10.G00.01.006", "PARIS"),
        ("S20.G00.05.005", "01" + mois[5:7] + mois[0:4]), ("S20.G00.05.007", jjmm(depot)),
        ("S21.G00.06.003", "9001Z"), ("S21.G00.11.022", "3090"),
        ("S21.G00.30.001", nir), ("S21.G00.30.002", "TESTEUR"), ("S21.G00.30.004", "JEAN"),
        ("S21.G00.30.006", "15011985"), ("S21.G00.30.007", "LYON"),
        ("S21.G00.30.008", "2 RUE DES ESSAIS"), ("S21.G00.30.009", "69001"),
        ("S21.G00.30.010", "LYON"), ("S21.G00.30.013", "01"), ("S21.G00.30.014", "69"),
        ("S21.G00.30.015", "FR"), ("S21.G00.30.018", email), ("S21.G00.30.019", "7"),
        ("S21.G00.40.001", "05" + mois[5:7] + mois[0:4]), ("S21.G00.40.002", "05"),
        ("S21.G00.40.003", "04"), ("S21.G00.40.004", pcs), ("S21.G00.40.005", code_ft),
        ("S21.G00.40.006", libelle), ("S21.G00.40.009", "TE1.26.01"),
        ("S21.G00.40.010", "06" + mois[5:7] + mois[0:4]), ("S21.G00.40.017", "3090"),
        ("S21.G00.40.022", "970000000000X"), ("S21.G00.40.049", licence),
        ("S21.G00.40.050", objet),
    ]
    return "\r\n".join("%s,'%s'" % kv for kv in lignes) + "\r\n"


def _aem(debut: dt.date, fin: dt.date, cachets: int, heures: int, jours: int,
         brut: Decimal, nir=NIR, objet=OBJET_2026, numero="000042",
         signe: dt.date = None) -> str:
    """Un enregistrement de 1000 caracteres, les champs aux positions de
    moteur.aem.CHAMPS, le reste a blanc."""
    ligne = [" "] * 1000
    def poser(nom, valeur):
        a, b = CHAMPS[nom]
        v = str(valeur)[:b - a].ljust(b - a)
        ligne[a:b] = list(v)
    poser("nir", nir + (champs.cle_nir(nir) or "00"))
    poser("nom", "TESTEUR"); poser("prenom", "JEAN")
    poser("date_naissance", "19850115")
    poser("date_debut", debut.strftime("%Y%m%d"))
    poser("date_fin", fin.strftime("%Y%m%d"))
    poser("numero_objet", objet)
    poser("nb_heures", "%03d" % heures); poser("nb_cachets", "%02d" % cachets)
    poser("nb_jours", "%04d" % jours)
    poser("brut_cts", "%09d" % int(brut * 100))
    poser("num_attestation", numero)
    poser("date_signature", (signe or fin).strftime("%Y%m%d"))
    return "".join(ligne)


def _export(dossier: Path, aem_lignes: list, dsn: dict = None) -> Path:
    (dossier / "DSN").mkdir(parents=True)
    (dossier / "AEM_EDI").mkdir(parents=True)
    for nom, contenu in (dsn or {
            "Juin_2026.dsn": _dsn("2026-06", "2026-07-04"),
            "Mai_2026.dsn": _dsn("2026-05", "2026-06-04", email="VIEILLE@EXEMPLE.FR"),
            "Oct_2023.dsn": _dsn("2023-10", "2023-11-04", objet=OBJET_2023,
                                 emploi=("354B", "MUS010", "MUSICIEN"))}).items():
        (dossier / "DSN" / nom).write_text(contenu, encoding="latin-1")
    (dossier / "AEM_EDI" / "_010726_EDIV5.txt").write_bytes(
        ("\r\n".join(aem_lignes) + "\r\n").encode("latin-1"))
    return dossier


CONTRATS = [
    _aem(dt.date(2025, 10, 3), dt.date(2025, 10, 4), 2, 0, 2, Decimal("260.00"), numero="000040"),
    _aem(dt.date(2026, 3, 10), dt.date(2026, 3, 12), 1, 12, 3, Decimal("370.00"), numero="000041"),
    # Le meme contrat, reedite : ne doit compter qu'une fois.
    _aem(dt.date(2026, 3, 10), dt.date(2026, 3, 12), 1, 12, 3, Decimal("370.00"), numero="000043"),
    _aem(dt.date(2026, 6, 5), dt.date(2026, 6, 6), 2, 0, 2, Decimal("260.00"), numero="000042"),
]


def _bac(avec_fiche=False):
    """Une racine de donnees : la config reelle copiee (sans secrets), un
    faux export a cote, et pas d'historique."""
    racine = Path(tempfile.mkdtemp(prefix="puppetpaie-import-")) / "prive"
    shutil.copytree(REEL.racine / "config", racine / "config")
    for secret in ("google-jeton.bin", "coffre.bin", ".seance"):
        (racine / "config" / secret).unlink(missing_ok=True)
    (racine / "paies").mkdir()
    export = _export(racine.parent / "export", CONTRATS)
    if avec_fiche:
        p = racine / "config" / "salaries.json"
        fiches = json.loads(p.read_text(encoding="utf-8"))
        modele = next(v for k, v in fiches.items() if not k.startswith("_"))
        fiches["TESTEUR"] = dict(modele, nom="TESTEUR", prenom="JEAN", nir=NIR,
                                 nir_cle=champs.cle_nir(NIR), email="jean@exemple.fr",
                                 code_salarie="7", actif=True, historique=[])
        p.write_text(json.dumps(fiches, ensure_ascii=False, indent=2), encoding="utf-8")
    ctx = Contexte(racine)
    assert ctx.export == export, ctx.export
    return ctx


# --------------------------------------------------------------- la lecture
def test_la_dsn_donne_identite_emploi_objets_et_entreprise():
    with tempfile.TemporaryDirectory() as tmp:
        _export(Path(tmp), CONTRATS)
        r = imp.lire_dsn(Path(tmp) / "DSN")
    assert r.fichiers == 3 and (r.premier_mois, r.dernier_mois) == ("2023-10", "2026-06")
    s = r.salaries[NIR]
    # La DERNIERE DSN fait foi : l'adresse de juin, pas celle de mai.
    assert s.mois == "2026-06" and s.fiche["email"] == "ARTISTE@EXEMPLE.FR"
    assert s.fiche["date_naissance"] == "1985-01-15"
    assert s.fiche["pcs_ese"] == "354C" and s.fiche["emploi"] == "ARTISTE DRAMATIQUE"
    assert s.initiales == "TE"
    assert set(r.objets) == {OBJET_2026, OBJET_2023}
    assert r.objets[OBJET_2026].annee == "2026" and r.objets[OBJET_2023].annee == "2023"
    assert r.entreprise["siren"] == "123456789" and r.entreprise["idcc"] == "3090"
    assert r.licences == [("2023-10", "2019000001")]


def test_l_aem_donne_un_contrat_par_ligne_dedoublonne():
    with tempfile.TemporaryDirectory() as tmp:
        _export(Path(tmp), CONTRATS)
        contrats, illisibles = imp.lire_aem(Path(tmp) / "AEM_EDI")
    assert not illisibles
    assert len(contrats) == 3, [c.debut for c in contrats]    # 4 lignes, un doublon
    c = contrats[1]
    assert (c.debut, c.fin, c.cachets, c.heures, c.jours) == (
        dt.date(2026, 3, 10), dt.date(2026, 3, 12), 1, 12, 3)
    assert c.brut == Decimal("370.00")
    assert c.numero_attestation == "000041"       # la premiere attestation


def test_le_dossier_se_trouve_meme_donne_de_travers():
    with tempfile.TemporaryDirectory() as tmp:
        _export(Path(tmp), CONTRATS)
        assert imp.dossiers(tmp)["dsn"] == Path(tmp) / "DSN"
        assert imp.dossiers(Path(tmp) / "DSN")["dsn"] == Path(tmp) / "DSN"
        assert imp.dossiers(Path(tmp) / "DSN")["aem"] is None
        assert imp.dossiers(Path(tmp) / "AEM_EDI")["aem"] == Path(tmp) / "AEM_EDI"


# ---------------------------------------------------------------- l'apercu
def test_l_apercu_n_ecrit_rien_et_propose_une_fiche_complete():
    ctx = _bac()
    avant = {p.name: p.read_bytes() for p in (ctx.racine / "config").glob("*.json")}
    a = ops.apercu_importation(ctx, aujourdhui=dt.date(2026, 9, 15))
    assert not a.ecrit and not ops.chemin_historique(ctx).exists()
    assert {p.name: p.read_bytes() for p in (ctx.racine / "config").glob("*.json")} == avant
    # L'entreprise existe : on n'y touche pas.
    assert a.entreprise.etat == "existante"
    # Le salarie invente est a creer, avec ce que la derniere DSN dit de lui.
    (s,) = [f for f in a.salaries if f.etat == "a_creer"]
    d = s.donnees
    assert d["nir"] == NIR and d["nir_cle"] == champs.cle_nir(NIR)
    assert d["nom"] == "TESTEUR" and d["nom_affichage"] == "Testeur"
    assert d["statut"] == "artiste" and d["initiales_contrat"] == "TE"
    assert d["email"] == "ARTISTE@EXEMPLE.FR" and d["actif"] is True
    assert not [x for x in s.anomalies if x["gravite"] == "erreur"], s.anomalies
    # Les deux numeros d'objet sont inconnus : celui de 2026 actif, pas 2023.
    neufs = {f.donnees["numero_objet"]: f.donnees for f in a.spectacles if f.etat == "a_creer"}
    assert set(neufs) == {OBJET_2026, OBJET_2023}
    assert neufs[OBJET_2026]["actif"] is True and neufs[OBJET_2023]["actif"] is False
    assert neufs[OBJET_2026]["titre"] == "A COMPLETER"
    assert a.contrats == 3 and a.contrats_nouveaux == 3 and a.contrats_sans_fiche == 0
    assert (a.contrats_du, a.contrats_au) == ("2025-10-03", "2026-06-06")


def test_une_fiche_existante_n_est_pas_modifiee_mais_les_ecarts_sont_dits():
    ctx = _bac(avec_fiche=True)
    a = ops.apercu_importation(ctx)
    (s,) = [f for f in a.salaries if f.cle == "TESTEUR"]
    assert s.etat == "existante"
    assert s.ecarts["email"] == {"fiche": "jean@exemple.fr",
                                 "dsn": "ARTISTE@EXEMPLE.FR", "mois": "2026-06"}
    r = ops.importer(ctx)
    frais = Contexte(ctx.racine)
    assert frais.salaries["TESTEUR"]["email"] == "jean@exemple.fr"     # intacte
    assert [f for f in r.salaries if f.etat == "creee"] == []


def test_un_export_vide_est_refuse_clairement():
    ctx = _bac()
    with tempfile.TemporaryDirectory() as tmp:
        try:
            ops.apercu_importation(ctx, tmp)
            assert False, "un dossier sans DSN ni AEM doit etre refuse"
        except ops.ExportIntrouvable as e:
            assert "export/" in str(e)


# ------------------------------------------------------------------ l'import
def test_l_import_ecrit_fiches_et_historique_et_se_rejoue_sans_rien_ajouter():
    ctx = _bac()
    r = ops.importer(ctx, aujourdhui=dt.date(2026, 9, 15))
    assert r.ecrit and r.contrats_nouveaux == 3
    frais = Contexte(ctx.racine)
    cle = frais.salarie("TESTEUR")["_cle"]
    assert frais.salaries[cle]["nir"] == NIR
    assert not frais.salaries[cle].get("historique")     # neuve : rien a dater
    assert frais.spectacle(OBJET_2026)["_cle"] == "objet-" + OBJET_2026
    h = json.loads(ops.chemin_historique(ctx).read_text(encoding="utf-8"))
    assert len(h["engagements"]) == 3
    e = h["engagements"][1]
    assert e["salarie"] == cle and e["debut"] == "2026-03-10" and e["cachets"] == 1
    assert e["heures"] == 12 and e["brut"] == "370.00" and e["atteste_par"] == "AEM"
    assert set(r.fichiers) >= {str(ctx.racine / "config" / "salaries.json"),
                               str(ctx.racine / "config" / "spectacles.json"),
                               str(ops.chemin_historique(ctx))}
    # Rejoue : rien de plus.
    r2 = ops.importer(ctx, aujourdhui=dt.date(2026, 9, 15))
    assert r2.contrats_nouveaux == 0 and r2.a_creer == []
    assert len(json.loads(ops.chemin_historique(ctx).read_text(encoding="utf-8"))["engagements"]) == 3
    assert ops.apercu_importation(ctx).rien_a_faire


# --------------------------------------------------------- la source unique
def _paie_juin(ctx, cle):
    """Un fichier de paie pour juin 2026 : le mois de la derniere AEM, avec
    un contenu DIFFERENT (3 cachets au lieu de 2) pour voir qui l'emporte."""
    spec = next(iter(ctx.spectacles_actifs))
    ops.enregistrer_saisie(ctx, "2026-06", {
        "mois": "2026-06", "date_paiement": "2026-06-30",
        "engagements": [{"salarie": cle, "spectacle": spec,
                         "lignes": [{"rubrique": "cachet", "quantite": 3, "taux": 130,
                                     "dates": ["2026-06-05", "2026-06-06", "2026-06-20"]}]}]})


def test_les_droits_lisent_l_historique_sans_le_dossier_export():
    ctx = _bac()
    ops.importer(ctx)
    shutil.rmtree(ctx.export)                    # CoolPaie resilie
    ctx = Contexte(ctx.racine)
    cle = ctx.salarie("TESTEUR")["_cle"]
    engs = cumul.lire_engagements(ctx)
    miens = [e for e in engs if e.salarie == cle]
    assert len(miens) == 3
    assert sum(e.cachets for e in miens) == 5 and sum(e.heures for e in miens) == 12
    p = cumul.position_droits(ctx, cle, engs, a_la_date=dt.date(2026, 6, 6))
    # Les 12 mois qui precedent le 06/06/2026 : octobre 2025, mars et juin 2026.
    assert p.heures_equivalentes == 5 * 12 + 12
    assert any(d.cle == cle for d in ops.droits(ctx, mois="2026-06"))


def test_un_mois_qui_a_son_fichier_de_paie_n_est_lu_que_la():
    ctx = _bac()
    ops.importer(ctx)
    ctx = Contexte(ctx.racine)
    cle = ctx.salarie("TESTEUR")["_cle"]
    _paie_juin(ctx, cle)
    engs = [e for e in cumul.lire_engagements(ctx) if e.salarie == cle]
    juin = [e for e in engs if e.fin.month == 6]
    assert len(juin) == 1, "l'AEM de juin et la paie de juin ne doivent pas s'additionner"
    assert juin[0].cachets == 3 and juin[0].brut == Decimal("390.00")
    assert juin[0].debut == dt.date(2026, 6, 5) and juin[0].fin == dt.date(2026, 6, 20)
    # Les autres mois viennent toujours de l'historique.
    assert [e.debut for e in engs if e.fin.month != 6] == [dt.date(2025, 10, 3), dt.date(2026, 3, 10)]


def test_les_paies_courantes_remplacent_le_fichier_de_leur_mois():
    """Le bulletin se compte lui-meme : les paies qu'il imprime remplacent ce
    que le disque dit du mois."""
    ctx = _bac()
    ops.importer(ctx)
    ctx = Contexte(ctx.racine)
    cle = ctx.salarie("TESTEUR")["_cle"]
    _paie_juin(ctx, cle)
    spec = next(iter(ctx.spectacles_actifs))
    saisie = ops.charger(ctx, {"mois": "2026-06", "date_paiement": "2026-06-30",
                               "engagements": [{"salarie": cle, "spectacle": spec,
                                                "lignes": [{"rubrique": "cachet", "quantite": 1,
                                                            "taux": 130, "dates": ["2026-06-11"]}]}]},
                        sans_numeros=True)
    engs = [e for e in cumul.lire_engagements(ctx, paies_courantes=saisie.paies)
            if e.salarie == cle and e.fin.month == 6]
    assert len(engs) == 1 and engs[0].cachets == 1
    cols = cumul.tableau_cumul(ctx, cle, "2026-06", engagements=cumul.lire_engagements(
        ctx, paies_courantes=saisie.paies))
    assert cols[0].titre == "Periode" and cols[0].cachets == 1


def test_un_brouillon_illisible_ne_couvre_pas_son_mois():
    ctx = _bac()
    ops.importer(ctx)
    (ctx.racine / "paies" / "2026-06.json").write_text("{ pas du json", encoding="utf-8")
    ctx = Contexte(ctx.racine)
    cle = ctx.salarie("TESTEUR")["_cle"]
    juin = [e for e in cumul.lire_engagements(ctx) if e.salarie == cle and e.fin.month == 6]
    assert len(juin) == 1 and juin[0].cachets == 2          # l'historique parle


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("ok   ", nom)
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            import traceback
            print("ECHEC", nom, "->", e)
            traceback.print_exc()
    print("\n%d test(s), %d echec(s)" % (
        len([n for n in globals() if n.startswith("test_")]), echecs))
    sys.exit(1 if echecs else 0)
