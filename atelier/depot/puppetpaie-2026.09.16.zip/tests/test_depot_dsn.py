"""Depot DSN : les garde-fous, pas le transport.

Rien ici ne parle au reseau. On verifie ce qui doit etre vrai AVANT qu'un
octet parte, parce que c'est la seule commande du moteur dont l'erreur ne se
rattrape pas : une DSN deposee est deposee.

Le test le plus important est `test_la_bascule_en_test_mord_vraiment`. La
premiere version de `basculer_en_test` ancrait son motif sur une fin de ligne
(`$` en mode multiligne) alors que le fichier est en CRLF. Elle ne levait pas,
elle ne changeait simplement RIEN : un depot demande « en test » serait parti
code '02', c'est-a-dire aurait declare. Une fonction de securite qui echoue en
silence est pire que pas de fonction du tout.
"""
import sys
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import dsn_api                                    # noqa: E402

# Un squelette minimal, en CRLF comme les vraies DSN.
DSN = "\r\n".join([
    "S10.G00.00.001,'PUPPETPAIE'",
    "S10.G00.00.005,'02'",
    "S10.G00.01.001,'SIREN-FICTIF'",
    "S20.G00.05.001,'01'",
    "S20.G00.05.002,'03'",
    "S20.G00.05.003,'11'",
    "S20.G00.05.004,'2'",
    "S20.G00.05.005,'01082026'",
    "S20.G00.05.006,'030920261'",
    "S20.G00.05.007,'10092026'",
    "S21.G00.20.005,'275.90'",
    "S21.G00.20.005,'697.00'",
    # Deux individus, sans NIR : le squelette sert a compter des blocs, et
    # `tests/test_operations.py` interdit toute donnee personnelle dans le code.
    "S21.G00.30.001,'NIR-FICTIF-UN'",
    "S21.G00.30.001,'NIR-FICTIF-DEUX'",
    "S90.G00.90.001,'14'",
]).encode("latin-1") + b"\r\n"


def _fichier(tmp_nom="t.dsn", contenu=DSN) -> Path:
    import tempfile
    p = Path(tempfile.mkdtemp()) / tmp_nom
    p.write_bytes(contenu)
    return p


def test_la_bascule_en_test_mord_vraiment():
    """Le fichier est en CRLF : la bascule doit quand meme changer la rubrique."""
    sortie = dsn_api.basculer_en_test(DSN)
    assert b"S10.G00.00.005,'01'" in sortie, "la bascule n'a rien change"
    assert b"S10.G00.00.005,'02'" not in sortie
    # Et elle ne touche a rien d'autre.
    assert len(sortie) == len(DSN)
    assert b"S20.G00.05.006,'030920261'" in sortie


def test_la_bascule_refuse_un_fichier_qui_n_est_pas_une_dsn():
    try:
        dsn_api.basculer_en_test(b"bonjour\r\n")
    except dsn_api.DepotRefuse:
        return
    raise AssertionError("aurait du refuser")


def test_l_apercu_lit_tous_les_ordres_de_telepaiement():
    """Un depot reel les declenche TOUS : on les montre tous."""
    a = dsn_api.lire(_fichier())
    assert a.versements == ["275.90", "697.00"], a.versements
    assert a.salaries == 2
    assert a.mois_lisible == "2026-08"
    assert a.type_declaration == "03"
    assert a.remplace == "030920261"
    assert a.reel is True


def test_le_reel_exige_de_recopier_le_mois():
    a = dsn_api.lire(_fichier())
    for mois in (None, "", "2026-09", "aout"):
        try:
            dsn_api.verifier(a, reel=True, mois_confirme=mois)
        except dsn_api.DepotRefuse:
            continue
        raise AssertionError("aurait du refuser le mois %r" % mois)
    dsn_api.verifier(a, reel=True, mois_confirme="2026-08")      # ne leve pas


def test_un_fichier_de_test_ne_part_jamais_en_reel():
    """Deposer un fichier code '01' en croyant declarer ne declare RIEN."""
    a = dsn_api.lire(_fichier(contenu=dsn_api.basculer_en_test(DSN)))
    assert a.reel is False
    try:
        dsn_api.verifier(a, reel=True, mois_confirme="2026-08")
    except dsn_api.DepotRefuse as e:
        assert "test" in str(e).lower()
        return
    raise AssertionError("aurait du refuser")


def test_les_adresses_de_depot_sont_celles_du_regime_general():
    """`dsnra` est le regime agricole, `depot-formation` un bac a sable."""
    assert dsn_api.ADRESSES_DEPOT["production"] == \
        "https://depot.dsnrg.net-entreprises.fr/deposer-dsn/1.0/"
    for url in dsn_api.ADRESSES_DEPOT.values():
        assert "dsnra" not in url and "formation" not in url, url


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("  OK     %s" % nom)
        except AssertionError as exc:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, exc))
    print("\n%s" % ("Tous les tests passent." if not echecs
                    else "%d test(s) en echec." % echecs))
    sys.exit(1 if echecs else 0)
