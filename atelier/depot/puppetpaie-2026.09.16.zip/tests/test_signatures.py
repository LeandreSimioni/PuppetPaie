"""La signature d'un clic : le bouton, la releve, le contrat contresigne.

Le circuit entier tourne ici sans Google : un faux client garde ce qui part
et rend ce qu'on lui fait « recevoir ». Ce qu'on verrouille :

  - le courriel porte un bouton mailto: vers NOTRE compte, avec le code dans
    le corps de la reponse preparee, et pas de retour a la ligne force ;
  - la releve ne prend jamais notre propre envoi pour une reponse (en test,
    le salarie, c'est nous) ; ni une reponse qui ne fait que citer le
    message d'origine ; ni une reponse venue d'une autre adresse ;
  - une vraie reponse note le contrat recu AU JOUR DE LA SIGNATURE, archive
    le message, renvoie le contrat contresigne et scelle, et n'est pas
    relevee deux fois.
"""
import email
import email.policy
import email.utils
import shutil
import sys
import tempfile
from email.message import EmailMessage
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import journal, operations as ops                    # noqa: E402
from moteur import operations_documents as od                    # noqa: E402
from moteur.contexte import Contexte                             # noqa: E402

REEL = Contexte()
MOIS = "2026-10"


class FauxGmail:
    """Ce que `google.Client` sait faire, sans reseau."""

    def __init__(self, compte="compagnie@exemple.fr"):
        self.compte = compte
        self.envoyes = {}            # id -> octets MIME
        self.boite = {}              # id -> octets (ce qu'on « recoit »)
        self._n = 0

    def _id(self):
        self._n += 1
        return "m%03d" % self._n

    def envoyer(self, mime: bytes) -> str:
        i = self._id()
        self.envoyes[i] = mime
        self.boite[i] = mime         # Gmail garde aussi ce qu'on envoie
        return i

    def recevoir(self, message: EmailMessage) -> str:
        i = self._id()
        self.boite[i] = message.as_bytes()
        return i

    def rechercher(self, requete: str, maximum: int = 50) -> list:
        mot = requete.strip('"').encode("ascii")
        return [i for i, b in self.boite.items() if mot in b][:maximum]

    def message_brut(self, identifiant: str) -> bytes:
        return self.boite[identifiant]


def _bac():
    racine = Path(tempfile.mkdtemp(prefix="puppetpaie-sig-"))
    shutil.copytree(REEL.racine / "config", racine / "config")
    # Jamais le vrai compte Google dans un bac : un test qui l'aurait
    # interrogerait la vraie boite (et pourrait y envoyer quelque chose).
    for secret in ("google-jeton.bin", "coffre.bin", ".seance"):
        (racine / "config" / secret).unlink(missing_ok=True)
    # Le salarie de test a une adresse a lui, distincte du compte.
    import json
    p = racine / "config" / "salaries.json"
    fiches = json.loads(p.read_text(encoding="utf-8"))
    cle = next(iter(REEL.salaries_actifs))
    fiches[cle]["email"] = "artiste@exemple.fr"
    p.write_text(json.dumps(fiches, ensure_ascii=False, indent=2), encoding="utf-8")
    ctx = Contexte(racine)
    spec = next(iter(ctx.spectacles_actifs))
    ops.enregistrer_saisie(ctx, MOIS, {
        "mois": MOIS, "date_paiement": "2026-10-31",
        "engagements": [{"salarie": cle, "spectacle": spec,
                         "lignes": [{"rubrique": "cachet", "quantite": 1,
                                     "taux": 130, "dates": ["2026-10-02"]}]}]})
    return ctx, cle


def _demander(ctx, faux):
    return ops.demander_signature(ctx, MOIS, preuve=ops.Preuve(mois_recopie=MOIS),
                                  qui="test", client=faux)


def _reponse(faux, de, sujet, corps):
    m = EmailMessage()
    m["From"] = de
    m["To"] = faux.compte
    m["Subject"] = sujet
    m["Date"] = email.utils.format_datetime(
        email.utils.parsedate_to_datetime("Wed, 16 Sep 2026 14:32:00 +0200"))
    m.set_content(corps)
    return faux.recevoir(m)


# ---------------------------------------------------------- 1. le courriel
def test_le_courriel_porte_un_bouton_vers_notre_compte_et_le_code():
    ctx, cle = _bac()
    faux = FauxGmail()
    r = _demander(ctx, faux)
    assert r["partis"] == ["artiste@exemple.fr"]
    (c,) = r["contrats"]
    assert od.FORME_CODE.fullmatch(c["code"]), c["code"]
    assert c["adresse"] == "artiste@exemple.fr" and c["message"] == "m001"
    mime = email.message_from_bytes(faux.envoyes["m001"], policy=email.policy.default)
    html = next(p.get_content() for p in mime.walk()
                if p.get_content_type() == "text/html")
    texte = next(p.get_content() for p in mime.walk()
                 if p.get_content_type() == "text/plain")
    assert 'href="mailto:compagnie@exemple.fr?' in html
    assert "subject=Re%3A%20" in html, "la reponse preparee n'est pas un « Re: »"
    assert c["code"] in html and c["code"] in texte
    # Pas de retour a la ligne force dans un paragraphe : chaque ligne du
    # texte est un paragraphe entier ou une ligne voulue.
    for ligne in texte.splitlines():
        assert not ligne.endswith((" un", " du", " et", " de")), ligne
    assert "du 02/10/2026 au 02/10/2026" in texte.replace("\n", " ")


def test_le_journal_garde_le_code_et_attend_la_signature():
    ctx, cle = _bac()
    faux = FauxGmail()
    _demander(ctx, faux)
    attendues = journal.signatures_attendues(ctx)
    assert len(attendues) == 1
    a = attendues[0]
    assert a["salarie"] == cle and a["envoyes"] == {"m001"}
    assert a["adresse"] == "artiste@exemple.fr"
    assert a["contrats"][0]["debut"] == "2026-10-02"


# ------------------------------------------------------------ 2. la releve
def test_notre_propre_envoi_n_est_pas_une_signature():
    """En test, le salarie c'est nous : le message envoye porte le code, vient
    du compte, et ne doit pas valoir signature."""
    ctx, cle = _bac()
    faux = FauxGmail(compte="artiste@exemple.fr")     # le compte EST le salarie
    _demander(ctx, faux)
    r = ops.relever_signatures(ctx, client=faux, qui="test")
    assert r.attendues == 1 and not r.recues, r
    assert not r.incidents, r.incidents


def test_une_reponse_qui_ne_fait_que_citer_le_code_ne_signe_pas():
    ctx, cle = _bac()
    faux = FauxGmail()
    code = _demander(ctx, faux)["contrats"][0]["code"]
    _reponse(faux, "artiste@exemple.fr", "Re: Contrat d'engagement",
             "Je ne suis pas d'accord sur les dates.\n\n"
             "Le mar. 15 sept. 2026, PuppetPaie a écrit :\n"
             "> réponds à ce message en écrivant Je signe suivi de ce code : %s\n" % code)
    r = ops.relever_signatures(ctx, client=faux, qui="test")
    assert not r.recues and not r.incidents, r


def test_une_reponse_venue_d_une_autre_adresse_est_signalee_pas_retenue():
    ctx, cle = _bac()
    faux = FauxGmail()
    code = _demander(ctx, faux)["contrats"][0]["code"]
    _reponse(faux, "quelqu.un@ailleurs.fr", "Re: Contrat d'engagement",
             "Je signe %s" % code)
    r = ops.relever_signatures(ctx, client=faux, qui="test")
    assert not r.recues
    assert any("ailleurs.fr" in i and "pas retenue" in i for i in r.incidents), r.incidents
    assert not journal.contrats_recus(ctx)


def test_une_vraie_reponse_signe_archive_contresigne_et_renvoie():
    ctx, cle = _bac()
    faux = FauxGmail()
    d = _demander(ctx, faux)
    code, fichier = d["contrats"][0]["code"], d["contrats"][0]["fichier"]
    _reponse(faux, "Artiste@Exemple.fr", "Re: Contrat d'engagement",
             "Je soussigné(e) X déclare avoir lu et accepter le contrat.\n\n"
             "Code de signature : %s\n\n> citation du message d'origine %s\n"
             % (code, code))
    r = ops.relever_signatures(ctx, client=faux, qui="test")
    assert len(r.recues) == 1 and not r.incidents, r
    s = r.recues[0]
    assert s.adresse == "artiste@exemple.fr" and s.code == code
    assert s.quand == "2026-09-16T14:32:00", s.quand     # l'heure du message
    assert s.renvoye

    # Le journal : recu, date de la signature, origine dite.
    recus = journal.contrats_recus(ctx)
    assert recus[(cle, "2026-10-02")] == "2026-09-16T14:32:00"
    assert journal.contrats_recus_comment(ctx)[(cle, "2026-10-02")] == "courriel"
    ligne = journal.lire(ctx, journal.CONTRAT_RECU)[-1]
    assert ligne["origine"].startswith("courriel Gmail m")
    assert ligne["detail"]["preuve"].endswith(".eml")

    # La preuve et le contrat contresigne, scelle, dans le dossier d'envoi.
    dossier = ctx.racine / "sorties" / MOIS / "envoi"
    assert (dossier / ligne["detail"]["preuve"]).exists()
    signe = dossier / s.fichier_signe
    assert signe.exists() and signe.name == fichier[:-4] + "_signe.pdf"
    import pymupdf
    doc = pymupdf.open(str(signe))
    assert not (doc.permissions & pymupdf.PDF_PERM_MODIFY), "le PDF reste modifiable"
    texte = doc[0].get_text()
    assert code in texte and "artiste@exemple.fr" in texte and "16/09/2026" in texte

    # Le renvoi est parti au salarie, avec le PDF scelle, et il est journalise.
    renvoi = email.message_from_bytes(faux.envoyes["m003"], policy=email.policy.default)
    assert renvoi["To"] == "artiste@exemple.fr"
    assert "signé" in renvoi["Subject"]
    assert any(p.get_filename() == signe.name for p in renvoi.walk())
    assert journal.lire(ctx, journal.CONTRESIGNE)[-1]["detail"]["code"] == code

    # Plus rien n'est attendu : une seconde releve ne refait rien.
    assert not journal.signatures_attendues(ctx)
    r2 = ops.relever_signatures(ctx, client=faux, qui="test")
    assert r2.attendues == 0 and not r2.recues
    assert len(faux.envoyes) == 2


def test_l_apercu_dit_ce_qui_est_attendu_et_si_la_lecture_est_permise():
    ctx, cle = _bac()
    faux = FauxGmail()
    _demander(ctx, faux)
    a = ops.apercu_signature(ctx, MOIS)
    assert a["attendues"] == 1
    assert "lecture_autorisee" in a and a["contrats"][0]["recu_par"] is None


def test_la_releve_sans_compte_google_dit_pourquoi_sans_lever():
    ctx, cle = _bac()
    _demander(ctx, FauxGmail())
    r = ops.relever_signatures(ctx)            # pas de client : le vrai, absent
    assert r.attendues == 1 and not r.recues
    assert r.incidents and "Google" in r.incidents[0]


# --------------------------------------------------------- 3. le texte propre
def test_le_texte_propre_s_arrete_a_la_citation():
    m = EmailMessage()
    m.set_content("Je signe SIG-ABCDEF\n\nLe lun. 14 sept. 2026 à 10:00, X a écrit :\n> SIG-ZZZZZZ\n")
    t = od._texte_propre(m)
    assert "SIG-ABCDEF" in t and "SIG-ZZZZZZ" not in t
    m = EmailMessage()
    m.set_content("<div>Je signe <b>SIG-ABCDEF</b></div><blockquote>SIG-ZZZZZZ</blockquote>",
                  subtype="html")
    t = od._texte_propre(m)
    assert "SIG-ABCDEF" in t and "SIG-ZZZZZZ" not in t


def _lancer() -> int:
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    rates = []
    for nom, f in tests:
        try:
            f()
            print("  OK     %s" % nom)
        except AssertionError as e:
            rates.append((nom, e))
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            rates.append((nom, e))
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    print("\n%d test(s), %d echec(s)." % (len(tests), len(rates)))
    if not rates:
        print("\nTous les tests passent.")
    return 1 if rates else 0


if __name__ == "__main__":
    sys.exit(_lancer())
