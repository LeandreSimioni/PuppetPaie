"""La reduction generale (RGDU) et la deduction forfaitaire specifique (DFS).

Deux mecanismes ecrits le 13/09/2026 depuis les textes -- art. D. 241-7 CSS
pour la premiere, arrete du 20/12/2002 et BOSS pour la seconde -- et pas
depuis un bulletin : la compagnie n'emploie pas de technicien en 2026 et
aucun de ses artistes n'exerce la DFS. Ces tests verifient donc la formule
contre elle-meme et contre les valeurs remarquables que les textes donnent
(coefficient maximal 0,3981 au SMIC, nul a 3 SMIC), et que le chemin
artiste sans DFS ne bouge pas d'un centime.
"""
import io
import json
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import calcul, dsn, operations as ops          # noqa: E402
from moteur.contexte import Contexte                        # noqa: E402
from moteur.util import pct, eur                            # noqa: E402

ctx = Contexte()
BAR = ctx.bareme("2026-09-13")


def _bareme_technicien() -> dict:
    """Le corps du bareme, avec la seule section RGDU des techniciens greffee :
    la formule se teste sans le reste du bareme technicien."""
    b = dict(BAR)
    b["reduction_generale"] = BAR["par_statut"]["technicien"]["reduction_generale"]
    return b


# ---------------------------------------------------------------- la RGDU
def test_la_reduction_est_maximale_au_smic_et_nulle_a_trois_smic():
    b = _bareme_technicien()
    rg = b["reduction_generale"]
    smic_h = Decimal(str(rg["smic_horaire_reference"]))
    heures = Decimal("151.67")
    au_smic = calcul.reduction_generale(b, "technicien", eur(smic_h * heures), heures)
    assert au_smic["coefficient"] == Decimal("0.3981"), au_smic
    assert au_smic["coefficient"] == Decimal(str(rg["tmin"])) + Decimal(str(rg["tdelta"]))
    a_trois = calcul.reduction_generale(b, "technicien", eur(smic_h * heures * 3), heures)
    assert a_trois["montant"] == Decimal("0.00") and a_trois["coefficient"] == 0
    # Entre les deux, elle decroit.
    milieu = calcul.reduction_generale(b, "technicien", eur(smic_h * heures * 2), heures)
    assert 0 < milieu["coefficient"] < au_smic["coefficient"]


def test_le_coefficient_se_calcule_par_contrat_sur_les_heures_remunerees():
    """Quatre heures a 14 EUR, le contrat technicien de reference (mai 2025,
    rejoue avec les parametres 2026) : SMIC de reference 12,02 x 4 = 48,08 ;
    3 x 48,08 / 56 - 1 = 1,5757 ; /2 = 0,7879 ; ^1,75 = 0,6588 ; x 0,3781 +
    0,02 = 0,2691 -> 15,07 EUR. Arrondi a quatre decimales, D. 241-7."""
    b = _bareme_technicien()
    rg = calcul.reduction_generale(b, "technicien", Decimal("56.00"), Decimal("4"))
    assert rg["smic_reference"] == Decimal("48.08")
    assert rg["coefficient"] == Decimal("0.2691")
    assert rg["montant"] == Decimal("15.07")
    # La repartition retombe sur le montant, au centime.
    assert rg["urssaf"] + rg["chomage"] + rg["agirc_arrco"] == rg["montant"]
    assert rg["chomage"] == eur(Decimal("15.07") * Decimal("4.00") / Decimal("39.81"))


def test_un_artiste_n_y_a_pas_droit():
    b = _bareme_technicien()
    assert calcul.reduction_generale(b, "artiste", Decimal("130.00"), Decimal("12")) is None
    assert calcul.reduction_generale(b, "", Decimal("130.00"), Decimal("12")) is None
    # Et le corps du bareme, sans section, ne la calcule pour personne.
    assert calcul.reduction_generale(BAR, "technicien", Decimal("56.00"), Decimal("4")) is None


def test_la_dsn_porte_les_trois_parts_de_la_reduction():
    """Trois blocs 81 negatifs sous le bloc 78 type 03, comme dans la DSN
    CoolPaie de mai 2025 : 018 a l'Urssaf, 018 a France Travail, 106 sans
    organisme. Les deux 018 se distinguent par `cle_total` pour les
    versements."""
    paie = SimpleNamespace(
        brut=Decimal("56.00"), base_csg=Decimal("55.02"),
        salarie={"statut": "artiste"},
        reduction_generale={"montant": Decimal("15.07"), "urssaf": Decimal("11.28"),
                            "chomage": Decimal("1.51"), "agirc_arrco": Decimal("2.28")})
    lignes = dsn.cotisations(paie, BAR)
    parts = [(c["code81"], c["org"], c["montant"], c["cle_total"])
             for c in lignes if c.get("cle_total")]
    assert parts == [("018", "78861779300013", Decimal("-11.28"), "018:urssaf"),
                     ("018", "13000548100010", Decimal("-1.51"), "018:chomage"),
                     ("106", None, Decimal("-2.28"), "106")], parts
    assert all(c["bloc78"] == "03" and c["base81"] == Decimal("56.00")
               for c in lignes if c.get("cle_total"))
    # Sans reduction, pas de ligne : le chemin artiste est intact.
    paie.reduction_generale = None
    assert not [c for c in dsn.cotisations(paie, BAR) if c.get("cle_total")]


def _bac_technicien():
    """Une copie de la configuration ou le premier salarie actif devient
    technicien -- charge de production, comme le contrat SI2.25.7 de mai 2025."""
    racine = Path(tempfile.mkdtemp())
    shutil.copytree(ctx.racine / "config", racine / "config")
    f = racine / "config" / "salaries.json"
    d = json.loads(f.read_text(encoding="utf-8"))
    cle = next(iter(ctx.salaries_actifs))
    d[cle].update({"statut": "technicien", "statut_conventionnel": "07",
                   "emploi": "CHARGE DE PRODUCTION", "pcs_ese": "637C",
                   "code_emploi_ft": "CHA080"})
    f.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    return racine, cle


def _saisie_horaire(cle, heures=4, taux=14):
    spec = next(iter(ctx.spectacles_actifs))
    return {"mois": "2026-10", "date_paiement": "2026-10-31",
            "engagements": [{"salarie": cle, "spectacle": spec,
                             "lignes": [{"rubrique": "heure", "quantite": heures,
                                         "taux": taux, "dates": ["2026-10-02"]}]}]}


def test_un_technicien_est_paye_aux_taux_pleins_avec_sa_reduction():
    """Le contrat de reference (4 h a 14 EUR), en 2026 : taux pleins 13,00 et
    5,25, AT 1,50 sans abattement, Agirc-Arrco techniciens, et la reduction
    generale de 15,07 EUR en ligne negative cote employeur."""
    racine, cle = _bac_technicien()
    try:
        bac = Contexte(racine)
        p = ops.charger(bac, _saisie_horaire(cle)).paies[0]
        assert p.brut == Decimal("56.00")
        assert p.ligne("maladie").taux_pat == 13.0
        assert p.ligne("maladie").montant_pat == Decimal("7.28")
        assert p.ligne("famille").taux_pat == 5.25
        assert p.ligne("atmp").taux_pat == 1.5
        assert p.ligne("retraite_t1").taux_pat == 5.23
        assert p.ligne("ccn").taux_pat == 0.5
        rg = p.ligne("reduction_generale")
        assert rg is not None and rg.montant_pat == Decimal("-15.07")
        assert p.reduction_generale["coefficient"] == Decimal("0.2691")
        # Le cout employeur porte la reduction ; le net du salarie ne la voit pas.
        assert p.cout_employeur == p.brut + p.total_pat
        assert p.total_pat == sum((l.montant_pat for l in p.lignes), Decimal("0.00"))
        assert not _dfs(p), _dfs(p)
    finally:
        shutil.rmtree(racine, ignore_errors=True)


def test_la_dsn_d_un_technicien_suit_le_fichier_coolpaie_de_mai_2025():
    """La DSN CoolPaie de mai 2025 (export/DSN/Mai_CCoU_300525_MENSUELLE.dsn,
    contrat SI2.25.7) est le seul reel avec un technicien. Sa structure :
    sous le bloc 78 type 03, un composant 79 type 01 = SMIC x heures
    (47,52 = 11,88 x 4), puis trois blocs 81 NEGATIFS avec assiette -- 018
    Urssaf, 018 France Travail, 106 sans organisme ; au bordereau, CTP 100
    (AT plein) et 332 (FNAL) sur le brut du technicien, CTP 671 qualifiant
    921 avec le montant en euros (8,00 pour 8,12), et les CTP abattus 312 et
    334 sans le technicien."""
    racine, cle = _bac_technicien()
    try:
        bac = Contexte(racine)
        s = ops.charger(bac, _saisie_horaire(cle))
        texte = dsn.generer(bac, s.paies, "2026-10", versement_urssaf=Decimal("100"))
        lignes = texte.splitlines()

        def apres(motif, n=12):
            i = next(k for k, l in enumerate(lignes) if motif in l)
            return lignes[i:i + n]

        # Le SMIC retenu : celui du calcul, gele (12,02 x 4), pas le SMIC du jour.
        assert "S21.G00.79.004,'48.08'" in apres("S21.G00.79.001,'01'", 2)
        bloc = apres("S21.G00.81.001,'018'", 11)
        assert bloc[:11] == [
            "S21.G00.81.001,'018'", "S21.G00.81.002,'78861779300013'",
            "S21.G00.81.003,'56.00'", "S21.G00.81.004,'-11.28'",
            "S21.G00.81.001,'018'", "S21.G00.81.002,'13000548100010'",
            "S21.G00.81.003,'56.00'", "S21.G00.81.004,'-1.51'",
            "S21.G00.81.001,'106'", "S21.G00.81.003,'56.00'",
            "S21.G00.81.004,'-2.28'"], bloc
        # Le bordereau.
        assert "S21.G00.23.003,'01.50'" in apres("S21.G00.23.001,'100'", 3)
        assert apres("S21.G00.23.001,'671'", 3) == [
            "S21.G00.23.001,'671'", "S21.G00.23.002,'921'", "S21.G00.23.005,'11.00'"]
        assert "S21.G00.23.004,'62.00'" in apres("S21.G00.23.001,'332'", 3)
        # Sans artiste dans le mois, les CTP abattus ne s'ecrivent pas.
        assert not any("S21.G00.23.001,'312'" in l or "S21.G00.23.001,'334'" in l
                       for l in lignes)
        # Les taux pleins, decomposes comme CoolPaie decompose ceux des
        # artistes en 2026 : 074 + 102 = 5,25 ; 075 + 907 = 13,00.
        assert "S21.G00.81.007,'3.450'" in apres("S21.G00.81.001,'074'", 5)
        assert "S21.G00.81.007,'1.800'" in apres("S21.G00.81.001,'102'", 5)
        assert "S21.G00.81.007,'7.000'" in apres("S21.G00.81.001,'075'", 5)
        assert "S21.G00.81.007,'6.000'" in apres("S21.G00.81.001,'907'", 5)
        # Et la part chomage se retranche du versement France Travail.
        i = next(k for k, l in enumerate(lignes) if "S21.G00.20.001,'13000548100010'" in l)
        ft = next(l for l in lignes[i:i + 8] if "S21.G00.20.005" in l)
        attendu = (Decimal("56.00") * Decimal("12.15") / 100).quantize(Decimal("0.01"))
        assert ft.endswith("'%s'" % (attendu - Decimal("1.51"))), (ft, attendu)
    finally:
        shutil.rmtree(racine, ignore_errors=True)


def test_un_mois_sans_technicien_ne_change_pas_d_un_octet():
    """Le garde-fou de tout ce qui precede : les CTP techniciens et les blocs
    de reduction n'apparaissent pas dans un mois d'artistes. Le rejeu de
    juillet 2026 (test_non_regression) le prouve au caractere pres ; ici on
    verifie que rien de technicien ne fuit."""
    cle = next(iter(ctx.salaries_actifs))
    s = ops.charger(ctx, _saisie(cle))
    texte = dsn.generer(ctx, s.paies, "2026-10", versement_urssaf=Decimal("100"))
    for motif in ("S21.G00.23.001,'100'", "S21.G00.23.001,'332'",
                  "S21.G00.23.001,'671'", "S21.G00.81.001,'018'", "S21.G00.81.001,'106'"):
        assert motif not in texte, motif


# ----------------------------------------------------------------- la DFS
def _bac_avec_dfs(categorie: str):
    racine = Path(tempfile.mkdtemp())
    shutil.copytree(ctx.racine / "config", racine / "config")
    f = racine / "config" / "salaries.json"
    d = json.loads(f.read_text(encoding="utf-8"))
    cle = next(iter(ctx.salaries_actifs))
    d[cle]["deduction_forfaitaire"] = categorie
    f.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    return racine, cle


def _dfs(paie):
    """Les avertissements de DEDUCTION FORFAITAIRE de cette paie.

    `avertissements` en porte d'autres depuis le 13/09/2026 -- les minima
    conventionnels -- et ceux-la dependent de la fiche entreprise reelle :
    le jour ou son annexe de convention a ete renseignee, deux tests
    << aucun avertissement >> sont passes au rouge sans que rien du calcul
    n'ait bouge. Un test dit ce qu'il teste.
    """
    return [a for a in paie.avertissements if "deduction forfaitaire" in a]


def _saisie(cle):
    spec = next(iter(ctx.spectacles_actifs))
    return {"mois": "2026-10", "date_paiement": "2026-10-31",
            "engagements": [{"salarie": cle, "spectacle": spec,
                             "lignes": [{"rubrique": "cachet", "quantite": 1,
                                         "taux": 130, "dates": ["2026-10-02"]}]}]}


def test_la_dfs_abat_l_assiette_des_cotisations_de_securite_sociale():
    """Categorie 25 % -> 18 % en 2026 : maladie sur 130 x 0,82 = 106,60, le
    chomage et la CSG sur le brut entier, et un avertissement qui dit que le
    calcul n'a jamais ete confronte a un bulletin."""
    racine, cle = _bac_avec_dfs("25")
    try:
        bac = Contexte(racine)
        p = ops.charger(bac, _saisie(cle)).paies[0]
        assert p.deduction_forfaitaire and p.deduction_forfaitaire["taux"] == 18
        assert p.brut == Decimal("130.00")
        maladie = p.ligne("maladie")
        assert maladie.base == Decimal("106.60")
        assert maladie.montant_pat == pct(Decimal("106.60"), maladie.taux_pat)
        assert p.ligne("chomage").base == Decimal("130.00")
        assert p.ligne("csg_ded").base == p.base_csg
        assert _dfs(p) and "deduction forfaitaire" in _dfs(p)[0]
        # Le net salarie monte : la vieillesse salariale est sur l'assiette abattue.
        sans = ops.charger(ctx, _saisie(cle)).paies[0]
        assert p.net_a_payer > sans.net_a_payer
        assert p.cout_employeur < sans.cout_employeur
    finally:
        shutil.rmtree(racine, ignore_errors=True)


def test_une_categorie_inconnue_est_refusee():
    racine, cle = _bac_avec_dfs("30")
    try:
        bac = Contexte(racine)
        try:
            ops.charger(bac, _saisie(cle))
        except Exception as e:                                    # noqa: BLE001
            assert "30" in str(e) and "bareme" in str(e).lower()
        else:
            raise AssertionError("une DFS a 30 % a ete calculee sans taux")
    finally:
        shutil.rmtree(racine, ignore_errors=True)


def test_sans_dfs_rien_ne_change():
    cle = next(iter(ctx.salaries_actifs))
    p = ops.charger(ctx, _saisie(cle)).paies[0]
    assert p.deduction_forfaitaire is None and p.reduction_generale is None
    assert not _dfs(p), _dfs(p)
    assert p.ligne("maladie").base == p.brut


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            with redirect_stdout(io.StringIO()):
                fn()
            print("  OK     %s" % nom)
        except AssertionError as exc:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, exc))
        except Exception as exc:                                  # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(exc).__name__, exc))
    print("\n%s" % ("Tous les tests passent." if not echecs
                    else "%d test(s) en echec." % echecs))
    sys.exit(1 if echecs else 0)
