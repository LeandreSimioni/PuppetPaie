"""La version du logiciel, et sa mise a jour dans l'ombre.

Tout se passe dans des dossiers temporaires : un « depot » (un dossier), une
« installation » (le code courant, deballe a part), ses donnees (une racine
avec config/maj.json). Aucun reseau. Ce qu'on verrouille :

  - publier : l'archive et derniere.json ; on ne republie pas un numero ;
  - verifier : rien sans depot, « a jour » si rien de plus recent, sinon
    telecharge, controle (le code s'importe en entier), pose prete.json --
    et un condensat faux est refuse ;
  - appliquer : la bascule, l'ancienne version dans .avant/, la note
    « change un calcul » montree une fois ; revenir ;
  - l'ouverture : l'editeur verifie les sources et ne recoit rien ; une
    compagnie recoit et ne verifie pas les sources ; un maj.json illisible
    se dit.
"""
import io
import json
import shutil
import sys
import tempfile
import types
import zipfile
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import maj, operations as ops   # noqa: E402


def _tmp(nom):
    return Path(tempfile.mkdtemp(prefix="puppetpaie-maj-%s-" % nom))


def _installation(version: str) -> Path:
    """Le code courant, deballe dans un dossier a part, avec cette version."""
    d = _tmp("code") / "logiciel"
    d.mkdir()
    with zipfile.ZipFile(io.BytesIO(maj.archiver(CODE))) as z:
        z.extractall(d)
    (d / "VERSION").write_text(version + "\n", encoding="utf-8")
    return d


REEL = Path(__import__("moteur.contexte", fromlist=["racine_donnees"]).racine_donnees())


def _ctx(depot=None, editeur=False, brut=None):
    """Une racine de donnees : la configuration du poste copiee (sans
    secrets) -- le controle d'une version la lit --, et maj.json au choix."""
    racine = _tmp("prive")
    shutil.copytree(REEL / "config", racine / "config")
    for secret in ("google-jeton.bin", "coffre.bin", ".seance", "maj.json", ".ouverture.json"):
        (racine / "config" / secret).unlink(missing_ok=True)
    if brut is not None:
        (racine / "config" / "maj.json").write_text(brut, encoding="utf-8")
    elif depot or editeur:
        (racine / "config" / "maj.json").write_text(
            json.dumps({"depot": depot, "editeur": editeur}), encoding="utf-8")
    return types.SimpleNamespace(racine=racine)


# ------------------------------------------------------------------ tests
def test_la_version_est_une_date_qui_se_compare_en_entiers():
    assert maj.plus_recente("2026.10.02", "2026.9.16")
    assert not maj.plus_recente("2026.09.16", "2026.09.16")
    assert not maj.plus_recente("n'importe quoi", "2026.09.16")
    assert maj.courante(CODE).count(".") == 2


def test_publier_pose_l_archive_et_refuse_de_republier_le_meme_numero():
    code = _installation("2026.10.01")
    depot = _tmp("depot")
    r = maj.publier(str(depot), notes="essai", code=code)
    d = json.loads((depot / "derniere.json").read_text(encoding="utf-8"))
    assert d["version"] == "2026.10.01" and d["archive"] == r["archive"] == "puppetpaie-2026.10.01.zip"
    assert len(d["sha256"]) == 64 and d["notes"] == "essai" and d["calcul"] == ""
    with zipfile.ZipFile(depot / d["archive"]) as z:
        noms = z.namelist()
    assert "VERSION" in noms and "moteur/maj.py" in noms
    assert not any("__pycache__" in n or n.startswith(".avant") for n in noms)
    try:
        maj.publier(str(depot), code=code)
        assert False, "republier le meme numero devrait etre refuse"
    except ValueError as e:
        assert "augmenter VERSION" in str(e)
    # Archive deterministe : meme code, meme condensat.
    assert maj.archiver(code) == maj.archiver(code)


def test_verifier_sans_depot_dit_la_version_et_rien_d_autre():
    e = maj.verifier(_ctx(), code=CODE)
    assert e.message == "version %s" % maj.courante(CODE) and e.prete is None
    assert "aucun depot" in e.detail


def test_verifier_telecharge_controle_et_prepare_puis_appliquer_bascule():
    neuf = _installation("2026.12.01")
    depot = _tmp("depot")
    maj.publier(str(depot), notes="decembre", calcul="le cachet de repetition se calcule sur 4 h",
                code=neuf)
    code = _installation("2026.09.16")            # l'installation d'une compagnie
    ctx = _ctx(depot=str(depot))

    e = maj.verifier(ctx, code=code)
    assert e.derniere == "2026.12.01" and e.prete == "2026.12.01" and e.telechargee_maintenant
    assert "2026.12.01 est prete" in e.message and "redemarrez" in e.message
    p = maj.prete(ctx)
    assert p["version"] == "2026.12.01" and p["calcul"].startswith("le cachet")
    assert (maj.dossier_maj(ctx) / "2026.12.01" / "logiciel" / "moteur" / "maj.py").exists()

    # Deuxieme passage : rien a retelecharger, le message reste.
    e2 = maj.verifier(ctx, code=code)
    assert e2.prete == "2026.12.01" and not e2.telechargee_maintenant

    # La bascule.
    r = maj.appliquer(ctx, code=code, forcer=True)
    assert r["version"] == "2026.12.01"
    assert maj.courante(code) == "2026.12.01"
    assert maj.courante(code / ".avant") == "2026.09.16"
    assert (code / "moteur" / "maj.py").exists() and (code / ".avant" / "moteur" / "maj.py").exists()
    assert maj.prete(ctx) is None
    assert not (maj.dossier_maj(ctx) / "2026.12.01").exists()

    # La note « change un calcul » : une fois.
    e3 = maj.verifier(ctx, code=code)
    assert e3.message == "version 2026.12.01, a jour"
    assert "change un calcul" in e3.note_calcul and "4 h" in e3.note_calcul
    assert maj.verifier(ctx, code=code).note_calcul == ""

    # Revenir.
    r = maj.revenir(ctx, code=code, forcer=True)
    assert r["version"] == "2026.09.16" and maj.courante(code) == "2026.09.16"
    assert not (code / ".avant").exists()
    shutil.rmtree(code.parent, ignore_errors=True)
    shutil.rmtree(neuf.parent, ignore_errors=True)


def test_une_archive_alteree_ou_qui_ne_demarre_pas_n_est_jamais_prete():
    neuf = _installation("2026.12.01")
    depot = _tmp("depot")
    maj.publier(str(depot), code=neuf)
    code = _installation("2026.09.16")
    ctx = _ctx(depot=str(depot))
    d = json.loads((depot / "derniere.json").read_text(encoding="utf-8"))

    # Condensat faux.
    d["sha256"] = "0" * 64
    (depot / "derniere.json").write_text(json.dumps(d), encoding="utf-8")
    e = maj.verifier(ctx, code=code)
    assert e.prete is None and "alteree" in e.detail and e.message == "version 2026.09.16"
    assert maj.prete(ctx) is None

    # Un code qui ne s'importe pas : refuse, et rien ne reste.
    (neuf / "moteur" / "casse.py").write_text("import module_qui_n_existe_pas\n", encoding="utf-8")
    (neuf / "VERSION").write_text("2026.12.02\n", encoding="utf-8")
    maj.publier(str(depot), code=neuf)
    e = maj.verifier(ctx, code=code)
    assert e.prete is None and "ne demarre pas" in e.detail and "casse" in e.detail
    assert not (maj.dossier_maj(ctx) / "2026.12.02").exists()

    # Depot injoignable : calme.
    e = maj.verifier(_ctx(depot=str(depot / "nulle-part")), code=code)
    assert e.prete is None and "injoignable" in e.detail and e.message == "version 2026.09.16"
    shutil.rmtree(code.parent, ignore_errors=True)
    shutil.rmtree(neuf.parent, ignore_errors=True)


def test_l_ouverture_distingue_l_editeur_de_la_compagnie():
    from moteur import sources as _sources
    appels = {"sources": 0, "maj": 0}
    vrai_sources, vrai_verifier = _sources.verifier, maj.verifier

    def faux_sources(ctx, seulement=None, relever=False):
        appels["sources"] += 1
        return []

    def faux_maj(ctx, telecharger=True, code=maj.CODE):
        appels["maj"] += 1
        return maj.EtatMaj(courante="2026.09.16", depot="x", derniere="2026.10.01",
                           prete="2026.10.01", message="version 2026.09.16 -- la 2026.10.01 est prete")
    _sources.verifier, maj.verifier = faux_sources, faux_maj
    try:
        r = ops.ouverture(_ctx(editeur=True), sauvegarder=False, retours=False, signatures=False)
        assert r.sources is not None and r.maj is None
        assert appels == {"sources": 1, "maj": 0}
        r = ops.ouverture(_ctx(depot="x"), sauvegarder=False, retours=False, signatures=False)
        assert r.sources is None and r.maj is not None and r.maj.prete == "2026.10.01"
        assert appels == {"sources": 1, "maj": 1} and not r.incidents
        assert "est prete" in r.maj.resume()
        r = ops.ouverture(_ctx(brut="{ pas du json"), sauvegarder=False, retours=False, signatures=False)
        assert r.sources is None and r.maj is None
        assert any("maj.json illisible" in i for i in r.incidents)
    finally:
        _sources.verifier, maj.verifier = vrai_sources, vrai_verifier


def test_les_commandes_version_et_maj_rendent_du_json():
    from contextlib import redirect_stdout
    from moteur import cli
    buf = io.StringIO()
    with redirect_stdout(buf):
        assert cli.main(["version", "--json"]) == 0
    d = json.loads(buf.getvalue())
    assert d["ok"] and d["resultat"]["courante"] == maj.courante(CODE)
    buf = io.StringIO()
    with redirect_stdout(buf):
        assert cli.main(["version", "--controle", "--json"]) == 0
    assert json.loads(buf.getvalue())["resultat"]["echecs"] == []


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("ok   ", nom)
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            import traceback
            print("ECHEC", nom, "->", e)
            traceback.print_exc()
    print("\n%d test(s), %d echec(s)" % (
        len([n for n in globals() if n.startswith("test_")]), echecs))
    sys.exit(1 if echecs else 0)
