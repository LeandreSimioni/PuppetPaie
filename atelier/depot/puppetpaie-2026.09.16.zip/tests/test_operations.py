"""Tests de la couche d'orchestration -- ce qui rend les deux faces sures.

PuppetPaie a deux faces interchangeables : la ligne de commande et
l'interface. Ce fichier verrouille les trois proprietes sans lesquelles cette
promesse serait fausse.

  1. Les GARDE-FOUS sont dans `operations`, pas dans un front. Une interface
     qui appellerait `dsn.ecrire` directement ne doit pas pouvoir produire une
     DSN sans montant URSSAF : c'est `produire_mois` qui refuse.
  2. Un refus n'ECRIT RIEN -- ni fichier, ni compteur. Sinon un essai
     consommerait un numero de bulletin, et deux paies porteraient le meme.
  3. Deux productions SIMULTANEES s'excluent. C'est le seul risque vraiment
     nouveau qu'ouvre une deuxieme face : l'interface ouverte pendant qu'une
     commande tourne.

Aucun de ces tests ne produit un mois : ils s'arretent tous avant l'ecriture.
Le seul qui ecrive (`..._descend_dans_l_historique`) le fait dans une copie
jetable de la configuration -- la vraie ne bouge pas.
"""
import io
import sys
from contextlib import redirect_stdout
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent    # logiciel/ : le depot public
sys.path.insert(0, str(CODE))

from moteur import cli, operations as ops                # noqa: E402
from moteur.contexte import Contexte, resoudre           # noqa: E402

ctx = Contexte()
RACINE = ctx.racine        # prive/ : les donnees
SAISIE = RACINE / "paies" / "2026-08.json"


# ------------------------------------------------ 1. les garde-fous sont ici
def test_produire_mois_refuse_sans_montant_audiens():
    """Le bloc S21.G00.20 est un ordre de telepaiement : jamais devine."""
    essai = False
    try:
        ops.produire_mois(ctx, SAISIE, qui="test")
    except ops.UrssafManquant as e:
        essai = True
        assert e.estimation, "l'exception doit porter l'estimation"
        assert e.apercu.paies, "et l'apercu, pour que le front puisse l'afficher"
    assert essai, "produire_mois a accepte de produire sans montant URSSAF"


def test_le_refus_est_une_exception_pas_un_code_de_retour():
    """Un `return 2` ne franchit pas une frontiere de module : une interface
    ne le verrait pas. Le garde-fou doit etre une exception."""
    assert issubclass(ops.UrssafManquant, ops.ErreurOperation)
    assert issubclass(ops.ErreurOperation, Exception)


def test_la_ligne_de_commande_ne_decide_rien_elle_meme():
    """`cli.py` n'a pas le droit de reimplementer un garde-fou : il attrape
    celui d'`operations`. Si ce test tombe, c'est qu'une decision est
    redescendue dans un front -- et que l'autre face ne l'aura pas."""
    source = (CODE / "moteur" / "cli.py").read_text(encoding="utf-8")
    for interdit in ("estimation_urssaf", "valider_compteurs",
                     "enregistrer_compteur", "prochain_continu"):
        assert interdit not in source, (
            "cli.py touche a `%s` : cette decision appartient a operations.py"
            % interdit)


# ------------------------------------------------ 2. un refus n'ecrit rien
def test_un_refus_ne_consomme_aucun_numero():
    """Le piege classique : un essai qui brule un numero de bulletin."""
    fichier = ctx._fichier_compteurs()
    avant = fichier.read_bytes()
    try:
        ops.produire_mois(Contexte(), SAISIE, qui="test")
    except ops.UrssafManquant:
        pass
    assert fichier.read_bytes() == avant, "compteurs.json a bouge sur un refus"


def test_un_apercu_n_ecrit_rien():
    """L'interface calcule un formulaire a chaque frappe : cela doit etre
    gratuit, et surtout sans effet."""
    fichier = ctx._fichier_compteurs()
    avant = fichier.read_bytes()
    a = ops.apercu_mois(Contexte(), SAISIE)
    assert a.total_brut > 0
    assert fichier.read_bytes() == avant


def test_le_verrou_est_rendu_apres_un_refus():
    """Sinon le premier essai bloquerait le logiciel pour dix minutes."""
    try:
        ops.produire_mois(Contexte(), SAISIE, qui="test")
    except ops.UrssafManquant:
        pass
    assert not (ctx.racine / "config" / ".compteurs.verrou").exists()


# ------------------------------------------- 3. deux fronts ne se marchent pas
def test_deux_productions_simultanees_s_excluent():
    """Le risque qu'ouvre la deuxieme face : l'interface et une commande qui
    attribuent les memes numeros au meme instant."""
    pris = False
    with ops.verrou_compteurs(ctx, qui="interface"):
        try:
            with ops.verrou_compteurs(ctx, qui="cli"):
                pass
        except ops.CompteursVerrouilles as e:
            pris = True
            assert "interface" in e.detenteur
    assert pris, "deux productions ont pu tenir les compteurs en meme temps"


def test_le_verrou_abandonne_est_repris():
    """Une fenetre fermee au mauvais moment ne doit pas bloquer pour toujours :
    passe le delai, le verrou est tenu pour mort."""
    verrou = ctx.racine / "config" / ".compteurs.verrou"
    verrou.write_text("un processus disparu", encoding="utf-8")
    try:
        with ops.verrou_compteurs(ctx, qui="cli", delai=0):
            pass
    finally:
        verrou.unlink(missing_ok=True)


def test_le_verrou_ne_retire_que_le_sien():
    """Apres reprise d'un verrou perime, le sortant ne doit pas effacer le
    verrou du nouvel arrivant."""
    verrou = ctx.racine / "config" / ".compteurs.verrou"
    with ops.verrou_compteurs(ctx, qui="a"):
        verrou.write_text("quelqu'un d'autre", encoding="utf-8")
    assert verrou.exists(), "le verrou d'un autre a ete efface"
    verrou.unlink(missing_ok=True)


# ------------------------------------------------ la separation code/donnees
def test_le_code_ne_contient_aucune_donnee():
    """`prive/` ne doit jamais reapparaitre dans `logiciel/` : c'est toute la
    raison d'etre de la separation."""
    for interdit in ("config", "paies", "sorties", "retours", "gabarits",
                     "reference"):
        assert not (CODE / interdit).exists(), (
            "%s/ est dans le code : il appartient a prive/" % interdit)


def test_le_code_ne_porte_aucune_donnee_personnelle():
    """Le garde-fou du depot public, joue a chaque passage de tests.

    Le hook `pre-commit` fait le meme controle au moment de commiter, mais un
    hook s'installe et peut ne pas l'etre. Ce test-ci part avec le depot.
    """
    sys.path.insert(0, str(CODE / "outils"))
    import verifier_avant_commit as v
    trouvailles = v.verifier()
    detail = ["%s:%d %s -- %s" % (t["fichier"], t["ligne"], t["quoi"],
                                  t["extrait"]) for t in trouvailles[:10]]
    assert not trouvailles, "\n".join(detail)


def test_un_chemin_a_l_ancienne_est_toujours_compris():
    """`paies/2026-08.json` doit continuer de marcher : c'est ce qu'ecrivent
    les competences Claude, les lanceurs et cinq ans d'habitude."""
    assert resoudre("paies/2026-08.json", ctx.racine).exists()


def test_les_donnees_peuvent_vivre_ailleurs():
    """Une autre compagnie n'aura pas notre arborescence. Le contexte accepte
    une racine explicite -- c'est ce qui rend le logiciel reutilisable."""
    c = Contexte(RACINE)
    assert c.racine == RACINE
    assert c.entreprise["siret"]


# ----------------------------------------------------------------- execution
def _lancer():
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    echecs = 0
    for nom, fn in tests:
        try:
            with redirect_stdout(io.StringIO()):
                fn()
            print("  OK     %s" % nom)
        except AssertionError as e:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    print()
    print("Tous les tests passent." if not echecs
          else "%d test(s) en echec." % echecs)
    return 1 if echecs else 0


# ------------------------------------------------------------ les archives
# « Je ne les embaucherai plus, on devrait avoir une case archive : il reste
# dans la base mais pas dans le courant. » -- Leandre, 10/09/2026.
def test_une_fiche_sans_la_cle_est_active():
    """L'absence vaut actif : aucune fiche existante n'a a etre modifiee, et
    une compagnie qui ignore cet etat n'en subit rien."""
    from moteur.contexte import archivee
    assert archivee({}) is False
    assert archivee({"actif": True}) is False
    assert archivee({"actif": False}) is True


def test_une_archive_reste_en_base_mais_sort_du_courant():
    """Les deux moities de la notion, et c'est leur ecart qui la definit."""
    archives = [k for k, v in ctx.salaries.items() if v.get("actif") is False]
    assert archives, "ce test suppose au moins une fiche archivee"
    for cle in archives:
        assert cle in ctx.salaries          # la base la garde
        assert cle not in ctx.salaries_actifs   # le courant ne la propose plus


def test_le_nom_exact_retrouve_une_archive_mais_pas_l_a_peu_pres():
    """Une paie passee doit se rejouer -- donc le nom exact resout. Mais la
    recherche approchante ne doit PAS repecher une fiche mise de cote sur une
    faute de frappe : personne ne le verrait."""
    archive = next(k for k, v in ctx.salaries.items() if v.get("actif") is False)
    assert ctx.salarie(archive)["_cle"] == archive        # exact : oui

    approche = archive.lower().replace("-", "")[:6] + "x"  # une faute de frappe
    try:
        trouve = ctx.salarie(approche)
    except KeyError as e:
        assert "archive" in str(e).lower(), str(e)
    else:
        assert trouve["_cle"] != archive, (
            "une recherche approchante a repeche une fiche archivee : %r"
            % approche)


def test_un_spectacle_archive_se_resout_encore_par_son_numero_d_objet():
    """C'est ce que fait le rejeu : il lit un numero d'objet dans une DSN
    deposee. Archiver ne doit pas rendre l'historique illisible."""
    from moteur.contexte import archivee
    vieux = [v for v in ctx.spectacles.values()
             if archivee(v) and v.get("numero_objet")]
    if not vieux:
        return
    sp = vieux[0]
    assert ctx.spectacle(sp["numero_objet"])["numero_objet"] == sp["numero_objet"]


def test_moteur_fiche_ne_liste_pas_les_archives_mais_les_compte():
    """Une fiche qu'on ne voit plus passe pour perdue, et on la ressaisit --
    avec un deuxieme code salarie, ce qui serait pire que le silence."""
    courant = ops.fiche(ctx)
    tout = ops.fiche(ctx, archives=True)
    assert set(courant.salaries) < set(tout.salaries)
    assert courant.salaries_archives, "les archives doivent etre comptees"
    assert set(courant.salaries_archives) & set(tout.salaries)


def test_une_paie_sur_une_fiche_archivee_avertit_sans_bloquer():
    """On n'interdit pas : reimprimer un bulletin perdu, rejouer un mois, ce
    sont justement des fiches archivees. Mais une paie NEUVE sur une fiche
    mise de cote est presque toujours une erreur."""
    archive = next(k for k, v in ctx.salaries.items() if v.get("actif") is False)
    a = ops.apercu_mois(ctx, {
        "mois": "2026-11", "spectacle": "oooh teresina", "taux_cachet": 130.0,
        "date_paiement": "2026-11-30", "lieu": "",
        "engagements": [{"salarie": archive,
                         "lignes": [{"rubrique": "cachet", "quantite": 2, "taux": 130.0,
                                     "dates": ["2026-11-05", "2026-11-06"]}]}]})
    assert len(a.paies) == 1                     # la paie est bien calculee
    assert any("archive" in x.lower() for x in a.avertissements), a.avertissements


def test_une_case_a_cocher_arrivee_en_texte_redevient_un_booleen():
    """Le piege exact : « false » est une chaine VRAIE en Python. Sans cette
    conversion, une fiche archivee depuis l'interface serait restee dans les
    listes en paraissant archivee -- le pire des deux etats."""
    from moteur import champs
    from moteur.contexte import archivee

    assert archivee({"actif": "false"}) is False          # la faute, sans garde
    d = champs.coercer_booleens("salarie", {"actif": "false"})
    assert d["actif"] is False and archivee(d) is True
    assert champs.coercer_booleens("salarie", {"actif": "true"})["actif"] is True
    # Les autres champs ne bougent pas : on ne coerce que ce qui est declare
    # booleen.
    assert champs.coercer_booleens("salarie", {"nom": "false"})["nom"] == "false"


# ------------------------------------------------- dater ce qui est declare
def test_un_champ_declare_qui_change_est_signale_avant_d_ecrire():
    """`changements_declares` regarde, il n'ecrit rien -- et il derive d'abord.

    Le cas qui compte n'est pas celui qu'on tape : c'est celui que la machine
    fabrique. On ecrit « Montreuil » dans la forme lisible, le programme en
    tire `MONTREUIL`, et c'est CELA qui part aux organismes. Comparer avant
    de deriver laisserait passer exactement ce changement-la.
    """
    cle = next(iter(ctx.salaries))
    avant = dict(ctx.salaries[cle])
    saisie = {k: v for k, v in avant.items() if k != "commune"}
    saisie["commune_affichage"] = "Une Commune Qui N Existe Pas"

    ch = ops.changements_declares(ctx, "salarie", cle, saisie)
    assert [c["champ"] for c in ch] == ["commune"], ch
    assert ch[0]["apres"] == "UNE COMMUNE QUI N EXISTE PAS"
    assert ch[0]["avant"] == avant["commune"]
    # Il REGARDE : la fiche en memoire n'a pas bouge, le fichier non plus.
    assert ctx.salaries[cle]["commune"] == avant["commune"]
    assert "deja_declare" in ch[0]


def test_une_valeur_inchangee_ne_demande_rien():
    """Reenregistrer une fiche sans y toucher ne doit rien dater : sinon
    l'historique se remplirait de lignes qui ne racontent rien."""
    cle = next(iter(ctx.salaries))
    assert ops.changements_declares(ctx, "salarie", cle,
                                    dict(ctx.salaries[cle])) == []


def test_un_champ_non_declare_ne_se_date_pas():
    """Les initiales de contrat ne partent dans aucune declaration : les
    changer n'a rien a dater, et le demander serait du bruit. Le courriel, lui, part en
    DSN (S21.G00.30.018) : on l'a cru hors declaration jusqu'au 12/09/2026,
    ou son changement non date a fait diverger le rejeu de juillet."""
    cle = next(iter(ctx.salaries))
    saisie = dict(ctx.salaries[cle], initiales_contrat="ZZ")
    assert ops.changements_declares(ctx, "salarie", cle, saisie) == []
    saisie = dict(ctx.salaries[cle], email="autre@exemple.invalide")
    assert [c["champ"] for c in ops.changements_declares(ctx, "salarie", cle, saisie)] == ["email"]


def test_la_valeur_sortante_descend_dans_l_historique():
    """Enregistrer date l'ancienne valeur a la veille du jour d'effet.

    Sur une copie de la configuration : ce test ecrit, et il ne doit pas
    ecrire dans la vraie.
    """
    import shutil, tempfile, json as _json
    from moteur.contexte import Contexte, telle_qu_au
    racine = Path(tempfile.mkdtemp())
    shutil.copytree(ctx.racine / "config", racine / "config")
    bac = Contexte(racine)
    cle = next(iter(bac.salaries))
    avant = bac.salaries[cle]["commune"]

    saisie = {k: v for k, v in bac.salaries[cle].items() if k != "commune"}
    saisie["commune_affichage"] = "Ailleurs"
    ops.enregistrer_fiche(bac, "salarie", cle, saisie, forcer=True,
                          depuis="2026-09-15", note="demenagement")

    ecrit = _json.loads((racine / "config" / "salaries.json").read_text(
        encoding="utf-8"))[cle]
    assert ecrit["commune"] == "AILLEURS"
    ligne = next(e for e in ecrit["historique"] if e["champ"] == "commune")
    assert ligne["valeur"] == avant
    assert ligne["jusqu_au"] == "2026-09-14"       # la veille du jour d'effet
    assert ligne["note"] == "demenagement"
    # Et c'est relisible : la declaration du 14 porte encore l'ancienne.
    assert telle_qu_au(ecrit, "2026-09-14")["commune"] == avant
    assert telle_qu_au(ecrit, "2026-09-15")["commune"] == "AILLEURS"
    shutil.rmtree(racine, ignore_errors=True)


# ------------------------------------ 4. ce qu'un mois offre a deposer
def _bac():
    """Un dossier de donnees jetable, avec la vraie configuration recopiee.

    On ne construit pas un `Contexte` sur un dossier vide : il lit la fiche
    entreprise a l'ouverture, et un test qui l'esquiverait ne testerait plus
    le meme objet que celui dont l'interface se sert.
    """
    import shutil, tempfile
    racine = Path(tempfile.mkdtemp())
    shutil.copytree(ctx.racine / "config", racine / "config")
    return racine


def test_le_bon_fichier_a_deposer_est_le_dernier_ecrit():
    """Un mois porte souvent DEUX DSN, et la bonne n'est pas la premiere par
    ordre alphabetique.

    `DSN_Aout2026_AR.dsn` (l'annule-et-remplace) passe avant
    `DSN_Aout2026.dsn` dans un tri par nom, par le hasard du trait
    souligne -- et l'inverse le mois ou l'etiquette changera. Un ecran qui
    trierait dans son coin proposerait donc parfois de redeposer
    l'originale par-dessus son remplacement. La reponse vient du moteur, et
    elle est celle-ci : le dernier ECRIT.
    """
    import os, shutil
    racine = _bac()
    sortie = racine / "sorties" / "2026-08"
    sortie.mkdir(parents=True)
    original = sortie / "DSN_Aout2026.dsn"
    original.write_text("x", encoding="utf-8")
    remplacement = sortie / "DSN_Aout2026_AR.dsn"
    remplacement.write_text("x", encoding="utf-8")
    # On DATE, on n'attend pas : une seconde de sommeil dans un test est une
    # seconde payee a chaque lancement, et le systeme de fichiers peut ne pas
    # la distinguer de toute facon.
    os.utime(original, (1_700_000_000, 1_700_000_000))
    os.utime(remplacement, (1_700_003_600, 1_700_003_600))

    trouve = ops.fichiers_deposables(Contexte(racine), "2026-08")
    assert [f["nom"] for f in trouve["dsn"]] == ["DSN_Aout2026_AR.dsn",
                                                 "DSN_Aout2026.dsn"]
    shutil.rmtree(racine, ignore_errors=True)


def test_ni_l_archive_ni_le_recapitulatif_ne_se_deposent():
    """Le `.zip` est refuse au depot par `dpae_api`, et le recapitulatif n'est
    pas une declaration -- c'est la feuille qu'on recopie pour une saisie en
    ligne. Les proposer serait proposer d'envoyer ce qui sera rejete, ou ce
    qui ne declare rien."""
    import shutil
    racine = _bac()
    sortie = racine / "sorties" / "2026-08"
    sortie.mkdir(parents=True)
    for nom in ("DPAE_Aout2026.txt", "DPAE_Aout2026.txt.zip",
                "DPAE_Aout2026_recapitulatif.txt", "Bulletins_Aout2026.pdf"):
        (sortie / nom).write_text("x", encoding="utf-8")

    trouve = ops.fichiers_deposables(Contexte(racine), "2026-08")
    assert [f["nom"] for f in trouve["dpae"]] == ["DPAE_Aout2026.txt"]
    assert trouve["dsn"] == []
    shutil.rmtree(racine, ignore_errors=True)


def test_un_mois_sans_sorties_ne_plante_pas():
    """L'ecran demande l'etat d'un mois des qu'on l'ouvre, produit ou non."""
    import shutil
    racine = _bac()
    assert ops.fichiers_deposables(Contexte(racine), "2027-01") == {
        "dsn": [], "dpae": []}
    shutil.rmtree(racine, ignore_errors=True)


# ------------------------ 5. l'emploi appartient au contrat, pas a la fiche
def _saisie_type(**engagement):
    """Une saisie d'un cachet, sur laquelle on fait varier l'emploi."""
    cle = next(iter(ctx.salaries_actifs))
    spec = next(iter(ctx.spectacles_actifs))
    return {"mois": "2026-10", "date_paiement": "2026-10-31",
            "engagements": [dict(
                {"salarie": cle, "spectacle": spec,
                 "lignes": [{"rubrique": "cachet", "quantite": 1, "taux": 130,
                             "dates": ["2026-10-02"]}]},
                **engagement)]}


def test_un_statut_inconnu_est_refuse_en_nommant_ce_qui_manque():
    """LE TEST QUI COMPTE, et il garde un piege qui ne ressemblait pas a un
    piege.

    `statut` n'etait lu nulle part dans `calcul.py` : l'abattement de 30 %
    (arrete du 24/01/1975) est CUIT dans le bareme, pas applique comme un
    facteur qu'on pourrait retirer. Un engagement d'un autre statut ne se
    calculait donc pas faux -- il se calculait avec le MAUVAIS BAREME, en
    silence, et partait en DSN. Les nombres tombaient, ils etaient simplement
    ceux d'un autre metier.

    Regle 1 de CLAUDE.md : refuser plutot qu'inventer. Le technicien est
    verifie depuis le 13/09/2026 (voir test_allegements) ; le cadre, lui, n'a
    pas encore de section, et c'est lui qui porte ce test maintenant.
    """
    refus = None
    try:
        ops.charger(ctx, _saisie_type(statut="cadre"))
    except ValueError as e:
        refus = str(e)
    assert refus, "un engagement cadre a ete calcule avec le bareme artiste"
    # Le refus doit NOMMER ce qui manque, et dire ou l'ajouter.
    assert "cadre" in refus and "par_statut" in refus


def test_le_bilan_du_mois_dit_vert_quand_il_ne_reste_rien():
    """Une phrase et une couleur par acte, pour le mois entier : vert = plus
    rien a faire, orange = il reste quelque chose, rouge = un refus, rien =
    rien n'est parti. C'est ce que la colonne de droite affiche."""
    b = ops.bilan_du_mois(ctx, "2026-09")
    assert set(b) >= {"dpae", "contrat-signature", "documents", "dsn"}
    for v in b.values():
        assert v["couleur"] in ("", "bien", "alerte", "refus") and v["phrase"]
    # Un mois sans paie ne promet rien.
    vide = ops.bilan_du_mois(ctx, "2031-01")
    assert all(v["couleur"] == "" for v in vide.values())


def test_les_documents_ne_partent_qu_apres_la_dsn_et_l_aer():
    """<< Le bouton c'est envoyer, directement, il nous dit s'il peut >>
    (Leandre, 13/09/2026) : le moteur repond, et nomme ce qui manque --
    documents non ecrits, DSN non deposee ou pas passee, AER pas revenue.
    Sans compte Google, on peut produire, pas envoyer."""
    r = ops.documents_prets(ctx, "2031-01")
    assert not r["pret"]
    assert any("pas encore ecrits" in x for x in r["empechements"])
    assert any("DSN" in x for x in r["empechements"])
    assert isinstance(r["google_lie"], bool)
    # L'apercu d'envoi porte la reponse, et ne leve pas sans compte Google.
    a = ops.apercu_envoi(ctx, "2026-09")
    for cle in ("pret", "empechements", "google_lie", "produit", "dossier"):
        assert cle in a


def test_l_emploi_d_un_engagement_l_emporte_sur_la_fiche():
    """Un meme salarie n'exerce pas le meme metier d'un contrat a l'autre.

    Ce qui suit doit suivre : le PCS-ESE part en S21.G00.40.004, le code
    France Travail en .005, le libelle en .006. Tous les modules les lisent
    dans `paie.salarie` -- c'est pour ca que la substitution est faite une
    fois, dans `calcul.emploi_de`, et pas dans chacun d'eux.
    """
    p = ops.charger(ctx, _saisie_type(emploi="METTEUR EN SCENE",
                                      pcs_ese="353A")).paies[0]
    assert p.salarie["emploi"] == "METTEUR EN SCENE"
    assert p.salarie["pcs_ese"] == "353A"
    # Ce que l'engagement ne dit pas vient toujours de la fiche.
    cle = next(iter(ctx.salaries_actifs))
    assert p.salarie["code_emploi_ft"] == ctx.salaries[cle]["code_emploi_ft"]


def test_une_fiche_sans_emploi_d_engagement_ne_bouge_pas():
    """Le cas general, et celui qui fait que tout l'historique se rejoue."""
    cle = next(iter(ctx.salaries_actifs))
    p = ops.charger(ctx, _saisie_type()).paies[0]
    for champ in ("emploi", "pcs_ese", "code_emploi_ft", "statut"):
        assert p.salarie[champ] == ctx.salaries[cle][champ]


# --------------------------------- 6. la DPAE d'une partie du mois seulement
def test_une_dpae_partielle_ne_touche_pas_au_fichier_complet():
    """<< Si quelqu'un nous demande un spectacle le 10 pour le 25, on va faire
    la DPAE avant le 25 meme si on a deja fait pour le 3 et 4 du mois. Mais
    pas refaire toutes les DPAE du mois. >>

    Le complet reste relisible tel qu'il a ete depose : une declaration deja
    partie ne se regenere pas (regle 4 de CLAUDE.md).
    """
    import shutil
    from moteur import dpae as _dpae
    racine = _bac()
    shutil.copytree(ctx.racine / "paies", racine / "paies")
    bac = Contexte(racine)

    complet = ops.produire_dpae(bac, "paies/2026-08.json")
    combien = len(_dpae.relire(complet.fichiers[0]))
    assert combien > 1, "ce test n'a de sens que sur un mois a plusieurs embauches"

    une = next(iter(ops.etat_par_paie(bac, "2026-08")))
    partiel = ops.produire_dpae(
        bac, "paies/2026-08.json",
        paies=[{"salarie": une["salarie"], "debut": une["debut"]}])

    assert partiel.fichiers[0] != complet.fichiers[0], \
        "le fichier partiel doit s'ecrire A COTE du complet, jamais dessus"
    assert len(_dpae.relire(partiel.fichiers[0])) == 1
    assert len(_dpae.relire(complet.fichiers[0])) == combien, \
        "le fichier complet a ete reecrit"
    # Et il reste deposable : c'est `fichiers_deposables` qui le dira, le plus
    # recent en tete.
    noms = [f["nom"] for f in ops.fichiers_deposables(bac, "2026-08")["dpae"]]
    assert noms[0] == partiel.fichiers[0].name
    assert complet.fichiers[0].name in noms
    shutil.rmtree(racine, ignore_errors=True)


def test_une_embauche_introuvable_n_ecrit_rien():
    """Produire << ce qu'on a compris >> d'une selection est pire que refuser :
    la case cochee qu'on n'a pas trouvee manquerait en silence."""
    import shutil
    racine = _bac()
    shutil.copytree(ctx.racine / "paies", racine / "paies")
    bac = Contexte(racine)
    refus = None
    try:
        ops.produire_dpae(bac, "paies/2026-08.json",
                          paies=[{"salarie": "PERSONNE", "debut": "2026-08-23"}])
    except ops.ErreurOperation as e:
        refus = str(e)
    assert refus and "PERSONNE" in refus
    assert not (racine / "sorties").exists() or not list(
        (racine / "sorties" / "2026-08").glob("DPAE_*")), "un refus a ecrit"
    shutil.rmtree(racine, ignore_errors=True)


# ----------------------------- 7. l'etat par paie dit a quelle maille il sait
def test_l_etat_par_paie_dit_a_quelle_maille_chaque_acte_est_connu():
    """Les quatre actes ne se declarent pas au meme grain, et l'ecran doit le
    dire. Une DSN est mensuelle par nature : afficher << deposee >> sur une
    paie sans preciser qu'on parle du mois promettrait une precision que le
    journal n'a pas."""
    lignes = ops.etat_par_paie(ctx, "2026-08")
    assert lignes, "aout doit porter des paies"
    mailles = {k: v["maille"] for k, v in lignes[0]["etats"].items()}
    assert mailles == {"dpae": "paie", "signature": "paie",
                       "documents": "salarie", "dsn": "mois"}


# ------------------- 8. le classement conventionnel suit l'emploi, pas le code
def test_le_statut_conventionnel_n_est_plus_ecrit_en_dur():
    """S21.G00.40.002 valait `05` quoi qu'il arrive.

    C'est juste pour un artiste -- << 05 profession intermediaire >> -- et
    faux pour tout le reste. Les 151 DSN de l'export CoolPaie le disent : 05
    sur les 146 contrats d'artistes, 07 (ouvrier) sur le charge de
    production, 04 (cadre) sur la metteuse en scene, qui porte alors 003=01.
    """
    source = (CODE / "moteur" / "dsn.py").read_text(encoding="utf-8")
    for en_dur in ('"S21.G00.40.002", "0', '"S21.G00.40.003", "0'):
        assert en_dur not in source, (
            "dsn.py ecrit encore %s en dur : un contrat non artistique serait "
            "declare dans la mauvaise categorie" % en_dur)


def test_le_classement_d_un_engagement_descend_dans_la_paie():
    """Ce que l'engagement dit du classement doit arriver jusqu'a `p.salarie`,
    parce que c'est la que `dsn._bloc_contrat` le lit."""
    p = ops.charger(ctx, _saisie_type(statut_conventionnel="07",
                                      statut_categoriel_rc="04")).paies[0]
    assert p.salarie["statut_conventionnel"] == "07"
    assert p.salarie["statut_categoriel_rc"] == "04"


def test_le_defaut_du_classement_est_celui_de_l_historique():
    """Un defaut n'est pas une valeur choisie : c'est ce qui est DEJA declare.

    Ces deux champs sont neufs dans les fiches, et pourtant ils partent en DSN
    depuis toujours. Poser autre chose que 05/04 changerait ce qui est envoye
    aux organismes sans que personne ne l'ait demande.
    """
    from moteur import champs
    assert champs.defaut("salarie", "statut_conventionnel") == "05"
    assert champs.defaut("salarie", "statut_categoriel_rc") == "04"
    # Et une fiche qui ne les porte pas les montre quand meme a l'ecran :
    # une case vide ferait croire que rien n'est declare.
    cle = next(iter(ctx.salaries_actifs))
    comblee = champs.combler_affichage("salarie", ctx.salaries[cle])
    assert comblee["statut_conventionnel"] == "05"


# ------------------------------------ 5. la reprise du journal des depots
#
# Tous ces tests ecrivent, et aucun n'ecrit dans le vrai journal : ils posent
# des rapports fabriques dans un bac jetable. Un test de reprise qui toucherait
# `prive/journal/depots.json` serait un test qui fabrique de fausses traces de
# depot -- exactement ce contre quoi la reprise se garde.

_AEE = """<?xml version="1.0" encoding="UTF-8"?>
<gipmds:rapport xmlns:gipmds="http://www.gip-mds.fr/" type="AEE" profil="DSN">
  <envoi><envoi_identification>
    <idflux>%(flux)s</idflux>
    <essai_reel>%(essai)s</essai_reel>
    <date_reception>2026-09-03</date_reception>
    <heure_reception>10:04:42</heure_reception>
  </envoi_identification>
  <envoi_bilan><envoi_etat>%(envoi)s</envoi_etat></envoi_bilan></envoi>
</gipmds:rapport>"""

_BILAN = """<?xml version="1.0" encoding="UTF-8"?>
<gipmds:rapport xmlns:gipmds="http://www.gip-mds.fr/" type="%(rapport)s" profil="DSN">
  <envoi><envoi_identification>
    <idflux>%(flux)s</idflux>
    <essai_reel>%(essai)s</essai_reel>
    <nom_logiciel>%(logiciel)s</nom_logiciel>
    <date_reception>2026-09-03</date_reception>
    <heure_reception>10:04:44</heure_reception>
  </envoi_identification>
  <envoi_bilan><envoi_etat>%(envoi)s</envoi_etat></envoi_bilan></envoi>
  <declaration><declaration_identification>
    <mois>01082026</mois><type>01</type><fraction>11</fraction><ordre>1</ordre>
  </declaration_identification>
  <declaration_bilan><etat>%(decl)s</etat>
    <declaration_contenu><salaries>2</salaries><contrats>6</contrats></declaration_contenu>
    <niveau_conformite><etat_conformite>%(decl)s</etat_conformite>
      <certificat_conformite>CERTIF-%(flux)s</certificat_conformite>
    </niveau_conformite>
  </declaration_bilan></declaration>
</gipmds:rapport>"""


def _poser_retour(racine, nom, contenu):
    d = racine / "retours"
    d.mkdir(parents=True, exist_ok=True)
    (d / nom).write_text(contenu, encoding="utf-8")


def test_un_accuse_ok_suivi_d_un_bilan_ko_ne_compte_pas_comme_depose():
    """LE TEST CENTRAL DE LA REPRISE, et il vient d'un vrai piege.

    `envoi_etat` vaut OK des que le fichier est ARRIVE lisible ; le bilan qui
    suit peut rejeter la declaration deux secondes plus tard. Trois des huit
    depots reels de la compagnie sont dans ce cas. Une reprise qui croirait
    l'accuse noterait trois declarations faites qui n'existent pas -- et
    c'est sur ces lignes-la que quelqu'un se fierait pour ne pas recommencer.
    """
    import shutil
    racine = _bac()
    _poser_retour(racine, "20260903-100442_nature10_FLUXKO.xml",
                  _AEE % {"flux": "FLUXKO", "essai": "02", "envoi": "OK"})
    _poser_retour(racine, "20260903-100444_nature11_FLUXKO.xml",
                  _BILAN % {"flux": "FLUXKO", "essai": "02", "envoi": "OK",
                            "decl": "KO", "rapport": "BAN",
                            "logiciel": "PUPPETPAIE"})
    bac = Contexte(racine)
    r = ops.reconstruire_journal(bac, ecrire=True, qui="test")
    assert len(r["ajoutes"]) == 1
    from moteur import journal
    ligne = journal.lire(bac, journal.DSN)[0]
    assert ligne["accepte"] is False, "un bilan KO ne se note pas comme fait"
    # Et la consequence qui compte : le mois ne se lit pas comme declare.
    assert journal.etat_du_mois(bac, "2026-08")[journal.DSN] is None
    shutil.rmtree(racine, ignore_errors=True)


def test_la_reprise_lit_le_logiciel_declarant_au_lieu_de_l_annoter():
    """« On l'a deja envoye » -- oui, mais par quoi ?

    Le certificat de conformite porte `nom_logiciel`. C'est ce qui distingue
    un depot CoolPaie d'un depot PuppetPaie sans que personne n'ait a s'en
    souvenir, et sans annotation a la main qui serait fausse un jour.
    """
    import shutil
    racine = _bac()
    _poser_retour(racine, "20260903-100444_nature11_FLUXCP.xml",
                  _BILAN % {"flux": "FLUXCP", "essai": "02", "envoi": "OK",
                            "decl": "OK", "rapport": "CCO",
                            "logiciel": "COOLPAIE"})
    bac = Contexte(racine)
    ops.reconstruire_journal(bac, ecrire=True, qui="test")
    from moteur import journal
    ligne = journal.lire(bac, journal.DSN)[0]
    assert ligne["detail"]["logiciel"] == "COOLPAIE"
    assert ligne["detail"]["reconstruit"] is True
    # La date est celle du DEPOT, pas celle de la reprise.
    assert ligne["quand"].startswith("2026-09-03")
    # Et elle dit d'ou elle vient.
    assert "20260903-100444_nature11_FLUXCP.xml" in ligne["origine"]
    shutil.rmtree(racine, ignore_errors=True)


def test_la_reprise_ne_dit_rien_avant_qu_on_le_demande():
    """`ecrire=False` est le defaut. Une reprise qui part au premier appel
    est une reprise qu'on lance << pour voir >> et qui laisse des lignes que
    personne n'a relues."""
    import shutil
    racine = _bac()
    _poser_retour(racine, "20260903-100444_nature11_FLUXA.xml",
                  _BILAN % {"flux": "FLUXA", "essai": "02", "envoi": "OK",
                            "decl": "OK", "rapport": "CCO",
                            "logiciel": "PUPPETPAIE"})
    bac = Contexte(racine)
    r = ops.reconstruire_journal(bac)
    assert r["ajoutes"] and r["ecrit"] is False
    from moteur import journal
    assert not journal.chemin(bac).exists(), "rien ne devait etre ecrit"
    shutil.rmtree(racine, ignore_errors=True)


def test_la_reprise_relancee_n_ajoute_rien():
    """Idempotente par le flux. On la relance apres chaque releve de retours,
    et elle ne doit pas empiler des doublons -- deux lignes pour un depot
    feraient croire a deux depots."""
    import shutil
    racine = _bac()
    _poser_retour(racine, "20260903-100444_nature11_FLUXB.xml",
                  _BILAN % {"flux": "FLUXB", "essai": "02", "envoi": "OK",
                            "decl": "OK", "rapport": "CCO",
                            "logiciel": "PUPPETPAIE"})
    bac = Contexte(racine)
    ops.reconstruire_journal(bac, ecrire=True, qui="test")
    r2 = ops.reconstruire_journal(bac, ecrire=True, qui="test")
    assert r2["ajoutes"] == [] and len(r2["deja"]) == 1
    from moteur import journal
    assert len(journal.lire(bac, journal.DSN)) == 1
    shutil.rmtree(racine, ignore_errors=True)


def test_un_retour_qui_ne_parle_pas_d_un_depot_ne_fonde_pas_une_ligne():
    """`retours/` melange tout : CRM metier, retours France Travail, taux de
    PAS. Ce sont aussi des `rapport` et ils portent le meme `idflux`. Les
    prendre fabriquerait une ligne sans date et sans mois, a partir d'un
    fichier qui ne parle pas du depot."""
    import shutil
    racine = _bac()
    _poser_retour(racine, "20260819-234913_nature94_FLUXC.xml",
                  '<?xml version="1.0"?><rapport type="CRM nominatif">'
                  '<envoi><idflux>FLUXC</idflux></envoi></rapport>')
    bac = Contexte(racine)
    r = ops.reconstruire_journal(bac, ecrire=True, qui="test")
    assert r["trouves"] == []
    shutil.rmtree(racine, ignore_errors=True)


def test_une_ligne_datee_sans_origine_est_refusee():
    """Pouvoir dater une ligne, c'est pouvoir en fabriquer une fausse. Le
    garde-fou est qu'une date choisie EXIGE de dire d'ou elle vient."""
    import shutil
    racine = _bac()
    bac = Contexte(racine)
    from moteur import journal
    refuse = False
    try:
        journal.noter(bac, journal.DPAE, mois="2026-08",
                      quand="2026-08-28T09:00:00")
    except ValueError:
        refuse = True
    assert refuse, "une ligne datee sans origine doit etre refusee"
    shutil.rmtree(racine, ignore_errors=True)


def test_reprendre_une_dpae_sans_dire_lesquelles_est_refuse():
    """Une DPAE ne rend aucun accuse comparable a celui de la DSN : sa reprise
    est forcement manuelle. Mais une ligne qui ne nomme pas les embauches ne
    retirerait rien de la liste des embauches sans trace -- donc elle ne
    servirait qu'a faire croire que c'est regle."""
    import shutil
    racine = _bac()
    bac = Contexte(racine)
    from moteur import journal
    refuse = False
    try:
        ops.reprendre_depot(bac, journal.DPAE, mois="2026-08",
                            quand="2026-08-28", note="deposee par CoolPaie")
    except ops.ErreurOperation:
        refuse = True
    assert refuse
    # Avec les embauches, elle passe -- et elle retire bien la trace.
    ops.reprendre_depot(bac, journal.DPAE, mois="2026-08", quand="2026-08-28",
                        note="deposee par CoolPaie le 28/08",
                        embauches=[{"salarie": "X", "debut": "2026-08-23"}])
    assert ("X", "2026-08-23") in journal.embauches_declarees(bac)
    shutil.rmtree(racine, ignore_errors=True)


def test_une_reprise_sans_note_est_refusee():
    """Sans la phrase qui dit par quel chemin ca s'est fait, la ligne se lira
    comme un depot de PuppetPaie."""
    import shutil
    racine = _bac()
    bac = Contexte(racine)
    from moteur import journal
    refuse = False
    try:
        ops.reprendre_depot(bac, journal.DPAE, mois="2026-08",
                            quand="2026-08-28", note="   ",
                            embauches=[{"salarie": "X", "debut": "2026-08-23"}])
    except ops.ErreurOperation:
        refuse = True
    assert refuse
    shutil.rmtree(racine, ignore_errors=True)


def test_la_reprise_dpae_lit_les_embauches_dans_le_certificat():
    """Le retour 41 de l'Urssaf porte les DECLARATIONS elles-memes.

    C'est ce qui rend la reprise DPAE meilleure que celle de la DSN : on n'y
    lit pas seulement << un depot a eu lieu >> mais QUI est declare et A
    PARTIR DE QUAND -- la maille exacte dont la liste des embauches sans
    trace a besoin. Lue, pas saisie a la main.

    Le rattachement se fait par le NIR, jamais par le nom : une orthographe,
    un accent, un nom d'usage, et on declarerait quelqu'un d'autre.
    """
    import shutil
    from moteur import dpae
    racine = _bac()
    bac = Contexte(racine)
    cle = next(iter(bac.salaries_actifs))
    nir = bac.salaries[cle]["nir"]

    # Un enregistrement a plat de 990 caracteres, comme en produit le SI DPAE.
    rec = [" "] * 990
    def poser(champ, valeur):
        a, z = dpae.CHAMPS[champ]
        rec[a:z] = list(valeur.ljust(z - a)[:z - a])
    poser("horodatage", "28082026151300")
    poser("nir", nir)
    poser("date_embauche", "17082026")
    poser("heure_embauche", "0800")
    (racine / "retours" / "dpae").mkdir(parents=True, exist_ok=True)
    (racine / "retours" / "dpae" / "20260828-152442_nature41_FLUXDP.txt"
     ).write_bytes("".join(rec).encode("latin-1"))

    r = ops.reconstruire_journal_dpae(bac, ecrire=True, qui="test")
    assert len(r["ajoutes"]) == 1 and not r["inconnus"]
    from moteur import journal
    assert (cle, "2026-08-17") in journal.embauches_declarees(bac)
    ligne = journal.lire(bac, journal.DPAE)[0]
    # La date est celle du DEPOT, lue dans l'horodatage de l'enregistrement.
    assert ligne["quand"].startswith("2026-08-28T15:13")
    assert "nature41" in ligne["origine"]
    shutil.rmtree(racine, ignore_errors=True)


def test_un_nir_inconnu_n_est_pas_rattache_au_hasard():
    """Un NIR qu'on ne reconnait pas peut etre une fiche archivee sous une
    autre cle, ou une declaration faite pour quelqu'un d'autre. Dans les deux
    cas, inventer un rattachement serait pire que de le dire : la ligne
    retirerait de la liste une embauche qui n'a rien a y voir."""
    import shutil
    from moteur import dpae
    racine = _bac()
    bac = Contexte(racine)
    rec = [" "] * 990
    def poser(champ, valeur):
        a, z = dpae.CHAMPS[champ]
        rec[a:z] = list(valeur.ljust(z - a)[:z - a])
    poser("horodatage", "28082026151300")
    poser("nir", "1234567890123")          # personne
    poser("date_embauche", "17082026")
    (racine / "retours" / "dpae").mkdir(parents=True, exist_ok=True)
    (racine / "retours" / "dpae" / "20260828-152442_nature41_FLUXNC.txt"
     ).write_bytes("".join(rec).encode("latin-1"))

    r = ops.reconstruire_journal_dpae(bac, ecrire=True, qui="test")
    assert r["ajoutes"] == []
    assert r["inconnus"] and "1234567890123" in r["inconnus"][0]
    from moteur import journal
    assert not journal.lire(bac, journal.DPAE)
    shutil.rmtree(racine, ignore_errors=True)


def test_les_retours_dpae_ne_se_melent_pas_a_ceux_de_la_dsn():
    """Les natures se RESSEMBLENT d'un canal a l'autre : la DPAE a elle aussi
    une nature 10 et une nature 11, qui ne veulent pas dire la meme chose.

    Archives dans le meme dossier, un certificat de conformite de DPAE se
    lirait comme un bilan de DSN, et la reprise fabriquerait une ligne de DSN
    a partir d'une declaration d'embauche. D'ou `retours/dpae/`, a part -- et
    ce test, qui verifie que la reprise DSN ne descend pas dedans.
    """
    import shutil
    racine = _bac()
    bac = Contexte(racine)
    (racine / "retours" / "dpae").mkdir(parents=True, exist_ok=True)
    (racine / "retours" / "dpae" / "20260904-223612_nature11_FLUXDPAE.xml"
     ).write_text(_BILAN % {"flux": "FLUXDPAE", "essai": "02", "envoi": "OK",
                            "decl": "OK", "rapport": "CCO",
                            "logiciel": "COOLPAIE"}, encoding="utf-8")
    attestes, _ = ops.depots_attestes(bac)
    assert attestes == [], "la reprise DSN a lu un retour DPAE"
    shutil.rmtree(racine, ignore_errors=True)


def test_une_paie_validee_ferme_son_edition_et_se_rouvre():
    """« On valide, c'est vert, normalement on n'y revient pas, édition
    bloquée temporairement avec un bouton pour modifier avec avertissement. »

    Le drapeau vit dans le fichier de saisie, a cote de l'engagement, et
    NE CONSOMME AUCUN COMPTEUR -- valider n'est pas produire.
    """
    import shutil, json as _json
    racine = _bac()
    bac = Contexte(racine)
    cle = next(iter(bac.salaries_actifs))
    spec = next(iter(bac.spectacles))
    (racine / "paies").mkdir(parents=True, exist_ok=True)
    (racine / "paies" / "2026-09.json").write_text(_json.dumps({
        "mois": "2026-09", "taux_cachet": 130.0, "date_paiement": "2026-09-30",
        "engagements": [{"salarie": cle, "spectacle": spec,
                         "lignes": [{"rubrique": "cachet", "quantite": 1, "taux": 130.0,
                                     "dates": ["2026-09-06"]}]}]}), encoding="utf-8")

    avant = bac.compteurs()
    r = ops.valider_paie(bac, "2026-09", cle, "2026-09-06")
    assert r["valide"], "la paie devait etre validee"
    ecrit = _json.loads((racine / "paies" / "2026-09.json").read_text(
        encoding="utf-8"))
    assert ecrit["engagements"][0]["valide"] == r["valide"]
    assert ops.paies_validees(bac, "2026-09")[(cle, "2026-09-06")]
    # Et l'ecran le lit a cote des quatre actes, jamais dedans.
    ligne = ops.etat_par_paie(bac, "2026-09")[0]
    assert ligne["valide"] == r["valide"]
    assert "valide" not in ligne["etats"]

    # Rouvrir efface le drapeau et ne laisse rien derriere.
    ops.valider_paie(bac, "2026-09", cle, "2026-09-06", valide=False)
    ecrit = _json.loads((racine / "paies" / "2026-09.json").read_text(
        encoding="utf-8"))
    assert "valide" not in ecrit["engagements"][0]
    assert Contexte(racine).compteurs() == avant, (
        "valider ne doit consommer aucun compteur")
    shutil.rmtree(racine, ignore_errors=True)


def test_enregistrer_garde_ce_que_l_ecran_ne_montre_pas():
    """L'enregistrement automatique ne doit rien effacer par inadvertance.

    Depuis le 12/09/2026 l'interface enregistre une seconde apres la frappe,
    sans qu'on clique. Elle renvoie ce qu'elle affiche -- et elle n'affiche ni
    la phrase `_origine` en tete du fichier, ni la validation des paies. Sans
    fusion, ouvrir un mois et effleurer un champ effacerait les deux.
    """
    import shutil, json as _json
    racine = _bac()
    bac = Contexte(racine)
    cle = next(iter(bac.salaries_actifs))
    spec = next(iter(bac.spectacles))
    (racine / "paies").mkdir(parents=True, exist_ok=True)
    (racine / "paies" / "2026-09.json").write_text(_json.dumps({
        "_origine": "Une phrase ecrite a la main, que l'interface ignore.",
        "mois": "2026-09", "taux_cachet": 130.0, "date_paiement": "2026-09-30",
        "engagements": [{"salarie": cle, "spectacle": spec,
                         "lignes": [{"rubrique": "cachet", "quantite": 1, "taux": 130.0,
                                     "dates": ["2026-09-06"]}]}]}), encoding="utf-8")
    ops.valider_paie(bac, "2026-09", cle, "2026-09-06")

    # Ce que l'interface renvoie : le meme mois, un taux change, et rien
    # d'autre. Ni `_origine`, ni `valide` -- elle ne les connait pas.
    ops.enregistrer_saisie(bac, "2026-09", {
        "mois": "2026-09", "taux_cachet": 140.0, "date_paiement": "2026-09-30",
        "engagements": [{"salarie": cle, "spectacle": spec,
                         "lignes": [{"rubrique": "cachet", "quantite": 1, "taux": 130.0,
                                     "dates": ["2026-09-06"]}]}]})
    ecrit = _json.loads((racine / "paies" / "2026-09.json").read_text(
        encoding="utf-8"))
    assert ecrit["taux_cachet"] == 140.0, "la modification n'a pas ete ecrite"
    assert ecrit["_origine"].startswith("Une phrase"), "_origine a ete effacee"
    assert ecrit["engagements"][0].get("valide"), "la validation a ete effacee"

    # Et rouvrir une paie reste un retrait : la fusion ne la ressuscite pas.
    ops.valider_paie(bac, "2026-09", cle, "2026-09-06", valide=False)
    ops.enregistrer_saisie(bac, "2026-09", {
        "mois": "2026-09", "taux_cachet": 140.0, "date_paiement": "2026-09-30",
        "engagements": [{"salarie": cle, "spectacle": spec,
                         "lignes": [{"rubrique": "cachet", "quantite": 1, "taux": 130.0,
                                     "dates": ["2026-09-06"]}]}]})
    ecrit = _json.loads((racine / "paies" / "2026-09.json").read_text(
        encoding="utf-8"))
    assert "valide" not in ecrit["engagements"][0], (
        "une paie rouverte s'est revalidee toute seule")
    shutil.rmtree(racine, ignore_errors=True)


def test_une_ligne_de_paie_porte_ses_jours_et_son_lieu():
    """« 1 cachet a 130 EUR au Theatre de la Ville le 12, 4 cachets a 130 EUR
    au Theatre 71 le 14, 15, 17, 18 » (Leandre, 12/09/2026).

    C'est UNE paie : un contrat, un bulletin, une AEM, cinq cachets. Les jours
    de l'engagement sont la reunion de ceux de ses lignes.
    """
    import shutil
    racine = _bac()
    bac = Contexte(racine)
    cle = next(iter(bac.salaries_actifs))
    spec = next(iter(bac.spectacles))
    saisie = {
        "mois": "2026-09", "date_paiement": "2026-09-30",
        "engagements": [{"salarie": cle, "spectacle": spec, "lignes": [
            {"rubrique": "cachet", "quantite": 1, "taux": 130,
             "lieu": "Theatre de la Ville", "dates": ["2026-09-12"]},
            {"rubrique": "cachet", "quantite": 4, "taux": 130,
             "lieu": "Theatre 71",
             "dates": ["2026-09-14", "2026-09-15", "2026-09-17",
                       "2026-09-18"]}]}]}
    s = ops.charger(bac, saisie)
    e = s.paies[0].engagement
    assert [str(x) for x in e.dates_travail] == [
        "2026-09-12", "2026-09-14", "2026-09-15", "2026-09-17", "2026-09-18"]
    assert e.cachets == 5 and e.jours == 5
    assert str(e.debut) == "2026-09-12" and str(e.fin) == "2026-09-18"
    assert e.lieu_de("2026-09-12") == "Theatre de la Ville"
    assert e.lieu_de("2026-09-15") == "Theatre 71"

    # Un engagement qui ne dit aucun jour est refuse AVEC SON RANG : une
    # IndexError sur `dates_travail[0]` n'aurait designe personne.
    refuse = ""
    try:
        ops.charger(bac, {"mois": "2026-09", "engagements": [
            {"salarie": cle, "spectacle": spec,
             "lignes": [{"rubrique": "cachet", "quantite": 1, "taux": 130}]}]})
    except ops.ErreurOperation as x:
        refuse = str(x)
    assert "aucun jour" in refuse, refuse
    shutil.rmtree(racine, ignore_errors=True)


def test_valider_une_paie_non_enregistree_est_refuse():
    """Une pastille verte sur un formulaire qu'un rechargement de page
    effacerait serait la pire des promesses."""
    import shutil
    racine = _bac()
    bac = Contexte(racine)
    refuse = False
    try:
        ops.valider_paie(bac, "2026-09", "QUICONQUE", "2026-09-06")
    except ops.ErreurOperation:
        refuse = True
    assert refuse
    shutil.rmtree(racine, ignore_errors=True)


# ------------------------------------- les deux fautes du 13/09/2026 au soir
# Toutes deux venaient du meme malentendu : ce que l'ECRAN renvoie n'est pas
# la fiche. Il lui manque les champs calcules (ils ne se saisissent pas) et
# les notes internes (`sortie_json.brut` les retire de tout ce qui part vers
# un front). Le moteur doit rendre l'un et l'autre avant de juger.

def test_verifier_une_fiche_derive_avant_de_juger():
    """L'ecran n'envoie ni `adresse`, ni `commune`, ni `raison_sociale` : ils
    se deduisent. Les voir vides et crier << obligatoire >> mettait en rouge
    trois champs correctement remplis."""
    from moteur import champs
    d = dict(Contexte().entreprise)
    calcules = {c.cle for c in champs.FICHES["entreprise"] if c.calcule}
    assert calcules, "la fiche entreprise a bien des champs calcules"
    envoye = {k: v for k, v in d.items() if k not in calcules}
    erreurs = [a for a in ops.verifier_fiche("entreprise", envoye)
               if a["gravite"] == "erreur"]
    assert not erreurs, erreurs


def test_enregistrer_depuis_l_ecran_ne_rabote_pas_les_notes_internes():
    """`_note` est de la documentation ecrite a la main dans le JSON. L'API
    ne la montre pas ; l'interface renvoie donc la structure sans elle, et
    l'enregistrement l'effacait -- en annoncant en prime deux << valeurs
    declarees qui changent >> alors que rien de declare n'avait bouge."""
    ancienne = {"banque": {"bic": "X", "iban": "Y", "_note": "a garder"},
                "liste": [{"a": 1, "_pourquoi": "b"}]}
    #  ce que l'ecran a recu (js.brut retire les cles internes), puis renvoie
    from moteur import sortie_json as js
    renvoye = js.brut(ancienne)
    assert "_note" not in renvoye["banque"], "js.brut retire bien les notes"
    rendu = ops.garder_notes_internes(ancienne, renvoye)
    assert rendu["banque"] == ancienne["banque"]
    assert rendu["liste"] == ancienne["liste"]
    # une liste de longueur differente ne se recolle pas : rattacher une note
    # au mauvais element serait pire que la perdre
    court = ops.garder_notes_internes(ancienne, {"liste": []})
    assert court["liste"] == []


def test_un_enregistrement_qui_ne_change_rien_n_annonce_rien():
    """Le symptome vu a l'ecran : rouvrir la fiche, changer un champ non
    declare, et se voir demander de dater deux structures intactes."""
    from moteur import champs, sortie_json as js
    c = Contexte()
    d = dict(c.entreprise)
    form = {}
    for champ in champs.FICHES["entreprise"]:
        if champ.calcule:
            continue
        v = d.get(champ.cle)
        if champ.forme == "structure" or isinstance(v, (dict, list)):
            form[champ.cle] = js.brut(v)          # tel que l'ecran l'a recu
        elif champ.forme == "booleen":
            form[champ.cle] = v is not False
        else:
            form[champ.cle] = "" if v is None else str(v)
    assert ops.changements_declares(c, "entreprise", None, form) == []


if __name__ == "__main__":
    sys.exit(_lancer())
