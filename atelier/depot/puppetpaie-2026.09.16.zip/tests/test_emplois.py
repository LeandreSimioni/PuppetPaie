"""Le catalogue des metiers, les minima conventionnels et les sources.

Trois choses que ces tests verrouillent :

  1. Le catalogue est COHERENT avec ses sources : chaque code existe dans la
     nomenclature France Travail, son statut suit l'annexe du code, son PCS
     existe dans la liste Insee, et chaque cle de minima pointe une grille.
     Un catalogue qu'on edite a la main derive vite ; le test le rattache.
  2. Un engagement qui dit `metier` declare ce que le catalogue dit -- et ce
     qu'il ecrit lui-meme l'emporte. C'est la meme resolution pour la fiche
     salarie (route `emploi`) et pour l'engagement : une regle, un endroit.
  3. Un cachet sous le minimum conventionnel produit un AVERTISSEMENT, jamais
     un refus ; au-dessus, rien. Et le message dit quelle grille il a lue.

Aucune donnee reelle : les paies sont fabriquees, sur une copie jetable de la
configuration.
"""
import io
import json
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import emplois, minima, operations as ops, sources   # noqa: E402
from moteur.contexte import Contexte                             # noqa: E402

ctx = Contexte()


def _bac(**entreprise):
    racine = Path(tempfile.mkdtemp())
    shutil.copytree(ctx.racine / "config", racine / "config")
    if entreprise:
        p = racine / "config" / "entreprise.json"
        d = json.loads(p.read_text(encoding="utf-8"))
        d.update(entreprise)
        p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    return racine


def _saisie(cle, spec, lignes, **eng):
    e = dict(salarie=cle, spectacle=spec, lignes=lignes)
    e.update(eng)
    return {"mois": "2026-09", "engagements": [e]}


def _un_salarie(c):
    cle = sorted(c.salaries_actifs)[0]
    spec = sorted(c.spectacles_actifs)[0]
    return cle, spec


# ------------------------------------------------------- 1. le catalogue
def test_chaque_metier_du_catalogue_existe_dans_la_nomenclature():
    nomen = emplois.nomenclature()
    for code, m in emplois.base().items():
        assert code in nomen, "code %s absent de la nomenclature France Travail" % code
        assert m["emploi"] == nomen[code]["libelle"], code
        assert m["annexe"] == nomen[code]["annexe"], code


def test_le_statut_suit_l_annexe_du_code():
    """Annexe 10 = artiste (taux abattus), annexe 8 = technicien. Un metier
    qui dirait autre chose ferait calculer le mauvais bareme."""
    for code, m in emplois.base().items():
        attendu = "artiste" if m["annexe"] == 10 else "technicien"
        assert m["statut"] == attendu, (code, m["statut"], m["annexe"])


def test_chaque_pcs_du_catalogue_existe_chez_l_insee():
    """La liste Insee est dans reference/sources/ (hors depot) ; sans elle on
    verifie au moins la forme et le perimetre des rubriques du spectacle."""
    valides = {"353b", "353c", "354a", "354b", "354c", "354e", "354f", "465b", "637c"}
    xls = sources.dossier(ctx) / "insee-pcs-ese-2017-liste.xls"
    if xls.exists():
        try:
            import xlrd
            feuille = xlrd.open_workbook(str(xls)).sheets()[0]
            valides = {str(feuille.row(r)[0].value).strip()
                       for r in range(feuille.nrows)}
        except ImportError:
            pass
    for code, m in emplois.base().items():
        assert m["pcs_ese"] in valides, (code, m["pcs_ese"])


def test_chaque_cle_de_minima_pointe_une_grille():
    t = minima.table()
    for code, m in emplois.base().items():
        for idcc, ref in (m.get("minima") or {}).items():
            if idcc == "3090":
                for annexe, cle in ref.items():
                    assert cle in t["3090"]["annexes"][annexe]["cachets"], (code, annexe, cle)
            else:
                assert ref in t[idcc]["cachets"], (code, idcc, ref)


def test_les_cadres_par_defaut_sont_ceux_de_la_grille_3090():
    """Un technicien est cadre par defaut si et seulement si la grille 3090
    le range en cadre. Les artistes cadres sont enumeres : metteur en scene,
    choregraphe, chef d'orchestre."""
    for code, m in emplois.base().items():
        if m["statut"] == "technicien":
            niveau = m["classification_3090"]["niveau"]
            assert m["cadre_par_defaut"] == niveau.startswith("cadre"), code
        if m["cadre_par_defaut"]:
            assert m["statut_conventionnel"] == "04", code   # CCH-11
    cadres_artistes = {c for c, m in emplois.base().items()
                       if m["statut"] == "artiste" and m["cadre_par_defaut"]}
    assert cadres_artistes == {"MET040", "CHO010", "CHE190"}, cadres_artistes


def test_le_catalogue_verifie_contre_le_releve_coolpaie():
    """Les 51 codes de l'ecran Professions de CoolPaie existent dans la
    nomenclature. Verification, pas source : voir
    reference/professions-coolpaie.md."""
    codes = """ACC010 ACT010 ADM020 ADM030 ART040 ART070 ART110 ART120 ART160
    ART170 ASS170 MET042 CHA080 CHE070 CHE190 CHE270 CHE280 CHE320 CHE370 CHO020
    COI010 COL040 COS010 CRE010 DIR090 DIR120 ELE010 ENS010 HAB010 ING030 MAC010
    MAQ040 MAR010 MEC010 MEN010 MET040 MON010 MUS010 PEI010 PHO010 POU010 REA010
    REG040 REG100 REG120 REG130 REG150 SCR010 TAP010 TEC230 TEC250""".split()
    nomen = emplois.nomenclature()
    assert len(codes) == 51
    for c in codes:
        assert c in nomen, c


# ---------------------------------------------------- 2. la resolution
def test_resoudre_un_metier_donne_les_six_champs():
    r = emplois.resoudre("REG120")
    assert r["emploi"] == "REGISSEUR GENERAL"
    assert r["pcs_ese"] == "353c" and r["code_emploi_ft"] == "REG120"
    assert r["statut"] == "technicien"
    assert r["statut_categoriel_rc"] == "01" and r["statut_conventionnel"] == "04"
    r = emplois.resoudre("REG120", cadre=False)
    assert r["statut_categoriel_rc"] == "04" and r["statut_conventionnel"] == "05"
    r = emplois.resoudre("MET040", feminin=True)
    assert r["emploi_affichage"] == "Metteuse en scène" and r["emploi"] == "METTEUR EN SCENE"


def test_un_code_hors_catalogue_mais_dans_la_nomenclature_est_accepte():
    r = emplois.resoudre("TRU010")            # truquiste : audiovisuel
    assert r["statut"] == "technicien" and r["pcs_ese"] is None
    refuse = False
    try:
        emplois.resoudre("XXX999")
    except ValueError:
        refuse = True
    assert refuse


def test_un_engagement_avec_metier_declare_le_metier():
    racine = _bac()
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "heure", "quantite": 4, "taux": 20, "dates": ["2026-09-05"]}]
    s = ops.charger(c, _saisie(cle, spec, lignes, metier="TEC250"))
    p = s.paies[0]
    assert p.salarie["emploi"] == "TECHNICIEN SON"
    assert p.salarie["pcs_ese"] == "465b" and p.salarie["statut"] == "technicien"
    assert p.salarie["statut_conventionnel"] == "07"
    assert p.salarie["statut_categoriel_rc"] == "04"
    # ce que l'engagement ecrit lui-meme l'emporte
    s = ops.charger(c, _saisie(cle, spec, lignes, metier="TEC250", pcs_ese="637c"))
    assert s.paies[0].salarie["pcs_ese"] == "637c"
    # un metier inconnu est refuse, avec le rang de l'engagement
    refuse = ""
    try:
        ops.charger(c, _saisie(cle, spec, lignes, metier="ZZZ000"))
    except ops.ErreurOperation as x:
        refuse = str(x)
    assert "inconnu" in refuse and "Engagement 1" in refuse, refuse
    shutil.rmtree(racine, ignore_errors=True)


def test_sans_metier_rien_ne_change():
    """La saisie d'avant se rejoue telle quelle : la fiche fait foi."""
    racine = _bac()
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "cachet", "quantite": 1, "taux": 130, "dates": ["2026-09-05"]}]
    p = ops.charger(c, _saisie(cle, spec, lignes)).paies[0]
    fiche = c.salarie(cle)
    for k in emplois.CHAMPS:
        assert p.salarie.get(k) == fiche.get(k), k
    shutil.rmtree(racine, ignore_errors=True)


# ----------------------------------------------------- 3. les minima
def _avis(c, cle, spec, lignes, **eng):
    return ops.charger(c, _saisie(cle, spec, lignes, **eng)).paies[0].avertissements


def test_un_cachet_sous_le_minimum_avertit_sans_refuser():
    racine = _bac(idcc="3090", annexe_convention="")
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    avis = _avis(c, cle, spec, [{"rubrique": "cachet", "quantite": 1, "taux": 90,
                                 "dates": ["2026-09-05"]}], metier="ART120")
    assert len(avis) == 1, avis
    assert "90,00" in avis[0] and "119,42" in avis[0] and "annexe 1" in avis[0], avis[0]
    assert "Non bloquant" in avis[0]
    # au-dessus du plus bas des planchers : silence
    avis = _avis(c, cle, spec, [{"rubrique": "cachet", "quantite": 1, "taux": 130,
                                 "dates": ["2026-09-05"]}], metier="ART120")
    assert avis == [], avis
    shutil.rmtree(racine, ignore_errors=True)


def test_l_annexe_de_l_entreprise_change_le_plancher():
    """En tournee (annexe 4), le marionnettiste est a 135,54 pour 1 a 7
    cachets ; sans annexe, le moteur prend le plus bas (annexe 1, 119,42)."""
    racine = _bac(idcc="3090", annexe_convention="4")
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "cachet", "quantite": 2, "taux": 130, "dates": ["2026-09-05", "2026-09-06"]}]
    avis = _avis(c, cle, spec, lignes, metier="MAR010")
    assert len(avis) == 1 and "135,54" in avis[0] and "annexe 4" in avis[0], avis
    # 8 cachets dans le mois : palier suivant, 120,67 -> 130 passe
    lignes = [{"rubrique": "cachet", "quantite": 8, "taux": 130,
               "dates": ["2026-09-%02d" % j for j in range(1, 9)]}]
    assert _avis(c, cle, spec, lignes, metier="MAR010") == []
    shutil.rmtree(racine, ignore_errors=True)


def test_le_taux_horaire_d_un_technicien_est_compare_a_son_niveau():
    racine = _bac(idcc="3090", annexe_convention="")
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "heure", "quantite": 8, "taux": 12, "dates": ["2026-09-05"]}]
    avis = _avis(c, cle, spec, lignes, metier="REG120")       # cadre G2 : 17,53
    assert len(avis) == 1 and "17,53" in avis[0] and "l'heure" in avis[0], avis
    avis = _avis(c, cle, spec, lignes, metier="REG120", cadre=False)
    # Le niveau ne change pas avec la case cadre : le plancher reste 17,53.
    # La case decochee sur un metier cadre ajoute SON avertissement, a part.
    assert len(avis) == 2 and "17,53" in avis[0] and "cadre decochee" in avis[1], avis
    lignes = [{"rubrique": "heure", "quantite": 8, "taux": 14, "dates": ["2026-09-05"]}]
    assert _avis(c, cle, spec, lignes, metier="TEC250") == []  # EQ1 : 12,57
    shutil.rmtree(racine, ignore_errors=True)


def test_un_administratif_a_le_plancher_de_sa_grille_mensuelle():
    """La 3090 ne donne pas de taux horaire aux emplois administratifs : une
    grille mensuelle, echelon 1, ramenee a l'heure sur 151,67 h. Un charge
    de production (agent de maitrise, 2 099,10 EUR) : 13,84 EUR l'heure --
    et pas les 17,28 des regisseurs en tournee (annexe 4)."""
    racine = _bac(idcc="3090", annexe_convention="4")
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "heure", "quantite": 7, "taux": 12, "dates": ["2026-09-05"]}]
    avis = _avis(c, cle, spec, lignes, metier="CHA080")
    assert len(avis) == 1 and "13,84" in avis[0] and "administrative" in avis[0], avis
    lignes = [{"rubrique": "heure", "quantite": 7, "taux": 14, "dates": ["2026-09-05"]}]
    assert _avis(c, cle, spec, lignes, metier="CHA080") == []
    shutil.rmtree(racine, ignore_errors=True)


def test_decocher_cadre_sur_un_metier_cadre_avertit_sans_refuser():
    """La case decochee change ce qui part (40.003, 40.002) ; on le dit. Le
    sens inverse -- cadre coche sur un metier non cadre -- est un choix de
    contrat, sans avertissement."""
    racine = _bac(idcc="3090", annexe_convention="4")
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "cachet", "quantite": 1, "taux": 200, "dates": ["2026-09-05"]}]
    avis = _avis(c, cle, spec, lignes, metier="MET040", cadre=False)   # metteur en scene : cadre
    assert len(avis) == 1 and "cadre decochee" in avis[0] and "Metteur en sc" in avis[0], avis
    assert _avis(c, cle, spec, lignes, metier="MET040") == []
    assert _avis(c, cle, spec, lignes, metier="MET040", cadre=True) == []
    assert _avis(c, cle, spec, lignes, metier="ART120", cadre=True) == []   # non cadre coche cadre : rien
    shutil.rmtree(racine, ignore_errors=True)


def test_la_repetition_a_son_plancher():
    racine = _bac(idcc="3090", annexe_convention="1")
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "repetition", "quantite": 1, "taux": 50, "dates": ["2026-09-05"]}]
    avis = _avis(c, cle, spec, lignes, metier="ART120")
    assert len(avis) == 1 and "84,00" in avis[0], avis
    shutil.rmtree(racine, ignore_errors=True)


def test_une_convention_inconnue_ou_un_metier_sans_grille_se_taisent():
    racine = _bac(idcc="1234")
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "cachet", "quantite": 1, "taux": 1, "dates": ["2026-09-05"]}]
    assert _avis(c, cle, spec, lignes, metier="ART120") == []
    shutil.rmtree(racine, ignore_errors=True)
    racine = _bac(idcc="3090")
    c = Contexte(racine)
    assert _avis(c, cle, spec, lignes, metier="MET042") == []   # pas de ligne de minima
    shutil.rmtree(racine, ignore_errors=True)


def test_la_ccneac_a_ses_paliers():
    racine = _bac(idcc="1285")
    c = Contexte(racine)
    cle, spec = _un_salarie(c)
    lignes = [{"rubrique": "cachet", "quantite": 2, "taux": 150, "dates": ["2026-09-05", "2026-09-06"]}]
    avis = _avis(c, cle, spec, lignes, metier="ART120")
    assert len(avis) == 1 and "159,56" in avis[0] and "CCNEAC" in avis[0], avis
    lignes = [{"rubrique": "cachet", "quantite": 3, "taux": 150,
               "dates": ["2026-09-05", "2026-09-06", "2026-09-07"]}]
    assert _avis(c, cle, spec, lignes, metier="ART120") == []    # > 2 cachets : 138,85
    shutil.rmtree(racine, ignore_errors=True)


# ------------------------------------------------------- 4. les sources
def test_le_manifeste_des_sources_est_complet():
    m = sources.manifeste()["sources"]
    assert len(m) >= 6
    for ident, s in m.items():
        for k in ("titre", "editeur", "url", "contenu", "releve_le", "fichier", "sha256", "verification", "nourrit"):
            assert s.get(k) is not None, (ident, k)
        assert s["verification"] in ("telechargement", "manuelle"), ident
        if s["verification"] == "manuelle":
            assert s.get("page_de_veille"), ident
        assert len(s["sha256"]) == 64, ident


def test_chaque_fichier_de_donnees_cite_une_source_du_manifeste():
    idents = set(sources.manifeste()["sources"])
    for nom in ("emplois-base.json", "minima-conventionnels.json"):
        d = json.loads((CODE / "moteur" / nom).read_text(encoding="utf-8"))
        for s in d["_sources"]:
            assert s in idents, (nom, s)
    n = json.loads((CODE / "moteur" / "nomenclature-emplois-ft.json").read_text(encoding="utf-8"))
    assert n["_source"] in idents
    assert len(n["emplois"]) == 1236


def test_les_copies_sur_disque_sont_conformes_quand_elles_sont_la():
    """Sans les donnees (depot public seul), le test passe : il ne peut rien
    verifier. Avec elles, une copie qui ne colle plus au manifeste est une
    source relue sans que le manifeste ait suivi."""
    for e in sources.etats(ctx):
        if e.copie_presente:
            assert e.copie_conforme, e.ident


def test_la_commande_sources_rend_du_json():
    from moteur import cli
    buf = io.StringIO()
    with redirect_stdout(buf):
        code = cli.main(["sources", "--json"])
    assert code == 0
    d = json.loads(buf.getvalue())
    assert d["ok"] and d["resultat"]["total"] >= 6


def test_la_commande_emplois_rend_du_json():
    from moteur import cli
    buf = io.StringIO()
    with redirect_stdout(buf):
        code = cli.main(["emplois", "--json", "--chercher", "marionn"])
    assert code == 0
    d = json.loads(buf.getvalue())
    assert d["resultat"]["total"] == 1 and d["resultat"]["emplois"][0]["code"] == "MAR010"


def _lancer():
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    echecs = 0
    for nom, fn in tests:
        try:
            with redirect_stdout(io.StringIO()):
                fn()
            print("  OK     %s" % nom)
        except AssertionError as e:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    print()
    print("Tous les tests passent." if not echecs
          else "%d test(s) en echec." % echecs)
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(_lancer())
