"""Un mois sans aucun salarie : la DSN est due quand meme.

Leandre, 15/09/2026 : << il faut toujours des DSN, meme les mois sans paye,
je suis sur de moi >>. Le cahier technique NEODeS 2026.1 (§2.4, p. 64-67)
le confirme et dit la forme : une « declaration normale sans individu »
(S20.G00.05.002 = 02, ou 05 en annule et remplace), dans un « envoi neant »
(S10.G00.00.008 = 02), qui ne porte que S10, S20, S90, l'entreprise (06),
l'etablissement (11) et, pour nos organismes, les adhesions prevoyance (15,
sans personnel couvert), le versement Urssaf (20) et son bordereau (22, 23).
Le depot de test du 15/09/2026 a corrige deux choses : une adhesion « avec
personnel couvert » sans affiliation est refusee (15 CCH-13), et un
versement de prevoyance sans composant 55 aussi (20 CCH-12). S20.G00.08 nomme les
organismes precedemment destinataires qui n'ont plus d'individu rattache ce
mois-ci (AGIRC-ARRCO 88, France Travail 93, Conges spectacles 97 -- codes
lus p. 140, portes par config/organismes.json).

Ce fichier produit un tel mois dans un bac jetable et lit la DSN. Rien
d'autre n'est du : ni bulletin, ni contrat, ni certificat.
"""
import io
import json
import shutil
import sys
import tempfile
from contextlib import redirect_stdout
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import operations as ops                     # noqa: E402
from moteur import dsn                                   # noqa: E402
from moteur.contexte import Contexte                     # noqa: E402

ctx = Contexte()


def _bac():
    racine = Path(tempfile.mkdtemp())
    shutil.copytree(ctx.racine / "config", racine / "config",
                    ignore=shutil.ignore_patterns("*.bin", ".seance", "avant"))
    (racine / "paies").mkdir()
    return racine


def _valeurs(lignes, rubrique):
    return [l.split(",", 1)[1].strip("'") for l in lignes if l.startswith(rubrique + ",")]


class Neant:
    _fait = None

    @classmethod
    def faire(cls):
        if cls._fait:
            return cls._fait
        racine = _bac()
        p = racine / "paies" / "2026-05.json"
        p.write_text(json.dumps({"mois": "2026-05", "taux_cachet": 130.0,
                                 "date_paiement": "2026-05-31", "engagements": []}),
                     encoding="utf-8")
        r = ops.produire_mois(Contexte(racine), p, qui="test")
        lignes = next(f for f in r.fichiers if f.suffix == ".dsn") \
            .read_bytes().decode("latin-1").splitlines()
        cls._fait = {"racine": racine, "produit": r, "dsn": lignes}
        return cls._fait


def test_un_mois_sans_salarie_ne_produit_que_sa_dsn_sans_bordereau_a_confronter():
    n = Neant.faire()
    r = n["produit"]
    assert [f.name for f in r.fichiers] == ["DSN_Mai2026.dsn"], [f.name for f in r.fichiers]
    assert r.numeros.bulletin_premier == 0
    assert any("sans individu" in a and "due chaque mois" in a for a in r.avertissements), r.avertissements
    # Aucun montant Urssaf demande : rien n'est du, le bordereau est nul.
    assert r.urssaf == 0.0 and not r.urssaf_estime


def test_la_dsn_sans_individu_a_la_forme_du_cahier_technique():
    d = Neant.faire()["dsn"]
    assert _valeurs(d, "S10.G00.00.008") == ["02"]              # envoi neant
    assert _valeurs(d, "S20.G00.05.001") == ["01"]              # mensuelle
    assert _valeurs(d, "S20.G00.05.002") == ["02"]              # normale sans individu
    assert _valeurs(d, "S20.G00.05.005") == ["01052026"]
    assert _valeurs(d, "S20.G00.05.007") == ["31052026"]        # constituee en fin de mois
    assert _valeurs(d, "S20.G00.08.001") == ["88", "93", "97"]
    # Entreprise et etablissement, comme tout mois.
    assert _valeurs(d, "S21.G00.06.001") and _valeurs(d, "S21.G00.11.001")
    # Aucun individu, aucun contrat, aucune remuneration.
    for rub in ("S21.G00.30.001", "S21.G00.40.001", "S21.G00.50.001",
                "S21.G00.51.011", "S21.G00.78.001", "S21.G00.81.001"):
        assert not _valeurs(d, rub), rub
    # Les adhesions prevoyance restent, mais ne couvrent personne (CCH-13).
    assert len(_valeurs(d, "S21.G00.15.001")) == 4
    assert set(_valeurs(d, "S21.G00.15.004")) == {"02"}
    # Un seul versement, l'Urssaf, a zero, avec son bordereau a zero.
    assert _valeurs(d, "S21.G00.20.001") == ["78861779300013"]
    assert _valeurs(d, "S21.G00.20.005") == ["0.00"]
    assert _valeurs(d, "S21.G00.22.005") == ["0.00"]
    assert set(_valeurs(d, "S21.G00.23.004")) == {"0.00"}
    assert not _valeurs(d, "S21.G00.55.001")
    # Le compte des lignes est juste.
    assert int(_valeurs(d, "S90.G00.90.001")[0]) == len(d)


def test_l_annule_et_remplace_d_un_mois_sans_salarie_est_de_type_05():
    texte = dsn.generer(ctx, [], "2026-05", type_declaration="03", ordre=2)
    d = texte.splitlines()
    assert _valeurs(d, "S20.G00.05.002") == ["05"]
    assert _valeurs(d, "S20.G00.05.004") == ["2"]
    assert _valeurs(d, "S10.G00.00.008") == ["02"]
    refuse = False
    try:
        dsn.generer(ctx, [], "2026-05", type_declaration="03", ordre=1)
    except ValueError as e:
        refuse = "STRICTEMENT superieur" in str(e)
    assert refuse


def test_un_mois_avec_salaries_reste_un_envoi_normal():
    """Le chemin ordinaire ne bouge pas : envoi 01, type 01, pas de S20.G00.08."""
    from tests.test_contrats_plurimensuels import Tournee, _dsn
    d = _dsn(Tournee.faire()["produits"]["2026-10"])
    assert _valeurs(d, "S10.G00.00.008") == ["01"]
    assert _valeurs(d, "S20.G00.05.002") == ["01"]
    assert not _valeurs(d, "S20.G00.08.001")


def _lancer():
    tests = [(n, f) for n, f in sorted(globals().items())
             if n.startswith("test_") and callable(f)]
    echecs = 0
    for nom, fn in tests:
        try:
            with redirect_stdout(io.StringIO()):
                fn()
            print("  OK     %s" % nom)
        except AssertionError as e:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, e))
        except Exception as e:                                    # noqa: BLE001
            echecs += 1
            print("  ERREUR %s\n         %s: %s" % (nom, type(e).__name__, e))
    if Neant._fait:
        shutil.rmtree(Neant._fait["racine"], ignore_errors=True)
    try:
        from tests.test_contrats_plurimensuels import Tournee
        if Tournee._fait:
            shutil.rmtree(Tournee._fait["racine"], ignore_errors=True)
    except ImportError:
        pass
    print()
    print("Tous les tests passent." if not echecs
          else "%d test(s) en echec." % echecs)
    return 1 if echecs else 0


if __name__ == "__main__":
    sys.exit(_lancer())
