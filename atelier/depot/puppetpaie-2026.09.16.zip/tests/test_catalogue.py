"""Le catalogue de base : ce que PuppetPaie sait payer, pour n'importe qui.

Ces tests ne verrouillent pas notre paie a nous. Ils verrouillent le MODELE :
qu'une rubrique dise d'ou vient sa regle, qu'aucune ne recree le coefficient
`jours` de CoolPaie, et qu'une compagnie puisse choisir les siennes.

Le catalogue de base est livre AVEC LE LOGICIEL : ces tests doivent passer sur
un clone du depot public, sans aucune donnee.
"""
import json
import sys
import tempfile
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import catalogue as cat                            # noqa: E402


class _Ctx:
    """Un contexte reduit a ce que le catalogue lui demande : une racine."""
    def __init__(self, racine):
        self.racine = racine


# ------------------------------------------------------- le catalogue existe
def test_le_catalogue_de_base_est_livre_avec_le_code():
    """Il vit dans moteur/, pas dans les donnees : c'est lui qui rend le
    logiciel utilisable par une compagnie qui n'a pas notre config."""
    assert cat.BASE.exists(), "moteur/rubriques-base.json est absent"
    assert cat.BASE.is_relative_to(CODE / "moteur")


def test_toutes_les_rubriques_de_base_sont_valides():
    """Chaque entree se construit : unite connue, nature connue, source non
    vide. Une erreur ici est une erreur de saisie du catalogue lui-meme."""
    liste = cat.catalogue()
    assert len(liste) >= 12
    assert len({r.code for r in liste}) == len(liste), "codes en double"


def test_chaque_rubrique_dit_d_ou_vient_sa_regle():
    """C'est la condition de l'autonomie : une rubrique sans source est une
    rubrique que personne ne pourra verifier apres nous."""
    for r in cat.catalogue():
        assert len(r.source) > 30, (
            "%s : source trop courte pour dire quoi que ce soit" % r.code)


# ------------------------------------------------- les jours sont un fait
def test_aucune_rubrique_ne_porte_de_coefficient_jours():
    """Le point tranche le 10/09/2026. CoolPaie devinait les jours depuis les
    heures, avec quatre valeurs pour la meme notion. Ici les jours travailles
    se saisissent avec les dates, et rien d'autre ne les produit."""
    donnees = json.loads(cat.BASE.read_text(encoding="utf-8"))
    for code, d in donnees["rubriques"].items():
        assert "jours_coefficient" not in d and "coefficient_jours" not in d
        # `jours` existe comme champ de SAISIE (la semaine en demande un),
        # jamais comme coefficient porte par la rubrique.
        assert not isinstance(d.get("jours"), (int, float)), (
            "%s porte un coefficient `jours` : c'est la faute de CoolPaie" % code)


def test_demander_les_jours_a_une_rubrique_leve():
    for r in cat.catalogue():
        try:
            r.jours(1)
        except TypeError as e:
            assert "saisie" in str(e)
        else:
            raise AssertionError("%s.jours() aurait du lever" % r.code)


# ------------------------------------------------------ les heures, elles
def test_le_cachet_vaut_douze_heures():
    """Annexes VIII et X. Des heures accordees, pas des heures faites : c'est
    le seul cas ou la rubrique impose le nombre."""
    c = cat.rubrique("cachet")
    assert c.heures_forfait == 12
    assert c.heures(1) == 12 and c.heures(3) == 36


def test_la_journee_prend_ses_heures_a_la_saisie():
    """Elle remplace j7, j8, j10 et j12 : quatre rubriques de CoolPaie qui
    n'etaient qu'un nombre fige faute de pouvoir le demander."""
    j = cat.rubrique("journee")
    assert j.heures_forfait is None
    assert "heures" in j.saisie
    assert j.heures(2, 5) == 10          # deux journees de cinq heures
    assert j.heures(1, 12) == 12         # ce que j12 faisait, en une rubrique


def test_l_heure_compte_ses_propres_heures():
    assert cat.rubrique("heure").heures(7) == 7


# ------------------------------------------- la nature commande l'assiette
def test_le_salaire_est_dans_l_assiette_et_les_frais_non():
    """CSS L.242-1 : la contrepartie du travail cotise. Les frais
    professionnels n'en sont pas, dans les limites du bareme."""
    for code in ("cachet", "heure", "journee", "mois"):
        r = cat.rubrique(code)
        assert r.nature == "salaire"
        assert r.soumis and r.imposable
    for code in ("defraiement_forfait", "defraiement_reel"):
        r = cat.rubrique(code)
        assert r.nature == "frais"
        assert not r.soumis and not r.imposable


def test_l_avantage_en_nature_est_soumis_et_imposable():
    a = cat.rubrique("avantage_nature")
    assert a.soumis and a.imposable
    assert a.dsn_autres_bruts == "06"    # S21.G00.54.001, autres avantages


def test_les_defraiements_portent_leur_code_de_norme():
    """Releve dans le cahier technique NEODeS 2026.1, p. 257."""
    assert cat.rubrique("defraiement_forfait").dsn_autres_bruts == "07"
    assert cat.rubrique("defraiement_reel").dsn_autres_bruts == "09"


def test_l_acompte_ne_touche_aucune_assiette():
    a = cat.rubrique("acompte")
    assert a.sens == "-" and not a.soumis and not a.imposable


# ------------------------------------------------------- ce qui est refuse
def test_une_unite_inconnue_est_refusee():
    try:
        cat._construire("x", {"libelle": "X", "unite": "lune",
                              "nature": "salaire", "soumis": True,
                              "imposable": True, "conges_spectacles": True,
                              "source": "x" * 40}, "base", 0, False)
    except ValueError as e:
        assert "unite" in str(e)
    else:
        raise AssertionError("une unite inventee aurait du etre refusee")


def test_une_rubrique_sans_source_est_refusee():
    try:
        cat._construire("x", {"libelle": "X", "unite": "heure",
                              "nature": "salaire", "soumis": True,
                              "imposable": True, "conges_spectacles": True,
                              "source": ""}, "base", 0, False)
    except ValueError as e:
        assert "source" in str(e)
    else:
        raise AssertionError("une rubrique sans source aurait du etre refusee")


def test_un_champ_inconnu_est_refuse():
    """Une faute de frappe dans un fichier de compagnie ne doit pas passer
    inapercue en etant simplement ignoree."""
    try:
        cat._construire("x", {"libelle": "X", "unite": "heure",
                              "nature": "salaire", "soumis": True,
                              "imposable": True, "conges_spectacles": True,
                              "source": "x" * 40, "soumise": True},
                        "base", 0, False)
    except ValueError as e:
        assert "soumise" in str(e)
    else:
        raise AssertionError("un champ inconnu aurait du etre refuse")


# ------------------------------------------- ce qu'une compagnie en fait
def test_une_compagnie_choisit_les_siennes_et_les_plus_utilisees_remontent():
    """« On clique les rubriques que l'on veut voir apparaitre dans le
    deroulant et il met la plus utilisee en premier. »"""
    with tempfile.TemporaryDirectory() as tmp:
        conf = Path(tmp) / "config"
        conf.mkdir()
        (conf / "rubriques-actives.json").write_text(json.dumps({
            "actives": ["cachet", "enseignement"],
            "usages": {"cachet": 214, "enseignement": 3}}), encoding="utf-8")
        liste = cat.catalogue(_Ctx(Path(tmp)))
    assert [r.code for r in liste[:2]] == ["cachet", "enseignement"]
    assert liste[0].usages == 214
    assert all(not r.active for r in liste[2:]), (
        "les non cochees doivent rester disponibles, mais en second rang")


def test_une_compagnie_peut_ajouter_une_rubrique_a_elle():
    with tempfile.TemporaryDirectory() as tmp:
        conf = Path(tmp) / "config"
        conf.mkdir()
        (conf / "rubriques-compagnie.json").write_text(json.dumps({
            "rubriques": {"filage": {
                "libelle": "Filage", "unite": "service", "nature": "salaire",
                "saisie": ["quantite", "taux", "heures"],
                "soumis": True, "imposable": True, "conges_spectacles": True,
                "source": "Convention IDCC 3090 : service de filage, duree "
                          "saisie, minimum conventionnel par service."}}}),
            encoding="utf-8")
        ctx = _Ctx(Path(tmp))
        f = cat.rubrique("filage", ctx)
    assert f.origine == "compagnie" and f.unite == "service"


def test_une_compagnie_peut_ajuster_une_rubrique_de_base():
    """Sans la recopier : elle ne redit que ce qui change chez elle."""
    with tempfile.TemporaryDirectory() as tmp:
        conf = Path(tmp) / "config"
        conf.mkdir()
        (conf / "rubriques-compagnie.json").write_text(json.dumps({
            "rubriques": {"enseignement": {"libelle": "Atelier scolaire"}}}),
            encoding="utf-8")
        e = cat.rubrique("enseignement", _Ctx(Path(tmp)))
    assert e.libelle == "Atelier scolaire"
    assert e.origine == "base" and e.soumis is True     # le reste ne bouge pas


def test_sans_configuration_le_catalogue_de_base_suffit():
    """Le cas d'une compagnie qui deballe le logiciel : aucun fichier de
    configuration, rien n'est cochee, tout est disponible, rien ne plante."""
    with tempfile.TemporaryDirectory() as tmp:
        liste = cat.catalogue(_Ctx(Path(tmp)))
    assert liste and all(not r.active for r in liste)


def test_sans_contexte_les_rubriques_de_la_compagnie_restent_visibles():
    """`catalogue()` sans contexte prend la racine de donnees par defaut, la
    meme convention que partout ailleurs. C'est ce qui permet a `Engagement`
    de resoudre une rubrique maison sans qu'on lui passe un contexte -- sinon
    elle serait invisible la ou elle compte, et la zone AEM sortirait fausse
    sans que rien ne le signale."""
    liste = cat.catalogue()
    assert liste, "le catalogue par defaut est vide"


# ------------------------------ les deux annexes, relevees le 10/09/2026
def test_tous_les_cachets_valent_douze_heures_le_groupe_n_existe_plus():
    """Point 14.2 de ETAT.md, tranche. Leandre : « il n'y a plus de cachet de
    8 h, depuis un bail deja. » Verifie : le decret du 13 juillet 2016 a
    supprime la distinction isole (12 h) / groupe (8 h). Tous les cachets
    valent 12 heures, quelle que soit la duree du contrat.

    Le catalogue de CoolPaie porte toujours `cg` a 8 h -- une valeur perimee
    depuis dix ans, qui a servi cinq ans chez nous."""
    c = cat.rubrique("cachet")
    assert c.heures_forfait == 12
    assert "cachet_groupe" not in {r.code for r in cat.catalogue()}
    assert "SUPPRIMEE" in c.source and "2016" in c.source


def test_le_cachet_est_plafonne_a_vingt_huit_par_mois():
    """Annexe X, article 3. Au-dela, les cachets ne se convertissent plus."""
    assert cat.rubrique("cachet").plafond_mensuel == 28


def test_le_cachet_appartient_a_l_annexe_X():
    """Un technicien (annexe VIII) est paye a l'heure : le cachet n'existe pas
    pour lui. C'est la seule difference de forme de paie entre les deux
    annexes -- la duree, elle, ne les distingue plus depuis 2016 (507 heures
    sur 12 mois pour les deux, contre 10 et 10,5 mois auparavant)."""
    assert cat.rubrique("cachet").annexe == "X"
    assert cat.rubrique("heure").annexe is None       # les deux annexes


def test_l_enseignement_est_plafonne_selon_l_age():
    """70 h avant 50 ans, 120 h a partir de 50 ans, pour les DEUX annexes.
    L'age retenu est celui a la fin du contrat servant a l'ouverture des
    droits. Source : France Travail, heures d'enseignement."""
    e = cat.rubrique("enseignement")
    assert e.plafond_annuel_heures == {"moins_de_50_ans": 70,
                                       "50_ans_et_plus": 120}


def test_l_enseignement_ouvre_les_droits_mais_n_augmente_pas_l_are():
    """La nuance qui fait qu'un seul compteur ne suffit pas : ces heures font
    atteindre les 507, mais n'entrent pas dans le calcul du montant. Un cumul
    qui les melangerait annoncerait une allocation fausse."""
    assert cat.rubrique("enseignement").compte_pour == "ouverture_des_droits"
    for code in ("cachet", "heure", "journee"):
        assert cat.rubrique(code).compte_pour == "droits_et_montant"


def test_un_compte_pour_invente_est_refuse():
    try:
        cat._construire("x", {"libelle": "X", "unite": "heure",
                              "nature": "salaire", "soumis": True,
                              "imposable": True, "conges_spectacles": True,
                              "source": "x" * 40, "compte_pour": "peut-etre"},
                        "base", 0, False)
    except ValueError as e:
        assert "compte_pour" in str(e)
    else:
        raise AssertionError("un compte_pour invente aurait du etre refuse")


# ---------------------- le passage par le catalogue ne change aucun nombre
def test_les_lignes_de_brut_refont_exactement_l_ancien_calcul():
    """Le 10/09/2026, `calcul.py` a cesse de fabriquer ses montants lui-meme
    pour passer par le catalogue. Ce test compare, sur toutes les formes de
    contrat que la compagnie a jouees, l'ancienne formule et la nouvelle.

    L'ancienne, telle qu'elle etait ecrite :

        h  = heures
        th = taux_horaire, ou taux_cachet si contrat purement horaire, sinon 0
        montants = [eur(taux_cachet x cachets)] + [eur(th x h)]
        heures_equivalentes = h + 12 x cachets

    Un ecart d'un centime ici, et cinq ans de bulletins cesseraient de se
    rejouer. Aucun n'est tolere."""
    from decimal import Decimal
    from moteur.calcul import Engagement, lignes_brut
    from moteur.util import eur

    grille = [(c, hh, th)
              for c in (0, 1, 2, 5, 28)
              for hh in (0, 8, 12, 35.5)
              for th in (None, 20.0, 12.02)]
    vus = 0
    for cachets, heures, taux_horaire in grille:
        if not cachets and not heures:
            continue                      # un engagement vide n'existe pas
        lignes = []
        if cachets:
            lignes.append({"rubrique": "cachet", "quantite": cachets, "taux": 130.0})
        if heures:
            lignes.append({"rubrique": "heure", "quantite": heures,
                           "taux": taux_horaire if taux_horaire is not None else 130.0})
        eng = Engagement(salarie="X", spectacle="Y",
                         dates_travail=["2026-09-06", "2026-09-07"],
                         lignes=lignes, jours=2)

        h = Decimal(str(eng.heures)) if eng.heures else Decimal(0)
        attendu = (Decimal(cachets or 0) * Decimal("130.0")
                   + h * Decimal(str(taux_horaire if taux_horaire is not None else 130.0)))
        brut = sum((l.montant for l in lignes_brut(eng)), Decimal(0))
        assert brut == attendu, (cachets, heures, taux_horaire, brut, attendu)
        assert eng.cachets == (cachets or 0)
        assert (eng.heures or 0) == (heures or 0)


def test_le_convertisseur_rend_la_saisie_d_avant_en_lignes_equivalentes():
    """L'ancienne ecriture (`cachets` sur l'engagement) ne se lit plus : elle
    se convertit une fois, et la conversion doit donner exactement les memes
    lignes de paie. C'est ce qui a permis de basculer aout 2026 sans que
    rien ne bouge (douze documents identiques)."""
    import sys as _sys
    from decimal import Decimal
    from moteur.calcul import Engagement, lignes_brut
    _sys.path.insert(0, str(CODE / "outils"))
    import convertir_saisies as conv

    dates = ["2026-09-06", "2026-09-07"]
    ancien = {"salarie": "X", "spectacle": "Y", "dates": dates, "cachets": 2,
              "heures": 3, "taux_horaire": 20.0}
    neuf = conv.convertir_engagement(ancien, 130.0)
    assert "dates" not in neuf and "cachets" not in neuf
    eng = Engagement(salarie="X", spectacle="Y", dates_travail=dates, jours=2,
                     lignes=neuf["lignes"])
    assert [l.montant for l in lignes_brut(eng)] == [Decimal("260.00"), Decimal("60.00")]
    assert eng.cachets == 2 and eng.heures == 3.0 and eng.taux_cachet == 130.0


def test_une_journee_de_cinq_heures_se_saisit_enfin():
    """Ce que CoolPaie ne savait pas faire : il aurait fallu une rubrique j5,
    qui n'existe pas dans ses 81."""
    from decimal import Decimal
    from moteur.calcul import Engagement, lignes_brut
    eng = Engagement(salarie="X", spectacle="Y",
                     dates_travail=["2026-09-06"], jours=1,
                     lignes=[{"rubrique": "journee", "quantite": 1,
                              "taux": 150.0, "heures": 5}])
    l = lignes_brut(eng)[0]
    assert l.montant == Decimal("150.00")
    assert l.heures_annexes == Decimal("5")


def test_un_engagement_sans_ligne_est_refuse():
    """Il n'y a plus qu'une ecriture : un engagement qui ne porte aucune
    ligne de paie ne sait pas ce qu'il paie, et le message nomme l'outil de
    conversion pour un fichier d'avant."""
    from moteur.calcul import Engagement
    try:
        Engagement(salarie="X", spectacle="Y", dates_travail=["2026-09-06"])
    except ValueError as e:
        assert "convertir_saisies" in str(e)
    else:
        raise AssertionError("un engagement sans ligne aurait du etre refuse")


def test_une_saisie_par_rubrique_remplit_la_zone_aem():
    """Zone AEM [650:659] : heures, cachets, jours travailles -- trois nombres
    distincts. Avec des lignes de rubrique, les cachets viennent des lignes en
    cachets et les heures des AUTRES lignes seulement : les 12 heures d'un
    cachet sont impliquees par le nombre de cachets, et les compter aussi dans
    les heures doublerait les droits du salarie.

    Bogue trouve le 10/09/2026 en regardant la page : l'AEM annoncait
    0 cachet des qu'on saisissait par rubrique."""
    from moteur.contexte import Contexte
    from moteur import operations as ops
    ctx = Contexte()
    if not (ctx.racine / "config" / "salaries.json").exists():
        return                                   # clone public : rien a rejouer
    s = ops.charger(ctx, {
        "mois": "2026-09", "spectacle": "oooh teresina",
        "date_paiement": "2026-09-30", "lieu": "",
        "engagements": [{
            "salarie": "Ana", "jours": 1,
            "lignes": [{"rubrique": "cachet", "quantite": 1, "taux": 130.0,
                        "dates": ["2026-09-06"]},
                       {"rubrique": "journee", "quantite": 1, "taux": 90.0,
                        "heures": 5}]}]})
    e = s.paies[0].engagement
    assert e.cachets == 1, "l'AEM declarerait %s cachet(s)" % e.cachets
    assert e.heures == 5.0, "les heures du cachet ne doivent pas s'y ajouter"
    assert e.jours == 1


def test_l_engagement_se_connait_sans_qu_on_ait_calcule():
    """Le sens du flux, corrige le 10/09/2026.

    Avant : `calculer()` ECRIVAIT `cachets` et `heures` dans l'engagement, et
    l'AEM lisait le resultat. Une AEM produite sans passer par le calcul
    declarait donc zero cachet, en silence -- et rien dans le code ne disait
    que l'ordre importait.

    Maintenant l'engagement pose ces nombres a sa construction. On peut lire
    la zone AEM d'un engagement qu'on n'a jamais calcule."""
    from moteur.calcul import Engagement
    eng = Engagement(salarie="X", spectacle="Y",
                     dates_travail=["2026-09-06"], jours=1,
                     lignes=[{"rubrique": "cachet", "quantite": 2, "taux": 130.0},
                             {"rubrique": "journee", "quantite": 1,
                              "taux": 90.0, "heures": 5}])
    assert eng.cachets == 2 and eng.heures == 5.0 and eng.jours == 1


def test_calculer_ne_modifie_plus_l_engagement():
    """Un calcul qui change sa propre entree donne un resultat different au
    deuxieme appel. Ici, deux calculs de suite laissent l'engagement intact."""
    from moteur.contexte import Contexte
    from moteur.calcul import Engagement, calculer
    ctx = Contexte()
    if not (ctx.racine / "config" / "salaries.json").exists():
        return                                   # clone public : rien a rejouer
    eng = Engagement(salarie="Ana", spectacle="oooh teresina",
                     dates_travail=["2026-09-06"], jours=1,
                     date_paiement="2026-09-30",
                     lignes=[{"rubrique": "cachet", "quantite": 1,
                              "taux": 130.0}])
    avant = (eng.cachets, eng.heures, eng.jours)
    calculer(ctx, eng)
    calculer(ctx, eng)
    assert (eng.cachets, eng.heures, eng.jours) == avant


def test_un_contrat_mixte_se_saisit_sans_ambiguite():
    """Chaque ligne porte son taux : un contrat mixte n'a plus rien
    d'ambigu, et l'engagement compte lui-meme ce que l'AEM declare."""
    from moteur.calcul import Engagement
    eng = Engagement(salarie="X", spectacle="Y", dates_travail=["2026-09-06"],
                     lignes=[{"rubrique": "cachet", "quantite": 1, "taux": 130.0},
                             {"rubrique": "heure", "quantite": 12, "taux": 20.0}])
    assert eng.cachets == 1 and eng.heures == 12.0


# ------------------------------- la ligne se dit elle-meme, en francais
def test_une_ligne_sait_se_nommer():
    """Le bulletin et le contrat impriment cette phrase-la. Deux documents qui
    la fabriqueraient chacun de leur cote finiraient par ne plus dire la meme
    chose du meme contrat -- et l'un des deux est signe."""
    from moteur.calcul import Engagement, lignes_brut

    eng = Engagement(salarie="X", spectacle="Y",
                     dates_travail=["2026-09-06", "2026-09-07"],
                     lignes=[{"rubrique": "cachet", "quantite": 2, "taux": 130.0},
                             {"rubrique": "journee", "quantite": 1, "taux": 200.0,
                              "heures": 5},
                             {"rubrique": "repetition", "quantite": 3, "taux": 50.0,
                              "heures": 4},
                             {"rubrique": "enseignement", "quantite": 6,
                              "taux": 40.0}])
    dits = [l.designation for l in lignes_brut(eng)]
    assert dits == ["2 Cachets", "1 Journée de travail",
                    "3 Services de répétition",
                    "6 h de Masterclass / action culturelle"]


def test_le_pluriel_porte_sur_le_premier_mot():
    """« Journee de travails » serait le resultat d'un `s` ajoute a la fin."""
    from moteur.calcul import Engagement, lignes_brut

    eng = Engagement(salarie="X", spectacle="Y", dates_travail=["2026-09-06"],
                     lignes=[{"rubrique": "journee", "quantite": 2, "taux": 200.0,
                              "heures": 5}])
    assert lignes_brut(eng)[0].designation == "2 Journées de travail"


def test_une_quantite_fractionnaire_se_dit_a_la_francaise():
    """3,5 heures, pas 3.5 : ces phrases s'impriment sur un bulletin.

    Et la rubrique horaire dit deja son unite : « 3,5 h de Heure de travail »
    serait un begaiement."""
    from moteur.calcul import Engagement, lignes_brut

    eng = Engagement(salarie="X", spectacle="Y", dates_travail=["2026-09-06"],
                     lignes=[{"rubrique": "heure", "quantite": 3.5, "taux": 20.0}])
    assert lignes_brut(eng)[0].designation == "3,5 Heures de travail"


def test_les_libelles_du_catalogue_sont_ecrits_en_francais():
    """Ils s'impriment sur un bulletin et sur un contrat : ils portent leurs
    accents. Le reste du fichier -- codes, commentaires -- reste en ASCII,
    comme le code."""
    accentues = [r.libelle for r in cat.catalogue()
                 if any(ord(c) > 127 for c in r.libelle)]
    assert "Journée de travail" in accentues
    assert "Service de répétition" in accentues


if __name__ == "__main__":
    # Sans ce bloc, `python tests/test_catalogue.py` ne lancait RIEN et
    # sortait 0 : 34 tests passaient pour verts sans avoir ete executes.
    # Ajoute le 10/09/2026, apres l'avoir constate. Meme bloc que les autres
    # fichiers de tests -- pytest n'est pas installe ici.
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("  OK     %s" % nom)
        except AssertionError as exc:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, exc))
    print("\n%s" % ("Tous les tests passent." if not echecs
                    else "%d test(s) en echec." % echecs))
    sys.exit(1 if echecs else 0)
