"""Tests de la lecture des retours DSN et du magasin de taux de PAS.

Deux natures de preuve, et il faut savoir les distinguer :

  - les tests sur la fiche de parametrage Audiens et sur l'historique des DSN
    portent sur des fichiers REELS, deposes ou recus. Ils font foi.
  - le test du format reel du CRM 94 porte sur le retour du 19/08/2026,
    reellement recu. Il fait foi. Ses NIR et son SIRET ont ete remplaces par
    des valeurs fabriquees -- ce depot est public. Ce qui fait foi ici est la
    STRUCTURE (les balises, leur imbrication, l'attribut `identifiant`), pas
    l'identite des personnes ; les cles des NIR fabriques se verifient, pour
    qu'un test ne puisse pas passer sur un numero impossible.
  - les autres tests du CRM portent sur des fichiers FABRIQUES : ce sont les
    strategies de secours, gardees au cas ou le format changerait.
"""
import sys
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent    # logiciel/ : le depot public
sys.path.insert(0, str(CODE))

from moteur import cumul, pas, retours                   # noqa: E402
from moteur.contexte import Contexte, racine_donnees                     # noqa: E402

ctx = Contexte()
RACINE = ctx.racine        # prive/ : les donnees
EXPORT_DSN = ctx.export / "DSN"


# --------------------------------------------------- reponses de l'API (guide)
LISTE_XML = """<retours>
  <flux>
    <id>F1spdeAilkR4q3UUlQA7haa</id>
    <retour>
      <publication>20260904123242</publication>
      <production>20260904123242</production>
      <nature>11</nature>
      <statut>OK</statut>
      <id>0123456789</id>
      <url>https://telechargement.dsnrg.net-entreprises.fr/telecharger-retour/1.0/F1/01</url>
    </retour>
    <retour>
      <publication>20260906080000</publication>
      <production>20260906080000</production>
      <nature>94</nature>
      <statut>OK</statut>
      <id>0123456790</id>
      <url>https://telechargement.dsnrg.net-entreprises.fr/telecharger-retour/1.0/F1/02</url>
    </retour>
  </flux>
</retours>"""


def test_liste_retours_xml():
    r = retours.parse_liste_retours(LISTE_XML)
    assert len(r) == 2
    assert r[0]["nature"] == "11" and r[0]["statut"] == "OK"
    assert r[1]["nature"] == retours.NATURE_TAUX_PAS
    assert r[1]["flux"] == "F1spdeAilkR4q3UUlQA7haa"
    assert r[1]["url"].endswith("/F1/02")


def test_liste_retours_json():
    """Version 2.0 des services : meme contenu, en JSON."""
    brut = """{"retours": {"flux": [{"id": "F1", "retour": [
        {"publication": "20260906080000", "production": "20260906080000",
         "nature": "94", "statut": "OK", "url": "https://h/t/1"}]}]}}"""
    r = retours.parse_liste_retours(brut)
    assert len(r) == 1 and r[0]["nature"] == "94" and r[0]["flux"] == "F1"


def test_liste_depots():
    brut = """<depots><declarant><siret>12345678900017</siret>
      <depot><idflux>WSA82</idflux><date>20260903093654</date><statut>OK</statut></depot>
    </declarant></depots>"""
    d = retours.parse_liste_depots(brut)
    assert d == [{"idflux": "WSA82", "date": "20260903093654", "statut": "OK"}]


def test_libelle_nature_94():
    assert "PAS" in retours.libelle_nature("94")
    assert "inconnue" in retours.libelle_nature("999")


# ------------------------------------------------- CRM 94 (formats plausibles)
def _crm_par_code(nir, taux, type_taux, identifiant):
    return """<?xml version="1.0" encoding="UTF-8"?>
<bilan><declaration><individu>
  <rubrique code="S21.G00.30.001">%s</rubrique>
  <rubrique code="S21.G00.50.006">%s</rubrique>
  <rubrique code="S21.G00.50.007">%s</rubrique>
  <rubrique code="S21.G00.50.008">%s</rubrique>
</individu></declaration></bilan>""" % (nir, taux, type_taux, identifiant)


def _crm_par_nom_metier(nir, taux, type_taux, identifiant):
    return """<?xml version="1.0" encoding="UTF-8"?>
<bilan><individu><NumeroInscription>%s</NumeroInscription>
  <VersementIndividu>
    <TauxPAS>%s</TauxPAS><TypeTauxPAS>%s</TypeTauxPAS><IdTauxPAS>%s</IdTauxPAS>
  </VersementIndividu>
</individu></bilan>""" % (nir, taux, type_taux, identifiant)


def test_crm_par_code_rubrique():
    res = retours.extraire_taux_pas(_crm_par_code("2910599999999", "0.00", "01", "450189378"))
    assert res["strategie"] == "rubriques codees"
    assert res["releves"] == [{"nir": "2910599999999", "taux": "0.00",
                               "type": "01", "identifiant": "450189378"}]


def test_crm_par_nom_metier():
    res = retours.extraire_taux_pas(_crm_par_nom_metier("1880275999999", "3.50", "01", "450189378"))
    assert res["strategie"] == "noms metier NEODeS"
    assert res["releves"][0]["taux"] == "3.50"
    assert res["releves"][0]["identifiant"] == "450189378"


def test_crm_rattache_les_salaries_par_nir():
    """Le NIR vient de la fiche : le test dit alors que le rattachement marche
    sur NOS donnees, pas seulement que la fonction tourne."""
    res = retours.extraire_taux_pas(_crm_par_code(NIR_F, "0.00", "01", "450189378"))
    ok, orphelins = retours.releves_vers_salaries(ctx, res["releves"])
    assert not orphelins
    assert ok[0]["salarie"] == "PUPPIS"


def test_crm_nir_inconnu_reste_orphelin():
    """Un NIR qu'on ne connait pas n'est jamais rattache au hasard."""
    res = retours.extraire_taux_pas(_crm_par_code("1234567890123", "0.00", "01", "1"))
    ok, orphelins = retours.releves_vers_salaries(ctx, res["releves"])
    assert not ok and len(orphelins) == 1


def test_crm_illisible_ne_pretend_rien():
    res = retours.extraire_taux_pas("<bilan><rien/></bilan>")
    assert res["strategie"] is None and res["releves"] == []


# ------------------------------------------------- CRM 94, LE FORMAT REEL
# Les NIR et le SIRET sont des MARQUEURS : ce depot est public, et un CRM
# porte l'identite fiscale de deux personnes. Ce qui fait foi ici est la
# STRUCTURE -- les balises, leur imbrication, l'identifiant porte par la
# racine -- pas les numeros. Les vrais viennent de la configuration, qui
# n'est pas versionnee, et seulement au moment ou le test tourne.
NIR_F = ctx.salaries["PUPPIS"]["nir"]
NIR_H = ctx.salaries["SIMIONI"]["nir"]

GABARIT_CRM_REEL = """<?xml version="1.0" encoding="UTF-8"?><ns2:rapport xmlns:ns2="http://www.gip-mds.fr/" identifiant="450189378" type="CRM nominatif" profil="DSN" version="v02r01" message="En cas d'absence de taux communique par la DGFIP, le taux applicable est le taux issu des grilles de taux par defaut definies par la loi de finances."><envoi><envoi_identification><idflux>WSUrBZ50Y4RWJdDpsRsh.3r</idflux><version_norme>P26V01</version_norme><point_de_depot>01</point_de_depot><emetteur_siret>12345678900017</emetteur_siret></envoi_identification><envoi_bilan><envoi_etat>OK</envoi_etat></envoi_bilan></envoi><declaration><declaration_identification><rang>1</rang><type>01</type><SIREN>123456789</SIREN><nic_affectation>00016</nic_affectation></declaration_identification><declaration_bilan><etat>OK</etat><declaration_contenu><salaries>2</salaries></declaration_contenu><salarie><NIR>{NIR_H}</NIR><matricule>2</matricule><taux_imposition_PAS>0.00</taux_imposition_PAS></salarie><salarie><NIR>{NIR_F}</NIR><matricule>1</matricule><taux_imposition_PAS>0.00</taux_imposition_PAS></salarie></declaration_bilan></declaration></ns2:rapport>"""

CRM_REEL = GABARIT_CRM_REEL.replace("{NIR_F}", NIR_F).replace("{NIR_H}", NIR_H)


def test_crm_format_reel():
    """CRM DGFiP du 19/08/2026, tel que net-entreprises l'a rendu.

    L'identifiant est un ATTRIBUT DE LA RACINE, partage par tous les salaries du
    compte-rendu. Le `matricule` (1, 2) est interne et ne va nulle part.
    """
    res = retours.extraire_taux_pas(CRM_REEL)
    assert res["strategie"] == "rapport CRM nominatif"
    assert res["releves"] == [
        {"nir": NIR_H, "taux": "0.00", "type": "01", "identifiant": "450189378"},
        {"nir": NIR_F, "taux": "0.00", "type": "01", "identifiant": "450189378"},
    ]


def test_crm_reel_ne_confond_pas_matricule_et_identifiant():
    """Le premier parseur avait rendu « identifiant 1 » et « identifiant 2 ».

    C'etaient les matricules. Ce test verrouille la distinction.
    """
    res = retours.extraire_taux_pas(CRM_REEL)
    identifiants = {r["identifiant"] for r in res["releves"]}
    assert identifiants == {"450189378"}
    assert "1" not in identifiants and "2" not in identifiants


def test_crm_reel_rattache_les_deux_salaries():
    res = retours.extraire_taux_pas(CRM_REEL)
    ok, orphelins = retours.releves_vers_salaries(ctx, res["releves"])
    assert not orphelins
    assert {x["salarie"] for x in ok} == {"PUPPIS", "SIMIONI"}


def test_crm_sans_taux_bascule_sur_le_bareme():
    """Sans taux communique, le rapport le dit : grilles par defaut.

    C'est alors le type 13, et l'identifiant du CRM ne s'applique plus (-1).
    """
    sans_taux = CRM_REEL.replace(
        "<taux_imposition_PAS>0.00</taux_imposition_PAS>", "", 1)
    res = retours.extraire_taux_pas(sans_taux)
    premier = res["releves"][0]
    assert premier["type"] == "13" and premier["identifiant"] == "-1"


def test_crm_archive_reel_si_present():
    """Le fichier reellement telecharge, s'il est encore dans retours/."""
    import glob
    fichiers = glob.glob(str(RACINE / "retours" / "*_nature94_*.xml"))
    if not fichiers:
        return
    res = retours.extraire_taux_pas(pathlib_read(fichiers[0]))
    assert res["strategie"] == "rapport CRM nominatif"
    assert all(r["identifiant"].isdigit() and len(r["identifiant"]) >= 6
               for r in res["releves"])


def pathlib_read(chemin):
    return Path(chemin).read_bytes()


# ----------------------------------------------- historique reellement declare
def test_historique_pas_par_salarie():
    """Avril et mai 2026 : les deux salaries portent des identifiants differents.

    C'est le fait qui a invalide l'ancienne formule (un compteur par depot).
    """
    if not EXPORT_DSN.exists():
        return
    h = pas.historique_par_mois(ctx, EXPORT_DSN)
    assert h[("SIMIONI", "2026-04")]["identifiant"] == "423640633"
    assert h[("PUPPIS", "2026-04")]["identifiant"] == "428811523"
    assert h[("SIMIONI", "2026-05")]["identifiant"] == "423640633"
    assert h[("PUPPIS", "2026-05")]["identifiant"] == "428811523"


def test_historique_pas_type_bareme():
    """Juillet 2021 : type 13 (bareme) et identifiant -1, comme le veut la norme."""
    if not EXPORT_DSN.exists():
        return
    h = pas.historique_par_mois(ctx, EXPORT_DSN)
    e = h[("PUPPIS", "2021-07")]
    assert e["type"] == "13" and e["identifiant"] == "-1"


def test_magasin_pas_amorce():
    """Le magasin est renseigne pour les deux salaries actifs."""
    for cle in ("PUPPIS", "SIMIONI"):
        e = pas.etat(ctx, cle)
        assert e["type"] in pas.TYPES
        assert e["identifiant"]


def test_pas_refuse_de_deviner():
    """Sans taux connu, on leve : on n'invente pas un identifiant fiscal."""
    class Faux:
        racine = CODE / "tests" / "_inexistant"
    try:
        pas.etat(Faux(), "INCONNU")
    except pas.PasInconnu as exc:
        assert "retours" in str(exc)
    else:
        raise AssertionError("PasInconnu attendu")


# ------------------------------------------- fiche de parametrage OC (reelle)
FICHE_AUDIENS = ctx.export / "IP0983-5206445.xml"


def test_fiche_parametrage_audiens():
    """Fichier reel recu d'Audiens le 13/12/2025.

    Il porte la prevoyance intermittents a 1,2300 % au 01/01/2026 - exactement
    la valeur que le moteur avait deduite de 8 contrats, mais ici sourcee et
    datee. La table Audiens etait donc bien telechargeable.
    """
    if not FICHE_AUDIENS.exists():
        return
    f = retours.parse_fiche_parametrage(FICHE_AUDIENS.read_bytes())
    assert f["producteur"] == "AUDIENS-PREVOYANCE"
    groupes = {g["libelle"]: g for g in f["groupes"]}
    etam = groupes["ETAM PREVOYANCE"]
    par_debut = {c["debut"]: c for c in etam["contrats"]}
    assert par_debut["01012026"]["taux"][0]["taux"] == "1.2300"
    assert par_debut["01012025"]["taux"][0]["taux"] == "1.1600"
    casc = groupes["ETAM CASC SVP"]
    assert {c["debut"]: c["taux"][0]["taux"] for c in casc["contrats"]}["01012026"] == "0.5000"


# ------------------------------------------------------- taux accident du travail
def test_taux_at_derive_du_taux_carsat():
    """1,50 % notifie par la CARSAT, 1,05 % applique : abattement de 30 %.

    Arrete du 24 janvier 1975 : les artistes du spectacle cotisent a 70 % des
    taux du regime general (maladie, vieillesse, AT/MP, allocations familiales).
    L'abattement porte sur le taux, pas sur l'assiette, et ne vaut pas pour les
    techniciens. Ce test est le garde-fou de janvier : changer _taux_carsat sans
    recalculer taux_pat le fera echouer.
    """
    import json
    bareme = json.loads((RACINE / "config" / "baremes" / "2026.json")
                        .read_text(encoding="utf-8"))
    at = next(c for c in bareme["rubriques_bulletin"] if c["id"] == "atmp")
    attendu = round(at["_taux_carsat"] * (1 - at["_abattement_artistes"]), 4)
    assert at["taux_pat"] == attendu, (
        "taux_pat %s incoherent avec %s x 70%% = %s"
        % (at["taux_pat"], at["_taux_carsat"], attendu))

    orgs = json.loads((RACINE / "config" / "organismes.json").read_text(encoding="utf-8"))
    # Deux CTP portent un taux AT : 312 pour les artistes (taux abattu) et,
    # depuis le 13/09/2026, 100 pour les techniciens (taux plein CARSAT).
    dans_dsn = {c["code"]: c["taux_at"] for c in orgs["ctp_urssaf"] if c.get("taux_at")}
    assert dans_dsn == {"312": "%05.2f" % at["taux_pat"],
                        "100": "%05.2f" % at["_taux_carsat"]}, (
        "les taux AT de la DSN %s ne suivent pas le bareme (%s abattu, %s plein)"
        % (dans_dsn, at["taux_pat"], at["_taux_carsat"]))


# ------------------------------------------------ cumuls et droits chomage
def test_aem_un_enregistrement_par_ligne():
    """Les AEM sont delimitees par CRLF, pas par offsets fixes de 1000.

    Le decoupage par offsets tombe juste sur le premier enregistrement puis
    derive de 2 octets a chaque suivant : les autres deviennent illisibles et
    disparaissent SANS ERREUR. Ce test verrouille le comptage.
    """
    aout = RACINE / "sorties" / "2026-08"
    if not aout.exists():
        return
    engs = cumul.lire_aem(ctx, aout)
    assert len(engs) == 6, "6 enregistrements attendus, %d lus" % len(engs)
    assert {e.salarie for e in engs} == {"PUPPIS", "SIMIONI"}


def test_heures_equivalentes_additionne_heures_et_cachets():
    """Un contrat peut porter les deux. Le total est la somme, pas l'un ou l'autre."""
    e = cumul.Engagement(salarie="PUPPIS", debut=None, fin=None,
                         numero_objet="266Z06538468", heures=20, cachets=1,
                         jours=6, brut=0)
    assert e.heures_equivalentes == 20 + 12


def test_anniversaire_est_la_fin_de_la_fenetre():
    """Les 507 h se comptent sur les 12 mois PRECEDANT le reexamen."""
    import datetime as dt
    debut, fin, _ = cumul.fenetre_anniversaire(dt.date(2027, 1, 2))
    assert fin == dt.date(2027, 1, 2)
    assert debut == dt.date(2026, 1, 2)


def test_position_droits_utilise_l_anniversaire_configure():
    import datetime as dt
    for cle, attendu in (("SIMIONI", dt.date(2027, 1, 2)),
                         ("PUPPIS", dt.date(2027, 3, 24))):
        assert cumul.anniversaire_configure(ctx, cle) == attendu
        p = cumul.position_droits(ctx, cle,
                                  anniversaire=cumul.anniversaire_configure(ctx, cle))
        assert p.fin == attendu
        assert p.heures_equivalentes == p.heures + p.cachets * 12


def test_tableau_cumul_trois_colonnes():
    """Periode, annee civile, et fenetre des droits avec le reste a acquerir."""
    import datetime as dt
    cols = cumul.tableau_cumul(ctx, "SIMIONI", "2026-08")
    assert [c.titre for c in cols] == ["Periode", "Cumul", "Droits"]
    periode, annee, droits = cols
    # La colonne Droits porte l'echeance et ce qui reste.
    assert droits.echeance == dt.date(2027, 1, 2)
    assert droits.reste == cumul.SEUIL_HEURES - droits.heures_equivalentes
    # Chaque colonne additionne heures et cachets de la meme facon.
    for c in cols:
        assert c.heures_equivalentes == c.heures + c.cachets * 12
    # La periode est incluse dans l'annee.
    assert periode.heures_equivalentes <= annee.heures_equivalentes


def test_tableau_cumul_sans_anniversaire_na_que_deux_colonnes():
    """Sans date notifiee, on n'invente pas de fenetre de droits."""
    cols = cumul.tableau_cumul(ctx, "PERE-CLET", "2026-08")
    assert [c.titre for c in cols] == ["Periode", "Cumul"]


# ------------------------------------------- les heures d'enseignement
# Elles ouvrent les droits, plafonnees, mais n'entrent PAS dans le calcul du
# montant de l'ARE. Un seul compteur annoncerait une allocation trop haute.
def test_le_plafond_d_enseignement_depend_de_l_age_a_la_fin_de_la_fenetre():
    """70 h avant 50 ans, 120 h a partir de 50 ans. L'age est celui de la fin
    du contrat servant a l'ouverture, donc de la fin de la fenetre."""
    import datetime as dt
    ne_en_1980 = dt.date(1980, 6, 15)
    assert cumul.plafond_enseignement(ne_en_1980, dt.date(2026, 9, 10)) == 70
    # Le jour meme des 50 ans : « a partir de 50 ans », donc 120.
    assert cumul.plafond_enseignement(ne_en_1980, dt.date(2030, 6, 15)) == 120
    assert cumul.plafond_enseignement(ne_en_1980, dt.date(2030, 6, 14)) == 70


def test_sans_date_de_naissance_c_est_le_plafond_bas():
    """Sous-estimer se corrige en lisant son releve ; surestimer fait rater un
    reexamen. On retient donc le plafond le plus bas."""
    import datetime as dt
    assert cumul.plafond_enseignement(None, dt.date(2026, 9, 10)) == 70


def test_un_engagement_separe_ce_qui_ouvre_de_ce_qui_paie():
    """L'enseignement est DEDANS les heures declarees, pas en plus : l'AEM les
    a envoyees avec les autres."""
    e = cumul.Engagement(salarie="PUPPIS", debut=None, fin=None,
                         numero_objet="266Z06538468", heures=30, cachets=1,
                         jours=6, brut=0, heures_enseignement=10)
    assert e.heures_equivalentes == 30 + 12      # ce qui est declare
    assert e.heures_montant == 30 + 12 - 10      # ce qui calcule l'ARE


def test_l_enseignement_est_plafonne_dans_le_total_qui_ouvre_les_droits():
    """Au-dela du plafond, les heures restent payees et declarees -- elles
    n'ouvrent simplement plus rien."""
    import datetime as dt
    e = cumul.Engagement(salarie="X", debut=dt.date(2026, 1, 5),
                         fin=dt.date(2026, 1, 20), numero_objet="O",
                         heures=100, cachets=0, jours=10, brut=0,
                         heures_enseignement=100)
    p = cumul.position([e], "X", (dt.date(2026, 1, 1), dt.date(2026, 12, 31),
                                  "essai"), dt.date(1980, 6, 15))
    assert p.heures_equivalentes == 100
    assert p.heures_montant == 0            # aucune heure ne calcule l'ARE
    assert p.heures_enseignement_retenues == 70
    assert p.heures_ouverture == 70
    assert p.enseignement_perdu == 30
    assert p.manque == cumul.SEUIL_HEURES - 70   # et non 507 - 100


def test_le_seuil_regarde_l_ouverture_pas_le_total_declare():
    """Le piege exact : 507 h declarees dont 100 d'enseignement ne font PAS
    507 h de droits, parce que 30 d'entre elles depassent le plafond."""
    import datetime as dt
    e = cumul.Engagement(salarie="X", debut=dt.date(2026, 1, 5),
                         fin=dt.date(2026, 6, 20), numero_objet="O",
                         heures=507, cachets=0, jours=60, brut=0,
                         heures_enseignement=100)
    p = cumul.position([e], "X", (dt.date(2026, 1, 1), dt.date(2026, 12, 31),
                                  "essai"), dt.date(1980, 6, 15))
    assert p.heures_equivalentes == 507
    assert not p.atteint
    assert p.manque == 30


def test_l_enseignement_se_lit_dans_les_paies_par_rubrique():
    """L'AEM ne distingue pas une masterclass d'une heure de plateau : les
    deux sont dans `nb_heures`. C'est le fichier de paie qui sait, parce que
    sa ligne porte une rubrique et que le catalogue dit `compte_pour`."""
    import datetime as dt
    import json
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        (Path(tmp) / "2026-11.json").write_text(json.dumps({
            "mois": "2026-11", "spectacle": "oooh teresina",
            "engagements": [{
                "salarie": "Ana",
                "lignes": [
                    {"rubrique": "cachet", "quantite": 1, "taux": 130.0,
                     "dates": ["2026-11-05", "2026-11-06"]},
                    {"rubrique": "enseignement", "quantite": 6, "taux": 40.0},
                    {"rubrique": "heure", "quantite": 4, "taux": 20.0},
                ]}]}), encoding="utf-8")
        m = cumul.enseignement_par_contrat(ctx, tmp)
    cle = ctx.salarie("Ana")["_cle"]
    # Seule la masterclass compte : les 4 heures de plateau et les 12 h du
    # cachet n'en sont pas.
    assert m == {(cle, dt.date(2026, 11, 5), dt.date(2026, 11, 6)): 6}


def test_lire_aem_va_chercher_l_enseignement_sans_qu_on_le_demande():
    """La faute a ne pas refaire : un appelant qui oublierait de rapprocher
    les paies obtiendrait des heures d'enseignement comptees comme des heures
    de plateau -- une ARE annoncee trop haut, en silence."""
    aout = RACINE / "sorties" / "2026-08"
    if not aout.exists():
        return
    vrai = cumul.enseignement_par_contrat
    temoin = cumul.lire_aem(ctx, aout)[0]
    cle = (temoin.salarie, temoin.debut, temoin.fin)
    cumul.enseignement_par_contrat = lambda _ctx, dossier=None: {cle: 3}
    try:
        engs = cumul.lire_aem(ctx, aout)
    finally:
        cumul.enseignement_par_contrat = vrai
    trouve = [e for e in engs if (e.salarie, e.debut, e.fin) == cle]
    assert trouve and all(e.heures_enseignement == min(3, e.heures)
                          for e in trouve)


def test_le_bulletin_n_imprime_l_enseignement_que_s_il_y_en_a():
    """Une ligne a zero n'apprend rien ; une ligne absente quand il y a des
    heures d'enseignement laisserait croire qu'elles augmentent l'ARE."""
    from decimal import Decimal
    from moteur.bulletin import _bloc_cumul

    sans = cumul.Colonne("Periode", "09/2026", 2, 0, 24, Decimal("260.00"))
    assert "enseignement" not in _bloc_cumul([sans])

    avec = cumul.Colonne("Periode", "09/2026", 2, 6, 30, Decimal("500.00"),
                         enseignement=6, heures_ouverture=24)
    html = _bloc_cumul([avec])
    assert "dont enseignement" in html
    assert "Heures retenues pour les 507 h" in html


def test_l_enseignement_ne_peut_pas_depasser_les_heures_declarees():
    """Si les deux sources se contredisent, l'AEM fait foi : c'est elle qui a
    ete deposee. Sans ce plafonnement, `heures_montant` deviendrait negatif."""
    aout = RACINE / "sorties" / "2026-08"
    if not aout.exists():
        return
    temoin = cumul.lire_aem(ctx, aout)[0]
    cle = (temoin.salarie, temoin.debut, temoin.fin)
    engs = cumul.lire_aem(ctx, aout, enseignement={cle: 9999})
    e = next(x for x in engs if (x.salarie, x.debut, x.fin) == cle)
    assert e.heures_enseignement == e.heures
    assert e.heures_montant >= 0


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("  OK     %s" % nom)
        except AssertionError as exc:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, exc))
    print("\n%s" % ("Tous les tests passent." if not echecs
                    else "%d test(s) en echec." % echecs))
    sys.exit(1 if echecs else 0)
