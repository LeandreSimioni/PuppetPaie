"""La suite de tests se verifie elle-meme.

Deux fautes reelles, trouvees le 10/09/2026, et qui ne se voyaient pas :

  - `test_catalogue.py` n'avait PAS de bloc `if __name__ == "__main__"`.
    Lance seul -- et pytest n'est pas installe ici -- il ne faisait rien et
    sortait 0. Trente-quatre tests comptes comme verts sans avoir tourne.
  - `test_interface.py` avait le sien AU MILIEU du fichier. Il ne voyait que
    les tests definis avant lui, et `sys.exit` sortait avant de definir les
    suivants : sept tests, dont ceux de la saisie par rubrique, ne
    s'executaient jamais.

Un test qui ne tourne pas est pire qu'un test absent : il donne la meme
assurance sans rien verifier. D'ou ces deux gardes.
"""
import ast
import sys
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

FICHIERS = sorted(p for p in (CODE / "tests").glob("test_*.py"))


def _bloc_principal(noeud) -> bool:
    """`if __name__ == "__main__":` -- le lanceur, quelle qu'en soit la forme."""
    if not isinstance(noeud, ast.If):
        return False
    t = noeud.test
    return (isinstance(t, ast.Compare)
            and isinstance(t.left, ast.Name) and t.left.id == "__name__")


def test_chaque_fichier_de_tests_a_son_lanceur():
    """Sans lui, `python tests/test_x.py` ne lance rien et sort 0."""
    assert FICHIERS, "aucun fichier de tests trouve"
    for f in FICHIERS:
        corps = ast.parse(f.read_text(encoding="utf-8")).body
        assert any(_bloc_principal(n) for n in corps), (
            "%s n'a pas de bloc `if __name__ == \"__main__\"` : lance seul, "
            "il ne verifie rien et sort 0." % f.name)


def test_le_lanceur_est_la_derniere_instruction():
    """Place plus haut, il ne voit que les tests definis avant lui -- et les
    suivants ne sont meme pas definis, puisqu'il sort."""
    for f in FICHIERS:
        corps = ast.parse(f.read_text(encoding="utf-8")).body
        i = next(k for k, n in enumerate(corps) if _bloc_principal(n))
        assert i == len(corps) - 1, (
            "%s : le lanceur est en %d-e position sur %d. Les %d instruction(s) "
            "qui le suivent ne s'executent jamais -- deplacer le bloc a la fin."
            % (f.name, i + 1, len(corps), len(corps) - i - 1))


def test_aucun_fichier_de_tests_n_est_vide_de_tests():
    """Un fichier sans `def test_` passerait toujours, en silence."""
    for f in FICHIERS:
        corps = ast.parse(f.read_text(encoding="utf-8")).body
        noms = [n.name for n in corps
                if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")]
        assert noms, "%s ne definit aucun test." % f.name


if __name__ == "__main__":
    echecs = 0
    for nom, fn in sorted(globals().items()):
        if not nom.startswith("test_"):
            continue
        try:
            fn()
            print("  OK     %s" % nom)
        except AssertionError as exc:
            echecs += 1
            print("  ECHEC  %s\n         %s" % (nom, exc))
    print("\n%s" % ("Tous les tests passent." if not echecs
                    else "%d test(s) en echec." % echecs))
    sys.exit(1 if echecs else 0)
