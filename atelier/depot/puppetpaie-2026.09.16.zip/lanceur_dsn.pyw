"""Fenetre de depot de la DSN.

Se lance en double-cliquant sur « Depot DSN.cmd ». Pas de ligne de commande.

Meme regle que pour les retours et la DPAE : le mot de passe est tape ici,
passe au sous-processus par son environnement (jamais par la ligne de commande,
ou il serait visible de tout le systeme), puis efface. Il n'est ecrit nulle
part, et le champ est masque.

CE QUE CETTE FENETRE PEUT FAIRE, DU PLUS INOFFENSIF AU PLUS ENGAGEANT

    Relire            lit le fichier et l'affiche. Aucun reseau, aucun mot de
                      passe. A refaire autant de fois qu'on veut.
    Depot de test     le fichier part code '01' : les vrais controles du vrai
                      point de depot s'executent, un bilan revient, RIEN n'est
                      conserve. C'est le remplacant de DSN-VAL.
    DEPOSER           la declaration part, avec ses ordres de telepaiement.

Le depot reel demande trois gestes, pas un : cocher la case, RECOPIER le mois
declare, et confirmer. Recopier n'est pas confirmer -- on ne recopie pas par
reflexe un mois qu'on n'a pas lu.

LE TROISIEME GESTE A CHANGE LE 11/09/2026, sur decision de Leandre. C'etait
le mot de passe net-entreprises retape ; c'est maintenant, quand le mot de
passe est dans le coffre, une fenetre qui recapitule ce qui va partir et
demande « VOUS ETES SUR ? ». Ce qu'on y perd et ce qu'on y gagne est ecrit
dans moteur/coffre.py -- en un mot : on troque une preuve (celui qui tape
connait le mot de passe) contre une presence (quelqu'un a lu et clique), et la
preuve est reportee a l'ouverture du logiciel, une fois par seance.

Le champ mot de passe reste, et il passe devant le coffre : aucun de ces
chemins n'a ete retire, on en a ajoute un.
"""
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk, scrolledtext

CODE = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE))
from moteur.contexte import racine_donnees, Contexte           # noqa: E402
from moteur import coffre, dsn_api                             # noqa: E402

RACINE = racine_donnees()
VARIABLE = "NET_ENTREPRISES_MOTDEPASSE"

FOND = "#1e1e24"
FOND_CHAMP = "#2a2a33"
TEXTE = "#e8e8ec"
DISCRET = "#9a9aa8"
ACCENT = "#c9a227"
ALERTE = "#d05353"
SUCCES = "#6aa84f"


def fichiers_dsn() -> list:
    """Les DSN produites, de la plus recente a la plus ancienne."""
    return sorted(RACINE.glob("sorties/*/*.dsn"), reverse=True)


class Fenetre(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Depot DSN - Compagnia UEUEUE")
        self.configure(bg=FOND)
        self.minsize(780, 640)
        self.file = queue.Queue()
        self.processus = None
        self._construire()
        self.after(100, self._vider_file)

    # ------------------------------------------------------------- interface
    def _construire(self):
        cadre = tk.Frame(self, bg=FOND, padx=22, pady=18)
        cadre.pack(fill="both", expand=True)

        tk.Label(cadre, text="Depot DSN", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 17, "bold")).pack(anchor="w")
        tk.Label(cadre,
                 text="Transmet une declaration sociale nominative a net-entreprises.\n"
                      "Une DSN deposee ne se retire pas : elle se corrige par une\n"
                      "« annule et remplace », ou par la DSN du mois suivant.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9), justify="left").pack(
                     anchor="w", pady=(4, 16))

        # --- fichier
        tk.Label(cadre, text="Fichier a deposer", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 10)).pack(anchor="w")
        self.fichiers = fichiers_dsn()
        self.choix = ttk.Combobox(
            cadre, state="readonly", width=54, font=("Segoe UI", 10),
            values=[str(f.relative_to(RACINE)) for f in self.fichiers])
        self.choix.pack(anchor="w", pady=(4, 2))
        if self.fichiers:
            self.choix.current(0)
        self.choix.bind("<<ComboboxSelected>>", lambda e: self.relire())
        tk.Label(cadre, text="Produit par : python -m moteur mois paies/AAAA-MM.json",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 14))

        # --- mot de passe
        tk.Label(cadre, text="Mot de passe net-entreprises", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 10)).pack(anchor="w")
        self.mdp = tk.Entry(cadre, show="•", bg=FOND_CHAMP, fg=TEXTE,
                            insertbackground=TEXTE, relief="flat",
                            font=("Segoe UI", 12), width=34)
        self.mdp.pack(anchor="w", ipady=6, pady=(4, 2))
        tk.Label(cadre, text=self._note_mot_de_passe(),
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8),
                 justify="left").pack(anchor="w", pady=(0, 14))

        # --- reel
        self.reel = tk.BooleanVar(value=False)
        tk.Checkbutton(
            cadre, text="Deposer pour de vrai (la declaration part)",
            variable=self.reel, bg=FOND, fg=TEXTE, selectcolor=FOND_CHAMP,
            activebackground=FOND, activeforeground=TEXTE,
            command=self._maj_bouton,
            font=("Segoe UI", 9), anchor="w").pack(anchor="w")

        ligne = tk.Frame(cadre, bg=FOND)
        ligne.pack(anchor="w", padx=(24, 0), pady=(6, 2))
        tk.Label(ligne, text="Recopier le mois declare :", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 9)).pack(side="left")
        self.mois = tk.Entry(ligne, bg=FOND_CHAMP, fg=TEXTE, relief="flat",
                             insertbackground=TEXTE, font=("Consolas", 11),
                             width=10)
        self.mois.pack(side="left", padx=8, ipady=3)
        self.attendu = tk.Label(ligne, text="", bg=FOND, fg=DISCRET,
                                font=("Segoe UI", 9))
        self.attendu.pack(side="left")
        tk.Label(cadre,
                 text="Le mois est lu DANS le fichier. Le recopier a la main est le\n"
                      "dernier garde-fou : c'est le geste qui oblige a l'avoir lu.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8),
                 justify="left").pack(anchor="w", padx=(24, 0), pady=(0, 14))

        # --- boutons
        barre = tk.Frame(cadre, bg=FOND)
        barre.pack(anchor="w", fill="x")
        self.bouton = tk.Button(barre, text="Relire le fichier",
                                command=self.lancer, bg=ACCENT, fg="#20201a",
                                activebackground="#e0b52c", relief="flat",
                                font=("Segoe UI", 11, "bold"), padx=18, pady=8,
                                cursor="hand2")
        self.bouton.pack(side="left")
        self.bouton_test = tk.Button(
            barre, text="Depot de test", command=self.deposer_test,
            bg=FOND_CHAMP, fg=TEXTE, activebackground="#3a3a45", relief="flat",
            font=("Segoe UI", 10), padx=14, pady=8, cursor="hand2")
        self.bouton_test.pack(side="left", padx=8)
        self.bouton_retours = tk.Button(
            barre, text="Voir les retours", command=self.retours,
            bg=FOND_CHAMP, fg=TEXTE, activebackground="#3a3a45", relief="flat",
            font=("Segoe UI", 10), padx=14, pady=8, cursor="hand2")
        self.bouton_retours.pack(side="left")

        # --- sortie
        self.sortie = scrolledtext.ScrolledText(
            cadre, bg="#141418", fg=TEXTE, relief="flat", height=14,
            font=("Consolas", 9), insertbackground=TEXTE, wrap="word")
        self.sortie.pack(fill="both", expand=True, pady=(16, 0))
        self.sortie.tag_config("erreur", foreground=ALERTE)
        self.sortie.tag_config("succes", foreground=SUCCES)
        self.sortie.tag_config("discret", foreground=DISCRET)

        if not self.fichiers:
            self._ecrire("Aucune DSN dans sorties/.\n"
                         "La produire d'abord :  python -m moteur mois "
                         "paies/AAAA-MM.json\n", "erreur")
        else:
            self.relire()

    def _maj_bouton(self):
        self.bouton.config(text="DEPOSER pour de vrai" if self.reel.get()
                           else "Relire le fichier")

    def _mois_attendu(self) -> str:
        """Le mois que le fichier declare. Affiche, jamais pre-rempli."""
        try:
            return dsn_api.lire(RACINE / self._fichier()).mois_lisible
        except Exception:
            return "?"

    # -------------------------------------------------------------- actions
    def relire(self):
        """Aucun reseau, aucun mot de passe : on regarde ce qui partirait."""
        if not self.fichiers:
            return
        self.attendu.config(text="(le fichier dit %s)" % self._mois_attendu())
        self._executer(["depot-dsn", self._fichier(), "--apercu"], None)

    def deposer_test(self):
        """Les vrais controles, sans rien declarer.

        Le fichier bascule en S10.G00.00.005 = '01' au moment de l'envoi ; le
        fichier sur le disque n'est pas touche.
        """
        if not self.fichiers:
            return
        mdp = self.mdp.get()
        if not mdp:
            ctx = Contexte()
            if not coffre.pose(ctx, coffre.NET_ENTREPRISES):
                self._ecrire("\nDepot de test : saisir le mot de passe, ou le "
                             "poser une fois :\n"
                             "    python -m moteur coffre poser net-entreprises\n"
                             "Rien ne sera declare, mais la connexion en a besoin.\n",
                             "erreur")
                return
            # Un essai ne declare rien, mais il TRANSMET et il consomme un
            # numero d'ordre dans la base de test. Il passe donc par la meme
            # porte que le depot : la seance.
            if not coffre.seance(ctx).ouverte and not self._ouvrir_seance(ctx):
                return
        self._executer(["depot-dsn", self._fichier(), "--test"], mdp)
        self.mdp.delete(0, "end")
        del mdp

    def retours(self):
        """Ce que les organismes repondent. C'est la que se lit le verdict."""
        mdp = self.mdp.get()
        if not mdp and not coffre.pose(Contexte(), coffre.NET_ENTREPRISES):
            self._ecrire("\nSaisir le mot de passe pour consulter les retours, "
                         "ou le poser une fois :\n"
                         "    python -m moteur coffre poser net-entreprises\n",
                         "erreur")
            return
        self._executer(["retours"], mdp)
        self.mdp.delete(0, "end")
        del mdp

    def lancer(self):
        if not self.fichiers:
            return
        if not self.reel.get():
            self.relire()
            return
        mois = self.mois.get().strip()
        if not mois:
            self._ecrire("\nDepot reel : recopier le mois declare (%s) dans la "
                         "case.\n" % self._mois_attendu(), "erreur")
            return

        mdp = self.mdp.get()
        if not mdp:
            # Pas de mot de passe tape : le coffre peut fournir, a deux
            # conditions -- qu'il porte le secret, et que la seance soit
            # ouverte. Sinon on le dit, et rien ne part.
            ctx = Contexte()
            if not coffre.pose(ctx, coffre.NET_ENTREPRISES):
                self._ecrire("\nDepot reel : saisir le mot de passe, ou le poser "
                             "une fois pour toutes :\n"
                             "    python -m moteur coffre poser net-entreprises\n",
                             "erreur")
                return
            if not coffre.seance(ctx).ouverte and not self._ouvrir_seance(ctx):
                return
            if not self._confirmer(mois):
                self._ecrire("\nAnnule. Rien n'est parti.\n", "discret")
                return

        self._executer(["depot-dsn", self._fichier(), "--reel",
                        "--confirmer-mois", mois], mdp)
        self.mdp.delete(0, "end")
        del mdp

    # ------------------------------------------------------ les deux fenetres
    def _ouvrir_seance(self, ctx) -> bool:
        """Demande le mot de passe DU LOGICIEL et ouvre la seance.

        C'est la preuve que le depot ne redemande plus a chaque fois : on la
        donne une fois, ici ou a l'ouverture de l'interface, et elle vaut deux
        heures. Voir moteur/coffre.py.
        """
        boite = tk.Toplevel(self)
        boite.title("Ouvrir la seance")
        boite.configure(bg=FOND)
        boite.transient(self)
        boite.grab_set()
        tk.Label(boite, text="Mot de passe PuppetPaie", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=20,
                                                     pady=(18, 2))
        tk.Label(boite,
                 text="Celui du logiciel, pas celui de net-entreprises.\n"
                      "Il ouvre la seance, sans limite de temps :\n"
                      "elle dure tant que cette fenetre est ouverte.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9),
                 justify="left").pack(anchor="w", padx=20)
        champ = tk.Entry(boite, show="*", bg=FOND_CHAMP, fg=TEXTE, relief="flat",
                         insertbackground=TEXTE, font=("Segoe UI", 12), width=28)
        champ.pack(anchor="w", padx=20, pady=12, ipady=6)
        champ.focus_set()
        reponse = {"ok": False}

        def valider():
            try:
                coffre.ouvrir_seance(ctx, champ.get(), proprietaire=os.getpid())
                reponse["ok"] = True
            except coffre.ErreurCoffre as e:
                self._ecrire("\n%s\n" % e, "erreur")
            champ.delete(0, "end")
            boite.destroy()

        champ.bind("<Return>", lambda e: valider())
        barre = tk.Frame(boite, bg=FOND)
        barre.pack(anchor="e", padx=20, pady=(0, 16))
        tk.Button(barre, text="Annuler", command=boite.destroy, bg=FOND_CHAMP,
                  fg=TEXTE, relief="flat", font=("Segoe UI", 10), padx=14,
                  pady=6, cursor="hand2").pack(side="left", padx=6)
        tk.Button(barre, text="Ouvrir", command=valider, bg=ACCENT, fg="#1e1e24",
                  relief="flat", font=("Segoe UI", 10, "bold"), padx=16, pady=6,
                  cursor="hand2").pack(side="left")
        self.wait_window(boite)
        return reponse["ok"]

    def _confirmer(self, mois: str) -> bool:
        """« VOUS ETES SUR ? » -- et ce dont on doit etre sur, ecrit en entier.

        Une confirmation qui ne dit pas CE QU'ELLE confirme ne confirme rien :
        on la clique par reflexe. D'ou le recapitulatif -- type de declaration,
        numero d'ordre, nombre de lignes, et surtout les ordres de telepaiement,
        qui sont la seule partie du depot qui coute de l'argent.
        """
        try:
            a = dsn_api.lire(RACINE / self._fichier())
        except OSError as e:
            self._ecrire("\nFichier illisible : %s\n" % e, "erreur")
            return False

        boite = tk.Toplevel(self)
        boite.title("VOUS ETES SUR ?")
        boite.configure(bg=FOND)
        boite.transient(self)
        boite.grab_set()
        tk.Label(boite, text="VOUS ETES SUR ?", bg=FOND, fg=ALERTE,
                 font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=24,
                                                     pady=(20, 4))
        tk.Label(boite,
                 text="La declaration part maintenant. C'est irreversible :\n"
                      "seule une DSN « annule et remplace » peut la corriger.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9),
                 justify="left").pack(anchor="w", padx=24)

        lignes = [
            ("Fichier", self._fichier()),
            ("Mois declare", a.mois_lisible),
            ("Type", "%s - %s" % (a.type_declaration,
                                  dsn_api.TYPES.get(a.type_declaration, "?"))),
            ("Ordre", "%s   fraction %s" % (a.ordre, a.fraction)),
            ("Contenu", "%d salarie(s), %d lignes" % (a.salaries, a.lignes)),
        ]
        tableau = tk.Frame(boite, bg=FOND)
        tableau.pack(anchor="w", padx=24, pady=14)
        for i, (cle, valeur) in enumerate(lignes):
            tk.Label(tableau, text=cle, bg=FOND, fg=DISCRET,
                     font=("Segoe UI", 9)).grid(row=i, column=0, sticky="w",
                                                padx=(0, 16))
            tk.Label(tableau, text=str(valeur), bg=FOND, fg=TEXTE,
                     font=("Consolas", 10)).grid(row=i, column=1, sticky="w")
        if a.versements:
            tk.Label(boite, text="Ordres de telepaiement", bg=FOND, fg=DISCRET,
                     font=("Segoe UI", 9)).pack(anchor="w", padx=24)
            tk.Label(boite, text="   ".join("%s EUR" % v for v in a.versements),
                     bg=FOND, fg=ACCENT, font=("Consolas", 11, "bold"),
                     wraplength=520, justify="left").pack(anchor="w", padx=24,
                                                          pady=(2, 4))
            tk.Label(boite, text="Ces montants seront preleves par les organismes.",
                     bg=FOND, fg=DISCRET,
                     font=("Segoe UI", 8)).pack(anchor="w", padx=24)

        reponse = {"ok": False}
        barre = tk.Frame(boite, bg=FOND)
        barre.pack(anchor="e", padx=24, pady=18)
        tk.Button(barre, text="Non, annuler", command=boite.destroy, bg=FOND_CHAMP,
                  fg=TEXTE, relief="flat", font=("Segoe UI", 10), padx=16, pady=8,
                  cursor="hand2").pack(side="left", padx=8)

        def oui():
            reponse["ok"] = True
            boite.destroy()

        tk.Button(barre, text="OUI, DEPOSER %s" % mois, command=oui, bg=ALERTE,
                  fg="#ffffff", relief="flat", font=("Segoe UI", 10, "bold"),
                  padx=18, pady=8, cursor="hand2").pack(side="left")
        # Le bouton dangereux ne prend pas le focus : ni Entree ni la barre
        # d'espace ne doivent pouvoir deposer une declaration toutes seules.
        boite.bind("<Escape>", lambda e: boite.destroy())
        self.wait_window(boite)
        return reponse["ok"]

    def _note_mot_de_passe(self) -> str:
        """Ce que le champ demande VRAIMENT, selon ce que le coffre porte."""
        try:
            if coffre.pose(Contexte(), coffre.NET_ENTREPRISES):
                return ("Facultatif : il est dans le coffre, chiffre par ce compte "
                        "Windows.\nCe qui est tape ici passe devant. Sans lui, le "
                        "depot demande le mot de\npasse du LOGICIEL une fois, puis "
                        "une confirmation avant d'envoyer.")
        except Exception:                                         # noqa: BLE001
            pass
        return ("Celui du compte net-entreprises, PAS celui de l'Urssaf (la DPAE).\n"
                "Il n'est ecrit nulle part et disparait a la fermeture de la fenetre.\n"
                "La relecture s'en passe : il n'est demande que pour envoyer.")

    def _fichier(self) -> str:
        return self.choix.get() or str(self.fichiers[0].relative_to(RACINE))

    def _executer(self, args, mdp):
        if self.processus is not None:
            self._ecrire("\nUne commande est deja en cours.\n", "erreur")
            return
        self.sortie.delete("1.0", "end")
        self.bouton.config(state="disabled", text="En cours...")
        self.bouton_test.config(state="disabled")
        self.bouton_retours.config(state="disabled")
        env = dict(os.environ)
        if mdp:
            env[VARIABLE] = mdp
        else:
            env.pop(VARIABLE, None)
        threading.Thread(target=self._travail, args=(args, env),
                         daemon=True).start()

    def _travail(self, args, env):
        exe = sys.executable
        if exe.lower().endswith("pythonw.exe"):
            exe = exe[:-len("pythonw.exe")] + "python.exe"
        try:
            self.processus = subprocess.Popen(
                [exe, "-u", "-m", "moteur"] + args,
                cwd=str(CODE), env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            for ligne in self.processus.stdout:
                self.file.put((ligne, None))
            code = self.processus.wait()
        except Exception as exc:                                  # noqa: BLE001
            self.file.put(("\nEchec du lancement : %s\n" % exc, "erreur"))
            code = 1
        finally:
            env.pop(VARIABLE, None)
            self.processus = None
        self.file.put((None, code))

    def _vider_file(self):
        while True:
            try:
                texte, marque = self.file.get_nowait()
            except queue.Empty:
                break
            if texte is None:
                self.bouton.config(state="normal")
                self.bouton_test.config(state="normal")
                self.bouton_retours.config(state="normal")
                self._maj_bouton()
                if marque == 0:
                    self._ecrire("\nTermine.\n", "succes")
                else:
                    self._ecrire("\nArrete (code %s) - rien n'a ete depose.\n"
                                 % marque, "erreur")
            else:
                self._ecrire(texte, marque)
        self.after(100, self._vider_file)

    def _ecrire(self, texte, marque=None):
        self.sortie.insert("end", texte, marque or ())
        self.sortie.see("end")


if __name__ == "__main__":
    Fenetre().mainloop()
