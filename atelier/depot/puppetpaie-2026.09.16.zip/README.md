# PuppetPaie

Remplacement de CoolPaie (150 €/an) pour les paies d'intermittents de la
Compagnia UEUEUE : bulletins, contrats, DPAE, AEM France Travail, certificats
Congés Spectacles et DSN
mensuelle.

Le calcul n'est pas confié au modèle de langage : il est fait par du code
Python déterministe, calé sur les fichiers réellement déposés depuis 2021.
Claude sert à parler à ce moteur en français, pas à calculer la paie.

## Vérifié contre CoolPaie

| Ce qui est rejoué | Résultat |
|---|---|
| Bulletin PUPPIS juin 2026 (2 cachets, 260 € brut) | identique **au centime** — brut, assiette CSG, 149,66 € patronal, 58,68 € salarial, 201,32 € net, 208,81 € imposable |
| DSN de juillet 2026 (4 contrats, 997 lignes) | **identique ligne pour ligne**, hors le nom du logiciel émetteur |
| DPAE du 28/08/2026 (6 enregistrements) | **identiques octet pour octet** — mais c'est le seul fichier DPAE laissé par CoolPaie, voir docs/ARCHITECTURE.md |
| 10 fichiers AEM V5 de 2026 | **identiques octet pour octet** |
| Schéma AEM sur 189 enregistrements 2021-2026 | validé à 189/189 |

`python -m moteur calibrer` rejoue tout l'historique et affiche ce rapport.

## Venir de CoolPaie : l'import

Ce qui est déjà déclaré ne se ressaisit pas. CoolPaie garde dans son dossier
`export/` les DSN et les AEM qu'il a déposées ; on y lit tout ce qu'il faut
pour démarrer :

```
python -m moteur importer              # l'aperçu : rien n'est écrit
python -m moteur importer --ecrire     # écrit fiches et historique
python -m moteur importer --export "D:\CoolPaie\export" --ecrire
```

Ou, dans l'interface : **Configuration › Importer de CoolPaie**, le même
aperçu, puis un bouton.

| Ce qui est lu | D'où | Ce qui est écrit |
|---|---|---|
| l'entreprise (SIREN, NAF, adresse, IDCC, licence, affiliation CS) | S10 et blocs 06/11/40 des DSN | `config/entreprise.json`, **seulement si la fiche est vide** |
| les salariés (NIR, état civil, adresse, courriel, emploi, PCS, statut) | bloc S21.G00.30 et dernier bloc 40 de la **dernière** DSN où ils figurent | une fiche par NIR inconnu ; une fiche existante n'est **jamais modifiée**, ce que la DSN disait autrement est signalé |
| les spectacles (numéros d'objet) | `S21.G00.40.050` des DSN, et les AEM | une fiche `objet-<numéro>` par numéro inconnu, titre « A COMPLETER » (ni la DSN ni l'AEM ne portent le titre), active seulement si le numéro est de l'année |
| l'historique des contrats (dates, cachets, heures, jours, brut) | chaque enregistrement AEM, dédoublonné | `historique/engagements.json` |

L'import se rejoue sans dommage : ce qui existe est laissé, ce qui manque est
ajouté. La base CoolPaie elle-même (`bases/*.CSOC`) est chiffrée et n'est pas
lue — on n'en a pas besoin.

**Pourquoi l'historique compte.** Les droits à l'assurance chômage (annexes
8 et 10 : 507 h sur 12 mois, un cachet = 12 h) se comptent sur tout ce que la
compagnie a déclaré, et `python -m moteur droits` comme le bloc de cumul du
bulletin lisent **une seule source, la nôtre** : l'historique importé, puis
nos fichiers de paie. Un mois qui a son fichier dans `paies/` est lu là, et
l'historique se tait pour ce mois-là — pendant un double run, rien n'est
compté deux fois. Une fois l'import fait, le logiciel n'a plus besoin du
dossier `export/` de CoolPaie (seul `calibrer`, le rejeu de non-régression,
continue de le lire).

## Faire une paie

Trois façons, au choix — elles font le même travail, avec les mêmes
garde-fous, parce qu'elles appellent toutes `moteur/operations.py`.

**Dans le chat.** « Fais 2 paies pour Ana et Léandre les 2 et 3 octobre 26,
pour Oooh Teresina. » Claude écrit le fichier de saisie, lance le moteur et
rend les fichiers. La compétence `paie` décrit exactement ce qu'il fait.

**Dans l'interface.**

```bash
python -m moteur interface
```

Une page s'ouvre dans le navigateur : le mois, les engagements, l'aperçu
chiffré qui se recalcule à mesure, et la production. Un second écran édite
l'entreprise, les salariés et les spectacles, en vérifiant chaque champ au
format qu'exigent la DSN et l'AEM. Le serveur n'écoute que la machine
(127.0.0.1), sur le port 7331 — fixe, pour que le navigateur reconnaisse le
site `puppetpaie.localhost` et retrouve le mot de passe du logiciel — et exige
un jeton. Les dépôts et les envois se font depuis l'interface, séance ouverte,
mot de passe du logiciel retapé à chaque acte.

**En ligne de commande.**

```bash
python -m moteur nouveau 2026-10
```

Éditer `paies/2026-10.json` (noms, dates, spectacle), puis :

```bash
python -m moteur mois paies/2026-10.json
```

Sortie dans `sorties/2026-10/` :

| Fichier | Où il va |
|---|---|
| `Contrats_Octobre2026.pdf` | à faire signer |
| `DPAE_Octobre2026.txt` (+ `.zip`) | net-entreprises.fr, **avant** le début du contrat |
| `Bulletins_Octobre2026.pdf` | aux artistes |
| `AEM_Octobre2026_EDIV5.txt` | declarationspectacle.francetravail.fr |
| `AEM_Octobre2026_papier.pdf` | aux artistes (attestation employeur mensuelle) |
| `CertificatsCS_Octobre2026.pdf` (+ récapitulatif) | **aux artistes** — congés spectacles ; rien à envoyer à Audiens |
| `DSN_Octobre2026.dsn` | dépôt en test (`depot-dsn --test`), lecture du bilan, puis dépôt réel |

Puis, pour envoyer aux salariés :

```
python -m moteur envoi paies/2026-10.json
```

Un message par salarié — bulletin, certificat Congés Spectacles et AEM papier —
et une page de relecture qui s'ouvre dans le navigateur : chaque message y est
affiché en entier, chaque pièce jointe s'ouvre d'un clic, et rien ne part avant
la confirmation. Les pièces jointes viennent de `sorties/2026-10/envoi/`, où
chaque document est écrit salarié par salarié : le fichier groupé porte la paie
de tout le monde et ne doit jamais partir.

## Le compte Google

L'envoi et l'archivage passent par un compte Google autorisé **une fois** —
plus de mot de passe d'application, plus de SMTP.

```
python -m moteur google autoriser
```

Une fenêtre Google s'ouvre, on choisit son compte, on accepte. C'est tout : pas
de console Google, pas de projet à créer, rien à recopier. Le logiciel embarque
**PuppetPaie**, l'application déclarée une fois par la compagnie, la même pour
tout le monde — comme le font rclone ou gcloud.

```
python -m moteur google etat          # vérifie que l'autorisation tient
python -m moteur google oublier       # efface le jeton local
```

Quatre permissions : **`gmail.send`** (envoyer), **`gmail.readonly`** (lire
la boîte — voir « Le contrat se signe d'un clic » ci-dessous), **`drive.file`**
(écrire dans le Drive, uniquement les fichiers créés par l'application) et
**`userinfo.email`** (connaître l'adresse du compte, pour n'avoir pas à la
demander). Le dépôt en brouillon a été abandonné : il exige `gmail.compose`,
et la page de relecture joue déjà ce rôle. La lecture est la seule permission
*restreinte* au sens de Google ; elle ne sert qu'à retrouver les réponses
« Je signe » par leur code, jamais à parcourir la boîte.

### Le contrat se signe d'un clic

`Demander la signature` envoie le contrat avec un bouton **« Je signe »**. Le
salarié appuie dessus : sa messagerie s'ouvre sur une réponse toute écrite
(« Je soussigné(e)… Code de signature : SIG-XXXXXX »), il l'envoie. À
l'ouverture du logiciel et toutes les vingt minutes ensuite — ou par
`python -m moteur signatures` — la réponse est relevée dans Gmail : le
journal note le contrat **signé, à l'heure du message**, le message est
archivé tel quel dans `sorties/<mois>/envoi/` (`Signature_*.eml`, c'est la
preuve), et le contrat **contresigné** — la case de l'artiste porte qui,
quand, depuis quelle adresse, quel code — scellé contre la modification, lui
est renvoyé aussitôt. Une réponse venue d'une autre adresse que celle de la
fiche est signalée, pas retenue ; un contrat signé à la main se note
toujours d'un clic sur sa pastille.

C'est une signature électronique *simple* (art. 1367 du code civil), pas un
service certifié : le procédé identifie le signataire (son adresse) et le lie
à l'acte (le code, le message gardé).

Le jeton est écrit dans `config/google-jeton.bin`, chiffré par DPAPI — lié au
compte Windows, illisible ailleurs.

Tant que l'application n'est pas passée par la vérification Google, l'écran
« Google n'a pas validé cette application » apparaît la première fois :
*Paramètres avancés* → *Accéder à PuppetPaie…*. La marche à suivre pour la faire
disparaître, et celle pour utiliser sa propre application Google plutôt que la
nôtre, sont en tête de `moteur/google.py`.

## À l'ouverture : le coffre, la sauvegarde, les retours

Depuis le 11/09/2026, le logiciel travaille seul dès qu'on l'ouvre — interface
ou Claude Code, c'est la même fonction :

```bash
python -m moteur ouverture
```

1. il **sauvegarde tout le dossier privé** dans le Drive, par différences :
   seuls les fichiers neufs ou modifiés repartent (comparaison sur l'empreinte
   MD5 que Google publie lui-même) ;
2. il **relève les retours** des organismes et les archive dans `retours/` ;
3. il **relève les signatures** (les réponses « Je signe » dans Gmail) ;
4. une fois par semaine, il **vérifie les sources** des données livrées
   (minima, métiers — voir plus bas) : une source qui a bougé est signalée
   « à relire » jusqu'à ce qu'elle le soit.

L'interface le fait au démarrage puis toutes les 20 minutes
(`--veille MINUTES`, `0` pour une seule fois à l'ouverture), et affiche un
bandeau qui dit où ça en est. Le passage périodique ne touche au réseau que si
quelque chose a bougé sur le disque — sinon il ne coûte rien.

**Une ouverture n'échoue jamais.** Pas de réseau, pas de compte Google, pas de
secret posé : elle le note et rend la main. Une paie se calcule très bien hors
ligne.

### Où mettre les mots de passe

Deux comptes distincts, et un troisième mot de passe qui n'appartient qu'au
logiciel :

```bash
python -m moteur coffre poser net-entreprises   # la DSN
python -m moteur coffre poser urssaf            # la DPAE
python -m moteur coffre ouverture               # le mot de passe PuppetPaie
python -m moteur coffre                         # ce qui est posé, jamais les valeurs
python -m moteur coffre verifier                # ils ouvrent bien une session ?
```

**`--fenetre` si la saisie du terminal ne capture pas tout.** C'est arrivé le
11/09/2026 : la saisie masquée n'a lu qu'un caractère des deux mots de passe,
et la panne n'est ressortie qu'une heure plus tard sous la forme d'un « HTTP
422 » qui ne désignait rien. Le coffre refuse désormais un secret de moins de
six caractères, et `--fenetre` ouvre un champ masqué qui ne dépend pas du
terminal :

```bash
python -m moteur coffre poser net-entreprises --fenetre
```

`coffre verifier` fait **une** tentative d'authentification par compte — jamais
plus : au-delà de quelques échecs, net-entreprises bloque temporairement le
compte.

Chacun se tape dans un champ masqué (`getpass`) : jamais sur la ligne de
commande, où il resterait dans l'historique du shell. Le fichier est
`prive/config/coffre.bin`, **chiffré par DPAPI** — Windows le lie à ce compte
utilisateur, une copie sur une autre machine est illisible. Le mot de passe du
logiciel, lui, n'y est pas : seul son condensé PBKDF2 l'est.

### La séance, et ce qu'elle autorise

Le mot de passe du logiciel ouvre une **séance**. C'est elle, et non un mot de
passe retapé, qui autorise ensuite un dépôt. Elle n'a pas de durée : elle dure
tant que la fenêtre PuppetPaie reste ouverte, et se referme avec elle.

```bash
python -m moteur seance --ouvrir
python -m moteur seance            # ouverte ou fermée
python -m moteur seance --fermer
```

| | sans séance | séance ouverte |
|---|---|---|
| lire, produire, sauvegarder | oui | oui |
| relever les retours | oui | oui |
| déposer une DSN ou une DPAE | **non** | oui, après les trois gestes |

Les trois gestes du dépôt restent : cocher « pour de vrai », **recopier le
mois**, et confirmer dans la fenêtre qui récapitule ce qui va partir, montants
de télépaiement compris. Tant qu'aucun mot de passe du logiciel n'est posé, la
séance est toujours ouverte — on n'invente pas un verrou que personne n'a
demandé, et le dépôt s'en remet à ses trois gestes.

**Ce que ça a coûté, honnêtement.** Avant, aucun mot de passe n'était stocké :
c'était la garantie. Elle a été échangée contre l'autonomie, à la demande de
Léandre. Ce qui la remplace est écrit en tête de `moteur/coffre.py`, et deux
choses sont tenues par des tests : le secret ne sort jamais (ni par `etat()`,
ni en clair sur le disque), et les modules qui parlent au réseau ne peuvent pas
ouvrir le coffre eux-mêmes.

### La sauvegarde

```bash
python -m moteur sauvegarder          # les différences
python -m moteur sauvegarder --point  # où en est la dernière, sans réseau
python -m moteur sauvegarder --tout   # tout renvoyer, sans comparer
```

Vers `PuppetPaie / sauvegarde / …` dans le Drive, en conservant l'arborescence.
Le premier passage monte tout (une quinzaine de minutes pour 16 Mo) ; les
suivants ne coûtent que la comparaison — une dizaine de secondes quand rien n'a
changé.

**Elle ne supprime jamais rien là-bas.** Un fichier effacé ici reste dans le
Drive : une sauvegarde qui répercute les suppressions n'est pas une sauvegarde,
c'est un miroir, et un miroir recopie fidèlement les accidents.

Ne montent jamais : `coffre.bin` et `google-jeton.bin` (des secrets, chiffrés
pour cette machine — ils n'aideraient personne ailleurs), `.seance`,
`.compteurs.verrou`, `.sauvegarde.json`, `.ouverture.json` (de l'état machine,
qui ment ailleurs), et le rebut (`__pycache__`, `*.tmp`).

## Archiver dans le Drive

```
python -m moteur archiver 2026-10
```

Dépose tout `sorties/2026-10/` dans `PuppetPaie / 2026-10` sur le Drive (le
sous-dossier `envoi/` est exclu : ce sont les mêmes documents redécoupés par
salarié, déjà partis par courriel).

Autres commandes : `python -m moteur fiche` (rappel des données de référence),
`python -m moteur calibrer` (non-régression), `python -m moteur interface`.

**Pour un programme.** Toute commande accepte `--json` : même travail, mêmes
garde-fous, sortie lisible par une machine. Les montants y sont des chaînes
(`"201.32"`, jamais un flottant), les dates en `AAAA-MM-JJ`, et une erreur
métier reste une réponse — `{"ok": false, "erreur": {"type": "AudiensManquant",
…}}` — sur laquelle un appelant branche son comportement. C'est par là que
passe l'interface, et que passerait une API.

## La DPAE, séparément

La déclaration préalable à l'embauche est due **avant le premier jour
travaillé**, donc bien avant la paie. Elle se produit seule, sans montant
Audiens et sans consommer de numéro de bulletin :

```bash
python -m moteur dpae paies/2026-09.json --heure 0800
```

Elle dit, pour chaque contrat, si le délai est tenu — la DPAE ne s'envoie que
dans les 8 jours qui précèdent l'embauche.

**Le dépôt.** Deux voies. À la main sur net-entreprises.fr, rubrique DPAE
(dépôt du `.txt`, ou saisie en ligne à partir du `_recapitulatif.txt`). Ou par
l'API de l'Urssaf, en double-cliquant sur **`Depot DPAE.cmd`** : la fenêtre
s'ouvre sur un essai à blanc, montre qui est déclaré, et n'envoie rien tant que
la case n'est pas cochée et le mot de passe pas tapé. C'est le mot de passe qui
vaut confirmation.

En ligne de commande, même chose :

```bash
python -m moteur deposer-dpae sorties/2026-09/DPAE_Septembre2026.txt
```

Sans `--reel`, rien ne part. Avec, il faut recopier le mois : `--reel
--confirmer 2026-09`.

Et il y a un **vrai dépôt de test**, qui parcourt toute la chaîne sans rien
déclarer — bouton « Dépôt de test » dans la fenêtre, ou :

```bash
python -m moteur deposer-dpae sorties/2026-09/DPAE_Septembre2026.txt --test
```

Le champ `C_VERSION` bascule de `120` à `TST` **en mémoire** au moment de
l'envoi ; le fichier sur le disque reste un fichier réel. L'API DPAE ne demande
aucune inscription, seulement un compte en ligne Urssaf. Détail : `../prive/journal/ETAT.md` §7 bis.

## Les retours DSN

Après chaque dépôt, les organismes répondent : accusé, certificat de conformité,
bilans, puis les comptes-rendus métier. Celui de la **DGFiP, nature 94**, porte
le taux de prélèvement à la source de chaque salarié et son identifiant — les
rubriques `S21.G00.50.006/.007/.008`, qui ne se calculent pas.

```bash
python -m moteur retours
```

Ou, sans ligne de commande : **double-cliquer sur `Retours DSN.cmd`**.

Le mot de passe n'est plus demandé si le coffre le porte (`python -m moteur
coffre poser net-entreprises`) : relever les retours est une lecture, et c'est
ce qui permet à l'ouverture de le faire seule. Le champ reste, pour le cas où
aucun coffre n'est posé — et ce qui y est tapé passe devant le coffre.

Sans coffre, en ligne de commande, pour cette fenêtre seulement :

```bash
$env:NET_ENTREPRISES_MOTDEPASSE = (Read-Host "mot de passe net-entreprises")
```

La commande télécharge et archive tout dans `retours/`, puis **affiche** les
taux lus sans rien écrire. Il faut `--appliquer` pour toucher `config/pas.json`.
`python -m moteur pas` montre l'état courant et d'où il vient.

Ce module **ne dépose rien** : il n'a aucune fonction d'envoi. Pour produire une
DSN en envoi de test (`S10.G00.00.005 = 01`, données non conservées) :
`python -m moteur mois paies/2026-09.json --test`.

## Le fichier de saisie

```json
{
  "mois": "2026-10",
  "taux_cachet": 130.0,
  "date_paiement": "2026-10-31",
  "engagements": [
    { "salarie": "Ana", "spectacle": "oooh teresina",
      "lignes": [
        { "rubrique": "cachet", "quantite": 1, "taux": 130,
          "lieu": "Théâtre de la Ville", "dates": ["2026-10-12"] },
        { "rubrique": "cachet", "quantite": 4, "taux": 130,
          "lieu": "Théâtre 71",
          "dates": ["2026-10-14", "2026-10-15", "2026-10-17", "2026-10-18"] }
      ] }
  ]
}
```

**Une ligne de paie porte ses jours et son lieu** : « 4 cachets à 130 € au
Théâtre 71 le 14, 15, 17, 18 ». Deux villes, deux lignes — et c'est **une
seule paie** : même spectacle, donc même numéro d'objet, donc un contrat, un
bulletin, une AEM. Les jours de l'engagement sont la réunion de ceux de ses
lignes. Le contrat groupe les dates par lieu et les nomme toutes ; le lieu ne
se déclare nulle part ailleurs (ni DSN, ni AEM, ni DPAE).

**Une seule écriture, depuis le 13/09/2026.** Un engagement n'a que des
`lignes` ; `dates`, `cachets`, `heures` ou `taux_horaire` posés sur
l'engagement lui-même sont **refusés**, en nommant l'outil qui convertit un
fichier ancien une fois pour toutes :

```bash
python outils/convertir_saisies.py paies/2026-08.json --ecrire
```

(la copie d'avant est gardée dans `paies/avant/`). Un contrat mixte se saisit
avec une ligne `cachet` et une ligne `heure`, chacune à son taux. Le rejeu de
l'historique CoolPaie (`calibrer`) construit ses engagements de la même façon.

Les noms sont tolérants : « Ana », « anastasia », « Lenadre » avec la faute de
frappe, « teresina » — tout est résolu vers la bonne fiche. Un nom ou un
spectacle vraiment inconnu provoque une erreur explicite plutôt qu'une paie
fausse.

Par engagement on peut préciser `debut` / `fin` (si le contrat déborde des
dates jouées), `numero`, `lieu` (celui des lignes qui n'en portent pas),
`date_paiement`, et le **métier** de ce contrat :

```json
{ "salarie": "Ana", "spectacle": "oooh teresina", "metier": "REG120",
  "cadre": true, "lignes": [ … ] }
```

`metier` est un code emploi France Travail. Le catalogue
(`python -m moteur emplois`, 129 métiers du spectacle vivant, `--tous` pour
les 1 236 codes de la nomenclature) le traduit en six champs déclarés —
libellé officiel, PCS-ESE, statut, statut conventionnel, cadre — que
l'engagement peut écrire lui-même par-dessus. Sans `metier`, c'est l'emploi
de la fiche du salarié. Un code inconnu est refusé.

**Les minima conventionnels** (CCN 3090 et CCNEAC 1285, dans
`moteur/minima-conventionnels.json`) sont confrontés à chaque ligne :
cachet et répétition d'un artiste, heure, journée ou semaine d'un technicien.
Une ligne sous le plancher donne un **avertissement, jamais un refus**, sous
la paie dans l'interface et dans `avertissements` en `--json`. Le plancher
dépend de l'annexe de la convention (`annexe_convention` sur la fiche
entreprise : 1 théâtre, 4 tournée…) ; sans elle, ou quand une grille
distingue les jauges, le moteur retient **le plus bas** — il se tait plutôt
que de crier à tort.

**Les sources** de ces données — notices France Travail, nomenclature des
emplois, PCS-ESE de l'Insee, avenants salaires sur Légifrance, NAO — sont
décrites et datées dans `moteur/sources.json`, leurs copies rangées dans
`prive/reference/sources/`. `python -m moteur sources` les liste ;
`--verifier` les retélécharge et dit `inchangee` / `changee` / `injoignable`
(`--relever` pose la nouvelle version à côté, jamais par-dessus).

Légifrance refuse les robots, mais la DILA publie chaque soir en open data
ce qui a bougé dans les conventions collectives (base KALI, une archive de
quelques centaines de Ko, sans compte). Pour les deux textes salaires
(CCN 1285 et 3090), `--verifier` lit ces livraisons depuis le relevé et dit
si la convention a bougé : un texte dont le titre parle de salaires, ou le
texte cité lui-même, met la source « à relire » avec son titre, sa date et
son état (étendu ou non) ; les autres mouvements sont montrés en second.
`--relever` garde le XML du texte touché, qui contient le texte intégral.
La première fois, la lecture remonte l'index (environ un an) jusqu'à la
dernière fiche de chaque convention, pour savoir ensuite rattacher un texte
à la sienne : une minute, une fois. Ce que l'ouverture hebdomadaire refait
toute seule (point 4 ci-dessus).

### Un contrat sur plusieurs mois

Un CDDU signé une fois pour une tournée d'octobre à décembre est **un seul
contrat, saisi dans chacun de ses mois**. Chaque fichier de mois reste
autonome : il porte les cachets joués ce mois-là, et le contrat entier par
ses bornes — `debut`, `fin`, et, dès le deuxième mois, le `numero` que le
premier a déclaré :

```json
paies/2026-10.json   { "salarie": "Ana", "spectacle": "oooh teresina",
                       "debut": "2026-10-12", "fin": "2026-12-20",
                       "lignes": [ …les cachets d'octobre… ] }
paies/2026-11.json   { "salarie": "Ana", "spectacle": "oooh teresina",
                       "debut": "2026-10-12", "fin": "2026-12-20",
                       "numero": "PU1.26.14",
                       "lignes": [ …les cachets de novembre… ] }
```

Le rôle du mois se **déduit** des dates, il ne se saisit pas :

| | contrat imprimé, DPAE | bulletin, DSN | certificat Congés Spectacles |
|---|---|---|---|
| premier mois (`debut` dans le mois) | oui | oui | non |
| mois du milieu | non | oui | non |
| dernier mois (`fin` dans le mois) | non | oui, avec la fin de contrat (bloc 62) | oui, **pour le contrat entier** |

La DSN déclare le même bloc contrat chaque mois (début, numéro, fin
prévisionnelle : ce sont ses identifiants), la période de paie bornée au
mois, et la fin de contrat le dernier mois seulement. Le certificat Congés
Spectacles du dernier mois additionne les cachets et le brut de tous les
mois du contrat, lus dans les fichiers précédents — le seul regard en
arrière du moteur.

**Le numéro se fige à la production** : `produire_mois` réécrit `numero`
dans chaque engagement du fichier produit et pose `numeros_figes: true`.
Le mois suivant le recopie (`python -m moteur nouveau 2026-11 --reprendre`
écrit les contrats en cours dans le fichier neuf, bornes et numéro, à
compléter avec les jours ; dans l'interface, « + reprendre un contrat en
cours »). Un mois du milieu dont le premier mois n'a pas été produit est
refusé : sans numéro connu, le moteur en tirerait un autre.

**Le planning.** Une ligne de paie peut porter, sous `planning`, les jours
des mois *suivants* cochés d'avance — dans l'interface, le calendrier d'une
ligne a une flèche vers le mois suivant, et le premier jour coché là-bas
demande « vous êtes en train de créer un contrat sur plusieurs mois.
Valider ? » :

```json
{ "rubrique": "cachet", "quantite": 3, "taux": 130, "lieu": "Varzy",
  "dates": ["2026-05-12", "2026-05-24", "2026-05-26"],
  "planning": ["2026-06-05", "2026-06-06"] }
```

Le planning n'est pas payé ce mois-ci ; il sert à trois choses : `fin` se
cale sur son dernier jour sans qu'on l'écrive, le contrat imprimé liste
toutes les dates de la tournée (et dit que sa rémunération chiffre le
mois), et « reprendre un contrat en cours » (ou `nouveau --reprendre`)
retrouve, le mois venu, la ligne déjà datée — même rubrique, même taux,
même lieu, quantité = nombre de jours pour un cachet. Un jour de planning
dans le mois est refusé (c'est un jour joué), de même qu'un planning
au-delà d'une `fin` écrite. Sans planning, le contrat imprimé ne connaît
que le mois et renvoie au planning pour la suite — le relire avant
signature.

## Ce qu'il faut vérifier à chaque mois

1. **Le montant Audiens** du bloc `S21.G00.20` de la DSN. C'est un ordre de
   télépaiement, et il n'est **pas calculable** depuis la paie : Audiens facture
   des éléments que la DSN ne détaille pas, et régularise chaque année en avril
   (analyse des 50 DSN de `export/`, voir docs/ARCHITECTURE.md). Il se recopie du
   bordereau :

   ```
   python -m moteur mois paies/2026-09.json --audiens 782.00
   ```

   Sans ce montant, la commande **s'arrête sans rien écrire** et affiche son
   estimation avec sa marge (± 14 €). Pour produire quand même, à vérifier
   avant dépôt : `--audiens-estime`.
2. **La DSN en dépôt de test** (`depot-dsn --test`) avant tout dépôt réel.
   C'est le validateur qui fait foi : la même brique de contrôle que DSN-Val,
   à jour, côté plate-forme (voir `prive/reference/norme-dsn/LISEZMOI.md`).
3. **Le numéro d'objet du spectacle** : France Travail en délivre un nouveau
   chaque année (`216Z…` = 2021 … `266Z…` = 2026). En janvier, demander les
   numéros de l'année et les ajouter dans `config/spectacles.json`.
4. **Les compteurs** de `config/compteurs.json` (numéros de bulletin, de contrat
   et d'attestation AEM) au premier mois d'utilisation réelle : ils ont été
   estimés à partir des dernières sorties CoolPaie, pas lus dans sa base.
   Ils ne sont écrits qu'une fois tous les fichiers du mois produits : un essai,
   un rejeu ou une commande interrompue ne consomme aucun numéro.

## Chaque janvier

Créer `config/baremes/<année>.json` en partant du précédent : SMIC horaire,
taux de cotisations, taux chômage AEM. Puis `python -m moteur calibrer` pour
vérifier que les mois de l'année écoulée se rejouent toujours.

## La version, et la mise à jour dans l'ombre

Le logiciel porte un numéro de version — une date, dans le fichier
`VERSION` — que `python -m moteur version` affiche, comme la fenêtre de
lancement et le bandeau de l'interface.

Chez une compagnie, l'ouverture **cherche une nouvelle version** au dépôt
(`config/maj.json`, clé `depot` : un dossier ou une adresse web ; sinon
l'adresse par défaut du code). Si elle existe, elle est téléchargée dans le
fil de fond (le code compressé fait moins d'un mégaoctet), vérifiée
(condensat), déballée dans `prive/maj/`, et **contrôlée** : le nouveau code
doit s'importer en entier et lire la configuration de la compagnie. Alors
seulement le bandeau dit *« version 2026.09.16 — la 2026.10.02 est prête :
redémarrez PuppetPaie quand vous voulez »*. Rien d'autre ne change : le
logiciel en cours continue.

Au démarrage suivant, la fenêtre de lancement **bascule** avant de lancer
le serveur : ce qui était dans `logiciel/` va dans `logiciel/.avant/`, la
version prête prend sa place. Si quelque chose casse en route, tout revient.
`python -m moteur maj --revenir` reprend la version d'avant.

Pas d'avertissement : un dépôt injoignable, une version qui ne passe pas
le contrôle, c'est un détail dans le rapport d'ouverture, jamais un
incident — une compagnie hors ligne fait sa paie. Une seule chose s'affiche
après coup, une fois : la phrase que la version porte quand elle **change
un calcul** (`--calcul` au moment de publier). Un taux qui change n'en est
pas une : la déclaration est mensuelle, le mois suivant rattrape.

Chez l'éditeur (`config/maj.json`, `"editeur": true`), pas de mise à jour
reçue — c'est lui qui les fabrique, après relecture des sources (voir
plus haut) :

```bash
python -m moteur maj --publier --notes "..." [--calcul "..."]
```

pose l'archive et `derniere.json` dans le dépôt, et refuse de republier un
numéro déjà pris : augmenter `VERSION` d'abord. Le dépôt n'est qu'une
adresse ; le format est le même sur un disque et sur un site.

## Ce que le moteur ne fait pas

- **Régularisations annuelles** (bloc DSN `S21.G00.82`, vu en avril 2026).
- **Arrêts de travail, DSN événementielles, soldes de tout compte.**
- **Déposer sans qu'on le lui demande.** La DSN et la DPAE partent par l'API,
  mais depuis l'interface seulement, sous une séance ouverte, et jamais deux
  fois pour le même mois ou la même embauche. Une déclaration part sous la
  responsabilité de l'employeur. (Plus d'AEM à déposer depuis le 01/06/2026 :
  la compagnie est en 100 % DSN, France Travail édite l'attestation lui-même.)

## Organisation

Le code et les données sont séparés, et c'est structurel : ce dossier-ci est
destiné à un dépôt public, les données ne doivent jamais en approcher.

```
logiciel/                 ← ce dossier : le code, et rien d'autre
  moteur/                 calcul, bulletin, contrat, DPAE, AEM (EDI et papier),
                          certificats CS, DSN, envoi aux salariés, vérification
  moteur/operations*.py   l'orchestration et les garde-fous, communs aux deux
                          faces du logiciel (ligne de commande et interface) :
                          operations.py réexporte neuf modules par domaine
                          (socle, paies, declarations, retours, documents,
                          ouverture, fiches, catalogues, importation)
  moteur/importation.py   la lecture du dossier export/ de CoolPaie
  moteur/sources.py       les sources des données livrées et leur veille ;
  moteur/kali.py          les livraisons open data KALI (conventions collectives)
  moteur/maj.py           la version, et la mise à jour dans l'ombre
  VERSION                 la version du logiciel, une date
  tests/                  393 tests, dont le rejeu de cinq ans de déclarations
  docs/                   ARCHITECTURE.md, RUBRIQUES.md, PORTAGE-RUST.md
  outils/                 verifier_avant_commit.py (garde-fou du depot),
                          convertir_saisies.py, essai_contrat_plurimensuel.py
                          (un contrat fictif sur trois mois, à déposer en test)
  site/                   les pages publiques, à publier sur ueueue.eu
  .claude/                compétences Claude (paie, contrat, declarations)

prive/                    ← à côté, jamais publié
  config/                 entreprise, salariés, spectacles, barèmes, compteurs
  paies/                  fichiers de saisie, un par mois
  historique/             les contrats attestés avant ce logiciel (import CoolPaie)
  sorties/                les fichiers produits
  gabarits/               enregistrements AEM et DPAE réels servant de patrons
  retours/                ce que renvoient les organismes
  reference/              extraits de l'historique CoolPaie
  journal/                ETAT.md — où en est le projet
```

Les commandes s'écrivent depuis `logiciel/` et les chemins de données
s'écrivent comme avant : `paies/2026-10.json` est cherché tel quel, puis sous
`prive/`. Pour installer les données ailleurs, poser `PUPPETPAIE_DONNEES`.

Deux faces, une seule vérité : la ligne de commande et l'interface appellent
toutes deux `moteur/operations.py`, qui porte l'orchestration et les
garde-fous — un nom, neuf fichiers par domaine derrière (`operations_*.py`),
sans qu'un appelant ait à le savoir. Aucun front ne décide quoi que ce soit —
un test le vérifie.

Voir [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) pour le détail des formats et la façon
dont chaque taux a été retrouvé.
