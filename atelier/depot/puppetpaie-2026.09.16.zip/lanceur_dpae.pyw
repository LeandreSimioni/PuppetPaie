"""Fenetre de depot de la DPAE.

Se lance en double-cliquant sur « Depot DPAE.cmd ». Pas de ligne de commande.

Meme regle que pour les retours : le mot de passe est tape ici, passe au
sous-processus par son environnement (jamais par la ligne de commande, ou il
serait visible de tout le systeme), puis efface. Il n'est ecrit nulle part.

La difference : cette fenetre-ci ENVOIE. Elle s'ouvre donc sur l'essai a
blanc, qui n'envoie rien, et le depot reel demande deux gestes -- cocher la
case, et taper le mot de passe. C'est le mot de passe qui vaut confirmation.
"""
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk, scrolledtext

# Le code d'un cote, les donnees de l'autre : cette fenetre lit les flux
# produits (prive/sorties) mais lance le moteur depuis le code (logiciel/).
CODE = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE))
from moteur.contexte import racine_donnees, Contexte           # noqa: E402
from moteur import coffre                                      # noqa: E402
RACINE = racine_donnees()
VARIABLE = "URSSAF_MOTDEPASSE"     # compte Urssaf, pas net-entreprises

FOND = "#1e1e24"
FOND_CHAMP = "#2a2a33"
TEXTE = "#e8e8ec"
DISCRET = "#9a9aa8"
ACCENT = "#c9a227"
ALERTE = "#d05353"
SUCCES = "#6aa84f"


def fichiers_dpae() -> list:
    """Les flux DPAE produits, du plus recent au plus ancien."""
    trouves = sorted(RACINE.glob("sorties/*/DPAE_*.txt"), reverse=True)
    # Le recapitulatif porte le meme prefixe : c'est un aide-memoire pour la
    # saisie en ligne, pas un flux. Il ne doit pas pouvoir etre depose.
    return [f for f in trouves if not f.stem.endswith("_recapitulatif")]


def mois_du_fichier(chemin: Path) -> str:
    """AAAA-MM des embauches contenues, lu dans le fichier lui-meme."""
    try:
        from moteur import dpae
        mois = sorted({"%s-%s" % (e["date_embauche"][4:], e["date_embauche"][2:4])
                       for e in dpae.relire(chemin)
                       if e["date_embauche"].isdigit()})
        if len(mois) == 1:
            return mois[0]
    except Exception:
        pass
    return chemin.parent.name          # sorties/AAAA-MM/


class Fenetre(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Depot DPAE - Compagnia UEUEUE")
        self.configure(bg=FOND)
        self.minsize(760, 580)
        self.file = queue.Queue()
        self.processus = None
        self._construire()
        self.after(100, self._vider_file)

    # ------------------------------------------------------------- interface
    def _construire(self):
        cadre = tk.Frame(self, bg=FOND, padx=22, pady=18)
        cadre.pack(fill="both", expand=True)

        tk.Label(cadre, text="Depot DPAE", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 17, "bold")).pack(anchor="w")
        tk.Label(cadre,
                 text="Depose une declaration prealable a l'embauche aupres de l'Urssaf.\n"
                      "Elle est due AVANT le premier jour travaille, et au plus tot huit\n"
                      "jours avant. Une DPAE deposee ne se retire pas.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9), justify="left").pack(
                     anchor="w", pady=(4, 16))

        # --- fichier
        tk.Label(cadre, text="Fichier a deposer", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 10)).pack(anchor="w")
        self.fichiers = fichiers_dpae()
        self.choix = ttk.Combobox(
            cadre, state="readonly", width=52, font=("Segoe UI", 10),
            values=[str(f.relative_to(RACINE)) for f in self.fichiers])
        self.choix.pack(anchor="w", pady=(4, 2))
        if self.fichiers:
            self.choix.current(0)
        self.choix.bind("<<ComboboxSelected>>", lambda e: self.voir())
        tk.Label(cadre, text="Produit par : python -m moteur dpae paies/AAAA-MM.json",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8)).pack(anchor="w", pady=(0, 14))

        # --- mot de passe
        tk.Label(cadre, text="Mot de passe URSSAF", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 10)).pack(anchor="w")
        self.mdp = tk.Entry(cadre, show="•", bg=FOND_CHAMP, fg=TEXTE,
                            insertbackground=TEXTE, relief="flat",
                            font=("Segoe UI", 12), width=34)
        self.mdp.pack(anchor="w", ipady=6, pady=(4, 2))
        tk.Label(cadre,
                 text="Celui du compte Urssaf, PAS celui de net-entreprises (la DSN).\n"
                      "Il n'est ecrit nulle part et disparait a la fermeture de la fenetre.\n"
                      "L'essai a blanc s'en passe : il n'est demande que pour envoyer.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8),
                 justify="left").pack(anchor="w", pady=(0, 14))

        # --- casse du mot de passe
        self.majuscules = tk.BooleanVar(value=False)
        tk.Checkbutton(
            cadre, text="Forcer le mot de passe en MAJUSCULES",
            variable=self.majuscules, bg=FOND, fg=TEXTE, selectcolor=FOND_CHAMP,
            activebackground=FOND, activeforeground=TEXTE,
            font=("Segoe UI", 9), anchor="w").pack(anchor="w")
        tk.Label(cadre,
                 text="A laisser decoche : le mot de passe part tel qu'il est tape,\n"
                      "c'est ce qui fonctionne sur ce compte (verifie le 04/09/2026).",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8),
                 justify="left").pack(anchor="w", padx=(24, 0), pady=(0, 14))

        # --- reel
        self.reel = tk.BooleanVar(value=False)
        tk.Checkbutton(
            cadre, text="Deposer pour de vrai aupres de l'Urssaf",
            variable=self.reel, bg=FOND, fg=TEXTE, selectcolor=FOND_CHAMP,
            activebackground=FOND, activeforeground=TEXTE,
            command=self._maj_bouton,
            font=("Segoe UI", 9), anchor="w").pack(anchor="w")
        tk.Label(cadre,
                 text="Decoche : essai a blanc. Le fichier est relu et affiche, rien ne part.\n"
                      "A laisser decoche tant qu'on n'a pas lu la liste des personnes declarees.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8),
                 justify="left").pack(anchor="w", padx=(24, 0), pady=(0, 14))

        # --- boutons
        barre = tk.Frame(cadre, bg=FOND)
        barre.pack(anchor="w", fill="x")
        self.bouton = tk.Button(barre, text="Voir ce qui partirait",
                                command=self.lancer, bg=ACCENT, fg="#20201a",
                                activebackground="#e0b52c", relief="flat",
                                font=("Segoe UI", 11, "bold"), padx=18, pady=8,
                                cursor="hand2")
        self.bouton.pack(side="left")
        self.bouton_test = tk.Button(
            barre, text="Tester la connexion", command=self.tester,
            bg=FOND_CHAMP, fg=TEXTE, activebackground="#3a3a45", relief="flat",
            font=("Segoe UI", 10), padx=14, pady=8, cursor="hand2")
        self.bouton_test.pack(side="left", padx=8)
        self.bouton_blanc = tk.Button(
            barre, text="Depot de test", command=self.deposer_test,
            bg=FOND_CHAMP, fg=TEXTE, activebackground="#3a3a45", relief="flat",
            font=("Segoe UI", 10), padx=14, pady=8, cursor="hand2")
        self.bouton_blanc.pack(side="left")

        # --- sortie
        self.sortie = scrolledtext.ScrolledText(
            cadre, bg="#141418", fg=TEXTE, relief="flat", height=14,
            font=("Consolas", 9), insertbackground=TEXTE, wrap="word")
        self.sortie.pack(fill="both", expand=True, pady=(16, 0))
        self.sortie.tag_config("erreur", foreground=ALERTE)
        self.sortie.tag_config("succes", foreground=SUCCES)
        self.sortie.tag_config("discret", foreground=DISCRET)

        if not self.fichiers:
            self._ecrire("Aucun fichier DPAE dans sorties/.\n"
                         "Le produire d'abord :  python -m moteur dpae "
                         "paies/AAAA-MM.json\n", "erreur")
        else:
            self.voir()

    def _maj_bouton(self):
        self.bouton.config(text="DEPOSER pour de vrai" if self.reel.get()
                           else "Voir ce qui partirait")

    # -------------------------------------------------------------- actions
    def voir(self):
        """Essai a blanc, sans mot de passe : montre le contenu du fichier."""
        if not self.fichiers:
            return
        self._executer(["deposer-dpae", self._fichier()], None)

    def tester(self):
        """Ouvre une session et s'arrete la. Rien n'est declare.

        C'est le bouton de test de connexion MtoM de CoolPaie. Il repond a la
        seule question qui bloque aujourd'hui : est-ce que le compte passe ?
        """
        mdp = self.mdp.get()
        if not mdp and not coffre.pose(Contexte(), coffre.URSSAF):
            self._ecrire("\nSaisir le mot de passe Urssaf pour tester la "
                         "connexion, ou le poser une fois :\n"
                         "    python -m moteur coffre poser urssaf\n"
                         "Le test n'envoie aucune declaration.\n", "erreur")
            return
        self._executer(["tester-dpae"] + self._casse(), mdp)
        self.mdp.delete(0, "end")
        del mdp

    def deposer_test(self):
        """Depot de TEST : la chaine complete, sans rien declarer.

        C_VERSION bascule en TST au moment de l'envoi (FAQ Urssaf : les depots
        de test se font sur le service de production). Le fichier sur le disque
        n'est pas touche.
        """
        if not self.fichiers:
            return
        mdp = self.mdp.get()
        if not mdp:
            ctx = Contexte()
            if not coffre.pose(ctx, coffre.URSSAF):
                self._ecrire("\nDepot de test : saisir le mot de passe Urssaf, "
                             "ou le poser une fois :\n"
                             "    python -m moteur coffre poser urssaf\n"
                             "Rien ne sera declare.\n", "erreur")
                return
            if not coffre.seance(ctx).ouverte and not self._ouvrir_seance(ctx):
                return
        self._executer(["deposer-dpae", self._fichier(), "--test"] + self._casse(),
                       mdp)
        self.mdp.delete(0, "end")
        del mdp

    def _casse(self) -> list:
        return ["--majuscules"] if self.majuscules.get() else []

    def lancer(self):
        if not self.fichiers:
            return
        if not self.reel.get():
            self.voir()
            return
        chemin = Path(self._fichier())
        mois = mois_du_fichier(RACINE / chemin)
        mdp = self.mdp.get()
        if not mdp:
            ctx = Contexte()
            if not coffre.pose(ctx, coffre.URSSAF):
                self._ecrire("\nDepot reel : saisir le mot de passe Urssaf, ou "
                             "le poser une fois :\n"
                             "    python -m moteur coffre poser urssaf\n", "erreur")
                return
            if not coffre.seance(ctx).ouverte and not self._ouvrir_seance(ctx):
                return
            if not self._confirmer(mois):
                self._ecrire("\nAnnule. Rien n'est parti.\n", "discret")
                return
        args = ["deposer-dpae", self._fichier(), "--reel", "--confirmer",
                mois] + self._casse()
        self._executer(args, mdp)
        self.mdp.delete(0, "end")          # efface des que c'est parti
        del mdp

    # ------------------------------------------------------ les deux fenetres
    def _ouvrir_seance(self, ctx) -> bool:
        """Le mot de passe DU LOGICIEL, une fois, qui autorise ensuite le depot.

        Meme mecanique que la fenetre DSN -- et le meme coffre : la seance est
        commune aux deux, parce que c'est la presence de la personne qu'elle
        atteste, pas le compte d'un organisme. Voir moteur/coffre.py.
        """
        boite = tk.Toplevel(self)
        boite.title("Ouvrir la seance")
        boite.configure(bg=FOND)
        boite.transient(self)
        boite.grab_set()
        tk.Label(boite, text="Mot de passe PuppetPaie", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=20,
                                                     pady=(18, 2))
        tk.Label(boite,
                 text="Celui du logiciel, pas celui de l'Urssaf.\n"
                      "Il ouvre la seance, sans limite de temps :\n"
                      "elle dure tant que cette fenetre est ouverte.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9),
                 justify="left").pack(anchor="w", padx=20)
        champ = tk.Entry(boite, show="*", bg=FOND_CHAMP, fg=TEXTE, relief="flat",
                         insertbackground=TEXTE, font=("Segoe UI", 12), width=28)
        champ.pack(anchor="w", padx=20, pady=12, ipady=6)
        champ.focus_set()
        reponse = {"ok": False}

        def valider():
            try:
                coffre.ouvrir_seance(ctx, champ.get(), proprietaire=os.getpid())
                reponse["ok"] = True
            except coffre.ErreurCoffre as e:
                self._ecrire("\n%s\n" % e, "erreur")
            champ.delete(0, "end")
            boite.destroy()

        champ.bind("<Return>", lambda e: valider())
        barre = tk.Frame(boite, bg=FOND)
        barre.pack(anchor="e", padx=20, pady=(0, 16))
        tk.Button(barre, text="Annuler", command=boite.destroy, bg=FOND_CHAMP,
                  fg=TEXTE, relief="flat", font=("Segoe UI", 10), padx=14,
                  pady=6, cursor="hand2").pack(side="left", padx=6)
        tk.Button(barre, text="Ouvrir", command=valider, bg=ACCENT, fg="#1e1e24",
                  relief="flat", font=("Segoe UI", 10, "bold"), padx=16, pady=6,
                  cursor="hand2").pack(side="left")
        self.wait_window(boite)
        return reponse["ok"]

    def _confirmer(self, mois: str) -> bool:
        """« VOUS ETES SUR ? », avec QUI est declare -- pas seulement combien.

        Une DPAE nomme des personnes et une date d'embauche : c'est cela qu'il
        faut relire avant d'envoyer, pas un total. La fenetre les liste.
        """
        from moteur import dpae as _dpae
        try:
            enregistrements = _dpae.relire(RACINE / self._fichier())
        except Exception as e:                                    # noqa: BLE001
            self._ecrire("\nFichier illisible : %s\n" % e, "erreur")
            return False

        boite = tk.Toplevel(self)
        boite.title("VOUS ETES SUR ?")
        boite.configure(bg=FOND)
        boite.transient(self)
        boite.grab_set()
        tk.Label(boite, text="VOUS ETES SUR ?", bg=FOND, fg=ALERTE,
                 font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=24,
                                                     pady=(20, 4))
        tk.Label(boite,
                 text="Ces embauches sont declarees a l'Urssaf maintenant.\n"
                      "Une DPAE deposee ne se retire pas.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9),
                 justify="left").pack(anchor="w", padx=24)
        tk.Label(boite, text="%s   -   mois %s   -   %d declaration(s)"
                             % (self._fichier(), mois, len(enregistrements)),
                 bg=FOND, fg=TEXTE, font=("Consolas", 10)).pack(anchor="w",
                                                                padx=24, pady=(12, 6))
        for e in enregistrements[:12]:
            j = e["date_embauche"]
            tk.Label(boite, text="   %s %s   embauche le %s/%s/%s a %sh%s"
                                 % (e["nom"].strip(), e["prenom"].strip(),
                                    j[:2], j[2:4], j[4:],
                                    e["heure_embauche"][:2], e["heure_embauche"][2:]),
                     bg=FOND, fg=TEXTE,
                     font=("Consolas", 9)).pack(anchor="w", padx=24)
        if len(enregistrements) > 12:
            tk.Label(boite, text="   ... et %d autre(s)" % (len(enregistrements) - 12),
                     bg=FOND, fg=DISCRET,
                     font=("Segoe UI", 9)).pack(anchor="w", padx=24)

        reponse = {"ok": False}
        barre = tk.Frame(boite, bg=FOND)
        barre.pack(anchor="e", padx=24, pady=18)
        tk.Button(barre, text="Non, annuler", command=boite.destroy, bg=FOND_CHAMP,
                  fg=TEXTE, relief="flat", font=("Segoe UI", 10), padx=16, pady=8,
                  cursor="hand2").pack(side="left", padx=8)

        def oui():
            reponse["ok"] = True
            boite.destroy()

        tk.Button(barre, text="OUI, DECLARER", command=oui, bg=ALERTE,
                  fg="#ffffff", relief="flat", font=("Segoe UI", 10, "bold"),
                  padx=18, pady=8, cursor="hand2").pack(side="left")
        boite.bind("<Escape>", lambda e: boite.destroy())
        self.wait_window(boite)
        return reponse["ok"]

    def _fichier(self) -> str:
        return self.choix.get() or str(self.fichiers[0].relative_to(RACINE))

    def _executer(self, args, mdp):
        if self.processus is not None:
            self._ecrire("\nUne commande est deja en cours.\n", "erreur")
            return
        self.sortie.delete("1.0", "end")
        self.bouton.config(state="disabled", text="En cours...")
        self.bouton_test.config(state="disabled")
        self.bouton_blanc.config(state="disabled")
        env = dict(os.environ)
        if mdp:
            env[VARIABLE] = mdp
        else:
            env.pop(VARIABLE, None)
        threading.Thread(target=self._travail, args=(args, env),
                         daemon=True).start()

    def _travail(self, args, env):
        exe = sys.executable
        if exe.lower().endswith("pythonw.exe"):
            exe = exe[:-len("pythonw.exe")] + "python.exe"
        try:
            self.processus = subprocess.Popen(
                [exe, "-u", "-m", "moteur"] + args,
                cwd=str(CODE), env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            for ligne in self.processus.stdout:
                self.file.put((ligne, None))
            code = self.processus.wait()
        except Exception as exc:                                  # noqa: BLE001
            self.file.put(("\nEchec du lancement : %s\n" % exc, "erreur"))
            code = 1
        finally:
            env.pop(VARIABLE, None)
            self.processus = None
        self.file.put((None, code))

    def _vider_file(self):
        while True:
            try:
                texte, marque = self.file.get_nowait()
            except queue.Empty:
                break
            if texte is None:
                self.bouton.config(state="normal")
                self.bouton_test.config(state="normal")
                self.bouton_blanc.config(state="normal")
                self._maj_bouton()
                if marque == 0:
                    self._ecrire("\nTermine.\n", "succes")
                else:
                    self._ecrire("\nArrete (code %s) - rien n'a ete depose.\n"
                                 % marque, "erreur")
            else:
                self._ecrire(texte, marque)
        self.after(100, self._vider_file)

    def _ecrire(self, texte, marque=None):
        self.sortie.insert("end", texte, marque or ())
        self.sortie.see("end")


if __name__ == "__main__":
    Fenetre().mainloop()
