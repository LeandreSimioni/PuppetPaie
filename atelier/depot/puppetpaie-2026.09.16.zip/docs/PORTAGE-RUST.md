# Porter le moteur en Rust — la carte

Document de travail, écrit le 05/09/2026 après lecture ligne à ligne de
`moteur/calcul.py`, `moteur/cumul.py`, `moteur/plafond.py`, `moteur/util.py`,
`moteur/contexte.py` et de `config/baremes/2026.json`.

Il ne remplace pas `prive/journal/ETAT.md`, qui reste le document de reprise. Il répond à une
seule question : **qu'est-ce qu'on tape, dans quel ordre, pour que la phase 1 du
portage — `calcul` et les barèmes — soit finie et prouvée.**

Le cap et les raisons du portage sont fixés ailleurs (binaire de 10 à 15 Mo,
sans runtime, dépôt public en Rust seulement, janvier 2027). Ici on ne discute
que du comment.

---

> ## Cette carte est périmée — lu le 13/09/2026
>
> Elle décrit le moteur tel qu'il était le 05/09. Depuis, huit jours ont
> changé ce qu'elle cartographie, et pas à la marge :
>
> - **les rubriques** : le calcul se fait rubrique par rubrique, depuis un
>   catalogue livré (`moteur/rubriques-base.json`, `catalogue.py`), plus par
>   une formule unique ;
> - **une seule écriture** : un engagement n'a plus que des `lignes` ;
>   `cachets`, `heures`, `taux_horaire` et `dates` sur l'engagement ont
>   disparu (§4.1 de cette carte est faux) ;
> - **les fiches datées** : une valeur déclarée ne s'écrase pas, elle descend
>   dans `historique` avec sa date de fin (`contexte.telle_qu_au`) — le §10
>   ne le prévoyait pas ;
> - **technicien et cadre** : RGDU sur les techniciens, statut cadre combiné,
>   DFS en option de fiche — le §4 ne connaissait que l'artiste ;
> - **métiers et minima** : `emplois.py`, `minima.py` et leurs données, qui
>   entrent dans `charger` ;
> - **`operations.py`** est devenu une façade sur neuf modules (le neuvième, `operations_importation`, le 15/09).
>
> **Le portage ne commence pas avant qu'un mois complet ait été produit,
> déposé et passé (DSN et DPAE acceptées) sans une seule modification de
> `calcul.py`, `cumul.py` ni `dsn.py`.** Tant qu'un mois réel oblige à
> toucher l'un des trois, l'oracle bouge, et porter un oracle qui bouge c'est
> porter deux fois. Au rythme d'un mois par mois, ce sera octobre ou novembre
> 2026. Ce jour-là, **réécrire cette carte d'abord** — nouvelle lecture ligne
> à ligne, nouveaux corpus du §9 (les saisies en `lignes`, les bulletins 2026
> avec technicien et cadre) — puis taper. Ce qui reste juste ici : le §0
> (l'état de la machine, à revérifier), le §1 (le principe de l'oracle), le
> §2 (l'arithmétique), le §3 (les dates), et le §9 (la méthode différentielle).

---

## 0. L'état de la machine — vérifié aujourd'hui

Deux surprises, une bonne et une mauvaise :

| | |
|---|---|
| `rustup`, `cargo`, `rustc` | **installés** — `rustc 1.98.1`, toolchain `stable-x86_64-pc-windows-msvc`, posés à 21h06 le 05/09 |
| L'éditeur de liens | **absent**. `rustc` compile puis échoue au `link.exe` : les Build Tools MSVC (« C++ build tools ») ne sont pas sur la machine |

Donc rien ne se compile aujourd'hui, et c'est le seul point qui exige du wifi.

**Deux chemins, et le second est dix fois plus léger.**

1. La chaîne MSVC, celle que rustup a choisie par défaut :

   ```
   winget install Microsoft.VisualStudio.2022.BuildTools --override "--quiet --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
   ```

   Plusieurs gigaoctets. C'est ce que la mémoire du projet avait anticipé.

2. La chaîne GNU, que rustup fournit **avec son propre éditeur de liens**
   (composant `rust-mingw`) :

   ```
   rustup toolchain install stable-x86_64-pc-windows-gnu
   rustup default stable-x86_64-pc-windows-gnu
   ```

   Quelques centaines de mégaoctets, et cela suffit tant que **toutes** les
   dépendances sont du Rust pur — ce qui est le cas de la phase 1, et ce qui
   est de toute façon un objectif du projet.

**À essayer dans cet ordre : la 2, puis la 1 seulement si le lien échoue.**
La cible MSVC restera préférable le jour d'une diffusion publique (binaire sans
dépendance à la libc MinGW) ; ce jour n'est pas aujourd'hui.

Troisième chose à faire pendant qu'il y a du réseau, et qu'on oublie toujours :

```
cargo fetch          # puis, une fois le Cargo.toml stabilisé :
cargo vendor
```

Après quoi `cargo build --offline` fonctionne sans réseau. Sur un forfait
limité, tout le reste du portage peut se faire hors ligne.

---

## 1. Le principe : le Python devient l'oracle, pas l'ancêtre

Le Rust **lit les mêmes fichiers** : `config/*.json`, `config/baremes/*.json`,
`paies/AAAA-MM.json`. Aucune migration, aucun format nouveau. C'est déjà écrit
dans la mémoire du projet, et c'est ce qui rend la preuve gratuite :

> dès que le core existe, le double run de septembre et octobre devient un
> **triple run** — CoolPaie, Python, Rust.

Il y a donc trois niveaux de vérité, et il faut les garder distincts :

| Niveau | Ce qu'il prouve |
|---|---|
| CoolPaie (`export/`, 50 DSN, 189 AEM, les bulletins PDF) | la **spécification**. Cinq ans de déclarations acceptées. |
| Python (`moteur/`) | l'**oracle**. Il reproduit CoolPaie au centime, c'est établi. |
| Rust | doit reproduire **le Python**, chiffre pour chiffre. |

Conséquence de méthode : le Rust ne se compare **jamais** directement à
CoolPaie en phase 1. Il se compare au Python, qui a déjà payé le prix de la
rétro-ingénierie. Un écart Rust/Python est un bug de portage ; un écart
Python/CoolPaie serait une découverte, et il n'y en a plus à faire ici.

---

## 2. `util.py` — l'arithmétique, et le seul vrai piège du portage

Trois fonctions portent tout le reste :

```python
CENT = Decimal("0.01")
def eur(x):        return Decimal(str(x)).quantize(CENT, rounding=ROUND_HALF_UP)
def pct(base, tx): return eur(Decimal(str(base)) * Decimal(str(tx)) / Decimal(100))
```

**L'arrondi est au demi supérieur, jamais au pair.** Vérifié sur les 144 cas
ambigus de l'historique, 144/144. En Rust : `rust_decimal`, et
`round_dp_with_strategy(2, RoundingStrategy::MidpointAwayFromZero)`.
`MidpointNearestEven` est le défaut de beaucoup de bibliothèques : c'est
exactement l'erreur à ne pas faire.

**Le piège, c'est le `str(x)`.** Python ne convertit jamais un flottant en
`Decimal` directement : il passe par sa représentation textuelle. `0.9825`,
`1.115`, `2.836` lus dans le JSON sont des `float` ; `Decimal(str(1.115))` vaut
**exactement** `1.115`, alors que `Decimal(1.115)` vaudrait
`1.1149999999999999911182158029987`. Sur une base de 260 € la différence ne se
voit pas ; sur un montant qui tombe pile sur un demi-centime, elle change le
centime, et elle le change **en silence**.

Recette Rust :

- lire les nombres du barème comme du **texte**, pas comme des `f64` ;
- activer `serde_json/arbitrary_precision`, qui conserve le littéral tel qu'il
  est écrit dans le fichier, puis `Decimal::from_str(nombre.as_str())` ;
- écrire un désérialiseur `Taux(Decimal)` qui accepte indifféremment un nombre
  JSON et une chaîne, pour que le barème reste éditable à la main comme
  aujourd'hui.

Un test doit figer cela : **chaque valeur numérique de `2026.json` reparsée en
Rust doit être égale à la `Decimal` que Python en tire.** C'est vingt lignes, et
c'est le test qui empêche de chercher un centime pendant une soirée.

Le reste de `util.py` (`fmt_eur`, `fmt_taux`, `sans_accent`, `cle_recherche`,
les formats de date) est du confort d'affichage et de saisie ; ça se porte
mécaniquement, ça ne se prouve pas.

---

## 3. Les dates : les écrire nous-mêmes

Le moteur a besoin de très peu : analyser quatre ou cinq formats
(`AAAA-MM-JJ`, `JJ/MM/AAAA`, `JJMMAAAA`, `AAAAMMJJ`), comparer, ajouter des
jours, compter des jours entre deux dates, connaître le nombre de jours d'un
mois, et formater. Une centaine de lignes.

`chrono` et `time` font cela très bien, mais ils apportent des fuseaux, une
horloge, de la localisation, et de la surface à auditer, pour un outil qui
manipule des identifiants net-entreprises. **Recommandation : un `date.rs`
maison**, jour civil pur (année, mois, jour), sans heure et sans fuseau, vérifié
exhaustivement contre Python sur 2000-2050 (aller-retour jour julien, nombre de
jours par mois, bissextiles). C'est un test qu'on écrit une fois et qu'on ne
relit jamais.

Seule exception à surveiller : la DPAE porte un horodatage `JJMMAAAAHHMMSS` et
l'AEM une heure d'embauche. C'est de la phase 2, et une horloge système suffit.

---

## 4. `calcul.py` — l'algorithme, dans l'ordre exact

C'est le cœur, et l'ordre des opérations **fait** le résultat. Le porter, c'est
reproduire cette séquence sans la « simplifier ».

### 4.1 L'entrée

`Engagement` : salarié, spectacle, dates travaillées, `taux_cachet`, et les
optionnels `cachets`, `debut`, `fin`, `numero`, `heures`, `taux_horaire`,
`jours`, `date_paiement`, `lieu`.

Les défauts se calculent à la construction, et ils comptent :

- `cachets` ← nombre de dates travaillées ;
- `jours` ← nombre de dates travaillées ;
- `debut` / `fin` ← première et dernière date, **après tri** ;
- **refus** si `heures` et `cachets` sont tous deux non nuls sans
  `taux_horaire` : « le taux du cachet ne s'applique pas aux heures ».

En Rust : un constructeur faillible (`Engagement::nouveau(...) -> Result<…>`),
pas un `Default` complaisant. Le refus est une règle métier, pas une commodité.

### 4.2 Les rubriques de salaire

```
rubriques = []
si cachets : rubriques.push( eur(taux_cachet × cachets) )
si heures  : rubriques.push( eur(taux_horaire × heures) )
brut = Σ rubriques
```

Le taux horaire se résout ainsi : `taux_horaire` s'il est donné ; sinon, s'il y
a des heures **et aucun cachet**, `taux_cachet` tient lieu de taux horaire
(contrat purement horaire) ; sinon zéro.

C'est un `Vec<Decimal>` de un ou deux éléments aujourd'hui. **Ne pas le réduire
à un scalaire** : c'est ce vecteur qui porte la règle du §4.4, et c'est lui qui
accueillera les 79 rubriques du catalogue le jour de l'étape 2 de `prive/journal/ETAT.md`.

### 4.3 Les assiettes, par rubrique

Pour chaque montant de rubrique `m` :

```
brut      = m
csg       = eur(m × abattement_csg)  +  pct(m, taux_pat_prevoyance)
brut_x115 = eur(m × majoration_conges_115)
brut_x110 = eur(m × majoration_conges_110)
```

`taux_pat_prevoyance` est lu **dans le barème**, en cherchant la rubrique
d'identifiant `prevoyance` (1,11 % en 2026). Il n'est pas en dur.

`base_csg` = somme des `csg` de chaque rubrique. Exemple à connaître par cœur :
brut 260 → 255,45 + 2,89 = **258,34**.

### 4.4 La règle qui a coûté un centime

> CoolPaie applique les taux à **chaque rubrique de salaire**, arrondit chaque
> montant, puis somme. **Sauf** pour les cotisations assises sur la CSG, qui se
> calculent **une seule fois** sur l'assiette agrégée.

En code :

```
pour chaque rubrique r du barème :
    assiettes = [ base_csg ]                          si r.base == "csg"
              = [ a[r.base] pour a dans par_rubrique ] sinon
    pour chaque assiette :
        si r.composants     : m_pat += Σ pct(assiette, t) pour t dans composants
        sinon si r.taux_pat : m_pat += pct(assiette, r.taux_pat)
        si r.taux_sal       : m_sal += pct(assiette, r.taux_sal)
```

Invisible sur 168 bulletins au cachet pur. Visible sur le bulletin 27/2026
(1 cachet à 130 € + 12 h à 20 €) : 212,99 de charges patronales et non 213,00.

Les `composants` sont le second cas du même phénomène : la ligne « autres
contributions 0,680 % » est en réalité 0,590 + 0,090, **arrondies séparément**,
affichées en une ligne. 286,00 → 1,69 + 0,26 = 1,95, et non 1,94.

### 4.5 Le plafond déclaré en DSN — à ne pas confondre avec l'autre

```
heures  = min( heures_payées + 12 × cachets , heures_par_cachet × jours )
plafond = eur( smic_horaire(fin) × heures )
```

`heures_par_cachet` vaut 7 dans le barème. Sur un contrat pur, `jours` =
`cachets` et le second terme gagne : on retrouve les 7 h par cachet.

Trois points d'ancrage vérifiés :

| Cas | heures retenues | plafond |
|---|---|---|
| 1 cachet, février 2026 | 7 | 84,14 (12,02 × 7) |
| 1 cachet, juillet 2026 | 7 | 86,17 (12,31 × 7) |
| 04→17/10/2025, 1 cachet + 40 h, 11 jours | min(52, 77) = **52** | 617,76 dans la DSN déposée |

Le `min` mord réellement sur 6 enregistrements AEM de l'historique (janvier
2026, août 2024, juillet 2026) : les deux branches sont exercées, la formule
n'est pas ajustée sur un seul côté.

**Le nom est piégeux** : cette valeur est `S21.G00.79.001 = '01'`, le *SMIC
retenu pour la réduction générale*, pas un plafond. Le vrai plafond est le
sujet du §5. Garder deux noms distincts dans le Rust dès la première ligne —
`smic_reduction_generale` et `plafond_urssaf` — pour ne pas rejouer l'erreur
qui a fait chercher au mauvais endroit pendant des mois.

### 4.6 La sortie

`Paie` : brut, base_csg, plafond, smic, heures, les lignes de cotisation,
`total_pat`, `total_sal`, `net_social`, `net_a_payer`, `net_imposable`,
`cout_employeur`, `numero_bulletin`.

```
net            = brut − total_sal
net_imposable  = net + montant_sal de la ligne `csg_crds_nd`
cout_employeur = brut + total_pat
```

`net_social` vaut aujourd'hui `net` : à ne pas « corriger » au passage — le
portage n'est pas le moment de changer une définition.

`LigneCotisation` porte `masquer_base_et_taux`, un drapeau d'affichage
(cotisations CCN). Il traverse jusqu'au PDF, donc il traverse le portage.

---

## 5. `plafond.py` — le « Plafond Urssaf » du bas de bulletin

```
plafond = max( PSS mensuel × jours calendaires du contrat / jours du mois,
               PSS horaire × 12 h × nombre de cachets )
```

Le premier terme est le prorata de droit commun, calculé **mois par mois** puis
sommé pour un contrat à cheval (les deux bornes incluses : du 24 au 24 fait un
jour). Le second est un plancher propre aux artistes : chaque cachet emporte ses
12 heures, l'équivalence de l'annexe 10.

Vérifié sur 29 bulletins CoolPaie sur 30, deux employeurs, cinq ans, plusieurs
versions du logiciel. **La 30e est figée par un test qui documente l'écart** —
bulletin AKD du 20 au 25/03/2023, CoolPaie affiche 709,55 là où la règle donne
1 944,00. Ce test doit être porté **avec son écart**, pas « réparé ».

`PSS_MENSUEL` et `PSS_HORAIRE` sont des tables année → entier, dans le code, et
le module **lève** pour une année inconnue au lieu de deviner. En Rust : une
erreur typée `PlafondInconnu(annee)` dont le message dit quoi faire (relever
`PSS_M_METROP` et `PSS_H_METROP` sur la table des paramètres du BOSS). Le refus
de deviner est la marque de fabrique du moteur ; il se porte comme le reste.

**Une bonne nouvelle sur la précision.** Le prorata est une division non
arrondie en `Decimal` (28 chiffres significatifs chez Python), puis un `max`,
puis un arrondi au centime. On pourrait craindre que `rust_decimal` divise
autrement au 28e chiffre et fasse basculer un demi-centime. Ça ne peut pas
arriver : le dénominateur ne vaut que 28, 29, 30 ou 31, et
`PSS × jours / dénominateur` ne peut pas tomber exactement sur un demi-centime —
29 et 31 sont premiers (quotient entier, ou périodique), une division par 30 ne
donne au plus qu'une décimale exacte, une division par 28 au plus deux. Aucune
égalité parfaite à `X,XX5` n'est possible, donc aucun arbitrage d'arrondi ne
dépend du 28e chiffre. **Le prorata est portable sans réserve.**

Malgré cela, le test à écrire est exhaustif et coûte trois lignes : les
6 années connues × 12 mois × toutes les durées de contrat possibles, comparées
au Python. Environ 2 200 cas, une seconde.

---

## 6. `cumul.py` — deux fenêtres qu'il ne faut jamais confondre

C'est le module le plus facile à porter et le plus facile à mal porter, parce
que ses erreurs ne lèvent rien : elles rendent un nombre plus petit.

### 6.1 Ce qu'il fait

- **Le cumul de paie**, en année civile, imprimé en bas du bulletin. Repart à
  zéro le 1er janvier.
- **Les droits à l'assurance chômage** (annexes 8 et 10), sur les 12 mois
  **précédant** la date anniversaire notifiée par France Travail. La fenêtre
  finit à l'anniversaire, elle ne commence pas là — l'erreur inverse compte une
  période qui n'a pas encore eu lieu.

`heures_equivalentes = heures déclarées + 12 × cachets`. Seuil 507.
`manque = max(0, 507 − heures_equivalentes)`, `cachets_manquants` = division
entière **par excès**. Une fenêtre fait 365 jours pleins, pas douze mois
calendaires : à porter tel quel.

La source est l'**AEM réellement déposée**, jamais un recalcul : c'est le
document que France Travail a reçu.

### 6.2 Les trois pièges, tous déjà payés

1. **Le découpage par offsets fixes de 1000 caractères est faux.** Un
   enregistrement AEM fait 1 000 caractères **suivis d'un CRLF** : découper par
   pas de 1 000 tombe juste sur le premier puis dérive de 2 octets à chaque
   suivant, et les enregistrements suivants disparaissent **sans lever
   d'erreur** — 53 lus au lieu de 137. On découpe par lignes. Le test qui
   compte les enregistrements attendus est obligatoire.

2. **Le latin-1 et le découpage en octets.** En Python, `ligne[650:653]` indexe
   des caractères après décodage. En Rust, `&s[650..653]` indexe des **octets
   UTF-8** et *panique* sur une frontière multi-octets dès qu'un nom porte un
   accent. **Régler la question une fois pour toutes : travailler sur `&[u8]`,
   découper en octets, décoder chaque champ en latin-1 à l'extraction**
   (`octet as char`, la correspondance est directe). C'est aussi ce qu'il
   faudra pour l'AEM et la DPAE en phase 2, où l'octet fait foi.

3. **Le dédoublonnage.** Un même contrat peut avoir été réédité plusieurs fois
   (rectificatifs, réimpressions). La clé est le n-uplet complet
   (salarié, début, fin, objet, heures, cachets, jours, brut). En Python c'est
   un tuple dans un `dict`, puis un `sorted()` ; en Rust, un `struct` avec
   `#[derive(PartialEq, Eq, PartialOrd, Ord)]` **dans le même ordre de champs**,
   pour que le tri soit identique. Un `BTreeSet` rend le tri gratuit.

### 6.3 Deux choses à trancher au passage, sans les décider seul

- `HEURES_PAR_CACHET_GROUPE = 8` est **déclaré et jamais utilisé** :
  `heures_equivalentes` applique 12 à tous les cachets. Le catalogue de
  rubriques distingue pourtant `ci` (isolé, 12 h) et `cg` (groupé, 8 h). Tant
  que la compagnie ne joue qu'en cachets isolés c'est sans effet ; c'est à
  reprendre le jour de la saisie par rubrique (étape 2 de `prive/journal/ETAT.md`), pas au
  portage.
- `lire_aem` va chercher `../export/AEM_EDI`, c'est-à-dire **la sortie de
  CoolPaie**, hors du dossier `claude/`. Un logiciel paramétrable par une autre
  compagnie ne peut pas dépendre de ce chemin. En Rust, il devient un réglage
  (`config/entreprise.json`), avec ce chemin comme valeur par défaut le temps
  du triple run.

---

## 7. Le barème — un fichier de données, et il doit le rester

`config/baremes/2026.json`, 9 ko, contient :

| Clé | Rôle |
|---|---|
| `smic_horaire` | **liste datée** `{depuis, valeur}` — 12,02 puis 12,31 au 01/06/2026 |
| `heures_par_cachet` | 7 (§4.5) |
| `abattement_csg`, `majoration_conges_115`, `majoration_conges_110` | 0,9825 / 1,115 / 1,10 |
| `rubriques_bulletin` | 15 lignes : `id`, `famille`, `libelle`, `base`, `taux_pat`, `taux_sal`, éventuels `composants` et `masquer_base_et_taux` |
| `cotisations_dsn` | 17 lignes, pour la phase 2 |
| `taux_chomage_aem`, `cotisation_prevoyance_retraite_supp` | phase 2 également |

Les clés commençant par `_` sont des commentaires — `_source`, `_note`,
`_taux_carsat`, `_abattement_artistes`. **Elles doivent survivre au portage** :
c'est là qu'est écrit *pourquoi* le taux AT vaut 1,05 et non 1,50 (arrêté du
24 janvier 1975, 70 % pour les artistes). Un désérialiseur strict qui refuse
les champs inconnus effacerait cette mémoire à la première réécriture.
`serde` sans `deny_unknown_fields`, donc — et un test qui vérifie que réécrire
le barème depuis le Rust ne perd aucune clé.

Trois règles de conception héritées, à ne pas relâcher :

- **le barème est un fichier, pas du code.** Aucun taux en dur dans le Rust,
  jamais, même « en attendant » ;
- **pas de barème pour une année → refus**, avec un message qui dit quoi faire
  (partir du plus récent, mettre à jour SMIC et taux, relancer `calibrer`) ;
- le SMIC et la licence sont des **listes datées** résolues à la date de fin du
  contrat. Le rejeu de l'historique doit reproduire ce qui a été déclaré à
  l'époque, pas la valeur du jour.

**Le prérequis que personne n'a planifié.** `config/baremes/` ne contient que
**2026.json**. `calibrer` ignore donc aujourd'hui toutes les DSN de 2021 à
2025 : « barème absent ». Or l'étape 3 de l'ordre convenu est « `calibrer`
rejouant les cinq ans d'`export/` », décrite comme le point de bascule du
portage. Il manque donc **cinq fichiers de barème** avant que ce point de
bascule soit seulement atteignable.

Les écrire est un travail **Python**, pas Rust : c'est de la rétro-ingénierie
sur les DSN déposées, exactement ce qui a été fait pour 2026, et l'oracle doit
être complet avant qu'on lui compare quoi que ce soit. À faire hors ligne —
c'est un bon chantier de soirée sans wifi.

---

## 8. La forme du crate, phase 1

Un seul crate, pas d'espace de travail tant qu'il n'y a pas de raison.

```
paie/
  Cargo.toml
  src/
    main.rs        commandes : `paie calcul <fichier>`, `paie fiche`, `paie oracle`
    util.rs        eur, pct, formats — §2
    date.rs        jour civil maison — §3
    config.rs      Contexte : chargement JSON, recherche floue des noms
    bareme.rs      structures du barème, désérialisation par le texte — §7
    calcul.rs      Engagement -> Paie — §4
    plafond.rs     PSS, prorata, plancher — §5
```

`cumul.rs` arrive avec l'AEM, en phase 2 : il ne sait rien faire sans un
lecteur d'enregistrements à largeur fixe, et c'est le même code que l'écriture.

Le profil de compilation, à mettre dans `Cargo.toml` dès le premier jour pour
que le budget d'octets soit mesuré et pas espéré :

```toml
[profile.release]
opt-level = "z"
lto = "fat"
codegen-units = 1
panic = "abort"
strip = true
```

Dépendances de la phase 1, et rien d'autre :

| Crate | Pourquoi | Alternative écartée |
|---|---|---|
| `rust_decimal` (+ `serde`) | l'arithmétique décimale, `MidpointAwayFromZero` | les flottants : disqualifiés d'office |
| `serde`, `serde_json` (`arbitrary_precision`) | lire les mêmes fichiers qu'aujourd'hui | — |
| — | le CLI se parse à la main tant qu'il a trois commandes | `clap`, à reconsidérer en phase 5 |
| — | les dates sont maison (§3) | `chrono`, `time` |

Mesurer la taille du binaire à la fin de **chaque** phase et la noter ici. Le
budget des 10 à 15 Mo se joue en phase 4 (`resvg`/`svg2pdf`, ≈ 3,5 Mo) et en
phase 5 (TLS) ; la phase 1 doit rester sous le mégaoctet, et si elle n'y est
pas c'est qu'une dépendance est entrée sans être invitée.

---

## 9. Le harnais différentiel — comment on prouve

C'est la moitié du travail, et c'est ce qui rend le reste rapide.

**Un format d'échange canonique.** Une `Paie` sérialisée en JSON, champs triés,
montants en chaînes à deux décimales (`"149.66"`, jamais `149.66` en flottant),
lignes de cotisation dans l'ordre du barème.

**Des deux côtés la même commande :**

```
python -m moteur oracle <corpus.json>   > py.json
paie oracle <corpus.json>               > rs.json
diff py.json rs.json
```

Un `oracle` qui ne fait que calculer et sérialiser : il n'écrit aucun PDF, ne
touche à aucun compteur, ne dépose rien.

**Trois corpus, du plus faible au plus fort :**

1. **Les mois saisis** — `paies/2026-08.json`, `2026-09.json`, `2026-10.json`.
   Six bulletins pour août, dont le contrat mixte. C'est le corpus de
   développement : petit, immédiat, il attrape 90 % des fautes de frappe.
2. **L'historique** — les 189 enregistrements AEM et les 50 DSN de `export/`,
   reconstitués en engagements exactement comme le fait `verif.py`. C'est le
   corpus qui prouve, et il ne sera complet qu'avec les barèmes 2021-2025 (§7).
3. **Une grille engendrée** — cachets 0 à 10 × taux {60, 100, 130, 260, 520} ×
   heures 0 à 40 × taux horaires {15, 20, 22,50} × dates de part et d'autre du
   01/06/2026, plus des durées de contrat traversant deux mois et une année.
   Quelques dizaines de milliers de cas, sans aucune valeur métier, dont le
   seul but est de trouver le demi-centime que les corpus réels ne contiennent
   pas. C'est là qu'on attrape une erreur d'arrondi ou de conversion de taux.

**Les tests unitaires Rust, à écrire avant le code, avec les valeurs déjà
connues :**

| Cas | Attendu |
|---|---|
| PUPPIS juin 2026, 2 cachets à 130 | brut 260,00 · CSG 258,34 · pat 149,66 · sal 58,68 · net 201,32 · imposable 208,81 · plafond 172,34 · coût 409,66 |
| Bulletin 27/2026, 1 cachet 130 + 12 h à 20 | brut 370,00 · CSG 367,63 · pat 212,99 · sal 83,50 · net 286,50 · coût 582,99 |
| Ligne `autres_3` (composants) | 1,95 — et non 1,94 |
| Lignes `ccn` / `csg_ded` sur 260 | 1,30 / 17,57 |
| Plafond DSN février / juillet 2026 | 84,14 / 86,17 |
| Plafond DSN octobre 2025 (1 cachet + 40 h, 11 j) | 52 h retenues, 617,76 |
| Plafond Urssaf, les 6 lignes du tableau de `plafond.py` | dont 624,00 · 2 808,00 · 1 222,00 · 1 291,94 · 360,00 |
| Plafond Urssaf AKD 20-25/03/2023 | **709,55**, l'exception, figée telle quelle |
| Août 2026 complet | 6 bulletins, brut du mois 1 780,00 |

Si ces neuf tests passent et que les trois corpus ne montrent aucun écart, la
phase 1 est finie. Pas avant, et rien de plus n'est nécessaire.

---

## 10. Les deux corrections de conception à porter — et seulement elles

Elles sont déjà décidées ; le portage est l'occasion de les faire, parce qu'on
réécrit de toute façon.

1. **Les compteurs ne sont plus mutables.** `config/compteurs.json` est écrit à
   chaque production ; générer un aperçu a consommé six numéros de bulletin
   (25 → 31). En Rust, **le numéro se déduit des bulletins émis et stockés**, et
   un aperçu n'en consomme aucun. Le Python a déjà fait la moitié du chemin
   (`Contexte.valider_compteurs` n'écrit qu'après production réussie) ; le Rust
   va au bout et supprime la source de vérité mutable.
2. **Un bulletin émis stocke son résultat et sa version de barème.** Il n'est
   jamais recalculé. Un barème corrigé en mars ne doit pas changer un bulletin
   de janvier déjà remis à un salarié.

**Tout le reste se porte à l'identique, y compris ce qui semble améliorable.**
Le portage n'est pas le moment de refaire la saisie par rubrique (étape 2), ni
de trancher le numéro de licence, ni de toucher au `net_social`. Un écart
Rust/Python doit toujours pouvoir être qualifié de bug ; si on change une règle
en même temps, plus rien ne le peut.

---

## 11. La séquence de frappe

**Au wifi, dans l'ordre — vingt minutes, dont dix-neuf d'attente :**

```
rustup toolchain install stable-x86_64-pc-windows-gnu
rustup default stable-x86_64-pc-windows-gnu
cargo new --bin paie
cd paie
cargo build --release
```

La dernière commande doit produire un `.exe` qui s'exécute. Si le lien échoue,
alors seulement :

```
winget install Microsoft.VisualStudio.2022.BuildTools --override "--quiet --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
rustup default stable-x86_64-pc-windows-msvc
```

Puis, avant de couper le réseau, les dépendances de la phase 1 :

```
cargo add rust_decimal --features serde
cargo add serde --features derive
cargo add serde_json --features arbitrary_precision
cargo fetch
```

**Hors ligne, ensuite, dans cet ordre :**

1. `util.rs` + `date.rs`, et leurs tests exhaustifs contre Python.
2. `bareme.rs` : lire `2026.json`, et le test « chaque nombre reparsé est égal
   à la `Decimal` de Python ».
3. `plafond.rs` : la formule, la table PSS, les 6 lignes de référence, le cas
   AKD figé, la comparaison exhaustive des prorata.
4. `config.rs` : chargement de `entreprise` / `salaries` / `spectacles`, et la
   recherche floue (exact, puis préfixe, puis distance d'édition ≤ 3).
5. `calcul.rs` : dans l'ordre du §4, avec les neuf tests du §9 écrits d'abord.
6. La commande `oracle` des deux côtés, et les trois corpus.
7. Les barèmes 2021-2025 en Python (§7), qui débloquent le corpus 2.

Le triple run de septembre peut commencer dès l'étape 6 : `paie calcul
paies/2026-09.json` à côté du Python, sur les mêmes fichiers, sans rien écrire.

---

## 12. Ce que cette carte ne couvre pas

Les phases 2 à 6 de l'ordre convenu : DSN et AEM, `calibrer` en Rust, les PDF
en gabarits SVG, le réseau, la persistance et l'interface. Elles ne se
planifient pas utilement avant que la phase 1 tourne — et surtout, aucune
d'elles ne porte de risque juridique tant que le calcul, lui, est prouvé.

Rappel de la règle du dépôt public : **le Rust seulement**, jamais le Python,
jamais `reference/`, jamais `config/`, `paies/`, `retours/`, `gabarits/`.
L'historique git est définitif — le **premier commit** doit déjà être propre,
pas le premier push.
