# Architecture

## Le principe

CoolPaie a produit cinq ans de déclarations acceptées par l'URSSAF, France
Travail et Audiens. Ces fichiers sont la spécification : chaque taux, chaque
règle d'arrondi et chaque champ de ce moteur en a été déduit, puis vérifié en
rejouant les mêmes mois et en comparant caractère par caractère.

D'où trois règles de conception.

**Le calcul est du code, pas du langage.** Un modèle de langage ne doit jamais
calculer une cotisation. `moteur/calcul.py` applique un barème JSON versionné ;
Claude ne fait que traduire une phrase en fichier de saisie et lancer la
commande.

**Les formats à largeur fixe partent d'un vrai enregistrement.** L'AEM et la
DPAE sont générées en recopiant un enregistrement réel (`gabarits/`) et en n'y
remplaçant que les zones identifiées. Tout ce qui n'a pas été compris reste
donc exactement tel que l'administration l'a déjà accepté.

**Rien n'est réputé juste sans rejeu.** `python -m moteur calibrer` reconstruit
chaque DSN et chaque AEM du dossier `export/` à partir de leurs propres données
et les compare à l'original.

## Le flux

```
   une phrase, ou paies/AAAA-MM.json (des lignes de paie datées)
              │
              ▼
   operations.py ── l'orchestration et les garde-fous, seuls à décider ;
              │     la ligne de commande (cli.py) et l'interface (web.py)
              │     ne font que l'appeler. Un nom, neuf modules par domaine
              │     derrière : operations_socle (erreur, verrou, preuve,
              │     filet), _paies, _declarations, _retours, _documents,
              │     _ouverture, _fiches, _catalogues
              ▼
   contexte.py ── config/entreprise.json, salaries.json, spectacles.json,
              │   organismes.json, baremes/AAAA.json, compteurs.json
              ▼
   calcul.py  ── brut, assiette CSG, plafond, rubriques du catalogue, net, coût
              │
   ┌──────────┼───────────┬────────────┬────────────┬──────────────────┐
   ▼          ▼           ▼            ▼            ▼                  ▼
contrat.py bulletin.py  dpae.py     aem.py       dsn.py    conges_spectacles.py
  PDF        PDF        990 c.   1000 c.*    NEODeS P26V01      PDF
   │          │           │            │            │                  │
   └──────────┴───────────┴────────────┴────────────┴──────────────────┘
                          │
                       sorties/AAAA-MM/
                          │
              verif.py ───┤  rejeu contre export/ de CoolPaie
                          │
        dpae_api.py / dsn_api.py ── dépôt par l'API, sous une séance ouverte
                          │
                     journal.py ── journal/depots.json : ce qu'un fichier
                                   est devenu, et ce que l'organisme en a dit
```

\* Plus d'AEM produite depuis le 01/06/2026 (100 % DSN, France Travail édite
l'attestation lui-même — `moteur aer`) ; `aem.py` reste pour relire l'archive
2021-2026 et pour le rejeu.

## La ligne de paie datée

Le fichier de saisie ne décrit pas un engagement par ses dates et son lieu,
mais par ses **lignes de paie** : « 4 cachets à 130 € au Théâtre 71 le 14, 15,
17, 18 ». Une ligne est un groupe de cachets, à un taux, à un endroit, à des
dates. Deux villes, deux lignes — et c'est une seule paie, donc un contrat, un
bulletin, une AEM. Le format est dans le `README.md`.

Ce que ça impose au moteur :

- `operations.dates_engagement(e)` est le **seul endroit** qui sache où
  chercher les jours d'un engagement : dans ses lignes, et nulle part
  ailleurs. `cumul.py` et `charger` passent par lui.
- **Une seule écriture** depuis le 13/09/2026. `calcul.Engagement` exige
  `lignes` ; `cachets` et `heures` en sont **dérivés** (l'AEM, le bloc 53 de
  la DSN, le plafond et `cumul` les lisent toujours), `taux_cachet` est le
  taux de la première ligne `cachet`, `taux_horaire` n'existe plus. Un
  engagement portant `dates`, `cachets`, `heures` ou `taux_horaire` est
  refusé par `charger`, qui nomme `outils/convertir_saisies.py`. La preuve
  de la conversion : août 2026 produit dans deux copies jetables, fichier tel
  quel / converti, **douze documents identiques**.
- `util.d()` accepte `{"jour": …, "lieu": …}` en plus des quatre formats de
  date : une date détaillée est une date, tout ce qui parcourt des jours
  continue de marcher sans le savoir.
- `Engagement.__post_init__` (`calcul.py`) réunit les deux écritures et n'en
  laisse qu'une : `dates_travail` reste une liste de dates triées, le lieu part
  dans `lieux` (`lieu_de()`, `lieux_joues()`). Le contrat groupe les dates par
  lieu ; le lieu ne se déclare nulle part ailleurs (ni DSN, ni AEM, ni DPAE).
- **L'ancienne écriture reste lue sans conversion.** Cinq ans de saisies
  tiennent ce moteur : `calibrer` doit rendre les mêmes écarts avant et après.

## Les métiers, les minima, et les sources qu'on date

Trois fichiers de données livrés avec le moteur, et une règle : **toute
donnée réglementaire part d'une source officielle téléchargée, décrite,
datée, vérifiable**. CoolPaie ne sert qu'à vérifier.

- `moteur/nomenclature-emplois-ft.json` — les **1 236 codes emploi** France
  Travail (annexes 8 et 10), **générés** depuis le PDF de la nomenclature.
- `moteur/emplois-base.json` — **129 métiers du spectacle vivant** en onze
  familles. Chaque métier : libellé (et féminin), `emploi` officiel
  (S21.G00.40.006), `pcs_ese` (40.004, depuis les fiches Insee), `statut`
  (déduit de l'annexe, jamais saisi), `cadre_par_defaut`,
  `statut_conventionnel` (40.002 : cadre → 04, artiste et agent de maîtrise
  → 05, administratif non cadre → 06, employé technique → 07),
  `classification_3090` et `minima`. `emplois.resoudre(code, cadre=…)` rend
  les six champs déclarés ; `charger` les pose sur l'engagement, sauf ce que
  l'engagement écrit lui-même. Le cadre se combine au statut.
- `moteur/minima-conventionnels.json` — les grilles de la **3090** (annexes
  1, 2, 4, 5 et clauses communes) et de la **1285** (cachet, répétition,
  cirque, musiciens, lyrique, chœur ; NAO 2026 sous `non_etendu`).
  `minima.avertissements(ctx, paie)` compare chaque ligne à son plancher et
  rend une phrase, jamais un refus. **Toute inconnue tire vers le bas** :
  jauge minimale, palier du mois pour un barème trimestriel, la plus basse
  des annexes quand la fiche entreprise ne dit pas la sienne
  (`annexe_convention`). Quand une grille distingue les jauges, le métier
  pointe la ligne la plus basse et la grille porte les autres pour mémoire.
- `moteur/sources.json` — le **manifeste** : pour chaque source, titre,
  éditeur, URL, description, version et d'où on la lit, date de relevé,
  fichier de la copie (dans `prive/reference/sources/`, hors dépôt :
  documents publics, retéléchargeables), SHA-256, mode de vérification, et
  quels fichiers de données elle nourrit. `python -m moteur sources
  --verifier` retélécharge et compare ; une source `changee` est à RELIRE
  (`--relever` pose la nouvelle version à côté). Légifrance refuse les
  robots (403) : la copie ne se revérifie pas en ligne, mais la source
  porte un bloc `kali` (IDCC, conteneur, texte) et `moteur/kali.py` lit
  les **livraisons open data KALI** de la DILA
  (`echanges.dila.gouv.fr/OPENDATA/KALI/`, une archive par soir) depuis
  le relevé : fiche de la convention relivrée avec des textes nouveaux,
  texte modifié (état, arrêté d'extension). Un texte dont le titre parle
  de salaires, ou le texte cité, rend la source `changee` ; le reste est
  montré en second. Lecture incrémentale, résumée dans
  `prive/reference/sources/veille-kali.json` (livraisons lues, liste des
  textes de chaque convention, trous de l'index) ; à la première veille,
  l'index est remonté jusqu'à la dernière fiche de chaque convention.
  L'ouverture (`operations_ouverture`) refait `sources.verifier` une
  fois par semaine et compte une source `changee` comme incident.

Ce que la confrontation à CoolPaie a montré (`prive/reference/professions-coolpaie.md`) :
les 51 codes PE concordent ; CoolPaie met l'accessoiriste en PCS `637d`,
l'Insee dit `637c` ; sa colonne « abat. » n'est pas la DFS réglementaire.

## Le barème, et comment il a été retrouvé

Point de départ : le bulletin PUPPIS de juin 2026, brut 260,00 €.

| Rubrique | Base | Patronal | Salarial |
|---|---|---|---|
| Maladie maternité invalidité décès | brut | 9,100 | — |
| Prévoyance Audiens | brut | 1,110 | 0,120 |
| AT/MP | brut | 1,050 | — |
| Vieillesse plafonnée | brut | 5,990 | 4,830 |
| Vieillesse déplafonnée | brut | 1,480 | 0,280 |
| Retraite complémentaire T1 | brut | 5,740 | 5,300 |
| Famille | brut | 3,680 | — |
| Chômage | brut | 9,750 | 2,400 |
| Autres contributions | brut | 2,836 | — |
| Autres contributions | brut × 1,115 | 0,070 | — |
| Autres contributions | brut × 1,10 | 0,590 + 0,090 | — |
| Congés Spectacles | brut | 15,500 | — |
| Cotisations statutaires CCN | brut | 0,500 | — |
| CSG déductible | assiette CSG | — | 6,800 |
| CSG/CRDS non déductible | assiette CSG | — | 2,900 |

Les taux de vieillesse et de famille sont les taux de droit commun réduits de
30 % : c'est l'abattement applicable aux artistes du spectacle (8,55 × 0,70 =
5,985 ≈ 5,990 ; 6,90 × 0,70 = 4,83 ; 5,25 × 0,70 = 3,675 ≈ 3,680).

Trois subtilités, chacune trouvée en cherchant pourquoi un centime manquait.

**L'assiette CSG n'est pas 98,25 % du brut.** Elle vaut
`arrondi(brut × 0,9825) + part patronale de prévoyance`, soit
255,45 + 2,89 = 258,34 pour 260 € de brut, et 510,90 + 5,77 = 516,67 pour 520 €.

**Une ligne du bulletin peut cacher deux cotisations.** La ligne
« autres contributions 0,680 % » sur 286,00 € affiche 1,95 € alors que
286 × 0,68 % = 1,9448 → 1,94. Ce sont en réalité deux contributions arrondies
séparément : 0,590 % → 1,69 et 0,090 % → 0,26. Même mécanisme pour la
contribution formation `059` de la DSN (0,420 + 0,810).

**Tous les arrondis sont au demi supérieur.** `round()` de Python arrondit au
pair le plus proche et se trompe donc d'un centime régulièrement ; `moteur/util.py`
utilise `Decimal` avec `ROUND_HALF_UP`.

## Le plafond déclaré en DSN

`S21.G00.79.001 = '01'` vaut **SMIC horaire × 7 h × nombre de cachets**.

Vérifié sur soixante-dix contrats de 2021 à 2026 : la valeur par cachet suit
exactement les revalorisations du SMIC (10,25 → 10,48 → 10,57 → 10,85 → 11,07 →
11,27 → 11,65 → 11,88 → 12,02 → 12,31), et pour les contrats payés à l'heure
c'est SMIC × nombre d'heures — 52 h en octobre 2025, 140 h en novembre 2023.

## L'AEM V5

Enregistrements de 1000 caractères, latin-1, séparés par CRLF. Zones
identifiées dans `moteur/aem.py`. La queue numérique est celle-ci :

| Position | Contenu |
|---|---|
| 650-653 | nombre d'**heures** effectuées |
| 653-655 | nombre de **cachets** |
| 655-659 | nombre de **jours** travaillés |
| 659-668 | brut en centimes |
| 668-677 | assiette des contributions chômage en centimes |
| 677-681 | taux de contribution chômage × 100 (1215 = 12,15 %) |
| 681-690 | montant de contribution, **arrondi à l'euro** puis × 100 |
| 690-712 | zéros |
| 712-721 | même montant |

Ce schéma a été testé sur les 189 enregistrements émis depuis 2021 : 189/189
conformes. C'est l'arrondi à l'euro, et non au centime, qui bloquait au départ
(119,79 → 120, 7,29 → 7, 36,30 → 36).

### Les positions 650-659, élucidées

Elles se lisaient mal parce qu'un contrat au cachet pur a autant de jours que
de cachets : `00002` + `0002` se laissait interpréter comme « 2 heures, 2
cachets », et 168 des 189 enregistrements sont dans ce cas. Les contrats mixtes
trahissaient l'erreur (`01201`, `02401`, `01604`…).

Le formulaire officiel imprimé par CoolPaie (`affichage/aemV5/aemV501.pdf`)
donne les trois champs accolés : **Nombre d'HEURES effectuées**, **Nombre de
CACHETS**, **Nombre de JOURS travaillés**. La découpe 3 / 2 / 4 est cohérente
sur 185 des 189 enregistrements — les 4 restants sont un même contrat de
décembre 2021 au format antérieur.

Exemple, le contrat du 23 au 26 août 2026 : `012` `01` `0004` = 12 heures,
1 cachet, 4 jours travaillés. Brut 370 € = 130 € de cachet + 12 h à 20 €.

Le moteur calcule donc ces trois champs au lieu de recopier une valeur
inexpliquée. Un contrat mixte se saisit avec une ligne `cachet` **et** une
ligne `heure`, chacune à son taux : le taux du cachet ne s'applique pas aux
heures.

## Les droits (annexes 8 et 10), et d'où viennent les contrats

`moteur/cumul.py` compte les 507 heures sur 12 mois (un cachet = 12 h, les
heures d'enseignement plafonnées) et imprime le bloc de cumul du bulletin.
Depuis le 15/09/2026 il ne lit qu'**une source, la nôtre**, en deux fichiers :

| | quoi | quand |
|---|---|---|
| `prive/historique/engagements.json` | les contrats attestés **avant** ce logiciel : les AEM de CoolPaie, importées une fois (`python -m moteur importer`) — dates, numéro d'objet, cachets, heures, jours, brut, numéro et date d'attestation | pour tout mois qui n'a pas de fichier de paie |
| `prive/paies/AAAA-MM.json` | les mois produits ici, chargés par `operations.charger` (un seul chemin de calcul : mêmes cachets, heures et brut que le bulletin et la DSN) | pour le mois du fichier — et l'historique se tait |

La règle de départage tient en une phrase : **un mois qui a son fichier de
paie est lu là, jamais deux fois.** Pendant le double run d'août 2026, l'AEM
de CoolPaie et notre fichier disent la même chose (vérifié : six engagements,
mêmes cachets, heures, jours et brut), et c'est le fichier qui compte. Un
fichier qui ne se charge pas (brouillon en cours, année sans barème) ne
couvre pas son mois : l'historique parle pour lui s'il a quelque chose à
dire. Les bornes d'un engagement issu d'une paie sont celles de sa **période
de paie** (le contrat borné au mois) : un contrat d'octobre à décembre compte
ses cachets d'octobre en octobre.

Le bulletin se compte lui-même : `bulletin.ecrire` passe les paies qu'il
imprime à `cumul.lire_engagements(ctx, paies_courantes=...)`, qui les
substitue au fichier de leur mois.

Avant cette date, `cumul.py` lisait `export/AEM_EDI` — le dossier de
CoolPaie — directement. Cela liait les droits à un logiciel qu'on résilie en
janvier 2027, et laissait de côté les mois produits ici (plus d'AEM depuis le
01/06/2026 : la compagnie est en 100 % DSN). `cumul.lire_aem` reste : il
dépouille un dossier d'AEM (l'import s'en sert, et nos propres AEM de
`sorties/`), mais plus personne ne l'appelle pour les droits.

### L'import CoolPaie

`moteur/importation.py` lit `export/` (les DSN pour l'identité, l'emploi,
les numéros d'objet et l'entreprise ; les AEM pour les contrats) ;
`operations_importation.py` décide quoi écrire, par les mêmes fiches que
l'écran (`enregistrer_fiche` : même clé, même matricule, même vérification,
même filet). Une fiche existante n'est jamais modifiée : ce que la DSN disait
autrement est rendu dans `ecarts`, et c'est à l'humain de dater un
changement. La dernière DSN où un salarié figure fait foi pour son identité ;
l'annule-et-remplace d'un mois passe après l'original. Un numéro d'objet
sans titre devient `objet-<numéro>`, titre « A COMPLETER », et l'année se lit
dans le numéro (`266Z` = 2026). La base CoolPaie (`bases/*.CSOC`) est
chiffrée : on ne la lit pas.

## La DSN

Norme NEODeS P26V01. `moteur/dsn.py` émet les blocs dans l'ordre observé, ce qui
donne 997 lignes strictement identiques à celles de juillet 2026.

Correspondances retrouvées :

- `S21.G00.78.005` (affectation de la contribution formation) s'incrémente de 3
  par versement du mois : 202/203 pour le premier contrat, 205/206 pour le
  deuxième — même règle que `S21.G00.70.012`.
- `S21.G00.54.002` (jours de congés) = `arrondi supérieur(cachets × 1,5)`,
  cohérent avec le taux 1,50 porté en `S21.G00.40.043`.
- `S21.G00.53` : type `12` = nombre de cachets, type `37` = nombre de jours
  distincts travaillés.
- `S21.G00.86` (type 07, unité 01) = ancienneté en jours entre le 01/12/2019 et
  la fin du mois déclaré.
- `S21.G00.23` : assiettes agrégées du mois arrondies à l'euro — brut pour les
  CTP 027/312/432/636/983, assiette CSG pour 260, brut × 1,115 pour 334,
  brut × 1,10 pour 992.
- `S21.G00.50.008` : compteur technique croissant (177900330 en 2021 →
  444207754 en août 2026), sans portée déclarative identifiée ; prolongé dans
  `config/compteurs.json`.

**Un contrat qui déborde du mois** (15/09/2026, option B1 de
`prive/journal/CONTRATS-PLURIMENSUELS.md`). `Engagement` connaît son mois
(`mois`, posé par `charger`) et en déduit `premier_mois`, `dernier_mois`,
`debut_periode`/`fin_periode` (le contrat borné au mois). La DSN en tire :

- bloc 40 identique chaque mois — 40.001 début, 40.009 numéro, 40.010 fin
  prévisionnelle sont les identifiants du contrat (fiche net-entreprises
  n° 3344) ;
- blocs 50, 51, 54, 58, 78 sur la **période de paie du mois**, pas sur le
  contrat (contrôles CCH-11 et CCH-13 du cahier technique) ;
- bloc 62 (fin de contrat) **le dernier mois seulement** ;
- bloc 53 : l'activité du mois, comme toujours ;
- date de constitution : la fin de période la plus tardive du mois.

`Engagement.planning` (jours des mois suivants, lus sous `planning` sur les
lignes, avec leur lieu dans `planning_lieux`) ne compte ni dans
`dates_travail`, ni dans les cachets, ni dans la DSN : il donne `fin` par
défaut, `dates_du_contrat()` pour le contrat imprimé, et la reprise du
mois suivant (`engagement_de_reprise`). Le contrat entier recomposé pour le
certificat CS (`paie_du_contrat_entier`) retire le planning des lignes :
chaque mois a payé le sien.

Le barème et le SMIC (`calcul.calculer`) sont ceux de `fin_periode`, pas de
`fin` : un contrat de décembre à février se paie en décembre au barème de
décembre. Sur un contrat qui tient dans son mois — tout l'historique — ces
propriétés valent `debut`/`fin` et rien ne bouge : `calibrer` le prouve sur
75 DSN, `tests/test_contrats_plurimensuels.py` rejoue un contrat fictif
octobre → décembre et lit les trois DSN — déposées en test le 15/09/2026,
conformes. La quotité 40.012/013 est celle du **contrat entier** (jours
signés : dates du premier mois + planning, `Engagement.jours_contrat`),
identique chaque mois et jamais zéro : le cahier technique 2026.1 interdit
le zéro en unité journée (bloc 40, CCH-11) et déclare tout changement de
quotité en bloc 41 (41.007). Plafond 31 (CCH-12) : au-delà, `dsn.py` lève.

**Un mois du contrat sans aucun cachet** (`lignes: []`, `Engagement.sans_paie`)
a quand même sa DSN : le contrat en cours avec un versement à zéro — bloc 50,
quatre 51, 53 à 0 jour, 58, et par affiliation prévoyance une base 78 « 31 »
avec sa cotisation 81 « 059 », tous à `0.00` ; ni 54, ni autre base. Pas de
bulletin. Établi par trois dépôts de test le 15/09/2026 (ETAT.md §26.9).

### Le montant Audiens : une donnée, pas un calcul

`S21.G00.20.005` pour Audiens vaut 782,00 € en juillet 2026 alors que la somme
des cotisations `S21.G00.81` affectées à Audiens fait 502,88 €. Les 50 DSN de
`export/DSN` (2021-2026) ont été dépouillées pour comprendre l'écart. Résultat :

Le montant vaut **les cotisations détaillées plus un résidu**, et ce résidu
suit un taux du brut stable par régime :

| Régime | cotisations 81 / brut | résidu / brut |
|---|---|---|
| 2021 → sept. 2022 | 0 % (aucun détail) | ~30,9 puis ~33,5 % |
| oct. 2022 → févr. 2026 | 10,047 % | ~23,6 % |
| depuis mars 2026 | 25,146 % | ~13,95 % |

Mais **aucun taux ne reproduit tous les mois d'un même régime**. Au meilleur
taux possible, l'écart au montant réellement payé monte à 42 € (décembre 2025),
et les mois d'**avril 2024, 2025 et 2026** portent tous un excédent de +10 à
+14 € — une régularisation annuelle. La base CoolPaie étant chiffrée, rien n'y
est récupérable.

Conclusion : ce montant n'est pas déductible de la paie. Audiens facture des
éléments que la DSN ne ventile pas. Comme le bloc est un **ordre de
télépaiement** — un montant faux fait un prélèvement faux — le moteur
**refuse désormais de le deviner** :

```
python -m moteur mois <fichier> --audiens 782.00   # montant du bordereau
python -m moteur mois <fichier> --audiens-estime   # estime, à vérifier
```

Sans l'une des deux options, la commande s'arrête (code 2) sans rien écrire.
L'estimation reste affichée avec sa marge mesurée (± 14 €) : elle sert à
repérer une saisie aberrante, pas à remplacer le bordereau.

Le rejeu, lui, relit le montant dans la DSN de référence au lieu de l'estimer —
c'est ce qui rend juin 2026 exact.

### Les cotisations se calculent rubrique par rubrique

CoolPaie n'applique pas les taux au brut global : il les applique à **chaque
rubrique de salaire**, arrondit chaque montant, puis somme. L'assiette CSG suit
la même règle ; les cotisations CSG, en revanche, se calculent une seule fois
sur l'assiette agrégée.

Invisible sur un contrat au cachet pur, qui n'a qu'une rubrique — d'où 168
bulletins qui ne trahissaient rien. Le bulletin 27/2026 (1 cachet à 130 € et
12 h de masterclass à 20 €) l'a révélé :

| | rubrique par rubrique | brut global | CoolPaie |
|---|---|---|---|
| Assiette CSG | 367,63 | 367,64 | **367,63** |
| Charges patronales | 212,99 | 213,00 | **212,99** |
| Coût employeur | 582,99 | 583,00 | **582,99** |

L'arrondi lui-même est bien **au demi supérieur** : vérifié sur les 144 cas
ambigus des cotisations `S21.G00.81` de l'historique, 144/144.

## La DPAE (ex-DUE)

Enregistrements de 990 caractères, **saut de ligne compris** : 989 caractères
puis `LF`, comme le dit le Format 120 (« 990 en incluant le saut de ligne »).
Un enregistrement par contrat, encodage latin-1. Zones dans `moteur/dpae.py` :

| Position | Contenu |
|---|---|
| 121-133 | horodatage de l'envoi, `JJMMAAAAHHMM` — **sans secondes** : le dessin officiel (Format 120) place `C_URSSAF` juste après |
| 133-136 | `C_URSSAF`, code de l'Urssaf réceptrice (117 Île-de-France), lu dans `entreprise.json` → `code_urssaf` |
| 283-315 | nom (32 c.) |
| 315-347 | prénom (32 c.) |
| 347-360 | NIR (13 c., sans la clé) |
| 360-368 | date de naissance `JJMMAAAA` |
| 368-412 | lieu de naissance (44 c.) |
| 412-420 | date d'embauche `JJMMAAAA` |
| 420-424 | heure d'embauche `HHMM` |
| 730-731 | sexe `M` / `F` |
| 827-829 | département de naissance |
| 865-873 | fin prévue du CDD `JJMMAAAA` |

Le reste est constant : marqueur `DUE`, `912` (N_LG_MESS, la longueur du message hors entête — pas un code Urssaf), `120` (C_VERSION), SIRET, raison
sociale, adresse, téléphone, code NAF, et `MT176` (code du service de santé au
travail). Ces zones viennent du gabarit et ne sont jamais réécrites.

**Niveau de preuve — plus faible qu'ailleurs, à savoir.** CoolPaie n'a laissé
qu'**un seul** fichier DPAE dans tout le dossier
(`export/TEMP/CCoU_280826_15h12m44s_DUE_TEL.txt`, 6 enregistrements du
28/08/2026, deux salariés × trois contrats). Les 6 sont reconstitués octet pour
octet, et l'audit des zones montre que tout segment non vide est soit un champ
identifié, soit une donnée d'entreprise stable. Mais aucune variation n'a pu
être observée sur : un autre établissement, un contrat autre que CDD (le `1` en
position 864 précède la date de fin et code probablement « durée déterminée »),
un autre service de santé au travail, une heure d'embauche autre que 19h00.
Pour l'usage de la compagnie — mêmes artistes, mêmes CDD d'usage — c'est couvert.

**Ce que l'Urssaf répond** (onglet « Codes retour » du Format 120, tables dans
`moteur/dpae.py`) : le bilan de conformité (nature 11, XML) porte un `<code>`
par anomalie, et le certificat de conformité (nature 41) est **notre
enregistrement renvoyé** avec ses zones de retour remplies — `C_RET_AR_LOT`
(76-77, le traitement du message), `R_DOSSIER` (425-429, la référence sous
laquelle la DPAE est enregistrée), `C_RETOUR_AR` (430-431, le code par DPAE)
et les formalités déclenchées (`I_CERTIF`, `I_IMMA`, `I_MT`, `I_PMF5`,
971-976). `journal.py` lit le certificat (`dpae.lire_certificat`) et pose sur
chaque embauche sa référence de dossier.

Deux lectures à connaître, observées sur les 16 enregistrements reçus de juin
au 12 septembre 2026, ceux de CoolPaie compris :

- **`99` « autre erreur, données facultatives » est l'état nominal**, toujours
  avec un `R_DOSSIER` et `CERTIF` + `MT` levées. Le tableau de 2013 est plus
  sévère que le service ; une DPAE en `99` avec un dossier est enregistrée.
- **`98` « DPAE déjà existante »** : l'Urssaf n'a rien créé (formalités à `N`)
  parce qu'une DPAE identique existait — vu sur le second test des mêmes
  embauches. L'embauche est déclarée, par la première.

Le moteur écrit le `.txt` **et** le `.txt.zip` du même nom, comme le faisait
CoolPaie ; net-entreprises accepte les deux. `DPAE_<mois>_recapitulatif.txt`
donne la même chose en clair pour la saisie en ligne, qui reste une option
raisonnable pour deux personnes.

## Ce que le rejeu couvre aujourd'hui

```
DSN juillet 2026 ......... identique
DSN juin 2026 ............ identique
DSN mars/avril/mai 2026 .. contrats à l'heure, régularisation annuelle S21.G00.82
DSN janvier/février 2026 . structure de blocs antérieure
DSN 2021-2025 ............ non rejouées : barèmes de ces années absents
AEM 2026 ................. 10 fichiers sur 10 identiques octet pour octet
```

Ajouter `config/baremes/2025.json` et les précédents étendrait mécaniquement la
couverture ; ce n'est utile que pour se rassurer, pas pour produire.

## Le dépôt, et le journal

Ces déclarations engagent l'employeur. Le moteur les dépose **par l'API**
(DSN : `dsn_api.py`, net-entreprises ; DPAE : `dpae_api.py`, Urssaf), jamais
par un portail : un contrat écrit, des retours lus par programme, et une
erreur qui se voit — la première DPAE du 12/09/2026 a été refusée cinq fois
pour un code Urssaf faux que le portail DUE de CoolPaie laissait passer.

Trois garde-fous, tous dans `operations` (`operations_declarations.py`, sur la preuve du socle) :

- **Une séance.** Rien ne part sans le coffre ouvert et les trois gestes de
  l'ouverture (`README.md`) ; la ligne de commande ne dépose pas.
- **Pas deux fois.** `produire_dpae` refuse une embauche déjà déclarée et non
  refusée (`DpaeDejaDeclaree`), `deposer_dsn` une DSN réelle déjà partie pour
  le mois (`DsnDejaDeposee`). Une déclaration **refusée** repart sans forcer —
  c'est la seule raison de la refaire.
- **Un dépôt n'est pas fini quand il est parti.** `journal.py` écrit une ligne
  par acte sortant dans `journal/depots.json` (dépôt, courriel, demande de
  signature), avec le `flux` rendu par le point de dépôt, puis y rattache les
  retours relevés à l'ouverture. `verdict_du_retour` lit les bilans (natures
  10/11) : une DPAE est **passée quand son bilan est OK**, le certificat 41
  confirme, il ne décide plus. `resume()` dit « REFUSÉ : motif », « bilan OK »,
  « en TEST ».

Déposer la DSN en test avant le dépôt réel, et garder CoolPaie installé le temps
de faire tourner un ou deux mois en parallèle et de comparer.


## La version, et la mise à jour dans l'ombre

`VERSION` (une date, `AAAA.MM.JJ`, comparée en entiers) ; `moteur/maj.py`.
Un dépôt est une adresse (dossier ou URL) qui sert deux fichiers :
`derniere.json` (`version`, `archive`, `sha256`, `notes`, `calcul`) et
l'archive zip du contenu de `logiciel/` (sans `__pycache__`, `.git`,
`.avant`), déterministe.

- `verifier(ctx)` — à l'ouverture, chez une compagnie (`operations_ouverture`,
  `maj=True`, sauté chez l'éditeur) : lit `derniere.json`, télécharge si
  plus récent, vérifie le condensat, déballe dans `prive/maj/<version>/logiciel/`,
  contrôle par sous-processus (`python -m moteur version --controle`, avec
  `PUPPETPAIE_DONNEES` sur la racine de la compagnie : tout s'importe et la
  configuration se lit), pose `prive/maj/prete.json`. Ne lève jamais.
- `appliquer(ctx)` — par le lanceur, avant le serveur (refusé si le port
  7331 répond) : `logiciel/*` → `logiciel/.avant/`, puis la version prête
  → `logiciel/` ; retour arrière si une étape casse ; `appliquee.json`
  garde `calcul` avec `vue: false`, montré une fois au passage suivant.
- `revenir(ctx)` — `.avant/` reprend la place.
- `publier(depot, notes, calcul)` — chez l'éditeur (`config/maj.json`,
  `editeur: true`, aussi ce qui déclenche la veille des sources à
  l'ouverture) ; refuse de republier un numéro.
