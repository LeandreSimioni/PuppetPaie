# Les rubriques de paie — comment elles sont construites

Question posée par Léandre le 09/09/2026 : *« il faut saisir toutes les
rubriques et essayer de comprendre comment CoolPaie les a construites. Dans le
futur on n'aura plus CoolPaie ; si on veut en construire, il faut soit
comprendre la règle, soit trouver des docs officielles. »*

C'est la bonne question, et elle a une réponse. Ce document dit ce qui est
établi, ce qui reste une hypothèse, et où se trouvent les sources.

> ⚠️ **À relire avant de s'en servir.** Léandre a relevé le 10/09/2026 trois
> approximations dans ce document : il n'y a **plus de cachet de 8 heures**
> depuis longtemps ; **jour et cachet ne sont pas la même chose** (les jours
> sont les jours effectivement travaillés, on peut faire 1 cachet et 8 h sur
> deux ou trois jours) ; et surtout ce document répond à « comment CoolPaie a
> rempli son catalogue », pas à **« comment construit-on une rubrique »**, qui
> est la question qui rend autonome. Voir `prive/journal/ETAT.md` §14. Rien
> n'a été corrigé ici en attendant.

---

## 1. Ce qu'est une rubrique

Le catalogue de CoolPaie compte **79 rubriques**, dans
`prive/reference/rubriques-coolpaie.csv`. Chacune porte cinq informations :

| colonne | ce que c'est |
|---|---|
| `code` | l'identifiant saisi (`ci`, `srp`, `m35`) |
| `libelle` | ce qui s'imprime sur le bulletin |
| `dsn` | un code DSN, **seulement pour 5 d'entre elles** |
| `type` | la famille : Brut, Indemnité, Congés payés, Déplacements… |
| `jours` / `heures` | les deux coefficients — le cœur du sujet |

Une ligne de bulletin est alors `quantité × taux`, la quantité étant un nombre
de cachets, d'heures, de journées ou de mois selon la rubrique. Les deux
coefficients ne servent pas au calcul du salaire : ils servent à **déclarer**.

## 2. Les deux coefficients, et à quoi ils servent vraiment

C'est le point qu'il fallait comprendre, et il est simple une fois vu :

- **`jours`** alimente le décompte des jours travaillés — l'AEM France Travail,
  et le plafond déclaré en DSN (`S21.G00.79.001`).
- **`heures`** alimente les **heures équivalentes** des annexes 8 et 10 : les
  507 heures sur douze mois qui ouvrent les droits.

Les deux ne se déduisent pas l'un de l'autre, et c'est pour cela qu'il en faut
deux. Un cachet isolé, c'est **1 jour et 12 heures** : douze heures qui n'ont
jamais été faites, mais que la réglementation chômage accorde.

### Et les heures ne comptent pas toutes pour la même chose

Une troisième distinction, à l'intérieur des heures cette fois, et elle est
tout aussi peu déductible : les **heures d'enseignement** (masterclass, action
culturelle) font atteindre les 507 heures — dans la limite de 70 h avant 50
ans, 120 h à partir de 50 ans — mais **n'entrent pas dans le calcul du montant
de l'ARE**. C'est le champ `compte_pour` du catalogue :
`ouverture_des_droits` au lieu de `droits_et_montant`.

D'où **deux totaux** dans `cumul.py`, et non un :

| | ce qu'il répond |
|---|---|
| `heures_ouverture` | ai-je mes 507 heures ? — enseignement compris, plafonné |
| `heures_montant` | sur combien d'heures l'allocation sera-t-elle calculée ? — enseignement exclu |

**L'AEM ne sait pas les distinguer** : une heure de masterclass et une heure de
plateau tombent dans les mêmes trois positions `[650:653]`. Ce qui sait, c'est
le fichier de paie, où la ligne porte sa rubrique. Le total vient donc de l'AEM
déposée — elle fait foi — et la part d'enseignement des paies, rapprochée par
contrat (salarié, début, fin). Les heures enseignées chez un **autre**
employeur ne sont dans aucun des deux : elles manquent, comme manquent ses
autres cachets.

## 3. Les constantes, toutes retrouvées

Chaque coefficient du catalogue se déduit de cinq constantes. Vérifié ligne à
ligne, au centième :

| constante | valeur | d'où elle vient |
|---|---|---|
| Cachet **isolé** | 12 h | règlement d'assurance chômage, annexes VIII et X |
| Cachet **groupé** | 8 h | idem — à partir de 5 cachets sur une même période |
| Journée de travail | 7 h | base journalière de la profession |
| Mois | 21,67 j et 151,67 h | 5 × 52 ÷ 12 = 21,67 ; 35 × 52 ÷ 12 = 151,67 |
| Trentième | 21,67 ÷ 30 et 151,67 ÷ 30 | l'absence maladie se compte au trentième |

Et les vérifications qui le prouvent :

```
s5   Semaine de 5 jours     5 j   35 h   =  5 × 7
s6   Semaine de 6 jours     6 j   42 h   =  6 × 7
m35  Mois de 35 heures  21,67 j  151,67 h
absma Absence maladie   −0,722 j  −5,056 h  = 21,67/30 et 151,67/30
hSt15 Heure de stage     0,142 j    1 h      ≈ 1/7 (0,1429)
j8 / j10 / j12             1 j    8/10/12 h  — les heures réelles
srp3 / srp  Répétition     1 j     3 / 4 h   — les heures réelles
sri  Service isolé        0,5 j     12 h     — demi-journée, cachet plein
```

**Les absences sont les mêmes rubriques en négatif.** `absj` vaut −1 j / −7 h,
`absm` −21,67 j / −151,67 h. Rien de nouveau à comprendre : une absence retire
ce qu'une présence aurait apporté.

## 4. Donc : comment construire une rubrique

Trois décisions, dans cet ordre. Aucune n'est arbitraire.

1. **Ce qu'elle paie.** Une quantité et un taux — des cachets à 130 €, des
   heures à un taux horaire, un mois à un salaire mensuel.
2. **Son coefficient `jours`** : combien de jours travaillés elle fait
   compter. Un cachet, une journée : 1. Un service isolé : 0,5. Une rubrique
   horaire : 1/7 par heure (0,143), ou 0 si elle ne fait pas compter de jour
   (`mast`, masterclass). Un mois : 21,67.
3. **Son coefficient `heures`** : les heures réelles, **sauf** quand la
   réglementation chômage fixe un forfait — 12 h le cachet isolé, 8 h le
   cachet groupé.

Un exemple, pour fixer les idées. Une rubrique « filage » de 5 heures qui
compte pour une journée s'écrirait `jours = 1`, `heures = 5`. Une rubrique
« résidence, semaine de 4 jours » s'écrirait `jours = 4`, `heures = 28`.

**Ce qu'il ne faut pas faire** : inventer un coefficient parce qu'il « semble
juste ». Ces deux nombres partent dans l'AEM et dans le plafond DSN ; un
coefficient faux ne se voit nulle part et fausse les droits du salarié
plusieurs années plus tard. Si la règle n'est pas trouvée, elle se demande —
à France Travail pour les jours, à Audiens ou à la convention pour le reste.

## 5. Les sources officielles

Pour ne plus dépendre de CoolPaie, ce sont elles qu'il faut consulter :

| ce qu'on y trouve | où |
|---|---|
| Les 12 h / 8 h, le seuil des 507 heures, la date anniversaire | règlement d'assurance chômage, **annexes VIII et X** (unedic.org) |
| Les jours et heures à déclarer, les codes emploi | **cahier technique AEM V5**, France Travail (declarationspectacle.francetravail.fr) |
| Le plafond `S21.G00.79.001` et les codes de rémunération | **cahier technique DSN**, norme NEODeS — déjà dans `prive/reference/norme-dsn/` |
| Les taux de cotisation réglementaires | **Table des paramètres du BOSS**, en CSV — voir `prive/reference/veille-taux.md` |
| Les taux Audiens | espace employeur, « Gestion des cotisations » → « Taux de cotisations », un `.xls` par organisme |
| Les minima de salaire, les heures de service | **convention collective IDCC 3090**, spectacle vivant privé |

## 6. Ce qui n'est PAS élucidé

Deux choses, et elles sont signalées comme telles plutôt que devinées.

**Le `#` final.** Vingt-et-une rubriques sur 79 portent un `#` : activité
partielle (`acap#`, `ihap60#`, `icap70#`…), primes exceptionnelles (`ppv#`,
`pexpa#`, `IndInf#`), heures supplémentaires et complémentaires (`hsUE25#`,
`hcUE10#`), et les deux services de répétition « contrat ≥ 5 j »
(`srp3cg#`, `srp4cg#`).

L'hypothèse — **non vérifiée** — est que le `#` marque une rubrique dont le
traitement social sort du régime commun : exonération plafonnée pour les
primes, CSG à taux réduit pour l'activité partielle, réduction salariale pour
les heures supplémentaires. Elle explique dix-neuf des vingt-et-une ; les deux
rubriques de répétition, elles, sont seulement conditionnelles à la durée du
contrat. **À confirmer avant d'en tirer quoi que ce soit.**

**Les 5 codes DSN.** Cinq rubriques seulement portent un code DSN
(`AENa` → `AN-AU`, `co2`/`co5` → `FT`, `dns` → `FP-AF`, `tre` → `TR`). Ce sont
des avantages en nature et des frais professionnels, qui se déclarent dans des
blocs propres. Les autres rubriques n'ont pas de code parce qu'elles alimentent
le brut, déclaré globalement. C'est cohérent, mais la correspondance complète
reste à établir depuis la norme NEODeS.

## 7. Où en est le moteur

Il ne connaît aujourd'hui que **deux formes** : des cachets (`cachets` ×
`taux_cachet`) et des heures (`heures` × `taux_horaire`). C'est assez pour ce
que joue la compagnie, et c'est calé au centime sur cinq ans de bulletins.

Ce n'est pas assez pour une répétition, un service isolé ou une masterclass :
le brut serait juste, les coefficients non — donc l'AEM et le plafond DSN
seraient faux, sans que rien ne le signale.

**Le passage à la saisie par rubrique** consiste à remplacer `cachets` +
`heures` par une liste de `{code, quantité, taux}`, et à faire porter les deux
coefficients par le catalogue plutôt que par le code. Le « 12 h par cachet »
inscrit aujourd'hui dans `moteur/cumul.py` cesserait d'être une constante du
moteur pour devenir une donnée — la même règle que le barème, et pour la même
raison : ce qui change sans nous ne doit pas vivre dans le code.
