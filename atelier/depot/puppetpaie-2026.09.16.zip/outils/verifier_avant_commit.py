"""Refuse qu'une donnee personnelle parte dans le depot public.

    python outils/verifier_avant_commit.py            # tout le depot
    python outils/verifier_avant_commit.py --indexes  # ce que git s'apprete a commiter

Le depot est public ; les donnees ne le sont pas. `prive/` est hors du depot,
ce qui regle le gros du probleme -- mais pas celui-ci : **le code parle des
vraies personnes**. L'enquete qui a reconstitue le bareme s'est faite sur de
vrais bulletins, et les commentaires la racontent avec de vrais chiffres.

Ce script est la parce que la vigilance ne tient pas dans le temps. On
ecrira encore des commentaires, et il suffit d'un jour de fatigue.

**Il ne contient aucune donnee sensible.** Il LIT ce qu'il faut proteger dans
`prive/config/`, qui n'est pas versionne. Un garde-fou qui porterait la liste
des NIR a proteger serait exactement ce qu'il pretend empecher.

Pose en hook git :

    git config core.hooksPath .githooks

Sortie : 0 si rien n'a ete trouve, 1 sinon, avec la liste fichier par ligne.
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent

# Ce qu'on ne cherche PAS : les dossiers de donnees (hors depot de toute
# facon), les caches, et ce fichier -- qui parle de NIR sans en porter.
IGNORES = {"__pycache__", ".git", "prive", "config", "paies", "sorties",
           "retours", "gabarits", "reference", "avant"}
EXTENSIONS = {".py", ".md", ".html", ".css", ".js", ".json", ".txt", ".cmd",
              ".pyw", ".modele", ".yml", ".yaml", ".toml"}

# Les valeurs FABRIQUEES qui remplacent les vraies dans les tests et les
# exemples. Elles ne designent personne, mais elles ont la forme du vrai --
# c'est meme leur interet : leurs cles se verifient, donc un test ne peut pas
# passer sur un numero impossible. Sans cette liste, le motif generique les
# signalerait a chaque fois et le garde-fou finirait ignore.
#
# Y ajouter une valeur est un acte visible, relu comme le reste du code. N'y
# mettre QUE des valeurs inventees : cette liste est publiee avec le depot.
FICTIVES = {
    "2910599999999": "NIR feminin fabrique (cle 97)",
    "1880275999999": "NIR masculin fabrique (cle 21)",
    "1234567890123": "NIR de forme invalide, pour les tests de rejet",
    "12345678900017": "SIRET fabrique (cle de Luhn juste)",
}


def _secrets_a_proteger() -> list:
    """Les valeurs a ne jamais publier, lues hors du depot.

    Rend une liste de (motif, quoi, casse). `casse` dit si la recherche
    respecte les majuscules : un BIC et un IBAN s'ecrivent en capitales, et
    chercher « CHIFFRE » sans tenir compte de la casse trouve le mot
    « chiffres » dans une phrase francaise -- premiere version de ce script,
    56 fausses alertes.

    Si la configuration est absente -- un clone frais, une autre machine --
    on se rabat sur les motifs generiques, qui suffisent a attraper un NIR ou
    un IBAN quelconque.
    """
    import json

    motifs = [
        # Un NIR : sexe, annee, mois, puis 8 chiffres. Le motif generique
        # attrape aussi ceux qu'on ne connait pas.
        # Sexe, annee, MOIS 01-12, puis 8 a 9 chiffres. Le mois est restreint
        # aux valeurs courantes : sans cela, un horodatage « 20260906080000 »
        # se lit comme un NIR. On y perd les immatriculations a mois 20-42,
        # rares ; ce motif n'est qu'un filet, les vraies valeurs a proteger
        # sont lues dans la configuration, plus bas.
        (r"\b[12][0-9]{2}(?:0[1-9]|1[0-2])[0-9]{8,9}\b", "NIR", True),
        (r"\bFR\d{2} ?(?:\d{4} ?){5}\d{3}\b", "IBAN", True),
        # Un BIC est en capitales et porte au moins un chiffre chez nous.
        # Sans ces deux contraintes, le motif trouvait le mot « chiffres »
        # dans une phrase francaise : 56 fausses alertes, premiere version.
        (r"\b[A-Z]{4}FR[A-Z0-9]{2}[0-9][A-Z0-9]{0,2}\b", "BIC", True),
    ]
    cfg = CODE.parent / "prive" / "config"
    if not cfg.is_dir():
        return motifs

    valeurs = {}
    try:
        ent = json.loads((cfg / "entreprise.json").read_text(encoding="utf-8"))
        for cle in ("siret", "siren", "urssaf_compte",
                    "congesspectacles_affiliation", "affiliation_france_travail"):
            if ent.get(cle):
                valeurs[str(ent[cle])] = cle
        banque = ent.get("banque") or {}
        for cle in ("iban", "bic"):
            if banque.get(cle):
                valeurs[str(banque[cle])] = "banque." + cle
        sal = json.loads((cfg / "salaries.json").read_text(encoding="utf-8"))
        for k, s in sal.items():
            if k.startswith("_"):
                continue
            for cle in ("nir", "num_conges_spectacles", "email", "adresse"):
                if s.get(cle):
                    valeurs[str(s[cle])] = "%s.%s" % (k, cle)
            # Le nom seul est trop courant pour etre un motif ; le nom ET le
            # prenom colles le sont beaucoup moins.
            if s.get("nom") and s.get("prenom"):
                valeurs["%s %s" % (s["nom"], s["prenom"])] = "%s (identite)" % k
    except (OSError, ValueError, KeyError):
        return motifs

    for v, quoi in valeurs.items():
        if len(str(v)) >= 6:              # sous 6 caracteres, trop de faux positifs
            motifs.append((re.escape(str(v)), quoi, False))
    return motifs


def _fichiers(indexes: bool) -> list:
    if indexes:
        sortie = subprocess.run(["git", "diff", "--cached", "--name-only",
                                 "--diff-filter=ACM"],
                                cwd=CODE, capture_output=True, text=True)
        noms = [n for n in sortie.stdout.splitlines() if n.strip()]
        return [CODE / n for n in noms if (CODE / n).is_file()]
    out = []
    for p in CODE.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in EXTENSIONS:
            continue
        if IGNORES & set(p.relative_to(CODE).parts):
            continue
        out.append(p)
    return out


def verifier(indexes: bool = False) -> list:
    motifs = [(re.compile(m, 0 if casse else re.IGNORECASE), quoi)
              for m, quoi, casse in _secrets_a_proteger()]
    moi = Path(__file__).resolve()
    trouvailles = []
    for f in _fichiers(indexes):
        if f.resolve() == moi:
            continue
        try:
            texte = f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for n, ligne in enumerate(texte.splitlines(), 1):
            for motif, quoi in motifs:
                m = motif.search(ligne)
                if m and m.group(0) not in FICTIVES:
                    trouvailles.append({
                        "fichier": str(f.relative_to(CODE)), "ligne": n,
                        "quoi": quoi, "extrait": ligne.strip()[:110]})
                    break
    return trouvailles


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--indexes", action="store_true",
                    help="ne verifier que les fichiers indexes par git")
    args = ap.parse_args(argv)

    trouvailles = verifier(args.indexes)
    if not trouvailles:
        print("Rien de personnel dans le code. C'est publiable.")
        return 0

    print("ARRET - %d occurrence(s) de donnees personnelles :\n" % len(trouvailles))
    par_fichier = {}
    for t in trouvailles:
        par_fichier.setdefault(t["fichier"], []).append(t)
    for fichier, lignes in sorted(par_fichier.items()):
        print("  %s" % fichier)
        for t in lignes:
            print("    ligne %-5d %-22s %s" % (t["ligne"], t["quoi"], t["extrait"]))
        print()
    print("Ces valeurs identifient des personnes reelles. L'historique d'un")
    print("depot est definitif : une fois pousse, efface ne veut plus rien dire.")
    print("Retirer les identites, garder les chiffres -- ce sont eux qui prouvent")
    print("que le moteur est cale. Voir AVANT-LE-PREMIER-COMMIT.md.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
