"""Produit un contrat fictif sur trois mois, dans un bac jetable, et range ses
trois DSN (et les recapitulatifs) dans un dossier -- pour les deposer EN
TEST avant le premier contrat reel a cheval.

    python outils/essai_contrat_plurimensuel.py                 # oct.-dec. 2026
    python outils/essai_contrat_plurimensuel.py 2026-07          # juil.-sept. 2026
    python outils/essai_contrat_plurimensuel.py 2026-07 --vers DOSSIER
    python outils/essai_contrat_plurimensuel.py 2026-01 --creux   # 2e mois sans cachet

Le bac est une copie de la configuration sans les secrets ; AUCUN compteur
reel ne bouge, aucune saisie reelle n'est touchee. Le contrat : premiere
salariee active, premier spectacle actif, 2 + 1 + 3 cachets a 130 EUR, du 12
du premier mois au 20 du troisieme, saisi comme l'ecran le ferait (planning
coche depuis le premier mois, reprises ensuite). Montant Urssaf pose a
100 EUR, fictif.

Ce que les trois DSN doivent montrer (ETAT.md §26, fiche 3344, cahier
technique NEODeS 2026.1) : bloc 40 identique -- quotite 40.012/013 comprise,
les jours du contrat entier --, bloc 62 au dernier mois seulement, blocs
51/50/54/58/78 bornes au mois. Avec `--creux`, le deuxieme mois n'a aucun
cachet : sa DSN porte le contrat avec un versement a zero (bloc 50 et 51 a
0.00, bloc 53 a 0.00 jour, ni 54, ni 78, ni 81), et il n'a pas de bulletin.

Un mois futur peut etre refuse par la plate-forme en depot de test : donner
alors un premier mois passe (`2026-07`), la structure est la meme.
"""
from __future__ import annotations

import argparse
import calendar
import json
import shutil
import sys
import tempfile
from pathlib import Path

CODE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(CODE))

from moteur import operations as ops                     # noqa: E402
from moteur.contexte import Contexte                     # noqa: E402


def _mois_suivant(mois: str) -> str:
    an, mo = int(mois[:4]), int(mois[5:7])
    return "%d-%02d" % (an + (mo == 12), (mo % 12) + 1)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("premier_mois", nargs="?", default="2026-10", help="AAAA-MM")
    ap.add_argument("--vers", help="dossier de sortie (defaut : "
                    "prive/reference/exemples/dsn-val/contrat-plurimensuel)")
    ap.add_argument("--creux", action="store_true",
                    help="le deuxieme mois n'a aucun cachet")
    args = ap.parse_args(argv)

    vrai = Contexte()
    cible = Path(args.vers) if args.vers else (
        vrai.racine / "reference" / "exemples" / "dsn-val" / "contrat-plurimensuel")
    m1 = args.premier_mois
    m2, m3 = _mois_suivant(m1), _mois_suivant(_mois_suivant(m1))
    cachets = {m1: ["%s-12" % m1, "%s-13" % m1],
               m2: [] if args.creux else ["%s-05" % m2],
               m3: ["%s-18" % m3, "%s-19" % m3, "%s-20" % m3]}
    fin = "%s-20" % m3

    racine = Path(tempfile.mkdtemp(prefix="puppetpaie-essai-"))
    try:
        shutil.copytree(vrai.racine / "config", racine / "config",
                        ignore=shutil.ignore_patterns("*.bin", ".seance", "avant"))
        (racine / "paies").mkdir()
        bac = Contexte(racine)
        cle = next(iter(bac.salaries_actifs))
        spec = next(iter(bac.spectacles_actifs))
        cible.mkdir(parents=True, exist_ok=True)
        for m, jours in cachets.items():
            e = {"salarie": cle, "spectacle": spec, "debut": "%s-12" % m1,
                 "lignes": [{"rubrique": "cachet", "quantite": len(jours), "taux": 130,
                             "lieu": "Varzy", "dates": jours}] if jours else []}
            suite = [x for mm, xs in cachets.items() if mm > m for x in xs]
            if suite and jours:
                e["lignes"][0]["planning"] = suite
            else:
                # Le dernier mois, ou un mois creux : le planning ne se porte
                # que sur une ligne, et il n'y en a pas -- `fin` dit la borne.
                e["fin"] = fin
            an, mo = int(m[:4]), int(m[5:7])
            p = racine / "paies" / ("%s.json" % m)
            p.write_text(json.dumps(
                {"mois": m, "taux_cachet": 130.0,
                 "date_paiement": "%s-%02d" % (m, calendar.monthrange(an, mo)[1]),
                 "engagements": [e]}, ensure_ascii=False, indent=2), encoding="utf-8")
            # Le bordereau Urssaf fictif : 100 EUR, et 0 sur un mois creux,
            # ou rien n'est du -- un montant qui ne colle pas aux cotisations
            # agregees (23.004) serait releve par l'Urssaf, pas par la norme.
            r = ops.produire_mois(Contexte(racine), p,
                                  urssaf=100.0 if jours else 0.0, qui="essai")
            for f in r.fichiers:
                if f.suffix in (".dsn", ".txt"):
                    shutil.copy(f, cible / f.name)
            shutil.copy(p, cible / p.name)
            print("%s : %s" % (m, ", ".join(f.name for f in r.fichiers)))
    finally:
        shutil.rmtree(racine, ignore_errors=True)
    print("Range dans %s" % cible)
    return 0


if __name__ == "__main__":
    sys.exit(main())
