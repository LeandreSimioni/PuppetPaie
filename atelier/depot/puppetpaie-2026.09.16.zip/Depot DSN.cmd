@echo off
rem ---------------------------------------------------------------
rem  Depot DSN - Compagnia UEUEUE
rem  Ouvre la fenetre de depot de la declaration sociale nominative.
rem  Le mot de passe se tape dans la fenetre. Il n'est stocke nulle part.
rem  Sans la case "pour de vrai", rien n'est declare.
rem ---------------------------------------------------------------
cd /d "%~dp0"

where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "lanceur_dsn.pyw"
    exit /b 0
)

where py >nul 2>nul
if %errorlevel%==0 (
    start "" pyw "lanceur_dsn.pyw"
    exit /b 0
)

echo.
echo   Python est introuvable sur cette machine.
echo   Installer Python 3 depuis https://www.python.org/downloads/
echo   en cochant "Add Python to PATH", puis relancer ce raccourci.
echo.
pause
