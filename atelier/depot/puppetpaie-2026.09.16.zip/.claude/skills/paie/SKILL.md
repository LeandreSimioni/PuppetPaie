---
name: paie
description: Fabrique les paies d'intermittents de la Compagnia UEUEUE - bulletins, contrats, DPAE, AEM France Travail et DSN mensuelle. Déclencher dès que Léandre demande une ou plusieurs paies, un bulletin, un cachet, une DSN, une AEM, une DPAE/DUE, ou parle d'engager quelqu'un sur un spectacle à des dates données. Exemples : « fais 2 paies pour Ana et Léandre les 2 et 3 octobre pour Oooh Teresina », « la DSN d'octobre », « il faut déclarer Anastasia sur 3 cachets ».
---

# Paie intermittents - Compagnia UEUEUE

Le calcul est fait par `moteur/`, pas par toi. Ton rôle : comprendre la
demande, écrire le fichier de saisie, lancer la commande, relire la sortie.
Ne calcule jamais une cotisation ni un net à la main, même pour vérifier —
le moteur est calé au centime sur les bulletins réels, pas toi.

## Marche à suivre

1. **Comprendre.** Il faut : qui, quelles dates jouées, quel spectacle. Le reste
   a des valeurs par défaut (130 € le cachet, un cachet par date, contrat du
   premier au dernier jour joué).

2. **Écrire `paies/AAAA-MM.json`.**

```json
{
  "mois": "2026-10",
  "spectacle": "oooh teresina",
  "taux_cachet": 130.0,
  "date_paiement": "2026-10-31",
  "engagements": [
    { "salarie": "Ana",     "dates": ["2026-10-02", "2026-10-03"] },
    { "salarie": "Leandre", "dates": ["2026-10-02", "2026-10-03"] }
  ]
}
```

   Les noms sont résolus de façon tolérante (« Ana », « Lenadre », « teresina »).
   Champs facultatifs par engagement : `cachets` si le nombre diffère du nombre
   de dates, `taux_cachet`, `debut`/`fin` si le contrat déborde des dates
   jouées, `heures` si la personne est payée à l'heure, `lieu`, `numero`.

   Un mois peut contenir plusieurs contrats pour la même personne : un
   engagement par contrat, chacun avec ses dates.

3. **Lancer** `python -m moteur mois paies/AAAA-MM.json` depuis `claude/`.

4. **Relire et rendre compte.** Reprends le tableau affiché (brut, net, coût
   employeur par personne), dis où sont les fichiers et rappelle les trois
   dépôts à faire. Ne recopie pas le détail des cotisations : c'est dans le PDF.

## Ce qu'il faut demander avant de lancer

- Le spectacle est inconnu du catalogue → demander son **numéro d'objet
  France Travail** et l'ajouter à `config/spectacles.json`. Ne jamais inventer
  un numéro d'objet, et ne jamais réutiliser celui d'une autre année : France
  Travail en délivre un par spectacle **et par année** (`266Z…` pour 2026).
- La personne est inconnue → demander nom, prénom, NIR + clé, date et lieu de
  naissance, adresse, e-mail, et l'ajouter à `config/salaries.json`.
- Le taux du cachet n'est pas 130 € → le demander plutôt que le supposer.

## Après la génération

Rappelle l'ordre des dépôts, il compte :

1. **DPAE** sur net-entreprises.fr — **avant** le premier jour de travail. Si le
   contrat a déjà commencé, dis-le clairement : la DPAE est en retard.
2. **Contrat** signé.
3. **AEM** sur declarationspectacle.francetravail.fr.
4. **DSN** — la **déposer en test** (`depot-dsn --test`) et lire le bilan
   **avant** le dépôt réel.
5. **Certificats Congés Spectacles** — `CertificatsCS_<Mois><Année>.pdf` :
   **rien à déposer nulle part**, ils sont dus AU SALARIÉ, avec son bulletin.
   Les N° CE sont une séquence continue de l'employeur : ils sont consommés
   dès que le mois est produit, ne les rejoue pas pour rien.

Le montant Audiens du bloc `S21.G00.20` doit être **recopié du bordereau
Audiens** : `--audiens MONTANT`. Il n'est pas calculable depuis la paie, et
sans lui la commande s'arrête sans rien écrire. Si Léandre n'a pas encore le
bordereau, dis-le et propose `--audiens-estime`, en rappelant que la DSN
produite ne doit alors pas être déposée telle quelle.

Échéance DSN : le 5 ou le 15 du mois suivant selon l'effectif — pour cette
compagnie, le 15.

## Limites à signaler plutôt qu'à contourner

- Contrat mêlant cachets et heures : il faut `heures` **et** `taux_horaire`
  dans la saisie (le taux du cachet ne s'applique pas aux heures). Sans le taux
  horaire, le moteur refuse le contrat plutôt que de deviner.
- Régularisation annuelle, arrêt de travail, DSN événementielle : hors moteur.
- Année sans barème dans `config/baremes/` : le moteur s'arrête avec un message
  explicite. Créer le fichier à partir du plus récent, mettre à jour SMIC et
  taux, puis `python -m moteur calibrer`.

## En cas de doute sur un chiffre

`python -m moteur calibrer` rejoue les déclarations déjà déposées et les compare
aux originaux. C'est la réponse à « est-ce que ça calcule juste ? » — pas une
vérification mentale.
