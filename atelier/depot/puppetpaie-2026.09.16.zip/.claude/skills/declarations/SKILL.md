---
name: declarations
description: Où, quand et comment déposer les déclarations sociales de la Compagnia UEUEUE - DPAE, AEM France Travail, DSN mensuelle, Congés Spectacles, Audiens. Déclencher quand Léandre demande une échéance, un calendrier de dépôt, où déposer un fichier, ce qui reste à déclarer, ou signale un rejet de déclaration.
---

# Calendrier et dépôt des déclarations

La compagnie emploie des intermittents (artistes, CDD d'usage, convention
collective IDCC 3090). Quatre déclarations, quatre destinataires.

## DPAE - déclaration préalable à l'embauche

- **Où** : net-entreprises.fr, rubrique DPAE (dépôt de fichier ou saisie), ou
  l'API Urssaf — `Depot DPAE.cmd`, voir plus bas.
- **Quand** : dans les 8 jours qui précèdent l'embauche, et **obligatoirement
  avant** que la personne commence à travailler.
- **Produire** : `python -m moteur dpae paies/<mois>.json --heure HHMM`. Cette
  commande ne fait que la DPAE : ni Audiens, ni numéro de bulletin consommé.
  Ne pas passer par `mois` pour une DPAE — elle est due un mois plus tôt.
- **Fichier** : `sorties/<mois>/DPAE_<Mois><Année>.txt` — enregistrements de
  990 caractères collés bout à bout. Pour saisir en ligne, utiliser
  `DPAE_<Mois><Année>_recapitulatif.txt`. Le `.zip` sert au dépôt manuel ;
  l'API, elle, refuse les archives.
- **Déposer par l'API** : `Depot DPAE.cmd` ouvre la fenêtre. Essai à blanc par
  défaut ; le dépôt réel demande la case cochée et le mot de passe **Urssaf**
  (pas celui de net-entreprises : ce sont deux comptes distincts). Jamais
  déposé automatiquement après la production.
- **Le dépôt de test** parcourt toute la chaîne sans rien déclarer : bouton
  « Dépôt de test », ou `--test`. `C_VERSION` bascule en `TST` en mémoire. À
  faire avant tout premier dépôt réel du mois si l'on a un doute.
- **Une seule fenêtre à la fois** : ne pas mettre dans un même dépôt des
  embauches à plus de 8 jours. La commande refuse, et c'est voulu.
- Une DPAE en retard est une infraction : le dire franchement plutôt que de la
  faire passer discrètement.

## AEM - attestation employeur mensuelle

- **Où** : declarationspectacle.francetravail.fr.
- **Quand** : au plus tard le 15 du mois suivant le dernier jour travaillé.
  Sans elle, l'artiste ne peut pas faire valoir ses cachets pour l'intermittence.
- **Fichier** : `sorties/<mois>/AEM_<Mois><Année>_EDIV5.txt`.
- Le **numéro d'objet** du spectacle est délivré par France Travail, un par
  spectacle et par année (`216Z…` = 2021 … `266Z…` = 2026). Le demander en
  janvier pour tous les spectacles de l'année.

## DSN mensuelle

- **Où** : net-entreprises.fr. **Toujours déposer en test d'abord**
  (`depot-dsn --test`) : c'est le validateur qui fait foi — la brique de
  contrôle officielle, à jour — et il détecte ce que le moteur ne voit pas.
  DSN-Val (l'outil local) n'est pas installé et ne le sera pas : 200 Mo + Java
  pour le même moteur (`prive/reference/norme-dsn/LISEZMOI.md`).
- **Quand** : le 15 du mois suivant (entreprise de moins de 50 salariés).
- **Fichier** : `sorties/<mois>/DSN_<Mois><Année>.dsn`, norme NEODeS P26V01.
- **Montant Audiens** du bloc `S21.G00.20` : ordre de télépaiement, non
  calculable depuis la paie (Audiens facture des éléments non détaillés et
  régularise en avril). Il se recopie du bordereau : `--audiens MONTANT`.
  Sans lui, la commande s'arrête sans rien écrire.
- Une DSN « néant » reste due les mois sans paie.

## Congés Spectacles et Audiens

Depuis le passage en DSN, les congés spectacles (15,5 % du brut) et les
cotisations Audiens sont déclarés **par la DSN** : rien à envoyer à Audiens en
plus. Ne restent que les paiements, sur bordereau.

**Mais il reste un document dû au SALARIÉ** : le *certificat d'emploi Congés
Spectacles*, à lui remettre à l'issue de chaque contrat — c'est la pièce qui lui
sert à réclamer ses congés payés à Audiens. Il ne part nulle part ailleurs.

**Le moteur l'édite depuis le 09/09/2026** : `CertificatsCS_<Mois><Année>.pdf`,
produit par `python -m moteur mois` à côté du bulletin et de l'AEM. Audiens a
délivré le numéro d'édition sur papier blanc le 07/09/2026 (adhérent
`0360220002F`, premier N° CE `1`).

Deux choses à savoir quand la question revient :

- **Le N° CE est une séquence continue de l'employeur**, pas une séquence
  annuelle. Elle ne repart jamais à 1. Deux certificats au même numéro seraient
  deux chèques au même numéro : Audiens écrit qu'ils « ont valeur de chèque émis
  sur votre compte ».
- **L'arriéré n'est pas rattrapé.** Aucun certificat n'a jamais été remis depuis
  le 11/10/2019. Si Léandre parle de congés spectacles, c'est le sujet à
  remonter. Détail dans `../prive/journal/CONGES-SPECTACLES.md` §6 bis.

## Échéances de paiement portées par la DSN

| Organisme | Bloc | Échéance |
|---|---|---|
| URSSAF | `S21.G00.20` réf. CS00011319 | 15 du mois suivant |
| Formation professionnelle (P0983) | `S21.G00.20` | fin du trimestre suivant |
| Congés Spectacles, Audiens, retraite | `S21.G00.20` | selon bordereau |

## En cas de rejet

Reprendre le message de net-entreprises, l'identifier dans le fichier
(`RUBRIQUE,'valeur'`), corriger la donnée dans `config/` ou dans le fichier de
saisie, régénérer, revalider. Ne jamais corriger le `.dsn` à la main : la
correction se perdrait au prochain mois.
