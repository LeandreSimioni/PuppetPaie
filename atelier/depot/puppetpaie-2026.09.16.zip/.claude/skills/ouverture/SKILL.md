---
name: ouverture
description: Ouvrir PuppetPaie au début d'une session — sauvegarder le dossier privé dans le Drive et relever les retours des organismes —, consulter l'état du coffre et de la séance, et savoir quelles actions sont permises. Déclencher au début de toute session de travail sur les paies, quand Léandre demande « où on en est », s'il parle des retours, d'une sauvegarde, d'un mot de passe, de la séance, ou avant de tenter un dépôt DSN ou DPAE.
---

# Ouvrir PuppetPaie

## Au début d'une session

```bash
cd claude/logiciel && python -m moteur ouverture
```

Elle sauvegarde le dossier privé dans le Drive (par différences) et relève les
retours des organismes. Elle **n'échoue jamais** : sans réseau, sans compte
Google ou sans secret posé, elle le dit et rend la main. Compter une dizaine de
secondes quand rien n'a bougé.

`--json` pour une sortie exploitable. `--pas-avant 20` pour ne rien refaire si
l'ouverture a moins de vingt minutes.

Puis lire ce qui est arrivé :

```bash
python -m moteur retours          # le détail, et les taux de PAS
python -m moteur pas              # l'état courant des taux
```

## Ce qui est permis, et ce qui ne l'est pas

| | condition |
|---|---|
| lire, calculer, produire un mois, sauvegarder, relever les retours | aucune |
| **déposer une DSN ou une DPAE** | **séance ouverte** |

```bash
python -m moteur seance           # ouverte ? combien de temps reste-t-il ?
```

La séance s'ouvre quand **un humain** tape le mot de passe du logiciel — à
l'ouverture de l'interface, ou par `python -m moteur seance --ouvrir`. Un agent
ne peut pas l'ouvrir : la saisie passe par `getpass`, qui échoue sans terminal.
C'est voulu.

Séance fermée et dépôt demandé : **dire qu'il faut l'ouvrir**, ne pas
contourner — ni en posant `NET_ENTREPRISES_MOTDEPASSE` à la place de Léandre,
ni autrement. Un dépôt engage la compagnie, ordres de télépaiement compris.

## Le coffre

```bash
python -m moteur coffre                          # ce qui est posé, jamais les valeurs
python -m moteur coffre poser net-entreprises    # (à Léandre de le taper)
python -m moteur coffre poser urssaf
python -m moteur coffre ouverture                # le mot de passe du logiciel
```

**Ne jamais lire `prive/config/coffre.bin`, `google-jeton.bin` ou `.seance`.**
`python -m moteur coffre` répond à toutes les questions légitimes sans afficher
un seul secret.

## Deux pièges à ne pas rejouer

1. **Ne jamais régénérer une déclaration déjà déposée.** Les numéros de contrat
   se renumérotent dès que les compteurs avancent : un annule-et-remplace aux
   numéros changés ne remplace plus rien de reconnaissable. Vérifier un fichier
   se fait avec `python -m moteur depot-dsn <fichier> --apercu`, qui ne touche
   ni au réseau ni au disque.
2. **Un dépôt de test consomme un numéro d'ordre** dans la base de test, qui
   est séparée de la base réelle. Déposer « pour voir » avant un
   annule-et-remplace réel fait échouer le réel avec `B1-208-11`.
