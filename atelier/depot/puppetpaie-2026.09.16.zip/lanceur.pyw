"""Fenetre de recuperation des retours DSN.

Se lance en double-cliquant sur « Retours DSN.cmd ». Pas de ligne de commande.

Le mot de passe est tape ici, garde en memoire le temps de l'appel, passe au
sous-processus par son environnement (jamais par la ligne de commande, ou il
serait visible de tout le systeme), puis efface. Il n'est ecrit nulle part :
ni fichier, ni journal, ni variable d'environnement persistante.

DEPUIS LE 11/09/2026, LE CHAMP EST FACULTATIF. Si le mot de passe est dans le
coffre (`python -m moteur coffre poser net-entreprises`), cette fenetre ne
demande plus rien : relever les retours est une LECTURE, et Leandre a demande
qu'elle puisse se faire seule. Le champ reste pour deux cas -- aucun coffre
pose, ou un mot de passe different a essayer. Ce qui est tape ici l'emporte
toujours sur le coffre.
"""
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk, scrolledtext

CODE = Path(__file__).resolve().parent     # logiciel/ : d'ou tourne le moteur
VARIABLE = "NET_ENTREPRISES_MOTDEPASSE"

FOND = "#1e1e24"
FOND_CHAMP = "#2a2a33"
TEXTE = "#e8e8ec"
DISCRET = "#9a9aa8"
ACCENT = "#c9a227"
ALERTE = "#d05353"
SUCCES = "#6aa84f"


class Fenetre(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Retours DSN - Compagnia UEUEUE")
        self.configure(bg=FOND)
        self.minsize(720, 520)
        self.file = queue.Queue()
        self.processus = None
        self._construire()
        self.after(100, self._vider_file)

    # ------------------------------------------------------------- interface
    def _construire(self):
        cadre = tk.Frame(self, bg=FOND, padx=22, pady=18)
        cadre.pack(fill="both", expand=True)

        tk.Label(cadre, text="Retours DSN", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 17, "bold")).pack(anchor="w")
        tk.Label(cadre,
                 text="Recupere ce que net-entreprises a repondu depuis le dernier depot :\n"
                      "accuses, certificat de conformite, bilans, et le compte-rendu DGFiP\n"
                      "qui porte le taux de prelevement a la source.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 9), justify="left").pack(
                     anchor="w", pady=(4, 16))

        # --- mot de passe
        tk.Label(cadre, text="Mot de passe net-entreprises", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 10)).pack(anchor="w")
        self.mdp = tk.Entry(cadre, show="•", bg=FOND_CHAMP, fg=TEXTE,
                            insertbackground=TEXTE, relief="flat",
                            font=("Segoe UI", 12), width=34)
        self.mdp.pack(anchor="w", ipady=6, pady=(4, 2))
        self.mdp.focus_set()
        self.mdp.bind("<Return>", lambda e: self.lancer())
        tk.Label(cadre, text=self._note_coffre(),
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8),
                 justify="left").pack(anchor="w", pady=(0, 14))

        # --- options
        opts = tk.Frame(cadre, bg=FOND)
        opts.pack(anchor="w", fill="x", pady=(0, 6))
        tk.Label(opts, text="Remonter aux", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 10)).pack(side="left")
        self.jours = tk.StringVar(value="30")
        tk.Spinbox(opts, from_=1, to=365, width=5, textvariable=self.jours,
                   bg=FOND_CHAMP, fg=TEXTE, relief="flat", justify="center",
                   buttonbackground=FOND_CHAMP,
                   font=("Segoe UI", 10)).pack(side="left", padx=8)
        tk.Label(opts, text="derniers jours", bg=FOND, fg=TEXTE,
                 font=("Segoe UI", 10)).pack(side="left")

        self.appliquer = tk.BooleanVar(value=False)
        tk.Checkbutton(
            cadre,
            text="Ecrire les taux lus dans la configuration (config/pas.json)",
            variable=self.appliquer, bg=FOND, fg=TEXTE, selectcolor=FOND_CHAMP,
            activebackground=FOND, activeforeground=TEXTE,
            font=("Segoe UI", 9), anchor="w").pack(anchor="w", pady=(8, 0))
        tk.Label(cadre,
                 text="Decoche : les taux sont affiches, rien n'est modifie. A laisser\n"
                      "decoche la premiere fois, pour voir ce qui arrive avant d'ecrire.",
                 bg=FOND, fg=DISCRET, font=("Segoe UI", 8),
                 justify="left").pack(anchor="w", padx=(24, 0), pady=(0, 14))

        # --- boutons
        barre = tk.Frame(cadre, bg=FOND)
        barre.pack(anchor="w", fill="x")
        self.bouton = tk.Button(barre, text="Recuperer les retours",
                                command=self.lancer, bg=ACCENT, fg="#20201a",
                                activebackground="#e0b52c", relief="flat",
                                font=("Segoe UI", 11, "bold"), padx=18, pady=8,
                                cursor="hand2")
        self.bouton.pack(side="left")
        tk.Button(barre, text="Taux connus", command=self.voir_pas,
                  bg=FOND_CHAMP, fg=TEXTE, activebackground="#3a3a45",
                  relief="flat", font=("Segoe UI", 10), padx=14, pady=8,
                  cursor="hand2").pack(side="left", padx=8)

        # --- sortie
        self.sortie = scrolledtext.ScrolledText(
            cadre, bg="#141418", fg=TEXTE, relief="flat", height=14,
            font=("Consolas", 9), insertbackground=TEXTE, wrap="word")
        self.sortie.pack(fill="both", expand=True, pady=(16, 0))
        self.sortie.tag_config("erreur", foreground=ALERTE)
        self.sortie.tag_config("succes", foreground=SUCCES)
        self.sortie.tag_config("discret", foreground=DISCRET)
        self._ecrire("Pret. Le moteur ne depose rien : cette fenetre lit, "
                     "elle n'envoie aucune declaration.\n", "discret")

    # -------------------------------------------------------------- actions
    def lancer(self):
        mdp = self.mdp.get()
        if not mdp:
            self._ecrire("\nSaisir le mot de passe net-entreprises.\n", "erreur")
            return
        args = ["retours", "--depuis", self._depuis()]
        if self.appliquer.get():
            args.append("--appliquer")
        self._executer(args, mdp)
        self.mdp.delete(0, "end")          # efface des que c'est parti
        del mdp

    def voir_pas(self):
        self._executer(["pas"], None)

    def _depuis(self) -> str:
        import datetime as dt
        try:
            n = max(1, int(self.jours.get()))
        except ValueError:
            n = 30
        return (dt.date.today() - dt.timedelta(days=n)).strftime("%d/%m/%Y")

    def _executer(self, args, mdp):
        if self.processus is not None:
            self._ecrire("\nUne commande est deja en cours.\n", "erreur")
            return
        self.sortie.delete("1.0", "end")
        self.bouton.config(state="disabled", text="En cours...")
        env = dict(os.environ)
        if mdp:
            env[VARIABLE] = mdp
        else:
            env.pop(VARIABLE, None)
        threading.Thread(target=self._travail, args=(args, env), daemon=True).start()

    def _travail(self, args, env):
        exe = sys.executable
        if exe.lower().endswith("pythonw.exe"):
            exe = exe[:-len("pythonw.exe")] + "python.exe"
        try:
            self.processus = subprocess.Popen(
                [exe, "-u", "-m", "moteur"] + args,
                cwd=str(CODE), env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, encoding="utf-8", errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            for ligne in self.processus.stdout:
                self.file.put((ligne, None))
            code = self.processus.wait()
        except Exception as exc:                                  # noqa: BLE001
            self.file.put(("\nEchec du lancement : %s\n" % exc, "erreur"))
            code = 1
        finally:
            env.pop(VARIABLE, None)
            self.processus = None
        self.file.put((None, code))

    def _vider_file(self):
        while True:
            try:
                texte, marque = self.file.get_nowait()
            except queue.Empty:
                break
            if texte is None:
                self.bouton.config(state="normal", text="Recuperer les retours")
                if marque == 0:
                    self._ecrire("\nTermine.\n", "succes")
                else:
                    self._ecrire("\nTermine avec un probleme (code %s).\n" % marque,
                                 "erreur")
            else:
                self._ecrire(texte, marque)
        self.after(100, self._vider_file)

    def _ecrire(self, texte, marque=None):
        self.sortie.insert("end", texte, marque or ())
        self.sortie.see("end")


if __name__ == "__main__":
    Fenetre().mainloop()
