# PuppetPaie — ce qu'un agent doit savoir avant de toucher à quoi que ce soit

Lire `README.md` (usage), `docs/ARCHITECTURE.md` (formats et calculs), et —
si les données sont là — `prive/journal/ETAT.md`, qui raconte où en est le
projet avec de vrais chiffres.

## Le fichier qu'on ne lit pas

```
prive/config/coffre.bin      les mots de passe net-entreprises et Urssaf
prive/config/google-jeton.bin  le jeton du compte Google
prive/config/.seance           le billet de séance en cours
```

**Ne jamais lire, afficher, copier ni recopier le contenu de ces fichiers**,
ni chercher à en extraire une valeur — pas plus en les décodant qu'en passant
par `coffre.lire()` pour en imprimer le résultat.

C'est une **convention, pas une garantie technique**, et il faut le dire :
DPAPI chiffre ces fichiers pour le compte Windows courant, donc un agent qui
tourne sous ce compte *peut* les lire. Rien ne l'en empêche mécaniquement. Ce
qui tient la règle, c'est qu'elle est écrite ici, que personne n'a de raison
légitime de la franchir, et qu'aucune commande du moteur n'affiche jamais un
mot de passe — ni en sortie, ni en erreur, ni dans un journal.

Ce qu'on peut faire à la place, et qui suffit toujours :

```bash
python -m moteur coffre     # ce qui est posé, depuis quand, pour quel usage
```

## Ce qu'un agent peut faire, et à quelle condition

| | condition |
|---|---|
| lire, calculer, produire un mois, sauvegarder, relever les retours | aucune |
| **déposer une DSN ou une DPAE** | **séance ouverte** |

La séance s'ouvre quand un humain tape le mot de passe **du logiciel** — à
l'ouverture de l'interface, ou par `python -m moteur seance --ouvrir`. Elle
**n'a pas de durée** : elle vaut tant que la fenêtre qui l'a ouverte est là,
et se referme avec elle. Un agent ne peut pas l'ouvrir : `getpass` échoue sans
terminal, et c'est voulu.

Si un dépôt est demandé et que la séance est fermée, la commande refuse et dit
quoi faire. **Ne pas contourner** : ni en posant la variable d'environnement à
la place de l'utilisateur, ni en fabriquant un billet de séance. Le dépôt
engage l'employeur — jusqu'à des ordres de télépaiement réellement prélevés.

## Les règles de fond du logiciel

1. **Rien ne se devine.** Un montant de bordereau, un taux de PAS, un
   identifiant DGFiP se *lisent* (du bordereau, du compte-rendu métier). Le
   moteur refuse de produire plutôt que d'inventer. Ne pas « déboguer » un
   refus en fournissant une valeur plausible.
2. **Toute décision vit dans `operations`.** Les deux faces — ligne de
   commande et interface — ne font qu'afficher. `operations.py` est une
   façade : le code vit dans neuf modules par domaine (`operations_socle`,
   `_paies`, `_declarations`, `_retours`, `_documents`, `_ouverture`,
   `_fiches`, `_catalogues`, `_importation`), et une opération neuve s'écrit dans le sien
   puis s'ajoute à la façade. Un garde-fou ajouté dans un front est un
   garde-fou qu'on contourne par l'autre.
3. **Les modules de transport ne cherchent jamais un secret.** `dsn_api.py`,
   `dpae_api.py` et `netentreprises.py` reçoivent un mot de passe ; ils
   n'ouvrent pas le coffre. `tests/test_ouverture.py` échoue si l'un d'eux s'y
   met.
4. **Ne jamais régénérer une déclaration déjà déposée** pour la redéposer :
   les numéros de contrat se renumérotent dès que les compteurs avancent, et
   un annule-et-remplace aux numéros changés ne remplace plus rien de
   reconnaissable.
5. **Deux canaux de retours, pas un.** La DSN répond sur net-entreprises, la
   DPAE sur `consultation.dpae-edi.urssaf.fr` — services distincts, natures
   distinctes (41 = certificat de conformité des DPAE), mots de passe
   distincts, archives distinctes (`retours/` et `retours/dpae/`). Chercher
   une DPAE dans les retours DSN ne rend rien, et « je n'ai rien trouvé » n'y
   veut jamais dire « il n'y a rien ». Deux pièges qui vont avec : un **404
   sur une plage de consultation veut dire « rien sur cette plage »**, pas
   « ce service n'existe pas » ; et un **accusé de transport `OK` n'est pas
   une déclaration acceptée** — c'est le bilan (CCO/BAN) qui tranche.
6. **Aucune donnée réelle dans le code.** Pas de NIR, pas de salaire, pas
   d'adresse dans un commentaire, un test ou un message — `logiciel/` est
   destiné à un dépôt public. Voir `AVANT-LE-PREMIER-COMMIT.md`.

## Vérifier qu'on n'a rien cassé

```bash
python tests/test_non_regression.py
python tests/test_ouverture.py
python -m moteur calibrer          # rejoue l'historique CoolPaie
python -m moteur version --controle   # tout le code s'importe
```

## Publier une version

Ce poste est celui de l'éditeur (`prive/config/maj.json`, `"editeur": true`) :
il relit les sources (`python -m moteur sources --verifier`, et l'ouverture
le fait chaque semaine) et **publie** ; il ne reçoit pas de mise à jour. Une
compagnie, elle, reçoit : son ouverture télécharge la version dans l'ombre,
le lanceur bascule au démarrage suivant (`moteur/maj.py`).

1. Augmenter `VERSION` (une date : `2026.10.02`).
2. Suite verte, `verifier_avant_commit` publiable.
3. `python -m moteur maj --publier --notes "..."`, et `--calcul "..."` **seulement**
   si la version change un calcul de paie — c'est la seule phrase qu'une
   compagnie verra, une fois. Un taux qui change n'en est pas une.

Ne jamais appliquer une mise à jour pendant que l'interface tourne (la
commande refuse) ; ne pas republier un numéro (refusé aussi).
