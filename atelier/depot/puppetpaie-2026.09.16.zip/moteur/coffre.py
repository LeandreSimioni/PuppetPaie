"""Le coffre : les mots de passe des organismes, chiffres par le compte Windows.

    python -m moteur coffre                  ce qui est pose, jamais les valeurs
    python -m moteur coffre poser net-entreprises
    python -m moteur coffre oublier urssaf

CE QUI A CHANGE, ET QUI L'A DECIDE
-----------------------------------
Jusqu'au 11/09/2026, `netentreprises.py` et `dpae_api.py` disaient en toutes
lettres : le guide impose de chiffrer le mot de passe s'il est stocke, ICI IL
N'EST PAS STOCKE DU TOUT. Il etait lu dans une variable d'environnement,
utilise le temps d'une requete, et jamais ecrit.

Le logiciel doit pouvoir travailler seul --
relever les retours a l'ouverture et pendant la journee, sauvegarder le dossier
prive -- ce qu'aucune saisie manuelle ne permet. On renonce donc a cette
garantie-la. Ce fichier existe pour la remplacer par une autre, ecrite :

1. **Chiffre au repos par DPAPI.** Windows lie le contenu au compte
   utilisateur courant. Copie sur une autre machine, ou lu par un autre compte
   de celle-ci, le fichier est illisible. C'est le meme mecanisme que le jeton
   Google (`google.py`), qui vit a cote.
2. **Jamais affiche, jamais journalise.** Aucune commande du moteur n'imprime
   un mot de passe, ni en sortie, ni en erreur, ni dans un journal. `etat()`
   rend ce qui est pose et depuis quand -- jamais la valeur. Un test le tient.
3. **Jamais dans le depot public.** Le fichier vit dans les DONNEES
   (`prive/config/`), pas dans `logiciel/`.
4. **Hors de portee du LLM -- par convention, et il faut le savoir.** Le
   fichier est nomme et declare interdit dans `CLAUDE.md`, `AGENTS.md` et
   `claude/LISEZ-MOI-DABORD.md`. Ce n'est PAS une garantie technique : un
   agent qui tourne sous le meme compte Windows peut lire ce que
   l'utilisateur peut lire, et DPAPI n'y change rien. La convention tient
   parce qu'elle est ecrite et qu'aucune commande ne la contredit.
5. **Deux secrets, pas un.** Le compte net-entreprises (DSN) et le compte
   Urssaf (DPAE) sont distincts. Le coffre les tient separement.

LECTURE ET DEPOT : DEUX USAGES, ET LE SECOND SE CONFIRME
---------------------------------------------------------
`lire()` exige de dire POUR QUOI on lit.

    usage=CONSULTATION   relever les retours, lister les depots. Automatisable,
                         c'est le but du coffre.
    usage=DEPOT          transmettre une declaration. Exige en plus `confirme`,
                         qui porte la confirmation obtenue de l'humain -- le
                         mois recopie en ligne de commande, le « VOUS ETES
                         SUR ? » de la fenetre.

La regle d'origine (§17.11 d'ETAT.md) reservait le secret stocke a la
consultation seule. Elle a ete levee : le mot de passe retape
prouvait qu'on CONNAISSAIT le mot de passe ; la confirmation prouve seulement
qu'un humain etait la. Sur une machine a un seul compte, DPAPI liant deja le
coffre a ce compte, l'ecart est mince -- et les trois gestes du depot
subsistent : cocher « pour de vrai », recopier le mois, confirmer.

LE MOT DE PASSE DU LOGICIEL, ET LA SEANCE
------------------------------------------
L'idee retenue, et elle vaut mieux que la precedente : plutot
que de retaper le mot de passe d'un ORGANISME a chaque geste, on tape UNE fois,
a l'ouverture, le mot de passe DU LOGICIEL. Cela ouvre une **seance**, et c'est
la seance qui autorise ensuite un depot.

    python -m moteur coffre ouverture        poser (ou changer) ce mot de passe
    python -m moteur interface               le demande, puis ouvre la seance
    python -m moteur seance                  ouverte ou fermee
    python -m moteur seance --fermer         refermer tout de suite

Ce que ca deplace, exactement :

  - la PREUVE reste (il faut connaitre un mot de passe), mais elle est donnee
    une fois par seance au lieu d'une fois par geste ;
  - la seance dure TANT QUE LA FENETRE EST OUVERTE, et pas une minute de plus.
    Elle n'a pas de duree. La demande : << tant que la
    fenetre est ouverte on laisse le jeton, pas de limite de temps ; la seance
    dure tant que la fenetre a ete ouverte et pas refermee >>. Ce qui la ferme
    est la fermeture du lanceur, qui efface le billet -- et, si le logiciel
    est mort sans pouvoir l'effacer, la disparition du processus qui l'avait
    ouvert : le billet porte son numero, et un billet dont le proprietaire
    n'existe plus ne vaut rien. Un compte a rebours n'apportait rien qu'une
    interruption au milieu d'un depot ;
  - la CONSULTATION ne la demande jamais. Relever les retours et sauvegarder
    le prive doivent marcher sans personne -- c'est tout l'objet du coffre ;
  - le depot, lui, exige la seance ouverte ET les trois gestes. Une seance
    ouverte n'a jamais depose quoi que ce soit toute seule.

Le mot de passe du logiciel n'est PAS stocke : seul son condense PBKDF2 l'est,
avec son sel. On ne peut donc pas le retrouver depuis le coffre -- meme en
dechiffrant le fichier. Il ne sert qu'a repondre oui ou non.

Le billet de seance vit dans `config/.seance`, chiffre par DPAPI lui aussi :
un autre compte Windows ne peut pas en fabriquer un.

CE QUI RESTE INTERDIT, ET QU'UN TEST VERIFIE
---------------------------------------------
Les modules de TRANSPORT -- `dsn_api.py`, `dpae_api.py`, `netentreprises.py` --
ne connaissent pas ce fichier et ne l'importent pas. Ils recoivent un mot de
passe, ils ne vont jamais le chercher. La decision de puiser dans le coffre
appartient a la couche qui a vu l'humain : `commandes_dsn.py`,
`commandes_dpae.py`, les fenetres. `tests/test_ouverture.py` echoue si un
module de transport mentionne ce module.
"""
from __future__ import annotations

import datetime as _dt
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path

FICHIER = "coffre.bin"

NET_ENTREPRISES = "net-entreprises"
URSSAF = "urssaf"

CONSULTATION = "consultation"
DEPOT = "depot"

# Chaque service : son libelle, la variable d'environnement qui le court-circuite,
# et ce a quoi il sert. La variable garde la priorite -- une fenetre qui fait
# taper le mot de passe doit passer devant le coffre sans avoir a le vider.
SERVICES = {
    NET_ENTREPRISES: {
        "libelle": "net-entreprises (DSN)",
        "variable": "NET_ENTREPRISES_MOTDEPASSE",
        "sert_a": "relever les retours, lister les depots, deposer une DSN",
    },
    URSSAF: {
        "libelle": "Urssaf (DPAE)",
        "variable": "URSSAF_MOTDEPASSE",
        "sert_a": "verifier les identifiants et deposer une DPAE",
    },
}

DESCRIPTION_DPAPI = "PuppetPaie - mots de passe des organismes"


class ErreurCoffre(Exception):
    """Le coffre refuse. Le message est ecrit pour etre lu."""


@dataclass
class Secret:
    """Ce qu'on peut dire d'un secret sans le dire."""
    service: str
    libelle: str
    sert_a: str
    pose: bool
    pose_le: str = ""
    variable: str = ""
    dans_environnement: bool = False


# --------------------------------------------------------------------- DPAPI
def _dpapi(donnees: bytes, sens: str, description: str) -> bytes:
    """Chiffre (sens='proteger') ou dechiffre, lie au compte Windows courant.

    Seul endroit du logiciel qui appelle DPAPI : `google.py` passe par ici
    pour son jeton. Deux implementations, c'est une de trop le jour ou l'une
    se trompe de drapeau.
    """
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD),
                    ("pbData", ctypes.POINTER(ctypes.c_char))]

    crypt = ctypes.windll.crypt32
    fonction = (crypt.CryptProtectData if sens == "proteger"
                else crypt.CryptUnprotectData)
    tampon = ctypes.create_string_buffer(donnees, len(donnees))
    entree = BLOB(len(donnees),
                  ctypes.cast(tampon, ctypes.POINTER(ctypes.c_char)))
    sortie = BLOB()
    ok = fonction(ctypes.byref(entree),
                  ctypes.c_wchar_p(description) if sens == "proteger" else None,
                  None, None, None, 0, ctypes.byref(sortie))
    if not ok:
        raise ErreurCoffre(
            "DPAPI a refuse de %s (erreur %d). Un fichier chiffre pour un "
            "autre compte Windows, ou copie depuis une autre machine, est "
            "illisible ici : il faut reposer le secret."
            % ("chiffrer" if sens == "proteger" else "dechiffrer",
               ctypes.GetLastError()))
    try:
        return ctypes.string_at(sortie.pbData, sortie.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(sortie.pbData)


def proteger(donnees: bytes, description: str = DESCRIPTION_DPAPI) -> bytes:
    return _dpapi(donnees, "proteger", description)


def deproteger(donnees: bytes, description: str = DESCRIPTION_DPAPI) -> bytes:
    return _dpapi(donnees, "deproteger", description)


def dpapi_disponible() -> bool:
    return sys.platform == "win32"


# --------------------------------------------------------------- le fichier
def chemin(ctx) -> Path:
    return Path(ctx.racine) / "config" / FICHIER


def _charger(ctx) -> dict:
    p = chemin(ctx)
    if not p.exists():
        return {}
    brut = p.read_bytes()
    if dpapi_disponible():
        brut = deproteger(brut)
    try:
        contenu = json.loads(brut.decode("utf-8"))
    except ValueError:
        raise ErreurCoffre(
            "Le coffre (%s) est illisible. Le supprimer et reposer les "
            "secrets : `python -m moteur coffre poser net-entreprises`." % p)
    return contenu.get("secrets", {})


def _ecrire(ctx, secrets: dict) -> Path:
    p = chemin(ctx)
    p.parent.mkdir(parents=True, exist_ok=True)
    brut = json.dumps({"version": 1, "secrets": secrets}).encode("utf-8")
    if dpapi_disponible():
        p.write_bytes(proteger(brut))
    else:
        # Hors Windows, pas d'equivalent portable en bibliotheque standard. On
        # ecrit en clair, mais on le DIT : un secret en clair qu'on croit
        # chiffre est pire qu'un secret en clair assume.
        p.write_bytes(brut)
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
    return p


# ------------------------------------------------------------------ l'usage
def _service(service: str) -> dict:
    if service not in SERVICES:
        raise ErreurCoffre(
            "Service inconnu : %r. Connus : %s."
            % (service, ", ".join(sorted(SERVICES))))
    return SERVICES[service]


LONGUEUR_MINIMALE = 6


def poser(ctx, service: str, motdepasse: str) -> Path:
    """Range un mot de passe. Rend le chemin du coffre, jamais la valeur.

    LE GARDE-FOU DE LONGUEUR N'EST PAS UNE REGLE DE ROBUSTESSE. Le 11/09/2026,
    la saisie masquee du terminal n'a capture qu'UN CARACTERE des deux mots de
    passe poses par l'utilisateur. Rien ne l'a dit : le coffre les a ranges sans
    broncher, et la panne est apparue plus tard, sous la forme d'un « HTTP 422
    parametres invalides » qui ne designait rien. Un secret trop court est
    beaucoup plus surement une saisie perdue qu'un vrai mot de passe -- et il
    vaut mieux refuser tout de suite que laisser une authentification echouer
    a un moment ou l'on croira le compte en cause.
    """
    fiche = _service(service)
    if not (motdepasse or "").strip():
        raise ErreurCoffre("Mot de passe vide : rien n'a ete pose.")
    if len(motdepasse) < LONGUEUR_MINIMALE:
        raise ErreurCoffre(
            "Mot de passe de %d caractere(s) : c'est trop court pour un compte "
            "d'organisme, et c'est presque toujours le signe que la saisie "
            "masquee n'a pas tout capture. Rien n'a ete pose.\n"
            "Reessayer dans une fenetre, qui ne depend pas du terminal :\n"
            "  python -m moteur coffre poser %s --fenetre"
            % (len(motdepasse), service))
    secrets = _charger(ctx)
    secrets[service] = {
        "motdepasse": motdepasse,
        "pose_le": _dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "libelle": fiche["libelle"],
    }
    return _ecrire(ctx, secrets)


def oublier(ctx, service: str) -> bool:
    _service(service)
    secrets = _charger(ctx)
    if service not in secrets:
        return False
    del secrets[service]
    if secrets:
        _ecrire(ctx, secrets)
    else:
        chemin(ctx).unlink(missing_ok=True)
    return True


def pose(ctx, service: str) -> bool:
    """Y a-t-il un secret pour ce service ? Ne le lit pas."""
    try:
        return bool(_charger(ctx).get(service, {}).get("motdepasse"))
    except ErreurCoffre:
        return False


def etat(ctx) -> list:
    """Ce qui est pose, pour quel usage, depuis quand. JAMAIS les valeurs.

    Rendue par la ligne de commande ET par l'interface. Aucune des deux ne
    peut afficher un mot de passe : il n'y en a pas dans ce qui sort d'ici.
    """
    try:
        secrets = _charger(ctx)
    except ErreurCoffre:
        secrets = {}
    fiches = []
    for nom, fiche in SERVICES.items():
        enregistre = secrets.get(nom) or {}
        fiches.append(Secret(
            service=nom,
            libelle=fiche["libelle"],
            sert_a=fiche["sert_a"],
            pose=bool(enregistre.get("motdepasse")),
            pose_le=enregistre.get("pose_le", ""),
            variable=fiche["variable"],
            dans_environnement=bool(os.environ.get(fiche["variable"]))))
    return fiches


def lire(ctx, service: str, *, usage: str, confirme=None):
    """Le mot de passe du service, ou None. DIRE POUR QUOI EST OBLIGATOIRE.

    L'environnement l'emporte sur le coffre : une fenetre qui fait taper le
    mot de passe doit passer devant, sans quoi on ne saurait plus lequel des
    deux a servi.
    """
    fiche = _service(service)
    if usage not in (CONSULTATION, DEPOT):
        raise ErreurCoffre(
            "usage doit valoir %r ou %r (recu %r). Lire un secret sans dire "
            "pourquoi n'est pas permis." % (CONSULTATION, DEPOT, usage))
    if usage == DEPOT and not confirme:
        raise ErreurCoffre(
            "Un depot ne puise dans le coffre qu'apres confirmation d'un "
            "humain. `confirme` doit porter ce qui a ete confirme -- le mois "
            "recopie, ou la reponse de la fenetre. Voir le docstring de "
            "moteur/coffre.py.")
    depuis_env = os.environ.get(fiche["variable"])
    if depuis_env:
        return depuis_env
    return (_charger(ctx).get(service) or {}).get("motdepasse") or None


def disponible(ctx, service: str) -> bool:
    """Peut-on travailler sans rien demander ? Environnement ou coffre."""
    return bool(os.environ.get(_service(service)["variable"])) or pose(ctx, service)


# ====================================================================== seance
#
# Le mot de passe DU LOGICIEL, tape une fois a l'ouverture, et le billet qu'il
# delivre. Voir le docstring en tete de fichier : c'est ce billet qui autorise
# un depot, jamais le coffre a lui seul.

FICHIER_SEANCE = ".seance"
ITERATIONS = 200_000            # PBKDF2-HMAC-SHA256


@dataclass
class Seance:
    """Ouverte ou fermee, et depuis quand. Pas de compte a rebours.

    `minutes_restantes` a disparu le 12/09/2026 avec la duree elle-meme : une
    seance qui ne se referme pas toute seule n'a pas de reste a annoncer, et
    l'annoncer quand meme (a zero, ou a l'infini) aurait fait lire un chiffre
    la ou il n'y a plus de decompte.
    """
    ouverte: bool
    ouverte_le: str = ""
    exigee: bool = True         # un mot de passe du logiciel est-il pose
    proprietaire: int = 0       # le processus qui l'a ouverte, 0 si inconnu


def _condenser(motdepasse: str, sel: bytes) -> str:
    import hashlib
    return hashlib.pbkdf2_hmac(
        "sha256", motdepasse.encode("utf-8"), sel, ITERATIONS).hex()


def poser_ouverture(ctx, motdepasse: str) -> Path:
    """Pose (ou change) le mot de passe du logiciel. Seul son condense est ecrit."""
    import secrets as _alea
    if len((motdepasse or "").strip()) < 4:
        raise ErreurCoffre(
            "Mot de passe du logiciel trop court : quatre caracteres au moins. "
            "Rien n'a ete pose.")
    sel = _alea.token_bytes(16)
    secrets = _charger(ctx)
    secrets["_logiciel"] = {
        "sel": sel.hex(),
        "condense": _condenser(motdepasse, sel),
        "iterations": ITERATIONS,
        "pose_le": _dt.datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    return _ecrire(ctx, secrets)


def ouverture_exigee(ctx) -> bool:
    """Un mot de passe du logiciel a-t-il ete pose ?

    Non par defaut : le logiciel ne s'invente pas un verrou que personne n'a
    demande. Tant qu'il n'y en a pas, la seance est tenue pour ouverte et le
    depot s'en remet a ses trois gestes.
    """
    try:
        return bool((_charger(ctx).get("_logiciel") or {}).get("condense"))
    except ErreurCoffre:
        return False


def oublier_ouverture(ctx) -> bool:
    secrets = _charger(ctx)
    if "_logiciel" not in secrets:
        return False
    del secrets["_logiciel"]
    if secrets:
        _ecrire(ctx, secrets)
    else:
        chemin(ctx).unlink(missing_ok=True)
    fermer_seance(ctx)
    return True


def verifier_ouverture(ctx, motdepasse: str) -> bool:
    """Le mot de passe du logiciel est-il le bon ? Comparaison a temps constant."""
    import hmac
    fiche = _charger(ctx).get("_logiciel") or {}
    if not fiche.get("condense"):
        return True                      # aucun verrou pose : rien a prouver
    attendu = fiche["condense"]
    donne = _condenser(motdepasse or "", bytes.fromhex(fiche["sel"]))
    return hmac.compare_digest(attendu, donne)


def _chemin_seance(ctx) -> Path:
    return Path(ctx.racine) / "config" / FICHIER_SEANCE


def _vivant(pid: int) -> bool:
    """Ce processus tourne-t-il encore ?

    Dans le doute, OUI. Se tromper ici en disant << mort >> refermerait une
    seance parfaitement valide au milieu d'un depot ; se tromper en disant
    << vivant >> laisse au plus un billet inutile jusqu'a la prochaine
    ouverture, qui le remplace. Le doute doit donc pencher du cote qui ne
    casse rien.
    """
    if not pid:
        return True                      # billet d'avant les proprietaires
    if os.name == "nt":
        try:
            import ctypes
            k32 = ctypes.windll.kernel32
            # PROCESS_QUERY_LIMITED_INFORMATION : le droit minimal, et il
            # suffit a lire un code de sortie.
            h = k32.OpenProcess(0x1000, False, int(pid))
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k32.GetExitCodeProcess(h, ctypes.byref(code))
            k32.CloseHandle(h)
            return (not ok) or code.value == 259       # STILL_ACTIVE
        except Exception:                              # noqa: BLE001
            return True
    try:
        os.kill(int(pid), 0)
        return True
    except ProcessLookupError:
        return False
    except Exception:                                  # noqa: BLE001
        return True


def ouvrir_seance(ctx, motdepasse: str = "", proprietaire: int = 0) -> Seance:
    """Verifie le mot de passe du logiciel et delivre un billet SANS echeance.

    Sans verrou pose, le billet est delivre sans rien demander : le logiciel
    marche comme avant pour qui n'a pas voulu de mot de passe.

    `proprietaire` est le numero du processus qui tient la fenetre -- le
    lanceur. La seance vaut tant qu'il vit : c'est lui qui la referme en se
    fermant, et s'il meurt sans pouvoir le faire, le billet cesse de valoir.
    A zero (la ligne de commande, qui n'a pas de fenetre a garder), la seance
    vaut jusqu'a `seance --fermer`.
    """
    if not verifier_ouverture(ctx, motdepasse):
        raise ErreurCoffre("Mot de passe du logiciel refuse.")
    billet = json.dumps({
        "ouverte_le": _dt.datetime.now().isoformat(timespec="seconds"),
        "proprietaire": int(proprietaire or 0),
    }).encode("utf-8")
    p = _chemin_seance(ctx)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(proteger(billet, "PuppetPaie - seance") if dpapi_disponible()
                  else billet)
    return seance(ctx)


def fermer_seance(ctx) -> bool:
    p = _chemin_seance(ctx)
    existait = p.exists()
    p.unlink(missing_ok=True)
    return existait


def seance(ctx) -> Seance:
    """Ou en est la seance. Ne delivre rien, ne demande rien."""
    exigee = ouverture_exigee(ctx)
    if not exigee:
        # Pas de verrou pose : la seance est toujours ouverte, et on le dit
        # plutot que de faire croire a une protection qui n'existe pas.
        return Seance(ouverte=True, exigee=False)
    p = _chemin_seance(ctx)
    if not p.exists():
        return Seance(ouverte=False, exigee=True)
    try:
        brut = p.read_bytes()
        if dpapi_disponible():
            brut = deproteger(brut, "PuppetPaie - seance")
        billet = json.loads(brut.decode("utf-8"))
    except (ErreurCoffre, ValueError, OSError):
        p.unlink(missing_ok=True)
        return Seance(ouverte=False, exigee=True)
    # Un billet d'avant le 12/09/2026 portait une echeance et pas de
    # proprietaire. On ne le rejette pas -- il a ete delivre contre un mot de
    # passe -- mais on ne fait pas semblant de savoir qui le tient.
    pid = int(billet.get("proprietaire") or 0)
    if not _vivant(pid):
        # La fenetre qui l'avait ouverte n'existe plus : le billet non plus.
        p.unlink(missing_ok=True)
        return Seance(ouverte=False, exigee=True)
    return Seance(ouverte=True, ouverte_le=billet.get("ouverte_le", ""),
                  exigee=True, proprietaire=pid)


def autorise_depot(ctx) -> tuple:
    """Peut-on deposer sans retaper un mot de passe d'organisme ? (oui/non, pourquoi)

    Trois cas, et un seul refuse :

      - la seance est ouverte (mot de passe du logiciel donne, ou aucun pose)
        ET le coffre porte le secret de l'organisme -> oui ;
      - le mot de passe de l'organisme est dans l'environnement -> oui, c'est
        le chemin d'avant, il reste ;
      - seance fermee -> non. Il faut ouvrir le logiciel.
    """
    s = seance(ctx)
    if not s.ouverte:
        return False, ("La seance est fermee. Ouvrir le logiciel "
                       "(`python -m moteur seance --ouvrir`) ou taper le mot "
                       "de passe de l'organisme.")
    return True, ""

