"""Les minima conventionnels, confrontes a une paie : des avertissements.

NON BLOQUANT, et c'est voulu. Un minimum conventionnel depend de choses que
la paie ne dit pas toujours -- la jauge de la salle, le role, le nombre de
representations sur un trimestre, l'annexe de la convention ou l'entreprise
se range. Le moteur prend donc, a chaque fois qu'il ne sait pas, l'hypothese
qui donne le minimum LE PLUS BAS : un avertissement qui crie a tort finit
decroche, celui-ci ne doit parler que quand il est sur. Et il dit toujours
quelle ligne de quelle grille il a lue, pour qu'on puisse verifier.

Les nombres viennent de `minima-conventionnels.json`, les cles de grille de
`emplois-base.json` (champ `minima`). Un metier sans cle : silence.
"""
from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path
from typing import Optional

from . import emplois

FICHIER = Path(__file__).parent / "minima-conventionnels.json"
_cache: dict = {}

# Les rubriques que l'on sait comparer, et a quoi.
CACHET = ("cachet",)
REPETITION = ("repetition",)
HORAIRES = ("heure", "journee", "semaine")


def table() -> dict:
    if "t" not in _cache:
        _cache["t"] = json.loads(FICHIER.read_text(encoding="utf-8"))
    return _cache["t"]


def _palier(paliers: list, nombre: int) -> Optional[float]:
    """Le montant du palier ou tombe `nombre` de representations."""
    for p in paliers:
        if p["jusqu_a"] is None or nombre <= p["jusqu_a"]:
            return p["montant"]
    return None


def _euros(x) -> str:
    return ("%.2f" % float(x)).replace(".", ",")


def _annexes_candidates(t3090: dict, m: dict, annexe_entreprise) -> list:
    """Les annexes de la 3090 ou ce metier a une ligne, restreintes a celle de
    l'entreprise quand elle est connue."""
    refs = (m.get("minima") or {}).get("3090") or {}
    if annexe_entreprise and str(annexe_entreprise) in refs:
        return [str(annexe_entreprise)]
    if annexe_entreprise and str(annexe_entreprise) in t3090["annexes"]:
        # L'entreprise dit son annexe, le metier n'y a pas de ligne : on ne
        # va pas chercher un minimum dans une annexe qui n'est pas la sienne.
        return []
    return list(refs)


def _plancher_cachet_3090(t: dict, m: dict, nb: int, annexe_entreprise) -> Optional[tuple]:
    """(montant, explication) du plancher le plus bas parmi les annexes candidates."""
    t3090 = t["3090"]
    refs = (m.get("minima") or {}).get("3090") or {}
    meilleurs = []
    for annexe in _annexes_candidates(t3090, m, annexe_entreprise):
        grille = t3090["annexes"][annexe]["cachets"][refs[annexe]]
        montant = _palier(grille["paliers"], nb)
        if montant is None:
            continue
        # Un palier trimestriel lu sur le seul mois : la colonne atteinte dans
        # le mois est la plus haute que le trimestre puisse donner, donc le
        # minimum lu est le plus bas possible. Jamais a tort, parfois muet.
        meilleurs.append((montant, annexe, grille))
    if not meilleurs:
        return None
    montant, annexe, grille = min(meilleurs, key=lambda x: x[0])
    quoi = "CCN 3090, annexe %s, %s" % (annexe, grille["libelle"])
    if grille.get("jauge"):
        quoi += " (plus petite jauge retenue)"
    if not annexe_entreprise and len(meilleurs) > 1:
        quoi += " -- la plus basse des annexes %s, l'entreprise ne disant pas la sienne" % \
                " et ".join(sorted(a for _, a, _ in meilleurs))
    return montant, quoi


def _plancher_cachet_1285(t: dict, m: dict, nb: int) -> Optional[tuple]:
    ref = (m.get("minima") or {}).get("1285")
    if not ref:
        return None
    grille = t["1285"]["cachets"][ref]
    montant = _palier(grille["paliers"], nb)
    if montant is None:
        return None
    return montant, "CCNEAC (1285), %s" % grille["libelle"]


def _plancher_repetition(t: dict, idcc: str, m: dict, annexe_entreprise) -> Optional[tuple]:
    if idcc == "1285":
        r = t["1285"]["repetition"]
        return r["service"], "CCNEAC (1285), %s" % r["service_libelle"]
    if idcc == "3090":
        t3090 = t["3090"]
        candidats = []
        for annexe in _annexes_candidates(t3090, m, annexe_entreprise) or (
                [str(annexe_entreprise)] if str(annexe_entreprise) in t3090["annexes"] else []):
            r = t3090["annexes"][annexe].get("repetition") or {}
            if "cachet" in r:
                candidats.append((r["cachet"], annexe, r["cachet_libelle"]))
        if not candidats:
            return None
        montant, annexe, lib = min(candidats, key=lambda x: x[0])
        return montant, "CCN 3090, annexe %s, %s" % (annexe, lib)
    return None


def _plancher_horaire(t: dict, idcc: str, m: dict, annexe_entreprise) -> Optional[tuple]:
    """Le taux horaire minimum d'un technicien, par son niveau 3090."""
    if idcc != "3090":
        return None
    classement = m.get("classification_3090") or {}
    niveau = classement.get("niveau")
    if not niveau:
        return None
    t3090 = t["3090"]
    if classement.get("grille") == "administratif":
        # Les emplois administratifs (charge de production, attache de
        # production, administrateur...) n'ont pas de taux horaire dans la
        # 3090 : leur grille est MENSUELLE, pour un temps plein. Ramenee a
        # l'heure sur 151,67 h (35 h x 52 / 12), echelon 1 -- le plus bas.
        # C'est plus juste que la grille des techniciens en tournee, qui
        # vise les regisseurs et les chefs d'equipe, et plus bas : l'avertissement
        # ne crie pas a tort.
        grille = t3090["clauses_communes"]["administratifs_mensuel_echelon_1"]
        if niveau not in grille:
            return None
        horaire = round(grille[niveau] / 151.67, 2)
        return horaire, ("CCN 3090, grille administrative, %s, echelon 1 : %s EUR par "
                         "mois ramenes a l'heure sur 151,67 h"
                         % (niveau.replace("_", " "), _euros(grille[niveau])))
    if annexe_entreprise and str(annexe_entreprise) in t3090["annexes"]:
        grille = t3090["annexes"][str(annexe_entreprise)]["techniciens"]
        ou = "annexe %s" % annexe_entreprise
    else:
        grille = t3090["clauses_communes"]["techniciens"]
        ou = "clauses communes"
    if niveau not in grille:
        return None
    return grille[niveau], "CCN 3090, %s, taux horaire %s" % (ou, niveau.replace("_", " "))


def avertissements(ctx, paie) -> list:
    """Les lignes de cette paie payees sous un minimum conventionnel.

    Une phrase par ligne fautive, qui dit le montant paye, le minimum, et la
    grille lue. Rien si l'entreprise n'a pas d'IDCC connu de la table, si le
    metier n'a pas de ligne de minima, ou si tout est au-dessus.
    """
    ent = ctx.entreprise
    idcc = str(ent.get("idcc") or "")
    t = table()
    if idcc not in t:
        return []
    sal = paie.salarie
    m = emplois.metier(sal.get("code_emploi_ft") or "")
    if m is None:
        return []
    annexe_entreprise = ent.get("annexe_convention") or None
    qui = "%s %s" % (sal.get("nom", ""), sal.get("prenom_affichage") or sal.get("prenom", ""))
    lignes = list(paie.remuneration)
    nb_cachets = int(sum((l.quantite for l in lignes if l.code in CACHET), Decimal(0)))
    avis = []
    for l in lignes:
        plancher = None
        if l.code in CACHET and m["statut"] == "artiste":
            plancher = (_plancher_cachet_3090(t, m, nb_cachets, annexe_entreprise)
                        if idcc == "3090" else _plancher_cachet_1285(t, m, nb_cachets))
            paye, unite = Decimal(l.taux), "le cachet"
        elif l.code in REPETITION and m["statut"] == "artiste":
            plancher = _plancher_repetition(t, idcc, m, annexe_entreprise)
            paye, unite = Decimal(l.taux), "la répétition"
        elif l.code in HORAIRES and m["statut"] == "technicien":
            plancher = _plancher_horaire(t, idcc, m, annexe_entreprise)
            if not l.heures_annexes:
                continue
            paye, unite = (Decimal(l.montant) / Decimal(l.heures_annexes)).quantize(Decimal("0.01")), "l'heure"
        if not plancher:
            continue
        minimum, quoi = plancher
        if paye < Decimal(str(minimum)):
            avis.append(
                "%s, %s : %s € %s, sous le minimum conventionnel de %s € "
                "(%s ; %s). Non bloquant -- vérifier le contrat."
                % (qui, l.designation, _euros(paye), unite, _euros(minimum), quoi,
                   _texte_source(t, idcc)))
    return avis


def _texte_source(t: dict, idcc: str) -> str:
    """« avenant du 21/07/2025 » : la reference courte, le reste est dans la table."""
    return t[idcc]["texte"].split(",")[0]
