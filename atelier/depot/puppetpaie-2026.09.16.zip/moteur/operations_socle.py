"""Ce que tous les domaines d'`operations` partagent : l'erreur, le verrou,
la preuve, le filet.

Quatre mecanismes, et aucun n'appartient a un domaine en particulier :

- **l'erreur** (`ErreurOperation`) : une operation qui refuse d'aller plus
  loin. Les deux faces l'attrapent ; chaque domaine en derive les siennes.
- **le verrou** (`verrou_compteurs`) : deux fronts ouverts en meme temps ne
  doivent pas attribuer le meme numero de bulletin.
- **la preuve** (`Preuve`, `_verifier_preuve`, `seance`) : ce qui prouve
  qu'un humain veut CET acte sortant, MAINTENANT -- un depot, un envoi.
- **le filet** (`_sauver_avant`) : la copie horodatee d'un fichier de
  configuration ou de saisie avant de le remplacer.

Rien ici n'imprime, n'ouvre de navigateur, ni ne connait un front.
"""
from __future__ import annotations

import contextlib
import datetime as _dt
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .contexte import Contexte


# ------------------------------------------------------------------- erreurs
class ErreurOperation(Exception):
    """Une operation refuse d'aller plus loin. Les deux fronts l'attrapent."""


class CompteursVerrouilles(ErreurOperation):
    """Une autre production est en cours -- ou s'est interrompue sans rendre.

    C'est la protection qui rend les deux faces sures : l'interface ouverte
    pendant qu'une commande tourne ne peut plus attribuer les memes numeros.
    """

    def __init__(self, verrou, detenteur, age):
        self.verrou, self.detenteur, self.age = Path(verrou), detenteur, age
        super().__init__(
            "Une autre production tient les compteurs depuis %d s (%s).\n"
            "Attendre qu'elle finisse. Si elle a ete interrompue, effacer :\n"
            "  %s" % (age, detenteur, self.verrou))


# -------------------------------------------------------------------- verrou
DELAI_VERROU = 600  # au-dela, un verrou est tenu pour abandonne (10 minutes)


@contextlib.contextmanager
def verrou_compteurs(ctx: Contexte, qui: str = "?", delai: int = DELAI_VERROU):
    """Exclut deux attributions de numeros simultanees.

    Un verrou est un fichier cree en exclusif : la creation echoue si le
    fichier existe, et c'est le systeme qui arbitre, pas nous. Passe `delai`,
    on considere que le detenteur est mort (machine eteinte, fenetre fermee)
    et on reprend la main -- sinon un plantage bloquerait le logiciel pour
    toujours.
    """
    chemin = ctx.racine / "config" / ".compteurs.verrou"
    marque = "%s pid %d %s" % (qui, os.getpid(),
                               _dt.datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
    for essai in (1, 2):
        try:
            fd = os.open(str(chemin), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, marque.encode("utf-8"))
            os.close(fd)
            break
        except FileExistsError:
            try:
                age = int(time.time() - chemin.stat().st_mtime)
                detenteur = chemin.read_text(encoding="utf-8").strip()
            except OSError:            # disparu entre-temps : on retente
                continue
            if age < delai or essai == 2:
                raise CompteursVerrouilles(chemin, detenteur, age)
            chemin.unlink(missing_ok=True)   # verrou abandonne, on le leve
    try:
        yield
    finally:
        # Ne retirer QUE le notre : si le delai a joue, un autre l'a peut-etre
        # repris entre-temps.
        try:
            if chemin.read_text(encoding="utf-8").strip() == marque:
                chemin.unlink(missing_ok=True)
        except OSError:
            pass


# ================================================ LA PREUVE DES ACTES SORTANTS
#
# Deposer une DSN, deposer une DPAE, envoyer les documents a un salarie : les
# seuls gestes du logiciel qui engagent l'employeur. Ils vivent dans
# `operations_declarations` et `operations_documents`, et les deux faces ne
# font que les appeler. Ce qu'ils exigent tous -- la preuve qu'un humain veut
# l'acte -- vit ici, pour qu'aucun des deux n'en ait sa propre version.
#
# La regle etait autrefois plus simple : « rien ne part depuis l'interface »
# (en-tete de web.py). Elle a ete ecrite AVANT la seance, a une epoque ou une
# page de navigateur n'avait aucun moyen de prouver qu'un humain voulait
# l'acte -- ni mot de passe, ni confirmation datee. Les fenetres `.cmd`
# avaient les deux, la page n'avait rien, donc la page n'avait pas le droit.
#
# Depuis le 11/09/2026 les deux mecanismes existent, et ils vivent dans le
# moteur : la SEANCE prouve la presence, la CONFIRMATION prouve la lecture. La
# regle peut donc etre levee -- mais pas en ajoutant trois boutons. En
# ajoutant ces operations-la, avec leur preuve, et en laissant les deux faces
# passer par elles.


@dataclass
class Preuve:
    """Ce qui prouve qu'un humain veut CET acte, MAINTENANT.

    DEUX FORMES, ET JAMAIS RIEN.

    - `mois_recopie` : le mois declare, retape a la main. C'est la preuve de
      la ligne de commande et des fenetres `.cmd`. Recopier n'est pas
      confirmer -- on ne recopie pas par reflexe.
    - `motdepasse` : le mot de passe DU LOGICIEL, retape au moment de l'acte.
      C'est la preuve de l'interface, et le supplement qu'elle paie pour avoir
      le droit de deposer. La seance prouve la presence UNE FOIS, pour deux
      heures ; un onglet de navigateur, lui, reste ouvert des heures -- sur
      une machine qu'on quitte, a cote de quelqu'un d'autre. Retaper rend au
      geste la preuve que la seance ne donne qu'en debut de journee.

    Le mot de passe arrive dans le CORPS d'une requete POST, jamais dans une
    URL -- elle finirait dans les journaux et l'historique du navigateur. Il
    n'est confronte qu'a `coffre.verifier_ouverture`, qui repond oui ou non.
    Le secret de l'ORGANISME, lui, ne quitte jamais le moteur : la page ne le
    voit pas, ne le demande pas, ne le recoit pas.

    Pourquoi le mot de passe peut remplacer le mois recopie -- c'est une
    La decision prise, et elle a une consequence de
    conception a tenir : recopier le mois etait le SEUL geste qu'on ne peut
    pas faire sans regarder l'ecran. Un mot de passe se tape de memoire, les
    yeux ailleurs. Le mois declare doit donc etre GROS et lisible dans le
    recapitulatif que la page montre -- c'est lui qui porte maintenant toute
    la lecture.
    """
    mois_recopie: Optional[str] = None
    motdepasse: Optional[str] = None

    @property
    def vide(self) -> bool:
        return not (self.mois_recopie or self.motdepasse)


class PreuveInsuffisante(ErreurOperation):
    """Personne n'a prouve vouloir cet acte. Rien n'est parti."""


class SeanceFermee(ErreurOperation):
    """Le depot demande une seance ouverte, et elle ne l'est pas.

    Un agent ne peut pas l'ouvrir, et c'est voulu : `getpass` echoue sans
    terminal. Voir CLAUDE.md.
    """


def _verifier_preuve(ctx: Contexte, preuve: Optional["Preuve"],
                     mois_attendu: str, quoi: str) -> str:
    """Rend la forme de preuve retenue, ou leve. Aucun acte sans l'une des deux.

    Note bien ce qui N'EST PAS accepte : un booleen « confirme=True » venu du
    front. Une case cochee par le code appelant ne prouve rien du tout, et
    c'est exactement la faute contre laquelle `operations` a ete ecrit --
    invisible a la relecture, parce qu'elle a l'air d'une confirmation.
    """
    from . import coffre

    if preuve is None or preuve.vide:
        raise PreuveInsuffisante(
            "Rien ne prouve que vous voulez ce depot. Deux formes sont "
            "acceptees : recopier le mois declare (%s), ou retaper le mot de "
            "passe du logiciel." % mois_attendu)
    if preuve.mois_recopie:
        if preuve.mois_recopie.strip() != mois_attendu:
            raise PreuveInsuffisante(
                "Mois confirme '%s' alors que le fichier declare '%s'. "
                "Rien n'est parti." % (preuve.mois_recopie.strip(), mois_attendu))
        return "mois recopie"
    if not coffre.verifier_ouverture(ctx, preuve.motdepasse or ""):
        raise PreuveInsuffisante(
            "Mot de passe du logiciel refuse. Rien n'est parti.")
    return "mot de passe du logiciel"


def seance(ctx: Contexte) -> dict:
    """Ou en est la seance, en dictionnaire. Ne delivre rien, ne demande rien.

    Public : les deux faces l'affichent, et un ecran qui propose un depot doit
    pouvoir dire d'avance qu'il sera refuse plutot que de le faire decouvrir
    au clic.
    """
    from . import coffre
    s = coffre.seance(ctx)
    return {"ouverte": s.ouverte, "exigee": s.exigee,
            "ouverte_le": s.ouverte_le}


# ---------------------------------------------------------------- le filet
def _lire_json(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


GARDER_COPIES = 20


def _sauver_avant(chemin: Path) -> Optional[Path]:
    """Copie horodatee du fichier, avant de le remplacer.

    Ce n'est pas un versionnement, c'est un filet : la configuration et les
    saisies n'existent qu'ici, et un mauvais enregistrement ne doit pas etre
    definitif. On ne garde que les `GARDER_COPIES` dernieres par fichier --
    au-dela, ce n'est plus un filet, c'est un tas.
    """
    if not chemin.exists():
        return None
    dossier = chemin.parent / "avant"
    dossier.mkdir(exist_ok=True)
    copie = dossier / ("%s.%s" % (chemin.name,
                                  _dt.datetime.now().strftime("%Y%m%d-%H%M%S")))
    copie.write_bytes(chemin.read_bytes())

    anciennes = sorted(dossier.glob(chemin.name + ".*"))
    for vieille in anciennes[:-GARDER_COPIES]:
        vieille.unlink(missing_ok=True)
    return copie
