"""AEM V5 - Attestation Employeur Mensuelle pour France Travail Spectacle.

Format a largeur fixe : un enregistrement de 1000 caracteres par contrat,
termine par CRLF, encodage latin-1. Le gabarit `gabarits/aem_v5_gabarit.txt`
est un enregistrement reel produit par CoolPaie ; on n'y remplace que les
zones variables, ce qui garantit que tout le reste reste conforme.

Le schema ci-dessous a ete valide sur les 189 enregistrements AEM emis entre
2021 et 2026 (voir `python -m moteur calibrer`).
"""
from __future__ import annotations
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

from .contexte import GABARITS
from .util import aaaammjj, d

GABARIT = GABARITS / "aem_v5_gabarit.txt"
LONGUEUR = 1000

# nom -> (debut, fin) dans l'enregistrement de 1000 caracteres
CHAMPS = {
    "date_fin_entete":   (7, 15),    # AAAAMMJJ
    "mois":              (15, 21),   # MMAAAA
    "num_attestation":   (36, 42),   # sequence a 6 chiffres
    "nom":               (300, 325),
    "prenom":            (325, 350),
    "nir":               (375, 390),  # NIR 13 + cle 2
    "date_naissance":    (390, 398),  # AAAAMMJJ
    "code_nationalite":  (527, 529),
    "date_debut":        (618, 626),  # precede de 'N' en 617
    "date_fin":          (627, 635),  # precede de 'N' en 626
    "numero_objet":      (638, 650),
    # Trois champs accoles, tels que les nomme le formulaire officiel
    # (affichage/aemV5/aemV501.pdf) : "Nombre d'HEURES effectuees",
    # "Nombre de CACHETS", "Nombre de JOURS travailles". Verifie sur 185 des
    # 189 enregistrements de export/AEM_EDI (les 4 autres sont un contrat de
    # 2021 au format anterieur).
    "nb_heures":         (650, 653),
    "nb_cachets":        (653, 655),
    "nb_jours":          (655, 659),
    # Numero de licence d'entrepreneur de spectacles. Fige dans le gabarit
    # jusqu'au 04/09/2026 ; il change, donc on le repose a chaque ecriture.
    # Largeur deduite des 189 enregistrements historiques, tous a 10 caracteres
    # exactement, suivis de "NN" : un test verifie que ce voisin reste intact.
    "licence":           (232, 242),
    "brut_cts":          (659, 668),
    "assiette_cts":      (668, 677),
    "taux_chomage":      (677, 681),  # pourcentage x 100 (1215 = 12,15 %)
    "montant_cts":       (681, 690),  # arrondi a l'EURO puis x100
    "montant_total_cts": (712, 721),
    "date_signature":    (858, 866),  # AAAAMMJJ
    "signataire":        (866, 891),  # zone libre : "KRASNOPOLSKY" ou "KRASNOPOLSKY JEROME"
}


def taux_chomage(paie) -> Decimal:
    """Taux de contribution d'assurance chomage porte par l'AEM, en pourcent."""
    return Decimal(str(paie.__dict__.get("taux_chomage_aem", 12.15)))


def contribution(paie) -> Decimal:
    """Montant de la contribution, ARRONDI A L'EURO comme l'exige le format.

    Sortie du calcul de `enregistrement`, isolee pour que l'AEM papier
    (`moteur/aem_pdf.py`) et le fichier EDI ne puissent pas diverger : un
    salarie qui compare son attestation au depot doit trouver le meme chiffre.
    """
    brut_cts = int((Decimal(str(paie.brut)) * 100).to_integral_value())
    return (Decimal(brut_cts) / 100 * taux_chomage(paie) / 100).quantize(
        Decimal("1"), rounding=ROUND_HALF_UP)


def _num(valeur, largeur: int) -> str:
    s = str(int(valeur))
    if len(s) > largeur:
        raise ValueError(f"valeur {valeur} trop longue pour {largeur} caracteres")
    return s.zfill(largeur)


def _txt(valeur: str, largeur: int) -> str:
    s = (valeur or "").upper()[:largeur]
    return s.ljust(largeur)


def enregistrement(paie, ent: dict, num_attestation: int, date_emission=None,
                   signataire=None) -> str:
    """Construit un enregistrement AEM de 1000 caracteres pour une paie."""
    gab = GABARIT.read_text(encoding="latin-1").rstrip("\r\n")
    if len(gab) != LONGUEUR:
        raise ValueError(f"gabarit AEM corrompu ({len(gab)} != {LONGUEUR})")
    buf = list(gab)

    def poser(champ: str, valeur: str):
        a, b = CHAMPS[champ]
        v = str(valeur)
        if len(v) != b - a:
            raise ValueError(f"{champ}: {v!r} fait {len(v)} car., attendu {b - a}")
        buf[a:b] = list(v)

    s, e = paie.salarie, paie.engagement
    fin = d(e.fin)
    emission = d(date_emission or fin)
    brut_cts = int((Decimal(str(paie.brut)) * 100).to_integral_value())
    taux = taux_chomage(paie)
    montant_cts = int(contribution(paie)) * 100

    # `ent["licence_spectacle"]` est resolu par l'appelant (Contexte.licence) :
    # c'est le numero en vigueur sur le mois declare. Une liste non resolue
    # arriverait ici, on refuse plutot que d'ecrire n'importe quoi.
    licence = ent.get("licence_spectacle")
    if isinstance(licence, (list, tuple)):
        raise ValueError(
            "licence_spectacle non resolue : passer ent avec la valeur du mois "
            "(Contexte.licence), pas la liste datee de config/entreprise.json.")
    if licence:
        poser("licence", _txt(licence, 10))

    poser("date_fin_entete", aaaammjj(fin))
    poser("mois", fin.strftime("%m%Y"))
    poser("num_attestation", _num(num_attestation, 6))
    poser("nom", _txt(s["nom"], 25))
    poser("prenom", _txt(s["prenom"], 25))
    poser("nir", s["nir"] + s["nir_cle"])
    poser("date_naissance", aaaammjj(s["date_naissance"]))
    poser("code_nationalite", s["code_nationalite_dsn"])
    poser("date_debut", aaaammjj(e.debut))
    poser("date_fin", aaaammjj(fin))
    poser("numero_objet", paie.spectacle["numero_objet"])
    poser("nb_heures", _num(e.heures or 0, 3))
    poser("nb_cachets", _num(e.cachets, 2))
    poser("nb_jours", _num(e.jours, 4))
    poser("brut_cts", _num(brut_cts, 9))
    poser("assiette_cts", _num(brut_cts, 9))
    poser("taux_chomage", _num(taux * 100, 4))
    poser("montant_cts", _num(montant_cts, 9))
    poser("montant_total_cts", _num(montant_cts, 9))
    poser("date_signature", aaaammjj(emission))
    poser("signataire", _txt(signataire or ent["signataire"].get("nom_aem")
                            or ent["signataire"]["nom"], 25))
    return "".join(buf)


def ecrire(paies: list, ent: dict, chemin, premier_numero: int, date_emission=None) -> Path:
    """Ecrit le fichier AEM EDI V5 (un enregistrement par contrat)."""
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    lignes = []
    for i, p in enumerate(paies):
        lignes.append(enregistrement(p, ent, premier_numero + i, date_emission))
    data = "".join(l + "\r\n" for l in lignes)
    chemin.write_bytes(data.encode("latin-1"))
    return chemin


def relire(chemin) -> list:
    """Relit un fichier AEM et renvoie les champs decodes (verification / debug)."""
    out = []
    for l in Path(chemin).read_bytes().split(b"\r\n"):
        if not l.strip():
            continue
        r = l.decode("latin-1")
        out.append({k: r[a:b] for k, (a, b) in CHAMPS.items()})
    return out
