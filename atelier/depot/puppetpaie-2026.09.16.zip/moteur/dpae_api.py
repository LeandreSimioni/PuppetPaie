"""Client de l'API DPAE de l'Urssaf -- DEPOT.

Source : « API DPAE - Guide d'implementation », Acoss NAT/5492,
`reference/norme-dpae/API-DPAE-Guide-Implementation-NAT5492.pdf`. Le guide dit
en toutes lettres que le mode API DPAE est « entierement compatible avec le
mode API disponible pour la DSN » : memes interfaces, seules changent les
adresses et les elements echanges. Tout le transport de `netentreprises.py`
est donc reutilise tel quel, y compris la facon de traiter le mot de passe.

    POST https://mon.urssaf.fr/authentifier_dpae
    POST https://depot.dpae-edi.urssaf.fr/deposer-dsn/1.0/
    GET  https://consultation.dpae-edi.urssaf.fr/lister-retours-declarant/1.0/...
    GET  https://telechargement.dpae-edi.urssaf.fr/...

Oui, la ressource de depot s'appelle bien `/deposer-dsn` meme pour une DPAE :
le guide le precise explicitement. Ce n'est pas une faute de frappe.

CE QUI EST DEPOSE. Le guide accepte deux formats, « DPAE XML » et « DPAE a
plat ». On depose le format a plat : c'est celui que produit `dpae.py`, et
c'est octet pour octet celui que CoolPaie deposait et que le SI DPAE a
accepte. Les archives sont refusees : on envoie le `.txt`, jamais le `.zip`.

DEUX POINTS NON RESOLUS, tenus au grand jour plutot que devines :

1. **Le code service de l'authentification : 25.** Le meme que la DSN. Ce
   n'est pas dans le guide d'implementation, c'est dans la FAQ officielle
   (`reference/norme-dpae/5493-API-DPAE-FAQ.pdf`) : « Pour un declarant ou
   tiers declarant, il convient de parametrer le service 25 » ; 98 pour un
   concentrateur. Il vit dans `config/entreprise.json`, cle `api_dpae.service`.

2. **L'indicateur de test : TST.** Meme source : « Pour une DPAE au format TXT,
   l'indicateur de test vaut TST et pour un depot reel, il vaut 120. Champ
   C_VERSION. » Ce champ est en position 72-75 de chaque enregistrement, la ou
   le format XML porte `FR_DUE_Upload.Test.Indicator`.

   Il y a donc un vrai mode test, et il passe par le service de PRODUCTION :
   « Vous pouvez realiser des tests a partir d'un compte client en deposant une
   DPAE de test sur le service de production. » La bascule se fait en memoire
   (`basculer_en_test`), jamais sur le disque : un fichier « de test » qui
   traine finit par etre depose pour de vrai.

3. **L'inscription : aucune.** Toujours la FAQ : « L'API DPAE ne necessite pas
   d'inscription specifique. En revanche, il est necessaire d'avoir au moins un
   abonne inscrit a un des services en ligne de l'Urssaf. » Seuls les
   concentrateurs doivent s'inscrire.

HABILITATION. api.gouv.fr annonce un « acces restreint » (contact
api-dpae@acoss.fr), mais c'est la procedure de referencement des editeurs.
CoolPaie, lui, depose les DPAE de la compagnie par ce canal depuis des annees,
avec les seuls identifiants de l'employeur : SIRET, nom, prenom, mot de passe, dans
un ecran « SOCIETE / DUE MtoM ». Son journal de version le documente sans
ambiguite (4.0.0.8.267 « ajout de la DUE mTom », 4.0.0.8.273 « boutons de test
des connexions MtoM DUE ET DSN », 4.0.0.8.293 « correction connexion DUE
MtoM »). Le canal est donc ouvert au declarant lui-meme, sans statut d'editeur.

Ce que CoolPaie nous apprend d'autre, et qui n'est nulle part dans le guide :
le mot de passe part **en majuscules**, il ne doit pas contenir de `@`, et les
nom et prenom du declarant ne doivent pas porter d'accent. Voir
`ClientDpae._preparer_motdepasse` et `verifier_identifiants`.

Une authentification refusee ne declare rien. Mais les tentatives repetees
bloquent le compte (HTTP 403) : en cas de refus, lire le message avant de
recommencer, ne pas essayer des variantes a l'aveugle.
"""
from __future__ import annotations
import gzip

from .netentreprises import Client, ErreurApi, USER_AGENT  # noqa: F401

# Le compte de la DPAE est un compte URSSAF, distinct du compte
# net-entreprises de la DSN : deux ecrans et deux mots de passe chez CoolPaie,
# donc deux variables ici. Melanger les deux ne donnerait qu'un 401 opaque.
VARIABLE_MOTDEPASSE_DPAE = "URSSAF_MOTDEPASSE"

# Guide, § « Table d'adressage des services ». Le port 8443 ne concerne que les
# concentrateurs : nous deposons pour nous-memes, en declarant.
# ETAT REEL, etabli le 04/09/2026 sur cette machine. A lire avant de toucher
# a ce module.
#
#   depot.dpae-edi.urssaf.fr/deposer-dsn/1.0/  -> 401 DSNLogin.
#       L'API de depot est VIVANTE aujourd'hui. api.gouv.fr la reference
#       toujours, avec cette base d'adresse.
#   mon.urssaf.fr/authentifier_dpae            -> 404, vraie page 404 du site.
#       Cette route d'authentification N'EXISTE PLUS. Sans jeton, pas de depot.
#
# D'ou vient l'adresse morte : de `coolpaieconsole2021.jar`, l'outil de
# teletransmission de CoolPaie, qui la porte en dur -- mais il date de 2021.
# L'executable de 2026 (`coolpaieMP.exe`) ne contient plus AUCUNE adresse
# dpae-edi. Il contient `www.due.urssaf.fr/declarant/upload.jsf` : CoolPaie ne
# depose plus la DPAE en MtoM, il televerse le fichier sur le portail DUE. Ce
# que confirme son journal d'aout 2026 : « Creation d'une DUE EDI par depot ».
#
# CE QUI MANQUE DONC : une seule chose, l'adresse d'authentification actuelle
# de l'API DPAE. Elle se demande a api-dpae@acoss.fr. Le reste de ce module est
# ecrit, teste, et conforme a ce que le guide et le jar decrivent.
#
# Ce que le jar de 2021 apprend, et qui reste valable :
#   - le corps d'authentification est <identifiants> avec siret, nom, prenom,
#     motdepasse, service (enum `EnumDSNXMLNode`) -- exactement le notre ;
#   - POST, Content-Type: application/xml, UTF-8 ;
#   - au depot : text/plain, Content-Encoding: gzip, Authorization DSNLogin ;
#   - `-letype` vaut 100 pour la DUE et 110 pour la DSN. C'est l'aiguillage
#     interne de CoolPaie entre les deux jeux d'adresses, pas une donnee du
#     message : il ne figure pas dans les noeuds XML.
#
#
# Note : `www.due.urssaf.fr` et `urssaf.fr` sont injoignables depuis
# l'environnement de travail (ECONNRESET), comme `boss.gouv.fr`. On ne peut
# donc rien mettre au point contre le portail DUE d'ici.
# CE QUI EST DOCUMENTE, ET CE QUI EST DEDUIT -- essaye le 12/09/2026.
#
# Le guide d'implementation donne les HOTES (table d'adressage des services)
# mais pas les ressources de consultation. La FAQ, elle, documente une seule
# URL de listage : `lister-retours-flux/1.0/<idflux>`.
#
# `lister-retours-declarant` et `lister-depots` etaient deduits par analogie
# avec l'API DSN. ESSAYES POUR DE VRAI le 12/09/2026, et le resultat demande
# d'etre lu avec soin :
#
#   - l'adresse EXISTE et repond. La FAQ le disait (<< les retours sont
#     consultables par declarant [...] par declarant et par periode >>) ;
#   - mais elle rend **HTTP 404 sur une plage sans retour**. La meme adresse
#     rend 404 pour le 8 septembre et la liste complete pour le 4.
#
# Un 404 ne veut donc PAS dire ici << ce service n'existe pas >>. C'est une
# facon de dire << rien sur cette plage >>, et le confondre coute cher :
# `relever_retours` enveloppait la boucle entiere dans un seul `try`, si bien
# qu'une reprise commencant par un jour vide s'arretait au premier jour et ne
# trouvait jamais rien. Corrige -- un 404 passe a la tranche suivante, tout
# autre code arrete.
#
# Le chemin par FLUX (`lister-retours-flux/1.0/<idflux>`) reste le seul
# documente noir sur blanc, et il sert quand on connait l'idflux.
#
# Retention, guide § CONTRAINTES D'EXPLOITATION : consultation 13 mois,
# TELECHARGEMENT 3 MOIS. Passe ce delai le retour est purge et n'est pas
# archive par le SI DPAE -- ce qui est une bonne raison de relever tot.
ADRESSES_DPAE = {
    "authentification": "https://mon.urssaf.fr/authentifier_dpae",
    "depot": "https://depot.dpae-edi.urssaf.fr/deposer-dsn/1.0/",
    # Deduite, et refusee par le service (404). Laissee en place pour que la
    # tentative reste lisible, pas parce qu'elle marche.
    "retours": "https://consultation.dpae-edi.urssaf.fr/lister-retours-declarant/1.0/",
    "depots": "https://consultation.dpae-edi.urssaf.fr/lister-depots/1.0/",
    # Documentee par la FAQ officielle, et la seule qui le soit.
    "retours_flux": "https://consultation.dpae-edi.urssaf.fr/lister-retours-flux/1.0/",
    "service": None,          # voir l'en-tete du module, point 1
}

# Guide, § « Disponibilite des retours par environnements ».
NATURES = {
    "10": "avis de rejet du depot",
    "11": "certificat de conformite / bilan d'anomalies",
    "20": "bilan d'identification des salaries",
    "41": "certificat de conformite des DPAE",
}

# Le champ C_VERSION de l'enregistrement a plat, en position 72-75. FAQ
# officielle : « Pour une DPAE au format TXT, l'indicateur de test vaut TST et
# pour un depot reel, il vaut 120. » Trois caracteres dans les deux cas, donc
# la bascule ne decale rien.
INDICATEUR = (72, 75)
INDICATEUR_REEL = "120"
INDICATEUR_TEST = "TST"


class ClientDpae(Client):
    """Meme transport que l'API DSN, adresses de la DPAE."""

    def __init__(self, ctx, majuscules: bool = False, motdepasse: str = None):
        super().__init__(ctx, "production", motdepasse=motdepasse)
        self.env = "dpae"
        self.adresses = dict(ADRESSES_DPAE)
        self.majuscules = majuscules
        self.variable_motdepasse = VARIABLE_MOTDEPASSE_DPAE
        cfg = ctx.entreprise.get("api_dpae") or {}
        if cfg.get("service"):
            self.adresses["service"] = cfg["service"]
        # Le compte de la DPAE n'est PAS celui de la DSN : c'est un compte
        # Urssaf. CoolPaie les tient dans deux panneaux distincts, avec deux
        # mots de passe differents. On fait pareil.
        self.declarant = {"siret": cfg.get("siret") or ctx.entreprise.get("siret"),
                          "nom": cfg.get("nom"), "prenom": cfg.get("prenom")}

    # ------------------------------------------------- exigences de la DPAE
    def _preparer_motdepasse(self, mdp: str) -> str:
        """Le mot de passe part TEL QU'IL EST TAPE. Verifie le 04/09/2026.

        J'avais d'abord conclu l'inverse, sur cette ligne du journal de version
        de CoolPaie (4.0.0.8.275) : « MtoM : verification du mot de passe en
        majuscule pour la DUE MtoM Urssaf ». Mauvaise lecture -- CoolPaie
        verifie sans doute autre chose. La connexion reelle passe avec le mot
        de passe tel quel, et echouait en majuscules.

        `--majuscules` reste disponible au cas ou un compte aurait la regle
        inverse ; ce n'est pas le defaut.
        """
        return mdp.upper() if self.majuscules else mdp

    def verifier_identifiants(self) -> list:
        """Ce que CoolPaie verifie AVANT d'ouvrir la connexion DUE MtoM.

        Renvoie la liste des problemes, en clair. Aucun n'est devine : chacun
        vient d'une ligne du journal de version de CoolPaie (4.0.0.8.275).
        """
        import os
        import unicodedata
        soucis = []
        manquants = [c for c in ("siret", "nom", "prenom")
                     if not self.declarant.get(c)]
        if manquants:
            soucis.append(
                "Identite du declarant DPAE incomplete (manque : %s). Elle se "
                "renseigne dans config/entreprise.json, cle `api_dpae`, et se "
                "recopie de l'ecran CoolPaie SOCIETE / DSN-DUE, panneau DUE."
                % ", ".join(manquants))
        for champ in ("nom", "prenom"):
            v = self.declarant.get(champ) or ""
            if v != unicodedata.normalize("NFKD", v).encode(
                    "ascii", "ignore").decode("ascii"):
                soucis.append(
                    "Le %s du declarant (%r) porte un accent. La DUE MtoM les "
                    "refuse : corriger config/entreprise.json." % (champ, v))
        mdp = self._motdepasse or os.environ.get(self.variable_motdepasse) or ""
        if "@" in mdp:
            soucis.append(
                "Le mot de passe contient un caractere @, que la connexion "
                "MtoM refuse. Il doit etre change sur net-entreprises.fr.")
        return soucis

    def deposer(self, contenu: bytes) -> dict:
        """Depose un flux DPAE a plat. Renvoie ce que le SI DPAE a repondu.

        `contenu` est le fichier tel qu'il sera declare : aucune retouche ici,
        pour que ce qui part soit exactement ce qui a ete relu.
        """
        self._assurer_session()
        corps = gzip.compress(contenu)
        brut, entetes = self._appel_depot(self.adresses["depot"], corps)
        return {"reponse": brut.decode("utf-8", "replace").strip(),
                "type": entetes.get("Content-Type", "")}

    def _appel_depot(self, url, corps):
        """Comme `_appel`, avec l'en-tete Content-Encoding: gzip du guide."""
        import urllib.error
        import urllib.request
        from .netentreprises import MESSAGES, _sans_secret
        entetes = {"User-Agent": USER_AGENT,
                   "Content-Type": "text/plain",
                   "Content-Encoding": "gzip",
                   "Accept-Encoding": "gzip",
                   "Authorization": "DSNLogin jeton=%s" % self.jeton}
        req = urllib.request.Request(url, data=corps, headers=entetes,
                                     method="POST")
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                brut = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    brut = gzip.decompress(brut)
                return brut, dict(r.headers)
        except urllib.error.HTTPError as e:
            corps_err = ""
            try:
                corps_err = e.read().decode("utf-8", "replace")[:400]
            except Exception:
                pass
            raise ErreurApi("HTTP %d au depot sur %s\n  %s%s"
                            % (e.code, _sans_secret(url),
                               MESSAGES.get(e.code, ""),
                               ("\n  " + corps_err) if corps_err.strip() else "")
                            ) from None
        except urllib.error.URLError as e:
            raise ErreurApi("Reseau injoignable pour %s : %s"
                            % (_sans_secret(url), e.reason)) from None


def indicateur(contenu: bytes) -> str:
    """Valeur de C_VERSION du premier enregistrement."""
    a, b = INDICATEUR
    return contenu[a:b].decode("latin-1", "replace")


def est_reel(contenu: bytes) -> bool:
    return indicateur(contenu) == INDICATEUR_REEL


def basculer_en_test(contenu: bytes, longueur: int = 990) -> bytes:
    """Repasse chaque enregistrement en C_VERSION = TST.

    Le fichier sur le disque reste un fichier reel : la bascule se fait en
    memoire, juste avant l'envoi, et le contenu transforme est celui qu'on
    affiche. On ne garde pas de « fichier de test » sur le disque, qui finirait
    tot ou tard par etre depose pour de vrai.
    """
    a, b = INDICATEUR
    if len(contenu) % longueur:
        raise ValueError("flux DPAE de longueur inattendue")
    sortie = bytearray(contenu)
    for i in range(len(contenu) // longueur):
        deb = i * longueur + a
        sortie[deb:i * longueur + b] = INDICATEUR_TEST.encode("latin-1")
    return bytes(sortie)
