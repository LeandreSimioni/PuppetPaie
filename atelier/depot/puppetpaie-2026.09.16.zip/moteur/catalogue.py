"""Le catalogue des rubriques : ce qu'une compagnie peut payer.

Deux niveaux, et la separation est la raison d'etre de ce module.

    moteur/rubriques-base.json     LE LOGICIEL. Livre avec le code, public.
                                   Ne decrit aucune compagnie : decrit ce que
                                   la reglementation permet de payer.

    config/rubriques-compagnie.json  LES DONNEES. Les rubriques propres a une
                                   compagnie, et les ajustements qu'elle fait
                                   aux rubriques de base.

    config/rubriques-actives.json  LES DONNEES. Celles qu'elle a cochees, et
                                   combien de fois elle s'en est servie.

Une compagnie de marionnettes qui joue des cachets et deux masterclasses par
an n'a pas a voir passer treize rubriques dans une liste deroulante. Elle
coche les siennes ; le catalogue les remonte, la plus utilisee en tete. Les
autres restent disponibles, en second rang, pour le jour ou elle fait une
residence.

CE MODULE NE CALCULE RIEN. Il dit ce qu'est une rubrique ; le calcul viendra
s'en servir quand le rejeu aura prouve qu'il retrouve cinq ans de bulletins.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

CODE = Path(__file__).resolve().parent
BASE = CODE / "rubriques-base.json"

# Les unites que le moteur sait compter. Une rubrique qui en porterait une
# autre serait refusee : mieux vaut s'arreter que produire une quantite dont
# personne ne sait ce qu'elle mesure.
UNITES = ("cachet", "heure", "jour", "semaine", "mois", "service",
          "forfait", "pourcentage")

# Les natures juridiques. C'est la nature qui commande l'assujettissement --
# un defraiement est hors assiette parce que ce n'est pas un salaire, pas
# parce qu'une case est decochee.
NATURES = ("salaire", "frais", "avantage_nature", "indemnite", "prime",
           "retenue", "absence")

# Toutes les heures ne comptent pas pour la meme chose, et les melanger
# annoncerait une allocation fausse :
#   "droits_et_montant"     le cas ordinaire -- elles ouvrent les droits ET
#                           entrent dans le calcul de l'ARE ;
#   "ouverture_des_droits"  les heures d'enseignement : elles font atteindre
#                           les 507 heures, mais n'augmentent pas l'ARE.
# C'est a cumul.py de tenir les deux decomptes ; la rubrique dit seulement
# dans lequel elle tombe.
COMPTE_POUR = ("droits_et_montant", "ouverture_des_droits")


# --------------------------------------------------------------- la rubrique
@dataclass(frozen=True)
class Rubrique:
    """Une forme de paie. Ce que le bulletin appelle une ligne."""
    code: str
    libelle: str
    unite: str
    nature: str
    saisie: tuple                    # les champs a demander a la saisie
    soumis: bool                     # entre dans l'assiette des cotisations
    imposable: bool                  # entre dans le net imposable
    conges_spectacles: bool          # entre dans l'assiette Conges Spectacles
    source: str                      # d'ou vient la regle -- jamais vide
    sens: str = "+"                  # "-" pour une absence ou une retenue
    heures_forfait: Optional[float] = None   # heures accordees, non faites
    plafond: Optional[str] = None            # unite de proratisation Urssaf
    aem: Optional[str] = None                # nature declaree a France Travail
    dsn_type: Optional[str] = None           # aiguillage DSN
    dsn_autres_bruts: Optional[str] = None   # S21.G00.54.001
    annexe: Optional[str] = None             # "VIII", "X", ou None pour les deux
    plafond_mensuel: Optional[int] = None    # 28 cachets par mois au plus
    plafond_annuel_heures: Optional[dict] = None   # par tranche d'age
    compte_pour: str = "droits_et_montant"   # voir plus bas
    origine: str = "base"            # "base" ou "compagnie"
    usages: int = 0                  # combien de fois elle a servi
    active: bool = False

    def __post_init__(self):
        if self.unite not in UNITES:
            raise ValueError(
                "Rubrique %r : unite %r inconnue. Connues : %s."
                % (self.code, self.unite, ", ".join(UNITES)))
        if self.nature not in NATURES:
            raise ValueError(
                "Rubrique %r : nature %r inconnue. Connues : %s."
                % (self.code, self.nature, ", ".join(NATURES)))
        if self.compte_pour not in COMPTE_POUR:
            raise ValueError(
                "Rubrique %r : compte_pour %r inconnu. Connus : %s."
                % (self.code, self.compte_pour, ", ".join(COMPTE_POUR)))
        if not self.source:
            raise ValueError(
                "Rubrique %r : `source` est vide. Une rubrique dit d'ou vient "
                "sa regle, sinon personne ne pourra la verifier." % self.code)

    # --- ce que la rubrique apporte au decompte des annexes VIII et X
    def heures(self, quantite: float, heures_saisies: Optional[float] = None):
        """Les heures que cette ligne fait compter.

        Le forfait l'emporte quand il existe -- les 12 h du cachet sont
        accordees par le reglement, elles ne se discutent pas. Sinon ce sont
        les heures saisies, parce qu'elles sont un fait.
        """
        if self.heures_forfait is not None:
            return self.heures_forfait * quantite
        if heures_saisies is not None:
            return heures_saisies * quantite
        if self.unite == "heure":
            return quantite
        return 0.0

    def jours(self, *_, **__):
        """Aucune rubrique ne fait compter de jours.

        Les jours travailles se saisissent, avec les dates. Cette methode
        existe pour que personne ne recree le coefficient `jours` de CoolPaie
        en croyant combler un manque.
        """
        raise TypeError(
            "Les jours travailles sont une saisie, pas un coefficient de "
            "rubrique. Voir prive/reference/anatomie-rubrique-coolpaie.md.")


# ------------------------------------------------------------------- lecture
def _lire(p: Path) -> dict:
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding="utf-8"))


def _construire(code: str, d: dict, origine: str, usages: int,
                active: bool) -> Rubrique:
    connus = {f for f in Rubrique.__dataclass_fields__}
    inconnus = set(d) - connus
    if inconnus:
        raise ValueError(
            "Rubrique %r : champ(s) inconnu(s) %s. Le schema est celui de "
            "moteur/catalogue.Rubrique." % (code, ", ".join(sorted(inconnus))))
    return Rubrique(
        code=code, origine=origine, usages=usages, active=active,
        libelle=d["libelle"], unite=d["unite"], nature=d["nature"],
        saisie=tuple(d.get("saisie", ())),
        soumis=d["soumis"], imposable=d["imposable"],
        conges_spectacles=d["conges_spectacles"], source=d["source"],
        sens=d.get("sens", "+"),
        heures_forfait=d.get("heures_forfait"),
        plafond=d.get("plafond"), aem=d.get("aem"),
        dsn_type=d.get("dsn_type"),
        dsn_autres_bruts=d.get("dsn_autres_bruts"),
        annexe=d.get("annexe"),
        plafond_mensuel=d.get("plafond_mensuel"),
        plafond_annuel_heures=d.get("plafond_annuel_heures"),
        compte_pour=d.get("compte_pour", "droits_et_montant"))


def base() -> dict:
    """Le catalogue livre avec le logiciel. Toujours present."""
    return _lire(BASE).get("rubriques", {})


def _racine(ctx):
    """Ou chercher les rubriques de la compagnie.

    Sans contexte, on prend la racine des donnees par defaut -- la meme
    convention que partout ailleurs dans le logiciel. C'est ce qui permet a
    `Engagement` de resoudre une rubrique propre a la compagnie sans qu'on ait
    a lui passer un contexte : sans cela, une rubrique maison serait invisible
    la ou elle compte le plus, et la declaration sortirait fausse en silence.
    """
    if ctx is not None:
        return Path(ctx.racine)
    from .contexte import RACINE
    return Path(RACINE)


def catalogue(ctx=None) -> list:
    """Les rubriques disponibles, dans l'ordre ou les proposer.

    Les actives d'abord, la plus utilisee en tete ; les autres ensuite, par
    libelle. Une compagnie voit donc ce dont elle se sert, sans perdre ce
    qu'elle pourrait vouloir un jour.
    """
    brut = dict(base())
    choix, usages = {}, {}
    racine = _racine(ctx)
    if racine.is_dir():
        propres = _lire(racine / "config" / "rubriques-compagnie.json")
        for code, d in propres.get("rubriques", {}).items():
            if code in brut:                 # ajustement d'une rubrique de base
                brut[code] = {**brut[code], **d}
            else:                            # une rubrique bien a elle
                brut[code] = dict(d, _propre=True)
        actives = _lire(racine / "config" / "rubriques-actives.json")
        choix = set(actives.get("actives", ()))
        usages = actives.get("usages", {})

    out = []
    for code, d in brut.items():
        propre = d.pop("_propre", False)
        out.append(_construire(code, d, "compagnie" if propre else "base",
                               int(usages.get(code, 0)),
                               code in choix if choix else False))
    out.sort(key=lambda r: (not r.active, -r.usages, r.libelle.lower()))
    return out


def rubrique(code: str, ctx=None) -> Rubrique:
    """Une rubrique par son code. Leve si elle n'existe pas : mieux vaut
    s'arreter que payer une ligne dont on ignore le regime."""
    for r in catalogue(ctx):
        if r.code == code:
            return r
    connues = ", ".join(sorted(x.code for x in catalogue(ctx)))
    raise KeyError("Rubrique inconnue : %r. Connues : %s." % (code, connues))
