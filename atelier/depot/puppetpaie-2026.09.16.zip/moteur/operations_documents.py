"""Les documents aux salaries : preparer, envoyer, faire signer, archiver.

Un courriel n'engage pas l'employeur comme une declaration -- personne ne
preleve rien -- mais il part chez quelqu'un et ne revient pas. D'ou la meme
preuve que pour un depot (`operations_socle.Preuve`), et le meme garde-fou
des deux cotes : un envoi n'est jamais enchaine a la production.

LA SIGNATURE D'UN CLIC -- 15/09/2026
------------------------------------
Jusqu'ici le contrat partait en PDF, le salarie l'imprimait, le signait, le
scannait, et quelqu'un cliquait « recu ». La demande : « un truc ou le
salarie puisse signer en cliquant [...] et la signature arrive directement
dans le logiciel ». Trois pieces, toutes ici :

1. `demander_signature` : le courriel porte un bouton « Je signe ». C'est un
   lien `mailto:` vers le compte de la compagnie, objet et corps deja ecrits,
   avec un CODE UNIQUE par courriel (`SIG-XXXXXX`, tire au hasard, garde au
   journal avec la demande). Un tap sur le telephone, la messagerie s'ouvre,
   le salarie appuie sur « envoyer ». Rien a imprimer.
2. `relever_signatures` : a l'ouverture du logiciel et toutes les N minutes
   (operations_ouverture), on cherche dans Gmail les messages dont l'OBJET
   porte un code encore attendu. Une reponse venue de l'adresse de la fiche
   vaut signature : le journal la note (`contrat_recu`, avec l'origine), le
   message est archive tel quel (.eml, c'est la preuve), et le contrat
   CONTRESIGNE -- la case de l'artiste porte qui, quand, de quelle adresse,
   quel code -- lui est renvoye aussitot.
3. `contrat_recu` reste ce qu'il etait : un humain peut toujours dire qu'un
   contrat est revenu signe a la main. La relève ne fait que le dire a sa
   place quand elle en a la preuve.

Ce que ca vaut : une signature electronique « simple » (art. 1367 du code
civil) -- un procede qui identifie le signataire (son adresse, la meme que
celle a laquelle le contrat a ete envoye) et le lie a l'acte (le code, et le
message garde). Pas un service de signature certifie, et c'est un choix :
« je crois pas trop a ces usines a gaz [...] personne ne va contester avoir
appuye sur j'ai signe le contrat » (Leandre, 15/09/2026).

LE SEUL ENVOI SANS CLIC. Le contrat contresigne part tout seul, depuis la
veille. C'est l'exception a « rien ne part sans un clic » (envoi.py), et
elle est etroite : le clic a ete donne par le salarie lui-meme, le contenu
qui part est celui qu'il vient de signer, plus la trace de sa signature.
Rien d'autre ne part de la veille.
"""
from __future__ import annotations

import email
import email.policy
import email.utils
import html as _html
import re
import secrets
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .contexte import Contexte
from .operations_paies import Saisie, charger
from .operations_socle import ErreurOperation, Preuve, _verifier_preuve, seance
from .util import jj_mm_aaaa, quand_lisible


class SortieAbsente(ErreurOperation):
    """On demande a envoyer ou archiver un mois qui n'a pas ete produit."""

    def __init__(self, dossier, mois):
        self.dossier, self.mois = Path(dossier), mois
        super().__init__("%s n'existe pas." % self.dossier)


class GoogleNonAutorise(ErreurOperation):
    def __init__(self):
        super().__init__("Compte Google pas encore autorise.")


@dataclass
class EnvoiPrepare:
    saisie: Saisie
    messages: list
    expediteur: str
    client: Any
    avertissements: list = field(default_factory=list)


@dataclass
class FichierArchive:
    nom: str
    octets: int
    remplace: bool


@dataclass
class Archivage:
    mois: str
    racine_drive: str
    compte: str
    fichiers: list


# --------------------------------------------------------------------- envoi
def preparer_envoi(ctx: Contexte, source) -> EnvoiPrepare:
    """Les messages aux salaries, le compte verifie -- rien n'est parti.

    Le compte Google est construit ICI, avant toute page de relecture : un
    compte non autorise doit se voir avant le clic d'envoi, pas apres.
    """
    from . import envoi, google

    s = charger(ctx, source)
    dossier = ctx.racine / "sorties" / s.mois / "envoi"
    if not dossier.exists():
        raise SortieAbsente(dossier, s.mois)

    messages = envoi.preparer(s.paies, ctx.entreprise, s.mois, dossier)
    client = google.Client(ctx)          # peut lever google.ErreurGoogle
    if not client.compte:
        raise GoogleNonAutorise()

    expediteur = client.compte.lower()
    avertissements = []
    signataire = (ctx.entreprise["signataire"].get("email") or "").lower()
    if signataire and signataire != expediteur:
        avertissements.append(
            "Les messages partiront de %s (le compte Google autorise), pas de "
            "%s indique dans config/entreprise.json." % (expediteur, signataire))
    return EnvoiPrepare(saisie=s, messages=messages, expediteur=expediteur,
                        client=client, avertissements=avertissements)


def confirmer_et_envoyer(prepare: EnvoiPrepare, ouvrir: bool = True) -> dict:
    """Ouvre la page de relecture et n'envoie qu'apres confirmation.

    Le seul endroit ou les deux faces divergeront : la ligne de commande ouvre
    le navigateur sur une page servie en local, une interface aura deja la
    sienne et appellera `envoi.expedier` apres son propre ecran. Le garde-fou
    -- un envoi n'est jamais enchaine a la production -- est le meme des deux
    cotes : `produire_mois` ne mene jamais ici.
    """
    from . import envoi

    return envoi.relire_et_agir(prepare.messages, prepare.expediteur,
                                prepare.saisie.libelle, prepare.client,
                                ouvrir=ouvrir)


# ------------------------------------------------------------------ archivage
def archiver(ctx: Contexte, mois: str,
             racine_drive: str = "PuppetPaie") -> Archivage:
    """Depose les sorties d'un mois dans le Drive du compte autorise.

    A ne pas confondre avec `preparer_envoi` : meme mecanique, mais le
    destinataire c'est nous. Le fichier groupe y a toute sa place -- c'est
    l'archive de la compagnie, pas le courrier d'un salarie. Le sous-dossier
    `envoi/` est exclu : memes documents redecoupes par salarie, deja partis.
    """
    from . import google

    dossier = ctx.racine / "sorties" / mois
    if not dossier.exists():
        raise SortieAbsente(dossier, mois)
    fichiers = sorted(p for p in dossier.iterdir() if p.is_file())
    if not fichiers:
        raise SortieAbsente(dossier, mois)

    client = google.Client(ctx)
    cible = client.chemin(racine_drive, mois)
    deposes = []
    for f in fichiers:
        r = client.televerser(f, cible)
        deposes.append(FichierArchive(nom=r.get("name", f.name),
                                      octets=f.stat().st_size,
                                      remplace=bool(r.get("remplace"))))
    return Archivage(mois=mois, racine_drive=racine_drive, compte=client.compte,
                     fichiers=deposes)


# ------------------------------------------------------------- les documents

# ------------------------------------------------ les documents aux salaries
def envoyer_documents(ctx: Contexte, mois: str, *,
                      preuve: Optional[Preuve] = None,
                      qui: str = "?") -> dict:
    """Envoie a chaque salarie ses documents du mois. Irreversible.

    `envoi.py` a deja sa page de relecture locale, et `preparer_envoi` /
    `confirmer_et_envoyer` l'orchestrent pour la ligne de commande. On ne la
    double pas : cette operation-ci est le chemin de l'INTERFACE, qui a deja
    son ecran et n'a pas besoin d'une seconde page. Les deux appellent
    `envoi.envoyer`, et c'est lui qui envoie.

    Un courriel n'engage pas l'employeur comme une declaration -- personne ne
    preleve rien -- mais il part chez quelqu'un et ne revient pas. D'ou la
    meme preuve : on ne veut pas qu'un onglet oublie envoie un bulletin d'un
    clic malencontreux.
    """
    from . import envoi, journal

    prepare = preparer_envoi(ctx, ctx.racine / "paies" / ("%s.json" % mois))
    _verifier_preuve(ctx, preuve, mois, journal.DOCUMENTS)
    try:
        partis = envoi.envoyer(prepare.messages, prepare.expediteur,
                               prepare.client)
    except Exception as e:                                     # noqa: BLE001
        journal.noter(ctx, journal.DOCUMENTS, mois=mois, qui=qui,
                      accepte=False, destinataire=prepare.expediteur,
                      reponse=str(e)[:600])
        raise
    ligne = journal.noter(
        ctx, journal.DOCUMENTS, mois=mois, qui=qui,
        destinataire=", ".join(partis),
        reponse="%d message(s) envoye(s)" % len(partis),
        detail={"salaries": [{"cle": m.cle, "nom": m.nom,
                              "pieces": [p.name for p in m.pieces]}
                             for m in prepare.messages],
                "expediteur": prepare.expediteur})
    return {"partis": partis, "messages": len(prepare.messages),
            "expediteur": prepare.expediteur,
            "avertissements": prepare.avertissements, "ligne": ligne}


def documents_prets(ctx: Contexte, mois: str) -> dict:
    """Peut-on envoyer les documents du mois ? Le moteur repond, et dit pourquoi.

    Le bouton est << envoyer >>, directement, et c'est le moteur qui dit s'il
    peut -- pas l'ecran. Trois conditions, dans cet ordre :
    le mois est produit (les pieces existent), la DSN est partie et passee,
    l'AER de France Travail est revenue. Et une quatrieme pour ENVOYER, qui
    n'empeche pas de produire : un compte Google lie.

    Rend {"pret", "empechements": [...], "google_lie", "produit", "dossier"}.
    """
    from . import google, journal

    dossier = ctx.racine / "sorties" / mois / "envoi"
    # << Produit >> = les bulletins individuels sont la. Le dossier peut
    # contenir des contrats ou une AER sans que le mois soit ecrit.
    produit = dossier.exists() and any(dossier.glob("Bulletin_*.pdf"))
    empechements = []
    if not produit:
        empechements.append("Les documents du mois ne sont pas encore ecrits.")
    e = journal.etat_dsn_du_mois(ctx, mois)
    if not e:
        empechements.append("La DSN du mois n'est pas deposee.")
    elif e.get("refusee"):
        empechements.append("La DSN du mois a ete REFUSEE : a corriger et a redeposer.")
    elif not e.get("passee"):
        empechements.append("La DSN est deposee (%s), son bilan n'est pas encore arrive."
                            % quand_lisible(e.get("quand")))
    elif not e.get("aer_recue"):
        empechements.append("L'attestation employeur (AER) de France Travail n'est pas "
                            "encore revenue -- elle suit la DSN de quelques heures ; "
                            "l'ouverture du logiciel la releve.")
    return {"pret": not empechements, "empechements": empechements,
            "google_lie": bool(google.compte_autorise(ctx)),
            "produit": produit, "dossier": str(dossier if produit else dossier.parent)}


def documents_du_mois(ctx: Contexte, mois: str, quoi: Optional[str] = None) -> list:
    """Les fichiers du mois a ouvrir ou a remettre a la main, par salarie.

    `quoi` : << contrats >> (les contrats un a un), << documents >> (bulletins,
    certificats, AER), ou rien pour tout. Chaque entree : {"nom", "octets",
    "salarie"} -- le nom nu, que la route /fichier du serveur sait servir.
    Rien n'est envoye : on regarde ce qui est ecrit.
    """
    base = ctx.racine / "sorties" / mois
    envoi = base / "envoi"
    prefixes = {"contrats": ("Contrat_", "Contrats_"),
                "documents": ("Bulletin_", "CertificatCS_", "AER_")}.get(quoi)
    out = []
    for d in (envoi, base):
        if not d.exists():
            continue
        for f in sorted(d.glob("*.pdf")):
            if prefixes and not f.name.startswith(prefixes):
                continue
            if d is base and quoi:
                continue                  # les fichiers groupes du mois : pas ici
            morceaux = f.stem.split("_")
            out.append({"nom": f.name, "octets": f.stat().st_size,
                        "salarie": morceaux[1] if len(morceaux) > 2 else ""})
    return out


def apercu_envoi(ctx: Contexte, mois: str) -> dict:
    """Ce que chaque salarie recevrait, sans rien envoyer.

    Ce que l'ecran doit montrer AVANT : qui, a quelle adresse, avec quelles
    pieces -- et si l'on PEUT envoyer (`documents_prets`). Sans compte
    Google, on montre quand meme : la boite propose alors les documents a
    telecharger, et l'envoi est grise avec son avertissement.
    """
    from . import envoi, journal

    prets = documents_prets(ctx, mois)
    s = charger(ctx, ctx.racine / "paies" / ("%s.json" % mois))
    dossier = ctx.racine / "sorties" / mois / "envoi"
    messages = envoi.preparer(s.paies, ctx.entreprise, mois, dossier) if prets["produit"] else []
    expediteur, avertissements = "", []
    if prets["google_lie"]:
        try:
            prepare = preparer_envoi(ctx, ctx.racine / "paies" / ("%s.json" % mois))
            expediteur, avertissements = prepare.expediteur, prepare.avertissements
        except (SortieAbsente, GoogleNonAutorise):
            pass
    return {
        "mois": mois,
        "expediteur": expediteur,
        "avertissements": avertissements,
        "messages": [{"cle": m.cle, "nom": m.nom,
                      "destinataire": m.destinataire, "sujet": m.sujet,
                      "pieces": [p.name for p in m.pieces],
                      "octets": m.taille()}
                     for m in messages],
        "deja": journal.etat_du_mois(ctx, mois).get(journal.DOCUMENTS),
        "seance": seance(ctx),
        **prets,
    }


# ------------------------------------------------- le contrat a faire signer
SUJET_SIGNATURE = "Contrat d'engagement {spectacle} - {mois} {annee}"
SUJET_SIGNATURE_PLURIEL = "Contrats d'engagement - {mois} {annee}"

# Le code de signature : SIG- puis six signes tires au hasard, sans 0/O ni
# 1/I/L, pour qu'il se relise sans hesiter s'il faut le recopier a la main.
ALPHABET_CODE = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
FORME_CODE = re.compile(r"SIG-[%s]{6}" % ALPHABET_CODE)


def code_signature() -> str:
    return "SIG-" + "".join(secrets.choice(ALPHABET_CODE) for _ in range(6))


# {contrats} : une ligne par contrat quand il y en a plusieurs -- << ton
# contrat ... du X au Y >> au singulier, sinon la liste.
#
# UN PARAGRAPHE = UNE LIGNE, si longue soit-elle. Un courriel en texte se
# plie a la largeur de l'ecran qui le lit ; un retour force a 72 colonnes y
# fait des lignes hachees -- « un scan (a la ligne) ou une photo », pas tres
# pro (Leandre, 15/09/2026). Seuls les retours voulus sont ecrits.
CORPS_SIGNATURE = """Bonjour {prenom},

{contrats}

Pour {le_signer}, un clic suffit : appuie sur le bouton « Je signe » de ce message, puis envoie la réponse qui s'ouvre, sans la modifier. Si ta messagerie n'affiche pas le bouton, réponds simplement à ce message en écrivant « Je signe » suivi de ce code : {code}

Tu recevras aussitôt ton contrat signé des deux parties, à conserver. Le contrat doit être signé avant le début du travail.

Si quelque chose ne correspond pas à ce qui était convenu, dis-le avant de signer plutôt qu'après : c'est plus simple à corriger.

Bien à toi,
{signataire}
{raison_sociale}
"""

# La meme lettre en HTML : le texte, et le bouton. Styles en ligne, comme
# l'exigent les messageries ; rien de charge d'ailleurs. PAS DE LARGEUR
# MAXIMALE : une colonne de 600 px pliait les lignes au milieu d'une fenetre
# plus large, et ca se lisait comme des retours forces (15/09/2026).
HTML_SIGNATURE = """<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.5;color:#2C3E50">
<p>Bonjour {prenom},</p>
<p>{contrats}</p>
<p>Pour {le_signer}, un clic suffit : appuie sur le bouton, puis envoie la réponse qui s'ouvre, sans la modifier.</p>
<p style="margin:26px 0">
<a href="{mailto}" style="display:inline-block;background:#B22222;color:#ffffff;padding:14px 26px;border-radius:6px;text-decoration:none;font-weight:bold;font-size:16px">Je signe</a>
</p>
<p style="font-size:13px;color:#555">Si le bouton ne fait rien, réponds simplement à ce message en écrivant « Je signe » suivi de ce code : <b>{code}</b></p>
<p>Tu recevras aussitôt ton contrat signé des deux parties, à conserver. Le contrat doit être signé avant le début du travail.</p>
<p>Si quelque chose ne correspond pas à ce qui était convenu, dis-le avant de signer plutôt qu'après : c'est plus simple à corriger.</p>
<p>Bien à toi,<br>{signataire}<br>{raison_sociale}</p>
</div>
"""

# La reponse que le bouton prepare. Son objet est « Re: » + celui du
# message recu : « ca serait mieux en reponse au mail » (Leandre,
# 15/09/2026) -- un lien mailto: ne sait pas faire une vraie reponse
# (pas d'en-tete In-Reply-To), mais Gmail range dans la meme conversation
# un message de meme objet, entre les memes personnes, dans la semaine.
# Le CODE est dans le corps, en haut ; la releve ne lit que ce qui precede
# la citation du message d'origine, qui porte aussi le code.
CORPS_REPONSE = """Je soussigné(e) {nom} déclare avoir lu et accepter {quoi}.

Code de signature : {code}
"""

# Ce qui repart, contresigne, des que la signature est relevee.
SUJET_CONTRESIGNE = "Ton contrat signé - {spectacle}"
SUJET_CONTRESIGNE_PLURIEL = "Tes contrats signés - {mois} {annee}"
CORPS_CONTRESIGNE = """Bonjour {prenom},

Nous avons bien reçu ta signature le {quand}. Ci-joint {quoi}, signé des deux parties : c'est l'exemplaire à conserver.

Bien à toi,
{signataire}
{raison_sociale}
"""


def _mailto(adresse: str, objet: str, corps: str) -> str:
    """Un lien mailto: -- RFC 6068 : les champs sont encodes comme une URL,
    et les sauts de ligne du corps s'ecrivent %0D%0A."""
    return "mailto:%s?%s" % (
        urllib.parse.quote(adresse, safe="@"),
        urllib.parse.urlencode({"subject": objet, "body": corps},
                               quote_via=urllib.parse.quote))


def apercu_signature(ctx: Contexte, mois: str) -> dict:
    """Les contrats du mois et l'etat de leur demande de signature."""
    from . import journal

    s = charger(ctx, ctx.racine / "paies" / ("%s.json" % mois))
    recus = journal.contrats_recus(ctx)
    recus_par = journal.contrats_recus_comment(ctx)
    demandes = {}
    for l in journal.lire(ctx, journal.SIGNATURE, mois):
        if not l.get("accepte"):
            continue
        for c in l.get("detail", {}).get("contrats", []):
            demandes[(c.get("salarie"), c.get("debut"))] = l.get("quand")
    lignes = []
    for p in s.paies:
        cle, debut = p.salarie["_cle"], str(p.engagement.debut)
        lignes.append({
            "salarie": cle,
            "nom": "%s %s" % (p.salarie["nom"],
                              p.salarie.get("prenom_affichage")
                              or p.salarie["prenom"]),
            "destinataire": p.salarie.get("email", ""),
            "spectacle": p.spectacle["titre"],
            "debut": debut, "fin": str(p.engagement.fin),
            "numero": p.engagement.numero,
            "demande_le": demandes.get((cle, debut)),
            # Revenu signe, dit par un humain d'un clic (contrat_recu) : un
            # contrat recu ne se redemande pas, et l'ecran ne doit plus le
            # montrer << demande >>.
            "recu_le": recus.get((cle, debut)),
            "recu_par": recus_par.get((cle, debut)),
        })
    from . import google
    dossier = ctx.racine / "sorties" / mois
    return {"mois": mois, "contrats": lignes, "seance": seance(ctx),
            # Sans compte Google, on ne peut pas envoyer -- mais on peut
            # ecrire les contrats et les donner a la main. La boite le dit.
            "google_lie": bool(google.compte_autorise(ctx)),
            # Sans la permission de lecture (jeton d'avant le 15/09/2026),
            # les contrats partent, mais les signatures ne reviennent pas
            # toutes seules : l'ecran dit de reautoriser.
            "lecture_autorisee": google.lecture_autorisee(ctx),
            "attendues": len(journal.signatures_attendues(ctx, mois)),
            "dossier": str(dossier),
            "produit": bool(dossier.exists() and (
                any(dossier.glob("Contrats_*.pdf"))
                or any((dossier / "envoi").glob("Contrat_*.pdf")) if (dossier / "envoi").exists()
                else any(dossier.glob("Contrats_*.pdf"))))}


def demander_signature(ctx: Contexte, mois: str, *,
                       salaries: Optional[list] = None,
                       contrats_voulus: Optional[list] = None,
                       preuve: Optional[Preuve] = None,
                       qui: str = "?", client=None) -> dict:
    """Envoie a chaque salarie son contrat, avec le bouton « Je signe ».

    Pas de service tiers : le bouton est un lien mailto: vers notre propre
    compte, et la reponse porte un code unique dans son objet (voir
    l'en-tete). Le JOURNAL garde la demande ET le code, par contrat : c'est
    par lui que `relever_signatures` reconnaitra la reponse.

    UN COURRIEL PAR SALARIE, UN PDF PAR COURRIEL, tous ses contrats dedans
    (une page par contrat) -- << quand c'est groupe, un seul pdf avec les
    deux contrats dedans >>. Ecrit pour l'occasion
    dans `sorties/<mois>/envoi/` avec les MEMES numeros que le fichier
    groupe : un document signe qui porterait un autre numero que celui qui
    est archive ne se rapprocherait de rien.

    LA SELECTION EST PAR CONTRAT, pas par salarie. `contrats_voulus` :
    [{"salarie", "debut"}] -- ce que l'ecran a coche. Le 12/09/2026, la
    selection remontait par salarie (`salaries`) et le moteur envoyait TOUS
    les contrats du mois de ces salaries-la, y compris ceux du 6 qu'on
    n'avait pas coches et qui etaient deja partis. `salaries` reste accepte
    (ligne de commande : tous les contrats de ces salaries).
    """
    from . import contrat, envoi, google, journal

    s = charger(ctx, ctx.racine / "paies" / ("%s.json" % mois))
    dossier = ctx.racine / "sorties" / s.mois / "envoi"
    dossier.mkdir(parents=True, exist_ok=True)
    etiq = envoi.etiquette(s.mois)

    voulus = set(salaries) if salaries else None
    # `client` : celui des tests, qui n'envoie rien. Sinon le vrai.
    client = client or google.Client(ctx)
    if not client.compte:
        raise GoogleNonAutorise()

    _verifier_preuve(ctx, preuve, mois, journal.SIGNATURE)

    an, mo = int(s.mois[:4]), int(s.mois[5:7])
    # Licence resolue sur le mois, comme dans `produire` : la fiche
    # entreprise porte une liste datee, et un contrat ne s'imprime pas avec
    # une liste a la place du numero (contrat.marqueurs le refuse).
    ent = dict(ctx.entreprise,
               licence_spectacle=ctx.licence("%d-%02d-01" % (an, mo)))
    cibles = ({(c["salarie"], str(c["debut"])) for c in contrats_voulus}
              if contrats_voulus else None)
    # Par salarie, dans l'ordre du mois.
    par_salarie = {}
    for p in s.paies:
        cle = p.salarie["_cle"]
        if voulus and cle not in voulus:
            continue
        if cibles is not None and (cle, str(p.engagement.debut)) not in cibles:
            continue
        par_salarie.setdefault(cle, []).append(p)
    if cibles is not None:
        trouves = {(p.salarie["_cle"], str(p.engagement.debut))
                   for ps in par_salarie.values() for p in ps}
        if cibles - trouves:
            raise ErreurOperation(
                "Ces contrats ne sont pas dans la saisie de %s : %s. Rien "
                "n'est parti." % (mois, ", ".join("%s au %s" % x
                                                  for x in sorted(cibles - trouves))))

    messages, contrats = [], []
    # Le prenom, en minuscules accentuees, comme le courriel des documents :
    # << KRASNOPOLSKY >> en bas d'un message qui tutoie, ce n'est pas une
    # signature.
    sg = ctx.entreprise["signataire"]
    signataire = sg.get("prenom_affichage") or sg.get("prenom", "").capitalize()
    raison = ctx.entreprise.get("nom_affichage") or ctx.entreprise["raison_sociale"]
    expediteur = client.compte.lower()
    for cle, ps in par_salarie.items():
        sal = ps[0].salarie
        adresse = (sal.get("email") or "").strip().lower()
        if not adresse:
            raise ErreurOperation(
                "%s n'a pas de courriel dans sa fiche : son contrat ne peut "
                "pas partir." % cle)
        code = code_signature()
        numeros = [p.engagement.numero or "sans-numero" for p in ps]
        pdf = contrat.ecrire(
            ps, ent,
            dossier / ("Contrat%s_%s_%s_%s.pdf" % ("s" if len(ps) > 1 else "",
                                                   cle, "+".join(numeros), etiq)))
        spectacles = list(dict.fromkeys(p.spectacle["titre"] for p in ps))
        nom_complet = "%s %s" % (sal.get("prenom_affichage") or sal["prenom"],
                                 sal.get("nom_affichage") or sal["nom"])
        if len(ps) == 1:
            p = ps[0]
            sujet = SUJET_SIGNATURE.format(spectacle=p.spectacle["titre"],
                                           mois=envoi.MOIS_ACCENTS[mo - 1], annee=an)
            liste = ("Tu trouveras ci-joint ton contrat d'engagement pour %s, du %s au %s."
                     % (p.spectacle["titre"], jj_mm_aaaa(p.engagement.debut),
                        jj_mm_aaaa(p.engagement.fin)))
            le_signer = "le signer"
            quoi = "le contrat d'engagement n° %s pour %s, du %s au %s" % (
                p.engagement.numero or "(sans numéro)", p.spectacle["titre"],
                jj_mm_aaaa(p.engagement.debut), jj_mm_aaaa(p.engagement.fin))
        else:
            sujet = (SUJET_SIGNATURE.format(spectacle=spectacles[0],
                                            mois=envoi.MOIS_ACCENTS[mo - 1], annee=an)
                     if len(spectacles) == 1 else
                     SUJET_SIGNATURE_PLURIEL.format(mois=envoi.MOIS_ACCENTS[mo - 1],
                                                    annee=an))
            liste = ("Tu trouveras ci-joint tes %d contrats d'engagement, dans un seul "
                     "document (un par page) :\n" % len(ps)
                     + "\n".join("  - %s, du %s au %s" % (
                         p.spectacle["titre"], jj_mm_aaaa(p.engagement.debut),
                         jj_mm_aaaa(p.engagement.fin)) for p in ps))
            le_signer = "les signer"
            quoi = "les contrats d'engagement suivants : " + " ; ".join(
                "n° %s pour %s, du %s au %s" % (
                    p.engagement.numero or "(sans numéro)", p.spectacle["titre"],
                    jj_mm_aaaa(p.engagement.debut), jj_mm_aaaa(p.engagement.fin))
                for p in ps)
        mailto = _mailto(expediteur, "Re: " + sujet,
                         CORPS_REPONSE.format(nom=nom_complet, quoi=quoi, code=code))
        champs = dict(prenom=sal.get("prenom_affichage") or sal["prenom"],
                      signataire=signataire, raison_sociale=raison,
                      le_signer=le_signer, expediteur=expediteur, code=code)
        messages.append(envoi.Message(
            cle=cle, nom=sal["nom"], destinataire=adresse, sujet=sujet,
            corps=CORPS_SIGNATURE.format(contrats=liste, **champs),
            html=HTML_SIGNATURE.format(
                contrats=_html.escape(liste).replace("\n", "<br>"),
                mailto=_html.escape(mailto),
                **{k: _html.escape(str(v)) for k, v in champs.items()}),
            pieces=[pdf]))
        for p in ps:
            contrats.append({"salarie": cle, "debut": str(p.engagement.debut),
                             "fin": str(p.engagement.fin),
                             "numero": p.engagement.numero, "fichier": pdf.name,
                             "spectacle": p.spectacle["titre"],
                             # Ce qu'il faut pour reconnaitre la reponse : le
                             # code, et l'adresse dont elle doit venir.
                             "code": code, "adresse": adresse})

    if not messages:
        raise ErreurOperation("Aucun contrat a envoyer pour %s." % mois)

    identifiants = []
    try:
        partis = envoi.envoyer(messages, expediteur, client, identifiants)
    except Exception as e:                                     # noqa: BLE001
        journal.noter(ctx, journal.SIGNATURE, mois=mois, qui=qui,
                      accepte=False, destinataire=expediteur,
                      reponse=str(e)[:600], detail={"contrats": contrats})
        raise
    # L'identifiant Gmail de chaque message parti, sur chacun de ses
    # contrats : la releve l'ecarte de ses candidats (voir envoi.envoyer).
    envoyes = {m.cle: i for m, i in zip(messages, identifiants)}
    for c in contrats:
        c["message"] = envoyes.get(c["salarie"], "")
    ligne = journal.noter(
        ctx, journal.SIGNATURE, mois=mois, qui=qui,
        destinataire=", ".join(partis),
        reponse="%d contrat(s) envoye(s) a la signature" % len(partis),
        detail={"contrats": contrats, "expediteur": expediteur})
    return {"partis": partis, "contrats": contrats, "expediteur": expediteur,
            "ligne": ligne}


# -------------------------------------------------- le contrat revenu signe
def contrat_recu(ctx: Contexte, mois: str, salarie: str, debut: str, *,
                 recu: bool = True, qui: str = "?",
                 courriel: Optional[dict] = None) -> dict:
    """Note qu'un contrat signe est revenu -- ou retire cette note.

    Deux facons de le savoir. Un humain qui range un contrat signe a la main
    le dit d'un clic -- c'est la demande du 12/09/2026 : << cliquer pour dire
    contrat signe recu, pour pouvoir suivre -- envoye on passe a orange,
    signe on passe au vert >>. Ou la releve des signatures (15/09/2026), qui
    a trouve la reponse « Je signe » du salarie dans Gmail : elle passe
    alors `courriel` -- code, adresse, date, identifiant du message, fichier
    archive -- et la ligne est datee de la SIGNATURE, pas du releve, avec
    le message pour origine (journal.noter : une date choisie nomme sa piece).

    C'est une ligne de journal, pas un etat de la saisie : elle date un fait
    du monde, comme un depot, et elle survit a une renumerotation ou a une
    reedition du contrat -- la maille est (salarie, premier jour), comme pour
    la demande de signature. `recu=False` ecrit une ligne de retrait : on ne
    supprime rien du journal, on dit qu'on s'etait trompe. Rien ne part,
    aucun compteur ne bouge, aucune preuve n'est demandee.

    Refuse une paie absente de la saisie enregistree : noter un contrat pour
    une paie qui n'existe pas serait une ligne qui ne se rattache a rien.
    """
    from . import journal

    s = charger(ctx, ctx.racine / "paies" / ("%s.json" % mois))
    p = next((x for x in s.paies
              if x.salarie["_cle"] == salarie and str(x.engagement.debut) == debut),
             None)
    if p is None:
        raise ErreurOperation(
            "Aucune paie de %s commencant le %s dans la saisie enregistree de "
            "%s." % (salarie, debut, mois))
    detail = {"salarie": salarie, "debut": debut, "recu": bool(recu),
              "numero": p.engagement.numero,
              "nom": "%s %s" % (p.salarie["nom"],
                                p.salarie.get("prenom_affichage")
                                or p.salarie["prenom"])}
    if courriel:
        detail.update(origine="courriel", **courriel)
        reponse = "contrat signe par courriel (%s, %s)" % (
            courriel.get("code", "?"), courriel.get("adresse", "?"))
        date = dict(quand=courriel.get("quand"),
                    origine="courriel Gmail %s" % courriel.get("message", "?"))
    else:
        reponse = ("contrat signe recu, range a la main" if recu
                   else "mention retiree : le contrat signe n'est pas la")
        date = {}
    ligne = journal.noter(ctx, journal.CONTRAT_RECU, mois=mois, qui=qui,
                          reponse=reponse, detail=detail, **date)
    return {"salarie": salarie, "debut": debut,
            "recu": ligne["quand"] if recu else None, "ligne": ligne}


# ------------------------------------------------ la releve des signatures
@dataclass
class SignatureRecue:
    mois: str
    salarie: str
    nom: str
    code: str
    adresse: str
    quand: str                      # ISO, la date du message
    contrats: list                  # [{salarie, debut, fin, numero, spectacle}]
    fichier_signe: str = ""
    preuve: str = ""
    renvoye: bool = False


@dataclass
class ReleveSignatures:
    quand: str
    attendues: int = 0
    recues: list = field(default_factory=list)      # [SignatureRecue]
    incidents: list = field(default_factory=list)

    def resume(self) -> str:
        if not self.attendues and not self.recues:
            return ""
        if not self.recues:
            return "%d signature(s) attendue(s), aucune arrivée" % self.attendues
        return "%d signature(s) reçue(s) : %s" % (
            len(self.recues), ", ".join(r.nom for r in self.recues))


def _adresse_de(message) -> str:
    return (email.utils.parseaddr(message.get("From", ""))[1] or "").strip().lower()


# Ou commence la citation du message d'origine, selon les messageries. Tout
# ce qui suit n'a pas ete ecrit par celui qui repond.
_DEBUT_CITATION = re.compile(
    r"^(>|Le .{3,120} a écrit ?:|On .{3,120} wrote:|-{3,}.*-{3,}$|De ?:|From:|"
    r"________________)", re.MULTILINE)


def _texte_propre(message) -> str:
    """Ce que l'auteur de la reponse a ecrit lui-meme, citation exclue.

    On prend la partie texte ; a defaut, le HTML debarrasse de ses balises
    (et de sa citation Gmail). Puis on coupe au premier signe de citation.
    """
    texte, html_ = "", ""
    for part in message.walk():
        if part.get_content_maintype() != "text" or part.get_filename():
            continue
        try:
            contenu = part.get_content()
        except (KeyError, LookupError, UnicodeDecodeError):
            continue
        if part.get_content_subtype() == "plain" and not texte:
            texte = contenu
        elif part.get_content_subtype() == "html" and not html_:
            html_ = contenu
    if not texte and html_:
        html_ = re.split(r"<blockquote|class=\"gmail_quote", html_, 1)[0]
        texte = _html.unescape(re.sub(r"<[^>]+>", " ", html_))
    coupe = _DEBUT_CITATION.search(texte)
    return texte[:coupe.start()] if coupe else texte


def _date_de(message) -> str:
    """La date du message, en heure locale, ISO a la seconde -- le format du
    journal. Sans en-tete Date lisible, l'heure du releve."""
    import datetime as _dt
    try:
        d = email.utils.parsedate_to_datetime(message.get("Date", ""))
        if d.tzinfo is not None:
            d = d.astimezone()
        return d.replace(tzinfo=None).isoformat(timespec="seconds")
    except (TypeError, ValueError):
        return _dt.datetime.now().isoformat(timespec="seconds")


def relever_signatures(ctx: Contexte, *, client=None, mois: Optional[str] = None,
                       qui: str = "veille") -> ReleveSignatures:
    """Cherche dans Gmail les reponses « Je signe » encore attendues, et fait
    tout ce qui suit : journal, archive de la preuve, contrat contresigne,
    renvoi au salarie.

    UNE RECHERCHE PAR CODE ATTENDU. Gmail cherche le code partout (objet,
    corps, pieces jointes) ; c'est nous qui trions ensuite, et strictement :

    * notre propre envoi est ecarte par son identifiant (note au journal
      avec la demande) -- pas par son expediteur, parce qu'en test le
      salarie, c'est nous ;
    * le code doit figurer dans la partie ECRITE de la reponse, avant la
      citation du message d'origine (`_texte_propre`) : une reponse « je ne
      suis pas d'accord » cite le message recu, code compris, et ne doit
      pas valoir signature ;
    * elle doit venir de l'adresse a laquelle le contrat a ete envoye : une
      reponse venue d'ailleurs est signalee, pas retenue -- l'identification
      du signataire tient a son adresse, et un humain peut toujours cliquer
      « recu » s'il sait a quoi s'en tenir.

    NE LEVE PAS pour un compte non autorise ou une permission manquante :
    c'est un travail de fond, il dit ce qui l'empeche dans `incidents` et
    rend la main (meme regle que `ouverture`).
    """
    import datetime as _dt
    from . import contrat, envoi, google, journal

    r = ReleveSignatures(quand=_dt.datetime.now().isoformat(timespec="seconds"))
    attendues = journal.signatures_attendues(ctx, mois)
    r.attendues = len(attendues)
    if not attendues:
        return r
    if client is None:
        if not google.compte_autorise(ctx):
            r.incidents.append("Compte Google non autorise : les signatures ne "
                               "peuvent pas etre relevees.")
            return r
        if not google.lecture_autorisee(ctx):
            r.incidents.append(
                "Le compte Google n'a pas la permission de lire la boite : "
                "les signatures ne reviennent pas toutes seules. "
                "`python -m moteur google autoriser` pour la redemander.")
            return r
        client = google.Client(ctx)

    sg = ctx.entreprise["signataire"]
    signataire = sg.get("prenom_affichage") or sg.get("prenom", "").capitalize()
    raison = ctx.entreprise.get("nom_affichage") or ctx.entreprise["raison_sociale"]
    expediteur = (client.compte or "").lower()

    for a in attendues:
        code = a["code"]
        try:
            identifiants = client.rechercher('"%s"' % code, maximum=10)
        except Exception as e:                                    # noqa: BLE001
            r.incidents.append("Recherche de %s : %s" % (code, e))
            # Une erreur de transport ne se corrige pas en essayant le code
            # suivant, et repeter le meme message dix fois n'aide personne.
            break
        retenu = None
        for ident in identifiants:
            if ident in a["envoyes"]:
                continue                # notre propre demande
            try:
                brut = client.message_brut(ident)
            except Exception as e:                                # noqa: BLE001
                r.incidents.append("Lecture du message %s : %s" % (ident, e))
                continue
            m = email.message_from_bytes(brut, policy=email.policy.default)
            texte = _texte_propre(m)
            if code not in texte.upper():
                continue                # le code n'est que dans la citation
            if "bouton « Je signe »" in texte:
                continue                # notre demande elle-meme (envoyee
                                        # avant que son identifiant soit note)
            de = _adresse_de(m)
            if de == expediteur and de != a["adresse"]:
                continue                # un autre de nos envois (le contresigne)
            if de != a["adresse"]:
                r.incidents.append(
                    "%s : une reponse portant %s vient de %s et non de %s ; "
                    "elle n'est pas retenue." % (a["nom"], code, de, a["adresse"]))
                continue
            retenu = (ident, brut, m, de)
            break
        if not retenu:
            continue
        ident, brut, m, de = retenu
        quand = _date_de(m)
        dossier = ctx.racine / "sorties" / a["mois"] / "envoi"
        dossier.mkdir(parents=True, exist_ok=True)
        preuve = dossier / ("Signature_%s_%s.eml" % (a["salarie"], code))
        preuve.write_bytes(brut)
        envoye = dossier / a["fichier"]
        signe = envoye.with_name(envoye.stem + "_signe.pdf")
        fichier_signe = ""
        if envoye.exists():
            try:
                contrat.contresigner(
                    envoye, signe, nom=a["nom"],
                    quand=quand_lisible(quand), adresse=de, code=code)
                fichier_signe = signe.name
            except Exception as e:                                # noqa: BLE001
                r.incidents.append("%s : contrat contresigne impossible (%s)."
                                   % (a["nom"], e))
        else:
            r.incidents.append("%s : le contrat envoye (%s) n'est plus dans %s ; "
                               "la signature est notee, sans exemplaire contresigne."
                               % (a["nom"], a["fichier"], dossier))
        recue = SignatureRecue(
            mois=a["mois"], salarie=a["salarie"], nom=a["nom"], code=code,
            adresse=de, quand=quand, contrats=a["contrats"],
            fichier_signe=fichier_signe, preuve=preuve.name)
        # LE JOURNAL D'ABORD : une fois la ligne ecrite, la releve suivante
        # n'attend plus ce code, et le renvoi ne se fera pas deux fois.
        for c in a["contrats"]:
            contrat_recu(ctx, a["mois"], c["salarie"], c["debut"], qui=qui,
                         courriel={"code": code, "adresse": de, "quand": quand,
                                   "message": ident, "preuve": preuve.name,
                                   "fichier_signe": fichier_signe})
        r.recues.append(recue)
        if not fichier_signe:
            continue
        an, mo = int(a["mois"][:4]), int(a["mois"][5:7])
        nb = len(a["contrats"])
        spectacles = list(dict.fromkeys(c["spectacle"] for c in a["contrats"]))
        sujet = (SUJET_CONTRESIGNE.format(spectacle=spectacles[0])
                 if nb == 1 or len(spectacles) == 1 else
                 SUJET_CONTRESIGNE_PLURIEL.format(mois=envoi.MOIS_ACCENTS[mo - 1],
                                                  annee=an))
        message = envoi.Message(
            cle=a["salarie"], nom=a["nom"], destinataire=de, sujet=sujet,
            corps=CORPS_CONTRESIGNE.format(
                prenom=a["prenom"], quand=quand_lisible(quand),
                quoi=("ton contrat d'engagement" if nb == 1
                      else "tes %d contrats d'engagement (un par page)" % nb),
                signataire=signataire, raison_sociale=raison),
            pieces=[signe])
        try:
            envoi.envoyer([message], expediteur, client)
            recue.renvoye = True
            journal.noter(
                ctx, journal.CONTRESIGNE, mois=a["mois"], qui=qui,
                destinataire=de, fichier=signe,
                reponse="contrat contresigne renvoye au salarie",
                detail={"salarie": a["salarie"], "nom": a["nom"], "code": code,
                        "contrats": a["contrats"]})
        except Exception as e:                                    # noqa: BLE001
            r.incidents.append("%s : le contrat contresigne n'a pas pu etre "
                               "renvoye (%s). Il est dans %s." % (a["nom"], e, signe))
    return r
