"""Les fiches de configuration : lire, verifier, enregistrer, dater.

Entreprise, salaries, spectacles : les fichiers dont dependent toutes les
declarations. Une erreur bloque, un avertissement passe ; l'ancien fichier
est copie avant l'ecriture ; et **un champ declare ne s'ecrase pas, il se
date** -- l'ancienne valeur descend dans `historique` avec le jour jusqu'auquel
elle valait, pour que le rejeu du passe reste lisible.
"""
from __future__ import annotations

import datetime as _dt
import json
from dataclasses import dataclass, field
from typing import Optional

from .contexte import Contexte
from .operations_socle import ErreurOperation, _lire_json, _sauver_avant
from .util import d


@dataclass
class Fiche:
    entreprise: dict
    salaries: dict
    spectacles: dict
    compteurs: dict
    # Ce qui a ete mis de cote. Compte, et non liste, quand on ne l'a pas
    # demande : l'ecran doit dire que ces fiches existent -- sinon on les
    # croit perdues -- sans les remettre dans le courant.
    salaries_archives: dict = field(default_factory=dict)
    spectacles_archives: dict = field(default_factory=dict)


# --------------------------------------------------------- la configuration
@dataclass
class FicheVerifiee:
    nom: str                 # "entreprise" | "salarie" | "spectacle"
    cle: Optional[str]       # la cle dans le fichier (None pour l'entreprise)
    donnees: dict
    anomalies: list
    # Ce que le programme a fabrique tout seul : {cle: (avant, apres)}.
    # Rendu au front pour qu'il puisse le montrer -- une derivation invisible
    # serait une correction silencieuse.
    derives: dict = field(default_factory=dict)

    @property
    def erreurs(self) -> list:
        return [a for a in self.anomalies if a["gravite"] == "erreur"]


FICHIERS_CONFIG = {"entreprise": "entreprise.json",
                   "salarie": "salaries.json",
                   "spectacle": "spectacles.json"}


def configuration(ctx: Contexte) -> dict:
    """Toute la configuration, verifiee. Ce que l'ecran de reglages affiche.

    Les anomalies sont rendues avec les donnees, pas a la demande : une fiche
    fautive doit se voir en arrivant, pas quand on pense a lancer un controle.
    """
    from . import champs

    entreprise = FicheVerifiee(
        "entreprise", None, ctx.entreprise,
        champs.verifier_fiche("entreprise", ctx.entreprise))
    salaries = [FicheVerifiee("salarie", k, v,
                              champs.verifier_fiche("salarie", v))
                for k, v in ctx.salaries.items()]
    spectacles = [FicheVerifiee("spectacle", k, v,
                                champs.verifier_fiche("spectacle", v))
                  for k, v in ctx.spectacles.items()]
    return {"entreprise": entreprise, "salaries": salaries,
            "spectacles": spectacles, "compteurs": ctx.compteurs()}


def verifier_fiche(nom: str, donnees: dict) -> list:
    """Les anomalies d'une fiche -- APRES derivation, sur une copie.

    L'ecran n'envoie pas les champs calcules : `adresse`, `commune` et
    `raison_sociale` ne se saisissent pas, ils se deduisent des formes
    lisibles. Verifier sans deriver les voyait donc vides et criait
    << obligatoire >> sur trois champs correctement remplis -- une fiche
    entreprise irreprochable s'affichait en rouge des qu'on y touchait
    (13/09/2026). C'est la meme regle que `changements_declares` : deriver
    d'abord, comparer -- ou ici verifier -- ensuite.

    Sur une COPIE : verifier ne doit rien changer a ce qu'on lui donne.
    """
    from . import champs
    donnees = dict(donnees)
    champs.deriver(nom, donnees)
    return champs.verifier_fiche(nom, donnees)


def garder_notes_internes(ancienne, neuve):
    """Rend `neuve`, augmentee des cles internes (`_...`) de `ancienne`.

    LES FICHES PORTENT DES NOTES QUE L'ECRAN NE VOIT PAS. `_note`,
    `_note_tel` : de la documentation ecrite a la main dans le JSON, qui dit
    pourquoi une valeur est ce qu'elle est. `sortie_json.brut` les retire de
    tout ce qui part vers un front -- a dessein, ce sont des commentaires,
    pas des donnees. Mais l'interface renvoie ensuite la structure telle
    qu'elle l'a recue : sans elles. Sans cette fusion, enregistrer une fiche
    depuis l'ecran RABOTE ses notes, et l'ecran annonce en prime deux
    << valeurs declarees qui changent >> alors que rien de declare n'a bouge
    (arrive le 13/09/2026 sur `signataire` et `banque`).

    Les listes se recollent par rang, et seulement a longueur egale : au-dela,
    on ne sait plus quel element correspond a quel autre, et rattacher une
    note au mauvais element serait pire que la perdre.
    """
    if isinstance(ancienne, dict) and isinstance(neuve, dict):
        out = dict(neuve)
        for k, v in ancienne.items():
            if k.startswith("_") and k not in out:
                out[k] = v
            elif k in out:
                out[k] = garder_notes_internes(v, out[k])
        return out
    if isinstance(ancienne, list) and isinstance(neuve, list)             and len(ancienne) == len(neuve):
        return [garder_notes_internes(a, n) for a, n in zip(ancienne, neuve)]
    return neuve


def changements_declares(ctx: Contexte, nom: str, cle: Optional[str],
                         donnees: dict) -> list:
    """Les champs DECLARES que cet enregistrement ferait changer.

    Rendu avant d'ecrire, pour que l'ecran puisse demander ce qu'il faut
    demander : a partir de quelle date la nouvelle valeur s'applique, et
    pourquoi. Chaque entree porte aussi ce que la valeur sortante a deja
    servi a declarer -- c'est cette information-la qui fait decider (§18.12),
    et pas l'annonce du changement, qui ne dit rien de ce qu'il coute.
    """
    from . import champs

    if nom not in FICHIERS_CONFIG:
        raise ErreurOperation("Fiche inconnue : %r" % nom)
    if nom == "entreprise":
        ancienne = ctx.entreprise
    else:
        magasin = ctx.salaries if nom == "salarie" else ctx.spectacles
        ancienne = magasin.get(cle, {})
    # LA DERIVATION D'ABORD, SUR UNE COPIE. Les champs declares qui se
    # calculent (`commune` depuis `commune_affichage`) ne sont pas dans ce que
    # l'ecran renvoie : ils ne se saisissent pas. Comparer avant de deriver
    # laisserait passer le seul cas qui compte -- on tape « Paris », la
    # machine ecrit `PARIS`, et ce qui part aux organismes change sans que
    # personne n'ait ete prevenu. Sur une COPIE, parce que ceci ne fait que
    # regarder : c'est `enregistrer_fiche` qui ecrit.
    donnees = garder_notes_internes(ancienne, dict(donnees))
    champs.deriver(nom, donnees, forcer=True)
    sortie = []
    for c in champs.FICHES[nom]:
        if not c.declare or c.cle not in donnees:
            continue
        avant, apres = ancienne.get(c.cle), donnees[c.cle]
        if avant in (None, "") or str(avant) == str(apres):
            continue
        sortie.append({"champ": c.cle, "libelle": c.libelle,
                       "avant": avant, "apres": apres,
                       "deja_declare": usages_declares(ctx, avant)})
    return sortie


def usages_declares(ctx: Contexte, valeur) -> dict:
    """Combien de DSN deja deposees portent cette valeur, et sur quelle periode.

    « Enregistrer declarera PARIS 12E » est une phrase juste qui n'aide
    personne a decider. « Cette valeur est deja partie 50 fois depuis janvier
    2021 » est la meme information avec son prix -- et l'identite est ce sur
    quoi France Travail et la DGFiP rapprochent un salarie.

    On cherche la valeur telle qu'une DSN l'ecrit (`,'PARIS 12'`), donc
    exactement : `PARIS 12` ne compte pas pour `PARIS 12E`. Les declarations
    lues sont celles qui sont REELLEMENT PARTIES -- l'export de CoolPaie et
    nos propres sorties.
    """
    jeton = ",'%s'" % valeur
    fichiers, mois = 0, []
    for dossier in (ctx.export / "DSN", ctx.racine / "sorties"):
        if not dossier.exists():
            continue
        for f in sorted(dossier.rglob("*.dsn")):
            try:
                texte = f.read_text(encoding="latin-1")
            except OSError:
                continue
            if jeton not in texte:
                continue
            fichiers += 1
            for l in texte.splitlines():
                if l.startswith("S20.G00.05.005,"):
                    mp = l.split(",", 1)[1].strip("'")
                    if len(mp) == 8:
                        mois.append("%s-%s" % (mp[4:8], mp[2:4]))
                    break
    return {"declarations": fichiers,
            "du": min(mois) if mois else None,
            "au": max(mois) if mois else None}


def enregistrer_fiche(ctx: Contexte, nom: str, cle: Optional[str],
                      donnees: dict, forcer: bool = False,
                      depuis: Optional[str] = None,
                      note: str = "") -> FicheVerifiee:
    """Ecrit une fiche de configuration, apres verification.

    Deux precautions, et elles ne sont pas de trop pour un fichier dont
    dependent toutes les declarations :

    - **une erreur bloque**, un avertissement passe. `forcer` lève le blocage,
      parce qu'une regle peut se tromper et que l'utilisateur en sait parfois
      plus qu'elle -- mais il faut le vouloir.
    - **l'ancien fichier est copie** avant l'ecriture. Ce n'est pas un
      versionnement, c'est un filet : la configuration est ce qui n'existe
      qu'ici, et un mauvais enregistrement ne doit pas etre definitif.

    **Un champ declare ne s'ecrase pas : il se date.** Une adresse change, un
    telephone change, une commune de naissance se corrige -- et les
    declarations deja parties portent l'ancienne valeur pour toujours.
    Remplacer sans garder la precedente rend le passe illisible : le rejeu de
    l'historique compare alors juillet a une fiche de septembre et crie a la
    regression sur un demenagement. L'ancienne valeur descend donc dans
    `historique`, avec la date jusqu'a laquelle elle valait.

    `depuis` est le jour ou la nouvelle valeur prend effet (par defaut
    aujourd'hui) : l'ancienne vaut jusqu'a la veille. Ce choix revient a
    l'humain -- si une declaration est partie ce matin avec l'ancienne
    valeur, la nouvelle ne vaut qu'a partir de demain.
    """
    from . import champs

    if nom not in FICHIERS_CONFIG:
        raise ErreurOperation("Fiche inconnue : %r" % nom)
    # Les notes internes que l'ecran n'a pas vues sont rendues a la fiche
    # AVANT tout le reste : sans cela on les ecrirait perdues.
    ancienne_fiche = (ctx.entreprise if nom == "entreprise"
                      else (ctx.salaries if nom == "salarie"
                            else ctx.spectacles).get(cle, {}))
    donnees = garder_notes_internes(ancienne_fiche, dict(donnees))
    changements = changements_declares(ctx, nom, cle, donnees)

    # L'humain a ecrit « Père Lahaille » ; c'est ici que `PERE LAHAILLE` se
    # fabrique. `forcer=True` : il vient de saisir, donc il veut le resultat
    # de ce qu'il a saisi -- c'est la seule occasion ou la derivation a le
    # droit d'ecraser une forme declaree existante.
    # Les cases a cocher arrivent en texte : « false » est une chaine vraie,
    # et une fiche archivee depuis l'interface serait restee dans les listes.
    donnees = champs.coercer_booleens(nom, donnees)
    if not cle and nom == "salarie":
        # Le matricule d'une fiche neuve : le suivant. Il est obligatoire et
        # ne dit rien a l'humain -- le demander, c'est le voir inventer un
        # numero deja pris. Un matricule saisi est garde tel quel.
        if not str(donnees.get("code_salarie") or "").strip():
            donnees["code_salarie"] = str(_matricule_suivant(
                _lire_json(ctx.racine / "config" / FICHIERS_CONFIG[nom])))
    derives = champs.deriver(nom, donnees, forcer=True)

    anomalies = verifier_fiche(nom, donnees)
    verifiee = FicheVerifiee(nom, cle, donnees, anomalies)
    if verifiee.erreurs and not forcer:
        raise FicheRefusee(verifiee)

    chemin = ctx.racine / "config" / FICHIERS_CONFIG[nom]
    contenu = _lire_json(chemin)
    if nom == "entreprise":
        contenu.update(donnees)
        fiche_ecrite = contenu
    else:
        if not cle:
            # UNE FICHE NEUVE. Sans cle, on cree ; la cle se fabrique ici et
            # nulle part ailleurs (`cle_neuve`), pour que les deux faces
            # nomment pareil. Le bouton « + » de l'interface passe par la
            #.
            cle = cle_neuve(nom, donnees, contenu)
            verifiee = FicheVerifiee(nom, cle, donnees, anomalies)
            verifiee.creee = True
        contenu[cle] = {**contenu.get(cle, {}), **donnees}
        fiche_ecrite = contenu[cle]
    hist = _dater(fiche_ecrite.get("historique"), changements, depuis, note)
    if hist:
        fiche_ecrite["historique"] = hist
    else:
        fiche_ecrite.pop("historique", None)

    _sauver_avant(chemin)
    chemin.write_text(json.dumps(contenu, ensure_ascii=False, indent=2),
                      encoding="utf-8")
    verifiee.derives = derives
    return verifiee


# ---------------------------------------------------------- une fiche neuve
# Le titre d'un spectacle dont on ne connait que le numero d'objet. L'import
# CoolPaie le pose ; l'ecran le montre tel quel, pour qu'on le remplace.
TITRE_A_COMPLETER = "A COMPLETER"


def cle_neuve(nom: str, donnees: dict, existants: dict) -> str:
    """La cle d'une fiche neuve, lisible et unique dans son fichier.

    salarie    le nom declare, espaces en tirets : `PERE-LAHAILLE`. S'il est
               pris (une fratrie), le prenom s'ajoute : `PERE-LAHAILLE-CLET`.
    spectacle  le titre en minuscules sans accents ni apostrophes, tirets
               entre les mots : `si-javais-un-oeuf` -- la forme des cles
               existantes. Sans titre (un numero d'objet importe de CoolPaie,
               « A COMPLETER »), c'est le numero qui nomme : `objet-266Z...`,
               et la cle ne bougera pas quand le titre sera saisi.

    Et si c'est encore pris, un numero. La cle est un identifiant interne :
    elle ne part dans aucune declaration, et elle ne change plus une fois
    posee -- les saisies la citent.
    """
    from . import champs

    def propre(texte: str, bas: bool) -> str:
        t = champs.sans_accents(str(texte or "")).replace("'", "").replace("\u2019", "")
        t = "".join(c if c.isalnum() else "-" for c in t)
        t = "-".join(m for m in t.split("-") if m)
        return t.lower() if bas else t.upper()

    if nom == "salarie":
        base = propre(donnees.get("nom") or donnees.get("nom_affichage"), False)
        candidats = [base, "%s-%s" % (base, propre(
            donnees.get("prenom") or donnees.get("prenom_affichage"), False))]
    else:
        titre = str(donnees.get("titre") or "").strip()
        if (not titre or titre.upper() == TITRE_A_COMPLETER) and donnees.get("numero_objet"):
            base = "objet-" + str(donnees["numero_objet"]).strip()
        else:
            base = propre(titre, True)
        candidats = [base]
    candidats = [c for c in candidats if c and not c.startswith("-")]
    if not candidats:
        raise ErreurOperation(
            "Impossible de nommer cette fiche %s : il lui faut au moins un %s."
            % (nom, "nom" if nom == "salarie" else "titre"))
    for c in candidats:
        if c not in existants:
            return c
    n = 2
    while "%s-%d" % (candidats[-1], n) in existants:
        n += 1
    return "%s-%d" % (candidats[-1], n)


def _matricule_suivant(salaries: dict) -> int:
    """Le plus grand code salarie du fichier, plus un. 1 s'il n'y a personne."""
    codes = []
    for k, s in salaries.items():
        if k.startswith("_") or not isinstance(s, dict):
            continue
        try:
            codes.append(int(str(s.get("code_salarie", "")).strip()))
        except ValueError:
            continue
    return (max(codes) + 1) if codes else 1


def _dater(historique, changements: list, depuis, note: str) -> list:
    """Fait descendre dans `historique` les valeurs declarees qui sortent.

    La veille de `depuis` : la nouvelle valeur prend effet le jour dit, donc
    l'ancienne valait jusqu'a la veille incluse. C'est `contexte.telle_qu_au`
    qui les relit.
    """
    hist = list(historique or [])
    if not changements:
        return hist
    jour = (d(depuis) if depuis else _dt.date.today()) - _dt.timedelta(days=1)
    for c in changements:
        hist.append({"champ": c["champ"], "valeur": c["avant"],
                     "jusqu_au": str(jour), "note": note or ""})
    # Par champ puis par date : c'est ainsi qu'on les relit, et c'est ainsi
    # qu'on les lit quand on ouvre le fichier a la main.
    hist.sort(key=lambda e: (e["champ"], e["jusqu_au"]))
    return hist


# ----------------------------------------------------------------- le refus
class FicheRefusee(ErreurOperation):
    """La fiche porte au moins une erreur : elle n'a pas ete ecrite."""

    def __init__(self, verifiee: FicheVerifiee):
        self.verifiee = verifiee
        super().__init__(
            "%d erreur(s) : %s" % (len(verifiee.erreurs),
                                   " ; ".join("%s : %s" % (a["champ"], a["message"])
                                              for a in verifiee.erreurs)))


# ---------------------------------------------------------------------- fiche
def fiche(ctx: Contexte, archives: bool = False) -> Fiche:
    """Les donnees de reference.

    Par defaut, les fiches COURANTES : celles qu'on peut encore employer. Les
    archivees sont rendues a part, pour que l'appelant puisse dire qu'elles
    existent sans les melanger. `archives=True` remet tout dans un seul lot,
    pour qui veut voir la base entiere.
    """
    from .contexte import archivee

    mis_de_cote = {k: v for k, v in ctx.salaries.items() if archivee(v)}
    spec_de_cote = {k: v for k, v in ctx.spectacles.items() if archivee(v)}
    return Fiche(
        entreprise=ctx.entreprise,
        salaries=ctx.salaries if archives else ctx.salaries_actifs,
        spectacles=ctx.spectacles if archives else ctx.spectacles_actifs,
        compteurs=ctx.compteurs(),
        salaries_archives=mis_de_cote, spectacles_archives=spec_de_cote)
