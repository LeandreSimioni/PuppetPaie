"""Commande `depot-dsn` : la seule qui declare quelque chose.

Elle est seule dans son fichier, exprès. `commandes_retours.py` ne fait que
lire, `commandes_dpae.py` depose une embauche ; ici on transmet une
declaration sociale, avec ses ordres de telepaiement. On doit pouvoir ouvrir
ce fichier et voir, en une page, tout ce qui peut engager la compagnie.

DEUX MODES, ET AUCUN PAR DEFAUT
-------------------------------
    --test    le fichier part avec S10.G00.00.005 = '01' : les controles
              s'executent, un bilan revient, rien n'est DECLARE. C'est le
              validateur de reference : la meme brique de controle que
              DSN-Val, a jour, cote plate-forme. Mais le point de depot a
              une memoire (vu le 15/09/2026) : une seconde declaration
              normale du meme mois, en test, est refusee B1-208-10 pendant
              au moins cinq jours ; et un mois au-dela de M+1 est refuse
              B1-207-03. Les vraies DSN, elles, ne genent pas un test.
    --reel    le fichier part tel qu'il est, et il declare.

Il faut en choisir un. Pas de defaut, parce qu'aucun des deux n'est
« naturellement » le bon : oublier `--test` declarerait, oublier `--reel` ne
declarerait rien tout en donnant l'impression du contraire.

`--reel` demande en plus de RECOPIER le mois declare (`--confirmer-mois
2026-08`). Recopier n'est pas confirmer : on ne recopie pas par reflexe.
"""
from __future__ import annotations
from pathlib import Path

from . import dsn_api
from .util import jj_mm_aaaa       # noqa: F401  (garde la meme famille d'import)


def _apercu(a) -> None:
    print("Fichier   : %s" % a.chemin)
    print("Mois      : %s" % a.mois_lisible)
    print("Type      : %s - %s"
          % (a.type_declaration, dsn_api.TYPES.get(a.type_declaration, "?")))
    print("Ordre     : %s   fraction %s   constitue le %s"
          % (a.ordre, a.fraction, a.constitution))
    if a.remplace:
        print("Remplace  : declaration %s" % a.remplace)
    print("Logiciel  : %s   SIREN %s" % (a.logiciel, a.siren))
    print("Contenu   : %d salarie(s), %d lignes" % (a.salaries, a.lignes))
    if a.versements:
        print("Ordres de telepaiement : %s"
              % ", ".join("%s EUR" % v for v in a.versements))


def resoudre(ctx, chemin) -> Path:
    """Le fichier, qu'il soit donne depuis le code ou depuis les donnees.

    Le reste du moteur prend « paies/AAAA-MM.json », c'est-a-dire un chemin
    relatif au dossier des DONNEES, pas au dossier courant. On accepte les
    deux ici pour la meme raison : « sorties/2026-08/DSN_Aout2026.dsn » doit
    marcher depuis n'importe ou, et c'est ce que la fenetre de depot envoie.
    """
    p = Path(chemin)
    if p.exists():
        return p
    depuis_donnees = Path(ctx.racine) / chemin
    if depuis_donnees.exists():
        return depuis_donnees
    return p                    # laisse l'erreur se produire sur le chemin donne


def cmd_depot_dsn(ctx, args) -> int:
    if not args.apercu and args.test == args.reel:
        print("Choisir --test OU --reel. Les deux s'excluent, et il n'y a pas "
              "de defaut :\n"
              "  --test    controles executes, bilan rendu, RIEN de conserve\n"
              "  --reel    la declaration part, avec ses ordres de telepaiement\n"
              "  --apercu  lit le fichier et l'affiche, sans reseau ni depot")
        return 2

    fichier = resoudre(ctx, args.fichier)
    try:
        apercu = dsn_api.lire(fichier)
    except OSError as e:
        print("Fichier illisible : %s" % e)
        return 1

    if args.apercu:
        # Ne touche pas au reseau et ne demande pas de mot de passe. C'est la
        # relecture avant decision, celle qu'on refait autant de fois qu'on
        # veut sans que rien ne parte.
        print("%s\nCE QUI PARTIRAIT - rien n'est envoye\n%s"
              % ("-" * 62, "-" * 62))
        _apercu(apercu)
        print("-" * 62)
        print("Le fichier est code %s : sans --test, un depot %s."
              % (apercu.nature_envoi,
                 "DECLARERAIT" if apercu.reel else "ne declarerait rien"))
        return 0

    print("%s\n%s\n%s"
          % ("-" * 62,
             "DEPOT REEL - LA DECLARATION PART" if args.reel
             else "DEPOT DE TEST - rien ne sera conserve",
             "-" * 62))
    _apercu(apercu)
    print("-" * 62)

    # LE DEPOT LUI-MEME EST DANS `operations`, ET LES DEUX FACES Y PASSENT.
    # Cette fonction-ci ne fait plus qu'afficher : ce qui va partir, puis ce
    # qui est revenu. Tant que la decision vivait ici, l'interface ne pouvait
    # pas deposer sans la recopier -- et une regle recopiee est une regle
    # qu'on finit par contourner d'un cote sans s'en apercevoir.
    #
    # La preuve reste celle de la ligne de commande : le mois RECOPIE. C'est
    # `operations` qui sait qu'il en existe une seconde, pour la page.
    from . import operations as ops
    try:
        fait = ops.deposer_dsn(
            ctx, fichier, reel=args.reel,
            preuve=ops.Preuve(mois_recopie=args.confirmer_mois),
            qui="ligne de commande", environnement=args.environnement,
            forcer=getattr(args, "force", False))
    except (ops.PreuveInsuffisante, dsn_api.DepotRefuse) as e:
        print("\nRefus : %s" % e)
        return 2
    except ops.SeanceFermee as e:
        print("\n%s" % e)
        return 2
    except ops.ErreurOperation as e:
        print("\n%s" % e)
        return 2
    except Exception as e:                      # ErreurApi et le reste
        print("\nEchec du depot : %s" % e)
        return 1

    if fait.deja:
        print("\nA SAVOIR : ce fichier exact avait deja ete depose le %s."
              % fait.deja.get("quand", "?"))
    print("\nReponse du point de depot :\n%s" % (fait.reponse or "(vide)"))
    print("Reponse archivee : %s" % fait.trace)
    if fait.flux:
        print("Flux : %s -- c'est par lui que les retours se rattacheront."
              % fait.flux)
    print("""
Le depot n'est pas la fin : les retours arrivent ensuite, et c'est eux qui
disent si la declaration est conforme.

  python -m moteur retours""")
    if args.reel:
        print("""
Puis, quelques jours plus tard, les attestations France Travail :

  python -m moteur aer --mois %s""" % apercu.mois_lisible)
    return 0


def enregistrer_commandes(sub) -> None:
    d = sub.add_parser(
        "depot-dsn", help="deposer une DSN sur net-entreprises (test ou reel)")
    d.add_argument("fichier", help="le fichier .dsn a deposer")
    d.add_argument("--apercu", action="store_true",
                   help="lire le fichier et l'afficher, sans reseau ni depot")
    d.add_argument("--test", action="store_true",
                   help="controles executes, bilan rendu, rien de conserve")
    d.add_argument("--reel", action="store_true",
                   help="la declaration part pour de vrai")
    d.add_argument("--confirmer-mois", dest="confirmer_mois",
                   help="obligatoire avec --reel : recopier le mois (AAAA-MM)")
    d.add_argument("--force", action="store_true",
                   help="redeposer meme si une DSN reelle est deja partie pour "
                        "ce mois et attend son retour (annule-et-remplace "
                        "voulu). Sans lui, le depot refuse et dit ou en est "
                        "la precedente.")
    d.add_argument("--environnement", default="production",
                   choices=["production", "editeur"])
    d.set_defaults(fn=cmd_depot_dsn)
