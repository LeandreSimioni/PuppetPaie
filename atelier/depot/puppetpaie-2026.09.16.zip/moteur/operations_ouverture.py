"""L'ouverture du logiciel et la veille : sauvegarder, relever, sans echouer.

Ce que le logiciel fait tout seul quand on l'ouvre -- interface ou ligne de
commande, c'est la meme fonction -- et toutes les N minutes ensuite. Le
compte Google (autorisation, etat, oubli) est ici aussi : c'est lui qui
porte la sauvegarde.

Depuis le 15/09/2026, la veille releve aussi les SIGNATURES : les reponses
« Je signe » des salaries, dans Gmail (operations_documents.
relever_signatures). C'est la demande -- << une reception automatique des
mails qui soit lue quand le logiciel est ouvert, et la signature arrive
directement dans le logiciel >>.

Depuis le 16/09/2026, elle verifie aussi les SOURCES des donnees livrees
(sources.py, et les livraisons open data KALI pour les conventions
collectives), une fois par semaine au plus : une grille de minima perimee
est une paie fausse, et personne ne va relire Legifrance tous les mois.
Cela, chez l'EDITEUR seulement (config/maj.json : "editeur": true). Chez
une compagnie, l'ouverture cherche a la place une MISE A JOUR du logiciel
(maj.py) : telechargee dans l'ombre, appliquee au redemarrage suivant par
le lanceur. La relecture est le travail de l'editeur ; la compagnie recoit
la version.
"""
from __future__ import annotations

import datetime as _dt
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .contexte import Contexte
from .operations_socle import ErreurOperation
from .operations_documents import ReleveSignatures, relever_signatures
from .operations_retours import (ReleveRetours, relever_retours,
                                 relever_retours_dpae)


@dataclass
class EtatGoogle:
    application: str
    permissions: list
    compte: Optional[str]
    verifie: bool


# --------------------------------------------------------------------- Google
def google_etat(ctx: Contexte) -> EtatGoogle:
    """L'autorisation tient-elle ? Un jeton present ne prouve rien : Google a
    pu le revoquer. Seul un rafraichissement reel repond."""
    from . import google

    ids = google.identifiants(ctx)
    permissions = [p.rsplit("/", 1)[-1] for p in google.PERMISSIONS]
    if not google.autorise(ctx):
        return EtatGoogle(ids["origine"], permissions, None, False)
    compte = google.compte_autorise(ctx)
    google.Client(ctx).jeton_acces()
    return EtatGoogle(ids["origine"], permissions, compte, True)


def google_autoriser(ctx: Contexte, ouvrir: bool = True) -> str:
    from . import google
    return google.autoriser(ctx, ouvrir=ouvrir)


def google_oublier(ctx: Contexte) -> bool:
    from . import google
    return google.oublier(ctx)


# ====================================================================== ouverture
#
# Ce que le logiciel fait tout seul quand on l'ouvre -- interface ou ligne de
# commande, c'est la meme fonction : sauvegarder le dossier prive dans le
# Drive, et relever les retours des organismes, sans rien avoir a taper. Le coffre (moteur/coffre.py) porte les mots de passe ; l'ouverture n'en
# lit aucun elle-meme, elle les demande pour un usage de CONSULTATION.
#
# REGLE : l'ouverture n'echoue jamais. Pas de reseau, pas de compte Google, pas
# de secret pose -- elle le NOTE et rend la main. Un logiciel de paie qui refuse
# de s'ouvrir parce que le wifi est coupe est un logiciel inutilisable, et la
# paie, elle, se calcule tres bien hors ligne.


@dataclass
class VeilleSources:
    """Ce que la verification des sources a donne -- celle de ce passage, ou
    la derniere en date si elle a moins d'une semaine."""
    le: str                              # date ISO de la verification
    total: int
    a_relire: list                       # idents dont la source en ligne a bouge
    injoignables: list
    faite_maintenant: bool
    details: dict = field(default_factory=dict)   # ident -> detail, pour a_relire

    def resume(self) -> str:
        quand = "verifiees le %s" % _dt.date.fromisoformat(self.le).strftime("%d/%m")
        if self.a_relire:
            return "sources %s : %d A RELIRE (%s)" % (quand, len(self.a_relire),
                                                       ", ".join(self.a_relire))
        if self.injoignables:
            return "sources %s : %d injoignable(s), les autres inchangees" % (
                quand, len(self.injoignables))
        return "%d sources %s, inchangees" % (self.total, quand)


SOURCES_TOUS_LES = 7                     # jours entre deux verifications


@dataclass
class MiseAJour:
    """La version du logiciel, et ce que le depot en dit -- calme par
    construction : ce qui n'a pas pu se faire est un detail, pas un incident."""
    courante: str
    message: str                         # ce que le bandeau montre
    derniere: Optional[str] = None
    prete: Optional[str] = None          # telechargee et controlee : au redemarrage
    telechargee_maintenant: bool = False
    detail: str = ""
    note_calcul: str = ""                # « cette version change un calcul », une fois

    def resume(self) -> str:
        return self.message


@dataclass
class Ouverture:
    quand: str
    sauvegarde: Optional[Any] = None
    releve: Optional[ReleveRetours] = None
    releve_dpae: Optional[ReleveRetours] = None
    signatures: Optional[ReleveSignatures] = None
    sources: Optional[VeilleSources] = None
    maj: Optional[MiseAJour] = None
    incidents: list = field(default_factory=list)
    manquants: list = field(default_factory=list)
    secondes: float = 0.0

    @property
    def tout_va_bien(self) -> bool:
        return not self.incidents and not self.manquants


def _marque_ouverture(ctx: Contexte) -> Path:
    """La trace de la derniere ouverture -- etat machine, ecarte de la sauvegarde.

    Meme raison que l'index de `sauvegarde.py` : un fichier reecrit a chaque
    ouverture et sauvegarde a chaque ouverture ferait croire, a chaque fois,
    que le dossier a change.
    """
    return ctx.racine / "config" / ".ouverture.json"


def derniere_ouverture(ctx: Contexte) -> dict:
    p = _marque_ouverture(ctx)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except ValueError:
        return {}


def ouverture(ctx: Contexte, *, sauvegarder: bool = True, retours: bool = True,
              signatures: bool = True, sources: bool = True, maj: bool = True,
              jours: int = 30, racine_drive: str = "PuppetPaie",
              pas_avant: int = 0, veille: bool = False) -> Ouverture:
    """Ce qui se fait a l'ouverture du logiciel, et toutes les N minutes ensuite.

    `pas_avant` : ne rien refaire si la derniere ouverture a moins de N minutes.
    Trois fenetres ouvertes coup sur coup ne relevent pas trois fois.

    `veille` : le passage periodique. Il saute la sauvegarde quand rien n'a
    bouge sur le disque -- une comparaison locale, sans un octet de reseau.

    `sources` : verifier les sources des donnees livrees, au plus une fois
    tous les SOURCES_TOUS_LES jours ; entre deux, on redit le dernier etat.
    Chez l'editeur seulement.

    `maj` : chercher une nouvelle version au depot et la preparer. Chez une
    compagnie seulement -- l'editeur fabrique les versions, il ne les recoit
    pas.
    """
    from . import coffre, sauvegarde as _sauvegarde

    debut = time.time()
    resultat = Ouverture(quand=_dt.datetime.now().strftime("%d/%m/%Y %H:%M"))

    precedente = derniere_ouverture(ctx)
    if pas_avant and precedente.get("quand"):
        try:
            age = (_dt.datetime.now()
                   - _dt.datetime.strptime(precedente["quand"], "%Y-%m-%d %H:%M"))
            if age.total_seconds() < pas_avant * 60:
                resultat.incidents.append(
                    "Ouverture deja faite il y a %d minute(s) : rien a refaire."
                    % int(age.total_seconds() // 60))
                return resultat
        except ValueError:
            pass

    if sauvegarder:
        if not _google_pret(ctx):
            resultat.manquants.append(
                "Compte Google non autorise : la sauvegarde ne peut pas partir. "
                "`python -m moteur google autoriser`.")
        elif veille and _sauvegarde.rien_n_a_bouge(ctx):
            pass                      # rien de neuf sur le disque : on n'appelle pas
        else:
            try:
                resultat.sauvegarde = _sauvegarde.sauvegarder(
                    ctx, racine_drive=racine_drive)
                resultat.incidents.extend(resultat.sauvegarde.incidents)
            except Exception as e:                                # noqa: BLE001
                resultat.incidents.append("Sauvegarde : %s" % e)

    if retours:
        if not coffre.disponible(ctx, coffre.NET_ENTREPRISES):
            resultat.manquants.append(
                "Mot de passe net-entreprises absent du coffre : les retours ne "
                "peuvent pas etre releves seuls. "
                "`python -m moteur coffre poser net-entreprises`.")
        else:
            try:
                fin = _dt.datetime.now()
                resultat.releve = relever_retours(
                    ctx, debut=fin - _dt.timedelta(days=jours), fin=fin)
                resultat.incidents.extend(resultat.releve.incidents)
            except Exception as e:                                # noqa: BLE001
                resultat.incidents.append("Retours : %s" % e)
        # LE CANAL DPAE AUSSI. Jusqu'au 12/09/2026 la veille ne relevait que
        # net-entreprises : une DPAE refusee en douze secondes restait << pas
        # encore de retour >> tant qu'on ne tapait pas la commande a la main.
        if not coffre.disponible(ctx, coffre.URSSAF):
            resultat.manquants.append(
                "Mot de passe Urssaf (DPAE) absent du coffre : les retours de "
                "DPAE ne peuvent pas etre releves seuls. "
                "`python -m moteur coffre poser urssaf`.")
        else:
            try:
                fin = _dt.datetime.now()
                resultat.releve_dpae = relever_retours_dpae(
                    ctx, debut=fin - _dt.timedelta(days=jours), fin=fin)
                resultat.incidents.extend(resultat.releve_dpae.incidents)
            except Exception as e:                                # noqa: BLE001
                resultat.incidents.append("Retours DPAE : %s" % e)

    if signatures:
        # Les reponses « Je signe ». `relever_signatures` ne leve pas pour un
        # compte absent ou une permission manquante : il le dit, et
        # seulement s'il y a quelque chose a attendre.
        try:
            resultat.signatures = relever_signatures(ctx, qui="veille")
            resultat.incidents.extend(resultat.signatures.incidents)
        except Exception as e:                                    # noqa: BLE001
            resultat.incidents.append("Signatures : %s" % e)

    from . import maj as _maj
    try:
        chez_l_editeur = _maj.editeur(ctx)
    except ValueError as e:
        resultat.incidents.append(str(e))
        chez_l_editeur, sources, maj = False, False, False
    if sources and chez_l_editeur:
        try:
            resultat.sources = _veiller_sources(ctx, precedente)
            for ident in resultat.sources.a_relire:
                resultat.incidents.append(
                    "Source a relire : %s -- %s" % (ident, resultat.sources.details[ident]))
        except Exception as e:                                    # noqa: BLE001
            resultat.incidents.append("Sources : %s" % e)

    if maj and not chez_l_editeur:
        # Ne leve jamais, ne fait jamais d'incident : une compagnie hors
        # ligne fait sa paie, la version attendra.
        e = _maj.verifier(ctx)
        resultat.maj = MiseAJour(courante=e.courante, message=e.message,
                                 derniere=e.derniere, prete=e.prete,
                                 telechargee_maintenant=e.telechargee_maintenant,
                                 detail=e.detail, note_calcul=e.note_calcul)

    resultat.secondes = round(time.time() - debut, 1)
    _noter_ouverture(ctx, resultat)
    return resultat


def _veiller_sources(ctx: Contexte, precedente: dict) -> VeilleSources:
    """Une fois par semaine, on retourne voir chaque source (sources.verifier :
    les fichiers retelecharges et compares, les conventions collectives par
    les livraisons KALI). Le reste du temps, l'etat de la derniere fois --
    une source A RELIRE le reste tant qu'on ne l'a pas relue, c'est-a-dire
    tant que le manifeste n'a pas change de date de releve."""
    d = precedente.get("sources_etat") or {}
    if d.get("le"):
        age = (_dt.date.today() - _dt.date.fromisoformat(d["le"])).days
        if 0 <= age < SOURCES_TOUS_LES:
            return VeilleSources(le=d["le"], total=d.get("total", 0),
                                 a_relire=list(d.get("a_relire", [])),
                                 injoignables=list(d.get("injoignables", [])),
                                 faite_maintenant=False, details=dict(d.get("details", {})))
    from . import sources as _sources
    liste = _sources.verifier(ctx)
    return VeilleSources(
        le=_dt.date.today().isoformat(), total=len(liste),
        a_relire=[e.ident for e in liste if e.en_ligne == "changee"],
        injoignables=[e.ident for e in liste if e.en_ligne == "injoignable"],
        faite_maintenant=True,
        details={e.ident: e.detail for e in liste if e.en_ligne == "changee"})


def _google_pret(ctx: Contexte) -> bool:
    from . import google
    try:
        return google.autorise(ctx)
    except Exception:                                             # noqa: BLE001
        return False


def _noter_ouverture(ctx: Contexte, r: Ouverture) -> None:
    """Trace de la derniere ouverture. Aucun secret n'y figure, par construction."""
    p = _marque_ouverture(ctx)
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        p.write_text(json.dumps({
            "quand": r.quand,
            "secondes": r.secondes,
            "sauvegarde": (r.sauvegarde.resume() if r.sauvegarde else ""),
            "retours": (r.releve.resume() if r.releve else ""),
            "nouveaux": len(r.releve.nouveaux) if r.releve else 0,
            "signatures": (r.signatures.resume() if r.signatures else ""),
            "signatures_recues": [{"nom": x.nom, "quand": x.quand,
                                   "renvoye": x.renvoye}
                                  for x in r.signatures.recues] if r.signatures else [],
            "sources": (r.sources.resume() if r.sources else ""),
            "maj": (r.maj.message if r.maj else ""),
            "maj_note": (r.maj.note_calcul if r.maj else ""),
            "maj_etat": ({"courante": r.maj.courante, "derniere": r.maj.derniere,
                          "prete": r.maj.prete, "detail": r.maj.detail}
                         if r.maj else {}),
            "sources_etat": ({"le": r.sources.le, "total": r.sources.total,
                              "a_relire": r.sources.a_relire,
                              "injoignables": r.sources.injoignables,
                              "details": r.sources.details}
                             if r.sources else {}),
            "incidents": r.incidents,
            "manquants": r.manquants,
        }, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass


# ================================================================ mise a jour
#
# Les operations de version : ce que les deux faces et le lanceur appellent.
# `maj.py` fait le travail ; ici les decisions -- qui est l'editeur, quand
# on refuse.

def version(ctx) -> dict:
    """La version du logiciel, ce qui est pret, ce qui est configure."""
    from . import maj as _maj
    cfg = _maj.configuration(ctx)
    p = _maj.prete(ctx)
    return {"courante": _maj.courante(), "editeur": cfg["editeur"], "depot": cfg["depot"],
            "prete": p["version"] if p else None,
            "avant": _maj.courante(_maj.CODE / ".avant") if (_maj.CODE / ".avant" / "moteur").is_dir() else None}


def verifier_maj(ctx, telecharger: bool = True) -> MiseAJour:
    """Aller voir le depot maintenant, meme chez l'editeur (a la demande)."""
    from . import maj as _maj
    e = _maj.verifier(ctx, telecharger=telecharger)
    return MiseAJour(courante=e.courante, message=e.message, derniere=e.derniere,
                     prete=e.prete, telechargee_maintenant=e.telechargee_maintenant,
                     detail=e.detail, note_calcul=e.note_calcul)


def appliquer_maj(ctx, forcer: bool = False) -> dict:
    """La bascule vers la version prete. Refuse si l'interface tourne."""
    from . import maj as _maj
    try:
        return _maj.appliquer(ctx, forcer=forcer)
    except ValueError as e:
        raise ErreurOperation(str(e))


def revenir_maj(ctx, forcer: bool = False) -> dict:
    from . import maj as _maj
    try:
        return _maj.revenir(ctx, forcer=forcer)
    except ValueError as e:
        raise ErreurOperation(str(e))


def publier_maj(ctx, depot: Optional[str] = None, notes: str = "", calcul: str = "") -> dict:
    """Chez l'editeur : l'archive et derniere.json dans le depot (config/maj.json
    ou l'argument). Refuse ailleurs : une compagnie ne publie pas."""
    from . import maj as _maj
    cfg = _maj.configuration(ctx)
    if not cfg["editeur"]:
        raise ErreurOperation("Ce poste n'est pas celui de l'editeur (config/maj.json, "
                              "\"editeur\": true) : il ne publie pas.")
    depot = depot or cfg["depot"]
    if not depot:
        raise ErreurOperation("Aucun depot : le donner en argument ou dans config/maj.json.")
    try:
        return _maj.publier(depot, notes=notes, calcul=calcul)
    except ValueError as e:
        raise ErreurOperation(str(e))
