"""Commandes de l'ouverture : `ouverture`, `sauvegarder`, `coffre`, `seance`.

Ce que le logiciel fait tout seul quand on l'ouvre, et ce qui l'y autorise.

    python -m moteur ouverture            sauvegarde + retours, sans rien taper
    python -m moteur sauvegarder          le prive dans le Drive, par differences
    python -m moteur coffre               ce qui est pose, jamais les valeurs
    python -m moteur coffre poser net-entreprises [--fenetre]
    python -m moteur coffre verifier      les secrets poses ouvrent-ils une session
    python -m moteur coffre ouverture     le mot de passe DU LOGICIEL
    python -m moteur seance --ouvrir      le taper, et ouvrir la seance

DEUX FACES, UNE SEULE OUVERTURE. L'interface appelle `operations.ouverture` au
demarrage puis toutes les vingt minutes ; la ligne de commande appelle la meme
fonction. Claude Code aussi -- c'est la meme, et c'est le point : il n'y a pas
une ouverture « pour l'humain » et une autre « pour le programme ».

CE QUE CLAUDE CODE PEUT FAIRE, ET A QUELLE CONDITION
-----------------------------------------------------
La demande : « c'est un peu dans l'idee MCP, on doit
pouvoir permettre a Claude Code de faire des actions PuppetPaie, si
l'authentification est validee. » La frontiere est celle-ci, et elle est
tenue par le coffre, pas par la politesse :

    LIRE, PRODUIRE, SAUVEGARDER      toujours. Aucune de ces commandes
                                     n'engage la compagnie : un bulletin de
                                     trop se reproduit, un retour archive de
                                     trop ne coute rien.
    DEPOSER (DSN, DPAE)              seulement seance ouverte -- donc
                                     seulement si un humain a tape le mot de
                                     passe du logiciel depuis moins de deux
                                     heures. Sinon la commande refuse, et elle
                                     dit comment ouvrir.

Un agent qui tourne sous le compte Windows de l'utilisateur peut lire le coffre : la
protection n'est pas la. Elle est dans le fait qu'une declaration ne part pas
sans qu'une personne ait ouvert la seance, coche « pour de vrai » et recopie le
mois.
"""
from __future__ import annotations

import getpass

from . import coffre, operations as ops, sauvegarde as _sauvegarde


# ------------------------------------------------------------------ affichage
def _dire_ouverture(r) -> None:
    print("Ouverture du %s (%.1f s)" % (r.quand, r.secondes))
    if r.sauvegarde:
        s = r.sauvegarde
        print("  Drive     : %s" % s.resume())
        for f in s.deposes[:12]:
            print("      %-6s %s" % (f.etat, f.relatif))
        if len(s.deposes) > 12:
            print("      ... et %d autre(s)" % (len(s.deposes) - 12))
    if r.releve:
        print("  Retours   : %s" % r.releve.resume())
        for a in r.releve.archives:
            from . import retours as _retours
            print("      %s  %s" % (a.chemin.name,
                                    _retours.libelle_nature(a.retour.get("nature"))))
    if r.signatures and (r.signatures.attendues or r.signatures.recues):
        print("  Signatures: %s" % r.signatures.resume())
        _dire_signatures(r.signatures)
    if r.sources:
        print("  Sources   : %s" % r.sources.resume())
    if r.maj:
        print("  Version   : %s" % r.maj.message)
        if r.maj.note_calcul:
            print("              %s" % r.maj.note_calcul)
    for m in r.manquants:
        print("  ! %s" % m)
    for i in r.incidents:
        print("  ! %s" % i)
    if r.releve and r.releve.nouveaux:
        print("\n%d retour(s) nouveau(x). Les lire en detail :"
              "\n  python -m moteur retours" % len(r.releve.nouveaux))


def _dire_signatures(s) -> None:
    for x in s.recues:
        print("      %s  signe le %s depuis %s (%s)%s"
              % (x.nom, x.quand.replace("T", " ")[:16], x.adresse, x.code,
                 " -- contrat contresigne renvoye" if x.renvoye else ""))


def cmd_signatures(ctx, args) -> int:
    """Relever maintenant les reponses « Je signe » dans Gmail."""
    r = ops.relever_signatures(ctx, mois=args.mois, qui="ligne de commande")
    if args.json:
        import json
        from . import sortie_json as js
        print(json.dumps(js.enveloppe("signatures", _signatures_json(r)),
                         ensure_ascii=False, indent=2))
        return 1 if r.incidents else 0
    if not r.attendues and not r.recues:
        print("Aucune signature attendue.")
        return 0
    print(r.resume())
    _dire_signatures(r)
    for i in r.incidents:
        print("  ! %s" % i)
    return 1 if r.incidents else 0


def _signatures_json(s) -> dict:
    return {"quand": s.quand, "attendues": s.attendues,
            "recues": [{"mois": x.mois, "salarie": x.salarie, "nom": x.nom,
                        "code": x.code, "adresse": x.adresse, "quand": x.quand,
                        "contrats": x.contrats, "fichier_signe": x.fichier_signe,
                        "preuve": x.preuve, "renvoye": x.renvoye}
                       for x in s.recues],
            "incidents": s.incidents}


def cmd_ouverture(ctx, args) -> int:
    """Tout ce qui se fait a l'ouverture. N'echoue pas : elle rend compte."""
    r = ops.ouverture(ctx,
                      sauvegarder=not args.sans_sauvegarde,
                      retours=not args.sans_retours,
                      signatures=not args.sans_signatures,
                      sources=not args.sans_sources,
                      maj=not args.sans_maj,
                      jours=args.jours,
                      pas_avant=args.pas_avant,
                      veille=args.veille)
    if args.json:
        import json
        from . import sortie_json as js
        print(json.dumps(js.enveloppe("ouverture", _en_json(r)),
                         ensure_ascii=False, indent=2))
        return 0
    _dire_ouverture(r)
    # Un manque de secret ou de compte Google n'est pas une panne : c'est une
    # chose a faire. Code 0, et on l'a dit. Un incident reseau, lui, se signale.
    return 1 if r.incidents else 0


def _en_json(r) -> dict:
    return {
        "quand": r.quand,
        "secondes": r.secondes,
        "sauvegarde": ({"resume": r.sauvegarde.resume(),
                        "deposes": [f.relatif for f in r.sauvegarde.deposes],
                        "identiques": r.sauvegarde.identiques,
                        "octets": r.sauvegarde.octets_deposes}
                       if r.sauvegarde else None),
        "retours": ({"resume": r.releve.resume(),
                     "trouves": len(r.releve.trouves),
                     "nouveaux": len(r.releve.nouveaux),
                     "archives": [str(a.chemin) for a in r.releve.archives]}
                    if r.releve else None),
        "signatures": _signatures_json(r.signatures) if r.signatures else None,
        "maj": ({"courante": r.maj.courante, "message": r.maj.message,
                 "derniere": r.maj.derniere, "prete": r.maj.prete,
                 "note_calcul": r.maj.note_calcul, "detail": r.maj.detail}
                if r.maj else None),
        "sources": ({"le": r.sources.le, "resume": r.sources.resume(),
                     "a_relire": r.sources.a_relire,
                     "injoignables": r.sources.injoignables}
                    if r.sources else None),
        "incidents": r.incidents,
        "manquants": r.manquants,
    }


def cmd_sauvegarder(ctx, args) -> int:
    """Le dossier prive dans le Drive. Ne supprime jamais rien la-bas."""
    from . import google

    if not google.autorise(ctx):
        print("Compte Google non autorise.\n  python -m moteur google autoriser")
        return 2
    if args.point:
        d = _sauvegarde.derniere(ctx)
        print("Dernier passage : %s (%d fichier(s) suivis)"
              % (d.get("quand") or "jamais", d.get("fichiers", 0)))
        print("Rien n'a bouge depuis : %s"
              % ("oui" if _sauvegarde.rien_n_a_bouge(ctx) else "non"))
        return 0

    print("Sauvegarde de %s vers Drive/%s/%s"
          % (ctx.racine, args.racine_drive, _sauvegarde.DOSSIER_DRIVE))
    r = _sauvegarde.sauvegarder(ctx, racine_drive=args.racine_drive, tout=args.tout)
    for f in r.deposes:
        print("  %-8s %s" % (f.etat, f.relatif))
    print("\n%s" % r.resume())
    print("%d fichier(s) ecarte(s) : secrets, verrous, rebut." % r.exclus)
    for i in r.incidents:
        print("  ! %s" % i)
    print("En %s s." % r.secondes)
    return 1 if r.incidents else 0


# --------------------------------------------------------------------- coffre
def cmd_coffre(ctx, args) -> int:
    """Poser, oublier, ou dire ce qui est pose. Jamais afficher une valeur."""
    quoi = args.quoi or "etat"

    if quoi == "etat":
        print("Coffre : %s" % coffre.chemin(ctx))
        print("  chiffre par DPAPI, lie a ce compte Windows."
              if coffre.dpapi_disponible() else
              "  ATTENTION : pas de DPAPI hors Windows, le contenu est en clair.")
        print()
        for s in coffre.etat(ctx):
            marque = "pose" if s.pose else "-"
            if s.dans_environnement:
                marque = "environnement"
            print("  %-18s %-14s %s" % (s.service, marque,
                                        ("depuis le %s" % s.pose_le) if s.pose_le else ""))
            print("     %s" % s.sert_a)
        s = coffre.seance(ctx)
        print()
        if not s.exigee:
            print("  Mot de passe du logiciel : AUCUN. Le depot s'en remet a ses")
            print("  trois gestes (case, mois recopie, confirmation).")
            print("  En poser un :  python -m moteur coffre ouverture")
        else:
            print("  Mot de passe du logiciel : pose. Seance %s%s."
                  % ("ouverte" if s.ouverte else "fermee",
                     (" depuis le %s" % s.ouverte_le.replace("T", " "))
                     if s.ouverte and s.ouverte_le else ""))
        return 0

    if quoi == "verifier":
        print("Verification des secrets poses -- UNE tentative par compte.\n")
        return cmd_verifier_coffre(ctx, args)

    if quoi == "ouverture":
        return _poser_ouverture(ctx, args)

    if quoi in ("poser", "oublier") and not args.service:
        print("Quel service ? %s" % ", ".join(sorted(coffre.SERVICES)))
        return 2

    if quoi == "oublier":
        efface = coffre.oublier(ctx, args.service)
        print("Oublie." if efface else "Il n'y avait rien pour ce service.")
        return 0

    # poser
    fiche = coffre.SERVICES.get(args.service)
    if not fiche:
        print("Service inconnu. Connus : %s" % ", ".join(sorted(coffre.SERVICES)))
        return 2
    print("Mot de passe %s." % fiche["libelle"])
    print("Il sert a : %s." % fiche["sert_a"])
    print("Il sera chiffre par le compte Windows et jamais affiche.")
    mdp = _demander("mot de passe : ", args.fenetre)
    if mdp is None:
        return 2
    if _demander("le retaper   : ", args.fenetre) != mdp:
        print("Les deux saisies different. Rien n'a ete pose.")
        return 2
    try:
        coffre.poser(ctx, args.service, mdp)
    except coffre.ErreurCoffre as e:
        print("\n%s" % e)
        return 2
    del mdp
    print("Pose. `python -m moteur coffre` dit desormais qu'il est la, jamais "
          "ce qu'il vaut.")
    return 0


def _poser_ouverture(ctx, args) -> int:
    print("Mot de passe DU LOGICIEL -- pas celui d'un organisme.")
    print("Il est demande une fois a l'ouverture, et c'est lui qui autorise")
    print("ensuite un depot, tant que la fenetre reste ouverte.")
    print("Seul son condense est ecrit : il ne peut pas etre retrouve.")
    mdp = _demander("mot de passe : ", getattr(args, "fenetre", False))
    if mdp is None:
        return 2
    if _demander("le retaper   : ", getattr(args, "fenetre", False)) != mdp:
        print("Les deux saisies different. Rien n'a ete pose.")
        return 2
    try:
        coffre.poser_ouverture(ctx, mdp)
    except coffre.ErreurCoffre as e:
        print("\n%s" % e)
        return 2
    coffre.ouvrir_seance(ctx, mdp)
    del mdp
    print("Pose, et la seance est ouverte. Elle le reste jusqu'a "
          "`python -m moteur seance --fermer`.")
    return 0


def _demander(invite: str, fenetre: bool = False):
    """Un mot de passe, masque, et JAMAIS par un argument de ligne de commande.

    Deux chemins, parce que le premier a laché une fois :

    - `getpass` dans le terminal. C'est le chemin normal. Mais le 11/09/2026,
      dans le terminal integre, il n'a capture qu'UN caractere : les deux
      secrets poses ce jour-la etaient inutilisables, et rien ne l'a dit avant
      un « HTTP 422 » sans rapport apparent.
    - une petite FENETRE tkinter (`--fenetre`), qui ne depend pas du terminal.
      C'est le meme champ masque que les lanceurs `Depot DSN.cmd` et compagnie,
      qui eux n'ont jamais eu ce probleme.

    Sans terminal du tout -- tache planifiee, agent -- les deux echouent, et
    c'est voulu : poser un mot de passe est un geste d'humain.
    """
    if fenetre:
        return _demander_fenetre(invite)
    try:
        mdp = getpass.getpass(invite)
    except (EOFError, OSError):
        print("\nPas de terminal pour saisir un mot de passe sans l'afficher.")
        print("Essayer la fenetre :  ... --fenetre")
        return None
    if mdp and len(mdp) < 6:
        # Ne pas dire la longueur exacte : le but est d'alerter, pas de
        # renseigner quelqu'un qui regarderait l'ecran par-dessus l'epaule.
        print("\nLa saisie masquee n'a capture que quelques caracteres.")
        print("C'est arrive le 11/09/2026 dans le terminal integre. Reessayer")
        print("dans une fenetre, qui ne depend pas du terminal :")
        print("  ... --fenetre")
        return None
    return mdp


def _demander_fenetre(invite: str):
    """Un champ masque dans une fenetre. Le mot de passe ne quitte pas la memoire."""
    try:
        import tkinter as tk
    except ImportError:
        print("tkinter absent : impossible d'ouvrir une fenetre.")
        return None

    reponse = {"valeur": None}
    racine = tk.Tk()
    racine.title("PuppetPaie")
    racine.configure(bg="#1e1e24")
    racine.attributes("-topmost", True)
    tk.Label(racine, text=invite.strip().rstrip(":").strip(), bg="#1e1e24",
             fg="#e8e8ec", font=("Segoe UI", 11)).pack(anchor="w", padx=20,
                                                       pady=(18, 6))
    champ = tk.Entry(racine, show="*", bg="#2a2a33", fg="#e8e8ec", relief="flat",
                     insertbackground="#e8e8ec", font=("Segoe UI", 12), width=32)
    champ.pack(anchor="w", padx=20, ipady=6)
    champ.focus_force()
    tk.Label(racine, text="Il n'est pas affiche, et il ne part nulle part.",
             bg="#1e1e24", fg="#9a9aa8",
             font=("Segoe UI", 8)).pack(anchor="w", padx=20, pady=(4, 0))

    def valider(*_):
        reponse["valeur"] = champ.get()
        racine.destroy()

    champ.bind("<Return>", valider)
    racine.bind("<Escape>", lambda e: racine.destroy())
    barre = tk.Frame(racine, bg="#1e1e24")
    barre.pack(anchor="e", padx=20, pady=14)
    tk.Button(barre, text="Annuler", command=racine.destroy, bg="#2a2a33",
              fg="#e8e8ec", relief="flat", font=("Segoe UI", 10), padx=14,
              pady=6, cursor="hand2").pack(side="left", padx=6)
    tk.Button(barre, text="Valider", command=valider, bg="#c9a227",
              fg="#1e1e24", relief="flat", font=("Segoe UI", 10, "bold"),
              padx=16, pady=6, cursor="hand2").pack(side="left")
    racine.mainloop()
    return reponse["valeur"]


def cmd_verifier_coffre(ctx, args) -> int:
    """Le secret pose ouvre-t-il vraiment une session ? UNE tentative par compte.

    Ecrite le 11/09/2026, apres qu'un secret tronque a la saisie a echoue
    beaucoup plus tard, sous une forme qui ne le designait pas. Poser un mot
    de passe sans jamais l'essayer, c'est remettre la panne a un moment ou
    l'on soupconnera le compte.

    UNE SEULE TENTATIVE PAR COMPTE, et le code le garantit : au-dela de
    quelques echecs, net-entreprises bloque temporairement le compte (HTTP
    403). On n'insiste jamais, et on ne boucle pas.
    """
    from . import coffre as _coffre, dpae_api
    from .netentreprises import Client, ErreurApi

    essais = []
    for service in (_coffre.NET_ENTREPRISES, _coffre.URSSAF):
        if not _coffre.pose(ctx, service):
            print("  %-16s pas pose -- rien a verifier" % service)
            continue
        mdp = _coffre.lire(ctx, service, usage=_coffre.CONSULTATION)
        client = (Client(ctx, "production", motdepasse=mdp)
                  if service == _coffre.NET_ENTREPRISES
                  else dpae_api.ClientDpae(ctx, motdepasse=mdp))
        try:
            client.authentifier()
            print("  %-16s OK -- session ouverte" % service)
        except ErreurApi as e:
            essais.append(service)
            premiere = str(e).splitlines()[0]
            print("  %-16s REFUSE : %s" % (service, premiere))
            if "422" in premiere:
                print("       422 = parametres invalides. Le plus souvent un")
                print("       secret tronque a la saisie, pas un compte fautif.")
                print("       Reposer :  python -m moteur coffre poser %s --fenetre"
                      % service)
            elif "403" in premiere:
                print("       403 = compte temporairement bloque (trop de")
                print("       tentatives). NE PAS REESSAYER, attendre.")
    if essais:
        print("\nNe pas relancer cette commande en boucle : chaque essai compte.")
    return 1 if essais else 0


# --------------------------------------------------------------------- seance
def cmd_seance(ctx, args) -> int:
    if args.fermer:
        print("Seance refermee." if coffre.fermer_seance(ctx)
              else "Aucune seance ouverte.")
        return 0

    if args.ouvrir:
        if not coffre.ouverture_exigee(ctx):
            print("Aucun mot de passe du logiciel n'est pose : la seance est")
            print("toujours ouverte. En poser un : python -m moteur coffre ouverture")
            return 0
        mdp = _demander("mot de passe du logiciel : ")
        if mdp is None:
            return 2
        try:
            # Pas de proprietaire : cette commande n'a pas de fenetre a
            # garder ouverte. La seance vaut jusqu'a `--fermer`.
            coffre.ouvrir_seance(ctx, mdp)
        except coffre.ErreurCoffre as e:
            print("%s" % e)
            return 1
        finally:
            del mdp
        print("Seance ouverte. Elle n'a pas de duree : elle se referme avec")
        print("`python -m moteur seance --fermer`, ou avec la fenetre qui")
        print("l'aura ouverte.")
        return 0

    s = coffre.seance(ctx)
    if not s.exigee:
        print("Aucun mot de passe du logiciel n'est pose.")
        print("La seance est donc toujours ouverte, et le depot s'en remet a")
        print("ses trois gestes. En poser un : python -m moteur coffre ouverture")
        return 0
    if s.ouverte:
        print("Seance ouverte depuis %s. Pas de duree : elle dure tant que la"
              % s.ouverte_le.replace("T", " "))
        print("fenetre qui l'a ouverte est la%s."
              % (" (processus %d)" % s.proprietaire if s.proprietaire else ""))
        print("Un depot est autorise (il demande encore le mois recopie).")
        return 0
    print("Seance fermee. Aucun depot ne peut partir.")
    print("  python -m moteur seance --ouvrir")
    return 0


# --------------------------------------------------------------- enregistrement
def enregistrer_commandes(sub) -> None:
    o = sub.add_parser("ouverture",
                       help="ce que le logiciel fait a l'ouverture : sauvegarde + retours")
    o.add_argument("--sans-sauvegarde", action="store_true",
                   help="ne pas toucher au Drive")
    o.add_argument("--sans-retours", action="store_true",
                   help="ne pas consulter net-entreprises")
    o.add_argument("--sans-signatures", action="store_true",
                   help="ne pas chercher les reponses « Je signe » dans Gmail")
    o.add_argument("--sans-sources", action="store_true",
                   help="ne pas verifier les sources des donnees (hebdomadaire sinon)")
    o.add_argument("--sans-maj", action="store_true",
                   help="ne pas chercher de nouvelle version au depot")
    o.add_argument("--jours", type=int, default=30,
                   help="profondeur de la recherche de retours (defaut 30)")
    o.add_argument("--pas-avant", dest="pas_avant", type=int, default=0,
                   help="ne rien refaire si la derniere ouverture a moins de N minutes")
    o.add_argument("--veille", action="store_true",
                   help="passage periodique : saute la sauvegarde si rien n'a bouge")
    o.set_defaults(fn=cmd_ouverture)

    sg = sub.add_parser("signatures",
                        help="relever maintenant les contrats signes d'un clic (Gmail)")
    sg.add_argument("--mois", help="ne regarder que les demandes de ce mois (AAAA-MM)")
    sg.add_argument("--json", action="store_true", help="sortie JSON")
    sg.set_defaults(fn=cmd_signatures)

    s = sub.add_parser("sauvegarder",
                       help="envoyer le dossier prive dans le Drive, par differences")
    s.add_argument("--tout", action="store_true",
                   help="tout renvoyer sans comparer les empreintes")
    s.add_argument("--point", action="store_true",
                   help="dire seulement ou en est la derniere sauvegarde")
    s.add_argument("--racine-drive", dest="racine_drive",
                   default=_sauvegarde.RACINE_DRIVE,
                   help="dossier racine dans le Drive (defaut : PuppetPaie)")
    s.set_defaults(fn=cmd_sauvegarder)

    c = sub.add_parser("coffre",
                       help="les mots de passe des organismes, chiffres par Windows")
    c.add_argument("quoi", nargs="?", default="etat",
                   choices=["etat", "poser", "oublier", "ouverture", "verifier"])
    c.add_argument("service", nargs="?",
                   help="net-entreprises ou urssaf (pour poser / oublier)")
    c.add_argument("--fenetre", action="store_true",
                   help="saisir dans une fenetre plutot que dans le terminal "
                        "(a utiliser si la saisie masquee ne capture pas tout)")
    c.set_defaults(fn=cmd_coffre)

    se = sub.add_parser("seance",
                        help="la seance : ce qui autorise un depot sans retaper")
    se.add_argument("--ouvrir", action="store_true",
                    help="demander le mot de passe du logiciel et ouvrir")
    se.add_argument("--fermer", action="store_true", help="refermer tout de suite")
    se.set_defaults(fn=cmd_seance)
