"""Non-regression contre CoolPaie.

Rejoue les declarations deja deposees (DSN et AEM presentes dans `export/`)
et compare, ligne a ligne ou octet a octet, avec ce que le moteur produirait
aujourd'hui. C'est le filet de securite : tant que ces rejeux passent, on sait
que le moteur se comporte comme le logiciel qu'il remplace.

    python -m moteur calibrer
"""
from __future__ import annotations
import datetime as _dt
import difflib
from decimal import Decimal
from pathlib import Path

from .calcul import Engagement, calculer
from .contexte import Contexte
from .util import d

# Emplacement des sorties CoolPaie, relatif a la racine du projet claude/

# SIRET URSSAF : son telepaiement n'est pas calculable depuis la paie, on le
# relit donc dans la DSN de reference plutot que de le deviner (cf. dsn.py).
AUDIENS = "78861779300013"

# Taux de cachet de reference pour rejouer un contrat mixte : l'AEM ne porte
# que le brut total, il faut fixer l'un des deux taux pour deduire l'autre.
TAUX_CACHET_REF = 130.00


# ------------------------------------------------------------------ lecture
def lire_dsn(chemin) -> dict:
    """Extrait d'une DSN deposee ce qu'il faut pour la regenerer."""
    lignes = [l for l in Path(chemin).read_text(encoding="latin-1").splitlines() if l.strip()]
    contrats, versements = {}, {}
    nir_courant = cur = num = siret_versement = None
    entete = {}
    # Taux de PAS tel qu'il a ete declare, par salarie : le rejeu doit
    # reproduire l'identifiant qui etait en vigueur ce mois-la, pas l'etat
    # courant du magasin. Il differe parfois d'un salarie a l'autre dans une
    # meme DSN (avril et mai 2026).
    pas_declare, pas_cur = {}, {}
    for l in lignes:
        k, v = l.split(",", 1)
        v = v.strip("'")
        if k in ("S20.G00.05.005", "S20.G00.05.007"):
            entete[k] = v
        elif k == "S21.G00.30.001":
            nir_courant = v
        elif k == "S21.G00.40.001":
            cur = {"nir": nir_courant, "debut": v}
        elif k == "S21.G00.40.009":
            cur["numero"] = v
            contrats[v] = cur
        elif k == "S21.G00.40.010":
            cur["fin"] = v
        elif k == "S21.G00.40.012":
            # Jours travailles, et non nombre de cachets : voir ARCHITECTURE.md.
            cur["jours_contrat"] = int(float(v))
        elif k == "S21.G00.40.050":
            cur["objet"] = v
        elif k == "S21.G00.51.010":
            num = v
        elif k == "S21.G00.51.011":
            rub = v
        elif k == "S21.G00.51.013" and rub == "001":
            versements.setdefault(num, {})["brut"] = Decimal(v)
        elif k == "S21.G00.53.003" and v == "12":
            versements.setdefault(num, {})["jours"] = int(float(derniere_qte))
        elif k == "S21.G00.53.003" and v == "37":
            versements.setdefault(num, {})["cachets"] = int(float(derniere_qte))
        elif k == "S21.G00.20.001":
            siret_versement = v
        elif k == "S21.G00.20.005" and siret_versement == AUDIENS:
            entete["versement_urssaf"] = float(v)
        elif k == "S21.G00.50.006":
            pas_cur["taux"] = v
        elif k == "S21.G00.50.007":
            pas_cur["type"] = v
        elif k == "S21.G00.50.008":
            pas_declare[nir_courant] = (pas_cur.get("taux", "0.00"),
                                        pas_cur.get("type", "01"), v)
            pas_cur = {}
        elif k == "S21.G00.53.002":
            derniere_qte = v
    for n, c in contrats.items():
        c.update(versements.get(n, {}))
    return {"entete": entete, "contrats": list(contrats.values()),
            "pas": pas_declare}


def engagements_depuis_dsn(ctx, info: dict) -> list:
    """Reconstitue les engagements. Les dates travaillees exactes ne sont pas
    dans la DSN : on en pose autant que de jours declares (bloc 53 type 12),
    ce qui suffit car seul leur nombre est redeclare.

    Limite connue : la DSN ne porte pas la ventilation par rubrique de salaire.
    Un contrat melant cachets et heures s'y rejoue donc comme une rubrique
    unique, ce qui peut donner 1 centime d'ecart sur les cotisations."""
    out = []
    for c in info["contrats"]:
        if "brut" not in c or not c.get("cachets") or not c.get("objet"):
            continue
        sal = next((k for k, s in ctx.salaries.items() if s["nir"] == c["nir"]), None)
        if sal is None:
            continue
        debut = d(c["debut"])
        jours = c.get("jours") or c["cachets"]
        dates = [debut + _dt.timedelta(days=i) for i in range(jours)]
        taux = c["brut"] / c["cachets"]
        out.append(Engagement(salarie=sal, spectacle=c["objet"], dates_travail=dates,
                              lignes=[{"rubrique": "cachet", "quantite": c["cachets"],
                                       "taux": float(taux)}],
                              jours=jours,
                              debut=c["debut"], fin=c["fin"], numero=c["numero"]))
    return out


# ------------------------------------------------------------------ rejeux
def rejouer_dsn(ctx, chemin, ignorer_entete=True) -> list:
    """Renvoie la liste des ecarts (chaines) entre la DSN deposee et celle
    que le moteur produit a partir des memes donnees."""
    from . import dsn
    info = lire_dsn(chemin)
    # LES FICHES TELLES QU'ELLES ETAIENT LE JOUR DU DEPOT. Une adresse, un
    # telephone, une commune de naissance corrigee : la declaration est partie
    # avec ce qu'on savait ce jour-la, et c'est a cela qu'il faut la comparer.
    # Sans ce recalage, le moindre changement de fiche fait echouer TOUS les
    # mois passes -- un filet qui crie a chaque emmenagement finit par etre
    # decroche. Voir `contexte.telle_qu_au`.
    depot = info["entete"].get("S20.G00.05.007")
    if depot:
        ctx = Contexte(ctx.racine, date=depot)
    engs = engagements_depuis_dsn(ctx, info)
    if not engs:
        return ["[ignore] aucun contrat exploitable"]
    mp = info["entete"].get("S20.G00.05.005", "")
    mois = "%s-%s" % (mp[4:8], mp[2:4])
    try:
        paies = [calculer(ctx, e) for e in engs]
        par_nir = {s["nir"]: cle for cle, s in ctx.salaries.items()}
        pas_par_salarie = {par_nir[nir]: v
                           for nir, v in info.get("pas", {}).items()
                           if nir in par_nir}
        produit = dsn.generer(ctx, paies, mois,
                              date_constitution=info["entete"].get("S20.G00.05.007"),
                              pas_par_salarie=pas_par_salarie,
                              versement_urssaf=info["entete"].get("versement_urssaf"))
    except FileNotFoundError as exc:
        return ["[ignore] %s" % exc.args[0].splitlines()[0]]
    except KeyError as exc:
        return ["[ignore] %s" % str(exc).strip('"').splitlines()[0]]
    a = [l for l in produit.replace("\r", "").split("\n") if l]
    b = [l for l in Path(chemin).read_text(encoding="latin-1").replace("\r", "").split("\n") if l]
    ecarts = []
    for l in difflib.unified_diff(b, a, "depose", "genere", lineterm="", n=0):
        if l.startswith(("---", "+++", "@@")):
            continue
        if ignorer_entete and l[1:].startswith("S10.G00.00.00"):
            continue
        ecarts.append(l)
    return ecarts


def rejouer_aem(ctx, chemin) -> list:
    """Regenere chaque enregistrement AEM depuis ses propres champs et compare."""
    from . import aem
    brut_ref = Path(chemin).read_bytes().decode("latin-1")
    ecarts = []
    for i, ligne in enumerate([x for x in brut_ref.split("\r\n") if x.strip()]):
        champs = {k: ligne[a:b] for k, (a, b) in aem.CHAMPS.items()}
        # Les fiches telles qu'elles etaient le jour de la signature : meme
        # raison qu'au rejeu de la DSN, et la date se lit dans
        # l'enregistrement lui-meme.
        ctx = Contexte(ctx.racine, date=champs["date_signature"])
        nir = champs["nir"][:13]
        try:
            sal = next(k for k, s in ctx.salaries.items() if s["nir"] == nir)
        except StopIteration:
            ecarts.append("enr. %d : salarie inconnu (NIR %s)" % (i + 1, nir))
            continue
        cachets = int(champs["nb_cachets"])
        heures = int(champs["nb_heures"])
        jours = int(champs["nb_jours"])
        brut = Decimal(champs["brut_cts"]) / 100
        if not cachets and not heures:
            # Enregistrements de 2021 au format anterieur : ni cachets ni
            # heures exploitables aux positions actuelles.
            ecarts.append("enr. %d : format anterieur, ni cachet ni heure"
                          % (i + 1))
            continue
        # L'AEM ne porte pas les taux, seulement les quantites et le brut : on
        # repartit sur la meme convention que la saisie (cachet d'abord). Le
        # contrat rejoue est ecrit en LIGNES DE PAIE, comme toute saisie :
        # une ligne `cachet`, une ligne `heure`, chacune a son taux.
        if cachets and heures:
            taux_c = Decimal(str(TAUX_CACHET_REF))
            lignes = [{"rubrique": "cachet", "quantite": cachets, "taux": float(taux_c)},
                      {"rubrique": "heure", "quantite": heures,
                       "taux": float((brut - taux_c * cachets) / heures)}]
        elif heures:
            lignes = [{"rubrique": "heure", "quantite": heures, "taux": float(brut / heures)}]
        else:
            lignes = [{"rubrique": "cachet", "quantite": cachets, "taux": float(brut / cachets)}]
        e = Engagement(salarie=sal, spectacle=champs["numero_objet"],
                       dates_travail=[d(champs["date_debut"])],
                       lignes=lignes, jours=jours,
                       debut=d(champs["date_debut"]), fin=d(champs["date_fin"]))
        try:
            p = calculer(ctx, e)
        except (FileNotFoundError, KeyError) as exc:
            ecarts.append("enr. %d : %s" % (i + 1, str(exc).splitlines()[0]))
            continue
        p.taux_chomage_aem = float(Decimal(champs["taux_chomage"]) / 100)
        # Licence en vigueur au mois rejoue : l'historique porte l'ancienne.
        ent_mois = dict(ctx.entreprise, licence_spectacle=ctx.licence(p.engagement.fin))
        refait = aem.enregistrement(p, ent_mois, int(champs["num_attestation"]),
                                    date_emission=d(champs["date_signature"]),
                                    signataire=champs["signataire"])
        if refait != ligne:
            pos = [j for j in range(1000) if refait[j] != ligne[j]]
            ecarts.append("enr. %d : ecart aux positions %s" % (i + 1, pos[:12]))
    return ecarts


# ------------------------------------------------------------------ rapport
def calibrer(ctx, racine_export=None) -> int:
    """Rejoue tout l'historique. Renvoie le nombre de fichiers en ecart."""
    base = Path(racine_export) if racine_export else ctx.export
    print("Rejeu des declarations CoolPaie depuis %s\n" % base.resolve())

    total_ko = 0
    print("--- DSN mensuelles " + "-" * 52)
    fichiers = sorted(base.glob("DSN/*.dsn"))
    for f in fichiers:
        ecarts = rejouer_dsn(ctx, f)
        if not ecarts:
            print("  OK       %s" % f.name)
        elif ecarts[0].startswith("[ignore]"):
            print("  ignore   %s  %s" % (f.name, ecarts[0]))
        else:
            total_ko += 1
            print("  ECART    %s  (%d lignes)" % (f.name, len(ecarts)))
            for l in ecarts[:6]:
                print("           %s" % l)

    print("\n--- AEM V5 " + "-" * 60)
    for f in sorted(base.glob("AEM_EDI/*.txt")):
        ecarts = rejouer_aem(ctx, f)
        reels = [e for e in ecarts if "positions" in e]
        if not ecarts:
            print("  OK       %s" % f.name)
        elif not reels:
            print("  ignore   %s  (%d enr. non rejouables : bareme ou spectacle absent)"
                  % (f.name, len(ecarts)))
        else:
            total_ko += 1
            print("  ECART    %s" % f.name)
            for l in reels[:4]:
                print("           %s" % l)

    print("\n%s" % ("Tous les rejeux passent." if not total_ko
                    else "%d fichier(s) en ecart - voir ci-dessus." % total_ko))
    return total_ko
