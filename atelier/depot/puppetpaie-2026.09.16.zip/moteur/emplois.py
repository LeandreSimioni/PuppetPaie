"""Les metiers du spectacle : ce qu'un engagement declare quand il dit `metier`.

Deux fichiers de donnees, tous deux livres avec le logiciel :

  nomenclature-emplois-ft.json  les 1 236 codes emploi France Travail, avec
                                leur annexe (8 ou 10). GENERE depuis la source.
  emplois-base.json             le catalogue du spectacle vivant : pour chaque
                                metier, tout ce que les declarations demandent
                                (PCS-ESE, libelle officiel, statut, cadre,
                                statut conventionnel) et la ligne de minima.

Un engagement porte `metier: "REG120"` et, s'il veut, `cadre: true|false`.
`resoudre` en tire les six champs que `calcul.emploi_de` pose sur la fiche
salarie pour cet engagement. Ce que l'engagement precise lui-meme (`pcs_ese`,
`statut`...) l'emporte toujours : le catalogue est un defaut, pas une loi.

Un code hors catalogue mais present dans la nomenclature est accepte : on sait
alors son statut (par l'annexe) et son libelle, rien d'autre -- le PCS-ESE
manquera, et `champs` le dira, plutot que d'en inventer un.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

ICI = Path(__file__).parent
BASE = ICI / "emplois-base.json"
NOMENCLATURE = ICI / "nomenclature-emplois-ft.json"

# Les champs de la fiche salarie qu'un metier sait remplir, dans l'ordre ou
# `calcul.emploi_de` les lit.
CHAMPS = ("emploi", "pcs_ese", "code_emploi_ft", "statut",
          "statut_conventionnel", "statut_categoriel_rc")

_cache: dict = {}


def _lire(p: Path) -> dict:
    if p not in _cache:
        _cache[p] = json.loads(p.read_text(encoding="utf-8"))
    return _cache[p]


def base() -> dict:
    """Le catalogue du spectacle vivant, code -> metier."""
    return _lire(BASE)["emplois"]


def nomenclature() -> dict:
    """Tous les codes emploi France Travail, code -> {libelle, annexe}."""
    return _lire(NOMENCLATURE)["emplois"]


def statut_de_l_annexe(annexe: int) -> str:
    return "artiste" if int(annexe) == 10 else "technicien"


def metier(code: str) -> Optional[dict]:
    """Un metier par son code, catalogue d'abord, nomenclature ensuite.

    Rend `None` si le code n'existe nulle part : l'appelant refuse, il
    n'invente pas un emploi.
    """
    if not code:
        return None
    code = code.strip().upper()
    m = base().get(code)
    if m:
        return dict(m, code=code, catalogue=True)
    n = nomenclature().get(code)
    if n:
        return {"code": code, "libelle": n["libelle"].capitalize(),
                "feminin": n["libelle"].capitalize(), "emploi": n["libelle"],
                "annexe": n["annexe"], "statut": statut_de_l_annexe(n["annexe"]),
                "famille": "Hors catalogue", "cadre_par_defaut": False,
                "pcs_ese": None, "statut_conventionnel": None,
                "minima": {}, "catalogue": False}
    return None


def resoudre(code: str, cadre: Optional[bool] = None,
             feminin: bool = False) -> dict:
    """Les six champs declares pour ce metier, prets pour `Engagement`.

    `cadre` a `None` prend le defaut du catalogue. Un cadre porte 40.003 = 01
    et, par la regle CCH-11 de la norme DSN, 40.002 = 04 ; un non-cadre 04 et
    le statut conventionnel du catalogue.

    Leve `ValueError` si le code est inconnu : un metier qui n'existe dans
    aucune nomenclature ne se declare pas.
    """
    m = metier(code)
    if m is None:
        raise ValueError(
            "Metier %r inconnu : ni dans le catalogue (emplois-base.json), ni "
            "dans la nomenclature France Travail (nomenclature-emplois-ft.json)."
            % code)
    est_cadre = m["cadre_par_defaut"] if cadre is None else bool(cadre)
    libelle = (m.get("feminin") if feminin else m.get("libelle")) or m["libelle"]
    return {
        # Le libelle officiel de la nomenclature, en majuscules : c'est lui que
        # la DSN porte en 40.006. CoolPaie feminisait (METTEUSE EN SCENE) ; le
        # libelle feminise reste disponible dans `libelle`, pas dans `emploi`.
        "emploi": m["emploi"],
        "emploi_affichage": libelle,
        "pcs_ese": m.get("pcs_ese"),
        "code_emploi_ft": m["code"],
        "statut": m["statut"],
        "statut_conventionnel": "04" if est_cadre else _statut_non_cadre(m),
        "statut_categoriel_rc": "01" if est_cadre else "04",
    }


def _statut_non_cadre(m: dict) -> Optional[str]:
    """Le statut conventionnel DSN (40.002) d'un metier declare NON cadre.

    Le catalogue porte celui du cas par defaut ; quand on decoche << cadre >>
    sur un metier cadre par defaut, 04 ne vaut plus (CCH-11 le reserve aux
    cadres). Un artiste est 05 ; un technicien suit son niveau 3090 : agent
    de maitrise ou niveau cadre declasse -> 05 (profession intermediaire),
    employe technique -> 07 (ouvrier), employe administratif -> 06.
    """
    st = m.get("statut_conventionnel")
    if st and st != "04":
        return st
    if m["statut"] == "artiste":
        return "05"
    c = m.get("classification_3090") or {}
    niveau, grille = c.get("niveau", ""), c.get("grille", "technique")
    if niveau.startswith(("cadre", "agent")):
        return "05"
    if niveau:
        return "06" if grille == "administratif" else "07"
    return None


def catalogue(tous: bool = False) -> list:
    """La liste pour un ecran ou une commande, groupee par famille.

    `tous` ajoute la nomenclature entiere (cinema, audiovisuel, radio...) en
    fin de liste, famille << Hors catalogue >> : un metier qu'on n'a pas
    prevu reste choisissable, il n'apporte juste pas ses codes annexes.
    """
    out = []
    for code, m in base().items():
        out.append({"code": code, "libelle": m["libelle"], "feminin": m["feminin"],
                    "famille": m["famille"], "statut": m["statut"],
                    "annexe": m["annexe"], "pcs_ese": m["pcs_ese"],
                    "cadre_par_defaut": m["cadre_par_defaut"],
                    "niveau_3090": (m.get("classification_3090") or {}).get("niveau"),
                    "catalogue": True})
    if tous:
        vus = set(base())
        for code, n in nomenclature().items():
            if code in vus:
                continue
            out.append({"code": code, "libelle": n["libelle"].capitalize(),
                        "feminin": n["libelle"].capitalize(),
                        "famille": "Hors catalogue",
                        "statut": statut_de_l_annexe(n["annexe"]),
                        "annexe": n["annexe"], "pcs_ese": None,
                        "cadre_par_defaut": False, "niveau_3090": None,
                        "catalogue": False})
    return out


def familles() -> list:
    """Les familles du catalogue, dans l'ordre ou les montrer : les artistes
    d'abord, parce que c'est le cas de presque toutes les paies."""
    ordre = ["Artistes", "Musique", "Cirque et rue", "Mise en scène et création",
             "Régie et plateau", "Son", "Lumière", "Décor et construction",
             "Costume, coiffure, maquillage", "Production et administration",
             "Audiovisuel dans le spectacle"]
    vues = {m["famille"] for m in base().values()}
    return [f for f in ordre if f in vues] + sorted(vues - set(ordre))


def controler_fiche(d: dict) -> list:
    """Ce qu'une fiche salarie declare, confronte au catalogue.

    Rend des phrases d'avertissement, jamais d'erreur : la fiche peut avoir
    raison contre le catalogue (un PCS choisi en connaissance de cause). Mais
    un code emploi que la nomenclature ignore, ou un statut qui contredit
    l'annexe du code, ce sont des declarations qui partiront fausses.
    """
    avis = []
    code = (d.get("code_emploi_ft") or "").strip().upper()
    if not code:
        return avis
    m = metier(code)
    if m is None:
        avis.append("Code emploi France Travail %r inconnu de la nomenclature "
                    "(S21.G00.40.005)." % code)
        return avis
    if d.get("statut") and d["statut"] != m["statut"]:
        avis.append("Le code emploi %s (%s) est de l'annexe %d, donc %s ; la "
                    "fiche dit %r." % (code, m["libelle"], m["annexe"],
                                       m["statut"], d["statut"]))
    if m.get("pcs_ese") and d.get("pcs_ese") and \
            d["pcs_ese"].lower() != m["pcs_ese"].lower():
        avis.append("PCS-ESE %s pour %s ; le catalogue attend %s (fiche Insee "
                    "de la rubrique)." % (d["pcs_ese"], m["libelle"], m["pcs_ese"]))
    return avis
