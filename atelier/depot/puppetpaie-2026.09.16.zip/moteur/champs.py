"""Ce qu'est une fiche : les champs, leur forme, et ce qui les rend valides.

Aujourd'hui la configuration s'edite a la main dans du JSON, avec des NIR, des
codes PCS-ESE et des dates. C'est l'endroit le plus dangereux du logiciel :
une faute ne se voit pas, elle part en DSN, et c'est un organisme qui la
signale des semaines plus tard -- quand il la signale.

Ce module decrit chaque champ une fois, et cette description sert aux deux
faces : l'interface y prend le libelle, l'aide et le controle de saisie ; la
ligne de commande et le moteur y prennent la verification. Une seule source,
donc pas deux verites.

**Les majuscules sans accents ne se saisissent PAS.** Les formats declaratifs
(AEM, DPAE, DSN) sont a largeur fixe et n'acceptent pas les accents :
`salaries.json` porte donc `MARTIN CLAIRE`, `VARZY`, `2 RUE DES LILAS`. Mais
un contrat imprime « 2 rue des Lilas ».

Ces deux formes ne sont pas deux saisies. **L'humain ecrit « Père Lahaille » ;
c'est le programme qui fabrique `PERE LAHAILLE`.** C'est tout son role : lui
demander de taper des capitales sans accents, ce serait lui faire faire le
travail de la machine. Chaque champ `officiel` porte donc `derive_de`, la
forme lisible dont il se deduit, et n'est jamais propose a la saisie.

**Ce que ce module ne fait pas.** Il ne corrige rien en silence. La derivation
ne s'impose pas a l'existant : CoolPaie ecrivait `ST GEORGES D ORQUES` la ou
une derivation naive donnerait `SAINT GEORGES D ORQUES`, et changer cela
changerait ce qui est declare -- donc casserait le rejeu. `deriver` ne
remplit que ce qui est vide ou ce que l'utilisateur vient de modifier, et
l'interface montre la forme declaree a cote de la forme lisible : on voit ce
qui partira. Une correction silencieuse sur une donnee declarative, c'est
exactement le genre de propagation qu'on a deja paye une fois (le
`_ref_versement` invente, voir le journal du projet).
"""
from __future__ import annotations

import datetime as _dt
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Optional


# --------------------------------------------------------------- description
@dataclass
class Champ:
    cle: str
    libelle: str
    forme: str = "texte"        # voir FORMES
    aide: str = ""
    obligatoire: bool = False
    longueur: Optional[int] = None
    exemple: str = ""
    choix: list = field(default_factory=list)
    declare: bool = True        # part-il dans une declaration ?
    # La forme lisible dont ce champ se DEDUIT. Quand elle est renseignee, le
    # champ n'est jamais saisi a la main : c'est le programme qui le fabrique.
    # Voir `deriver` plus bas -- c'est le coeur du sujet.
    derive_de: Optional[str] = None

    @property
    def calcule(self) -> bool:
        return bool(self.derive_de)


FORMES = {
    "texte":       "texte libre",
    "officiel":    "MAJUSCULES SANS ACCENTS (format declaratif a largeur fixe)",
    "affichage":   "forme lisible, jamais declaree",
    "chiffres":    "chiffres uniquement",
    "date":        "AAAA-MM-JJ",
    "email":       "adresse de courriel",
    "montant":     "nombre decimal",
    "choix":       "une valeur de la liste",
    "booleen":     "oui ou non",
    "structure":   "sous-objet ou liste : edition libre",
    "histoire":    "ce que ce champ valait avant, et jusqu'a quand",
}


# Le champ que toute fiche porte, et qu'aucune ne saisit : la trace datee des
# valeurs DECLAREES qui ont change. Pose par `operations.enregistrer_fiche`,
# relu par `contexte.telle_qu_au`, montre par l'interface -- jamais tape a la
# main, parce qu'il dit ce qui est REELLEMENT PARTI et qu'on ne reecrit pas
# une declaration deposee.
HISTOIRE = Champ(
    "historique", "Ce qui a change", "histoire", declare=False,
    aide="Une valeur declaree ne s'ecrase pas : elle se date. Chaque ligne "
         "dit ce que le champ valait, et jusqu'a quel jour -- c'est ce qui "
         "permet de rejouer une declaration deja deposee sans la reecrire.")


# --------------------------------------------------------------- les fiches
ENTREPRISE = [
    Champ("nom_affichage", "Nom de la compagnie", "affichage",
          obligatoire=True, declare=False,
          aide="Ce qui s'imprime sur les contrats et les bulletins.",
          exemple="Compagnia UEUEUE"),
    Champ("raison_sociale", "Raison sociale declaree", "officiel",
          obligatoire=True, derive_de="nom_affichage",
          exemple="COMPAGNIA UEUEUE"),
    Champ("siren", "SIREN", "chiffres", obligatoire=True, longueur=9),
    Champ("nic", "NIC", "chiffres", obligatoire=True, longueur=5,
          aide="Les cinq chiffres qui suivent le SIREN dans le SIRET."),
    Champ("siret", "SIRET", "chiffres", obligatoire=True, longueur=14,
          aide="SIREN + NIC. Sa cle se verifie (Luhn)."),
    Champ("naf", "Code NAF", "texte", obligatoire=True, longueur=5,
          exemple="9001Z"),
    Champ("code_urssaf", "Code Urssaf (DPAE)", "chiffres", longueur=3,
          aide="Le code de l'Urssaf receptrice (C_URSSAF, annexe II.1 de la "
               "norme DPAE) : 117 pour l'Ile-de-France. Part dans chaque "
               "DPAE. Vide : celui du gabarit (117)."),
    Champ("adresse", "Adresse declaree", "officiel", obligatoire=True,
          derive_de="adresse_affichage"),
    Champ("adresse_affichage", "Adresse", "affichage", declare=False),
    Champ("code_postal", "Code postal", "chiffres", obligatoire=True, longueur=5),
    Champ("commune", "Commune declaree", "officiel", obligatoire=True,
          derive_de="commune_affichage"),
    Champ("commune_affichage", "Commune", "affichage", declare=False),
    Champ("idcc", "IDCC", "chiffres", obligatoire=True, longueur=4,
          aide="Convention collective. 3090 = spectacle vivant prive."),
    Champ("convention_collective", "Convention collective", "texte", declare=False),
    # L'annexe de la CCN 3090 ou l'entreprise se range. Elle ne se declare
    # nulle part : elle sert aux minima conventionnels (moteur/minima.py), qui
    # different d'une annexe a l'autre -- un cachet d'artiste dramatique n'a
    # pas le meme plancher en salle (annexe 1) qu'en tournee (annexe 4). Vide :
    # le moteur prend le plancher le plus bas des annexes candidates, et le dit.
    Champ("annexe_convention", "Annexe de la convention (3090)", "choix",
          choix=["1", "2", "3", "4", "5", "6"], declare=False,
          aide="1 = exploitants de lieux, producteurs ou diffuseurs de "
               "spectacles dramatiques, lyriques, choregraphiques, musique "
               "classique ; 2 = chanson, varietes, jazz, musiques actuelles ; "
               "3 = cabarets ; 4 = producteurs ou diffuseurs de spectacles en "
               "tournee ; 5 = cirque ; 6 = bals. Ne sert qu'aux avertissements "
               "de minima conventionnels ; vide, le moteur prend le plus bas."),
    Champ("urssaf_compte", "Compte Urssaf", "chiffres"),
    Champ("licence_spectacle", "Licence d'entrepreneur", "structure",
          aide="Liste datee : le rejeu doit reproduire ce qui a ete declare, "
               "pas la valeur du jour."),
    Champ("congesspectacles_affiliation", "Conges Spectacles - affiliation", "texte"),
    Champ("congesspectacles_compte", "Conges Spectacles - compte", "texte"),
    Champ("congesspectacles_adherent", "Conges Spectacles - adherent", "texte",
          aide="Numero delivre par Audiens pour editer les certificats."),
    Champ("code_employeur_france_travail", "Code employeur France Travail", "chiffres"),
    Champ("affiliation_france_travail", "Affiliation France Travail", "chiffres",
          aide="Tel qu'il est IMPRIME sur les courriers : un chiffre de plus "
               "que le code employeur."),
    Champ("retraite_complementaire", "Retraite complementaire", "texte"),
    Champ("effectif_moyen", "Effectif moyen", "chiffres", longueur=2),
    Champ("code_convention_dsn", "Code convention DSN", "chiffres", longueur=4),
    Champ("signataire", "Signataire", "structure",
          aide="nom, prenom, fonction. Le nom part dans l'AEM."),
    Champ("declarant_dsn", "Declarant DSN", "structure",
          aide="Qui repond en cas de question sur la declaration."),
    Champ("banque", "Banque", "structure", aide="BIC et IBAN du telepaiement."),
]

SALARIE = [
    Champ("code_salarie", "Code salarie", "chiffres", obligatoire=True,
          aide="Le matricule. Il identifie la personne dans la DSN."),
    Champ("initiales_contrat", "Initiales de contrat", "texte", longueur=2,
          aide="Prefixe des numeros de contrat : PU1.26.13.", declare=False),
    Champ("nom_affichage", "Nom", "affichage", obligatoire=True, declare=False,
          aide="Ecrire comme on l'ecrit : « Père Lahaille ». La forme "
               "declaree se fabrique toute seule.",
          exemple="Père Lahaille"),
    Champ("nom", "Nom declare", "officiel", obligatoire=True,
          derive_de="nom_affichage"),
    Champ("prenom_affichage", "Prenom", "affichage", obligatoire=True,
          declare=False, aide="Sans lui, le contrat imprimait JEROME."),
    Champ("prenom", "Prenom declare", "officiel", obligatoire=True,
          derive_de="prenom_affichage"),
    Champ("nir", "NIR", "chiffres", obligatoire=True, longueur=13,
          aide="Numero de securite sociale, 13 chiffres sans la cle."),
    Champ("nir_cle", "Cle du NIR", "chiffres", obligatoire=True, longueur=2,
          aide="Les deux derniers chiffres. Ils se calculent : 97 - (NIR mod 97)."),
    Champ("date_naissance", "Date de naissance", "date", obligatoire=True),
    Champ("lieu_naissance", "Lieu de naissance declare", "officiel",
          obligatoire=True, derive_de="lieu_naissance_affichage"),
    Champ("lieu_naissance_affichage", "Lieu de naissance", "affichage",
          declare=False),
    Champ("departement_naissance", "Departement de naissance", "texte",
          longueur=2, aide="99 pour une naissance a l'etranger."),
    Champ("pays_naissance", "Pays de naissance", "texte", longueur=2,
          aide="Code ISO a deux lettres. FR pour la France."),
    Champ("code_nationalite_dsn", "Code nationalite DSN", "chiffres", longueur=2),
    Champ("adresse", "Adresse declaree", "officiel", obligatoire=True,
          derive_de="adresse_affichage"),
    Champ("adresse_affichage", "Adresse", "affichage", declare=False),
    Champ("code_postal", "Code postal", "chiffres", obligatoire=True, longueur=5),
    Champ("commune", "Commune declaree", "officiel", obligatoire=True,
          derive_de="commune_affichage"),
    Champ("commune_affichage", "Commune", "affichage", declare=False),
    # DECLARE : il part en DSN (S21.G00.30.018). Le 12/09/2026 il a ete
    # change sans etre date, et le rejeu de juillet a cesse d'etre identique.
    Champ("email", "Courriel", "email",
          aide="Destinataire du bulletin, du certificat CS et de l'AEM papier ; "
               "declare en DSN."),
    Champ("num_conges_spectacles", "Numero Conges Spectacles", "texte",
          aide="Delivre par Audiens au salarie."),
    Champ("emploi_affichage", "Emploi", "affichage", declare=False,
          exemple="Artiste dramatique"),
    Champ("emploi", "Emploi declare", "officiel", obligatoire=True,
          derive_de="emploi_affichage", exemple="ARTISTE DRAMATIQUE"),
    Champ("pcs_ese", "PCS-ESE", "texte", obligatoire=True, longueur=4,
          aide="Nomenclature INSEE. 354C = artiste dramatique. "
               "Verifie au depot (controle CRE) contre le referentiel officiel."),
    Champ("code_emploi_ft", "Code emploi France Travail", "texte",
          exemple="ART120"),
    Champ("statut", "Statut", "choix", choix=["artiste", "technicien"],
          obligatoire=True,
          aide="ATTENTION : l'abattement de 30 % sur les taux (arrete du "
               "24/01/1975) ne vaut QUE pour les artistes."),
    # S21.G00.40.002 -- cahier technique DSN 2026.1, p. 181. Ce n'est PAS la
    # nature du contrat (c'est .007) : c'est le classement au sens de la
    # convention collective. Il etait code en dur a "05" dans dsn.py, ce qui
    # est juste pour un artiste et faux pour tout le reste -- les 151 DSN de
    # l'export le montrent : 05 pour les 146 contrats d'artistes, 07 pour le
    # charge de production, 04 pour la metteuse en scene.
    Champ("statut_conventionnel", "Statut conventionnel (DSN)", "choix",
          choix=["04", "05", "07"],
          aide="04 = autres cadres au sens de la convention collective ; "
               "05 = profession intermediaire (technicien, agent de "
               "maitrise) -- c'est celui des artistes ici ; "
               "07 = ouvriers qualifies et non qualifies. Vide : 05."),
    # S21.G00.40.003. Il voyage avec le precedent : la regle CCH-11 du cahier
    # technique exige 002 dans (03, 04, 08) des que 003 vaut 01. La metteuse
    # en scene de l'export porte bien 04 + 01.
    Champ("statut_categoriel_rc", "Statut categoriel retraite compl. (DSN)",
          "choix", choix=["01", "02", "03", "04"],
          aide="01 = cadre (article 4 et 4bis) ; 04 = non-cadre. Un cadre "
               "garde les taux Urssaf de son statut (artiste ou technicien) "
               "et prend la prevoyance, la retraite et l'Apec des cadres "
               "(bareme, section par_categorie). Si 01, le statut "
               "conventionnel doit etre 03, 04 ou 08 (controle CCH-11 de la "
               "norme DSN). Vide : 04."),
    # La deduction forfaitaire specifique pour frais professionnels (DFS,
    # << abattement >>) : une OPTION du salarie, jamais exercee dans la
    # compagnie, posee ici parce qu'une autre compagnie peut l'exercer
    #. On stocke la CATEGORIE (20 ou 25 %), le taux de
    # l'annee vit dans le bareme -- il baisse chaque annee jusqu'a zero en
    # 2032. Declare : il change l'assiette de ce qui part en DSN.
    Champ("deduction_forfaitaire", "Deduction forfaitaire specifique", "choix",
          choix=["", "20", "25"],
          aide="Abattement pour frais professionnels, au choix du salarie "
               "(accord ecrit). Vide : aucune -- le cas de la compagnie. "
               "20 = musiciens, choristes, chefs d'orchestre, regisseurs de "
               "theatre ; 25 = artistes dramatiques, lyriques, "
               "cinematographiques, choregraphiques. Le taux de l'annee est "
               "dans le bareme (16 et 18 % en 2026, zero en 2032)."),
    Champ("taux_pas", "Taux de PAS", "montant",
          aide="Ne pas saisir a la main : il vient du compte-rendu DGFiP, "
               "par `moteur retours --appliquer`."),
    Champ("date_anciennete", "Date d'anciennete", "date"),
    Champ("actif", "Actif", "booleen", declare=False,
          aide="Une fiche inactive reste consultable et rejouable, mais ses "
               "manques ne bloquent plus : ils redeviennent des erreurs le "
               "jour ou on la reactive."),
    Champ("anniversaire_droits", "Anniversaire des droits", "date",
          declare=False,
          aide="Date de reexamen notifiee par France Travail. Elle prime sur "
               "toute deduction du moteur."),
]

SPECTACLE = [
    Champ("titre", "Titre", "texte", obligatoire=True,
          aide="Tel qu'il est declare a France Travail : il n'existe que la."),
    Champ("numero_objet", "Numero d'objet", "texte", obligatoire=True,
          longueur=12,
          aide="France Travail en delivre un NOUVEAU chaque annee : "
               "216Z... = 2021, 266Z... = 2026."),
    Champ("alias", "Autres noms", "structure", declare=False,
          aide="Ce qu'on peut ecrire dans le chat pour designer ce spectacle."),
    Champ("actif", "Actif", "booleen", declare=False,
          aide="France Travail delivre un numero d'objet par spectacle ET par "
               "annee : celui d'une annee passee ne servira plus a declarer. "
               "Archive, il reste lisible -- les AEM deposees le portent -- "
               "mais sort des listes."),
]

# Toute fiche porte son histoire, et en dernier : c'est une trace, pas une
# saisie, et elle se lit apres le reste.
for _f in (ENTREPRISE, SALARIE, SPECTACLE):
    _f.append(HISTOIRE)

FICHES = {"entreprise": ENTREPRISE, "salarie": SALARIE, "spectacle": SPECTACLE}


# ------------------------------------------------------------- normalisation
# Les regles de forme des rubriques d'identite, cahier technique DSN 2026.1,
# section 3.5 « Tables des caracteres autorises » et section 4 « Controles ».
# Ce ne sont PAS des suppositions : la table est un sous-ensemble d'ISO 8859-1
# ou les accentues sont grises (interdits) tandis que l'apostrophe (0x27) et
# le trait d'union (0x2D) sont autorises. Les exemples du cahier le montrent :
# `S21.G00.30.002,'MARTIN-DUPONT'` et `'DUBOIS DE LACIME DES NOUES--BEAUREGARD
# DE SAINT HAON'`.
SEPARATEURS = " -'."          # les quatre caracteres a usage contraint
CIVILITES = ("MONSIEUR ", "M ", "MADAME ", "MME ", "MLLE ", "MR ")


def sans_accents(texte: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", texte)
                   if unicodedata.category(c) != "Mn")


def normaliser(champ: Champ, valeur):
    """La forme que le champ DEVRAIT avoir. Ne modifie rien : propose."""
    if valeur is None or not isinstance(valeur, str):
        return valeur
    v = valeur.strip()
    if champ.forme == "officiel":
        v = re.sub(r"\s+", " ", sans_accents(v).upper()).strip()
        return v.strip(SEPARATEURS.replace("-", "") + "-")
    if champ.forme == "chiffres":
        return re.sub(r"\s", "", v)
    if champ.forme == "email":
        return v.strip()
    return v


VRAI = ("true", "vrai", "oui", "1", "on", "coche")
FAUX = ("false", "faux", "non", "0", "off", "")


def coercer_booleens(nom_fiche: str, donnees: dict) -> dict:
    """Remet en booleens les cases a cocher arrivees en texte.

    Un formulaire HTML n'envoie que des chaines. `"false"` est une chaine
    VRAIE en Python : une fiche enregistree depuis l'interface se serait
    retrouvee avec `actif: "false"`, que `archivee()` -- qui teste
    `is False` -- aurait lu comme active. La fiche serait restee dans les
    listes en paraissant archivee, ce qui est le pire des deux etats.

    Modifie une COPIE, et ne touche qu'aux champs declares booleens.
    """
    out = dict(donnees)
    for champ in FICHES.get(nom_fiche, ()):
        if champ.forme != "booleen" or champ.cle not in out:
            continue
        v = out[champ.cle]
        if isinstance(v, str):
            t = v.strip().lower()
            if t in VRAI:
                out[champ.cle] = True
            elif t in FAUX:
                out[champ.cle] = False
        elif v is not None:
            out[champ.cle] = bool(v)
    return out


def deriver(nom_fiche: str, donnees: dict, forcer: bool = False) -> dict:
    """Fabrique les formes declarees a partir des formes lisibles.

    C'est le coeur du role du programme : l'humain ecrit « Père Lahaille »,
    la machine ecrit `PERE LAHAILLE` dans l'AEM, la DPAE et la DSN.

    **Par defaut on ne remplit que ce qui est vide.** CoolPaie a declare
    `ST GEORGES D ORQUES` pendant cinq ans la ou une derivation naive donne
    `SAINT GEORGES D ORQUES` : ecraser cela changerait ce qui part aux
    organismes, et casserait le rejeu. `forcer` refait la derivation pour de
    bon -- l'appelant s'en sert quand l'utilisateur vient de modifier la
    forme lisible, donc quand il a voulu le changement.

    Rend le dictionnaire des champs derives : {cle: (avant, apres)}. Vide
    quand il n'y avait rien a faire.
    """
    faits = {}
    for c in FICHES[nom_fiche]:
        if not c.calcule:
            continue
        source = donnees.get(c.derive_de)
        if not source or not isinstance(source, str):
            continue
        attendu = normaliser(c, source)
        actuel = donnees.get(c.cle)
        if actuel == attendu:
            continue
        if actuel and not forcer:
            continue                    # l'existant fait foi : on n'y touche pas
        donnees[c.cle] = attendu
        faits[c.cle] = (actuel, attendu)
    return faits


# Ce que vaut un champ qu'aucune fiche ne porte encore.
#
# Ces deux-la sont NEUFS : `dsn.py` les ecrivait en dur, aucune fiche ne les
# nomme, et pourtant ils sont declares depuis toujours. Le defaut est donc ce
# que l'historique declare -- 05 et 04, les 146 contrats d'artistes -- et non
# une valeur choisie : poser autre chose changerait ce qui part aux organismes
# sans que personne ne l'ait demande.
#
# Il vit ICI et nulle part ailleurs. Le meme defaut ecrit dans `dsn.py` et
# dans l'ecran, c'est deux defauts le jour ou l'un des deux change.
DEFAUTS = {
    "salarie": {"statut_conventionnel": "05", "statut_categoriel_rc": "04"},
}


def defaut(nom_fiche: str, cle: str, sinon=""):
    return DEFAUTS.get(nom_fiche, {}).get(cle, sinon)


def combler_affichage(nom_fiche: str, donnees: dict) -> dict:
    """Donne une forme lisible de depart aux fiches qui n'en ont pas.

    Les fiches d'avant ne portent que la forme declaree : `PERE LAHAILLE`,
    sans `nom_affichage`. On ne peut pas deviner ou vont les accents -- et
    surtout on ne doit pas les inventer. On se contente donc de rendre la
    capitale a une casse de titre : « Pere Lahaille ». L'accent manquant se
    voit, et se corrige d'un clic dans l'interface.

    Rien n'est ecrit : c'est une vue, pas une migration.
    """
    sortie = dict(donnees)
    for c in FICHES[nom_fiche]:
        if not c.calcule or sortie.get(c.derive_de):
            continue
        officiel = sortie.get(c.cle)
        if isinstance(officiel, str) and officiel:
            sortie[c.derive_de] = officiel.title()
    # Un champ neuf que la fiche ne porte pas encore : on montre ce qui est
    # DEJA declare pour lui, pas une case vide. Une case vide ferait croire
    # que rien n'est envoye, alors que le defaut part en DSN a chaque mois.
    for cle, valeur in DEFAUTS.get(nom_fiche, {}).items():
        sortie.setdefault(cle, valeur)
    return sortie


def apercu_derive(nom_fiche: str, donnees: dict) -> dict:
    """Ce qui SERAIT declare, sans rien modifier. Pour l'affichage."""
    return {c.cle: normaliser(c, donnees.get(c.derive_de) or "")
            for c in FICHES[nom_fiche]
            if c.calcule and donnees.get(c.derive_de)}


# -------------------------------------------------------------- verification
def cle_nir(nir: str) -> Optional[str]:
    """La cle de controle d'un NIR : 97 - (NIR mod 97), sur deux chiffres.

    La Corse fait exception : 2A et 2B au 6e-7e rang valent 19 et 18. Sans
    cela, un NIR corse valide serait refuse.
    """
    n = nir.strip().upper()
    if len(n) != 13:
        return None
    n = n.replace("2A", "19", 1) if "2A" in n[5:7] else n
    n = n.replace("2B", "18", 1) if "2B" in n[5:7] else n
    if not n.isdigit():
        return None
    return "%02d" % (97 - int(n) % 97)


def luhn(numero: str) -> bool:
    """Cle du SIRET. Un chiffre faux se verra ici, pas dans un rejet Urssaf."""
    if not numero.isdigit():
        return False
    total, pair = 0, False
    for c in reversed(numero):
        n = int(c)
        if pair:
            n *= 2
            if n > 9:
                n -= 9
        total += n
        pair = not pair
    return total % 10 == 0


def verifier_champ(champ: Champ, valeur) -> Optional[str]:
    """Rend un message si le champ est fautif, sinon None."""
    vide = valeur is None or (isinstance(valeur, str) and not valeur.strip())
    if vide:
        return "obligatoire" if champ.obligatoire else None
    if champ.forme in ("structure", "booleen") or not isinstance(valeur, str):
        return None

    v = valeur.strip()
    if champ.forme == "officiel":
        faute = _faute_de_forme_officielle(v)
        if faute:
            return faute
    if champ.forme == "officiel" and v != sans_accents(v).upper():
        return ("doit etre en MAJUSCULES SANS ACCENTS : ce champ part dans un "
                "format a largeur fixe (AEM, DPAE, DSN). Forme attendue : %s"
                % (sans_accents(v).upper()))
    if champ.forme == "chiffres" and not v.isdigit():
        return "chiffres uniquement"
    if champ.forme == "date":
        try:
            _dt.date.fromisoformat(v)
        except ValueError:
            return "date attendue au format AAAA-MM-JJ"
    if champ.forme == "email" and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", v):
        return "adresse de courriel attendue"
    if champ.forme == "montant":
        try:
            float(v.replace(",", "."))
        except ValueError:
            return "nombre attendu"
    if champ.forme == "booleen":
        return None
    if champ.forme == "choix" and champ.choix and v not in champ.choix:
        return "valeur attendue parmi : %s" % ", ".join(champ.choix)
    if champ.longueur and len(v) != champ.longueur:
        return "%d caracteres attendus, %d saisis" % (champ.longueur, len(v))
    return None


def _faute_de_forme_officielle(v: str) -> Optional[str]:
    """Les regles de position du cahier technique DSN, section 4.

    Elles ne se devinent pas et ne se voient pas a l'oeil : un nom finissant
    par un trait d'union passe la relecture humaine et se fait rejeter des
    semaines plus tard, dans un bilan d'identification.
    """
    if not v:
        return None
    if v[0] in "- ":
        return ("ne peut pas commencer par un trait d'union ni un espace "
                "(cahier technique DSN, section 4)")
    if v[-1] in SEPARATEURS:
        return ("ne peut pas finir par un espace, un trait d'union, une "
                "apostrophe ou un point (cahier technique DSN, section 4)")
    for i in range(len(v) - 1):
        a, b = v[i], v[i + 1]
        if a in SEPARATEURS and b in SEPARATEURS:
            # Deux exceptions prevues : le double trait d'union des noms
            # doubles, et le point suivi d'un espace.
            if a == b == "-" or (a == "." and b == " "):
                continue
            return ("« %s%s » : espace, trait d'union, apostrophe et point "
                    "s'emploient isoles, jamais l'un a cote de l'autre "
                    "(cahier technique DSN, section 4)" % (a, b))
    if v.count("--") > 1:
        return ("le double trait d'union ne peut apparaitre qu'une fois, "
                "entre le premier et le second nom")
    for civilite in CIVILITES:
        if v.upper().startswith(civilite):
            return ("une civilite dans une rubrique d'identite est une "
                    "anomalie DSN : le sexe a sa propre rubrique")
    return None


def verifier_fiche(nom_fiche: str, donnees: dict) -> list:
    """Toutes les anomalies d'une fiche, champ par champ, puis les croisees.

    Rend une liste de {champ, gravite, message}. `gravite` vaut "erreur" quand
    la donnee est certainement fausse, "avertissement" quand elle est
    seulement suspecte : c'est la difference entre refuser un enregistrement
    et le signaler.
    """
    champs = FICHES[nom_fiche]
    donnees = combler_affichage(nom_fiche, donnees)
    anomalies = []
    for c in champs:
        msg = verifier_champ(c, donnees.get(c.cle))
        if not msg:
            continue
        # Un champ derive n'est pas saisi : le signaler a l'humain reviendrait
        # a lui reprocher le travail de la machine. On pointe la forme
        # lisible, qui est ce qu'il peut corriger.
        if c.calcule:
            anomalies.append({
                "champ": c.derive_de, "gravite": "erreur",
                "message": "%s (la forme declaree, « %s », s'en deduit)"
                           % (msg, c.libelle)})
        else:
            anomalies.append({"champ": c.cle, "gravite": "erreur",
                              "message": msg})

    anomalies.extend(_controles_croises(nom_fiche, donnees, champs))

    # Une fiche mise de cote ne doit pas crier. Ses manques restent visibles
    # -- et redeviennent bloquants a la reactivation, ce que le message dit.
    if donnees.get("actif") is False:
        for a in anomalies:
            if a["gravite"] == "erreur":
                a["gravite"] = "avertissement"
                a["message"] += " (fiche inactive : a completer avant toute paie)"
    return anomalies


def _controles_croises(nom_fiche: str, d: dict, champs: list) -> list:
    """Ce qu'aucun champ ne peut verifier seul."""
    out = []

    def dire(champ, gravite, message):
        out.append({"champ": champ, "gravite": gravite, "message": message})

    if nom_fiche == "salarie":
        nir, cle = (d.get("nir") or "").strip(), (d.get("nir_cle") or "").strip()
        attendue = cle_nir(nir) if nir else None
        if attendue and cle and attendue != cle:
            dire("nir_cle", "erreur",
                 "cle incoherente avec le NIR : %s attendue. Un NIR faux passe "
                 "les controles de format et se voit des mois plus tard, dans "
                 "un bilan d'identification." % attendue)
        if nir and len(nir) == 13 and nir[0] not in "1278":
            dire("nir", "avertissement",
                 "un NIR commence par 1 ou 2 (ou 7/8 pour un NIA)")
        if d.get("date_naissance") and len(nir) == 13 and nir[1:5].isdigit():
            an, mo = nir[1:3], nir[3:5]
            née = d["date_naissance"]
            if née[2:4] != an or (mo != "00" and née[5:7] != mo):
                dire("nir", "avertissement",
                     "le NIR annonce %s/%s, la date de naissance dit %s/%s"
                     % (mo, an, née[5:7], née[2:4]))
        # Le code emploi, le statut et le PCS de la fiche, confrontes au
        # catalogue des metiers (moteur/emplois.py). Avertissements, pas
        # erreurs : la fiche peut avoir raison contre le catalogue, mais un
        # statut qui contredit l'annexe du code partirait faux en DSN et
        # dans le bareme.
        from . import emplois as _emplois
        for msg in _emplois.controler_fiche(d):
            dire("code_emploi_ft", "avertissement", msg)

    if nom_fiche == "entreprise":
        siret, siren, nic = (d.get("siret") or ""), (d.get("siren") or ""), (d.get("nic") or "")
        if siret and siren and nic and siret != siren + nic:
            dire("siret", "erreur", "SIRET != SIREN + NIC (%s)" % (siren + nic))
        if siret and len(siret) == 14 and not luhn(siret):
            dire("siret", "erreur", "la cle du SIRET ne tombe pas juste")

    # Ce qui est declare AUJOURD'HUI contre ce que la forme lisible donnerait.
    #
    # C'est ce controle qui a trouve « ST GERORGES D ORQUES » -- une faute de
    # frappe dans un champ declare, invisible autrement puisque personne ne
    # relit une capitale. Le message dit ce qui remplacera quoi : une
    # derivation qui change ce qui part aux organismes ne doit jamais se
    # faire en silence.
    for c in champs:
        if not c.calcule:
            continue
        lisible, declare = d.get(c.derive_de), d.get(c.cle)
        if not lisible or not declare:
            continue
        deduit = normaliser(c, str(lisible))
        if deduit == declare:
            continue
        if _comparable(str(declare)) != _comparable(str(lisible)):
            dire(c.derive_de, "avertissement",
                 "« %s » est declare aujourd'hui, ce qui ne dit pas la meme "
                 "chose. Enregistrer declarera « %s »." % (declare, deduit))
        else:
            dire(c.derive_de, "avertissement",
                 "declare aujourd'hui sous la forme « %s » ; enregistrer "
                 "declarera « %s »." % (declare, deduit))
    return out


# Les abreviations que les formats declaratifs imposent et que la forme
# lisible developpe. Sans elles, « ST GEORGES » et « Saint-Georges »
# passeraient pour deux communes differentes -- et l'avertissement, criant au
# loup a chaque fiche, finirait ignore le jour ou il aurait raison.
ABREVIATIONS = {
    "ST": "SAINT", "STE": "SAINTE", "STS": "SAINTS", "STES": "SAINTES",
    "AV": "AVENUE", "BD": "BOULEVARD", "PL": "PLACE", "RTE": "ROUTE",
    "CHE": "CHEMIN", "IMP": "IMPASSE", "SQ": "SQUARE",
}


def _comparable(texte: str) -> str:
    """Reduit une forme a ce qu'elle DIT, en effacant ce qui n'est que style.

    On enleve les accents, la ponctuation et la casse ; on developpe les
    abreviations ; on laisse tomber l'ordinal apres un nombre (« PARIS 12 »
    et « Paris 12e » sont le meme arrondissement). Ce qui reste different
    l'est vraiment -- une faute de frappe, par exemple.
    """
    mots = re.split(r"[^A-Za-z0-9]+", sans_accents(texte).upper())
    sortie = []
    for m in mots:
        if not m:
            continue
        m = ABREVIATIONS.get(m, m)
        m = re.sub(r"^(\d+)(ER|EME|E)$", r"\1", m)
        sortie.append(m)
    return "".join(sortie)


def description(nom_fiche: str) -> list:
    """La description en dictionnaires -- ce que l'interface consomme."""
    return [{"cle": c.cle, "libelle": c.libelle, "forme": c.forme,
             "aide": c.aide, "obligatoire": c.obligatoire,
             "longueur": c.longueur, "exemple": c.exemple, "choix": c.choix,
             "declare": c.declare, "forme_libelle": FORMES.get(c.forme, ""),
             "calcule": c.calcule, "derive_de": c.derive_de}
            for c in FICHES[nom_fiche]]
