/* L'interface : elle affiche et elle demande, elle ne calcule jamais.
 *
 * Tout chiffre visible ici vient du moteur, par /api. Pas un brut, pas un
 * net, pas un plafond n'est recalcule en JavaScript -- c'est la meme regle
 * que pour Claude : le calcul est du code Python teste et cale au centime,
 * et deux calculateurs, c'est deux resultats le jour ou l'un derive.
 *
 * Les erreurs metier arrivent avec un `type` : c'est sur lui qu'on branche,
 * jamais sur le texte du message.
 */
"use strict";

const JETON = document.body.dataset.jeton;
let ETAT = null;            // configuration + historique, rafraichis a la demande
let SAISIE = null;          // le mois en cours d'edition
let MINUTEUR = null;        // anti-rebond de l'apercu

/* ------------------------------------------------------------- le tuyau */

/* « Failed to fetch » : le serveur ne répond plus.
 *
 * C'est arrivé le 11/09/2026, et le message du navigateur n'apprenait rien —
 * une fiche en cours d'édition n'a pas été enregistrée, sans qu'on sache
 * pourquoi. La page survit à son serveur : elle a l'air de marcher, les
 * champs se remplissent, et seul l'enregistrement échoue.
 *
 * On le dit donc en toutes lettres, et on le dit de façon PERSISTANTE : un
 * message qui s'efface au bout de six secondes n'aide pas quelqu'un qui
 * était en train de taper. */
let SERVEUR_PERDU = false;

function serveurPerdu() {
  if (SERVEUR_PERDU) return;
  SERVEUR_PERDU = true;
  const zone = document.getElementById("veille");
  zone.hidden = false;
  zone.classList.add("souci");
  document.getElementById("veille-texte").innerHTML =
    "<b>Le serveur ne répond plus.</b> La fenêtre PuppetPaie a été fermée, ou le "
    + "terminal qui la faisait tourner. <b>Rien de ce qui est à l'écran n'est "
    + "enregistré.</b> Relancer PuppetPaie, puis recharger cette page.";
  document.getElementById("veille-maintenant").hidden = true;
}

async function api(route, charge = {}) {
  let r;
  try {
    r = await fetch("/api/" + route + "?jeton=" + encodeURIComponent(JETON), {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Jeton": JETON },
      body: JSON.stringify(charge),
    });
  } catch (e) {
    // `fetch` ne rejette que sur un échec réseau — le serveur est parti.
    serveurPerdu();
    throw new Error("Le serveur PuppetPaie ne répond plus. Rien n'a été enregistré.");
  }
  const d = await r.json();
  if (!d.ok) { const e = new Error(d.erreur.message); e.detail = d.erreur; throw e; }
  return d.resultat;
}

function dire(texte, type) {
  const el = document.getElementById("message");
  el.textContent = texte;
  el.className = "message" + (type === "erreur" ? " erreur" : "");
  clearTimeout(dire._t);
  dire._t = setTimeout(() => el.classList.add("cachee"), 6000);
}

const echapper = (s) => String(s ?? "").replace(/[&<>"]/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* ------------------------------------------------------------ navigation */
document.querySelectorAll(".onglets button").forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll(".onglets button").forEach((x) => x.classList.remove("actif"));
    b.classList.add("actif");
    document.querySelectorAll(".vue").forEach((v) => v.classList.add("cachee"));
    document.getElementById("vue-" + b.dataset.vue).classList.remove("cachee");
    if (b.dataset.vue === "historique") dessinerHistorique();
    if (b.dataset.vue === "configuration") dessinerConfig();
  };
});

/* =======================================================================
   PAIE
   ===================================================================== */
function moisCourant() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
}

/** La rubrique par son code, dans le catalogue rendu par le moteur. */
function rubriqueDe(code) {
  return (ETAT.rubriques || []).find((r) => r.code === code);
}

/** Le déroulant des rubriques : les cochées d'abord, le moteur a déjà trié.
 *  Un trait sépare ce que la compagnie utilise du reste, qui reste offert. */
function optionsRubriques(choisie) {
  const actives = (ETAT.rubriques || []).filter((r) => r.active);
  const autres = (ETAT.rubriques || []).filter((r) => !r.active);
  const opt = (r) => `<option value="${echapper(r.code)}" ${r.code === choisie ? "selected" : ""}>
      ${echapper(r.libelle)}</option>`;
  if (!actives.length) return autres.map(opt).join("");
  return actives.map(opt).join("")
    + `<optgroup label="── autres rubriques ──">` + autres.map(opt).join("") + `</optgroup>`;
}

/** Une ligne de rémunération : une rubrique, une quantité, un taux.
 *  Le champ « heures » n'apparaît que si la rubrique le demande — une journée
 *  de 5 h, une répétition de 3 h. Un cachet ne le demande pas : ses 12 heures
 *  viennent du règlement, pas de nous. */
function ligneRubrique(l = {}) {
  const div = document.createElement("div");
  div.className = "rubrique";
  const code = l.rubrique || (ETAT.rubriques || [])[0]?.code || "cachet";
  // Une ligne neuve part du dernier taux donné, pas d'un champ vide : c'est
  // là que « on met de base le dernier taux » se voit.
  if (l.taux === undefined || l.taux === null || l.taux === "") l = { ...l, taux: DERNIER_TAUX };
  /* TOUT SUR LA MÊME LIGNE, et elle se lit comme une phrase :

       1 cachet à 130 €   Théâtre de la Ville   le 12
       4 cachets à 130 €  Théâtre 71            le 14 15 17 18

     « Pour moi tout est sur la même ligne : les dates, les lieux et le
     cachet » (12/09/2026). C'est la bonne maille, et elle règle le lieu par
     cachet d'un seul coup : une ligne de paie EST un groupe de cachets, à un
     taux, à un endroit, à des dates. Le lieu n'a plus à être rattaché à une
     date d'un côté et à un engagement de l'autre — il est là, sur la ligne
     qui le porte.

     Ce qui a disparu au passage : le rappel d'unité en fin de ligne
     (« cachet », qui redisait le déroulant) et les « 12 h » du cachet, qui
     sont une constante du règlement. Ce qui reste en mots : « à » et « € »,
     les deux seuls qui disent lequel des nombres est le taux. */
  div.innerHTML = `
    <input class="r-quantite" type="number" min="0" step="0.5" placeholder="qté"
           value="${l.quantite ?? ""}">
    <select class="r-code">${optionsRubriques(code)}</select>
    <span class="r-mot discret">à</span>
    <input class="r-taux" type="number" min="0" step="0.01" placeholder="taux"
           value="${l.taux ?? ""}">
    <span class="r-mot discret">€</span>
    <input class="r-lieu" placeholder="lieu — figure au contrat"
           value="${echapper(l.lieu || "")}">
    <span class="r-mot discret">le</span>
    <!-- LES JOURS SE COCHENT DANS UN CALENDRIER (15/09/2026 : « plus
         esthétique et clair que de taper 12, 24, 26 »). Le bouton dit les
         jours cochés ; le champ caché garde l'écriture « 14 15 17 18 » que
         tout le reste de la page lit (joursDe). Les jours cochés dans un
         mois SUIVANT sont le planning de la ligne (data-planning). -->
    <button type="button" class="r-jours-btn" title="cocher les jours dans le calendrier">—</button>
    <input class="r-jours" type="hidden"
           value="${echapper((l.dates || []).map((x) => +jourDe(x).slice(8)).join(" "))}">
    <input class="r-heures" type="number" min="0" step="0.5" placeholder="heures"
           value="${l.heures ?? ""}">
    <button class="supprimer" title="retirer cette ligne">&times;</button>`;
  const majAffichage = () => {
    const r = rubriqueDe(div.querySelector(".r-code").value);
    const veutHeures = !!r && r.saisie.includes("heures");
    // `.cachee` et non l'attribut `hidden` : la feuille de style pose
    // `input { display: block }`, qui l'emporterait sur le defaut du
    // navigateur. Le champ resterait visible sans qu'on comprenne pourquoi.
    div.querySelector(".r-heures").classList.toggle("cachee", !veutHeures);
  };
  div.querySelector(".r-code").onchange = () => { majAffichage(); rafraichirApercu(); };
  div.querySelector(".supprimer").onclick = () => { div.remove(); rafraichirApercu(); };
  div.querySelectorAll("input").forEach((c) => { c.oninput = rafraichirApercu; });
  // Taper un taux ici, c'est décider du prochain : le suivant s'en servira.
  div.querySelector(".r-taux").oninput = () => {
    const v = div.querySelector(".r-taux").value;
    if (v !== "" && +v > 0) DERNIER_TAUX = +v;
    rafraichirApercu();
  };
  /* LES JOURS COMPTENT LES CACHETS. Taper « 14 15 17 18 » sur une ligne de
     cachets, c'est dire quatre cachets — les recompter à la main serait un
     deuxième endroit où se tromper, et l'AEM déclare les deux (nombre de
     cachets ET nombre de jours). On ne le fait QUE pour les rubriques dont
     l'unité est le cachet : six heures de masterclass tiennent en un jour, et
     là la quantité et les dates disent deux choses différentes. */
  div.querySelector(".r-jours").oninput = () => {
    const r = rubriqueDe(div.querySelector(".r-code").value);
    if (r && r.unite === "cachet") {
      const n = joursDe(div.querySelector(".r-jours")).length;
      div.querySelector(".r-quantite").value = n || "";
    }
    rafraichirApercu();
  };
  div.dataset.planning = JSON.stringify((l.planning || []).map(jourDe).filter(Boolean));
  div.querySelector(".r-jours-btn").onclick = (ev) => {
    ev.preventDefault();
    ouvrirCalendrier(div);
  };
  majJoursBouton(div);
  majAffichage();
  return div;
}

/* ------------------------------------------------------------ le calendrier
   « J'aime bien l'idée de pouvoir cocher les dates dans un petit planning,
   plus esthétique et clair que de taper 12, 24, 26. Du coup avec une flèche
   on pourrait aller au mois suivant. Avec un petit avertissement : vous êtes
   en train de créer un contrat sur plusieurs mois. Valider ? » (15/09/2026)

   Un mois à la fois, sous la ligne de paie. Les jours du mois de la saisie
   se cochent comme jours joués (ils comptent les cachets) ; ceux des mois
   suivants sont le PLANNING de la ligne — pas payés ce mois-ci, mais connus :
   le contrat imprimé les liste, la fin du contrat se cale sur le dernier, et
   « reprendre un contrat en cours » les retrouve déjà cochés le mois venu.
   On ne remonte pas avant le mois de la saisie : un cachet d'octobre se paie
   dans le fichier d'octobre. */
const JOURS_SEMAINE = ["L", "M", "M", "J", "V", "S", "D"];
const MOIS_ABR = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août",
                  "sept.", "oct.", "nov.", "déc."];

function planningDe(ligne) {
  try { return JSON.parse(ligne.dataset.planning || "[]"); } catch (e) { return []; }
}

/** Ce que dit le bouton : « le 12, 13 », puis le planning « +1 nov. +3 déc. ». */
function majJoursBouton(ligne) {
  const b = ligne.querySelector(".r-jours-btn");
  if (!b) return;
  const jours = joursDe(ligne.querySelector(".r-jours"));
  const plan = planningDe(ligne);
  const parMois = {};
  plan.forEach((iso) => { const m = iso.slice(0, 7); parMois[m] = (parMois[m] || 0) + 1; });
  let texte = jours.length ? jours.join(", ") : "— jours —";
  const suite = Object.keys(parMois).sort()
    .map((m) => `+${parMois[m]} ${MOIS_ABR[+m.slice(5, 7) - 1]}`).join(" ");
  b.textContent = texte + (suite ? " " + suite : "");
  b.classList.toggle("vide", !jours.length);
  b.classList.toggle("planning", !!suite);
}

function fermerCalendriers() {
  document.querySelectorAll(".calendrier").forEach((c) => c.remove());
}

function ouvrirCalendrier(ligne) {
  fermerCalendriers();
  const mois = document.getElementById("mois").value;
  if (!mois) { dire("Choisir le mois d'abord.", "erreur"); return; }
  const bloc = ligne.closest(".engagement");
  const enCours = bloc && bloc.classList.contains("en-cours");
  const fin = bloc ? bloc.querySelector(".e-fin").value : "";
  const cal = document.createElement("div");
  cal.className = "calendrier";
  ligne.appendChild(cal);
  // Sous le bouton des jours, sans déborder de la ligne.
  const btn = ligne.querySelector(".r-jours-btn");
  cal.style.left = Math.max(0, Math.min(btn.offsetLeft, ligne.clientWidth - 272)) + "px";
  let vue = mois;                       // le mois affiché, AAAA-MM
  let attente = null;                   // un jour de planning qui attend « Valider »

  const dessiner = () => {
    const an = +vue.slice(0, 4), mo = +vue.slice(5, 7);
    const nb = new Date(an, mo, 0).getDate();
    const premier = (new Date(an, mo - 1, 1).getDay() + 6) % 7;   // lundi = 0
    const jours = new Set(joursDe(ligne.querySelector(".r-jours")));
    const plan = new Set(planningDe(ligne));
    const ici = vue === mois;
    let cases = "";
    for (let i = 0; i < premier; i++) cases += `<span class="c-vide"></span>`;
    for (let j = 1; j <= nb; j++) {
      const iso = `${vue}-${String(j).padStart(2, "0")}`;
      const coche = ici ? jours.has(j) : plan.has(iso);
      const horsContrat = enCours && fin && iso > fin;
      cases += `<button type="button" class="c-jour ${coche ? (ici ? "joue" : "prevu") : ""}
        ${horsContrat ? "hors" : ""}" data-iso="${iso}" data-j="${j}"
        ${horsContrat ? "disabled title=\"après la fin du contrat\"" : ""}>${j}</button>`;
    }
    const nJoues = jours.size, nPlan = plan.size;
    cal.innerHTML = `
      <div class="c-tete">
        <button type="button" class="c-prec" ${ici ? "disabled" : ""} title="mois précédent">‹</button>
        <b>${echapper(moisEnClair(vue))}</b>
        <button type="button" class="c-suiv" title="mois suivant">›</button>
      </div>
      <div class="c-grille">
        ${JOURS_SEMAINE.map((x) => `<span class="c-sem">${x}</span>`).join("")}
        ${cases}
      </div>
      ${attente ? `
        <div class="c-avert">
          <b>Vous êtes en train de créer un contrat sur plusieurs mois</b>
          — du ${echapper(jjmmaaaa(debutDuBloc(bloc) || mois + "-01"))} au
          ${echapper(jjmmaaaa(attente))}. Les cachets de ${echapper(moisEnClair(attente.slice(0, 7)))}
          se paieront dans le fichier de ce mois-là (« reprendre un contrat en
          cours » les retrouvera cochés) ; ce mois-ci partent le contrat et la
          DPAE pour le contrat entier. Valider ?
          <div class="c-actions">
            <button type="button" class="secondaire c-annuler">Annuler</button>
            <button type="button" class="primaire c-valider">Valider</button>
          </div>
        </div>` : `
        <div class="c-pied">
          <span class="discret">${ici ? "jours joués ce mois-ci" : "planning : payé dans son mois"}
            · ${nJoues} joué${nJoues > 1 ? "s" : ""}${nPlan ? `, ${nPlan} prévu${nPlan > 1 ? "s" : ""}` : ""}</span>
          <button type="button" class="secondaire c-ok">OK</button>
        </div>`}`;
    cal.querySelector(".c-prec").onclick = () => { vue = moisPrecedent(vue); attente = null; dessiner(); };
    cal.querySelector(".c-suiv").onclick = () => { vue = moisSuivant(vue); attente = null; dessiner(); };
    const ok = cal.querySelector(".c-ok");
    if (ok) ok.onclick = fermerCalendriers;
    const valider = cal.querySelector(".c-valider");
    if (valider) valider.onclick = () => {
      bloc.dataset.pluriOk = "1";
      const iso = attente; attente = null;
      basculerPlanning(ligne, iso);
      dessiner();
    };
    const annuler = cal.querySelector(".c-annuler");
    if (annuler) annuler.onclick = () => { attente = null; dessiner(); };
    cal.querySelectorAll(".c-jour:not([disabled])").forEach((b) => {
      b.onclick = () => {
        if (ici) {
          basculerJour(ligne, +b.dataset.j);
        } else {
          const iso = b.dataset.iso;
          const dejaPluri = (bloc && bloc.dataset.pluriOk === "1") || enCours
            || planningDuBloc(bloc).length || (fin && fin.slice(0, 7) > mois);
          if (!planningDe(ligne).includes(iso) && !dejaPluri) { attente = iso; dessiner(); return; }
          basculerPlanning(ligne, iso);
        }
        dessiner();
      };
    });
  };
  dessiner();
  // Fermer en cliquant ailleurs, ou à la touche Échap.
  setTimeout(() => {
    const dehors = (ev) => {
      if (!cal.isConnected) { document.removeEventListener("click", dehors); return; }
      // `composedPath` et non `contains` : un clic sur un jour redessine la
      // grille, et le bouton cliqué n'est déjà plus dans la page quand on
      // arrive ici -- `contains` dirait « dehors » et refermerait tout.
      const chemin = ev.composedPath ? ev.composedPath() : [];
      if (!chemin.includes(cal) && ev.target !== ligne.querySelector(".r-jours-btn")) {
        fermerCalendriers(); document.removeEventListener("click", dehors);
      }
    };
    document.addEventListener("click", dehors);
  }, 0);
  cal.onkeydown = (ev) => { if (ev.key === "Escape") fermerCalendriers(); };
}

/** Coche ou décoche un jour du mois de la saisie : la ligne compte ses
 *  cachets, comme quand on tapait les jours. */
function basculerJour(ligne, j) {
  const champ = ligne.querySelector(".r-jours");
  const jours = new Set(joursDe(champ));
  if (jours.has(j)) jours.delete(j); else jours.add(j);
  champ.value = [...jours].sort((a, b) => a - b).join(" ");
  champ.dispatchEvent(new Event("input"));
  majJoursBouton(ligne);
}

/** Coche ou décoche un jour de planning (un mois suivant), et cale la fin
 *  du contrat sur le dernier jour prévu — sauf sur un contrat en cours, dont
 *  la fin a été fixée par son premier mois. */
function basculerPlanning(ligne, iso) {
  const plan = new Set(planningDe(ligne));
  if (plan.has(iso)) plan.delete(iso); else plan.add(iso);
  ligne.dataset.planning = JSON.stringify([...plan].sort());
  majJoursBouton(ligne);
  const bloc = ligne.closest(".engagement");
  if (bloc && !bloc.classList.contains("en-cours")) {
    const tout = planningDuBloc(bloc);
    const finChamp = bloc.querySelector(".e-fin");
    const dernier = tout.length ? tout[tout.length - 1] : "";
    if (dernier && (!finChamp.value || finChamp.value < dernier || finChamp.value === bloc.dataset.finAuto)) {
      finChamp.value = dernier; bloc.dataset.finAuto = dernier;
    } else if (!dernier && bloc.dataset.finAuto && finChamp.value === bloc.dataset.finAuto) {
      finChamp.value = ""; bloc.dataset.finAuto = "";
    }
    majContrat(bloc);
  }
  rafraichirApercu();
}

/** Tout le planning d'un bloc, toutes lignes confondues, trié. */
function planningDuBloc(bloc) {
  const vus = new Set();
  if (bloc) bloc.querySelectorAll(".rubrique").forEach((r) => planningDe(r).forEach((x) => vus.add(x)));
  return [...vus].sort();
}

function debutDuBloc(bloc) {
  if (!bloc) return "";
  const jours = joursDuBloc(bloc);
  return bloc.querySelector(".e-debut").value || jours[0] || "";
}

function moisPrecedent(mois) {
  const an = +mois.slice(0, 4), mo = +mois.slice(5, 7);
  return mo === 1 ? `${an - 1}-12` : `${an}-${String(mo - 1).padStart(2, "0")}`;
}

/** Les jours tapés « 14 15 17 18 », en nombres, sans doublon et triés. */
function joursDe(champ) {
  const vus = new Set();
  String(champ.value).split(/[^0-9]+/).filter(Boolean).forEach((x) => vus.add(+x));
  return [...vus].sort((a, b) => a - b);
}

/** Les lignes viennent du moteur, y compris pour une saisie ancienne écrite
 *  en `cachets` : c'est lui qui dit ce qu'il a compris, la page ne redevine
 *  rien. Une saisie neuve n'en a pas encore — on offre alors une ligne vide. */
function lignesDe(e) {
  return (e.lignes && e.lignes.length) ? e.lignes : [{}];
}

/* LE DERNIER TAUX DONNÉ, et c'est tout ce qui reste du « par défaut du mois ».
   « Pas besoin de taux de cachet : on met de base le dernier taux donné.
   Simple et efficace » (12/09/2026). Il se reprend de la saisie chargée, et
   il suit ce qu'on tape : la ligne de paie suivante, et le mois suivant,
   partent de là. Il continue d'être écrit dans le fichier — le moteur s'en
   sert comme défaut d'un engagement qui ne dit pas son taux — mais plus
   personne n'a à le saisir. */
let DERNIER_TAUX = 130;
let SAISIE_DATE_PAIEMENT = "";   // celle du fichier, ou la fin du mois

/** Le dernier jour du mois. La date de paiement, qui ne s'affiche plus :
 *  « c'est juste écrit dans le contrat, la fin du mois ». */
function finDuMois(mois) {
  const [an, mo] = String(mois).split("-").map(Number);
  return new Date(an, mo, 0).toISOString().slice(0, 10);
}

/** Ce qui s'applique au mois, quand un engagement ne dit rien de lui-même.
 *  Il n'en reste que le taux : le lieu appartient au cachet, la date de
 *  paiement est la fin du mois, et le spectacle n'a jamais eu de défaut. */
function defautsDuMois() {
  return { taux_cachet: DERNIER_TAUX, lieu: "" };
}

function titreSpectacle(cle) {
  if (!cle) return "aucun spectacle";
  const s = (ETAT.spectacles || []).find((x) => x.cle === cle);
  return s ? s.titre : cle;
}

/* =======================================================================
   LE LIEU ET LES JOURS SONT SUR LA LIGNE DE PAIE
   =======================================================================
   Décidé le 11/09/2026 sur un exemple réel — quatre Teresina dans le
   mois, un à Berlin, un à Paris, deux à Varzy — écrit le 12, puis recadré par
   lui le même jour, et c'est le recadrage qui a tout simplifié :

     « Pour moi tout est sur la même ligne : les dates, les lieux et le
       cachet. Du coup on peut faire 1 cachet à 130 € au Théâtre de la Ville
       le 12. Ou 4 cachets à 130 € au Théâtre 71 le 14, 15, 17, 18. »

   La première version posait le lieu sur la DATE, avec un héritage à trois
   étages (la date, l'engagement, le mois) et une zone dépliante sous chaque
   engagement pour les cas où les villes diffèrent. Ça marchait, et c'était
   une mécanique à expliquer. Sa maille à lui n'a pas besoin d'héritage : une
   ligne de paie EST un groupe de cachets, à un taux, à un endroit, à des
   dates. Deux villes, deux lignes. Rien à hériter, rien à déplier, rien à
   trancher entre « ce qui est tapé » et « ce qui est repris ».

   C'est TOUJOURS UNE SEULE PAIE : même spectacle, donc même numéro d'objet,
   donc un contrat, un bulletin, une AEM. Les jours de l'engagement sont la
   réunion des jours de ses lignes — `joursDuBloc` ici, `dates_engagement`
   dans le moteur, et les deux composent la même liste.

   Le lieu ne se déclare NULLE PART : ni DSN, ni AEM, ni DPAE. Il figure au
   contrat, qui groupe les dates par lieu, et nulle part ailleurs. */

/** Le jour d'une date écrite d'une façon ou de l'autre — « 2026-10-02 » ou
 *  {"jour": "2026-10-02", "lieu": "Berlin"}. */
/** Le catalogue des métiers, tel que le moteur le rend (route « etat »),
 *  groupé par famille dans SON ordre. La page ne trie pas, elle affiche. */
function metierDe(code) {
  return (ETAT.emplois || []).find((m) => m.code === code) || null;
}

function optionsMetiers(choisi) {
  const familles = ETAT.familles_emplois || [];
  const parFamille = {};
  (ETAT.emplois || []).forEach((m) => { (parFamille[m.famille] ||= []).push(m); });
  let html = `<option value="">— celui de la fiche —</option>`;
  familles.forEach((f) => {
    if (!parFamille[f]) return;
    html += `<optgroup label="${echapper(f)}">` + parFamille[f].map((m) =>
      `<option value="${echapper(m.code)}">${echapper(m.libelle)}${m.cadre_par_defaut ? " (cadre)" : ""}</option>`)
      .join("") + `</optgroup>`;
  });
  // Un code hors catalogue mais présent dans le fichier reste proposé tel
  // quel : on ne perd pas un métier parce que l'écran ne le connaît pas.
  if (choisi && !metierDe(choisi)) html += `<option value="${echapper(choisi)}">${echapper(choisi)}</option>`;
  return html;
}

function jourDe(x) {
  return (x && typeof x === "object") ? String(x.jour || "") : String(x || "");
}

/** Un engagement : QUI, QUOI, QUAND, COMBIEN.
 *
 *  Le « quoi » était en haut du formulaire, une fois pour le mois. C'est juste
 *  la plupart du temps, et faux exactement quand ça compte : deux spectacles,
 *  deux lieux dans le même mois.
 *
 *  LE SPECTACLE N'EST PAS TRAITÉ COMME LES AUTRES, et c'est délibéré. Le lieu
 *  et le taux se répètent d'une paie à l'autre : ils ont un défaut de mois, et
 *  l'engagement s'en écarte quand il le faut. Le spectacle, lui, EST la raison
 *  d'avoir plusieurs paies — un contrat porte un numéro d'objet, donc un
 *  spectacle, et le mois en compte plusieurs. Il est donc une case de cet
 *  engagement, toujours visible, sans défaut et sans héritage. */
function ligneEngagement(e = {}) {
  const div = document.createElement("div");
  div.className = "engagement";
  const actifs = ETAT.salaries || [];
  // QUI : une liste à COCHER, pas un menu, et UN bloc pour tous les cochés.
  //
  // L'ancienne option « Les deux » qui dédoublait le bloc à la sélection
  // était taillée pour une compagnie à deux têtes, et dédoublait trop tôt.
  // La demande : « il faut pouvoir cocher dedans, x Anastasia
  // x Léandre, pas d'option les deux d'un coup » ; puis : « le dédoublement
  // doit se faire une fois validé, pas avant — c'est ce qui va me faire
  // aller vite quand j'ai plusieurs employés pour le même spectacle avec la
  // même paye ». Donc : on coche qui on veut, on saisit UNE fois, on valide
  // — et LÀ le bloc se démultiplie, un bloc par salarié (validerPlusieurs).
  //
  // Le moteur, lui, ne connaît toujours qu'un salarié par engagement : c'est
  // saisieCourante qui écrit un engagement par salarié coché, et chargerMois
  // qui regroupe au retour ce qui est identique et pas encore validé.
  const voulus = new Set(e.salaries || (e.salarie ? [e.salarie] : []));
  const connus = new Set(actifs.map((s) => s.cle));
  const cases = actifs.map(
    (s) => `<label><input type="checkbox" class="e-qui-case" value="${echapper(s.cle)}"
       ${voulus.has(s.cle) ? "checked" : ""}> ${echapper(s.libelle)}</label>`)
    // Un salarié du fichier absent des actifs (fiche mise de côté) garde sa
    // case, cochée : on ne perd pas une paie parce qu'on a archivé quelqu'un.
    .concat([...voulus].filter((c) => !connus.has(c)).map(
      (c) => `<label><input type="checkbox" class="e-qui-case" value="${echapper(c)}"
         checked> ${echapper(c)} <span class="discret">(fiche mise de côté)</span></label>`))
    .join("");
  div.innerHTML = `
    <div class="ligne1">
      <!-- Pas de « + » ici : une fiche neuve se crée dans Configuration.
           La saisie d'une paie doit rester simple et agréable ; on y choisit,
           on n'y administre pas (13/09/2026). -->
      <div class="champ">Salarié
        <details class="e-qui">
          <summary class="vide">— cocher —</summary>
          <div class="e-qui-liste">${cases}</div>
        </details>
      </div>
      <label>Spectacle
        <select class="e-spectacle"></select></label>
      <!-- LE MÉTIER DE CE CONTRAT. Vide : celui de la fiche (le cas général).
           Choisi : le moteur pose d'un coup code emploi, PCS, libellé, statut
           et classement DSN (moteur/emplois.py). La case « cadre » suit le
           défaut du catalogue et se décoche. -->
      <label class="e-metier-bloc" title="le métier de ce contrat, s'il diffère de la fiche">Métier
        <select class="e-metier"></select></label>
      <label class="coche e-cadre-bloc" title="cadre pour la retraite complémentaire (DSN 40.003 = 01)">
        <input type="checkbox" class="e-cadre"> cadre</label>
    </div>
    <!-- Les jours et le lieu ne sont plus ici : ils sont sur chaque ligne de
         paie, qui porte désormais la phrase entière — « 4 cachets à 130 € au
         Théâtre 71 le 14 15 17 18 ». Voir ligneRubrique(). -->
    <div class="rubriques"></div>
    <button class="ajouter-rubrique discret">+ une ligne de paie</button>
    <!-- LE CONTRAT, replié : « du 12/10/2026 au 20/12/2026 », préréglé sur
         le premier et le dernier jour joué. On l'ouvre pour une seule chose :
         allonger la date de fin quand le contrat se poursuit le mois suivant
         (contrats sur plusieurs mois, 15/09/2026). Le numéro y apparaît, en
         lecture seule, une fois le mois produit. -->
    <details class="e-contrat">
      <summary></summary>
      <div class="e-contrat-champs">
        <label>Début du contrat <input type="date" class="e-debut"></label>
        <label>Fin du contrat <input type="date" class="e-fin"></label>
        <span class="e-numero discret"></span>
      </div>
      <p class="note e-contrat-note">Vides : le contrat va du premier au dernier
        jour coché — planning compris, quand on a coché des jours dans les mois
        suivants depuis le calendrier d'une ligne. Un contrat qui se poursuit :
        ses cachets suivants se paient dans le mois suivant (« + reprendre un
        contrat en cours » les retrouve cochés), la DPAE et le contrat imprimé
        ne partent qu'avec ce mois-ci, le certificat Congés Spectacles à la
        fin du contrat.</p>
    </details>
    <div class="resolu"></div>
    <div class="avis"></div>
    <div class="etats"></div>`;

  const selSpec = div.querySelector(".e-spectacle");
  selSpec.innerHTML = `<option value="">— à choisir —</option>`
    + (ETAT.spectacles || []).map(
      (s) => `<option value="${echapper(s.cle)}">${echapper(s.titre)}</option>`).join("");
  selSpec.value = e.spectacle || "";
  selSpec.onchange = rafraichirApercu;
  // --- le métier
  const selMet = div.querySelector(".e-metier");
  selMet.innerHTML = optionsMetiers(e.metier);
  selMet.value = e.metier || "";
  const cadre = div.querySelector(".e-cadre");
  const majCadre = (depuisCatalogue) => {
    const m = metierDe(selMet.value);
    div.querySelector(".e-cadre-bloc").hidden = !m;
    if (m && depuisCatalogue) cadre.checked = !!m.cadre_par_defaut;
  };
  cadre.checked = e.cadre === true || (e.cadre == null && !!(metierDe(e.metier) || {}).cadre_par_defaut);
  majCadre(false);
  selMet.onchange = () => { majCadre(true); rafraichirApercu(); };
  cadre.onchange = rafraichirApercu;
  // --- les lignes de paie
  const cible = div.querySelector(".rubriques");
  lignesDe(e).forEach((l) => cible.appendChild(ligneRubrique(l)));
  div.querySelector(".ajouter-rubrique").onclick = (ev) => {
    ev.preventDefault();
    cible.appendChild(ligneRubrique());
    rafraichirApercu();
  };
  div.querySelectorAll(".ligne1 input").forEach((c) => {
    c.oninput = rafraichirApercu;
  });
  div.querySelectorAll(".e-qui-case").forEach((c) => {
    c.onchange = () => { majQui(div); rafraichirApercu(); };
  });
  majQui(div);
  // --- le contrat
  div.querySelector(".e-debut").value = e.debut || "";
  div.querySelector(".e-fin").value = e.fin || "";
  div.dataset.numero = e.numero || "";
  div.querySelectorAll(".e-debut, .e-fin").forEach((c) => {
    c.onchange = () => { majContrat(div); rafraichirApercu(); };
  });
  // UN CONTRAT EN COURS DEPUIS UN MOIS PRÉCÉDENT ne se modifie pas d'ici :
  // il a été signé et déclaré avec son premier mois. Salarié, spectacle,
  // métier et bornes sont verrouillés ; seules les lignes du mois se
  // saisissent. `verrou` : fermerEdition ne les rouvre pas.
  const mois = document.getElementById("mois").value;
  if (e.debut && mois && e.debut.slice(0, 7) < mois) {
    div.classList.add("en-cours");
    div.querySelectorAll(".e-debut, .e-fin, .e-spectacle, .e-metier, .e-cadre, .e-qui-case")
      .forEach((c) => { c.disabled = true; c.classList.add("verrou"); });
  }
  majContrat(div);
  return div;
}

/** La ligne repliée du contrat : ses bornes, son numéro, et ce qu'il fait
 *  par rapport au mois — « se poursuit en novembre », « en cours depuis
 *  octobre ». Les bornes vides se lisent sur les jours joués, comme le
 *  moteur le fait (`Engagement.debut`/`fin`). */
function majContrat(div) {
  const d = div.querySelector(".e-contrat");
  if (!d) return;
  const mois = document.getElementById("mois").value;
  const jours = joursDuBloc(div, mois);
  const debut = div.querySelector(".e-debut").value || jours[0] || "";
  const fin = div.querySelector(".e-fin").value || jours[jours.length - 1] || "";
  const numero = div.dataset.numero || "";
  div.querySelector(".e-numero").textContent = numero
    ? "n° " + numero + " — attribué à la production, il ne change plus" : "";
  const s = d.querySelector("summary");
  const enCours = !!(debut && mois && debut.slice(0, 7) < mois);
  const sePoursuit = !!(fin && mois && fin.slice(0, 7) > mois);
  d.classList.toggle("a-cheval", enCours || sePoursuit);
  if (!debut || !fin) {
    s.innerHTML = `Contrat <span class="discret">— du premier au dernier jour joué</span>`;
    return;
  }
  let texte = `Contrat du ${jjmmaaaa(debut)} au ${jjmmaaaa(fin)}`;
  if (numero) texte += ` · n° ${numero}`;
  if (enCours) texte += ` — en cours depuis ${moisEnClair(debut.slice(0, 7))}`;
  if (sePoursuit) texte += ` — se poursuit en ${moisEnClair(moisSuivant(mois))}`;
  s.textContent = texte;
}

function moisSuivant(mois) {
  const an = +mois.slice(0, 4), mo = +mois.slice(5, 7);
  return mo === 12 ? `${an + 1}-01` : `${an}-${String(mo + 1).padStart(2, "0")}`;
}

/** Les listes de salariés et de spectacles de TOUS les blocs, refaites sur
 *  l'ETAT courant, sans perdre ce qui est coché ou choisi. Appelé après
 *  qu'une fiche a été créée : le bloc d'où l'on est parti doit proposer le
 *  nouveau venu sans qu'on recharge le mois — recharger relirait le disque
 *  par-dessus une frappe pas encore enregistrée. */
function rafraichirReferentiels() {
  document.querySelectorAll(".engagement").forEach((div) => {
    const coches = new Set(salariesDuBloc(div));
    const modele = ligneEngagement({ salaries: [...coches] });
    div.querySelector(".e-qui-liste").innerHTML =
      modele.querySelector(".e-qui-liste").innerHTML;
    div.querySelectorAll(".e-qui-case").forEach((c) => {
      c.onchange = () => { majQui(div); rafraichirApercu(); };
    });
    majQui(div);
    const sel = div.querySelector(".e-spectacle");
    const v = sel.value;
    sel.innerHTML = modele.querySelector(".e-spectacle").innerHTML;
    sel.value = v;
  });
}

/** Une fiche neuve : le formulaire complet de Configuration, avec ses
 *  vérifications. Une seule façon de créer une fiche, et c'est là. */
function nouvelleFiche(nom) {
  document.querySelector('.onglets button[data-vue="configuration"]').click();
  document.querySelector(`.sous-onglets button[data-fiche="${nom}"]`).click();
  CLE_ACTIVE = null;
  dessinerConfig();
  dessinerFormulaire({ nom, cle: null, donnees: { actif: true }, anomalies: [] });
  document.getElementById("config-formulaire").scrollIntoView({ behavior: "smooth" });
}

/** Les salariés cochés d'un bloc, dans l'ordre de la liste. */
function salariesDuBloc(div) {
  return [...div.querySelectorAll(".e-qui-case:checked")].map((c) => c.value);
}

/** Le résumé de la liste refermée : les noms cochés, ou l'invitation. */
function majQui(div) {
  const resume = div.querySelector(".e-qui summary");
  const noms = [...div.querySelectorAll(".e-qui-case:checked")]
    .map((c) => c.parentNode.textContent.replace(/\s+/g, " ").trim());
  resume.textContent = noms.length ? noms.join(" + ") : "— cocher —";
  resume.classList.toggle("vide", !noms.length);
}

/** Une liste ouverte se referme quand on clique ailleurs — un <details> ne
 *  le fait pas tout seul. */
document.addEventListener("click", (ev) => {
  document.querySelectorAll(".e-qui[open]").forEach((d) => {
    if (!d.contains(ev.target)) d.open = false;
  });
});

/** Plusieurs salariés cochés : le bloc devient un bloc par salarié.
 *
 *  Appelé APRÈS la validation (validerPlusieurs), pas avant : tant qu'on
 *  saisit, un seul bloc pour tous — c'est ça qui va vite. Le moteur, lui, ne
 *  connaît qu'un salarié par engagement, un contrat, un bulletin ; ici on ne
 *  fait que montrer à l'écran ce que le fichier contient déjà. Rien à faire
 *  pour zéro ou une case. */
function dedoubler(div) {
  const cles = salariesDuBloc(div);
  if (cles.length < 2) return;
  // Les lignes voyagent telles quelles — lieux et jours compris : les
  // salariés jouent les mêmes dates aux mêmes endroits.
  const modele = {
    spectacle: div.querySelector(".e-spectacle").value,   // le meme spectacle
    lignes: lignesDuBloc(div),
    debut: div.querySelector(".e-debut").value || undefined,
    fin: div.querySelector(".e-fin").value || undefined,
  };
  const parent = div.parentNode;
  const suivant = div.nextSibling;
  div.remove();
  cles.forEach((cle) => {
    parent.insertBefore(ligneEngagement({ ...modele, salarie: cle }), suivant);
  });
}

/** Les lignes de paie d'un bloc, telles qu'elles sont saisies. */
function lignesDuBloc(div, mois) {
  mois = mois || document.getElementById("mois").value;
  return [...div.querySelectorAll(".rubrique")].map((r) => {
    const q = r.querySelector(".r-quantite").value;
    const t = r.querySelector(".r-taux").value;
    const h = r.querySelector(".r-heures").value;
    if (q === "" || t === "") return null;
    const l = { rubrique: r.querySelector(".r-code").value, quantite: +q, taux: +t };
    if (h !== "" && !r.querySelector(".r-heures").classList.contains("cachee")) l.heures = +h;
    // Le lieu et les jours de CETTE ligne. Absents du fichier quand ils sont
    // vides : une ligne qui ne dit rien de son lieu n'écrit pas `"lieu": ""`.
    const ou = r.querySelector(".r-lieu").value.trim();
    if (ou) l.lieu = ou;
    const jours = joursDe(r.querySelector(".r-jours"));
    if (jours.length) {
      l.dates = jours.map((j) => mois + "-" + String(j).padStart(2, "0"));
    }
    // Le planning de la ligne : les jours cochés dans les mois suivants.
    const plan = planningDe(r);
    if (plan.length) l.planning = plan;
    return l;
  }).filter(Boolean);
}

/** Les jours d'un engagement, toutes lignes confondues — c'est ce que le
 *  moteur appelle `dates_travail`, et il le recompose de la même façon
 *  (`operations.dates_engagement`). */
function joursDuBloc(div, mois) {
  const vus = new Set();
  lignesDuBloc(div, mois).forEach((l) => (l.dates || []).forEach((j) => vus.add(j)));
  return [...vus].sort();
}

document.getElementById("ajouter-engagement").onclick = () => {
  document.getElementById("engagements").appendChild(ligneEngagement());
  rafraichirApercu();
};

/* REPRENDRE UN CONTRAT EN COURS. Un CDDU signé en octobre pour une tournée
   jusqu'en décembre est UN contrat, déclaré une fois (DPAE, numéro) ; chaque
   mois n'en porte que les cachets joués. Le moteur sait lesquels courent
   encore (`contrats_en_cours`, lu dans les saisies des mois précédents) ; on
   en choisit un, le bloc arrive prérempli et verrouillé, il reste à poser
   les jours. Ce qui est déjà repris dans ce mois reste listé, grisé : le
   voir évite de le chercher. */
let CONTRATS_EN_COURS = [];

async function dessinerContratsEnCours(mois) {
  const b = document.getElementById("reprendre-contrat");
  if (!b) return;
  try {
    const r = await api("contrats-en-cours", { mois });
    CONTRATS_EN_COURS = r.contrats || [];
  } catch (e) { CONTRATS_EN_COURS = []; }
  const restants = CONTRATS_EN_COURS.filter((c) => !c.deja_repris).length;
  b.hidden = !CONTRATS_EN_COURS.length;
  b.textContent = restants
    ? `+ reprendre un contrat en cours (${restants})`
    : "+ reprendre un contrat en cours";
}

document.getElementById("reprendre-contrat").onclick = () => {
  if (!CONTRATS_EN_COURS.length) { dire("Aucun contrat en cours depuis un mois précédent."); return; }
  const mois = document.getElementById("mois").value;
  ouvrirBoite(`
    <h3>Reprendre un contrat en cours</h3>
    <p class="note">Un contrat signé un mois précédent et qui court encore sur
      ${echapper(moisEnClair(mois))}. Ni contrat ni DPAE ne seront refaits — ils
      datent de son premier mois ; il ne reste qu'à saisir les cachets du mois.</p>
    <div class="liste-choix">
      ${CONTRATS_EN_COURS.map((c, i) => `
        <div class="choix ${c.deja_repris ? "grise" : ""}">
          <span><b>${echapper(c.nom)}</b> — ${echapper(spectacleEnClair(c.spectacle))}
            <br><span class="discret">du ${echapper(jjmmaaaa(c.debut))} au ${echapper(jjmmaaaa(c.fin))}
            · n° ${echapper(c.numero || "?")} · depuis ${echapper(moisEnClair(c.depuis))}</span></span>
          ${c.deja_repris
            ? `<span class="discret">déjà dans ce mois</span>`
            : `<button class="secondaire c-reprendre" data-i="${i}">Reprendre</button>`}
        </div>`).join("")}
    </div>
    <div class="actions"><button class="secondaire" onclick="fermerBoite()">Fermer</button></div>`);
  document.querySelectorAll(".c-reprendre").forEach((b) => {
    b.onclick = () => {
      const c = CONTRATS_EN_COURS[+b.dataset.i];
      // L'engagement vient du moteur (`engagement_de_reprise`) : bornes,
      // numéro, métier, et les lignes déjà datées quand le premier mois a
      // coché son planning. Sinon une ligne de cachets, à dater.
      const e = { ...(c.engagement || {}), salarie: c.salarie, spectacle: c.spectacle,
                  debut: c.debut, fin: c.fin, numero: c.numero };
      if (!e.lignes || !e.lignes.length) e.lignes = [{ rubrique: "cachet", taux: c.taux_cachet || DERNIER_TAUX }];
      e.lignes = e.lignes.map((l) => (l.quantite === 0 ? { ...l, quantite: "" } : l));
      document.getElementById("engagements").appendChild(ligneEngagement(e));
      fermerBoite();
      rafraichirApercu();
      dire(`Contrat de ${c.nom} repris — poser les jours de ${moisEnClair(mois)}, ` +
           `ou rien du tout si aucun cachet ce mois-ci : la DSN portera le contrat, sans bulletin.`);
    };
  });
};

function spectacleEnClair(cle) {
  const s = (ETAT.spectacles || []).find((x) => x.cle === cle);
  return s ? s.titre : cle;
}

function saisieCourante() {
  const mois = document.getElementById("mois").value;
  const engagements = [...document.querySelectorAll(".engagement")].flatMap((div) => {
    // L'ENGAGEMENT N'ÉCRIT PLUS DE `dates` : chacune de ses lignes porte les
    // siennes, avec son lieu, et le moteur en fait la réunion
    // (`operations.dates_engagement`). Une seule source, donc pas de
    // divergence possible entre « les jours du contrat » et « les jours
    // payés ».
    //
    // UN ENGAGEMENT PAR SALARIÉ COCHÉ. Le bloc en porte plusieurs à l'écran
    // pour aller vite ; le fichier, lui, garde le format du moteur — un
    // salarié, un engagement. Chacun reçoit sa propre copie des lignes.
    // Un bloc sans salarié n'est pas une paie et n'écrit rien.
    const spectacle = div.querySelector(".e-spectacle").value;
    const lignes = lignesDuBloc(div, mois);
    const metier = div.querySelector(".e-metier").value;
    const cadre = div.querySelector(".e-cadre").checked;
    const debut = div.querySelector(".e-debut").value;
    const fin = div.querySelector(".e-fin").value;
    const numero = div.dataset.numero || "";
    return salariesDuBloc(div).map((salarie) => {
      const e = { salarie, spectacle };
      // Le contrat, quand il est dit : ses bornes (un contrat qui déborde
      // du mois n'existe que par elles) et son numéro, figé à la production.
      if (debut) e.debut = debut;
      if (fin) e.fin = fin;
      if (numero) e.numero = numero;
      // UN MOIS DU CONTRAT SANS CACHET (15/09/2026) : un contrat aux bornes
      // dites, et aucune ligne remplie, s'écrit `lignes: []` — le moteur en
      // fait une DSN qui porte le contrat avec un versement à zéro, sans
      // bulletin. Sans bornes, on n'écrit rien : c'est une saisie incomplète,
      // et le moteur le dit.
      if (lignes.length) e.lignes = JSON.parse(JSON.stringify(lignes));
      else if (debut && fin) e.lignes = [];
      // Le métier ne s'écrit que s'il est choisi : un engagement sans
      // `metier` prend celui de la fiche, et toutes les saisies d'avant
      // restent lisibles telles quelles. `cadre` voyage avec lui, seulement
      // quand il s'écarte du défaut du catalogue.
      if (metier) {
        e.metier = metier;
        const m = metierDe(metier);
        if (!m || cadre !== !!m.cadre_par_defaut) e.cadre = cadre;
      }
      return e;
    });
  });
  // `taux_cachet` et `date_paiement` ne s'affichent plus mais restent ECRITS :
  // le moteur s'en sert -- l'un comme defaut d'un engagement qui ne dit pas
  // son taux, l'autre comme date de paiement du contrat. Ce qui a disparu,
  // c'est la saisie, pas la valeur. `lieu` ne s'ecrit plus du tout : il
  // appartient au cachet.
  return {
    mois,
    taux_cachet: DERNIER_TAUX,
    date_paiement: SAISIE_DATE_PAIEMENT || finDuMois(mois),
    engagements,
  };
}

function rafraichirApercu() {
  clearTimeout(MINUTEUR);
  MINUTEUR = setTimeout(calculerApercu, 350);   // on ne calcule pas a chaque frappe
  // Et on enregistre. C'est le seul point de passage de TOUTES les
  // modifications de la saisie -- y accrocher l'enregistrement, c'est
  // s'assurer qu'aucune frappe ne reste dans la page seulement.
  enregistrerPlusTard();
  // Les etats, eux, ne coutent rien : ils sont deja lus. On les repeint tout
  // de suite, parce que changer le salarie ou les jours change la paie que ce
  // bloc DESIGNE -- et laisser 350 ms l'ancien etat sous le nouveau nom, c'est
  // exactement le mensonge qu'on veut eviter.
  peindreEtats();
}

async function calculerApercu() {
  const saisie = saisieCourante();
  const cible = document.getElementById("apercu");
  // Les jours sont sur les lignes de paie : un engagement « a des jours » dès
  // qu'une de ses lignes en porte.
  const aDesJours = (e) => (e.lignes || []).some((l) => (l.dates || []).length);
  if (!saisie.engagements.length || !saisie.engagements.some(aDesJours)) {
    cible.innerHTML = `<p class="discret">Ajouter un engagement, une ligne de
      paie et ses jours joués.</p>`;
    return;
  }
  cible.classList.add("attente");
  try {
    const a = await api("apercu", { saisie });
    cible.innerHTML = vueApercu(a);
    // Les dates resolues, sous chaque engagement : ce que le moteur a compris.
    document.querySelectorAll(".engagement").forEach((div, i) => {
      const p = a.paies[i];
      // Ce qui a été numéroté : un contrat en cours garde le numéro de son
      // premier mois, et c'est ici qu'il revient à l'écran quand la saisie
      // ne le portait pas encore.
      if (p && p.numero_contrat && p.contrat && !p.contrat.premier_mois
          && !div.dataset.numero) {
        div.dataset.numero = p.numero_contrat;
        majContrat(div);
      }
      // Un mois du contrat sans cachet n'a pas de bulletin : on le dit à la
      // place du numéro, et le brut à zéro suit.
      div.querySelector(".resolu").innerHTML = p
        ? `${p.contrat && p.contrat.sans_paie
             ? `<b>aucun cachet ce mois-ci</b> — pas de bulletin, la DSN porte le contrat`
             : `bulletin <b>${echapper(p.numero_bulletin)}</b>`} · contrat ${echapper(p.numero_contrat)}
           · ${echapper(jjmmaaaa(p.debut))} → ${echapper(jjmmaaaa(p.fin))}${
             p.contrat && p.contrat.a_cheval
               ? ` <span class="discret">(paie du ${echapper(jjmmaaaa(p.contrat.periode.debut))} au ${echapper(jjmmaaaa(p.contrat.periode.fin))})</span>`
               : ""}
           · ${echapper(designation(p))}${p.emploi && p.emploi.libelle
             ? ` · ${echapper(p.emploi.libelle.toLowerCase())}${p.emploi.cadre ? " (cadre)" : ""}` : ""}
           · brut <b>${p.brut} €</b>`
        : "";
      // Ce que le moteur a à dire de CETTE paie -- un cachet sous le minimum
      // conventionnel, une DFS jamais confrontée. Non bloquant : l'encart
      // s'affiche, la saisie continue.
      div.querySelector(".avis").innerHTML = (p && p.avertissements || []).map(
        (a) => `<div class="encart attention avis-paie">${echapper(a)}</div>`).join("");
    });
  } catch (e) {
    cible.innerHTML = `<div class="encart erreur"><b>${echapper(e.detail?.type || "Erreur")}</b>
      ${echapper(e.message)}</div>`;
  } finally {
    cible.classList.remove("attente");
  }
}

/* Ce que porte le contrat, en toutes lettres : « 2 Cachets », « 1 Journée de
 * travail, 6 h de Masterclass ». La phrase vient du MOTEUR (`remuneration`) ;
 * la page ne la fabrique pas depuis un nombre de cachets, sans quoi un contrat
 * sans cachet s'afficherait « 0 cachet(s) ». */
function designation(p) {
  const r = p.remuneration || [];
  return r.length ? r.map((l) => l.designation).join(", ") : "—";
}

/* L'APERCU NE PORTE PLUS L'ESTIMATION URSSAF -- retiree le 12/09/2026.
 *
 * La réaction : << normalement on estime rien, on sait avec
 * certitude grace a nos calculs >>, puis << supprimer alors cette case qui ne
 * sert pas au quotidien >>.
 *
 * Il a raison sur les deux points, et le second decoule du premier. Cette
 * estimation n'a jamais eu qu'un usage : reperer une saisie aberrante -- 102
 * ou 1 020. Or elle s'affichait a chaque frappe, a cote de chiffres qui, eux,
 * sont SURS au centime, et c'est precisement ce qui la rendait nuisible : la
 * seule valeur incertaine de l'ecran avait la meme place que les autres, et
 * lire tous les jours << estime >> a cote d'un net exact apprend a ne plus
 * faire la difference.
 *
 * RIEN N'EST PERDU, et c'est la condition pour la retirer : le montant est
 * demande la ou il sert, dans la boite << Produire >>, qui porte l'explication
 * entiere, le champ, et l'estimation en repere. Le moteur, lui, n'a pas bouge
 * -- `urssaf_estimation` est toujours calcule et toujours rendu par /api, et
 * `produire_mois` refuse toujours sans montant (ErreurOperation
 * UrssafManquant). On a retire un AFFICHAGE, pas un garde-fou.
 */
/* PAR SALARIÉ, UNE LIGNE. « C'est plus facile ensuite pour faire les paies :
 * j'ai juste à mettre le montant du net » ; puis, devant
 * le détail paie par paie : « pas de détail dans l'aperçu ! ». Donc une ligne
 * par salarié, sommée, et le net est ce qu'on vire. Les sommes se font ici,
 * sur les chaînes du moteur, à deux décimales — ce n'est qu'un aperçu, le
 * bulletin fait foi. */
function vueApercu(a) {
  const somme = (xs) => xs.reduce((t, x) => t + Number(x || 0), 0).toFixed(2);
  const groupes = [];
  a.paies.forEach((p) => {
    const cle = p.salarie.nom + "|" + p.salarie.prenom;
    let g = groupes.find((x) => x.cle === cle);
    if (!g) { g = { cle, salarie: p.salarie, paies: [] }; groupes.push(g); }
    g.paies.push(p);
  });
  // « 2 × 1 Cachet » plutôt que « 1 Cachet, 1 Cachet » : on compte les
  // rémunérations identiques.
  const remuneration = (paies) => {
    const comptes = new Map();
    paies.forEach((p) => { const d = designation(p); comptes.set(d, (comptes.get(d) || 0) + 1); });
    return [...comptes].map(([d, n]) => (n > 1 ? `${n} × ${d}` : d)).join(", ");
  };
  const lignes = groupes.map((g) => `
    <tr>
      <td>${echapper(g.salarie.nom)} ${echapper(g.salarie.prenom)}</td>
      <td>${echapper(remuneration(g.paies))}</td>
      <td class="num">${somme(g.paies.map((p) => p.brut))}</td>
      <td class="num"><b>${somme(g.paies.map((p) => p.net_a_payer))}</b></td>
      <td class="num">${somme(g.paies.map((p) => p.cout_employeur))}</td>
    </tr>`).join("");
  return `
    <table>
      <tr><th>Salarié</th><th>Rémunération</th><th>Brut</th><th>Net</th><th>Coût</th></tr>
      ${lignes}
      <tr class="total"><td>Total</td><td></td>
        <td class="num">${a.total_brut}</td>
        <td class="num">${somme(a.paies.map((p) => p.net_a_payer))}</td>
        <td class="num">${a.total_cout}</td></tr>
    </table>`;
}

/* ------------------------------------------------------- charger un mois */
let MOIS_AFFICHE = null;        // le mois REELLEMENT charge dans l'ecran

/** Le fichier en blocs : ce qui a été saisi d'un coup pour plusieurs
 *  salariés (saisieCourante) revient d'un coup — même spectacle, mêmes
 *  lignes, qui se suivent, et AUCUN validé. Une paie validée, elle, est
 *  déjà démultipliée : elle a son bloc, fermé, et n'absorbe rien. */
function regrouper(engagements) {
  const groupes = [];
  engagements.forEach((e) => {
    const empreinte = JSON.stringify({ spectacle: e.spectacle || "",
                                       metier: e.metier || "", cadre: e.cadre ?? null,
                                       debut: e.debut || "", fin: e.fin || "",
                                       // Un numéro figé est propre à UN
                                       // salarié : deux paies numérotées ne
                                       // se regroupent jamais.
                                       numero: e.numero || "",
                                       lignes: e.lignes || [] });
    const dernier = groupes[groupes.length - 1];
    if (dernier && !e.valide && !dernier.valide && dernier.empreinte === empreinte
        && !dernier.salaries.includes(e.salarie)) {
      dernier.salaries.push(e.salarie);
    } else {
      groupes.push({ ...e, salaries: [e.salarie], empreinte });
    }
  });
  return groupes;
}

async function chargerMois(mois) {
  const r = await api("saisie", { mois });
  SAISIE = r.saisie;
  MOIS_AFFICHE = mois;
  document.getElementById("mois").value = mois;
  // Le taux du mois chargé devient « le dernier taux donné ». Un mois neuf
  // n'en a pas : on garde alors celui de l'écran, qui vient du mois d'avant.
  if (SAISIE.taux_cachet) DERNIER_TAUX = +SAISIE.taux_cachet;
  // La date de paiement d'une saisie existante fait foi -- on ne réécrit pas
  // le 30 sur un mois payé le 15. Un mois neuf prend la fin du mois.
  SAISIE_DATE_PAIEMENT = SAISIE.date_paiement || finDuMois(mois);
  document.getElementById("rappels-mois").innerHTML =
    `cachet à <b>${echapper(DERNIER_TAUX)} €</b> par défaut ·
     paiement le ${echapper(jjmmaaaa(SAISIE_DATE_PAIEMENT))} ·
     le lieu et les jours se posent sur chaque ligne de paie`;
  const cible = document.getElementById("engagements");
  cible.innerHTML = "";
  regrouper(SAISIE.engagements || []).forEach((g) => cible.appendChild(ligneEngagement(g)));
  // Ce qui vient d'etre charge est, par definition, ce qui est sur le disque :
  // on le note, pour que l'enregistrement automatique ne reecrive pas un
  // fichier identique a chaque fois qu'on effleure un champ.
  clearTimeout(MINUTEUR_SAISIE);
  DERNIERE_ECRITE = JSON.stringify(saisieCourante());
  noteSaisie(r.existe
    ? "Saisie chargée — paies/" + mois + ".json. L'enregistrement est automatique."
    : "Nouveau mois — l'enregistrement est automatique dès la première saisie.");
  document.getElementById("resultat").innerHTML = "";
  calculerApercu();
  // Ce qui est parti de ce mois-la se lit au meme moment que ce qu'il
  // contient : un ecran qui montrerait la saisie sans l'etat du journal
  // laisserait rejouer un depot deja fait.
  dessinerActions(mois);
  dessinerEmbauches(mois);
  dessinerReprise();
  dessinerContratsEnCours(mois);
  // Ou en est CHAQUE paie. Se lit apres le chargement des blocs : les etats
  // se posent sur eux, et un bloc absent n'aurait rien ou se poser.
  dessinerEtatsDesPaies(mois);
}

/* Changer de mois enregistre d'abord CE QUI EST À L'ÉCRAN, et sous son vrai
 * mois. La case a déjà changé quand on arrive ici : on y remet l'ancien mois
 * le temps de l'écriture, sans quoi les engagements d'août partiraient dans le
 * fichier de septembre — la case du mois est ce qui date les jours joués. */
document.getElementById("mois").onchange = async (e) => {
  fermerCalendriers();
  const neuf = e.target.value;
  if (MOIS_AFFICHE && MOIS_AFFICHE !== neuf) {
    clearTimeout(MINUTEUR_SAISIE);
    e.target.value = MOIS_AFFICHE;
    await enregistrerSaisie(true);
    e.target.value = neuf;
  }
  chargerMois(neuf);
};

/* Quitter l'onglet ou fermer la fenêtre : on écrit ce qui attend encore. Une
 * seconde de battement suffit à perdre une frappe si on ferme juste après. */
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") {
    clearTimeout(MINUTEUR_SAISIE);
    enregistrerSaisie(true);
  }
});



/* ------------------------------------------- l'enregistrement automatique
   « Je comprends pas les boutons en bas produire le mois et enregistrer la
   saisie, tout est déjà dans les cases ».

   Il a raison, et le bouton est parti. Ce qui est tapé dans une case EST la
   saisie ; demander un clic pour le confirmer, c'était demander de tenir en
   tête un état — « est-ce que j'ai enregistré ? » — que la machine connaît
   mieux. Trois choses pour que ça reste honnête :

   1. UNE SECONDE APRÈS LA DERNIÈRE FRAPPE, pas à chaque touche. Écrire le
      fichier vingt fois pendant qu'on tape un nom ne sert personne.
   2. LA LIGNE D'ÉTAT DIT L'HEURE. « Enregistré à 14:32 » — sans quoi
      l'enregistrement automatique est un enregistrement dont on ne sait pas
      s'il a eu lieu, c'est-à-dire pire que le bouton.
   3. RIEN NE PART POUR AUTANT. Enregistrer, c'est écrire paies/AAAA-MM.json
      et rien d'autre. Produire consomme des numéros et écrit des fichiers qui
      partiront : ça reste un bouton, et ça le restera. */
let MINUTEUR_SAISIE = null;
let DERNIERE_ECRITE = null;      // le JSON tel qu'il a été enregistré

function noteSaisie(texte) {
  document.getElementById("note-saisie").textContent = texte;
}

/** Enregistre si quelque chose a changé. Rend true si le fichier a été écrit. */
async function enregistrerSaisie(silencieux) {
  const s = saisieCourante();
  if (!s.mois) return false;
  const empreinte = JSON.stringify(s);
  if (empreinte === DERNIERE_ECRITE) return false;
  try {
    await api("enregistrer-saisie", { mois: s.mois, saisie: s });
    DERNIERE_ECRITE = empreinte;
    const h = new Date().toTimeString().slice(0, 5);
    noteSaisie("Enregistré à " + h + " — paies/" + s.mois + ".json");
    ETAT.historique = await api("etat").then((e) => e.historique);
    // Ce qui vient d'etre enregistre devient declarable : les blocs qui
    // disaient << pas dans la saisie enregistree >> doivent cesser de le dire,
    // et la colonne << ce qui part >> compte desormais cette paie (elle
    // disait << aucune paie ce mois-ci >> tant qu'on ne rechargeait pas).
    await rafraichirActions();
    return true;
  } catch (e) {
    // Un échec d'enregistrement ne peut pas rester discret : c'est du travail
    // qu'on croit posé et qui ne l'est pas.
    noteSaisie("PAS enregistré — " + e.message);
    if (!silencieux) dire(e.message, "erreur");
    return false;
  }
}

/** Appelée à chaque frappe. Enregistre une seconde après la dernière. */
function enregistrerPlusTard() {
  clearTimeout(MINUTEUR_SAISIE);
  noteSaisie("Modifié…");
  MINUTEUR_SAISIE = setTimeout(() => enregistrerSaisie(true), 1000);
}

/* ---------------------------------------------------------- production */
/** Écrire le mois — bulletins, contrats, DPAE, certificats, DSN. Appelée
 *  depuis la boîte DSN quand rien n'est écrit (« le bouton c'est envoyer,
 *  directement ») ; `apres` enchaîne sur la suite,
 *  le dépôt en général. Produire consomme des numéros de bulletin : la
 *  saisie est enregistrée d'abord, pour dire exactement ce qui a servi. */
async function boiteProduire(mois, apres) {
  clearTimeout(MINUTEUR_SAISIE);
  await enregistrerSaisie(true);
  const saisie = saisieCourante();
  if (mois && saisie.mois !== mois) {
    dire("Le mois affiché n'est pas " + mois + ".", "erreur"); return;
  }
  let estimation = "?", marge = "?";
  try {
    const a = await api("apercu", { saisie });
    estimation = a.urssaf_estimation; marge = a.urssaf_marge;
  } catch (e) { dire(e.message, "erreur"); return; }

  ouvrirBoite(`
    <h3>Produire ${echapper(saisie.mois)}</h3>
    <div class="encart attention">
      <b>Le montant du télépaiement URSSAF est obligatoire</b>
      Bloc S21.G00.20 de la DSN : l'URSSAF prélève ce montant. Il n'est pas
      calculable depuis la paie — l'organisme facture des éléments que la DSN
      ne détaille pas, et régularise chaque année en avril. Il se recopie du
      bordereau.
    </div>
    <label>Montant du bordereau URSSAF (€)
      <input type="number" step="0.01" id="b-audiens" placeholder="${echapper(estimation)}">
    </label>
    <p class="note">Estimation du moteur : <b>${echapper(estimation)} €</b>
       (± ${echapper(marge)} €). À défaut de bordereau, on peut la retenir —
       la DSN sera alors à vérifier avant dépôt.</p>
    <label style="margin-top:12px"><input type="checkbox" id="b-estime" style="width:auto;display:inline">
      Retenir l'estimation, faute de bordereau</label>
    <label><input type="checkbox" id="b-sans-contrat" style="width:auto;display:inline">
      Ne pas régénérer contrats et DPAE (déjà faits)</label>
    <label><input type="checkbox" id="b-test" style="width:auto;display:inline">
      DSN en envoi de test (données non conservées)</label>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="b-lancer">Produire</button>
    </div>`);

  document.getElementById("b-lancer").onclick = async () => {
    const montant = document.getElementById("b-audiens").value;
    const charge = {
      mois: saisie.mois, saisie,
      sans_contrat: document.getElementById("b-sans-contrat").checked,
      test: document.getElementById("b-test").checked,
    };
    if (montant !== "") charge.urssaf = +montant;
    else if (document.getElementById("b-estime").checked) charge.urssaf_estime = true;
    else { dire("Montant du bordereau URSSAF manquant : le cocher ou le saisir.", "erreur"); return; }

    document.getElementById("b-lancer").disabled = true;
    try {
      const r = await api("produire", charge);
      fermerBoite();
      // La production a figé les numéros de contrat dans la saisie : on
      // recharge le mois pour que l'écran les porte (et les renvoie).
      await chargerMois(saisie.mois);
      afficherResultat(r);
      dire(r.fichiers.length + " fichier(s) écrits dans " + r.dossier);
      ETAT = await api("etat");
      await rafraichirActions();      // les fichiers a deposer viennent d'apparaitre
      if (apres) await apres();
    } catch (e) {
      document.getElementById("b-lancer").disabled = false;
      dire(e.message, "erreur");
    }
  };
}

function afficherResultat(r) {
  const fichiers = r.fichiers.map(
    (f) => `<li>${echapper(f.nom)} <span class="discret">(${f.octets} o)</span></li>`).join("");
  const etapes = r.etapes.map((e, i) => `
    <li><b>${echapper(e.titre)}</b> — ${echapper(e.detail)}
      ${e.commande ? `<br><code class="discret">${echapper(e.commande)}</code>` : ""}</li>`).join("");
  const avert = r.avertissements.map(
    (a) => `<div class="encart attention">${echapper(a)}</div>`).join("");
  document.getElementById("resultat").innerHTML = `
    <div class="carte" style="margin-top:20px">
      <h2>${echapper(r.libelle)} — produit</h2>
      ${avert}
      <div class="encart bien">
        <b>Numéros consommés</b>
        ${r.numeros.bulletin_premier
          ? `bulletins ${r.numeros.bulletin_premier} à ${r.numeros.bulletin_dernier}`
          : "aucun bulletin (aucun cachet ce mois-ci)"}${
          // Plus d'AEM depuis le 01/06/2026 (France Travail l'edite depuis la
          // DSN) ; et pas de certificat CS un mois ou aucun contrat ne finit.
          r.numeros.cs_dernier >= r.numeros.cs_premier
            ? ` · certificats CS ${r.numeros.cs_premier} à ${r.numeros.cs_dernier}`
            : " · aucun certificat CS ce mois-ci (contrat en cours)"}
      </div>
      <div class="colonnes">
        <div><h2>Fichiers</h2><ul>${fichiers}</ul>
          <p class="note">Dans ${echapper(r.dossier)}</p></div>
        <div><h2>À faire ensuite</h2><ol>${etapes}</ol>
          <p class="note">Les dépôts et les envois restent manuels : une
             déclaration part sous la responsabilité de l'employeur.</p></div>
      </div>
    </div>`;
}

/* ---------------------------------------------------------- la boite */
/*  `auFermer` est appele QUOI QU'IL ARRIVE, y compris quand on clique a cote
 *  de la boite. Sans lui, une boite qui repond par une promesse resterait en
 *  attente pour toujours : le clic a cote passerait pour un « annuler » a
 *  l'ecran, et l'enregistrement qui attendait sa reponse ne viendrait jamais. */
let FERMETURE_BOITE = null;
function ouvrirBoite(html, auFermer) {
  document.getElementById("boite").innerHTML = html;
  document.getElementById("voile").classList.remove("cachee");
  FERMETURE_BOITE = auFermer || null;
}
function fermerBoite() {
  document.getElementById("voile").classList.add("cachee");
  const f = FERMETURE_BOITE;
  FERMETURE_BOITE = null;
  if (f) f();
}
document.getElementById("voile").onclick = (e) => {
  if (e.target.id === "voile") fermerBoite();
};

/* =======================================================================
   LE MOIS : CE QUI PART D'ICI
   =======================================================================
   Quatre actes, un seul écran pour les quatre : déposer la DSN, déposer la
   DPAE, envoyer les documents aux salariés, demander la signature des
   contrats. Le moteur sait les faire depuis le 11/09/2026 ; ils n'avaient
   pas d'écran, et un bouton qui n'existe pas est une fonction qui n'existe
   pas.

   TROIS RÈGLES, ET AUCUNE N'EST TENUE ICI — c'est tout le sujet :

   1. La phrase d'état vient du JOURNAL, par le moteur (`journal.resume`).
      Elle distingue trois choses qu'un écran confondrait vite : jamais
      parti, parti sans réponse, parti et répondu. « En attente » affiché
      comme « conforme », c'est une déclaration qu'on croit faite.
   2. Rien ne part d'un clic. Chaque bouton ouvre un RÉCAPITULATIF, et le
      récapitulatif demande le mot de passe DU LOGICIEL — pas celui de
      l'organisme, que cette page ne voit jamais, ne demande jamais et ne
      reçoit jamais. Le moteur va le chercher lui-même au coffre.
   3. Le mois déclaré y est écrit EN GROS. Ce n'est pas de la décoration :
      recopier le mois était le seul geste qu'on ne peut pas faire sans
      regarder l'écran, et il a été retiré du parcours. Un mot de passe se
      tape de mémoire, les yeux ailleurs — donc c'est ce bloc-là qui porte
      désormais toute la lecture (docstring d'`operations.Preuve`).

   La séance se voit AVANT le clic, et pourtant les boutons restent actifs.
   Un garde-fou posé dans un front est un garde-fou qu'on contourne par
   l'autre face : c'est `operations` qui refuse, et lui seul. La page
   prévient, parce que découvrir un refus après avoir tapé son mot de passe
   est une mauvaise façon d'apprendre qu'il fallait ouvrir la séance.
*/
let MOIS_ACTES = null;          // le dernier /api/etat-du-mois lu

/* Trois états, trois couleurs, et surtout pas deux : « parti, pas de retour »
 * n'est pas « parti et conforme ». */
/** Les derniers envois d'un acte, tests compris, quand ils disent autre chose
 *  que l'état réel du dessus — « j'aimerais avoir les derniers retours ici »
 *. */
function derniersEnvois(e, cle) {
  const lignes = (e.derniers && e.derniers[cle]) || [];
  if (!lignes.length) return "";
  // Tous, réel compris, le plus récent en premier — l'état réel du dessus
  // reste la réponse à « est-ce fait ? », ceci est le fil des envois.
  return `<div class="acte-derniers">` + lignes.map((l) =>
    `<div class="acte-dernier ${l.mode === "test" ? "test" : "reel"}">${echapper(l.resume)}</div>`)
    .join("") + `</div>`;
}

/** La phrase d'un coup d'œil, dans la tête de la boîte : courte quand c'est
 *  fini, la phrase du bilan sinon (elle dit ce qui reste). */
function phraseCourte(cle, couleur, phrase, courte) {
  // Le bilan peut dire lui-même sa phrase courte : « rien ce mois-ci » pour
  // un contrat en cours, dont la DPAE et la signature relèvent d'un autre
  // mois — « toutes envoyées » serait une promesse que ce mois ne tient pas.
  if (courte) return courte;
  if (couleur === "bien") return {
    "dpae": "toutes envoyées", "contrat-signature": "envoyés et signés",
    "documents": "envoyés à tous", "dsn": "déposée et passée",
  }[cle] || phrase;
  if (couleur === "refus") return "REFUSÉ — à revoir";
  if (couleur === "alerte") return {
    "dpae": "en attente / à faire", "contrat-signature": "en attente / à faire",
    "documents": "en partie", "dsn": "retour attendu",
  }[cle] || phrase;
  return {
    "dpae": "à déposer", "contrat-signature": "à envoyer",
    "documents": "à envoyer", "dsn": "à déposer",
  }[cle] || phrase;
}

function couleurActe(ligne) {
  if (!ligne) return "";
  const retours = ligne.retours || [];
  // Un bilan KO sans certificat : c'est un refus, et ça se voit en rouge.
  if (retours.some((r) => r.verdict === "KO") && !retours.some((r) => String(r.nature) === "41")) return "refus";
  return retours.length ? "bien" : "alerte";
}

/* << d'aout >>, << de septembre >>. Une elision qui manque se lit comme une
 * faute de frappe, et une interface qui ecrit mal fait douter de ce qu'elle
 * compte. */
function deMois(iso) {
  const nom = moisEnClair(iso);
  return ("aeiouyâàéèêîôû".includes(nom[0]) ? "d'" : "de ") + nom;
}

function quand(iso) {
  // « 12/09/2026 à 18:18 » : on travaille en France, une date à l'américaine
  // dans une phrase se lit mal. L'ISO reste dans les
  // fichiers et les échanges ; ce qui s'affiche passe par ici.
  const s = String(iso || "");
  if (s.length < 10 || s[4] !== "-" || s[7] !== "-") return s;
  const jour = `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)}`;
  const heure = s.length >= 16 ? s.slice(11, 16) : "";
  return heure ? `${jour} à ${heure}` : jour;
}

/* Le mois déclaré, EN GROS. Voir le point 3 ci-dessus. */
function moisEnGros(mois) {
  return `<div class="mois-gros">
    <span class="clair">${echapper(moisEnClair(mois))}</span>
    <span class="iso">${echapper(mois)}</span>
  </div>`;
}

/* LA SÉANCE NE S'AFFICHE PLUS QUAND ELLE VA BIEN. Il y avait ici un encart
 * permanent « Séance ouverte — encore N minutes ». Il avait un sens tant que
 * la séance expirait ; depuis le 12/09/2026 elle dure ce que dure la fenêtre,
 * et c'est dit sans détour : « sans la notification dans l'interface,
 * pas nécessaire ». Un bandeau qui annonce en permanence que tout va bien
 * n'est plus lu, et occupe la place de ceux qui annoncent le contraire.
 *
 * Le cas fermé, lui, reste écrit : là, un dépôt SERA refusé, et découvrir un
 * refus après avoir tapé son mot de passe est une mauvaise façon de
 * l'apprendre. En pratique il ne devrait plus arriver — la fenêtre de
 * lancement ouvre la séance en démarrant. */
function blocSeance(s) {
  if (!s || !s.exigee || s.ouverte) return "";
  return `<div class="encart erreur"><b>Séance fermée — un dépôt sera refusé</b>
    Le coffre ne délivre le secret d'un organisme que séance ouverte. Elle
    s'ouvre avec la fenêtre PuppetPaie, ou par
    <code>python -m moteur seance --ouvrir</code>.
    Les envois de documents et de contrats, eux, ne l'exigent pas.</div>`;
}

/* -------------------------------------------- la colonne des quatre actes */
async function dessinerActions(mois) {
  const cible = document.getElementById("actions-mois");
  if (!mois) { cible.innerHTML = ""; return; }
  cible.innerHTML = `<p class="discret">Lecture du journal…</p>`;
  let e;
  try {
    e = await api("etat-du-mois", { mois });
  } catch (err) {
    cible.innerHTML = `<p class="discret">${echapper(err.message)}</p>`;
    return;
  }
  MOIS_ACTES = e;

  // Quel fichier se dépose est tranché par le moteur (`fichiers_deposables`) :
  // un mois porte souvent deux DSN, et la bonne est la dernière écrite.
  const dsn = (e.fichiers.dsn || [])[0];
  const dpae = (e.fichiers.dpae || [])[0];

  /* DANS L'ORDRE OÙ ÇA SE FAIT, et non dans l'ordre où c'est important.
     « L'ordre à droite est absurde : c'est d'abord DPAE, puis contrat, puis
     DSN, puis documents ». Il décrit le calendrier réel
     d'un mois, et c'est le seul ordre qui vaille pour une colonne qu'on
     descend :

       la DPAE part AVANT le premier jour travaillé (c'est la loi) ;
       le contrat se signe autour de l'embauche ;
       la DSN part le 5 ou le 15 du mois suivant ;
       les documents partent une fois la paie faite.

     La DSN était en tête parce qu'elle est l'acte le plus lourd. Une colonne
     n'est pas un classement par gravité : c'est une liste qu'on descend. */
  const actes = [
    { cle: "dpae", titre: "DPAE", court: "DPAE", detail: "les déclarations préalables à l'embauche",
      bouton: "Déposer la DPAE…", fichier: dpae, toujours: true,
      // La boîte des embauches, comme celle des signatures : chaque contrat
      // du mois, une case, cochée d'avance s'il reste à déclarer
      // (15/09/2026). Le fichier complet du mois ne se redépose jamais tel
      // quel — il redéclarerait ce qui est parti.
      ouvrir: () => boiteDpae(mois) },
    { cle: "contrat-signature", titre: "Contrats à signer", court: "CONTRATS",
      detail: "envoyés avec le bouton « Je signe » — la réponse est relevée toute seule",
      bouton: "Demander la signature…", toujours: true,
      ouvrir: () => boiteSignature(mois) },
    // « La DSN ne doit pas être liée à la sélection : elle fait
    // obligatoirement tout le mois, pas comme les DPAE » (12/09/2026). Elle
    // n'a jamais figuré dans la barre des actions groupées, et elle a quitté
    // les pastilles des blocs de paie le même jour. Le détail le dit ici, à
    // l'endroit où on clique.
    { cle: "dsn", titre: "DSN", court: "DSN",
      detail: "tout le mois d'un coup — une DSN ne se découpe pas",
      bouton: dsn ? "Déposer la DSN…" : "Écrire le mois et déposer la DSN…",
      fichier: dsn, toujours: true,
      // Rien d'écrit : la boîte écrit le mois (bulletins, contrats, DPAE,
      // certificats, DSN), puis enchaîne sur le dépôt. Un seul geste.
      ouvrir: () => dsn ? boiteDepot("dsn", dsn.chemin)
                        : boiteProduire(mois, async () => {
                            const e2 = await api("etat-du-mois", { mois });
                            const d2 = (e2.fichiers.dsn || [])[0];
                            if (d2) await boiteDepot("dsn", d2.chemin);
                          }) },
    { cle: "documents", titre: "Documents aux salariés", court: "DOCUMENTS",
      detail: "bulletin, certificat Congés Spectacles, AER",
      bouton: "Envoyer les documents…", toujours: true,
      ouvrir: () => boiteEnvoi(mois) },
  ];

  // UNE LIGNE PAR ACTE, ET LA COULEUR EN UN COUP D'OEIL. La demande, le
  // 13/09/2026 : « un truc court que je vois en un coup d'œil, et si je
  // clique j'ai le reste avec les détails et le bouton » — puis, devant le
  // résultat : « c'est ça ». Quand l'acte est fini (vert), la boîte est
  // repliée sur sa phrase courte ; sinon elle est ouverte, avec le fil des
  // envois et le bouton. Le chevron rouvre toujours.
  cible.innerHTML = blocSeance(e.seance) + actes.map((a) => {
    const dispo = a.toujours || !!a.fichier;
    const bilan = (e.bilans && e.bilans[a.cle]) || null;
    const couleur = bilan ? bilan.couleur : couleurActe(e.actes[a.cle]);
    const phrase = bilan ? bilan.phrase : e.resumes[a.cle];
    const fini = couleur === "bien";
    return `
      <details class="acte ${echapper(couleur)}" ${fini ? "" : "open"}>
        <summary class="acte-tete">
          <span class="acte-nom">${echapper(a.court || a.titre)}</span>
          <span class="acte-court">— ${echapper(phraseCourte(a.cle, couleur, phrase, bilan && bilan.courte))}</span>
        </summary>
        <div class="acte-corps">
          <div class="discret acte-detail">${echapper(a.detail)}</div>
          <div class="acte-etat ${echapper(couleur)}">${echapper(phrase)}</div>
          ${derniersEnvois(e, a.cle)}
          ${a.fichier ? `<div class="acte-fichier">${echapper(a.fichier.nom)}
             <span class="discret">écrit le
               ${echapper(quand(a.fichier.ecrit))}</span></div>` : ""}
          <button class="secondaire" data-acte="${echapper(a.cle)}"
                  ${dispo ? "" : "disabled"}>${echapper(a.bouton)}</button>
          ${dispo ? "" : `<p class="note">${echapper(a.absent)}</p>`}
        </div>
      </details>`;
  }).join("");

  cible.querySelectorAll("[data-acte]").forEach((b) => {
    b.onclick = () => actes.find((a) => a.cle === b.dataset.acte).ouvrir();
  });
}

/* Ce qu'il faut relire après avoir déposé ou envoyé : l'état du mois affiché,
 * et la liste des embauches, qu'un dépôt de DPAE vient de raccourcir. */
async function rafraichirActions() {
  const mois = document.getElementById("mois").value;
  await dessinerActions(mois);
  await dessinerEmbauches(mois);
  await dessinerEtatsDesPaies(mois);
  await dessinerReprise();
  await dessinerContratsEnCours(mois);
}

/* La reprise ne depend pas du mois : elle balaie tout ce qui est archive. Elle
 * se dessine donc une fois a l'ouverture, et se refait apres un depot -- qui
 * vient justement d'ecrire une ligne, et donc de raccourcir ce qu'il reste a
 * reprendre. */

/* ---------------------------------------- le récapitulatif d'un dépôt */
function corpsDsn(a) {
  const v = a.versements || [];
  return `
    <p class="discret">${echapper(a.nom)} — ${echapper(a.libelle_type)}
      (type ${echapper(a.type_declaration)}), ordre ${echapper(a.ordre)},
      fraction ${echapper(a.fraction)}, constituée le ${echapper(a.constitution)}.
      ${a.salaries} salarié(s), ${a.lignes} lignes, SIREN ${echapper(a.siren)}.</p>
    ${a.remplace ? `<div class="encart attention"><b>Annule et remplace</b>
      Ce fichier remplace la déclaration ${echapper(a.remplace)}.</div>` : ""}
    <div class="encart attention">
      <b>Ordres de télépaiement — un dépôt réel les déclenche TOUS</b>
      ${v.length
        ? `<ul class="versements">${v.map((x) =>
             `<li class="num">${echapper(x)} €</li>`).join("")}</ul>
           L'organisme prélèvera ces montants. Ce ne sont pas des indications.`
        : "Aucun ordre de télépaiement dans ce fichier."}
    </div>`;
}

/* LE CHAMP DU MOT DE PASSE, ET CE QU'IL FAUT POUR QUE CHROME LE GARDE
   (Leandre, 15/09/2026 : « j'aimerais qu'on puisse enregistrer le mot de
   passe dans ce champ, qu'il soit déclaré comme mot de passe et qu'on puisse
   le sauvegarder avec Chrome »). Trois conditions, et il manquait les trois :
   une ORIGINE stable (port fixe et nom, côté serveur) ; un vrai FORMULAIRE
   autour des deux champs, sans quoi le navigateur ne voit pas une connexion ;
   et une demande d'enregistrement explicite après un acte réussi
   (`memoriserMotDePasse`), parce que rien ici ne « soumet » une page.
   L'utilisateur est figé à PuppetPaie : sans lui, Chrome prendrait pour
   identifiant le dernier texte tapé sur la page — « Amsterdam », un lieu de
   cachet. Le formulaire ne s'envoie jamais lui-même (onsubmit = false) : ce
   sont les boutons de la boîte qui agissent. */
function champMotDePasse(id, note) {
  return `<form class="champ-mdp" autocomplete="on" onsubmit="return false">
    <label class="champ-boite">Mot de passe du logiciel
      ${note ? `<span class="discret">${echapper(note)}</span>` : ""}
      <input type="text" class="utilisateur-fixe" name="username" autocomplete="username" value="PuppetPaie" readonly tabindex="-1" aria-label="utilisateur">
      <input type="password" id="${id}" name="password" autocomplete="current-password">
    </label>
  </form>`;
}

/** Après un acte réussi : proposer au navigateur de garder le mot de passe.
 *  Chrome affiche alors sa bulle « Enregistrer le mot de passe ? » — et le
 *  remplit d'avance la fois suivante, à condition que l'origine soit la même
 *  (d'où le port fixe). Silencieux partout où l'API n'existe pas. */
function memoriserMotDePasse(mdp) {
  try {
    if (!mdp || !window.PasswordCredential || !navigator.credentials) return;
    const c = new PasswordCredential({ id: "PuppetPaie", name: "PuppetPaie", password: mdp });
    navigator.credentials.store(c).catch(() => {});
  } catch (e) { /* rien : c'est une commodité */ }
}

function corpsDpae(a) {
  const deja = (a.embauches || []).filter((x) => x.deja_declaree).length;
  return `
    <p class="discret">${echapper(a.nom)} — ${a.enregistrements}
      enregistrement(s), ${a.octets} octets, indicateur
      ${echapper(a.indicateur)}.</p>
    <table>
      <tr><th>Salarié</th><th>Du</th><th>Au</th><th>Trace d'envoi</th></tr>
      ${(a.embauches || []).map((x) => `
        <tr>
          <td>${echapper(x.nom)}</td>
          <td>${echapper(jjmmaaaa(x.debut))}</td>
          <td>${echapper(jjmmaaaa(x.fin))}</td>
          <td>${x.deja_declaree
                ? `<span class="pastille alerte">déjà déclarée</span>`
                : `<span class="pastille bien">à déclarer</span>`}</td>
        </tr>`).join("")}
    </table>
    ${deja ? `<div class="encart attention">
      <b>${deja} embauche(s) de ce fichier ont déjà une trace d'envoi</b>
      Le fichier porte TOUT le mois : le déposer les redéclare. Déclarer deux
      fois la même embauche n'est pas anodin — l'Urssaf reçoit deux
      déclarations pour un seul contrat.</div>` : ""}`;
}

async function boiteDepot(quoi, fichier) {
  let a;
  try {
    a = await api("depot-apercu", { quoi, fichier });
  } catch (e) { dire(e.message, "erreur"); return; }

  ouvrirBoite(`
    <h3>Déposer ${quoi === "dsn" ? "la DSN" : "la DPAE"}</h3>
    ${moisEnGros(a.mois)}
    ${quoi === "dsn" ? corpsDsn(a) : corpsDpae(a)}
    ${a.deja_depose ? `<div class="encart attention">
      <b>Ce fichier a déjà été déposé</b>
      Le ${echapper(quand(a.deja_depose.quand))}, en mode
      ${echapper(a.deja_depose.mode)}. Redéposer le même fichier ne remplace
      rien : un annule-et-remplace se produit, il ne se redépose pas.</div>` : ""}
    ${blocSeance(a.seance)}
    <!-- Le champ « utilisateur » figé à PuppetPaie, dans chaque boîte à mot de
         passe : sans lui, Chrome prend pour identifiant le dernier texte
         tapé sur la page — « Amsterdam », un lieu de cachet — et propose de
         l'enregistrer sous ce nom. La demande : « pas
         d'utilisateur farfelu ; forcer l'utilisateur à PuppetPaie et laisser
         Chrome enregistrer le mot de passe ». D'où aussi
         autocomplete="current-password", que Chrome respecte, là où "off"
         est ignoré. -->
    ${champMotDePasse("d-motdepasse", "— exigé pour un dépôt réel")}
    <p class="note">C'est le mot de passe <b>du logiciel</b>, et il ne sert
      qu'à prouver que quelqu'un est là. Celui de l'organisme ne passe pas par
      cette page : le moteur va le chercher au coffre, séance ouverte.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="secondaire" id="d-test">Dépôt de test</button>
      <button class="primaire" id="d-reel" ${a.reel ? "" : "disabled"}>
        Dépôt RÉEL — ${echapper(a.mois)}</button>
    </div>
    ${a.reel ? "" : `<p class="note">Le fichier est codé <b>envoi de test</b> :
      déposé « pour de vrai », il ne déclarerait rien et rien ne serait
      conservé. Reproduire le mois sans l'option d'envoi de test pour pouvoir
      déclarer.</p>`}`);

  const lancer = async (reel, forcer = false) => {
    const mdp = document.getElementById("d-motdepasse").value;
    if (reel && !mdp) {
      dire("Un dépôt réel demande le mot de passe du logiciel.", "erreur");
      return;
    }
    document.getElementById("d-test").disabled = true;
    document.getElementById("d-reel").disabled = true;
    try {
      const r = await api("deposer", { quoi, fichier, reel, motdepasse: mdp, forcer });
      if (reel) memoriserMotDePasse(mdp);
      fermerBoite();
      afficherDepot(r);
      dire(reel ? "Dépôt réel effectué." : "Dépôt de test effectué.");
      await rafraichirActions();
    } catch (e) {
      document.getElementById("d-test").disabled = false;
      document.getElementById("d-reel").disabled = !a.reel;
      if (e.detail?.type === "DsnDejaDeposee") {
        // « On attend le retour, et si vraiment on y tient, après un
        // avertissement, on peut renvoyer ». Le mot de
        // passe déjà tapé sert au renvoi : on ne le redemande pas.
        return boiteRenvoiDsn(e.detail.etat, () => lancer(true, true));
      }
      dire(e.message, "erreur");
    }
  };
  document.getElementById("d-test").onclick = () => lancer(false);
  document.getElementById("d-reel").onclick = () => lancer(true);
}

/** Une DSN réelle est déjà partie pour ce mois. Dire où elle en est, et ne
 *  renvoyer que si on le veut vraiment. */
function boiteRenvoiDsn(etat, renvoyer) {
  const quand = etat && etat.quand ? quand_(etat.quand) : "?";
  const situation = etat.passee
    ? `Le bilan de conformité est arrivé : <b>elle est passée</b>, il n'y a
       rien à faire de notre côté.`
    : `<b>Son retour n'est pas encore arrivé</b> : on attend, on ne renvoie pas.`;
  ouvrirBoite(`
    <h3>Une DSN est déjà partie pour ce mois</h3>
    <div class="encart attention">
      <b>Déposée le ${echapper(quand)}${etat.flux ? ` — flux ${echapper(etat.flux)}` : ""}</b>
      ${situation}
    </div>
    <p class="note">Renvoyer quand même fait un <b>annule-et-remplace</b> à
      net-entreprises : la nouvelle DSN remplace la précédente, avec ses ordres
      de télépaiement. À ne faire que si c'est voulu — une paie corrigée, par
      exemple — et jamais parce qu'on n'a pas encore vu le retour.</p>
    <div class="actions">
      <button class="primaire" onclick="fermerBoite()">Ne pas renvoyer</button>
      <button class="secondaire" id="d-renvoyer">Renvoyer quand même</button>
    </div>`);
  document.getElementById("d-renvoyer").onclick = () => { fermerBoite(); renvoyer(); };
}
const quand_ = (iso) => quand(iso);

/* La réponse de l'organisme, en entier et telle quelle. On n'en fait pas un
 * résumé : c'est la pièce, et c'est elle qu'on relira le jour où un retour
 * dira le contraire. */
function afficherDepot(r) {
  document.getElementById("resultat").innerHTML = `
    <div class="carte" style="margin-top:20px">
      <h2>${echapper(r.quoi.toUpperCase())} ${echapper(r.mois || "")} —
        ${r.reel ? "dépôt réel" : "dépôt de test"}</h2>
      ${r.deja ? `<div class="encart attention"><b>Ce fichier avait déjà été
        déposé</b> Le ${echapper(quand(r.deja.quand))}.</div>` : ""}
      ${r.flux
        ? `<div class="encart bien"><b>Flux ${echapper(r.flux)}</b>
           C'est par ce numéro que les retours de l'organisme se rattacheront
           à ce dépôt.</div>`
        : `<div class="encart attention"><b>Pas d'identifiant de flux</b>
           La réponse n'en portait pas : les retours ne pourront pas se
           rattacher seuls à ce dépôt, et le diront.</div>`}
      <pre class="reponse">${echapper(r.reponse || "")}</pre>
      ${r.trace ? `<p class="note">Réponse entière archivée dans
        ${echapper(r.trace)}</p>` : ""}
    </div>`;
}

/* ------------------------------------------ les documents aux salariés */
async function boiteEnvoi(mois) {
  let a;
  try {
    a = await api("envoi-apercu", { mois });
  } catch (e) { dire(e.message, "erreur"); return; }

  // LE MOTEUR DIT S'IL PEUT (documents_prets) : DSN déposée et passée, AER
  // revenue, documents écrits. Et un compte Google pour ENVOYER — sans lui,
  // les documents se donnent à la main depuis le dossier du mois.
  const peut = a.pret && a.google_lie;
  ouvrirBoite(`
    <h3>Envoyer les documents</h3>
    ${moisEnGros(mois)}
    ${a.google_lie ? `<p class="discret">Depuis ${echapper(a.expediteur)}.</p>`
      : `<div class="encart attention"><b>Aucun compte Google lié</b>
         Veuillez lier un compte Google (à l'ouverture du logiciel) pour
         envoyer par courriel. En attendant, les documents s'ouvrent depuis
         le dossier du mois et se remettent à la main.</div>`}
    ${(a.empechements || []).map((x) =>
      `<div class="encart attention">${echapper(x)}</div>`).join("")}
    ${(a.avertissements || []).map((x) =>
      `<div class="encart attention">${echapper(x)}</div>`).join("")}
    ${!a.produit ? "" : `<table>
      <tr><th>Salarié</th><th>Adresse</th><th>Pièces</th><th>Taille</th></tr>
      ${a.messages.map((m) => `
        <tr>
          <td>${echapper(m.nom)}</td>
          <td>${echapper(m.destinataire)}</td>
          <td>${echapper(m.pieces.join(", "))}</td>
          <td class="num">${Math.round(m.octets / 1024)} ko</td>
        </tr>`).join("")}
    </table>`}
    ${a.deja ? `<div class="encart attention"><b>Déjà envoyé</b>
      Le ${echapper(quand(a.deja.quand))} — ${echapper(a.deja.reponse || "")}.
      Renvoyer enverra une seconde fois.</div>` : ""}
    ${peut ? champMotDePasse("e-motdepasse") + `
    <p class="note">Un courriel n'engage pas l'employeur comme une
      déclaration — personne ne prélève rien — mais il part chez quelqu'un et
      ne revient pas.</p>` : ""}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      ${a.produit ? `<button class="secondaire" id="e-dossier">Ouvrir le dossier des documents</button>`
                  : `<button class="secondaire" id="e-ecrire">Écrire le mois…</button>`}
      <button class="primaire" id="e-envoyer" ${peut ? "" : "disabled"}
              title="${peut ? "" : echapper((a.empechements || []).concat(
                a.google_lie ? [] : ["Aucun compte Google lié."]).join(" "))}">Envoyer à
        ${a.messages.length} salarié(s)</button>
    </div>`);

  const dossier = document.getElementById("e-dossier");
  if (dossier) dossier.onclick = () => ouvrirDossier(dossier, mois, "documents");
  const ecrire = document.getElementById("e-ecrire");
  if (ecrire) ecrire.onclick = () => boiteProduire(mois, () => boiteEnvoi(mois));
  document.getElementById("e-envoyer").onclick = async () => {
    const mdp = document.getElementById("e-motdepasse").value;
    if (!mdp) { dire("Le mot de passe du logiciel est demandé.", "erreur"); return; }
    document.getElementById("e-envoyer").disabled = true;
    try {
      const r = await api("envoyer-documents", { mois, motdepasse: mdp });
      memoriserMotDePasse(mdp);
      fermerBoite();
      dire(r.partis.length + " message(s) envoyé(s).");
      afficherEnvoi("Documents aux salariés", mois, r.partis, r.avertissements);
      await rafraichirActions();
    } catch (e) {
      document.getElementById("e-envoyer").disabled = false;
      dire(e.message, "erreur");
    }
  };
}

/* --------------------------------------------- les contrats à faire signer */

/** « signé par courriel le … » ou « signé, reçu le … » : le journal sait
 *  d'où vient la mention (contrats_recus_comment), l'écran ne fait que
 *  l'écrire. */
function signeLe(quandRecu, par) {
  return (par === "courriel" ? "signé d'un clic le " : "signé, reçu le ") + quand(quandRecu);
}

async function boiteSignature(mois, seulement) {
  let a;
  try {
    a = await api("signature-apercu", { mois });
  } catch (e) { dire(e.message, "erreur"); return; }

  // Cochés d'avance : ceux dont aucune demande n'est partie. Redemander une
  // signature déjà demandée se fait — on relance quelqu'un — mais ça se
  // décide, ça ne se coche pas tout seul.
  //
  // `seulement` : la sélection venue des cases de la colonne de gauche. Elle
  // REMPLACE la règle du dessus — quelqu'un qui a coché trois paies a déjà
  // choisi, et lui recocher les autres serait défaire son geste. La liste
  // reste entière : on voit ce qu'on n'a pas pris, et on peut le reprendre.
  // Coché d'office : ce qui n'est ni demandé ni revenu signé. Un contrat
  // reçu ne repart pas, même dans une sélection.
  const choisi = (c) => !c.recu_le && (seulement ? seulement.includes(c.salarie) : !c.demande_le);
  ouvrirBoite(`
    <h3>Demander la signature des contrats</h3>
    ${moisEnGros(mois)}
    <div class="encart">
      <b>Signature d'un clic</b>
      Le contrat part par courriel avec un bouton « Je signe ». Le salarié
      appuie dessus, sa messagerie s'ouvre sur une réponse toute écrite avec
      un code unique, il l'envoie. Rien à faire ensuite : la réponse est
      relevée toute seule, à l'ouverture et avec la sauvegarde régulière —
      la signature passe au journal, le message est gardé comme preuve, et
      le salarié reçoit son contrat contresigné.${a.attendues ? ` <b>${a.attendues}
      réponse${a.attendues > 1 ? "s" : ""} attendue${a.attendues > 1 ? "s" : ""}.</b>` : ""}
      Un contrat signé à la main se note toujours d'un clic sur sa pastille.
    </div>
    ${a.google_lie && !a.lecture_autorisee ? `<div class="encart attention">
      <b>Le compte Google ne peut pas lire la boîte</b>
      Les contrats partiront, mais les signatures ne reviendront pas toutes
      seules. Dans un terminal : <code>python -m moteur google autoriser</code>,
      pour redemander l'autorisation avec la lecture.</div>` : ""}
    <div class="liste-choix">
      ${a.contrats.map((c) => `
        <label class="choix">
          <input type="checkbox" class="s-qui" value="${echapper(c.salarie)}"
                 data-debut="${echapper(c.debut)}" ${choisi(c) ? "checked" : ""}>
          <span><b>${echapper(c.nom)}</b> — ${echapper(c.spectacle)}, du
            ${echapper(jjmmaaaa(c.debut))} au ${echapper(jjmmaaaa(c.fin))}
            ${c.numero ? `<span class="discret">(contrat n° ${echapper(c.numero)})</span>` : ""}
            <br><span class="discret">${echapper(c.destinataire)
              || "aucun courriel dans la fiche — l'envoi sera refusé"}</span>
            ${c.recu_le ? `<br><span class="pastille bien">${echapper(signeLe(c.recu_le, c.recu_par))}</span>`
              : c.demande_le ? `<br><span class="pastille alerte">demandé le
              ${echapper(quand(c.demande_le))} — pas encore revenu</span>` : ""}</span>
        </label>`).join("")}
    </div>
    ${a.google_lie ? champMotDePasse("s-motdepasse") : `<div class="encart attention"><b>Aucun compte Google lié</b>
      Veuillez lier un compte Google (à l'ouverture du logiciel) pour envoyer
      les contrats par courriel. En attendant, ils s'ouvrent depuis le dossier
      du mois et se font signer à la main.</div>`}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      ${a.produit ? `<button class="secondaire" id="s-dossier">Ouvrir le dossier des contrats</button>`
                  : `<button class="secondaire" id="s-ecrire">Écrire le mois…</button>`}
      <button class="primaire" id="s-envoyer" ${a.google_lie ? "" : "disabled"}
              title="${a.google_lie ? "" : "Aucun compte Google lié."}">Envoyer les contrats</button>
    </div>`);

  const dossierS = document.getElementById("s-dossier");
  if (dossierS) dossierS.onclick = () => ouvrirDossier(dossierS, mois, "contrats");
  const ecrireS = document.getElementById("s-ecrire");
  if (ecrireS) ecrireS.onclick = () => boiteProduire(mois, () => boiteSignature(mois, seulement));
  document.getElementById("s-envoyer").onclick = async () => {
    // Par CONTRAT : un salarié peut avoir un contrat coché et un autre non.
    const contrats = [...document.querySelectorAll(".s-qui:checked")]
      .map((c) => ({ salarie: c.value, debut: c.dataset.debut }));
    if (!contrats.length) { dire("Aucun contrat coché.", "erreur"); return; }
    const mdp = document.getElementById("s-motdepasse").value;
    if (!mdp) { dire("Le mot de passe du logiciel est demandé.", "erreur"); return; }
    document.getElementById("s-envoyer").disabled = true;
    try {
      const r = await api("demander-signature", { mois, contrats, motdepasse: mdp });
      memoriserMotDePasse(mdp);
      fermerBoite();
      dire(r.partis.length + " contrat(s) envoyé(s) à la signature.");
      afficherEnvoi("Contrats à signer", mois, r.partis,
                    r.contrats.map((c) => c.fichier));
      await rafraichirActions();
    } catch (e) {
      document.getElementById("s-envoyer").disabled = false;
      dire(e.message, "erreur");
    }
  };
}

/** Ouvre le dossier du mois dans l'explorateur, et le DIT dans la boîte :
 *  le bandeau du haut est sous la boîte, on ne le voit pas d'ici. Une
 *  fenêtre de l'explorateur peut s'ouvrir derrière PuppetPaie — le chemin
 *  écrit ici permet de la retrouver. */
async function ouvrirDossier(bouton, mois, quoi) {
  let note = bouton.parentNode.querySelector(".note-dossier");
  if (!note) {
    note = document.createElement("p");
    note.className = "note note-dossier";
    bouton.parentNode.appendChild(note);
  }
  try {
    await api("ouvrir-dossier", { mois, quoi });
    note.textContent = "";                 // l'explorateur passe devant
  } catch (e) {
    note.textContent = e.message;
    note.classList.add("erreur");
  }
}

function afficherEnvoi(titre, mois, partis, details) {
  document.getElementById("resultat").innerHTML = `
    <div class="carte" style="margin-top:20px">
      <h2>${echapper(titre)} — ${echapper(moisEnClair(mois))}</h2>
      <div class="encart bien"><b>${partis.length} message(s) parti(s)</b>
        ${echapper(partis.join(", "))}</div>
      ${(details || []).length
        ? `<p class="note">${echapper(details.join(" · "))}</p>` : ""}
    </div>`;
}

/* ------------------------------------------- la reprise du journal
   Le journal des dépôts est né le 11/09/2026 au soir. Tout ce qui est parti
   avant — par CoolPaie, par le site, ou par nos propres dépôts de la veille —
   n'y figure pas, et l'écran affiche donc « rien n'est parti » sur des actes
   qui ont bel et bien eu lieu. Devant la liste des embauches :

     « je comprends pas pourquoi il veut que je renvoie ça alors qu'on l'a
       déjà envoyé et on a les traces de dépôt il me semble »

   Ce bloc lui rend ce qu'il savait. Il n'apparaît QUE s'il y a quelque chose
   à reprendre : une fois le journal à jour, il disparaît et ne revient que si
   un nouveau dépôt atteste d'un chemin qui n'est pas passé par ici.

   DEUX TEMPS, comme partout ailleurs : on montre d'abord ce qui serait écrit,
   ligne par ligne, et on n'écrit que sur un second clic. Une reprise qui part
   au premier appel est une reprise qu'on lance « pour voir » et qui laisse
   des lignes que personne n'a relues. */
async function dessinerReprise() {
  const cible = document.getElementById("reprise");
  if (!cible) return;
  let r;
  try {
    r = await api("journal-reprise", {});
  } catch (e) {
    cible.innerHTML = "";
    return;
  }
  if (!r.ajoutes.length) { cible.innerHTML = ""; return; }

  const reels = r.ajoutes.filter((v) => v.mode === "reel" && v.accepte);
  cible.innerHTML = `
    <h2>Dépôts retrouvés <span class="discret">— pas encore au journal</span></h2>
    <div class="encart attention">
      <b>${r.ajoutes.length} dépôt(s) attestés par les retours, absents du journal</b>
      Le journal des dépôts est né le 11/09/2026 ; ce qui est parti avant ne
      s'y est pas écrit. Les accusés d'enregistrement archivés dans
      <code>retours/</code>, eux, s'en souviennent. Les reprendre ne dépose
      rien et n'envoie rien : ça remet au journal ce qui a déjà eu lieu.
      ${reels.length ? `<br><b>${reels.length} sont des dépôts RÉELS acceptés.</b>` : ""}
    </div>
    <div class="liste-choix">
      ${r.ajoutes.map((v) => `
        <div class="choix"><span>
          <b>${echapper(quand(v.quand))}</b>
          — ${echapper(v.mois ? moisEnClair(v.mois) : "mois inconnu")}
          <span class="pastille ${v.mode === "reel" ? (v.accepte ? "bien" : "erreur") : "alerte"}">
            ${v.mode === "reel" ? "dépôt réel" : "test"}${v.accepte ? "" : " — refusé"}</span>
          <br><span class="discret">déposé par ${echapper(v.logiciel || "logiciel inconnu")}
            · flux ${echapper(v.flux)}</span>
        </span></div>`).join("")}
    </div>
    <button class="secondaire" id="reprendre">Reprendre ces ${r.ajoutes.length} dépôt(s)</button>
    <p class="note">Le nom du logiciel n'est pas une annotation : il est lu
      dans le certificat de conformité. C'est lui qui distingue un dépôt
      CoolPaie d'un dépôt PuppetPaie.</p>`;

  document.getElementById("reprendre").onclick = async () => {
    document.getElementById("reprendre").disabled = true;
    try {
      const f = await api("journal-reprise", { ecrire: true });
      dire(f.ajoutes.length + " dépôt(s) remis au journal"
           + (f.rattaches ? ", " + f.rattaches + " retour(s) rattachés." : "."));
      await rafraichirActions();
      await dessinerReprise();
    } catch (e) {
      document.getElementById("reprendre").disabled = false;
      dire(e.message, "erreur");
    }
  };
}

/* --------------------------------- les embauches sans trace d'envoi
   La demande était « un bouton qui envoie les DPAE des contrats pas encore
   envoyés ». Ce qu'on peut faire honnêtement aujourd'hui, c'est la LISTE et
   le chemin vers le dépôt : le fichier DPAE d'un mois porte tout le mois, et
   il n'existe pas encore de production qui ne reprendrait qu'une partie des
   engagements. Le récapitulatif du dépôt dit alors, ligne par ligne, ce qui a
   déjà une trace — c'est là que la nuance se joue, pas ici.

   DU MOIS AFFICHÉ, ET DE LUI SEUL, depuis le 12/09/2026 :

     « je vois octobre dans septembre »
     « chaque mois doit être autonome »

   La liste balayait tous les mois connus. Une saisie d'essai laissée en
   octobre s'affichait donc dans la colonne de septembre, avec son bouton
   « Voir la DPAE d'octobre… » — un dépôt d'un autre mois à un clic, dans une
   colonne qui ne parle que de celui-ci. Le moteur savait déjà filtrer
   (`embauches_a_declarer(ctx, mois)`) ; on lui passe enfin le mois. */
async function dessinerEmbauches(mois) {
  const cible = document.getElementById("embauches");
  const titre = document.getElementById("titre-embauches");
  // Plus de bloc dans la page depuis le 13/09/2026 : la pastille DPAE de
  // chaque paie et la boîte DPAE disent déjà tout. Le code reste pour le
  // jour où on voudrait la liste ailleurs.
  if (!cible) return;
  if (titre) {
    titre.innerHTML = `Embauches sans trace d'envoi
      <span class="discret">${mois ? "— " + echapper(moisEnClair(mois)) : ""}</span>`;
  }
  if (!mois) { cible.innerHTML = ""; return; }
  let liste;
  try {
    liste = (await api("embauches-a-declarer", { mois })).embauches;
  } catch (e) {
    cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`;
    return;
  }
  if (!liste.length) {
    cible.innerHTML = `<p class="discret">Toutes les embauches de
      ${echapper(moisEnClair(mois))} ont une trace d'envoi.</p>`;
    return;
  }
  cible.innerHTML = `
    <div class="encart attention">
      <b>« Pas de trace d'envoi », et non « pas déclarée »</b>
      Ce journal ne connaît que ce que <i>ce</i> logiciel a déposé. Une
      embauche déclarée par CoolPaie, ou à la main sur le site de l'Urssaf,
      figure ici quand même — et déclarer deux fois la même embauche n'est pas
      anodin.
    </div>
    <div class="acte">
      <ul class="embauches-liste">
        ${liste.map((x) => `
          <li>${echapper(x.nom)} — ${echapper(x.spectacle)}, du
            ${echapper(jjmmaaaa(x.debut))} au
            ${echapper(jjmmaaaa(x.fin))}</li>`).join("")}
      </ul>
      <button class="secondaire" data-embauche="${echapper(mois)}">
        Voir la DPAE ${echapper(deMois(mois))}…</button>
    </div>
    <p class="note">Le fichier DPAE d'un mois porte <b>tout</b> le mois.
      Le récapitulatif du dépôt dit, pour chaque embauche, si elle a déjà une
      trace.</p>`;
  cible.querySelectorAll("[data-embauche]").forEach((b) => {
    b.onclick = () => ouvrirDpaeDuMois(b.dataset.embauche);
  });
}

async function ouvrirDpaeDuMois(mois) {
  return boiteDpae(mois);
}

/* =======================================================================
   L'ÉCRAN PAR PAIE
   =======================================================================
   Demandé en regardant l'écran :

     « pour les contrats à signer, il pourrait y avoir plusieurs cases dans
       chaque paie, pour voir en un coup d'œil si la DPAE est faite, si le
       contrat est envoyé… »
     « et une case pour sélectionner, pour pouvoir en sélectionner plusieurs
       pour envoyer plusieurs contrats d'un coup, ou plusieurs DPAE d'un coup »

   Le moteur sait répondre depuis le 11/09 au soir (`operations.etat_par_paie`,
   `produire_dpae(paies=[…])`) ; ces deux fonctions n'avaient pas d'écran, et
   une fonction sans écran est une fonction que personne n'utilise.

   TROIS RÈGLES, ET LA PREMIÈRE EST TOUT LE SUJET :

   1. CHAQUE PASTILLE DIT À QUELLE MAILLE ELLE EST CONNUE. Les quatre actes ne
      se déclarent pas au même grain : une DPAE déclare une embauche, un
      contrat se signe par engagement, les documents partent par salarié, et
      une DSN est mensuelle — il n'existe pas de DSN d'une paie. Écrire « DSN
      déposée » sur un bloc de paie sans dire qu'on parle du mois promettrait
      une précision que le journal n'a pas. D'où le « du mois », le « de
      <nom> », sous la pastille — et la maille vient du moteur, pas d'ici.
   2. L'ÉTAT EST CELUI DE LA SAISIE ENREGISTRÉE, pas de ce qui est à l'écran.
      `etat_par_paie` lit `paies/AAAA-MM.json`. Un engagement qu'on vient
      d'ajouter ou de changer n'a donc pas d'état, et le bloc le DIT au lieu
      de montrer celui d'à côté. Une pastille verte sur une paie modifiée
      serait le pire mensonge possible ici.
   3. RIEN NE PART D'UN CLIC. Les deux actions groupées ouvrent les mêmes
      récapitulatifs que la colonne de droite, avec le même mot de passe du
      logiciel. Elles ne font que RESTREINDRE ce qui part à ce qui est coché.

   Ce qui n'est pas là, et qu'il ne faut pas croire oublié : le bouton
   « valider » par paie, et le bloc qui devient vert. « Valider » est un état
   de la SAISIE, pas un acte — rien ne part — et le moteur ne sait pas encore
   l'écrire. Le dessiner d'abord aurait fait une case à cocher qui ne se
   souvient de rien. Voir ETAT.md §19.12.
*/
let ETATS_PAIES = null;      // "clé|début" → les quatre actes ; null = pas lu

const clePaie = (salarie, debut) => salarie + "|" + debut;

/** Le (salarié, premier jour) d'un bloc, tel qu'il est SAISI à l'écran.
 *  Le moteur trie les dates et prend la première (`Engagement.debut`) : on
 *  fait pareil, sans quoi une paie saisie « 12 3 » ne se retrouverait pas. */
function paiesDuBloc(div) {
  // Les jours sont sur les lignes de paie depuis le 12/09/2026 : le premier
  // jour de la paie est le plus petit de TOUTES ses lignes -- sauf si le
  // contrat dit son début (un contrat en cours depuis octobre s'identifie
  // par le 12/10, pas par son premier cachet de novembre).
  const dates = joursDuBloc(div);
  const debut = div.querySelector(".e-debut")?.value || dates[0];
  if (!debut) return [];
  return salariesDuBloc(div).map((salarie) => ({ salarie, debut }));
}

/* LES TROIS ACTES D'UNE PAIE. Ils étaient quatre — la DSN en faisait partie,
   avec un « du mois » sous la pastille pour prévenir du contresens. La demande : « la DSN, elle ne doit pas être liée à la sélection, elle
   fait obligatoirement tout le mois, pas comme les DPAE ». Une mention sous
   une pastille ne rattrape pas une pastille mal placée : posée dans un bloc de
   paie, à côté d'une case à cocher qui sert à restreindre ce qui part, elle se
   lisait comme « la DSN de cette paie-ci ». Il n'existe pas de DSN d'une paie.
   Elle vit désormais dans la colonne du mois, et là seulement. */
const ACTES_PAIE = [
  { cle: "dpae", titre: "DPAE" },
  { cle: "signature", titre: "Contrat" },
  { cle: "documents", titre: "Documents" },
];

/** « de Puppis » : ce que la pastille couvre AU JUSTE, quand ce n'est pas
 *  cette paie-ci. Reste utile pour les documents, qui partent par salarié. */
function ditLaMaille(maille, ligne) {
  if (maille === "mois") return "du mois";
  if (maille === "salarie") {
    return "de " + String(ligne.nom || "ce salarié").split(" ")[0];
  }
  return "";
}

/* TROIS COULEURS, ET UN PETIT CARRÉ. La demande, devant les
   anciennes vignettes : « j'imaginais ça en petit, juste un petit carré qui
   est gris, qui passe au vert ou orange si problème ou pas encore arrivé — ça
   prend trop de place comme ça ».

   Elles prenaient en effet quatre encadrés sur toute la largeur du bloc, alors
   qu'on ne leur demande qu'un coup d'œil. Une ligne, trois carrés, trois
   libellés. Le détail — la date, la maille, l'état du retour — passe dans
   l'infobulle : il se lit quand on le cherche, et il ne se lit que là.

     gris     rien n'est parti ;
     orange   parti, mais l'accusé n'est pas arrivé (ou a refusé) ;
     vert     parti, et attesté.

   L'orange n'est pas décoratif : « envoyé » et « accepté » sont deux choses,
   et les confondre fait tenir pour faite une déclaration en attente. Pour les
   contrats et les documents, il n'existe pas d'accusé — un envoi est un envoi,
   et le vert est alors la vérité entière. */
function couleurPastille(cle, e) {
  // Le contrat a son accusé à lui : le papier signé qui revient, et c'est un
  // humain qui le dit d'un clic (contrat-recu). « Envoyé on passe à orange,
  // signé on passe au vert ». Un contrat signé sur
  // place, jamais envoyé, se marque reçu quand même : vert.
  if (cle === "signature") {
    if (e && e.recu) return "vert";
    return (e && e.fait) ? "orange" : "gris";
  }
  if (!e || !e.fait) return "gris";
  if (cle !== "dpae") return "vert";          // pas d'accusé pour ces envois-là
  // La DPAE, elle, reçoit un certificat de conformité — et le moteur le dit
  // PAR PAIE (`passee`), sur le dépôt qui porte cette embauche-là. Refusée :
  // rouge, et c'est la seule pastille qui demande de REFAIRE quelque chose.
  if (e.refusee) return "rouge";
  return e.passee ? "vert" : "orange";
}

function infobulle(cle, titre, e, ligne) {
  // Un contrat en cours depuis un mois précédent : sa DPAE et sa signature
  // sont celles de ce mois-là. La pastille les montre (le journal les
  // connaît par salarié et début de contrat), et dit d'où elles viennent.
  // Les documents, eux, partent chaque mois : la mention ne les concerne pas.
  const enCours = cle !== "documents" && ligne && ligne.contrat && !ligne.contrat.premier_mois
    ? " (contrat en cours depuis " + moisEnClair(ligne.contrat.depuis) + ")" : "";
  if (cle === "signature") {
    const envoi = (e && e.fait) ? "envoyé le " + quand(e.fait) : "pas envoyé";
    if (e && e.recu) {
      return titre + " — " + envoi + enCours + " — " + signeLe(e.recu, e.recu_par)
        + " (cliquer pour retirer la mention)";
    }
    return titre + " — " + envoi + enCours + " — pas encore revenu signé"
      + " (cliquer quand il est là)";
  }
  if (!e || !e.fait) return titre + " — rien n'est parti" + enCours;
  const maille = ditLaMaille(e.maille, ligne);
  const couleur = couleurPastille(cle, e);
  if (couleur === "rouge") {
    return titre + " — envoyé le " + quand(e.fait) + " — REFUSÉ : "
      + ((e.anomalies || []).join(" ; ") || "motif non lu")
      + " — à corriger et à renvoyer";
  }
  return titre + " — envoyé le " + quand(e.fait) + enCours
    + (maille ? " (" + maille + ")" : "")
    + (couleur === "orange" ? " — accusé pas encore arrivé, on attend"
       : cle === "dpae" ? " — passée, rien à faire" + dossierUrssaf(e) : "");
}

/** La référence sous laquelle l'Urssaf a enregistré la DPAE (certificat de
 *  conformité, R_DOSSIER), quand elle est arrivée ; ou « déjà existante »
 *  quand l'Urssaf n'a rien créé parce qu'une DPAE identique était là. */
function dossierUrssaf(e) {
  if (!e) return "";
  if (e.deja_existante) return " (déjà existante à l'Urssaf, rien de créé)";
  return e.dossier ? " (dossier " + e.dossier + ")" : "";
}

/** Le bandeau d'un bloc : une ligne, un carré par acte. */
function bandeauEtats(ligne) {
  return `<div class="etats-actes">` + ACTES_PAIE.map((a) => {
    const e = ligne.etats[a.cle] || {};
    // La pastille du contrat se clique : c'est là qu'on dit « reçu signé ».
    const clic = a.cle === "signature"
      ? ` cliquable" data-salarie="${echapper(ligne.salarie)}"
          data-debut="${echapper(ligne.debut)}" data-recu="${e.recu ? "1" : "0"}"`
      : `"`;
    return `<span class="etat-acte ${couleurPastille(a.cle, e)}${clic}
        title="${echapper(infobulle(a.cle, a.titre, e, ligne))}">
      <i class="carre"></i>${echapper(a.titre)}${e.recu ? " ✓" : ""}</span>`;
  }).join("") + `</div>`;
}

/** Le clic sur la pastille Contrat : reçu signé, ou retrait de la mention.
 *  Pas de boîte : le geste est réversible d'un second clic, et le journal
 *  garde les deux. */
function brancherRecu(div) {
  div.querySelectorAll(".etat-acte.cliquable").forEach((s) => {
    s.onclick = async (ev) => {
      ev.preventDefault();
      const mois = document.getElementById("mois").value;
      const recu = s.dataset.recu !== "1";
      try {
        await api("contrat-recu", { mois, salarie: s.dataset.salarie,
                                    debut: s.dataset.debut, recu });
        dire(recu ? "Contrat signé reçu — noté au journal."
                  : "Mention retirée : le contrat signé n'est pas là.");
        await dessinerEtatsDesPaies(mois);
        await rafraichirActions();
      } catch (e) { dire(e.message, "erreur"); }
    };
  });
}

/** Peint les états sur les blocs. Rappelée après chaque frappe : changer le
 *  salarié ou les jours change la paie que le bloc désigne. */
function peindreEtats() {
  let refaire = false;
  document.querySelectorAll(".engagement").forEach((div) => {
    const cible = div.querySelector(".etats");
    if (!cible) return;
    const ps = paiesDuBloc(div);
    const lignes = ETATS_PAIES
      ? ps.map((p) => ETATS_PAIES[clePaie(p.salarie, p.debut)]).filter(Boolean)
      : [];
    const connue = ps.length > 0 && lignes.length === ps.length;
    div.classList.toggle("enregistree", connue);
    if (!ETATS_PAIES) { cible.innerHTML = ""; return; }
    if (!connue) {
      fermerEdition(div, false);
      if (!salariesDuBloc(div).length) {
        // Sans salarié, ce bloc n'est pas une paie : il n'est même pas
        // enregistré. Le dire, plutôt que de laisser un bloc muet qu'on
        // ne peut ni valider ni faire partir.
        cible.innerHTML = `<p class="etats-absent">Cocher un ou plusieurs
             salariés pour que cette paie existe. Tant que ce n'est pas fait,
             rien n'est enregistré.</p>
           <div class="validation"><span class="boutons">${BOUTON_RETIRER}</span></div>`;
        brancherRetirer(div);
        return;
      }
      // Le cas courant et normal : une paie qu'on vient d'ajouter ou de
      // changer. Pas de pastille grise — une pastille, même grise, se lit
      // comme un état connu. Le message ne dit plus « Enregistrer la saisie
      // d'abord » : le bouton n'existe plus, l'enregistrement se fait tout
      // seul une seconde après la frappe, et il n'y a donc rien à faire —
      // seulement à attendre que l'écran se rattrape.
      cible.innerHTML = (ps.length
        ? `<p class="etats-absent">Pas encore dans la saisie enregistrée :
             rien ne peut partir pour cette paie. L'enregistrement suit la
             frappe d'une seconde.</p>`
        : "") + `<div class="validation"><span class="boutons">${BOUTON_RETIRER}</span></div>`;
      brancherRetirer(div);
      return;
    }
    if (lignes.length === 1) {
      const ligne = lignes[0];
      const contrat = ligne.contrat && !ligne.contrat.premier_mois
        ? ` <span class="discret">· contrat en cours depuis ${echapper(moisEnClair(ligne.contrat.depuis))}</span>`
        : ligne.contrat && !ligne.contrat.dernier_mois
          ? ` <span class="discret">· se poursuit jusqu'en ${echapper(moisEnClair(ligne.contrat.jusqu_a))}</span>`
          : "";
      cible.innerHTML = `<span class="etats-qui">${echapper(ligne.nom)}
          <span class="discret">— ${echapper(ligne.spectacle)}</span>${contrat}</span>`
        + bandeauEtats(ligne) + bandeauValidation(ligne);
      brancherValidation(div, ligne);
      brancherRecu(div);
      fermerEdition(div, !!ligne.valide);
      return;
    }
    // PLUSIEURS PAIES DANS UN BLOC : pas encore validées, sinon le bloc
    // aurait été démultiplié. Si l'une l'a été ailleurs (un autre onglet),
    // on démultiplie maintenant et on repeint.
    if (lignes.some((l) => l.valide)) { dedoubler(div); refaire = true; return; }
    cible.innerHTML = lignes.map((l) =>
      `<span class="etats-qui">${echapper(l.nom)}
         <span class="discret">— ${echapper(l.spectacle)}</span></span>` + bandeauEtats(l))
      .join("")
      + `<div class="validation">
           <span class="discret">Édition ouverte — ${lignes.length} paies dans
             ce bloc, un bloc par salarié après validation</span>
           <span class="boutons">
             ${BOUTON_RETIRER}
             <button class="secondaire v-valider-tout">Valider ces ${lignes.length}
               paies</button>
           </span>
         </div>`;
    cible.querySelector(".v-valider-tout").onclick = (ev) => {
      ev.preventDefault();
      validerPlusieurs(div, lignes);
    };
    brancherRetirer(div);
    brancherRecu(div);
    fermerEdition(div, false);
  });
  if (refaire) return peindreEtats();
}

/** Valide chaque paie du bloc, PUIS le démultiplie : « il faut le bouton
 *  valider, et une fois validé ça se démultiplie ».
 *  Chaque bloc né ici se repeint validé, fermé, avec son propre
 *  « Modifier… ». Si une validation échoue, on s'arrête là : ce qui est
 *  validé l'est, le reste se voit au repeint. */
async function validerPlusieurs(div, lignes) {
  const mois = document.getElementById("mois").value;
  let faites = 0;
  try {
    for (const l of lignes) {
      await api("valider-paie", { mois, salarie: l.salarie, debut: l.debut,
                                  valide: true });
      faites += 1;
    }
    dire(`${faites} paies validées — un bloc par salarié, édition fermée.`);
  } catch (e) {
    dire(e.message + (faites ? ` (${faites} paie(s) validée(s) avant)` : ""),
         "erreur");
  }
  if (faites) dedoubler(div);
  await dessinerEtatsDesPaies(mois);
}

/** Lit `etat-par-paie` et repeint. */
async function dessinerEtatsDesPaies(mois) {
  ETATS_PAIES = null;
  if (!mois) { peindreEtats(); return; }
  try {
    const r = await api("etat-par-paie", { mois });
    ETATS_PAIES = {};
    r.paies.forEach((l) => { ETATS_PAIES[clePaie(l.salarie, l.debut)] = l; });
  } catch (e) {
    // Mois jamais enregistré, spectacle manquant, saisie en cours : il n'y a
    // rien à peindre, et rien d'alarmant à dire. La saisie, elle, marche.
    ETATS_PAIES = {};
  }
  peindreEtats();
}

/* ------------------------------------------------ valider une paie
   « On valide, c'est vert, normalement on n'y revient pas, édition bloquée
   temporairement avec un bouton pour modifier avec avertissement » —
   11 et 12/09/2026.

   Trois choses, et la troisième est celle qui compte.

   1. VERT, et sur le bloc entier. Une pastille de plus se serait perdue au
      milieu des quatre autres ; c'est le bloc qui change d'état, pas un
      détail dedans.
   2. ÉDITION FERMÉE. Les champs passent en lecture seule pour de vrai
      (`disabled`), pas seulement grisés : une paie validée qu'on peut encore
      modifier par distraction n'est pas validée.
   3. L'AVERTISSEMENT DIT CE QUE LÉANDRE A DIT. Pas « êtes-vous sûr ? », qui
      ne renseigne personne — mais la conséquence exacte qu'il a lui-même
      nommée : modifier une paie validée peut obliger à refaire la DPAE. Et
      quand la DPAE est DÉJÀ partie pour cette paie, l'écran le sait
      (`etat_par_paie`) et le dit avec sa date. C'est la différence entre un
      avertissement qu'on lit et un avertissement qu'on clique. */

/** Ferme ou rouvre les champs d'un bloc. Le bouton de validation, lui, reste
 *  actif — sinon on ne pourrait plus rouvrir. */
function fermerEdition(div, ferme) {
  div.classList.toggle("validee", ferme);
  div.querySelectorAll("input, select, button").forEach((c) => {
    if (c.classList.contains("v-basculer") || c.classList.contains("retirer-paie")) return;
    if (c.classList.contains("verrou")) return;    // un contrat en cours
    c.disabled = ferme;
  });
}

/* RETIRER UNE PAIE : un vrai bouton, en bas à droite, à côté de « Valider »
   — et non plus une petite croix à côté du métier (Léandre, 15/09/2026 :
   « plus clair, une case comme valider la paie, avec un avertissement »).
   L'avertissement n'est là que quand il y a quelque chose à perdre : une
   paie validée, un contrat envoyé à la signature ou revenu signé, une DPAE
   partie. Sinon le bloc s'en va, et l'enregistrement suit. */
const BOUTON_RETIRER = `<button class="lien retirer-paie" title="retirer cette paie de la saisie">Retirer cette paie</button>`;

/** Le bandeau de validation d'un bloc, sous les quatre pastilles. */
function bandeauValidation(ligne) {
  if (ligne.valide) {
    return `<div class="validation faite">
      <span><b>Paie validée</b> le ${echapper(quand(ligne.valide))}
        <span class="discret">— édition fermée</span></span>
      <span class="boutons">
        ${BOUTON_RETIRER}
        <button class="lien v-basculer" data-valide="0">Modifier…</button>
      </span>
    </div>`;
  }
  return `<div class="validation">
    <span class="discret">Édition ouverte</span>
    <span class="boutons">
      ${BOUTON_RETIRER}
      <button class="secondaire v-basculer" data-valide="1">Valider cette paie</button>
    </span>
  </div>`;
}

/** Branche le bouton d'un bloc, une fois le bandeau posé. */
function brancherValidation(div, ligne) {
  const b = div.querySelector(".v-basculer");
  if (b) b.onclick = (ev) => {
    ev.preventDefault();
    if (b.dataset.valide === "1") return basculerValidation(ligne, true);
    boiteRouvrir(ligne);
  };
  brancherRetirer(div);
}

/** Le bouton « Retirer cette paie » d'un bloc, quel que soit son état. */
function brancherRetirer(div) {
  const b = div.querySelector(".retirer-paie");
  if (!b) return;
  b.onclick = (ev) => {
    ev.preventDefault();
    const lignes = paiesDuBloc(div)
      .map((p) => ETATS_PAIES && ETATS_PAIES[clePaie(p.salarie, p.debut)])
      .filter(Boolean);
    const risques = [];
    lignes.forEach((l) => {
      const qui = l.nom;
      if (l.valide) risques.push(`${qui} : paie validée le ${quand(l.valide)}`);
      const s = l.etats.signature || {};
      if (s.recu) risques.push(`${qui} : contrat ${signeLe(s.recu, s.recu_par)}`);
      else if (s.fait) risques.push(`${qui} : contrat envoyé à la signature le ${quand(s.fait)}`);
      const d = l.etats.dpae || {};
      if (d.fait && !d.refusee) risques.push(`${qui} : DPAE déposée le ${quand(d.fait)}`);
    });
    const retirer = () => { div.remove(); rafraichirApercu(); dire("Paie retirée de la saisie."); };
    if (!risques.length) return retirer();
    ouvrirBoite(`
      <h3>Retirer cette paie ?</h3>
      <div class="encart erreur">
        <b>Quelque chose est déjà parti ou acté pour cette paie</b>
        <ul>${risques.map((r) => `<li>${echapper(r)}</li>`).join("")}</ul>
      </div>
      <p class="note">Retirer la paie ne défait rien de tout cela : une DPAE
        déposée reste déposée à l'Urssaf, un contrat envoyé reste envoyé. Si
        l'embauche n'a pas lieu, c'est une annulation de DPAE qu'il faut faire,
        pas un retrait à l'écran. Le journal garde ce qui est parti.</p>
      <div class="actions">
        <button class="secondaire" onclick="fermerBoite()">Garder la paie</button>
        <button class="primaire" id="r-retirer">Retirer quand même</button>
      </div>`);
    document.getElementById("r-retirer").onclick = () => { fermerBoite(); retirer(); };
  };
}

async function basculerValidation(ligne, valide) {
  const mois = document.getElementById("mois").value;
  try {
    await api("valider-paie", { mois, salarie: ligne.salarie,
                                debut: ligne.debut, valide });
    dire(valide ? "Paie validée — édition fermée."
                : "Édition rouverte pour cette paie.");
    await dessinerEtatsDesPaies(mois);
  } catch (e) { dire(e.message, "erreur"); }
}

/* Rouvrir demande un mot, pas un clic. Ce qui est écrit ici est ce que
 * c'est dit en posant la question — et la DPAE déjà partie est
 * nommée avec sa date quand c'est le cas. */
function boiteRouvrir(ligne) {
  const dpae = ligne.etats && ligne.etats.dpae && ligne.etats.dpae.fait;
  ouvrirBoite(`
    <h3>Rouvrir l'édition de cette paie</h3>
    <p class="discret">${echapper(ligne.nom)} — ${echapper(ligne.spectacle)},
      du ${echapper(jjmmaaaa(ligne.debut))} au ${echapper(jjmmaaaa(ligne.fin))}
      · validée le ${echapper(quand(ligne.valide))}</p>
    ${dpae ? `<div class="encart erreur">
      <b>La DPAE de cette embauche est déjà partie</b>
      Déposée le ${echapper(quand(dpae))}. Changer le salarié ou le premier
      jour travaillé fait une AUTRE embauche : celle qui est déclarée ne
      correspondrait plus, et il faudrait en déclarer une nouvelle. Changer
      seulement la rémunération ne touche pas à la DPAE.
    </div>` : `<div class="encart attention">
      <b>Modifier une paie validée peut obliger à refaire la DPAE</b>
      Aucune DPAE n'est encore partie pour cette paie — mais si elle part
      avant la modification, le premier jour travaillé et le salarié seront
      figés par la déclaration.
    </div>`}
    <p class="note">Rouvrir n'annule rien et ne défait rien : ça remet les
      champs en écriture. On peut revalider ensuite.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="v-rouvrir">Rouvrir l'édition</button>
    </div>`);
  document.getElementById("v-rouvrir").onclick = async () => {
    fermerBoite();
    await basculerValidation(ligne, false);
  };
}

/* PLUS DE CASE DE SÉLECTION NI DE BARRE D'ACTIONS GROUPÉES (15/09/2026) :
 * « on pourrait enlever la petite coche de sélection, tout se fait
 * directement quand on clique sur le bouton déposer DPAE ou demander les
 * signatures ». Les deux boîtes de la colonne de droite listent chaque
 * contrat du mois avec sa case, cochée d'avance sur ce qui reste à faire :
 * c'est là que l'on choisit, et rien ne part sans y être passé. */

/* LA BOÎTE DPAE, comme celle des signatures (Léandre, 15/09/2026 : « qu'il
 * y ait la liste déroulante et que soient déjà sélectionnés les contrats qui
 * n'ont pas de DPAE »). Chaque contrat du mois enregistré, une case ; cochée
 * d'avance si aucune DPAE n'est partie, ou si elle a été refusée. Un contrat
 * en cours depuis un mois précédent n'a pas de DPAE ce mois-ci : il se voit,
 * grisé, avec le mois où elle a été faite.
 *
 * DEUX TEMPS, ET C'EST VOULU : on ÉCRIT le fichier des embauches cochées,
 * puis on ouvre le récapitulatif de dépôt habituel. Écrire n'envoie rien et
 * ne consomme aucun compteur ; le dépôt reste le même geste, avec la même
 * relecture ligne à ligne et le même mot de passe. Le fichier prend un nom
 * horodaté, à côté du fichier complet du mois, jamais par-dessus. */
async function boiteDpae(mois) {
  if (!mois) { dire("Choisir un mois.", "erreur"); return; }
  let r;
  try {
    r = await api("etat-par-paie", { mois });
  } catch (e) {
    dire("Rien d'enregistré pour " + moisEnClair(mois) + " : saisir une paie d'abord.", "erreur");
    return;
  }
  const lignes = r.paies || [];
  if (!lignes.length) { dire("Aucune paie enregistrée en " + moisEnClair(mois) + ".", "erreur"); return; }
  const embauche = (l) => !l.contrat || l.contrat.premier_mois;
  // Déjà partie ET pas refusée : elle ne repart pas. Une refusée, si — c'est
  // même la seule raison de redéposer.
  const aFaire = (l) => embauche(l) && (!l.etats.dpae.fait || l.etats.dpae.refusee);

  ouvrirBoite(`
    <h3>Déclarer les embauches (DPAE)</h3>
    ${moisEnGros(mois)}
    <p class="note">Cochées d'avance : les embauches sans DPAE, ou dont la
      DPAE a été refusée. Une DPAE déjà passée ne se redéclare pas : l'Urssaf
      recevrait deux déclarations pour un seul contrat.</p>
    <div class="liste-choix">
      ${lignes.map((l, i) => {
        const e = l.etats.dpae;
        const etat = !embauche(l)
          ? `<br><span class="pastille">contrat en cours depuis
               ${echapper(moisEnClair(l.contrat.depuis))} — sa DPAE a été faite ce mois-là</span>`
          : !e.fait ? `<br><span class="pastille alerte">à déclarer</span>`
          : e.refusee
          ? `<br><span class="pastille erreur">refusée le ${echapper(quand(e.fait))}
               — ${echapper((e.anomalies || []).join(" ; ") || "motif non lu")}
               — à redéclarer</span>`
          : e.passee
          ? `<br><span class="pastille bien">déclarée le ${echapper(quand(e.fait))}
               — passée${echapper(dossierUrssaf(e))}</span>`
          : `<br><span class="pastille alerte">déclarée le ${echapper(quand(e.fait))}
               — retour pas encore arrivé : on attend, on ne renvoie pas</span>`;
        return `<label class="choix ${embauche(l) ? "" : "grise"}">
          <input type="checkbox" class="d-qui" data-i="${i}" ${aFaire(l) ? "checked" : ""}
                 ${embauche(l) ? "" : "disabled"}>
          <span><b>${echapper(l.nom)}</b> — ${echapper(l.spectacle)}, embauche le
            ${echapper(jjmmaaaa(l.debut))}${l.numero
              ? ` <span class="discret">(contrat n° ${echapper(l.numero)})</span>` : ""}
            ${etat}</span></label>`;
      }).join("")}
    </div>
    <p class="note">Heure d'embauche déclarée : 08h00. Écrire ne déclare rien :
      le dépôt vient après, avec sa relecture et le mot de passe du logiciel.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      <button class="primaire" id="d-ecrire">Écrire le fichier et déposer…</button>
    </div>`);

  const bouton = document.getElementById("d-ecrire");
  const majBouton = () => {
    const n = document.querySelectorAll(".d-qui:checked").length;
    bouton.disabled = !n;
    bouton.textContent = n ? `Écrire le fichier (${n}) et déposer…` : "Rien de coché";
  };
  document.querySelectorAll(".d-qui").forEach((c) => { c.onchange = majBouton; });
  majBouton();
  bouton.onclick = async () => {
    const choisies = [...document.querySelectorAll(".d-qui:checked")]
      .map((c) => lignes[+c.dataset.i]);
    if (!choisies.length) return;
    bouton.disabled = true;
    try {
      const w = await api("dpae", {
        mois, paies: choisies.map((l) => ({ salarie: l.salarie, debut: l.debut })),
      });
      fermerBoite();
      // Le dossier porte le fichier à déposer et son récapitulatif ; c'est le
      // premier qui se dépose.
      const f = (w.fichiers || []).find(
        (x) => /\.txt$/i.test(x.nom) && !/recapitulatif/i.test(x.nom));
      dire("Fichier écrit : " + (f ? f.nom : w.dossier));
      await rafraichirActions();
      if (f) boiteDepot("dpae", f.chemin);
    } catch (e) {
      bouton.disabled = false;
      dire(e.message, "erreur");
    }
  };
}

/* =======================================================================
   CONFIGURATION
   ===================================================================== */
let FICHE_ACTIVE = "entreprise";
let CLE_ACTIVE = null;

document.querySelectorAll(".sous-onglets button").forEach((b) => {
  b.onclick = () => {
    document.querySelectorAll(".sous-onglets button").forEach((x) => x.classList.remove("actif"));
    b.classList.add("actif");
    FICHE_ACTIVE = b.dataset.fiche;
    CLE_ACTIVE = null;
    dessinerConfig();
  };
});

function fichesDe(nom) {
  const c = ETAT.configuration;
  if (nom === "entreprise") return [c.entreprise];
  return nom === "salarie" ? c.salaries : c.spectacles;
}

function dessinerConfig() {
  const liste = document.getElementById("config-liste");
  if (FICHE_ACTIVE === "importer") {
    document.getElementById("config-formulaire").innerHTML = "";
    dessinerImportation(liste);
    return;
  }
  const fiches = fichesDe(FICHE_ACTIVE);
  if (FICHE_ACTIVE === "entreprise") {
    liste.innerHTML = "";
    CLE_ACTIVE = null;
    dessinerFormulaire(fiches[0]);
    return;
  }
  // Les archives en dernier, jamais melangees aux courantes. Elles restent
  // visibles : une fiche qu'on ne voit plus passe pour perdue, et on la
  // ressaisit -- avec un deuxieme code salarie, ce qui serait pire.
  const rangees = [...fiches].sort(
    (a, b) => (a.donnees.actif === false) - (b.donnees.actif === false));
  liste.innerHTML = `<h2>${FICHE_ACTIVE === "salarie" ? "Salariés" : "Spectacles"}
      <button class="secondaire" id="config-nouvelle">+ ${FICHE_ACTIVE === "salarie"
        ? "un salarié" : "un spectacle"}</button></h2>
    <div class="cartes">` + rangees.map((f) => {
      const err = f.anomalies.filter((a) => a.gravite === "erreur").length;
      const av = f.anomalies.length - err;
      const pastille = err ? `<span class="pastille erreur">${err} erreur(s)</span>`
        : av ? `<span class="pastille alerte">${av} à vérifier</span>`
             : `<span class="pastille bien">complet</span>`;
      const titre = f.donnees.titre || `${f.donnees.nom || ""} ${f.donnees.prenom_affichage || f.donnees.prenom || ""}`;
      const meta = f.donnees.numero_objet || f.donnees.emploi || "";
      const archive = f.donnees.actif === false;
      return `<div class="fiche-carte ${archive ? "archivee" : ""} ${f.cle === CLE_ACTIVE ? "selectionnee" : ""}" data-cle="${echapper(f.cle)}">
        <h3>${echapper(titre.trim() || f.cle)}</h3>
        <div class="meta">${echapper(meta)}</div>
        ${archive ? `<span class="pastille archive">archivé</span>` : pastille}</div>`;
    }).join("") + `</div>`;

  liste.querySelectorAll(".fiche-carte").forEach((c) => {
    c.onclick = () => {
      CLE_ACTIVE = c.dataset.cle;
      dessinerConfig();
      dessinerFormulaire(rangees.find((f) => f.cle === CLE_ACTIVE));
    };
  });
  document.getElementById("config-nouvelle").onclick = () => nouvelleFiche(FICHE_ACTIVE);
  if (!CLE_ACTIVE) document.getElementById("config-formulaire").innerHTML = "";
}

/* ---------------------------------------------------- l'import CoolPaie
   Deux temps, et jamais un seul : l'aperçu dit ce qui serait créé et ce que
   les DSN disaient autrement que les fiches ; le bouton n'écrit qu'après.
   Une fiche existante n'est jamais modifiée par l'import — la fiche fait
   foi, un changement se date à la main (operations_fiches). */
let IMPORT_EXPORT = "";

function dessinerImportation(cible) {
  cible.innerHTML = `<h2>Importer de CoolPaie
      <span class="discret">— ce qui est déjà déclaré ne se ressaisit pas</span></h2>
    <p class="note">CoolPaie garde dans son dossier <code>export/</code> les DSN
      et les AEM qu'il a déposées. On y lit les salariés (NIR, adresse, emploi),
      les numéros d'objet des spectacles, et chaque contrat attesté à France
      Travail — c'est cet historique qui compte pour les droits (507 h).
      Les fiches qui existent déjà ne sont pas touchées ; ce que la DSN disait
      autrement est seulement signalé.</p>
    <div class="e-contrat-champs">
      <label style="flex:1">Dossier <code>export/</code> de CoolPaie
        <input type="text" id="import-export" placeholder="vide : celui trouvé à côté des données"
               value="${echapper(IMPORT_EXPORT)}" style="width:100%">
      </label>
      <button class="secondaire" id="import-apercu">Voir ce qui serait importé</button>
    </div>
    <div id="import-resultat"></div>`;
  document.getElementById("import-apercu").onclick = () => apercuImportation();
}

function fichesImportees(fiches, titre) {
  const lignes = fiches.filter((f) => f).map((f) => {
    const etat = f.etat === "existante" ? `<span class="pastille bien">existe déjà</span>`
      : f.etat === "creee" ? `<span class="pastille bien">créée (${echapper(f.cle)})</span>`
      : `<span class="pastille alerte">à créer</span>`;
    const ecarts = Object.entries(f.ecarts || {}).map(([champ, e]) =>
      `<div class="acte-dernier">la DSN de ${echapper(moisEnClair(e.mois))} disait
         <b>${echapper(champ)}</b> = « ${echapper(e.dsn)} », la fiche dit
         « ${echapper(e.fiche)} » — la fiche fait foi</div>`).join("");
    const erreurs = (f.anomalies || []).filter((a) => a.gravite === "erreur").map((a) =>
      `<div class="acte-dernier" style="color:var(--erreur)">${echapper(a.champ)} : ${echapper(a.message)}</div>`).join("");
    return `<div class="mois-ligne" style="padding:8px 12px">
      <span class="titre" style="min-width:220px">${echapper(f.libelle)}</span>
      ${etat}
      <span class="fichiers">${ecarts}${erreurs}</span></div>`;
  });
  if (!lignes.length) return "";
  return `<h3>${titre}</h3>${lignes.join("")}`;
}

function vueImportation(r) {
  const periode = r.premier_mois ? ` (${moisEnClair(r.premier_mois)} → ${moisEnClair(r.dernier_mois)})` : "";
  const contrats = r.contrats
    ? `${r.contrats} contrat(s) attesté(s) du ${jjmmaaaa(r.contrats_du)} au ${jjmmaaaa(r.contrats_au)} :
       <b>${r.contrats_nouveaux} ${r.ecrit ? "ajouté(s)" : "à ajouter"}</b> à l'historique,
       ${r.contrats - r.contrats_nouveaux - r.contrats_sans_fiche} déjà connu(s)${
         r.contrats_sans_fiche ? `, ${r.contrats_sans_fiche} sans fiche` : ""}`
    : "aucun contrat attesté (pas d'AEM)";
  const avert = r.avertissements.map((a) => `<div class="encart attention">${echapper(a)}</div>`).join("");
  const nb = [r.entreprise, ...r.salaries, ...r.spectacles].filter((f) => f && f.etat === "a_creer").length;
  const bouton = r.ecrit
    ? `<div class="encart bien"><b>Importé.</b> ${r.fichiers.map((f) => echapper(f)).join("<br>")}</div>`
    : r.rien_a_faire
      ? `<div class="encart bien"><b>Rien à importer</b> : tout est déjà là.</div>`
      : `<p><button class="primaire" id="import-ecrire">Importer
           <span class="discret">— ${nb} fiche(s), ${r.contrats_nouveaux} contrat(s)</span></button>
         <span class="note">Rien n'est écrit avant ce clic.</span></p>`;
  return `<div class="encart"><b>${echapper(r.source)}</b>
      ${r.dsn} DSN${periode}, ${r.aem} fichier(s) AEM — ${contrats}</div>
    ${avert}
    ${fichesImportees([r.entreprise], "Entreprise")}
    ${fichesImportees(r.salaries, "Salariés")}
    ${fichesImportees(r.spectacles, "Spectacles")}
    ${bouton}`;
}

async function apercuImportation() {
  IMPORT_EXPORT = document.getElementById("import-export").value.trim();
  const cible = document.getElementById("import-resultat");
  cible.innerHTML = `<p class="discret">Lecture de l'export…</p>`;
  try {
    const r = await api("importation-apercu", { export: IMPORT_EXPORT });
    cible.innerHTML = vueImportation(r);
    const b = document.getElementById("import-ecrire");
    if (b) b.onclick = () => ecrireImportation();
  } catch (e) {
    cible.innerHTML = `<div class="encart erreur">${echapper(e.message)}</div>`;
  }
}

async function ecrireImportation() {
  const cible = document.getElementById("import-resultat");
  cible.classList.add("attente");
  try {
    const r = await api("importer", { export: IMPORT_EXPORT });
    cible.innerHTML = vueImportation(r);
    // Les fiches créées doivent apparaître dans Salariés et Spectacles, et
    // dans les déroulants de la saisie, sans recharger la page.
    ETAT = await api("etat");
    rafraichirReferentiels();
    dire(`Importé : ${r.contrats_nouveaux} contrat(s), ${
      [r.entreprise, ...r.salaries, ...r.spectacles].filter((f) => f && f.etat === "creee").length} fiche(s).`, "ok");
  } catch (e) {
    cible.innerHTML = `<div class="encart erreur">${echapper(e.message)}</div>`;
  } finally {
    cible.classList.remove("attente");
  }
}

function dessinerFormulaire(fiche) {
  if (!fiche) return;
  const desc = ETAT.configuration.description[FICHE_ACTIVE];
  const anomalie = (cle) => fiche.anomalies.find((a) => a.champ === cle);

  // Les champs CALCULES ne sont pas proposes a la saisie : c'est le
  // programme qui les fabrique. On les montre sous leur forme lisible, en
  // lecture seule, pour qu'on voie ce qui partira aux organismes.
  const declares = {};
  desc.filter((c) => c.calcule).forEach((c) => { declares[c.derive_de] = c; });

  const champs = desc.filter((c) => !c.calcule).map((c) => {
    const v = fiche.donnees[c.cle];
    const a = anomalie(c.cle);
    const calc = declares[c.cle];
    // L'histoire de la fiche se LIT, elle ne se tape pas : elle dit ce qui
    // est reellement parti aux organismes, et on ne reecrit pas une
    // declaration deposee. La montrer en JSON editable inviterait a la
    // corriger, ce qui est exactement ce qu'il ne faut pas.
    if (c.forme === "histoire") return histoireDuChamp(v, desc);
    const structure = c.forme === "structure" || (v !== null && typeof v === "object");
    // Un booleen se coche. Ecrit en toutes lettres, il partait en texte : et
    // « false » est une chaine VRAIE, donc la fiche serait restee active en
    // paraissant archivee.
    const controle = c.forme === "booleen"
      ? `<input type="checkbox" data-cle="${c.cle}" data-forme="booleen"
            ${v === false ? "" : "checked"}>`
      : structure
      ? `<textarea rows="4" data-cle="${c.cle}" data-structure="1">${echapper(JSON.stringify(v ?? null, null, 1))}</textarea>`
      : `<input data-cle="${c.cle}" data-forme="${c.forme}" value="${echapper(v ?? "")}"
            class="${a ? (a.gravite === "erreur" ? "faute" : "suspect") : ""}">`;
    return `<div class="champ ${structure ? "pleine" : ""}">
      <label>${echapper(c.libelle)}
        ${c.obligatoire ? '<span style="color:var(--erreur)">*</span>' : ""}
        ${c.declare ? '<span class="badge-declare" title="part dans une déclaration">déclaré</span>' : ""}
        ${controle}
      </label>
      ${c.aide ? `<div class="aide">${echapper(c.aide)}</div>` : ""}
      ${calc ? `<div class="declare" data-declare="${echapper(calc.cle)}">
          <span class="etiquette">déclaré</span>
          <span class="valeur">${echapper((fiche.declare || {})[calc.cle] || "")}</span>
        </div>` : ""}
      ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
    </div>`;
  }).join("");

  const err = fiche.anomalies.filter((a) => a.gravite === "erreur").length;
  document.getElementById("config-formulaire").innerHTML = `
    <div class="carte" style="margin-top:16px">
      <h2>${echapper(fiche.cle || (FICHE_ACTIVE === "entreprise" ? "Entreprise"
        : FICHE_ACTIVE === "salarie" ? "Nouveau salarié" : "Nouveau spectacle"))}</h2>
      ${!fiche.cle && FICHE_ACTIVE !== "entreprise" ? `<p class="note">La clé de la
        fiche${FICHE_ACTIVE === "salarie" ? " et le matricule" : ""} se
        fabriquent à l'enregistrement.</p>` : ""}
      ${err ? `<div class="encart erreur"><b>${err} erreur(s)</b>
        Une erreur empêche l'enregistrement : ces champs partent dans des
        déclarations, et une faute ne se voit qu'au rejet, des semaines plus tard.</div>` : ""}
      ${FICHE_ACTIVE === "salarie" ? `<div class="encart" id="config-metier">
        <label>Remplir l'emploi depuis le catalogue des métiers
          <select id="config-metier-choix">${optionsMetiers("")}</select></label>
        <div class="aide">Pose d'un coup l'emploi déclaré, le PCS-ESE, le code
          France Travail, le statut et le classement DSN — les six champs restent
          modifiables. <code>python -m moteur emplois</code> pour la liste et ses sources.</div>
      </div>` : ""}
      <div class="champs">${champs}</div>
      <div class="actions">
        <button class="primaire" id="config-enregistrer">Enregistrer</button>
        <button class="secondaire" id="config-verifier">Vérifier sans enregistrer</button>
      </div>
      <p class="note">L'ancienne version est copiée dans
         <code>config/avant/</code> avant toute écriture.</p>
    </div>`;

  document.querySelectorAll("#config-formulaire input, #config-formulaire textarea")
    .forEach((c) => { c.oninput = () => { clearTimeout(verifierFormulaire._t);
      verifierFormulaire._t = setTimeout(verifierFormulaire, 400); }; });
  document.getElementById("config-verifier").onclick = verifierFormulaire;
  document.getElementById("config-enregistrer").onclick = () => enregistrerFiche(fiche);
  const choixMetier = document.getElementById("config-metier-choix");
  if (choixMetier) choixMetier.onchange = () => remplirDepuisMetier(choixMetier.value);
}

/** Les six champs d'emploi d'une fiche salarié, depuis un métier du
 *  catalogue. La page ne calcule rien : elle recopie ce que le moteur rend
 *  (route « emploi »), qui applique les mêmes règles qu'un engagement. */
async function remplirDepuisMetier(code) {
  if (!code) return;
  let r;
  try { r = await api("emploi", { metier: code }); }
  catch (e) { dire(e.message, "erreur"); return; }
  const poser = (cle, v) => {
    const c = document.querySelector(`#config-formulaire [data-cle="${cle}"]`);
    if (c && v != null) c.value = v;
  };
  poser("emploi_affichage", r.emploi_affichage);
  poser("pcs_ese", r.pcs_ese || "");
  poser("code_emploi_ft", r.code_emploi_ft);
  poser("statut", r.statut);
  poser("statut_conventionnel", r.statut_conventionnel || "");
  poser("statut_categoriel_rc", r.statut_categoriel_rc);
  verifierFormulaire();
}

/*  L'HISTOIRE D'UNE FICHE
 *
 *  Une fiche n'est pas un etat, c'est une suite d'etats : on demenage, on
 *  change de telephone, et une valeur declaree se corrige. Chaque ligne dit
 *  ce qu'un champ valait et jusqu'a quel jour -- au-dela, la valeur courante
 *  du formulaire reprend la main.
 *
 *  C'est ce qui permet de rejouer une declaration deja deposee : la DSN de
 *  juillet est partie avec l'adresse de juillet, et elle doit pouvoir se
 *  recalculer a l'identique apres un demenagement en septembre.
 */
function histoireDuChamp(lignes, desc) {
  if (!Array.isArray(lignes) || !lignes.length) return "";
  const libelle = (cle) => (desc.find((c) => c.cle === cle) || {}).libelle || cle;
  const rangees = [...lignes].sort((a, b) =>
    a.champ === b.champ ? b.jusqu_au.localeCompare(a.jusqu_au)
                        : a.champ.localeCompare(b.champ));
  return `<div class="champ pleine">
    <label>Ce qui a changé</label>
    <div class="aide">Une valeur déclarée ne s'écrase pas : elle se date.
       Ce qui est déjà parti aux organismes porte l'ancienne forme, et le
       rejeu de l'historique en a besoin.</div>
    <div class="histoire">${rangees.map((e) => `
      <div class="histoire-ligne">
        <span class="histoire-champ">${echapper(libelle(e.champ))}</span>
        <span class="histoire-valeur">${echapper(e.valeur)}</span>
        <span class="histoire-date">jusqu'au ${echapper(jjmmaaaa(e.jusqu_au))}</span>
        ${e.note ? `<div class="histoire-note">${echapper(e.note)}</div>` : ""}
      </div>`).join("")}</div>
  </div>`;
}

function jjmmaaaa(iso) {
  if (!iso || iso.length !== 10) return iso || "";
  return `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}`;
}

const MOIS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
                 "août", "septembre", "octobre", "novembre", "décembre"];
/* « juillet 2021 » et non « 2021-07 » : on lit une phrase, pas un tri. */
function moisEnClair(iso) {
  if (!iso || iso.length !== 7) return iso || "";
  return `${MOIS_FR[Number(iso.slice(5, 7)) - 1]} ${iso.slice(0, 4)}`;
}

function lireFormulaire() {
  const d = {};
  document.querySelectorAll("#config-formulaire [data-cle]").forEach((c) => {
    if (c.dataset.structure) {
      try { d[c.dataset.cle] = JSON.parse(c.value); }
      catch (e) { c.classList.add("faute"); }
    } else if (c.dataset.forme === "booleen") {
      d[c.dataset.cle] = c.checked;      // un vrai booleen, pas « true »
    } else {
      d[c.dataset.cle] = c.value;
    }
  });
  return d;
}

async function verifierFormulaire() {
  const r = await api("verifier-fiche",
    { nom: FICHE_ACTIVE, donnees: lireFormulaire() });
  const anomalies = r.anomalies;
  // Ce que la machine fabrique, mis a jour a mesure qu'on tape.
  document.querySelectorAll("[data-declare]").forEach((el) => {
    el.querySelector(".valeur").textContent = r.declare[el.dataset.declare] || "";
  });
  document.querySelectorAll("#config-formulaire [data-cle]").forEach((c) => {
    const a = anomalies.find((x) => x.champ === c.dataset.cle);
    c.classList.toggle("faute", !!a && a.gravite === "erreur");
    c.classList.toggle("suspect", !!a && a.gravite === "avertissement");
  });
  dire(anomalies.length ? anomalies.length + " point(s) à regarder" : "Fiche valide");
  return anomalies;
}

/*  ENREGISTRER UNE FICHE : DATER CE QUI CHANGE
 *
 *  Le §18.12 du journal raconte ce qui arrive quand on ne le fait pas. Une
 *  commune de naissance a ete corrigee depuis cet ecran ; l'avertissement
 *  disait bien « enregistrer declarera PARIS 12E », et il etait juste. Ce
 *  qu'il ne disait pas, c'est que 55 DSN etaient deja parties avec l'autre
 *  forme, et que l'identite est ce sur quoi France Travail et la DGFiP
 *  rapprochent un salarie.
 *
 *  D'ou cette etape, et les deux choses qu'elle demande :
 *
 *   - A PARTIR DE QUAND la nouvelle valeur vaut. Par defaut aujourd'hui,
 *     modifiable : si une declaration est partie ce matin avec l'ancienne,
 *     la nouvelle ne vaut qu'a partir de demain. C'est l'humain qui sait.
 *   - POURQUOI. Une correction et un demenagement se datent pareil ; seule
 *     la note dira, dans deux ans, laquelle des deux c'etait.
 *
 *  Et elle MONTRE ce que l'ancienne valeur a deja servi a declarer, parce
 *  que c'est cette information-la qui fait decider.
 */
async function enregistrerFiche(fiche) {
  const donnees = lireFormulaire();
  const { changements } = await api("changements-declares",
    { nom: FICHE_ACTIVE, cle: fiche.cle, donnees });
  if (changements.length) {
    const daté = await demanderDateDEffet(changements);
    if (!daté) return;                       // annulé : rien n'est écrit
    return ecrireFiche(fiche, donnees, daté);
  }
  return ecrireFiche(fiche, donnees, {});
}

/* Une valeur declaree n'est pas toujours un mot : `signataire` et `banque`
 * sont des structures. `echapper(objet)` donnait « [object Object] → [object
 * Object] », c'est-a-dire un changement qu'on ne peut ni lire ni juger --
 * alors que c'est precisement ce que cette boite demande de juger. */
function valeurLisible(v) {
  if (v === null || v === undefined) return "—";
  if (typeof v === "object") {
    return Array.isArray(v) ? v.map(valeurLisible).join(" · ")
      : Object.entries(v).map(([k, x]) => `${k} : ${valeurLisible(x)}`).join(" · ");
  }
  return String(v);
}

function demanderDateDEffet(changements) {
  const aujourdHui = new Date().toISOString().slice(0, 10);
  return new Promise((resoudre) => {
    let repondu = false;
    const repondre = (v) => { if (!repondu) { repondu = true; resoudre(v); } };
    ouvrirBoite(`<h3>${changements.length} valeur${changements.length > 1 ? "s" : ""}
        déclarée${changements.length > 1 ? "s" : ""} change${changements.length > 1 ? "nt" : ""}</h3>
      <div class="changements">${changements.map((c) => {
        const u = c.deja_declare || {};
        return `<div class="changement">
          <div class="changement-titre">${echapper(c.libelle)}</div>
          <div class="changement-valeurs">
            <span class="avant">${echapper(valeurLisible(c.avant))}</span>
            <span class="fleche">→</span>
            <span class="apres">${echapper(valeurLisible(c.apres))}</span>
          </div>
          <div class="changement-prix">${u.declarations
            ? `<b>${u.declarations} déclaration${u.declarations > 1 ? "s" : ""}</b>
               déjà déposée${u.declarations > 1 ? "s" : ""} sous la forme
               « ${echapper(valeurLisible(c.avant))} »${u.du ? `, de ${echapper(moisEnClair(u.du))} à ${echapper(moisEnClair(u.au))}` : ""}.
               Elles ne changent pas : cette page ne réécrit pas le passé.`
            : `Aucune déclaration déposée ne porte cette valeur.`}</div>
        </div>`; }).join("")}</div>
      <label class="champ-boite">À partir de quand la nouvelle valeur s'applique
        <input type="date" id="b-depuis" value="${aujourdHui}">
      </label>
      <p class="note">L'ancienne vaudra jusqu'à la veille. Si une déclaration
         est partie ce matin avec l'ancienne valeur, mettre demain.</p>
      <label class="champ-boite">Pourquoi (correction, déménagement…)
        <input type="text" id="b-note" placeholder="ce qu'on voudra lire dans deux ans">
      </label>
      <div class="actions">
        <button class="secondaire" id="b-annuler">Annuler</button>
        <button class="primaire" id="b-dater">Enregistrer en datant</button>
      </div>`,
      // Fermer la boite sans repondre -- clic a cote -- vaut annuler : c'est
      // ce que l'ecran montre, et rien ne doit s'ecrire en douce.
      () => repondre(null));
    document.getElementById("b-annuler").onclick = fermerBoite;
    document.getElementById("b-dater").onclick = () => {
      repondre({ depuis: document.getElementById("b-depuis").value,
                 note: document.getElementById("b-note").value });
      fermerBoite();
    };
  });
}

async function ecrireFiche(fiche, donnees, daté) {
  try {
    const r = await api("enregistrer-fiche",
      { nom: FICHE_ACTIVE, cle: fiche.cle, donnees, ...daté });
    ETAT = await api("etat");
    // Une fiche neuve : le moteur a fabriqué sa clé, c'est elle qu'on ouvre.
    if (!fiche.cle && r.fiche && r.fiche.cle) CLE_ACTIVE = r.fiche.cle;
    dire(fiche.cle ? "Enregistré." : `Fiche créée : ${r.fiche.cle}.`);
    dessinerConfig();
    if (CLE_ACTIVE || FICHE_ACTIVE === "entreprise") {
      dessinerFormulaire(fichesDe(FICHE_ACTIVE).find(
        (f) => f.cle === CLE_ACTIVE) || fichesDe(FICHE_ACTIVE)[0]);
    }
    if (!fiche.cle) {
      // Une fiche neuve : les listes des blocs de paie doivent la proposer
      // sans qu'on recharge le mois.
      rafraichirReferentiels();
    }
  } catch (e) {
    if (e.detail?.type === "FicheRefusee") {
      // On propose de forcer, mais on ne force jamais tout seul : une regle
      // peut se tromper, l'utilisateur en sait parfois plus qu'elle.
      ouvrirBoite(`<h3>Enregistrement refusé</h3>
        <div class="encart erreur"><b>${e.detail.anomalies.filter((a) => a.gravite === "erreur").length} erreur(s)</b>
          ${e.detail.anomalies.filter((a) => a.gravite === "erreur")
            .map((a) => `<div>${echapper(a.champ)} : ${echapper(a.message)}</div>`).join("")}</div>
        <p class="note">Ces champs partent dans des déclarations. Si la règle
           se trompe et que la valeur est juste, on peut passer outre — mais il
           faut le vouloir.</p>
        <div class="actions">
          <button class="secondaire" onclick="fermerBoite()">Corriger</button>
          <button class="primaire" id="b-forcer">Enregistrer quand même</button>
        </div>`);
      document.getElementById("b-forcer").onclick = async () => {
        // La date d'effet deja saisie voyage avec : passer outre une erreur
        // ne doit pas faire perdre au passage ce qu'on venait de dater.
        await api("enregistrer-fiche", { nom: FICHE_ACTIVE, cle: fiche.cle,
                                         donnees, ...daté, forcer: true });
        fermerBoite(); dire("Enregistré malgré les erreurs.");
        ETAT = await api("etat"); dessinerConfig();
      };
    } else { dire(e.message, "erreur"); }
  }
}

/* =======================================================================
   HISTORIQUE
   ===================================================================== */
function dessinerHistorique() {
  const cible = document.getElementById("historique");
  if (!ETAT.historique.length) {
    cible.innerHTML = `<p class="discret">Aucun mois pour l'instant.</p>`;
    return;
  }
  cible.innerHTML = ETAT.historique.map((m) => `
    <div class="mois-ligne">
      <span class="titre">${echapper(m.mois)}</span>
      <span class="pastille ${m.produit ? "bien" : "alerte"}">
        ${m.produit ? "produit" : "saisi seulement"}</span>
      <span class="fichiers">${m.fichiers.length
        ? m.fichiers.map((f) => echapper(f.nom)).join(" · ")
        : "aucun fichier"}</span>
      <button class="secondaire" data-ouvrir="${echapper(m.mois)}">Ouvrir</button>
    </div>`).join("");
  cible.querySelectorAll("[data-ouvrir]").forEach((b) => {
    b.onclick = () => {
      document.querySelector('.onglets button[data-vue="paie"]').click();
      chargerMois(b.dataset.ouvrir);
    };
  });
}

/* =======================================================================
   LA VEILLE
   =======================================================================
   Ce que le serveur fait sans qu'on le lui demande : sauvegarder le dossier
   prive dans le Drive, relever les retours. La page ne declenche rien
   d'elle-meme au chargement -- le serveur a deja lance le premier tour a
   l'ouverture. Elle ne fait que demander ou ca en est.

   Elle ne calcule rien non plus : tout ce qui s'affiche ici est rendu par
   /api/veille, comme le reste. */
let VEILLE = null;

/** Un passage de veille a pu changer ce que la page montre : un contrat
 *  signé d'un clic (pastille, colonne de droite, fiche), un retour rattaché
 *  à un dépôt. « Il devrait se mettre à jour tout en même temps » : quand
 *  le dernier passage n'est plus celui qu'on a vu, on repeint les états et
 *  la colonne des actes — ce sont des lectures locales, elles ne coûtent
 *  rien. */
async function rafraichirApresVeille(v) {
  const avant = VEILLE?.dernier?.quand;
  const apres = v?.dernier?.quand;
  if (!apres || apres === avant || v.en_cours) return;
  const mois = document.getElementById("mois").value;
  try {
    await dessinerEtatsDesPaies(mois);
    await rafraichirActions();
  } catch (e) { /* le bandeau dit déjà l'essentiel */ }
}

function dessinerVeille(v) {
  VEILLE = v;
  const zone = document.getElementById("veille");
  const texte = document.getElementById("veille-texte");
  if (!v || (!v.minutes && !v.dernier?.quand && !v.en_cours)) { zone.hidden = true; return; }
  zone.hidden = false;
  zone.classList.remove("souci", "neuf");

  if (v.en_cours) {
    texte.innerHTML = "Sauvegarde, relevé des retours et des signatures en cours…";
    return;
  }
  const d = v.dernier || {};
  const morceaux = [];
  if (d.quand) morceaux.push(`dernier passage <b>${echapper(d.quand)}</b>`);
  if (d.sauvegarde) morceaux.push(echapper(d.sauvegarde));
  if (d.retours) morceaux.push(echapper(d.retours));
  if (d.signatures) morceaux.push(echapper(d.signatures));
  if (d.sources) morceaux.push(echapper(d.sources));
  if (d.maj) morceaux.push(echapper(d.maj));
  if (d.maj_note) morceaux.push(`<b>${echapper(d.maj_note)}</b>`);
  // La séance n'apparaît ici QUE fermée. Ouverte, elle l'est tant que la
  // fenêtre l'est : l'écrire à chaque passage de veille, c'était répéter une
  // évidence dans le seul bandeau qui doit rester lisible.
  if (v.seance?.exigee && !v.seance.ouverte) {
    morceaux.push("séance fermée — aucun dépôt possible");
  }
  const ennuis = [...(d.manquants || []), ...(d.incidents || [])];
  if (v.erreur) ennuis.push(v.erreur);
  if (ennuis.length) {
    zone.classList.add("souci");
    morceaux.push(ennuis.map(echapper).join(" · "));
  } else if (d.nouveaux) {
    zone.classList.add("neuf");
    morceaux.push(`<b>${d.nouveaux} retour(s) nouveau(x)</b>`);
  } else if (d.signatures_recues?.length) {
    zone.classList.add("neuf");
  }
  texte.innerHTML = morceaux.join(" — ");
}

async function suivreVeille() {
  if (SERVEUR_PERDU) return;          // le bandeau dit déjà l'essentiel
  try {
    const v = await api("veille");
    await rafraichirApresVeille(v);
    dessinerVeille(v);
  } catch (e) { /* déjà signalé */ }
}

document.getElementById("veille-maintenant").onclick = async () => {
  dessinerVeille({ ...(VEILLE || {}), en_cours: true });
  try {
    const v = await api("veille-maintenant");
    // Le relevé manuel repeint TOUJOURS : c'est ce qu'on vient demander.
    VEILLE = { ...(VEILLE || {}), dernier: {} };
    await rafraichirApresVeille(v);
    dessinerVeille(v);
    dire("Relevé terminé.");
  } catch (e) { dire("Relevé impossible : " + e.message, "erreur"); }
};

/* =======================================================================
   DEMARRAGE
   ===================================================================== */
async function demarrer() {
  ETAT = await api("etat");

  // Une option VIDE en tete, et c'est elle le defaut. Un deroulant montre
  // toujours quelque chose : sans elle, le premier spectacle de la liste a
  // l'air choisi alors que personne ne l'a choisi -- et il porte le numero
  // d'objet qui part en DSN. Un mois porte d'ailleurs plusieurs spectacles :
  // c'est l'engagement qui dit le sien, pas le mois.
  const c = ETAT.configuration;
  const err = [c.entreprise, ...c.salaries, ...c.spectacles]
    .reduce((n, f) => n + f.anomalies.filter((a) => a.gravite === "erreur").length, 0);
  const annees = Object.entries(c.compteurs).filter(([k]) => /^\d{4}$/.test(k));
  const compteurs = annees.slice(-1)[0];
  document.getElementById("etat-global").innerHTML = `
    ${err ? `<span class="pastille erreur">${err} erreur(s) de configuration</span>` : ""}
    ${compteurs ? `<div>compteurs ${echapper(compteurs[0])} :
       bulletin <b>${compteurs[1].bulletin ?? "?"}</b> ·
       AEM <b>${compteurs[1].aem ?? "?"}</b> ·
       CS <b>${compteurs[1].certificat_cs ?? "?"}</b></div>` : ""}`;

  // LE MOIS EN COURS, et rien d'autre. « Le mois doit être le mois en cours de
  // base quand j'ouvre l'app ». La version d'avant
  // ouvrait sur « le premier mois non produit », ce qui paraissait serviable
  // et ne l'était pas : une saisie d'essai laissée en octobre faisait ouvrir
  // le logiciel en octobre, en septembre. On ouvre sur aujourd'hui ; le mois
  // se change d'une case, et l'Historique liste les autres.
  await chargerMois(moisCourant());

  // Le travail de fond : on le regarde toutes les minutes. C'est une lecture
  // d'etat en memoire cote serveur, elle ne coute rien -- surtout pas un
  // appel a Google ou a net-entreprises, qui n'ont lieu que dans le fil de
  // la veille, a son rythme a lui.
  suivreVeille();
  setInterval(suivreVeille, 60000);
}

demarrer().catch((e) => dire("Démarrage impossible : " + e.message, "erreur"));
