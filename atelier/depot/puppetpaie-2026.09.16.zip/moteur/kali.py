"""La veille des conventions collectives par les livraisons open data KALI.

Legifrance refuse les robots (403). Mais la DILA publie chaque soir, en
open data et sans compte, ce qui a change dans la base KALI (les conventions
collectives) : une archive de quelques centaines de Ko par jour, a
https://echanges.dila.gouv.fr/OPENDATA/KALI/ (`KALI_AAAAMMJJ-HHMMSS.tar.gz`).
L'index garde environ un an de livraisons. La base entiere existe aussi
(180 Mo) : on ne la prend jamais, on n'en a pas besoin.

Dans une livraison, deux choses nous interessent :

  - `conteneur/.../KALICONT*.xml` : la fiche d'une convention (IDCC, titre,
    et la liste de TOUS ses textes attaches, avec leur titre). Elle n'est
    livree que le jour ou la convention bouge -- un texte attache, un etat
    qui change. C'est le premier signal.
  - `texte/version/.../KALITEXT*.xml` : un texte modifie ce jour-la (un
    avenant nouveau, un arrete d'extension qui change son etat). Le texte ne
    dit pas a quelle convention il appartient : on le sait par la liste du
    conteneur, vue dans cette livraison ou une precedente, ou parce que le
    manifeste des sources le cite deja.

La liste des textes d'une convention ne vient que de sa fiche, livree les
jours ou elle bouge : a la premiere veille on remonte l'index a rebours
jusqu'a la trouver (une fois), pour savoir ensuite rattacher un texte
modifie a sa convention.

La lecture est incrementale : chaque livraison lue est resumee une fois
dans `reference/sources/veille-kali.json` (ce qui touche NOS conventions,
rien d'autre), et n'est jamais retelechargee. Le rapport est recalcule a
chaque fois depuis la date de releve de la source : un signal vu hier ne
disparait pas parce qu'on a relance la commande.

Ce module ne decide rien : il rend ce qui a bouge, `sources.verifier` en
fait un etat, les deux faces l'affichent.
"""
from __future__ import annotations

import io
import json
import re
import tarfile
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Callable, Optional

INDEX = "https://echanges.dila.gouv.fr/OPENDATA/KALI/"
CACHE = "veille-kali.json"
CITE = "(cite par sources.json)"      # un texte connu par le manifeste, pas par une fiche
_LIVRAISON = re.compile(r'href="KALI_(\d{8}-\d{6})\.tar\.gz"')


def _telecharger(url: str, agent: str, delai: int = 60) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": agent})
    with urllib.request.urlopen(req, timeout=delai) as r:
        return r.read()


def livraisons(index_html: str) -> list:
    """Les estampilles `AAAAMMJJ-HHMMSS` de l'index, dans l'ordre."""
    return sorted(set(_LIVRAISON.findall(index_html)))


def _texte(e, chemin: str) -> str:
    n = e.find(chemin)
    return (n.text or "").strip() if n is not None else ""


def lire_livraison(octets: bytes) -> dict:
    """Ce qu'une archive contient : les conteneurs (par identifiant : IDCC,
    titre, textes attaches) et les textes modifies (par identifiant : titre,
    date, etat, derniere modification). Tout, sans filtrer -- c'est l'appelant
    qui sait ce qu'il suit."""
    conteneurs, textes = {}, {}
    with tarfile.open(fileobj=io.BytesIO(octets), mode="r:gz") as tar:
        for m in tar.getmembers():
            if not m.isfile() or not m.name.endswith(".xml"):
                continue
            if "/conteneur/" not in m.name and "/texte/version/" not in m.name:
                continue
            racine = ET.fromstring(tar.extractfile(m).read())
            ident = _texte(racine, "META/META_COMMUN/ID")
            if racine.tag == "IDCC":
                meta = "META/META_SPEC/META_CONTENEUR/"
                conteneurs[ident] = {
                    "idcc": _texte(racine, meta + "NUM"),
                    "titre": _texte(racine, meta + "TITRE"),
                    "etat": _texte(racine, meta + "ETAT"),
                    "textes": {l.get("idtxt"): (l.get("titretxt") or "").strip()
                               for l in racine.iter("LIEN_TXT") if l.get("idtxt")},
                }
            elif racine.tag == "TEXTE_VERSION":
                chron = "META/META_SPEC/META_TEXTE_CHRONICLE/"
                vers = "META/META_SPEC/META_TEXTE_VERSION/"
                textes[ident] = {
                    "titre": _texte(racine, vers + "TITRE") or _texte(racine, vers + "TITREFULL"),
                    "date_texte": _texte(racine, chron + "DATE_TEXTE"),
                    "modifie_le": _texte(racine, chron + "DERNIERE_MODIFICATION"),
                    "etat": _texte(racine, vers + "ETAT"),
                    "extension": _texte(racine, vers + "LIBELLE_EXTENSION"),
                    "_xml": m.name,
                }
    return {"conteneurs": conteneurs, "textes": textes}


def _charger_cache(p: Path) -> dict:
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {"_quoi": ("Les livraisons open data KALI deja lues, resumees a ce qui touche "
                      "les conventions suivies dans sources.json. Une livraison lue n'est "
                      "jamais retelechargee ; supprimer ce fichier force la relecture."),
            "livraisons": {}, "textes_connus": {}}


def veiller(dossier: Path, suivis: dict, depuis: str, agent: str,
            relever: bool = False,
            telecharger: Optional[Callable[[str], bytes]] = None) -> dict:
    """Retourne voir ce qui a bouge, pour chaque convention suivie, depuis
    une date.

    `suivis` : {conteneur: {"idcc": "1285", "textes": [KALITEXT... deja
    cites par le manifeste]}}. `depuis` : une date ISO (la releve de la
    source) ; les livraisons de ce jour-la et d'avant ne comptent pas.
    `relever` : poser le XML des textes touches dans `dossier/kali/`.

    Rend {"livraisons_lues": [...], "nouvelles": [...], "trou": str|None,
    "amorces": {conteneur: {livraison, textes, titre}},
    "evenements": {conteneur: [ {livraison, genre, ident, titre, ...} ]}}.
    Leve URLError / OSError si l'index ou une archive ne repond pas : c'est
    a l'appelant de dire << injoignable >>.
    """
    telecharger = telecharger or (lambda url: _telecharger(url, agent))
    cache_p = dossier / CACHE
    cache = _charger_cache(cache_p)
    connus = cache.setdefault("textes_connus", {})
    for cont, s in suivis.items():
        connus.setdefault(cont, {})
        for t in s.get("textes", []):
            connus[cont].setdefault(t, CITE)

    seuil = depuis.replace("-", "") + "-999999"       # apres le dernier releve
    index = telecharger(INDEX).decode("utf-8", "replace")
    toutes = livraisons(index)
    if not toutes:
        raise ValueError("l'index KALI ne liste aucune livraison : la page a change ?")
    a_lire = [l for l in toutes if l > seuil]

    # Ce qu'on a couvert sans trou : de la premiere veille a la derniere
    # livraison vue. Si l'index ne remonte plus jusque-la, des livraisons
    # sont sorties sans avoir ete lues -- on le dit, et on s'en souvient.
    couv = cache.get("couverture")
    trous = cache.setdefault("trous", [])
    if couv is None:
        if toutes[0] > seuil:
            trous.append({"de": seuil[:8], "a": toutes[0][:8]})
        cache["couverture"] = {"de": min(seuil, toutes[0]), "a": toutes[-1]}
    elif toutes[0] > couv["a"]:
        trous.append({"de": couv["a"][:8], "a": toutes[0][:8]})
        cache["couverture"] = {"de": couv["de"], "a": toutes[-1]}
    else:
        couv["a"] = max(couv["a"], toutes[-1])
    trou = None
    for t in trous:
        if t["a"] > seuil[:8]:
            trou = ("des livraisons entre le %s et le %s sont sorties de l'index sans "
                    "avoir ete lues : verifier la page a la main pour cette periode"
                    % (_jour(t["de"]), _jour(t["a"])))

    # La liste de reference d'une convention (ses textes attaches) ne vient
    # que d'une fiche livree. Tant qu'on n'en a pas vu, on ne saurait pas
    # rattacher un texte modifie a la convention -- sauf ceux que le
    # manifeste cite. Alors, une fois, on remonte l'index a rebours jusqu'a
    # trouver la derniere fiche de chaque convention suivie : quelques Mo,
    # une seule fois, et la veille sait ensuite de quoi elle parle.
    amorces = cache.setdefault("amorces", {})
    a_amorcer = [c for c in suivis if all(v == CITE for v in connus[c].values())]
    for l in reversed([x for x in toutes if x <= seuil]):
        if not a_amorcer:
            break
        lu = lire_livraison(telecharger("%sKALI_%s.tar.gz" % (INDEX, l)))
        for cont in list(a_amorcer):
            c = lu["conteneurs"].get(cont)
            if c:
                connus[cont].update(c["textes"])
                amorces[cont] = {"livraison": _jour(l), "textes": len(c["textes"]),
                                 "titre": c["titre"]}
                a_amorcer.remove(cont)

    nouvelles = []
    for l in a_lire:
        if l in cache["livraisons"]:
            continue
        octets = telecharger("%sKALI_%s.tar.gz" % (INDEX, l))
        lu = lire_livraison(octets)
        resume = {"conteneurs": {}, "textes": {}}
        for cont in suivis:
            c = lu["conteneurs"].get(cont)
            if c:
                # La premiere fiche vue donne la liste de reference : rien n'y
                # est << nouveau >>, on ne connaissait pas la liste d'avant.
                premiere = all(v == CITE for v in connus[cont].values())
                anciens = set(connus[cont])
                resume["conteneurs"][cont] = {
                    "idcc": c["idcc"], "etat": c["etat"], "premiere": premiere,
                    "nouveaux": {} if premiere else
                                {k: v for k, v in c["textes"].items() if k not in anciens},
                }
                connus[cont].update(c["textes"])
        for ident, t in lu["textes"].items():
            for cont in suivis:
                if ident in connus[cont]:
                    resume["textes"][ident] = dict(t, conteneur=cont)
                    if relever:
                        _poser(dossier, l, ident, t["_xml"], octets)
        for t in resume["textes"].values():
            t.pop("_xml", None)
        cache["livraisons"][l] = resume
        nouvelles.append(l)

    if True:
        dossier.mkdir(parents=True, exist_ok=True)
        cache_p.write_text(json.dumps(cache, ensure_ascii=False, indent=1) + "\n",
                           encoding="utf-8")

    evenements = {cont: [] for cont in suivis}
    for l in sorted(cache["livraisons"]):
        if l <= seuil:
            continue
        r = cache["livraisons"][l]
        for cont, c in r["conteneurs"].items():
            # Une fiche relivree sans texte nouveau n'apprend rien de plus que
            # les textes modifies le meme jour : on ne la rapporte pas.
            if cont in evenements and (c["nouveaux"] or c.get("premiere")):
                evenements[cont].append({
                    "livraison": _jour(l), "genre": "convention", "ident": cont,
                    "titre": ("premiere fiche de la convention vue : %d texte(s) attache(s), "
                              "liste de reference posee" % len(connus[cont])
                              if c.get("premiere") else
                              "fiche de la convention relivree (etat %s)" % c["etat"]),
                    "premiere": bool(c.get("premiere")),
                    "nouveaux": c["nouveaux"]})
        for ident, t in r["textes"].items():
            if t["conteneur"] in evenements:
                evenements[t["conteneur"]].append(dict(
                    t, livraison=_jour(l), genre="texte", ident=ident))
    return {"livraisons_lues": [_jour(l) for l in toutes if l > seuil],
            "nouvelles": [_jour(l) for l in nouvelles], "trou": trou,
            "amorces": amorces,
            "evenements": evenements}


def _jour(livraison: str) -> str:
    return "%s-%s-%s" % (livraison[0:4], livraison[4:6], livraison[6:8])


def _poser(dossier: Path, livraison: str, ident: str, membre: str, octets: bytes) -> None:
    """Le XML d'un texte touche, garde a cote des sources : on le relira,
    et on ne le perd pas quand la livraison sort de l'index."""
    with tarfile.open(fileobj=io.BytesIO(octets), mode="r:gz") as tar:
        cible = dossier / "kali" / ("%s-%s.xml" % (ident, _jour(livraison)))
        cible.parent.mkdir(parents=True, exist_ok=True)
        cible.write_bytes(tar.extractfile(membre).read())
