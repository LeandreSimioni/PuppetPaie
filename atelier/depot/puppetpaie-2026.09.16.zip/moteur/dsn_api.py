"""Depot d'une DSN sur net-entreprises -- la seule sortie irreversible du moteur.

`netentreprises.py` disait : « CE MODULE NE DEPOSE RIEN [...] tant que cet
arbitrage n'est pas rendu ». Il l'est, le 10/09/2026, et ce module le porte --
separe, pour qu'on voie d'un coup d'oeil tout ce qui sort de la machine.

Le guide d'implementation de l'API DSN v6.8 et celui de l'API DPAE decrivent le
meme transport ; `moteur/dpae_api.py` l'a deja etabli et il est repris tel quel.
Seule change l'adresse :

    POST https://depot.dsnrg.net-entreprises.fr/deposer-dsn/1.0/
         Content-Type: text/plain, Content-Encoding: gzip
         Authorization: DSNLogin jeton=...

LE PIEGE, ET IL EST ECRIT DANS LE CAHIER TECHNIQUE
--------------------------------------------------
La nature de l'envoi est DANS LE FICHIER, rubrique S10.G00.00.005 :

    '01'  envoi de test  -- controles executes, bilan rendu, donnees NON conservees
    '02'  envoi reel

Il n'y a pas d'adresse « de test » cote regime general : c'est le meme service
qui recoit les deux. Donc un fichier code '02' depose « pour voir » EST une
declaration, et un fichier code '01' depose en croyant declarer n'a rien
declare. Les deux erreurs sont silencieuses au moment du clic.

D'ou les trois regles tenues ici :

1. **Le mode demande doit correspondre au fichier.** `deposer` refuse un
   fichier '02' quand on demande un test, et un fichier '01' quand on declare.
   Il n'y a pas de « il a probablement voulu dire ».

2. **La bascule en test se fait EN MEMOIRE.** `basculer_en_test` rend une copie
   modifiee ; le fichier sur le disque reste ce qu'il est. Un « fichier de
   test » qui traine finit tot ou tard par etre depose pour de vrai -- meme
   parti que pour la DPAE.

3. **Le reel exige une preuve, et jamais rien.** Deux formes sont acceptees,
   et une seule est possible selon la face : le mois principal declare,
   RECOPIE a la main (ligne de commande, fenetres `.cmd`), ou le mot de passe
   du LOGICIEL retape au moment de l'acte et verifie par `operations`
   (interface). Pas un « oui », pas un « y » : on ne confirme pas par reflexe
   ce qu'on doit recopier, et on ne clique pas un depot les yeux ailleurs.

CE QUI EST DEPOSE. Le fichier tel quel, en latin-1, sans retouche autre que la
bascule de test. Jamais l'archive : le `.dsn`, pas le `.zip`.
"""
from __future__ import annotations
import gzip
import re
from dataclasses import dataclass
from pathlib import Path

ADRESSES_DEPOT = {
    # Regime general. `dsnra` est le regime agricole, `depot-formation` le bac
    # a sable : ni l'un ni l'autre ne nous concerne.
    "production": "https://depot.dsnrg.net-entreprises.fr/deposer-dsn/1.0/",
    "editeur": "https://depot-edit.dsnrg.net-entreprises.fr/deposer-dsn/1.0/",
}

NATURE_TEST = "01"
NATURE_REEL = "02"
_RUB_NATURE = "S10.G00.00.005"

# Ce qu'on relit dans le fichier avant de l'envoyer, pour l'afficher a l'humain.
_LECTURE = {
    "nature_envoi": _RUB_NATURE,
    "logiciel": "S10.G00.00.001",
    "siren": "S10.G00.01.001",
    "type_declaration": "S20.G00.05.002",
    "fraction": "S20.G00.05.003",
    "ordre": "S20.G00.05.004",
    "mois": "S20.G00.05.005",
    "remplace": "S20.G00.05.006",
    "constitution": "S20.G00.05.007",
}

TYPES = {
    "01": "declaration normale",
    "02": "declaration normale sans individu",
    "03": "annule et remplace integral",
    "04": "declaration annule",
    "05": "annule et remplace sans individu",
}


class DepotRefuse(Exception):
    """Le depot n'a pas eu lieu, et c'est le moteur qui l'a refuse."""


@dataclass
class Apercu:
    """Ce qui va partir, en clair, avant que quoi que ce soit parte."""
    chemin: Path
    nature_envoi: str
    logiciel: str
    siren: str
    type_declaration: str
    fraction: str
    ordre: str
    mois: str
    remplace: str
    constitution: str
    salaries: int
    versements: list
    lignes: int

    @property
    def reel(self) -> bool:
        return self.nature_envoi == NATURE_REEL

    @property
    def mois_lisible(self) -> str:
        """'01082026' -> '2026-08', la forme que l'on fera recopier."""
        m = re.fullmatch(r"01(\d{2})(\d{4})", self.mois or "")
        return "%s-%s" % (m.group(2), m.group(1)) if m else (self.mois or "?")


def _rubriques(texte: str) -> dict:
    out = {}
    for ligne in texte.splitlines():
        m = re.match(r"(S\d\d\.G\d\d\.\d\d\.\d\d\d),'(.*)'$", ligne)
        if m and m.group(1) not in out:
            out[m.group(1)] = m.group(2)
    return out


def lire(chemin) -> Apercu:
    """Ce que le fichier declare. Aucune interpretation, que de la lecture."""
    chemin = Path(chemin)
    texte = chemin.read_text(encoding="latin-1")
    r = _rubriques(texte)
    return Apercu(
        chemin=chemin,
        **{nom: r.get(rub, "") for nom, rub in _LECTURE.items()},
        salaries=len(re.findall(r"^S21\.G00\.30\.001,", texte, re.M)),
        # S21.G00.20.005 : les ORDRES DE TELEPAIEMENT, un par organisme. Il y
        # en a plusieurs, et un depot reel les declenche TOUS -- d'ou la liste
        # entiere et pas la premiere valeur rencontree.
        versements=re.findall(r"^S21\.G00\.20\.005,'(.*)'$", texte, re.M),
        lignes=len(texte.splitlines()))


def basculer_en_test(contenu: bytes) -> bytes:
    """Repasse S10.G00.00.005 a '01'. En memoire, jamais sur le disque.

    Pas d'ancre de fin de ligne : le fichier est en CRLF, et un `$` en mode
    multiligne bute sur le 
. C'est passe inapercu au premier essai -- la
    fonction rendait le fichier INCHANGE, donc un « test » aurait ete un
    depot reel. D'ou le test unitaire qui verifie la bascule, et pas seulement
    qu'elle ne leve pas.
    """
    motif = (r"%s,'\d\d'" % re.escape(_RUB_NATURE)).encode("latin-1")
    remplacement = ("%s,'%s'" % (_RUB_NATURE, NATURE_TEST)).encode("latin-1")
    sortie, n = re.subn(motif, remplacement, contenu, count=1)
    if not n:
        raise DepotRefuse(
            "Rubrique %s introuvable : ce fichier ne ressemble pas a une DSN."
            % _RUB_NATURE)
    return sortie


def verifier(apercu: Apercu, *, reel: bool, mois_confirme: str = None,
             presence_prouvee: bool = False) -> None:
    """Leve DepotRefuse si ce qu'on demande ne colle pas au fichier.

    DEUX FORMES DE PREUVE, ET JAMAIS RIEN -- la regle a change le 11/09/2026,
    et elle a change ICI, la ou elle vit.

    Jusque-la, un depot reel exigeait `mois_confirme` : le mois declare,
    recopie a la main. C'etait la seule preuve possible, parce que les
    fenetres `.cmd` etaient la seule facon de deposer.

    L'interface, elle, prouve autrement : elle fait retaper le mot de passe du
    LOGICIEL au moment de l'acte, et c'est `operations.deposer_dsn` qui le
    verifie avant d'arriver ici. Elle passe alors `presence_prouvee=True`.

    CE QUE CE DRAPEAU N'EST PAS : une porte de sortie. Si l'interface le
    remplissait toute seule, ou remplissait `mois_confirme` en lisant le mois
    dans le fichier, elle contournerait un garde-fou du moteur sans le dire --
    la faute exacte contre laquelle `operations.py` a ete ecrit, et qui serait
    invisible a la relecture. Il n'est pose que par `operations`, apres avoir
    confronte un vrai mot de passe a `coffre.verifier_ouverture`.

    Ce qu'on perd en retirant le mois recopie, pour le savoir : c'etait le
    seul geste qu'on ne peut pas faire sans regarder l'ecran. Un mot de passe
    se tape de memoire, les yeux ailleurs. D'ou la consequence a tenir dans le
    front : le mois declare doit etre GROS dans le recapitulatif.
    """
    if reel and apercu.nature_envoi != NATURE_REEL:
        raise DepotRefuse(
            "Le fichier porte %s='%s' (envoi de test) et vous demandez un depot "
            "REEL. Un fichier de test depose reellement ne declare RIEN : les "
            "donnees ne sont pas conservees. Produire le fichier sans --test."
            % (_RUB_NATURE, apercu.nature_envoi))
    if not reel and apercu.nature_envoi != NATURE_REEL:
        return                      # deja code en test : rien a basculer
    if reel:
        if mois_confirme:
            if mois_confirme.strip() != apercu.mois_lisible:
                raise DepotRefuse(
                    "Mois confirme '%s' alors que le fichier declare '%s'. "
                    "Rien n'est parti."
                    % (mois_confirme.strip(), apercu.mois_lisible))
            return
        if not presence_prouvee:
            raise DepotRefuse(
                "Un depot REEL demande une preuve : reecrire le mois declare "
                "(%s), ou retaper le mot de passe du logiciel."
                % apercu.mois_lisible)


def deposer(client, chemin, *, reel: bool, mois_confirme: str = None,
            presence_prouvee: bool = False,
            environnement: str = "production") -> dict:
    """Depose le fichier. Rend la reponse du point de depot.

    `client` : un `netentreprises.Client` deja construit. La session s'ouvre
    ici si elle n'est pas ouverte.

    La verification est refaite ici, meme quand l'appelant vient de la faire :
    c'est la derniere porte avant le reseau, et elle ne doit dependre de la
    discipline de personne.
    """
    apercu = lire(chemin)
    verifier(apercu, reel=reel, mois_confirme=mois_confirme,
             presence_prouvee=presence_prouvee)

    contenu = Path(chemin).read_bytes()
    if not reel:
        contenu = basculer_en_test(contenu)

    client._assurer_session()
    brut, entetes = _appel_depot(client, ADRESSES_DEPOT[environnement],
                                 gzip.compress(contenu))
    return {"reponse": brut.decode("utf-8", "replace").strip(),
            "type": entetes.get("Content-Type", ""),
            "apercu": apercu, "reel": reel}


def _appel_depot(client, url, corps):
    """Le POST du guide : text/plain, gzip, jeton DSNLogin."""
    import urllib.error
    import urllib.request

    from .netentreprises import MESSAGES, USER_AGENT, _sans_secret

    entetes = {"User-Agent": USER_AGENT,
               "Content-Type": "text/plain",
               "Content-Encoding": "gzip",
               "Accept-Encoding": "gzip",
               "Authorization": "DSNLogin jeton=%s" % client.jeton}
    req = urllib.request.Request(url, data=corps, headers=entetes,
                                 method="POST")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            brut = r.read()
            if r.headers.get("Content-Encoding") == "gzip":
                brut = gzip.decompress(brut)
            return brut, dict(r.headers)
    except urllib.error.HTTPError as e:
        detail = MESSAGES.get(str(e.code), "")
        raise DepotRefuse(
            "Le point de depot a repondu %s%s.\n%s"
            % (e.code, " (%s)" % detail if detail else "",
               _sans_secret(e.read().decode("utf-8", "replace")[:800])))
    except urllib.error.URLError as e:
        raise DepotRefuse("Pas de reponse du point de depot : %s" % e.reason)
