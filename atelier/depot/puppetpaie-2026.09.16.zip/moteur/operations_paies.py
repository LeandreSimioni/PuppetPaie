"""La saisie et le mois : charger, apercevoir, produire, valider.

Un fichier de paie devient des paies calculees (`charger`), un mois se
regarde avant de s'ecrire (`apercu_mois`), puis s'ecrit tout entier ou pas
du tout (`produire_mois`, sous le verrou des compteurs). La validation d'une
paie, l'enregistrement d'une saisie depuis l'interface, la liste des mois
connus, les droits a l'assurance chomage et le rejeu de l'historique
(`calibrer`) sont ici aussi : tous lisent ou ecrivent la saisie.

Les autres domaines (`operations_declarations`, `operations_documents`,
`operations_retours`) passent tous par `charger` : c'est la seule porte
d'entree d'une saisie.
"""
from __future__ import annotations

import datetime as _dt
import json
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Any, Optional, Union

from . import emplois as _emplois
from . import minima as _minima
from .calcul import Engagement, calculer, numeroter
from .contexte import Contexte, resoudre
from .operations_socle import ErreurOperation, _sauver_avant, verrou_compteurs
from .util import MOIS, jj_mm_aaaa


class FichierExistant(ErreurOperation):
    def __init__(self, chemin):
        self.chemin = Path(chemin)
        super().__init__("%s existe deja." % self.chemin)


class UrssafManquant(ErreurOperation):
    """Le montant du bloc S21.G00.20 n'a pas ete fourni.

    Ce bloc est un ORDRE DE TELEPAIEMENT : L'URSSAF preleve ce montant. Il
    n'est pas calculable depuis la paie -- l'organisme facture des elements
    que la DSN ne detaille pas, et regularise chaque annee en avril. Il se
    recopie du bordereau.

    L'exception porte l'apercu du mois : le front peut montrer les paies
    calculees avant de dire pourquoi il s'arrete, comme le faisait la ligne
    de commande.
    """

    def __init__(self, apercu):
        self.apercu = apercu
        self.estimation = apercu.urssaf_estimation
        self.marge = apercu.urssaf_marge
        super().__init__(
            "Montant du telepaiement URSSAF (bloc S21.G00.20) manquant. "
            "Estimation : %s EUR (a +/- %s EUR)." % (self.estimation, self.marge))


@dataclass
class Etape:
    """Une chose a faire apres la production. Donnee, pas phrase imprimee."""
    cle: str
    titre: str
    detail: str
    commande: Optional[str] = None


@dataclass
class Saisie:
    """Un fichier de paie lu et calcule : le mois, les paies, la saisie brute."""
    mois: str
    paies: list
    donnees: dict
    source: Optional[Path] = None

    @property
    def annee(self) -> int:
        return int(self.mois[:4])

    @property
    def numero_mois(self) -> int:
        return int(self.mois[5:7])

    @property
    def etiquette(self) -> str:
        return "%s%s" % (MOIS[self.numero_mois - 1], self.annee)

    @property
    def libelle(self) -> str:
        return "%s %d" % (MOIS[self.numero_mois - 1], self.annee)


@dataclass
class ApercuMois:
    """Ce que couterait le mois, avant d'ecrire quoi que ce soit."""
    saisie: Saisie
    total_brut: Decimal
    total_cout: Decimal
    urssaf_estimation: Any
    urssaf_marge: Any
    # Ce qui merite d'etre dit avant de produire -- aujourd'hui : une paie
    # portant sur une fiche archivee. Ce n'est pas une erreur (on rejoue bien
    # une paie passee), c'est une chose qu'on ne fait pas sans le vouloir.
    avertissements: list = field(default_factory=list)

    @property
    def mois(self) -> str:
        return self.saisie.mois

    @property
    def paies(self) -> list:
        return self.saisie.paies


@dataclass
class Numeros:
    bulletin_premier: int
    bulletin_dernier: int
    cs_premier: int
    cs_dernier: int


@dataclass
class MoisProduit:
    apercu: ApercuMois
    dossier: Path
    fichiers: list
    numeros: Numeros
    urssaf: float
    urssaf_estime: bool
    envoi_test: bool
    avertissements: list = field(default_factory=list)
    etapes: list = field(default_factory=list)

    @property
    def saisie(self) -> Saisie:
        return self.apercu.saisie


@dataclass
class PositionDroits:
    cle: str
    salarie: dict
    position: Any
    anniversaire: Any
    colonnes: list
    jours_restants: int
    cachets_manquants: int


# --------------------------------------------------------------------- saisie
def lire_saisie(chemin) -> dict:
    return json.loads(Path(chemin).read_text(encoding="utf-8"))


def dates_engagement(e: dict) -> list:
    """Les jours joues d'un engagement, d'ou qu'ils viennent.

    UNE LIGNE DE PAIE EST UN GROUPE DE CACHETS, a un taux, a un endroit, a des
    dates : << tout est sur la meme ligne : les dates, les lieux et le cachet.
    1 cachet a 130 EUR au Theatre de la Ville le 12, ou 4 cachets a 130 EUR au
    Theatre 71 le 14, 15, 17, 18 >>. C'est ce qui resout le lieu par cachet
    d'un seul coup : le lieu n'a plus a etre rattache a une date par un cote
    et a un engagement par l'autre -- il est la, sur la ligne qui le concerne.

        "lignes": [
          {"rubrique": "cachet", "quantite": 1, "taux": 130,
           "lieu": "Theatre de la Ville", "dates": ["2026-09-12"]},
          {"rubrique": "cachet", "quantite": 4, "taux": 130,
           "lieu": "Theatre 71",
           "dates": ["2026-09-14", "2026-09-15", "2026-09-17", "2026-09-18"]}
        ]

    L'ancienne ecriture -- `dates` sur l'engagement -- n'est plus lue depuis
    le 13/09/2026 : le seul fichier qui la portait (aout 2026) a ete converti
    (outils/convertir_saisies.py), avec la preuve que les douze documents du
    mois ressortent identiques. Un fichier ancien est refuse par `charger`,
    en nommant l'outil.

    Rend une liste de jours, detailles ({"jour", "lieu"}) quand une ligne dit
    ou elle se joue. `Engagement` sait lire les deux.
    """
    out, vus = [], set()
    for l in (e.get("lignes") or []):
        for j in (l.get("dates") or []):
            jour = j["jour"] if isinstance(j, dict) else j
            if jour in vus:
                continue
            vus.add(jour)
            ou = (l.get("lieu") or "") if not isinstance(j, dict) else (
                j.get("lieu") or l.get("lieu") or "")
            out.append({"jour": jour, "lieu": ou} if ou else jour)
    return out


def planning_engagement(e: dict) -> list:
    """Les jours de planning d'un engagement : ceux que ses lignes portent
    sous `planning` -- des jours des mois SUIVANTS, coches d'avance, avec le
    lieu de la ligne. Meme forme que `dates_engagement`."""
    out, vus = [], set()
    for l in (e.get("lignes") or []):
        for j in (l.get("planning") or []):
            jour = j["jour"] if isinstance(j, dict) else j
            if jour in vus:
                continue
            vus.add(jour)
            ou = (l.get("lieu") or "") if not isinstance(j, dict) else (
                j.get("lieu") or l.get("lieu") or "")
            out.append({"jour": jour, "lieu": ou} if ou else jour)
    return out


def charger(ctx: Contexte, source: Union[str, Path, dict],
            sans_numeros: bool = False) -> Saisie:
    """D'un fichier de paie (ou d'un dictionnaire) aux paies calculees.

    Accepte un dictionnaire pour que l'interface puisse calculer un formulaire
    qui n'a pas encore ete enregistre.

    La numerotation attribuee ici n'est que RESERVEE : elle n'atteint le
    disque qu'au `valider_compteurs` de `produire_mois`. Un apercu, un essai
    ou une commande interrompue ne consomme donc aucun numero.
    """
    if isinstance(source, dict):
        data, chemin = source, None
    else:
        chemin = resoudre(source, ctx.racine)
        data = lire_saisie(chemin)

    defaut_taux = data.get("taux_cachet", 130.0)
    engagements = []
    for rang, e in enumerate(data["engagements"], 1):
        # Le spectacle ne se devine pas, et il n'a pas de defaut raisonnable.
        # Il porte le NUMERO D'OBJET -- S21.G00.40.050 en DSN, positions
        # 638-650 de l'AEM, imprime sur le bulletin -- et c'est lui qui fait
        # qu'une paie est UNE paie : un contrat ne peut porter qu'un numero
        # d'objet, donc un spectacle. Prendre <<le premier de la liste>> parce
        # qu'un deroulant en montre toujours un, c'est declarer le mauvais
        # spectacle en silence. Regle 1 de CLAUDE.md : refuser plutot
        # qu'inventer.
        spectacle = e.get("spectacle") or data.get("spectacle")
        if not spectacle:
            raise ErreurOperation(
                "L'engagement %d de %s ne dit pas quel spectacle il joue, et "
                "le mois n'en propose aucun. Le spectacle porte le numero "
                "d'objet, qui part en DSN, en AEM et sur le bulletin : il se "
                "choisit, il ne se devine pas." % (rang, data.get("mois", "?")))
        if any(k in e for k in ("dates", "cachets", "heures", "taux_horaire")):
            raise ErreurOperation(
                "L'engagement %d de %s est ecrit a l'ancienne (`dates`, "
                "`cachets`, `heures` ou `taux_horaire` sur l'engagement). "
                "Depuis le 13/09/2026 tout se porte sur les lignes de paie : "
                "convertir le fichier une fois avec "
                "outils/convertir_saisies.py." % (rang, data.get("mois", "?")))
        jours = dates_engagement(e)
        # `lignes: []` -- ecrit, vide -- est un mois du contrat SANS CACHET :
        # le contrat court, rien n'est joue ce mois-ci, la DSN doit quand
        # meme le porter (Engagement.sans_paie). Une ligne sans date, elle,
        # reste une saisie incomplete.
        if not jours and e.get("lignes") != []:
            raise ErreurOperation(
                "L'engagement %d de %s ne dit aucun jour joue. Les jours se "
                "portent sur chaque ligne de paie (\"dates\"). Sans eux il "
                "n'y a ni debut, ni fin, ni contrat. Un mois du contrat sans "
                "aucun cachet s'ecrit `lignes: []`, avec `debut` et `fin`."
                % (rang, data.get("mois", "?")))
        # LE METIER DE CE CONTRAT, par son code France Travail. Le catalogue
        # (moteur/emplois.py) le traduit en six champs declares ; ce que
        # l'engagement ecrit lui-meme par-dessus l'emporte. Un code inconnu
        # est refuse : un emploi qui n'existe dans aucune nomenclature ne se
        # declare pas.
        declare = {}
        if e.get("metier"):
            try:
                declare = _emplois.resoudre(
                    e["metier"], cadre=e.get("cadre"),
                    feminin=str(ctx.salarie(e["salarie"]).get("nir", "")).startswith("2"))
            except ValueError as exc:
                raise ErreurOperation("Engagement %d de %s : %s" % (
                    rang, data.get("mois", "?"), exc))
            declare.pop("emploi_affichage", None)
        engagements.append(Engagement(
            salarie=e["salarie"],
            spectacle=spectacle,
            dates_travail=jours,
            taux_cachet=e.get("taux_cachet", defaut_taux),
            debut=e.get("debut"), fin=e.get("fin"), numero=e.get("numero"),
            mois=data["mois"], jours=e.get("jours"),
            planning=planning_engagement(e),
            lignes=e.get("lignes"),
            date_paiement=e.get("date_paiement", data.get("date_paiement")),
            lieu=e.get("lieu", data.get("lieu", "")),
            # L'emploi de CE contrat. Absent : celui de la fiche (le cas
            # general). Il n'a pas de defaut de mois -- un mois ne s'exerce
            # pas dans un metier.
            emploi=e.get("emploi") or declare.get("emploi"),
            pcs_ese=e.get("pcs_ese") or declare.get("pcs_ese"),
            code_emploi_ft=e.get("code_emploi_ft") or declare.get("code_emploi_ft"),
            statut=e.get("statut") or declare.get("statut"),
            statut_conventionnel=e.get("statut_conventionnel") or declare.get("statut_conventionnel"),
            statut_categoriel_rc=e.get("statut_categoriel_rc") or declare.get("statut_categoriel_rc"),
        ))
    paies = [calculer(ctx, e) for e in engagements]
    # Les minima conventionnels, ligne par ligne : des avertissements poses
    # sur la paie, jamais un refus. Ici et pas dans `calcul`, parce que ce
    # n'est pas un calcul de paie mais une lecture de convention collective,
    # et parce que les deux faces passent par `charger`.
    for p in paies:
        p.avertissements.extend(_minima.avertissements(ctx, p))
    # La case << cadre >> decochee sur un metier que le catalogue classe cadre :
    # on le dit, on ne refuse pas. C'est un choix qui change ce qui part --
    # retraite complementaire (40.003) et statut conventionnel (40.002) -- et
    # qui se fait parfois d'un clic de trop. Le sens inverse (cadre coche sur
    # un metier non cadre) est un choix de contrat, il n'a rien d'etonnant.
    for p, e in zip(paies, data["engagements"]):
        m = _emplois.metier(e.get("metier") or "") or {}
        if e.get("cadre") is False and m.get("cadre_par_defaut"):
            p.avertissements.append(
                "%s %s, %s : case cadre decochee alors que ce metier est cadre "
                "dans le catalogue -- la retraite complementaire (40.003) et le "
                "statut conventionnel (40.002) partiront en non-cadre. Non "
                "bloquant -- verifier le contrat."
                % (p.salarie["nom"],
                   p.salarie.get("prenom_affichage") or p.salarie["prenom"],
                   m.get("libelle") or e["metier"]))
    # LES CONTRATS QUI DEBORDENT DU MOIS (15/09/2026, option B1 de
    # prive/journal/CONTRATS-PLURIMENSUELS.md). Un contrat d'octobre a
    # decembre est trois engagements, un par fichier de mois, qui portent
    # tous `debut`, `fin` et -- des le deuxieme -- le `numero` qu'octobre a
    # declare. Le role du mois se DEDUIT des dates, il ne se saisit pas :
    # premier mois = contrat et DPAE ; dernier mois = bloc 62 et certificat
    # Conges Spectacles ; entre les deux, ni l'un ni l'autre.
    for p, e in zip(paies, data["engagements"]):
        eng = p.engagement
        if not eng.a_cheval:
            continue
        qui = "%s %s" % (p.salarie["nom"],
                         p.salarie.get("prenom_affichage") or p.salarie["prenom"])
        bornes = "du %s au %s" % (jj_mm_aaaa(eng.debut), jj_mm_aaaa(eng.fin))
        if not eng.premier_mois:
            # Le numero est celui du premier mois, et il ne se REGENERE PAS :
            # S21.G00.40.009 identifie le contrat, et la DPAE d'octobre l'a
            # declare sous ce numero. On le recopie du fichier du premier
            # mois quand la saisie ne le porte pas encore ; s'il n'y est
            # pas, c'est que le premier mois n'a pas ete produit, et on
            # refuse plutot que d'en tirer un autre.
            premier = _engagement_du_premier_mois(ctx, eng, p.salarie["_cle"])
            # LA QUOTITE (40.012/013) EST CELLE DE LA SIGNATURE : les jours
            # du contrat entier tels que le premier mois les connaissait,
            # identiques chaque mois (cahier technique 2026.1, bloc 41). Sans
            # le premier mois sur le disque, on ne connait que ce mois-ci et
            # la suite : on le dit.
            if premier:
                eng.jours_contrat = jours_du_contrat(premier)
            else:
                p.avertissements.append(
                    "%s : contrat %s, la saisie de %s n'est pas sur le disque "
                    "-- la quotite declaree (40.012/013 = %d jours) ne compte "
                    "que les jours connus de ce mois et du planning, pas ceux "
                    "des mois passes."
                    % (qui, bornes, libelle_mois(eng.mois_du_contrat[0]),
                       eng.jours_contrat))
            if not eng.numero:
                if not premier or not premier.get("numero"):
                    raise ErreurOperation(
                        "%s, contrat %s : en cours depuis %s, mais son numero "
                        "n'est pas connu -- le mois %s n'a pas ete produit, "
                        "ou son fichier ne porte pas ce contrat. Produire "
                        "%s d'abord : c'est la que le contrat et la DPAE "
                        "partent, et que le numero se fige."
                        % (qui, bornes, libelle_mois(eng.mois_du_contrat[0]),
                           eng.mois_du_contrat[0], libelle_mois(eng.mois_du_contrat[0])))
                eng.numero = premier["numero"]
            p.avertissements.append(
                "%s : contrat %s en cours depuis %s (n° %s) -- ni contrat ni "
                "DPAE ce mois-ci, ils ont ete faits en %s."
                % (qui, bornes, libelle_mois(eng.mois_du_contrat[0]), eng.numero,
                   libelle_mois(eng.mois_du_contrat[0])))
        if not eng.dernier_mois:
            suivant = eng.mois_du_contrat[eng.mois_du_contrat.index(eng.mois) + 1]
            p.avertissements.append(
                "%s : contrat %s, se poursuit en %s -- ses cachets suivants se "
                "saisissent dans le fichier de %s ; le certificat Conges "
                "Spectacles sera emis a la fin du contrat (%s), pour le "
                "contrat entier.%s"
                % (qui, bornes, libelle_mois(suivant), libelle_mois(suivant),
                   libelle_mois(eng.mois_du_contrat[-1]),
                   (" Le contrat imprime ce mois-ci liste les %d jours coches "
                    "(planning compris) ; sa remuneration chiffre le mois et "
                    "renvoie au planning pour la suite -- le relire avant "
                    "signature." % len(eng.dates_du_contrat())
                    if eng.planning_connu() else
                    " Le contrat imprime ce mois-ci porte les dates et la "
                    "remuneration du mois et renvoie au planning pour la suite "
                    "-- le relire avant signature (gabarit "
                    "prive/gabarits/contrat-cddu.modele).") if eng.premier_mois else ""))
    # Toujours : `numeroter` respecte les numeros de contrat deja ecrits
    # (ceux qu'un mois produit a figes, ceux d'un contrat en cours) et ne
    # fait que reserver les numeros de bulletin. `numeros_figes` dans le
    # fichier ne change rien au calcul : il dit au lecteur que les numeros
    # ecrits sont ceux qui ont ete declares.
    # `sans_numeros` : une lecture qui ne doit rien reserver -- un mois
    # precedent relu pour un certificat, une correspondance de cles.
    if not sans_numeros:
        numeroter(ctx, paies, int(data["mois"][:4]))
    return Saisie(mois=data["mois"], paies=paies, donnees=data, source=chemin)


# ------------------------------------------ les contrats sur plusieurs mois
def libelle_mois(mois: str) -> str:
    """'2026-10' -> 'octobre 2026'."""
    return "%s %s" % (MOIS[int(mois[5:7]) - 1].lower(), mois[:4])


def _engagements_du_mois(ctx: Contexte, mois: str) -> list:
    """Les engagements bruts d'un fichier de mois, avec la cle du salarie.

    [(cle_salarie, engagement_dict)], vide si le mois n'est pas sur le
    disque. On resout le nom par `ctx.salarie` : << Ana >> et << PUPPIS >>
    sont la meme personne, et un contrat se suit par sa cle.
    """
    p = ctx.racine / "paies" / ("%s.json" % mois)
    if not p.exists():
        return []
    out = []
    for e in lire_saisie(p).get("engagements") or []:
        try:
            cle = ctx.salarie(e["salarie"])["_cle"]
        except Exception:                                      # noqa: BLE001
            continue
        out.append((cle, e))
    return out


def _bornes_brutes(e: dict) -> tuple:
    """(debut, fin) d'un engagement brut, AAAA-MM-JJ, comme `Engagement` les
    deduirait : `debut`/`fin` ecrits, sinon le premier jour joue et le
    dernier jour joue ou de planning. Vides sans aucun jour."""
    jours = sorted(j["jour"] if isinstance(j, dict) else j for j in dates_engagement(e))
    plan = sorted(j["jour"] if isinstance(j, dict) else j for j in planning_engagement(e))
    debut = str(e.get("debut") or (jours[0] if jours else ""))
    fin = str(e.get("fin") or max(jours + plan) if (jours or plan) else e.get("fin") or "")
    return debut, fin


def jours_du_contrat(e: dict) -> int:
    """Les jours du contrat entier qu'un engagement brut connait : ses dates
    jouees et son planning, sans doublon. Au premier mois, c'est le contrat
    signe -- la quotite declaree en 40.012/013 chaque mois."""
    jours = {j["jour"] if isinstance(j, dict) else j for j in dates_engagement(e)}
    jours |= {j["jour"] if isinstance(j, dict) else j for j in planning_engagement(e)}
    return len(jours)


def _meme_contrat(e: dict, cle: str, cle_voulue: str, debut) -> bool:
    return cle == cle_voulue and _bornes_brutes(e)[0] == str(debut)


def _engagement_du_premier_mois(ctx: Contexte, eng: Engagement, cle: str):
    """L'engagement (brut) qui a ouvert ce contrat, dans le fichier de son
    premier mois. None s'il n'y est pas."""
    premier = eng.mois_du_contrat[0]
    for c, e in _engagements_du_mois(ctx, premier):
        if _meme_contrat(e, c, cle, eng.debut):
            return e
    return None


def mois_precedents_du_contrat(ctx: Contexte, eng: Engagement, cle: str) -> list:
    """Les engagements des mois PRECEDENTS du meme contrat, lus sur le disque.

    [(mois, engagement_dict)] dans l'ordre des mois, pour un contrat en
    cours : ce qui manque au dernier mois pour ecrire le certificat Conges
    Spectacles du contrat entier. Le seul regard en arriere du moteur.
    """
    out = []
    for m in eng.mois_du_contrat:
        if m >= eng.mois:
            break
        for c, e in _engagements_du_mois(ctx, m):
            if _meme_contrat(e, c, cle, eng.debut):
                out.append((m, e))
    return out


def paie_du_contrat_entier(ctx: Contexte, p) -> tuple:
    """Le contrat recompose sur tous ses mois, pour son certificat CS.

    Rend (paie, mois_manquants). La paie est calculee sur la REUNION des
    lignes de tous les mois : le brut d'un contrat est la somme de ses
    lignes, et c'est verifie -- le brut recompose doit valoir la somme des
    bruts mensuels, sans quoi on refuse d'ecrire un document qui vaut
    cheque sur notre compte Conges Spectacles. Les mois du contrat absents
    du disque sont rendus a l'appelant, qui decide d'en avertir.
    """
    eng, cle = p.engagement, p.salarie["_cle"]
    precedents = mois_precedents_du_contrat(ctx, eng, cle)
    presents = {m for m, _ in precedents}
    manquants = [m for m in eng.mois_du_contrat if m < eng.mois and m not in presents]
    lignes, bruts, jours = [], Decimal("0.00"), 0
    for m, e in precedents:
        sous = charger(ctx, {"mois": m, "engagements": [e],
                             "taux_cachet": e.get("taux_cachet", eng.taux_cachet)},
                       sans_numeros=True).paies[0]
        lignes.extend(json.loads(json.dumps(e.get("lignes") or [])))
        bruts += sous.brut
        jours += sous.engagement.jours
    lignes.extend(json.loads(json.dumps(p.engagement.lignes or [])))
    # Le planning des mois passes a ete paye dans son mois : il ne compte
    # pas deux fois. Le contrat entier n'a que des jours joues.
    for l in lignes:
        l.pop("planning", None)
    entier = Engagement(
        salarie=eng.salarie, spectacle=eng.spectacle,
        dates_travail=[x for l in lignes for x in (l.get("dates") or [])],
        lignes=lignes, debut=eng.debut, fin=eng.fin, numero=eng.numero,
        jours=jours + eng.jours, taux_cachet=eng.taux_cachet,
        date_paiement=eng.date_paiement, lieu=eng.lieu,
        emploi=eng.emploi, pcs_ese=eng.pcs_ese, code_emploi_ft=eng.code_emploi_ft,
        statut=eng.statut, statut_conventionnel=eng.statut_conventionnel,
        statut_categoriel_rc=eng.statut_categoriel_rc)
    paie = calculer(ctx, entier)
    paie.numero_bulletin = p.numero_bulletin
    attendu = bruts + p.brut
    if paie.brut != attendu:
        raise ErreurOperation(
            "Contrat %s : le brut recompose sur %d mois (%s EUR) ne vaut pas la "
            "somme des bruts mensuels (%s EUR). Le certificat Conges Spectacles "
            "du contrat entier n'est pas ecrit."
            % (eng.numero, len(precedents) + 1, paie.brut, attendu))
    return paie, manquants


@dataclass
class ContratEnCours:
    """Un contrat ouvert un mois precedent et qui court encore sur ce mois."""
    salarie: str            # la cle
    nom: str
    spectacle: str          # la cle
    debut: str
    fin: str
    numero: Optional[str]
    depuis: str             # le mois qui l'a ouvert, AAAA-MM
    metier: Optional[str]
    cadre: Optional[bool]
    taux_cachet: Optional[float]
    lieu: str
    deja_repris: bool       # le fichier de ce mois le porte deja
    lignes: list = field(default_factory=list)   # celles du mois qui l'a ouvert


def contrats_en_cours(ctx: Contexte, mois: str) -> list:
    """Les contrats des mois precedents dont la fin depasse le 1er de `mois`.

    Ce que l'ecran propose sous << reprendre un contrat en cours >> : le bloc
    arrive prerempli et ses bornes verrouillees -- on ne change pas un
    contrat depuis son deuxieme mois. Lu dans les fichiers de saisie des
    mois qui precedent, jamais dans la DSN.
    """
    premier = "%s-01" % mois
    deja = {(c, _bornes_brutes(e)[0]) for c, e in _engagements_du_mois(ctx, mois)}
    out, vus = [], set()
    for m in sorted(x.mois for x in mois_connus(ctx) if x.saisie and x.mois < mois):
        for cle, e in _engagements_du_mois(ctx, m):
            debut, fin = _bornes_brutes(e)
            if not debut or fin < premier:
                continue
            ident = (cle, debut)
            if ident in vus:
                continue
            vus.add(ident)
            try:
                sal = ctx.salarie(cle)
                spec = ctx.spectacle(e.get("spectacle") or "")
            except Exception:                                  # noqa: BLE001
                continue
            out.append(ContratEnCours(
                salarie=cle,
                nom="%s %s" % (sal["nom"], sal.get("prenom_affichage") or sal["prenom"]),
                spectacle=spec.get("_cle") or e.get("spectacle"),
                debut=debut, fin=fin, numero=e.get("numero"),
                depuis=m, metier=e.get("metier"), cadre=e.get("cadre"),
                taux_cachet=next((l.get("taux") for l in (e.get("lignes") or [])
                                  if l.get("rubrique") == "cachet"), None),
                lieu=e.get("lieu") or "", deja_repris=ident in deja,
                lignes=json.loads(json.dumps(e.get("lignes") or []))))
    return out


def figer_numeros(ctx: Contexte, s: Saisie) -> Optional[Path]:
    """Ecrit dans le fichier de saisie les numeros de contrat que le mois
    vient de declarer, et `numeros_figes: true`.

    C'est le B1 de la note : le fichier dit ce qui a ete declare, et le mois
    suivant d'un contrat en cours le recopie. Se fait APRES
    `valider_compteurs`, sous le verrou : un numero ecrit ici est un numero
    consomme. La correspondance se fait par (cle du salarie, debut), comme
    tout le reste ; le fichier peut differer de la saisie produite (l'interface
    produit depuis la memoire) -- on ne touche qu'aux numeros.
    """
    chemin = s.source if s.source else ctx.racine / "paies" / ("%s.json" % s.mois)
    if not Path(chemin).exists():
        return None
    data = lire_saisie(chemin)
    numeros = {(p.salarie["_cle"], str(p.engagement.debut)): p.engagement.numero
               for p in s.paies}
    change = False
    for e in data.get("engagements") or []:
        try:
            cle = ctx.salarie(e["salarie"])["_cle"]
            debut = str(charger(ctx, {"mois": s.mois, "engagements": [e],
                                      "taux_cachet": data.get("taux_cachet", 130.0),
                                      "spectacle": data.get("spectacle")},
                                sans_numeros=True).paies[0].engagement.debut)
        except Exception:                                      # noqa: BLE001
            continue
        n = numeros.get((cle, debut))
        if n and e.get("numero") != n:
            e["numero"] = n
            change = True
    if change or not data.get("numeros_figes"):
        data["numeros_figes"] = True
        _sauver_avant(Path(chemin))
        Path(chemin).write_text(json.dumps(data, ensure_ascii=False, indent=2),
                                encoding="utf-8")
    return Path(chemin)


def squelette(mois: str, ctx: Optional[Contexte] = None) -> dict:
    """Un mois vierge.

    SANS `ctx` : le squelette d'exemple de la ligne de commande
    (`moteur nouveau`), avec deux engagements a modifier. Il montre la forme
    du fichier a qui ne l'a jamais vue, et c'est son seul role.

    AVEC `ctx` : ce que l'interface ouvre quand on choisit un mois neuf.
    AUCUN engagement -- << chaque mois doit etre autonome >> (12/09/2026), et
    deux paies inventees le 2 et le 3 sont deux paies a effacer avant de
    saisir les vraies. Le taux, lui, se reprend du dernier mois saisi : c'est
    la seule valeur qui se repete vraiment.
    """
    an, mo = int(mois[:4]), int(mois[5:7])
    fin = _dernier_jour(an, mo)
    if ctx is not None:
        return {"mois": mois, "taux_cachet": dernier_taux(ctx),
                "date_paiement": fin, "engagements": []}
    jours = ["%d-%02d-02" % (an, mo), "%d-%02d-03" % (an, mo)]
    ligne = {"rubrique": "cachet", "quantite": 2, "taux": 130.0,
             "lieu": "", "dates": jours}
    return {
        "mois": mois,
        "spectacle": "oooh teresina",
        "taux_cachet": 130.0,
        "date_paiement": fin,
        "engagements": [
            {"salarie": "Ana", "lignes": [dict(ligne)]},
            {"salarie": "Leandre", "lignes": [dict(ligne)]},
        ],
    }


def _dernier_jour(an: int, mo: int) -> str:
    import calendar
    return "%d-%02d-%02d" % (an, mo, calendar.monthrange(an, mo)[1])


def dernier_taux(ctx: Contexte, defaut: float = 130.0) -> float:
    """Le taux du cachet le plus recemment saisi. << Simple et efficace. >>

    Il n'y a plus de champ << taux du cachet >> a l'ecran : une ligne de paie
    neuve part de celui-ci. On le lit dans la saisie la plus recente -- une
    ligne de cachet d'abord, le `taux_cachet` du mois a defaut -- parce que
    c'est la seule source qui ne mente pas : ce qu'on a reellement paye la
    derniere fois.
    """
    from . import catalogue as cat

    for m in sorted((x.mois for x in mois_connus(ctx)), reverse=True):
        p = ctx.racine / "paies" / ("%s.json" % m)
        if not p.exists():
            continue
        try:
            data = lire_saisie(p)
        except (OSError, ValueError):
            continue
        for e in reversed(data.get("engagements") or []):
            for l in reversed(e.get("lignes") or []):
                try:
                    if cat.rubrique(l["rubrique"], ctx).unite == "cachet" and l.get("taux"):
                        return float(l["taux"])
                except Exception:                                  # noqa: BLE001
                    continue
        if data.get("taux_cachet"):
            return float(data["taux_cachet"])
    return defaut


def engagement_de_reprise(c: ContratEnCours, mois: str,
                          ctx: Optional[Contexte] = None) -> dict:
    """L'engagement d'un contrat en cours, pour le fichier de `mois`.

    Ce que l'ecran preremplit (et verrouille), ce que `nouveau --reprendre`
    ecrit : le contrat tel qu'il a ete signe -- salarie, spectacle, metier,
    `debut`, `fin`, `numero` -- et ses lignes de paie. Quand le premier mois
    a coche un PLANNING, les jours de `mois` y sont deja : ils deviennent
    les dates de la ligne (au meme taux, au meme lieu), et ceux des mois
    d'apres restent en planning. Sans planning, une ligne de cachets a
    completer : les jours ne se devinent pas.
    """
    from . import catalogue as cat

    e = {"salarie": c.salarie, "spectacle": c.spectacle,
         "debut": c.debut, "fin": c.fin}
    if c.numero:
        e["numero"] = c.numero
    if c.metier:
        e["metier"] = c.metier
    if c.cadre is not None:
        e["cadre"] = c.cadre
    if c.lieu:
        e["lieu"] = c.lieu

    def jour(x):
        return x["jour"] if isinstance(x, dict) else x

    lignes = []
    for src in c.lignes:
        plan = list(src.get("planning") or [])
        dedans = [x for x in plan if jour(x)[:7] == mois]
        apres = [x for x in plan if jour(x)[:7] > mois]
        if not dedans and not apres:
            continue
        l = {"rubrique": src.get("rubrique", "cachet"), "taux": src.get("taux")}
        if src.get("lieu"):
            l["lieu"] = src["lieu"]
        try:
            unite = cat.rubrique(l["rubrique"], ctx).unite
        except Exception:                                      # noqa: BLE001
            unite = ""
        # Un cachet ou une journee par date cochee ; les autres unites (des
        # heures) ne se deduisent pas d'un nombre de jours.
        l["quantite"] = float(len(dedans)) if unite in ("cachet", "jour") and dedans else 0
        l["dates"] = dedans
        if apres:
            l["planning"] = apres
        lignes.append(l)
    if not lignes:
        lignes = [{"rubrique": "cachet", "quantite": 0,
                   "taux": c.taux_cachet or 130.0, "dates": []}]
    e["lignes"] = lignes
    return e


def nouvelle_saisie(ctx: Contexte, mois: str, force: bool = False,
                    reprendre: bool = False) -> Path:
    """Le fichier d'exemple d'un mois. `reprendre` : les contrats en cours
    des mois precedents y sont ecrits a la place des deux exemples, avec
    leurs bornes et leur numero -- il reste a poser les jours du mois."""
    p = ctx.racine / "paies" / ("%s.json" % mois)
    if p.exists() and not force:
        raise FichierExistant(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    data = squelette(mois)
    if reprendre:
        en_cours = contrats_en_cours(ctx, mois)
        if en_cours:
            data.pop("spectacle", None)
            data["engagements"] = [engagement_de_reprise(c, mois, ctx) for c in en_cours]
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                 encoding="utf-8")
    return p


# ---------------------------------------------------------------------- mois
def apercu_mois(ctx: Contexte, source) -> ApercuMois:
    """Le mois calcule, rien d'ecrit -- ni fichier, ni compteur.

    C'est ce que l'interface montre avant de produire, et ce que la ligne de
    commande affiche avant de s'arreter faute du montant URSSAF.
    """
    from . import dsn

    s = charger(ctx, source)
    est, marge = dsn.estimation_urssaf(ctx, s.paies, s.mois)
    return ApercuMois(
        saisie=s,
        total_brut=sum((p.brut for p in s.paies), Decimal("0.00")),
        total_cout=sum((p.cout_employeur for p in s.paies), Decimal("0.00")),
        urssaf_estimation=est, urssaf_marge=marge,
        avertissements=_archives_employees(s)
        + [a for p in s.paies for a in p.avertissements])


def _archives_employees(saisie) -> list:
    """Dit ce qui, dans ce mois, porte sur une fiche archivee.

    On n'INTERDIT pas : rejouer une paie passee, reimprimer un bulletin perdu,
    cela doit marcher, et ce sont precisement des fiches archivees. Mais une
    paie NEUVE sur une fiche mise de cote est presque toujours une erreur, et
    elle ne se verrait nulle part ailleurs.
    """
    from .contexte import archivee

    out = []
    for p in saisie.paies:
        if archivee(p.salarie):
            out.append(
                "%s %s est archive(e) : sa fiche porte `actif: false`. "
                "Rejouer une paie passee est normal ; pour une embauche "
                "reelle, remettre `actif: true` dans config/salaries.json."
                % (p.salarie["nom"], p.salarie.get("prenom_affichage")
                   or p.salarie["prenom"]))
        if archivee(p.spectacle):
            out.append(
                "Le spectacle « %s » (objet %s) est archive : France Travail "
                "delivre un numero d'objet par annee, celui-ci est d'une "
                "annee passee." % (p.spectacle["titre"],
                                   p.spectacle.get("numero_objet")))
    return out


def _etapes_mois(etiq, mois, source, numeros, sans_contrat,
                 embauches: bool = True, certificats: bool = True) -> list:
    etapes = []
    if not sans_contrat and embauches:
        etapes.append(Etape(
            "dpae", "DPAE",
            "Deposer DPAE_%s.txt.zip sur net-entreprises.fr, rubrique DPAE, "
            "AVANT le debut du contrat." % etiq))
        etapes.append(Etape(
            "contrat", "Contrat", "Faire signer Contrats_%s.pdf." % etiq))
    etapes.append(Etape(
        "dsn", "DSN",
        "Deposer DSN_%s.dsn EN TEST (depot-dsn --test), lire le bilan, PUIS "
        "deposer en reel. Le "
        "montant URSSAF du bloc S21.G00.20 doit correspondre au bordereau."
        % etiq))
    if certificats:
        etapes.append(Etape(
            "cs", "Conges Spectacles",
            "REMETTRE CertificatsCS_%s.pdf aux salaries (N CE %d a %d). Rien a "
            "envoyer a Audiens : la cotisation part par la DSN. Ces certificats "
            "ont valeur de cheque sur notre compte Conges Spectacles."
            % (etiq, numeros.cs_premier, numeros.cs_dernier)))
    # Plus d'AEM : depuis le passage en 100 % DSN (01/06/2026), l'attestation
    # employeur est editee par France Travail a partir de la DSN et revient
    # dans les retours, en nature 46. On ne la fabrique plus, on la recupere.
    etapes.append(Etape(
        "aer", "Attestations France Travail",
        "Quelques jours apres le depot de la DSN : recuperer les retours, puis "
        "extraire les AER Cinema Spectacle dans sorties/%s/envoi/. Elles "
        "partiront avec le message aux salaries." % mois,
        commande="python -m moteur retours ; python -m moteur aer --mois %s"
                 % mois))
    etapes.append(Etape(
        "envoi", "Salaries",
        "Preparer un message par salarie (bulletin, certificat CS, AER) et "
        "relire avant d'agir. A faire APRES l'etape precedente : sans l'AER, "
        "le message part en annoncant qu'elle suivra.",
        commande=("python -m moteur envoi %s" % source) if source else None))
    return etapes


def produire_mois(ctx: Contexte, source, *, urssaf: Optional[float] = None,
                  accepter_estimation: bool = False, sans_contrat: bool = False,
                  date_constitution: Optional[str] = None,
                  envoi_test: bool = False, qui: str = "?") -> MoisProduit:
    """Contrats, DPAE, bulletins, certificats CS et DSN d'un mois.

    Plus d'AEM depuis le 01/06/2026 : la compagnie est en 100 % DSN, France
    Travail edite l'attestation employeur lui-meme et nous la renvoie. Voir
    `moteur aer`. Les modules `aem` et `aem_pdf` restent, pour relire
    l'archive 2021-2026 et pour le rejeu.

    Tout le mois, ou rien : les compteurs ne sont valides qu'une fois le
    dernier fichier ecrit, et le verrou tient pendant toute l'operation.
    """
    from . import (bulletin, conges_spectacles, contrat, dpae, dsn, envoi)

    with verrou_compteurs(ctx, qui=qui):
        apercu = apercu_mois(ctx, source)
        s = apercu.saisie
        an, etiq = s.annee, s.etiquette
        # Ceux de l'apercu d'abord : ils portent sur ce qu'on produit, pas
        # sur la facon de le produire.
        avertissements = list(apercu.avertissements)

        # Le garde-fou, AVANT la moindre ecriture.
        estime = False
        if urssaf is None and not s.paies:
            # Un mois sans aucun salarie : rien n'est du, le bordereau est
            # nul, il n'y a pas d'estimation a confronter.
            urssaf = 0.0
        if urssaf is None:
            if not accepter_estimation:
                raise UrssafManquant(apercu)
            urssaf = float(apercu.urssaf_estimation)
            estime = True
            avertissements.append(
                "Estimation URSSAF retenue (%s EUR) : NE PAS DEPOSER la DSN "
                "sans l'avoir confrontee au bordereau."
                % apercu.urssaf_estimation)
        if envoi_test:
            avertissements.append(
                "DSN produite en ENVOI DE TEST (S10.G00.00.005 = 01) : "
                "controles executes et bilan rendu, donnees non conservees. "
                "Un fichier code '02' est traite comme REEL.")

        sortie = ctx.racine / "sorties" / s.mois
        sortie.mkdir(parents=True, exist_ok=True)
        # Licence resolue une fois pour toutes sur le mois produit : contrats,
        # bulletins et DSN doivent porter le meme numero.
        ent = dict(ctx.entreprise,
                   licence_spectacle=ctx.licence(
                       "%d-%02d-01" % (an, s.numero_mois)))

        # UN CONTRAT QUI DEBORDE DU MOIS n'a son contrat imprime et sa DPAE
        # qu'au PREMIER mois, et son certificat Conges Spectacles qu'au
        # DERNIER, pour le contrat entier (prive/journal/
        # CONTRATS-PLURIMENSUELS.md, §2.3 et §2.4). Le bulletin et la DSN,
        # eux, sont mensuels : chaque mois les a.
        embauches = [p for p in s.paies if p.engagement.premier_mois]
        pour_cs = {}
        for p in s.paies:
            cle = (p.salarie["_cle"], str(p.engagement.debut))
            if not p.engagement.dernier_mois:
                pour_cs[cle] = None
            elif not p.engagement.a_cheval:
                pour_cs[cle] = p
            else:
                entier, manquants = paie_du_contrat_entier(ctx, p)
                pour_cs[cle] = entier
                if manquants:
                    avertissements.append(
                        "Certificat Conges Spectacles du contrat %s : aucune "
                        "paie sur le disque pour %s -- il ne porte que les "
                        "mois presents. Si ces mois ont ete payes, les "
                        "saisir et reproduire."
                        % (p.engagement.numero,
                           ", ".join(libelle_mois(m) for m in manquants)))
        paies_cs = [x for x in pour_cs.values() if x is not None]

        produits = []
        if not sans_contrat and embauches:
            produits.append(contrat.ecrire(
                embauches, ent, sortie / ("Contrats_%s.pdf" % etiq)))
            produits.append(dpae.ecrire(
                embauches, sortie / ("DPAE_%s.txt" % etiq),
                code_urssaf=ctx.entreprise.get("code_urssaf", "")))
            recap_dpae = sortie / ("DPAE_%s_recapitulatif.txt" % etiq)
            recap_dpae.write_text(dpae.recapitulatif(embauches), encoding="utf-8")
        # Les bulletins : un par paie, et un mois du contrat sans cachet
        # n'en a pas. Un mois ou personne n'est paye n'a pas de fichier.
        payes = [p for p in s.paies if not p.engagement.sans_paie]
        if payes:
            produits.append(bulletin.ecrire(
                payes, ent, sortie / ("Bulletins_%s.pdf" % etiq),
                ctx=ctx, mois=s.mois))
        if not s.paies:
            avertissements.append(
                "Aucun salarie en %s : DSN « normale sans individu » (envoi "
                "neant), a deposer quand meme -- une DSN est due chaque mois."
                % libelle_mois(s.mois))
        for p in s.paies:
            if p.engagement.sans_paie:
                avertissements.append(
                    "%s %s : contrat %s en cours, aucun cachet en %s -- pas de "
                    "bulletin ; la DSN porte le contrat avec un versement a "
                    "zero."
                    % (p.salarie["nom"],
                       p.salarie.get("prenom_affichage") or p.salarie["prenom"],
                       p.engagement.numero, libelle_mois(s.mois)))

        # Certificats d'emploi Conges Spectacles : rien a deposer nulle part,
        # ils sont dus AU SALARIE. Le N CE est une sequence employeur continue,
        # que `prochain_continu` lit sur toutes les annees a la fois : Audiens
        # la fait partir a 1 et elle ne repart jamais a zero.
        n_cs = ctx.prochain_continu("certificat_cs", an, defaut=1)
        combien = conges_spectacles.nombre(paies_cs)
        if paies_cs:
            produits.append(conges_spectacles.ecrire(
                paies_cs, ent, sortie / ("CertificatsCS_%s.pdf" % etiq),
                premier_numero=n_cs))
            recap_cs = sortie / ("CertificatsCS_%s_recapitulatif.txt" % etiq)
            recap_cs.write_text(conges_spectacles.recapitulatif(paies_cs, ent, n_cs),
                                encoding="utf-8")
            produits.append(recap_cs)
            ctx.enregistrer_compteur("certificat_cs", an, n_cs + combien - 1)

        # Un jeu de documents PAR SALARIE, pour l'envoi. Le fichier groupe porte
        # la paie de tout le monde : il ne doit jamais partir a un salarie.
        envoi.pieces_individuelles(s.paies, ent, sortie / "envoi", etiq,
                                   premier_cs=n_cs, ctx=ctx, mois=s.mois,
                                   pour_certificat=pour_cs)

        produits.append(dsn.ecrire(
            ctx, s.paies, s.mois, sortie / ("DSN_%s.dsn" % etiq),
            date_constitution=date_constitution,
            versement_urssaf=urssaf, envoi_test=envoi_test))

        # Les numeros n'existent qu'a partir d'ici : tous les fichiers sont
        # ecrits.
        ctx.valider_compteurs()
        # Et ils s'ecrivent dans la saisie : le fichier dit ce qui a ete
        # declare, et le mois suivant d'un contrat en cours le recopie.
        if figer_numeros(ctx, s) is None:
            avertissements.append(
                "Numeros de contrat non figes : la saisie de %s n'est pas sur "
                "le disque (paies/%s.json). Un contrat qui se poursuivrait le "
                "mois suivant n'y retrouverait pas son numero."
                % (s.libelle, s.mois))

    numeros = Numeros(
        bulletin_premier=int(payes[0].numero_bulletin.split("/")[0]) if payes else 0,
        bulletin_dernier=int(payes[-1].numero_bulletin.split("/")[0]) if payes else 0,
        cs_premier=n_cs, cs_dernier=n_cs + combien - 1)

    return MoisProduit(
        apercu=apercu, dossier=sortie, fichiers=produits, numeros=numeros,
        urssaf=urssaf, urssaf_estime=estime, envoi_test=envoi_test,
        avertissements=avertissements,
        etapes=_etapes_mois(etiq, s.mois, s.source, numeros, sans_contrat,
                            embauches=bool(embauches), certificats=bool(paies_cs)))


# -------------------------------------------------------------- l'historique
@dataclass
class MoisConnu:
    mois: str
    saisie: Optional[Path]
    dossier: Optional[Path]
    fichiers: list
    produit: bool


def mois_connus(ctx: Contexte) -> list:
    """Les mois saisis et les mois produits, du plus recent au plus ancien.

    Deux sources qui ne se recouvrent pas : un mois peut etre saisi sans
    avoir ete produit (on prepare octobre), ou produit sans que sa saisie
    existe encore sous ce nom. L'ecran doit montrer les deux.
    """
    vus = {}
    for p in sorted((ctx.racine / "paies").glob("*.json")):
        vus.setdefault(p.stem, {})["saisie"] = p
    dossier_sorties = ctx.racine / "sorties"
    if dossier_sorties.is_dir():
        for d in sorted(x for x in dossier_sorties.iterdir() if x.is_dir()):
            vus.setdefault(d.name, {})["dossier"] = d

    out = []
    for mois in sorted(vus, reverse=True):
        d = vus[mois].get("dossier")
        fichiers = sorted(f for f in d.iterdir() if f.is_file()) if d else []
        out.append(MoisConnu(mois=mois, saisie=vus[mois].get("saisie"),
                             dossier=d, fichiers=fichiers,
                             produit=bool(fichiers)))
    return out


def enregistrer_saisie(ctx: Contexte, mois: str, donnees: dict,
                       fusionner: bool = True) -> Path:
    """Ecrit un fichier de paie depuis l'interface.

    La saisie est verifiee en la CHARGEANT : si un nom de salarie ou un
    spectacle est inconnu, `charger` leve, et rien n'est ecrit. Mieux vaut
    refuser une saisie que produire une paie fausse.

    ELLE GARDE CE QUE L'ECRAN NE MONTRE PAS, et c'est devenu vital le
    12/09/2026, le jour ou l'interface s'est mise a enregistrer toute seule.
    Tant qu'il fallait cliquer, ecraser le fichier par ce que montrait l'ecran
    etait un geste : on savait ce qu'on remplacait. Une seconde apres chaque
    frappe, c'est autre chose -- ouvrir un mois et effleurer un champ suffirait
    a effacer :

      `_origine`  la phrase ecrite a la main en tete du fichier, qui raconte
                  ce mois-la. L'interface ne l'affiche nulle part, donc elle
                  ne peut pas la renvoyer, donc elle la perdrait.
      `valide`    la validation de chaque paie. L'ecran la lit (`etat_par_paie`)
                  mais ne la remet pas dans la saisie qu'il envoie : toutes les
                  paies validees se seraient rouvertes a la premiere frappe.

    La correspondance se fait par (cle du salarie, premier jour), calculee par
    `charger` des deux cotes -- jamais par le rang dans le fichier, qui change
    des qu'on ajoute un engagement au milieu, ni par le nom ecrit, puisque
    << Ana >> et << PUPPIS >> designent la meme personne.

      `numero`    le numero de contrat fige a la production (`figer_numeros`),
      `numeros_figes`  et le drapeau qui va avec. L'ecran les renvoie quand il
                  les a lus, mais une saisie qui ne les porte pas ne doit pas
                  les effacer : un contrat en cours perdrait le numero sous
                  lequel sa DPAE et sa premiere DSN sont parties.

    `fusionner=False` pour un appelant qui ecrit le fichier ENTIER en
    connaissance de cause -- `valider_paie`, qui part du fichier existant et
    dont un retrait de validation doit rester un retrait.
    """
    donnees = dict(donnees, mois=mois)
    neuf = charger(ctx, donnees)              # leve si la saisie ne tient pas
    p = ctx.racine / "paies" / ("%s.json" % mois)
    p.parent.mkdir(parents=True, exist_ok=True)

    if fusionner and p.exists():
        try:
            ancien = lire_saisie(p)
            anciennes = charger(ctx, p).paies
        except Exception:                                      # noqa: BLE001
            # Un fichier qu'on ne sait plus lire ne doit pas empecher
            # d'enregistrer ce qu'on est en train de taper. On ecrit, et la
            # copie de `avant/` garde l'ancien tel quel.
            ancien, anciennes = {}, []
        if "_origine" in ancien and "_origine" not in donnees:
            donnees["_origine"] = ancien["_origine"]
        if ancien.get("numeros_figes") and "numeros_figes" not in donnees:
            donnees["numeros_figes"] = True
        validees, numeros = {}, {}
        for i, x in enumerate(anciennes):
            e = (ancien.get("engagements") or [])[i] if i < len(
                ancien.get("engagements") or []) else {}
            ident = (x.salarie["_cle"], str(x.engagement.debut))
            if e.get("valide"):
                validees[ident] = e["valide"]
            if e.get("numero"):
                numeros[ident] = e["numero"]
        if validees or numeros:
            engagements = donnees.get("engagements") or []
            for i, x in enumerate(neuf.paies):
                if i >= len(engagements):
                    continue
                ident = (x.salarie["_cle"], str(x.engagement.debut))
                if not engagements[i].get("valide") and validees.get(ident):
                    engagements[i]["valide"] = validees[ident]
                if not engagements[i].get("numero") and numeros.get(ident):
                    engagements[i]["numero"] = numeros[ident]

    if p.exists():
        _sauver_avant(p)
    p.write_text(json.dumps(donnees, ensure_ascii=False, indent=2),
                 encoding="utf-8")
    return p


# ------------------------------------------------- valider une paie
#
# VALIDER, TEL QUE C'EST VOULU :
#
#   << valider une paie ca veut dire fermer l'edition temporairement sauf si
#      on veut revenir dessus mais ca veut dire peut-etre refaire les DPAE...
#      donc pas top. On valide, c'est vert, normalement on n'y revient pas,
#      edition bloquee temporairement avec un bouton pour modifier avec
#      avertissement >>
#
# CE QUE LA VALIDATION EST, ET SURTOUT CE QU'ELLE N'EST PAS
# ---------------------------------------------------------
# Elle est un etat de la SAISIE. Elle ne produit aucun fichier, n'envoie rien,
# ne depose rien, et -- le point important -- NE CONSOMME AUCUN COMPTEUR.
#
# C'etait la question laissee ouverte au §19.12 : valider fige-t-il le NUMERO
# de contrat ? Non, et voici pourquoi. Figer un numero, c'est le reserver pour
# de bon, donc ecrire dans les compteurs -- l'etat partage le plus dangereux
# du logiciel, celui qui a son propre verrou. Une paie validee puis modifiee,
# ou validee puis abandonnee, aurait consomme un numero que plus rien ne
# porte, et un bulletin manquerait dans la serie sans que personne ne sache
# pourquoi.
#
# Ce n'est pas ce qui est voulu : << normalement on n'y revient pas >>.
# Valider veut donc dire exactement cela et rien de plus. Le jour ou figer les
# numeros servira, ce sera une decision separee, avec son verrou et sa trace.
#
# LE DRAPEAU VIT DANS LE FICHIER DE SAISIE, a cote de l'engagement :
#
#     {"salarie": "...", "dates": [...], "valide": "2026-09-12T11:30:00"}
#
# Pas au journal : le journal note ce qui est PARTI, et ici rien ne part. Et
# dans la saisie plutot qu'a cote, pour qu'une paie validee se relise telle
# quelle, sans croiser deux fichiers.


def _paies_par_rang(ctx: Contexte, mois: str) -> tuple:
    """(donnees brutes, [(cle_salarie, debut), ...] dans l'ordre du fichier).

    On passe par `charger` pour obtenir la CLE du salarie et le premier jour,
    au lieu de les relire du fichier. La raison est un vrai piege : une saisie
    ecrite a la main dit << Ana >>, l'interface dit << PUPPIS >>, et les deux
    designent la meme personne. Comparer les chaines du fichier marcherait
    jusqu'au jour ou quelqu'un valide une paie ecrite a l'ancienne -- et
    echouerait sans rien dire d'utile.

    `charger` rend une paie par engagement, dans l'ordre du fichier : le rang
    est donc la correspondance, et elle est exacte.
    """
    p = ctx.racine / "paies" / ("%s.json" % mois)
    if not p.exists():
        raise ErreurOperation(
            "Le mois %s n'est pas enregistre : il n'y a rien a valider. "
            "Enregistrer la saisie d'abord." % mois)
    data = lire_saisie(p)
    s = charger(ctx, p)
    return data, [(x.salarie["_cle"], str(x.engagement.debut)) for x in s.paies]


def valider_paie(ctx: Contexte, mois: str, salarie: str, debut: str, *,
                 valide: bool = True, qui: str = "?") -> dict:
    """Ferme (ou rouvre) l'edition d'une paie. N'ecrit que la saisie.

    Refuse une paie absente du fichier ENREGISTRE, et c'est le garde-fou qui
    compte : valider ce qui n'est pas enregistre poserait une pastille verte
    sur un formulaire qu'un rechargement de page effacerait.
    """
    data, rangs = _paies_par_rang(ctx, mois)
    try:
        i = rangs.index((salarie, debut))
    except ValueError:
        raise ErreurOperation(
            "Aucune paie de %s commencant le %s dans la saisie enregistree de "
            "%s. Enregistrer la saisie avant de valider."
            % (salarie, debut, mois)) from None

    if valide:
        data["engagements"][i]["valide"] = _dt.datetime.now().isoformat(
            timespec="seconds")
    else:
        data["engagements"][i].pop("valide", None)

    # On repasse par `enregistrer_saisie` : elle recharge la saisie entiere
    # avant d'ecrire -- donc elle refuserait un fichier devenu incoherent --
    # et elle garde la copie de sauvegarde. Valider ne doit pas etre le seul
    # chemin d'ecriture qui esquive ces deux choses.
    # `fusionner=False` : `data` EST le fichier, validation comprise. Sans ça,
    # la fusion remettrait la validation qu'on vient justement de retirer.
    enregistrer_saisie(ctx, mois, data, fusionner=False)
    return {"salarie": salarie, "debut": debut,
            "valide": data["engagements"][i].get("valide")}


def paies_validees(ctx: Contexte, mois: str) -> dict:
    """(cle_salarie, debut) -> date de validation. Lu de la saisie enregistree.

    Muette plutot que bavarde en cas de pepin : un mois absent, un fichier
    illisible ou une saisie que `charger` refuse rendent {}. L'ecran affichera
    alors des paies non validees, ce qui est le defaut sur -- l'inverse
    afficherait du vert sur une saisie qu'on n'a pas su lire.
    """
    try:
        data, rangs = _paies_par_rang(ctx, mois)
    except (ErreurOperation, ValueError):
        return {}
    out = {}
    for i, cle in enumerate(rangs):
        e = data["engagements"][i] if i < len(data.get("engagements", [])) else {}
        if e.get("valide"):
            out[cle] = e["valide"]
    return out


# --------------------------------------------------------------------- droits
def droits(ctx: Contexte, mois: Optional[str] = None,
           aujourdhui: Optional[_dt.date] = None) -> list:
    """Position au regard des annexes 8 et 10 : heures + cachets sur 12 mois.

    La source est ce que la compagnie a declare : l'historique importe de
    CoolPaie, puis nos fichiers de paie (cumul.lire_engagements). Ce ne sont
    que les contrats de la compagnie : le seuil se compte sur tous les
    employeurs, donc ces totaux sont un plancher.
    """
    from . import cumul

    engs = cumul.lire_engagements(ctx)
    if not engs:
        return []
    mois = mois or _dt.date.today().strftime("%Y-%m")
    aujourdhui = aujourdhui or _dt.date.today()

    positions = []
    for cle in sorted({e.salarie for e in engs}):
        anniv = cumul.anniversaire_configure(ctx, cle)
        p = cumul.position_droits(ctx, cle, engs, anniversaire=anniv)
        positions.append(PositionDroits(
            cle=cle, salarie=ctx.salaries[cle], position=p, anniversaire=anniv,
            colonnes=cumul.tableau_cumul(ctx, cle, mois),
            jours_restants=p.jours_restants(aujourdhui),
            cachets_manquants=-(-p.manque // cumul.HEURES_PAR_CACHET_ISOLE)))
    return positions


# ----------------------------------------------------------------- le rejeu
def calibrer(ctx: Contexte, export=None) -> bool:
    """Rejeu de l'historique CoolPaie. Rend True si tout concorde.

    `verif.calibrer` imprime son rapport : c'est un outil de mise au point,
    pas une operation de production, et son rapport EST le resultat.
    """
    from .verif import calibrer as _calibrer
    return not _calibrer(ctx, export)
