"""AER Cinema Spectacle : la section 5, celle qui est a notre charge.

France Travail edite l'attestation a partir de notre DSN et nous la renvoie
(retour de nature 46, voir moteur/retours.py). Elle arrive PRE-REMPLIE des
faits -- salarie, contrats, cachets, brut -- et VIDE de son authentification :
158 champs sur 217 sont a blanc, dont le cadre 5.

    Je soussigne(e), (Nom) ... (Prenom) ... agissant en qualite de ...
    certifie que les renseignements indiques sur la presente attestation
    sont exacts ...
    Toute fausse declaration est passible de deux ans d'emprisonnement
    et d'une amende pouvant aller jusqu'a 30 000 euros (art. L. 5429-1).

C'est donc le seul endroit du logiciel ou l'on appose une signature sur une
declaration de veracite. Deux consequences tenues ici :

1. ON NE REMPLIT QUE LA SECTION 5. Les chiffres de France Travail ne sont
   jamais retouches : ce sont eux qui font foi, et les corriger nous-memes
   reviendrait a maquiller un document officiel. Si un chiffre est faux,
   c'est la DSN qu'on corrige, et France Travail reedite l'attestation.

2. ON REFUSE DE SIGNER UNE ATTESTATION QU'ON SAIT FAUSSE. `verifier` compare
   les quantites imprimees sur l'attestation a la saisie de paie du mois. Un
   ecart n'est pas une erreur d'affichage : c'est un renseignement inexact au
   sens de l'article L. 5429-1, et il vaut refus.

   Le cas qui a fait ecrire ce module : aout 2026, contrats PU1.26.15 et
   SI2.26.15, un cachet plus douze heures de masterclass. Les douze heures ne
   sont pas parties dans la DSN ; l'attestation les affiche a blanc. Signer
   aurait certifie exact un document amputant chaque salarie de douze heures
   sur les 507 des annexes 8 et 10.

Le cachet de l'entreprise (EMPLOYEUR_CACHET) reste vide : la compagnie n'en a
pas, et le formulaire ne l'exige pas -- la signature suffit.
"""
from __future__ import annotations
import datetime as _dt
import io
import re
from dataclasses import dataclass, field
from pathlib import Path

# Les champs du cadre 5, et rien d'autre.
CHAMPS_TEXTE = (
    "EMPLOYEUR_NOM", "EMPLOYEUR_PRENOM", "EMPLOYEUR_QUALITE_LIB",
    "EMPLOYEUR_LIEU_SIGN", "EMPLOYEUR_DATE_SIGN_J", "EMPLOYEUR_DATE_SIGN_M",
    "EMPLOYEUR_DATE_SIGN_A", "EMPLOYEUR_CORRES_NOM", "EMPLOYEUR_CORRES_TEL",
    "EMPLOYEUR_CORRES_EMAIL",
)
CHAMP_SIGNATURE = "EMPLOYEUR_SIGNATURE"

# Quantites imprimees par France Travail, par rang de contrat (01 a 05).
_QUANTITES = {
    "cachets": "SAL_NB_CACHET_%02d",
    "heures": "SAL_NB_HEURES_%02d",
}

# LA CLE DE RAPPROCHEMENT, ET POURQUOI CE N'EST PAS LE NUMERO DE CONTRAT.
# L'attestation imprime bien CON_NUMERO_nn -- « SI2.26.15 » -- mais ce numero
# vient d'un compteur qui a avance depuis. Recharger paies/2026-08.json
# aujourd'hui rend SI2.26.18, et le rapprochement echouerait sur tout.
# Les dates de contrat, elles, ne bougent pas.
_DEBUT = "SAL_DT_DEB_%02d"
_FIN = "SAL_DT_FIN_%02d"
_NUM_CONTRAT = "CON_NUMERO_%02d"


class AttestationInexacte(Exception):
    """Un chiffre de l'attestation ne correspond pas a la paie du mois."""

    def __init__(self, ecarts: list):
        self.ecarts = ecarts
        super().__init__(
            "L'attestation ne dit pas ce que la paie dit :\n  %s"
            % "\n  ".join(ecarts))


@dataclass
class Cadre5:
    """Ce qu'on appose. Rien n'est invente : tout vient d'entreprise.json."""
    nom: str
    prenom: str
    qualite: str
    lieu: str
    jour: str
    mois: str
    annee: str
    correspondant: str
    telephone: str
    courriel: str

    @classmethod
    def depuis(cls, ent: dict, aujourdhui: _dt.date = None) -> "Cadre5":
        j = aujourdhui or _dt.date.today()
        sig = ent["signataire"]
        dec = ent["declarant_dsn"]
        return cls(
            nom=sig["nom"], prenom=sig["prenom"], qualite=sig["fonction"],
            # Le lieu de signature est le siege, pas le lieu du spectacle.
            lieu=ent.get("commune_affichage") or ent["commune"],
            jour="%02d" % j.day, mois="%02d" % j.month, annee="%04d" % j.year,
            # « Personne a joindre concernant cette attestation » : c'est le
            # declarant DSN, pas le signataire. France Travail rappelle pour
            # une question de declaration, et c'est l'employeur qui les depose.
            correspondant=dec["nom_prenom"], telephone=dec["tel"],
            courriel=dec["email"].lower())

    def valeurs(self) -> dict:
        return {
            "EMPLOYEUR_NOM": self.nom,
            "EMPLOYEUR_PRENOM": self.prenom,
            "EMPLOYEUR_QUALITE_LIB": self.qualite,
            "EMPLOYEUR_LIEU_SIGN": self.lieu,
            "EMPLOYEUR_DATE_SIGN_J": self.jour,
            "EMPLOYEUR_DATE_SIGN_M": self.mois,
            "EMPLOYEUR_DATE_SIGN_A": self.annee,
            "EMPLOYEUR_CORRES_NOM": self.correspondant,
            "EMPLOYEUR_CORRES_TEL": self.telephone,
            "EMPLOYEUR_CORRES_EMAIL": self.courriel,
        }


def _entier(v) -> int:
    """Une quantite du formulaire -> entier. '' et None valent zero."""
    if v is None:
        return 0
    t = re.sub(r"[^0-9]", "", str(v))
    return int(t) if t else 0


def lire_quantites(donnees: bytes) -> dict:
    """{(debut, fin): {"numero", "cachets", "heures"}} tel qu'IMPRIME.

    Les dates sont des `datetime.date`, pour se comparer sans passer par une
    chaine : l'attestation ecrit JJ/MM/AAAA, la paie tient des dates.
    """
    import pypdf

    champs = pypdf.PdfReader(io.BytesIO(donnees)).get_fields() or {}

    def val(nom):
        c = champs.get(nom)
        return c.get("/V") if c else None

    out = {}
    for rang in range(1, 6):
        deb, fin = val(_DEBUT % rang), val(_FIN % rang)
        if not deb or not fin:
            continue
        cle = (_jour(deb), _jour(fin))
        if cle == (None, None):
            continue
        ligne = {quoi: _entier(val(motif % rang))
                 for quoi, motif in _QUANTITES.items()}
        ligne["numero"] = str(val(_NUM_CONTRAT % rang) or "").strip()
        out[cle] = ligne
    return out


def _jour(t):
    """« 23/08/2026 » -> date. None si ce n'est pas une date."""
    m = re.fullmatch(r"\s*(\d{2})/(\d{2})/(\d{4})\s*", str(t or ""))
    return _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1))) \
        if m else None


def verifier(donnees: bytes, paies: list) -> list:
    """Les ecarts entre l'attestation et la paie. Liste vide = concordance.

    On compare ce qui se perd en silence : les cachets et les heures. Le brut
    n'est pas compare ici -- un ecart de brut se verrait au premier coup d'oeil
    sur le bulletin, alors qu'une case d'heures vide ne se voit pas.
    """
    imprime = lire_quantites(donnees)
    ecarts = []
    for p in paies:
        e = p.engagement
        ligne = imprime.get((e.debut, e.fin))
        if ligne is None:
            continue                       # contrat d'un autre salarie
        attendu = {"cachets": int(e.cachets or 0), "heures": int(e.heures or 0)}
        for quoi, n in attendu.items():
            vu = ligne[quoi]
            if vu != n:
                ecarts.append(
                    "%s (%s au %s) : %s %s sur l'attestation, %s dans la paie"
                    % (ligne["numero"] or "contrat", e.debut, e.fin,
                       vu, quoi, n))
    return ecarts


def authentifier(donnees: bytes, ent: dict, aujourdhui: _dt.date = None,
                 signature: Path = None, paies: list = None,
                 forcer: bool = False) -> bytes:
    """L'attestation, cadre 5 rempli et signee. Rend les octets du PDF.

    `paies` : les paies du mois, pour la verification. Les omettre, c'est
    signer sans regarder -- possible, mais il faut le vouloir.
    `forcer` : signer malgre un ecart. Reserve au cas ou l'ecart est explique
    et accepte ; il laisse une trace dans le journal de la commande.
    """
    import pymupdf

    if paies is not None:
        ecarts = verifier(donnees, paies)
        if ecarts and not forcer:
            raise AttestationInexacte(ecarts)

    cadre = Cadre5.depuis(ent, aujourdhui)
    valeurs = cadre.valeurs()

    doc = pymupdf.open(stream=donnees, filetype="pdf")
    try:
        for page in doc:
            for w in page.widgets():
                if w.field_name in valeurs:
                    w.field_value = valeurs[w.field_name]
                    w.update()
                elif w.field_name == CHAMP_SIGNATURE and signature \
                        and Path(signature).exists():
                    cadre_sig = _cadre_signature(w.rect)
                    # La signature est posee APRES le champ, en travers de la
                    # case, comme une signature manuscrite. Le champ lui-meme
                    # reste vide : on ne tape pas son nom a la place.
                    page.insert_image(cadre_sig, filename=str(signature),
                                      keep_proportion=True, overlay=True)
        sortie = io.BytesIO()
        doc.save(sortie)
        return sortie.getvalue()
    finally:
        doc.close()


def _cadre_signature(rect):
    """La signature occupe le haut de la case, sur 80 % de sa largeur.

    Meme parti que pour le certificat Conges Spectacles : un tampon pose en
    travers, pas une image etiree aux dimensions de la case.
    """
    import pymupdf

    largeur = (rect.x1 - rect.x0) * 0.80
    hauteur = (rect.y1 - rect.y0) * 0.55
    return pymupdf.Rect(rect.x0 + 4, rect.y0 + 4,
                        rect.x0 + 4 + largeur, rect.y0 + 4 + hauteur)
