"""Les declarations : produire une DPAE, deposer une DSN ou une DPAE.

Deposer est l'un des rares gestes du logiciel qui engagent l'employeur --
jusqu'a des ordres de telepaiement reellement preleves. L'ordre est donc
toujours le meme : lire le fichier, verifier que le mode demande colle a ce
qu'il code, exiger la preuve (`operations_socle.Preuve`), chercher alors
seulement le secret de l'organisme, deposer, NOTER quoi qu'il arrive.

Le journal de ce qui est parti est lu par `operations_retours` ; les fichiers
qu'on peut deposer et les embauches sans trace sont dits ici, parce que ce
sont des decisions, pas des commodites d'affichage.
"""
from __future__ import annotations

import datetime as _dt
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .contexte import Contexte, resoudre
from .operations_paies import Etape, Saisie, charger, mois_connus
from .operations_socle import (ErreurOperation, Preuve, SeanceFermee,
                               _verifier_preuve, seance)
from .util import d, jj_mm_aaaa, quand_lisible


class DpaeDejaDeclaree(ErreurOperation):
    """Une de ces embauches est deja partie en DPAE reelle. `embauches` dit
    lesquelles, et pour chacune si le retour est arrive."""

    def __init__(self, message: str, embauches: list):
        super().__init__(message)
        self.embauches = embauches


class DsnDejaDeposee(ErreurOperation):
    """Une DSN reelle est deja partie pour ce mois et n'est pas refusee.
    `etat` dit quand, et ou en est le retour. `forcer=True` passe outre --
    apres avertissement, jamais en silence."""

    def __init__(self, message: str, etat: dict):
        super().__init__(message)
        self.etat = etat


@dataclass
class LigneDpae:
    salarie: str
    debut: _dt.date
    heure: str
    etat: str            # "retard" | "aujourdhui" | "trop_tot" | "ok"
    libelle: str
    jours_restants: int


@dataclass
class DpaeProduite:
    saisie: Saisie
    dossier: Path
    fichiers: list
    lignes: list
    etapes: list = field(default_factory=list)

    @property
    def retard(self) -> bool:
        return any(x.etat == "retard" for x in self.lignes)


# ---------------------------------------------------------------------- DPAE
def libelle_embauche_declaree(cle: str, debut: str, e: dict) -> str:
    """La phrase qu'on lit en face d'une embauche deja declaree.

    Une seule formulation pour les deux faces : ce que le journal sait, et
    ce qu'il reste a faire -- rien, dans les deux cas.
    """
    quand = quand_lisible(e.get("quand"), " a ")
    if e.get("refusee"):
        return "%s au %s : REFUSEE le %s -- %s -- a corriger et a renvoyer" % (
            cle, jj_mm_aaaa(debut), quand,
            " ; ".join(dict.fromkeys(e.get("anomalies") or [])) or "motif non lu")
    if e.get("passee"):
        suite = ("certificat de conformite recu : la DPAE est passee, rien a "
                 "faire de notre cote")
    else:
        suite = "retour pas encore arrive : on attend, on ne renvoie pas"
    return "%s au %s : declaree le %s -- %s" % (cle, jj_mm_aaaa(debut), quand, suite)


def produire_dpae(ctx: Contexte, source, heure: str = "0800",
                  aujourdhui: Optional[_dt.date] = None,
                  paies: Optional[list] = None,
                  forcer: bool = False) -> DpaeProduite:
    """La DPAE seule, due AVANT le premier jour travaille.

    Ni montant URSSAF, ni numero de bulletin : `valider_compteurs` n'est pas
    appele, donc aucun compteur n'est consomme et aucun verrou n'est requis.

    `paies` : une PARTIE du mois seulement, a la maille (salarie, premier
    jour). C'est la demande, et le cas qui la
    justifie est net :

      << si quelqu'un nous demande un spectacle le 10 pour le 25, on va faire
      la DPAE avant le 25 meme si on a deja fait pour le 3 et 4 du mois.
      Mais pas refaire toutes les DPAE du mois. >>

    Une DPAE declare une EMBAUCHE, pas un mois. Le fichier complet porte tout
    le mois ; le redeposer pour une embauche ajoutee en cours de route
    redeclarerait les autres, et declarer deux fois la meme embauche n'est pas
    anodin -- l'Urssaf recoit deux declarations pour un seul contrat.

    D'OU LE FICHIER A COTE, ET JAMAIS PAR-DESSUS. Le fichier partiel prend un
    nom horodate (`DPAE_Aout2026_20260910-1415.txt`) et laisse le complet
    intact. Ecraser le complet aurait ete plus propre a regarder et faux a
    l'usage : ce qui a ete depose doit rester relisible tel qu'il a ete
    depose -- c'est la meme raison qui interdit de regenerer une declaration
    deja partie (regle 4 de CLAUDE.md).
    """
    from . import dpae

    s = charger(ctx, source)
    sortie = ctx.racine / "sorties" / s.mois
    etiq = s.etiquette
    aujourdhui = aujourdhui or _dt.date.today()

    # UN CONTRAT EN COURS DEPUIS UN MOIS PRECEDENT n'est pas une embauche de
    # ce mois : sa DPAE est partie avec son premier mois, avec la date de
    # fin du contrat. Tout le mois = les embauches du mois ; une selection
    # qui le vise est refusee, nommement.
    en_cours = [p for p in s.paies if not p.engagement.premier_mois]
    retenues, marque = [p for p in s.paies if p.engagement.premier_mois], ""
    if paies is not None:
        voulues = {(x["salarie"], x["debut"]) if isinstance(x, dict)
                   else tuple(x) for x in paies}
        retenues = [p for p in s.paies
                    if (p.salarie["_cle"], str(p.engagement.debut)) in voulues]
        trouvees = {(p.salarie["_cle"], str(p.engagement.debut))
                    for p in retenues}
        # On refuse sur une selection qui ne se retrouve pas, au lieu de
        # produire ce qu'on a compris : un ecran qui envoie cinq embauches
        # quand on en a coche six ne le dit pas, et la sixieme manquera
        # silencieusement le jour ou elle etait la seule a compter.
        anciennes = {(p.salarie["_cle"], str(p.engagement.debut)) for p in en_cours}
        if voulues & anciennes:
            raise ErreurOperation(
                "Contrat en cours depuis un mois precedent, sa DPAE est deja "
                "partie avec son premier mois : %s. Rien n'est ecrit."
                % ", ".join("%s au %s" % x for x in sorted(voulues & anciennes)))
        if voulues - trouvees:
            raise ErreurOperation(
                "Ces embauches ne sont pas dans la saisie de %s : %s. "
                "Rien n'est ecrit."
                % (s.mois, ", ".join("%s au %s" % x
                                     for x in sorted(voulues - trouvees))))
        if not retenues:
            raise ErreurOperation(
                "Aucune embauche retenue : il n'y a rien a declarer.")
        marque = "_" + _dt.datetime.now().strftime("%Y%m%d-%H%M")
    if not retenues:
        raise ErreurOperation(
            "Aucune embauche en %s : %s. Rien n'est ecrit."
            % (s.libelle, "les contrats du mois sont en cours depuis un mois "
               "precedent, leur DPAE est partie avec lui" if en_cours
               else "la saisie est vide"))

    # PAS DEUX FOIS. Une embauche deja partie en DPAE reelle ne se reecrit
    # pas : l'Urssaf recevrait deux declarations pour un seul contrat. Le
    # journal sait lesquelles, et pour chacune si le retour est la. `forcer`
    # reste a la ligne de commande (`--force`), pour le cas d'un depot que
    # l'Urssaf a rejete et qu'il faut refaire ; l'interface ne force jamais.
    from . import journal
    deja = journal.etat_des_embauches(ctx)
    bloquees = [(p.salarie["_cle"], str(p.engagement.debut))
                for p in retenues
                if (p.salarie["_cle"], str(p.engagement.debut)) in deja
                and not deja[(p.salarie["_cle"], str(p.engagement.debut))].get("refusee")]
    if bloquees and not forcer:
        detail = [{"salarie": c, "debut": dd, "quand": deja[(c, dd)]["quand"],
                   "passee": deja[(c, dd)]["passee"],
                   "libelle": libelle_embauche_declaree(c, dd, deja[(c, dd)])}
                  for c, dd in bloquees]
        raise DpaeDejaDeclaree(
            "Deja declaree(s), rien n'est ecrit :\n  %s"
            % "\n  ".join(x["libelle"] for x in detail), detail)

    f = dpae.ecrire(retenues, sortie / ("DPAE_%s%s.txt" % (etiq, marque)),
                    heure_embauche=heure,
                    code_urssaf=ctx.entreprise.get("code_urssaf", ""))
    recap = sortie / ("DPAE_%s%s_recapitulatif.txt" % (etiq, marque))
    recap.write_text(dpae.recapitulatif(retenues, heure), encoding="utf-8")

    lignes = []
    for p in retenues:
        debut = d(p.engagement.debut)
        reste = (debut - aujourdhui).days
        if reste < 0:
            etat, libelle = "retard", "EN RETARD (embauche passee)"
        elif reste == 0:
            etat = "aujourdhui"
            libelle = "AUJOURD'HUI - a deposer avant le debut du travail"
        elif reste > 8:
            etat = "trop_tot"
            libelle = "trop tot : la DPAE s'envoie dans les 8 jours qui precedent"
        else:
            etat, libelle = "ok", "dans %d jour(s) - delai tenu" % reste
        lignes.append(LigneDpae(
            salarie=p.salarie["nom"] + " " + p.salarie["prenom_affichage"],
            debut=debut, heure=heure, etat=etat, libelle=libelle,
            jours_restants=reste))

    etapes = [Etape(
        "depot", "Depot",
        "Deposer %s.zip sur net-entreprises.fr, rubrique DPAE, AVANT le debut "
        "du contrat. Pour la saisie en ligne, recopier %s. Le depot reste "
        "manuel : le moteur ne connait pas le mot de passe net-entreprises."
        % (f.name, recap.name),
        commande="python -m moteur deposer-dpae %s" % f)]
    return DpaeProduite(
        saisie=s, dossier=sortie,
        fichiers=[f, f.with_suffix(f.suffix + ".zip"), recap],
        lignes=lignes, etapes=etapes)


# ----------------------------------------- le depot : preuve, secret, trace
@dataclass
class DepotFait:
    """Ce qui vient de partir, et ce que l'organisme a repondu."""
    quoi: str
    fichier: Path
    mois: str
    reel: bool
    reponse: str
    flux: str = ""
    trace: Optional[Path] = None
    ligne: Optional[dict] = None          # la ligne ecrite au journal
    # Le depot PRECEDENT du meme fichier, s'il y en a eu un. Ce n'est pas une
    # erreur -- un annule-et-remplace se depose sciemment -- mais l'ecran doit
    # le dire avant, pas apres.
    deja: Optional[dict] = None


def _motdepasse_organisme(ctx: Contexte, service: str, confirme: str):
    """Le secret de l'organisme : environnement d'abord, puis coffre.

    TROIS CHEMINS, ET UN SEUL EST NOUVEAU -- c'est le raisonnement de
    `commandes_dsn._motdepasse_du_depot`, remonte ici pour que les deux faces
    le partagent au lieu d'en avoir chacune une copie.

    1. La variable d'environnement : quelqu'un a tape le mot de passe dans une
       fenetre, il vaut confirmation a lui seul. Il passe devant tout.
    2. Le coffre, SEANCE OUVERTE.
    3. Rien, ou seance fermee : on refuse, en disant lequel des deux manque.

    Ce qui SORT d'ici est un secret. Il va directement au module de transport,
    qui le recoit et ne le cherche jamais lui-meme (regle 3 de CLAUDE.md), et
    il n'est ni journalise, ni affiche, ni renvoye a une page.
    """
    from . import coffre
    from .dpae_api import VARIABLE_MOTDEPASSE_DPAE
    from .netentreprises import VARIABLE_MOTDEPASSE

    variable = (VARIABLE_MOTDEPASSE if service == coffre.NET_ENTREPRISES
                else VARIABLE_MOTDEPASSE_DPAE)
    depuis_env = os.environ.get(variable)
    if depuis_env:
        return depuis_env
    if not coffre.pose(ctx, service):
        raise ErreurOperation(
            "Mot de passe %s absent : ni dans l'environnement, ni au coffre.\n"
            "  python -m moteur coffre poser %s" % (service, service))
    permis, pourquoi = coffre.autorise_depot(ctx)
    if not permis:
        raise SeanceFermee(
            "Le coffre porte le mot de passe %s, mais le depot est refuse.\n"
            "  %s\n\n  python -m moteur seance --ouvrir" % (service, pourquoi))
    return coffre.lire(ctx, service, usage=coffre.DEPOT, confirme=confirme)


# ------------------------------------------------------------------- la DSN
def apercu_depot_dsn(ctx: Contexte, fichier) -> dict:
    """Ce qui partirait, en clair, sans rien envoyer ni demander.

    Aucun reseau, aucun mot de passe : c'est la relecture avant decision,
    celle qu'on refait autant de fois qu'on veut.
    """
    from . import dsn_api, journal

    chemin = resoudre(fichier, ctx.racine)
    a = dsn_api.lire(chemin)
    deja = journal.deja_depose(ctx, journal.DSN, chemin)
    return {
        "fichier": str(chemin), "nom": chemin.name,
        "mois": a.mois_lisible, "nature_envoi": a.nature_envoi,
        "reel": a.reel,
        "type_declaration": a.type_declaration,
        "libelle_type": dsn_api.TYPES.get(a.type_declaration, "?"),
        "ordre": a.ordre, "fraction": a.fraction,
        "remplace": a.remplace, "constitution": a.constitution,
        "siren": a.siren, "salaries": a.salaries, "lignes": a.lignes,
        # Les ordres de TELEPAIEMENT. Il y en a plusieurs, et un depot reel
        # les declenche TOUS : ils sont ce que le recapitulatif doit montrer
        # en entier, pas en resume.
        "versements": a.versements,
        "deja_depose": deja,
        "seance": seance(ctx),
    }


def libelle_dsn_deposee(mois: str, e: dict) -> str:
    """La phrase en face d'une DSN deja partie -- la meme pour les deux faces."""
    quand = quand_lisible(e.get("quand"), " a ")
    if e.get("refusee"):
        return "DSN de %s deposee le %s -- REFUSEE : %s -- a corriger et a renvoyer" % (
            mois, quand, " ; ".join(dict.fromkeys(e.get("anomalies") or []))
            or "motif non lu")
    if e.get("passee"):
        return ("DSN de %s deposee le %s -- bilan de conformite recu : elle est "
                "passee, rien a faire de notre cote" % (mois, quand))
    return ("DSN de %s deposee le %s -- retour pas encore arrive : on attend, "
            "on ne renvoie pas" % (mois, quand))


def deposer_dsn(ctx: Contexte, fichier, *, reel: bool,
                preuve: Optional[Preuve] = None, qui: str = "?",
                environnement: str = "production",
                forcer: bool = False) -> DepotFait:
    """Depose une DSN. La seule sortie du moteur qui declare quelque chose.

    L'ORDRE COMPTE, ET IL EST CELUI-CI :

      1. lire le fichier -- ce qu'il DIT, pas ce qu'on croit qu'il dit ;
      2. verifier que le mode demande colle a la nature codee dedans. Un
         fichier '02' depose « pour voir » EST une declaration ; un fichier
         '01' depose en croyant declarer n'a rien declare ;
      3. exiger la preuve (depot reel seulement) ;
      4. seulement alors chercher le secret de l'organisme ;
      5. deposer ;
      6. NOTER, quoi qu'il arrive -- succes comme echec.

    Un essai ne consomme rien et ne note rien d'un depot reel : un depot de
    TEST est note aussi, mais en mode test, pour qu'il ne puisse jamais faire
    croire qu'une declaration est partie.
    """
    from . import coffre, dsn_api, journal
    from .netentreprises import Client

    chemin = resoudre(fichier, ctx.racine)
    apercu = dsn_api.lire(chemin)

    # 2. le mode contre le fichier. `presence_prouvee` dit a `dsn_api` que la
    # preuve a ete apportee ici, sous l'une des deux formes -- c'est
    # `operations` qui en decide, jamais le transport.
    dsn_api.verifier(apercu, reel=reel, presence_prouvee=True)

    forme = ""
    if reel:
        forme = _verifier_preuve(ctx, preuve, apercu.mois_lisible, journal.DSN)
        # PAS DEUX FOIS SANS LE VOULOIR. Une DSN reelle deja partie pour ce
        # mois, et pas refusee, ne repart pas : on attend son retour, ou il
        # est la et il n'y a rien a faire. `forcer` -- l'annule-et-remplace
        # voulu, apres avertissement -- passe outre ; une DSN REFUSEE, elle,
        # repart sans qu'on force : c'est la seule raison de la refaire.
        etat_mois = journal.etat_dsn_du_mois(ctx, apercu.mois_lisible)
        if etat_mois and not etat_mois["refusee"] and not forcer:
            raise DsnDejaDeposee(
                libelle_dsn_deposee(apercu.mois_lisible, etat_mois) + ". Rien "
                "n'est parti. Pour renvoyer quand meme (annule-et-remplace), "
                "le dire explicitement.", etat_mois)

    deja = journal.deja_depose(ctx, journal.DSN, chemin)
    confirme = (preuve.mois_recopie if (preuve and preuve.mois_recopie)
                else ("depot:%s" % apercu.mois_lisible)) if reel \
        else ("test:%s" % chemin.name)
    mdp = _motdepasse_organisme(ctx, coffre.NET_ENTREPRISES, confirme)

    client = Client(ctx, environnement, motdepasse=mdp)
    try:
        client.authentifier()
        r = dsn_api.deposer(client, chemin, reel=reel,
                            presence_prouvee=True,
                            environnement=environnement)
    except Exception as e:                                     # noqa: BLE001
        journal.noter(ctx, journal.DSN, mois=apercu.mois_lisible,
                      fichier=chemin, mode=journal.REEL if reel else journal.TEST,
                      qui=qui, accepte=False, destinataire="net-entreprises",
                      reponse=str(e)[:600],
                      detail={"preuve": forme, "erreur": type(e).__name__})
        raise

    flux = journal.flux_de(r["reponse"])
    trace = _archiver_reponse(ctx, "depot-dsn", apercu.mois_lisible, r["reponse"])
    ligne = journal.noter(
        ctx, journal.DSN, mois=apercu.mois_lisible, fichier=chemin,
        mode=journal.REEL if reel else journal.TEST, qui=qui,
        destinataire="net-entreprises", flux=flux, reponse=r["reponse"],
        trace=trace,
        detail={"preuve": forme, "type": apercu.type_declaration,
                "versements": apercu.versements, "salaries": apercu.salaries})
    return DepotFait(quoi=journal.DSN, fichier=chemin, mois=apercu.mois_lisible,
                     reel=reel, reponse=r["reponse"], flux=flux, trace=trace,
                     ligne=ligne, deja=deja)


# ------------------------------------------------------------------ la DPAE
def apercu_depot_dpae(ctx: Contexte, fichier) -> dict:
    """Ce que le fichier DPAE declare, enregistrement par enregistrement."""
    from . import dpae, dpae_api, journal

    chemin = resoudre(fichier, ctx.racine)
    contenu = chemin.read_bytes()
    enrs = dpae.relire(chemin)
    faites = journal.embauches_declarees(ctx)
    par_nir = {s["nir"]: (cle, s) for cle, s in ctx.salaries.items()}
    lignes = []
    for e in enrs:
        cle, s = par_nir.get(e["nir"], (None, {}))
        debut = _iso_depuis_jjmmaaaa(e["date_embauche"])
        lignes.append({
            "salarie": cle or "?",
            "nom": ("%s %s" % (s.get("nom", ""),
                               s.get("prenom_affichage") or s.get("prenom", ""))).strip()
                   or "salarie inconnu de la configuration",
            "debut": debut,
            "fin": _iso_depuis_jjmmaaaa(e["date_fin"]),
            "heure": e["heure_embauche"],
            "deja_declaree": (cle, debut) in faites,
        })
    mois = sorted({l["debut"][:7] for l in lignes if l["debut"]})
    return {
        "fichier": str(chemin), "nom": chemin.name,
        "enregistrements": len(enrs), "octets": len(contenu),
        "reel": dpae_api.est_reel(contenu),
        "indicateur": dpae_api.indicateur(contenu),
        "mois": mois[0] if mois else "",
        "tous_les_mois": mois,
        "embauches": lignes,
        "deja_depose": journal.deja_depose(ctx, journal.DPAE, chemin),
        "seance": seance(ctx),
    }


def deposer_dpae(ctx: Contexte, fichier, *, reel: bool,
                 preuve: Optional[Preuve] = None, qui: str = "?",
                 majuscules: bool = False) -> DepotFait:
    """Depose une DPAE. Meme ordre, memes regles que la DSN.

    Une difference qui compte : la DPAE declare des EMBAUCHES, et le journal
    retient lesquelles (salarie, premier jour). C'est ce qui permet ensuite de
    repondre a « quelles embauches n'ont pas encore ete declarees ».
    """
    from . import coffre, dpae_api, journal
    from .netentreprises import ErreurApi     # noqa: F401  (documente le type)

    chemin = resoudre(fichier, ctx.racine)
    apercu = apercu_depot_dpae(ctx, chemin)
    contenu = chemin.read_bytes()

    if reel and not apercu["reel"]:
        raise ErreurOperation(
            "Le fichier porte l'indicateur %s (test) et vous demandez un depot "
            "REEL : rien ne serait declare. Reproduire le fichier sans --test."
            % apercu["indicateur"])

    forme = ""
    if reel:
        forme = _verifier_preuve(ctx, preuve, apercu["mois"], journal.DPAE)

    if not reel:
        contenu = dpae_api.basculer_en_test(contenu)

    confirme = (preuve.mois_recopie if (preuve and preuve.mois_recopie)
                else ("depot:%s" % apercu["mois"])) if reel \
        else ("test:%s" % chemin.name)
    mdp = _motdepasse_organisme(ctx, coffre.URSSAF, confirme)

    client = dpae_api.ClientDpae(ctx, majuscules=majuscules, motdepasse=mdp)
    soucis = client.verifier_identifiants()
    if soucis:
        raise ErreurOperation(
            "Ces points feraient echouer la connexion MtoM. Rien n'est "
            "envoye :\n  %s" % "\n  ".join(soucis))
    try:
        client.authentifier()
        r = client.deposer(contenu)
    except Exception as e:                                     # noqa: BLE001
        journal.noter(ctx, journal.DPAE, mois=apercu["mois"], fichier=chemin,
                      mode=journal.REEL if reel else journal.TEST, qui=qui,
                      accepte=False, destinataire="urssaf",
                      reponse=str(e)[:600],
                      detail={"preuve": forme, "erreur": type(e).__name__})
        raise

    trace = _archiver_reponse(ctx, "depot-dpae", apercu["mois"], r["reponse"])
    ligne = journal.noter(
        ctx, journal.DPAE, mois=apercu["mois"], fichier=chemin,
        mode=journal.REEL if reel else journal.TEST, qui=qui,
        destinataire="urssaf", flux=journal.flux_de(r["reponse"]),
        reponse=r["reponse"], trace=trace,
        detail={"preuve": forme,
                # Ce que ce depot a REELLEMENT declare, a la maille de
                # l'embauche : c'est ce qui repondra ensuite a « lesquelles
                # restent a faire ».
                "embauches": [{"salarie": l["salarie"], "debut": l["debut"],
                               "fin": l["fin"]} for l in apercu["embauches"]]})
    return DepotFait(quoi=journal.DPAE, fichier=chemin, mois=apercu["mois"],
                     reel=reel, reponse=r["reponse"], trace=trace, ligne=ligne,
                     deja=apercu["deja_depose"])


# ------------------------------------------------- ce qu'il reste a deposer
def embauches_a_declarer(ctx: Contexte, mois: Optional[str] = None) -> list:
    """Les contrats dont la DPAE n'est pas encore partie.

    C'est ce que montre le bouton << envoyer les DPAE qui manquent >> -- le
    << simple et efficace >> de l'ecran.

    LA NUANCE QUE L'ECRAN DOIT REPRENDRE : ce journal ne connait que ce que CE
    logiciel a depose. Une embauche declaree par CoolPaie, ou a la main sur le
    site de l'Urssaf, y figure comme « pas encore declaree ». On dit donc
    « pas de trace d'envoi » et jamais « pas declaree » -- declarer deux fois
    la meme embauche n'est pas anodin.
    """
    from . import journal

    faites = journal.embauches_declarees(ctx)
    attente = []
    for m in ([mois] if mois else [x.mois for x in mois_connus(ctx)]):
        saisie = ctx.racine / "paies" / ("%s.json" % m)
        if not saisie.exists():
            continue
        try:
            s = charger(ctx, saisie)
        except Exception:                                      # noqa: BLE001
            continue
        for p in s.paies:
            debut = str(p.engagement.debut)
            if (p.salarie["_cle"], debut) in faites:
                continue
            # Un contrat en cours se declare avec son premier mois, ou il
            # est deja liste : le compter ici le ferait apparaitre deux fois.
            if not p.engagement.premier_mois:
                continue
            attente.append({
                "mois": m, "salarie": p.salarie["_cle"],
                "nom": "%s %s" % (p.salarie["nom"],
                                  p.salarie.get("prenom_affichage")
                                  or p.salarie["prenom"]),
                "spectacle": p.spectacle["titre"],
                "debut": debut, "fin": str(p.engagement.fin),
            })
    return attente


def fichiers_deposables(ctx: Contexte, mois: str) -> dict:
    """Les fichiers d'un mois qu'on peut deposer, par acte, le bon en tete.

    C'est une DECISION, pas une commodite d'affichage, et c'est pour cela
    qu'elle vit ici. Un mois produit porte souvent deux DSN -- l'originale et
    son annule-et-remplace -- et celle a deposer est la derniere ECRITE, pas
    la premiere dans l'ordre alphabetique. Un ecran qui trierait par nom
    proposerait `DSN_Aout2026_AR.dsn` avant `DSN_Aout2026.dsn` par hasard du
    trait souligne, et l'inverse le mois ou l'etiquette changera.

    Pour la DPAE : le `.txt`, et rien d'autre. Le `.zip` du meme nom est
    refuse au depot (`dpae_api` n'accepte pas les archives), et le
    `_recapitulatif.txt` n'est pas une declaration -- c'est la feuille qu'on
    recopie pour une saisie en ligne. Les proposer au depot serait proposer
    d'envoyer ce qui sera rejete, ou ce qui ne declare rien.

    On ne LIT pas les fichiers ici : ce qu'ils declarent vraiment est le
    travail d'`apercu_depot_dsn` et d'`apercu_depot_dpae`, qui repondent
    fichier par fichier et sans reseau. Celle-ci ne fait que nommer les
    candidats.
    """
    dossier = ctx.racine / "sorties" / mois
    if not dossier.is_dir():
        return {"dsn": [], "dpae": []}

    def _ranger(fichiers: list) -> list:
        fichiers.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return [{"nom": p.name, "chemin": str(p), "octets": p.stat().st_size,
                 "ecrit": _dt.datetime.fromtimestamp(p.stat().st_mtime)
                 .isoformat(timespec="minutes")}
                for p in fichiers]

    fichiers = [p for p in dossier.iterdir() if p.is_file()]
    return {
        "dsn": _ranger([p for p in fichiers if p.suffix.lower() == ".dsn"]),
        "dpae": _ranger([p for p in fichiers
                         if p.name.startswith("DPAE_")
                         and p.suffix.lower() == ".txt"
                         and not p.stem.endswith("_recapitulatif")]),
    }


# -------------------------------------------------------- la trace du depot
def _archiver_reponse(ctx: Contexte, quoi: str, mois: str, reponse: str):
    """Garde la reponse de l'organisme a cote du journal.

    Le journal n'en retient qu'un extrait -- assez pour reconnaitre, pas assez
    pour prouver. La piece entiere vit ici, en clair, datee.
    """
    dossier = ctx.racine / "retours" / "depots"
    dossier.mkdir(parents=True, exist_ok=True)
    p = dossier / ("%s_%s_%s.txt"
                   % (_dt.datetime.now().strftime("%Y%m%d-%H%M%S"), quoi,
                      (mois or "sans-mois").replace("-", "")))
    p.write_text(reponse or "", encoding="utf-8")
    return p


def _iso_depuis_jjmmaaaa(v: str) -> str:
    v = (v or "").strip()
    if len(v) != 8 or not v.isdigit():
        return ""
    return "%s-%s-%s" % (v[4:], v[2:4], v[:2])
