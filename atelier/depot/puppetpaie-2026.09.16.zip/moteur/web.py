"""L'interface : la seconde face du logiciel, servie en local.

    python -m moteur interface

Une page dans le navigateur, servie par ce fichier, qui ne parle qu'a
`operations` -- exactement comme la ligne de commande. Les deux faces sont
interchangeables parce qu'aucune ne decide : si une regle manque ici, c'est
qu'elle manque dans `operations`, et elle manquerait aussi a la ligne de
commande.

**Ce n'est pas un site web.** C'est une fenetre, qui se trouve etre rendue
par le navigateur parce que c'est le meilleur outil de mise en page installe
sur toutes les machines. D'ou les memes garde-fous que la page de relecture
d'`envoi.py`, et pour les memes raisons :

  - le serveur n'ecoute que sur **127.0.0.1** : rien de la machine ne sort ;
  - le **port est tire au hasard**, donc rien ne squatte un port connu ;
  - un **jeton** est exige a chaque appel. Sans lui, une page ouverte par
    ailleurs dans le meme navigateur pourrait parler a ce serveur.

LE JETON N'EST PLUS DANS LA BARRE D'ADRESSE -- 15/09/2026
--------------------------------------------------------
« Est-ce qu'on est oblige d'avoir cette adresse-la dans la barre, on
pourrait pas avoir un truc plus esthetique, sans les jetons ? » Non, on
n'est pas oblige. Le lanceur ouvre toujours `/?jeton=...`, mais le serveur
repond par un **cookie** (HttpOnly, SameSite=Strict, donc illisible par un
script et jamais envoye depuis une autre origine) et renvoie sur `/` : la
barre montre `http://puppetpaie.localhost:7331/`, et c'est tout. La page
porte encore le jeton dans son HTML, et chaque appel le renvoie en en-tete
`X-Jeton` -- le cookie est un second chemin, pas un remplacement.

Pour qu'un FAVORI marche aussi, le jeton ne change plus a chaque lancement :
il est tire une fois et garde dans `config/.jeton-interface` (etat de la
machine, exclu de la sauvegarde). Il ne protege de toute facon que contre
une page tierce dans le navigateur, pas contre un programme qui tourne sous
le meme compte Windows -- celui-la lit deja tout le dossier.

CE QUI PART D'ICI, ET A QUELLE CONDITION
----------------------------------------
Cette page a longtemps porte une regle plus simple : *rien ne part et rien
n'est depose depuis ici*. Elle etait juste quand elle a ete ecrite, et elle
ne l'est plus -- il faut dire pourquoi, parce qu'une regle levee en silence
est une regle qu'on croit encore en vigueur.

Elle datait d'avant la seance. A l'epoque, une page de navigateur n'avait
aucun moyen de prouver qu'un humain voulait l'acte : ni mot de passe, ni
confirmation datee. Les fenetres `.cmd` avaient les deux, la page n'avait
rien, donc la page n'avait pas le droit.

Depuis le 11/09/2026, les deux mecanismes existent et vivent dans le moteur :
la **seance** prouve la presence, la **confirmation** prouve la lecture. On
peut donc deposer et envoyer depuis ici -- a trois conditions, qui ne sont pas
negociables et qu'aucune d'elles n'est tenue par ce fichier :

1. **La decision reste dans `operations`.** Un bouton qui appellerait
   `dsn_api.deposer` depuis ici contournerait les garde-fous. Les routes
   ci-dessous n'appellent que `ops.deposer_dsn`, `ops.deposer_dpae`,
   `ops.envoyer_documents`, `ops.demander_signature`.
2. **Le mot de passe DU LOGICIEL est retape au moment de l'acte.** La seance
   prouve la presence une fois, pour deux heures ; un onglet reste ouvert des
   heures, sur une machine qu'on quitte. Il arrive dans le CORPS d'un POST,
   jamais dans une URL -- elle finirait dans les journaux et l'historique --
   et il n'est confronte qu'a `coffre.verifier_ouverture`, qui repond oui ou
   non. **Le secret de l'ORGANISME ne quitte jamais le moteur** : cette page
   ne le voit pas, ne le demande pas, ne le recoit pas.
3. **La page est plus bavarde que la ligne de commande, pas moins.** Un clic
   est plus facile qu'une commande ; c'est precisement pour cela. Le
   recapitulatif montre les ordres de telepaiement en entier, et le mois
   declare EN GROS -- c'est lui qui porte toute la lecture depuis que le mois
   recopie a ete retire du parcours.

Le serveur s'arrete a la fermeture de la fenetre de terminal, ou par Ctrl+C.
"""
from __future__ import annotations

import json
import secrets
import threading
import traceback
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from . import champs, emplois as _emplois, operations as ops, sortie_json as js
from .contexte import Contexte

RESSOURCES = Path(__file__).resolve().parent / "interface"


# ------------------------------------------------------------------ les vues
def _fiche_verifiee(f) -> dict:
    """La fiche telle que l'ecran la montre.

    `donnees` est COMBLEE : une fiche d'avant ne porte que la forme declaree
    (`PERE LAHAILLE`), et l'ecran doit proposer une forme lisible de depart
    plutot qu'un champ vide. Rien n'est ecrit pour autant.

    `declare` porte ce que le programme fabriquera -- l'humain doit voir ce
    qui partira aux organismes, sans avoir a le taper.
    """
    donnees = champs.combler_affichage(f.nom, f.donnees)
    return {"nom": f.nom, "cle": f.cle, "donnees": js.brut(donnees),
            "declare": champs.apercu_derive(f.nom, donnees),
            "anomalies": f.anomalies,
            "derives": {k: list(v) for k, v in getattr(f, "derives", {}).items()}}


def _configuration(ctx) -> dict:
    c = ops.configuration(ctx)
    return {
        "entreprise": _fiche_verifiee(c["entreprise"]),
        "salaries": [_fiche_verifiee(x) for x in c["salaries"]],
        "spectacles": [_fiche_verifiee(x) for x in c["spectacles"]],
        "compteurs": c["compteurs"],
        "description": {nom: champs.description(nom)
                        for nom in ("entreprise", "salarie", "spectacle")},
    }


def _historique(ctx) -> list:
    return [{"mois": m.mois, "produit": m.produit,
             "saisie": str(m.saisie) if m.saisie else None,
             "dossier": str(m.dossier) if m.dossier else None,
             "fichiers": [{"nom": f.name, "octets": f.stat().st_size}
                          for f in m.fichiers]}
            for m in ops.mois_connus(ctx)]


def _resoudre_noms(ctx: Contexte, saisie: dict) -> dict:
    """Remplace « Ana » et « oooh teresina » par les cles du fichier.

    Le fichier de saisie est tolerant : on y ecrit « Ana », « Lenadre » avec
    la faute de frappe, « teresina ». C'est une qualite quand Claude ecrit le
    fichier, mais une liste deroulante ne peut pas etre tolerante : sans
    correspondance exacte, le navigateur retombe sur sa premiere option -- et
    l'interface changerait silencieusement QUI est paye. On resout donc ici,
    par le moteur, avant de dessiner.

    Si la saisie ne se resout pas (salarie inconnu, bareme absent), on la rend
    telle quelle : c'est l'apercu qui dira pourquoi, avec son message a lui.
    """
    try:
        s = ops.charger(ctx, dict(saisie))
    except Exception:                                          # noqa: BLE001
        return saisie
    sortie = dict(saisie)
    # On ne resout le spectacle du MOIS que si la saisie en nommait un. La
    # premiere version prenait celui de la premiere paie a defaut : une saisie
    # ou chaque engagement nomme son spectacle -- le cas normal, puisqu'un mois
    # porte plusieurs spectacles -- se serait rouverte avec le premier promu
    # defaut du mois, et un engagement ajoute ensuite l'aurait herite sans que
    # personne ne l'ait choisi.
    if saisie.get("spectacle"):
        sortie["spectacle"] = s.paies[0].spectacle["_cle"] if s.paies else saisie["spectacle"]
    engagements = []
    for e, p in zip(saisie.get("engagements", []), s.paies):
        engagements.append(dict(e, salarie=p.salarie["_cle"],
                                spectacle=p.spectacle["_cle"],
                                lignes=_lignes_affichees(ctx, p.engagement,
                                                         e.get("lignes") or [])))
    sortie["engagements"] = engagements
    return sortie


def _jours_sur_les_lignes(ctx: Contexte, eng, lignes: list, brutes: list) -> list:
    """Pose sur chaque ligne les jours qu'elle couvre, et ou.

    Depuis le 12/09/2026 une ligne de paie porte ses dates et son lieu --
    << 4 cachets a 130 EUR au Theatre 71 le 14, 15, 17, 18 >>. Il reste a
    ouvrir les saisies ecrites AVANT, qui portaient les jours sur
    l'engagement. Deux cas :

      - un seul lieu (toutes les saisies existantes) : les jours vont a la
        ligne de cachets, et son lieu est celui de l'engagement ;
      - plusieurs lieux (une saisie ecrite a la main dans la forme
        intermediaire) : la ligne de cachets se SCINDE, une par lieu. C'est la
        traduction fidele -- pour un cachet, la quantite EST le nombre de
        jours -- et sans elle, rouvrir un tel fichier dans l'interface en
        perdrait les lieux au premier enregistrement.
    """
    from . import catalogue as cat

    # Ce que le fichier disait deja ligne par ligne : on le reprend tel quel.
    porte = False
    for i, l in enumerate(lignes):
        src = brutes[i] if i < len(brutes) else {}
        if src.get("dates"):
            l["dates"] = list(src["dates"])
            porte = True
        if src.get("planning"):
            l["planning"] = list(src["planning"])
        if src.get("lieu"):
            l["lieu"] = src["lieu"]
    if porte or not lignes:
        return lignes

    def cachet(l):
        try:
            return cat.rubrique(l["rubrique"], ctx).unite == "cachet"
        except Exception:                                      # noqa: BLE001
            return False

    i = next((k for k, l in enumerate(lignes) if cachet(l)), None)
    if i is None:
        # Pas de cachet : une journee, une masterclass. Les jours vont a la
        # premiere ligne, faute de mieux -- ils doivent aller quelque part,
        # sans quoi l'engagement n'aurait plus de dates du tout.
        lignes[0]["dates"] = [str(x) for x in eng.dates_travail]
        if eng.lieu:
            lignes[0]["lieu"] = eng.lieu
        return lignes

    groupes = eng.dates_par_lieu()
    if len(groupes) <= 1:
        lignes[i]["dates"] = [str(x) for x in eng.dates_travail]
        ou = groupes[0][0] if groupes else eng.lieu
        if ou:
            lignes[i]["lieu"] = ou
        return lignes

    eclatees = []
    for ou, jours in groupes:
        neuve = dict(lignes[i], quantite=float(len(jours)),
                     dates=[str(x) for x in jours])
        if ou:
            neuve["lieu"] = ou
        eclatees.append(neuve)
    return lignes[:i] + eclatees + lignes[i + 1:]


def _lignes_affichees(ctx: Contexte, eng, brutes: list = ()) -> list:
    """Les lignes de paie telles que le MOTEUR les a comprises.

    Une saisie ancienne ne porte souvent aucun nombre : ni `lignes`, ni meme
    `cachets`, parce qu'un cachet par jour joue va de soi. La page ne doit pas
    redeviner cela dans son coin -- elle afficherait une ligne vide sous un
    apercu qui compte deux cachets, et personne ne saurait lequel croire.

    C'est donc le moteur qui repond, avec la meme fonction qui calcule.
    """
    from .calcul import lignes_brut
    lignes = [{"rubrique": l.code, "quantite": float(l.quantite),
               "taux": float(l.taux)}
              for l in lignes_brut(eng, ctx)]
    return _jours_sur_les_lignes(ctx, eng, lignes, list(brutes))


# --------------------------------------------------------------- les actions
def _fenetres_explorateur(titre: str) -> list:
    """Les fenetres de l'explorateur (classe CabinetWClass) portant ce titre."""
    import ctypes
    from ctypes import wintypes
    u = ctypes.windll.user32
    out = []

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def _enum(h, _):
        classe = ctypes.create_unicode_buffer(64)
        u.GetClassNameW(h, classe, 64)
        if classe.value == "CabinetWClass":
            n = u.GetWindowTextLengthW(h) + 1
            buf = ctypes.create_unicode_buffer(n)
            u.GetWindowTextW(h, buf, n)
            # << envoi >>, ou << envoi : Explorateur de fichiers >> selon la
            # version de Windows.
            if buf.value == titre or buf.value.startswith(titre + " :"):
                out.append(h)
        return True

    u.EnumWindows(_enum, 0)
    return out


def _ouvrir_devant(dossier) -> None:
    """Ouvre un dossier dans l'explorateur, DEVANT la fenetre de PuppetPaie.

    `os.startfile` ouvre la fenetre derriere le navigateur : Windows ne donne
    le premier plan qu'au processus qui a recu la derniere frappe, et ce n'est
    pas nous.
    Ce qui marche depuis un processus sans la main, dans l'ordre ou on
    l'essaie, jusqu'a ce que GetForegroundWindow dise que c'est fait :

      1. s'attacher au fil de la fenetre active (AttachThreadInput), simuler
         Alt, SetForegroundWindow, SwitchToThisWindow -- l'appel d'Alt+Tab ;
      2. la mettre << toujours devant >> puis normale (SetWindowPos) ;
      3. reduire la fenetre puis la restaurer (SW_MINIMIZE / SW_RESTORE), en
         dernier : si la restauration n'a pas le droit d'activer, le premier
         plan part au voisin.

    Le 13/09/2026 au soir, aucune de ces methodes n'avait encore ete
    essayee pour de vrai : le titre de la fenetre est << envoi : Explorateur
    de fichiers >> sur ce Windows, et on cherchait << envoi >>.

    La fenetre visee est celle qui vient de s'ouvrir : on releve celles qui
    existaient avant, pour ne pas reveiller un vieux dossier du meme nom.
    Au pire, elle reste derriere, comme avant.
    """
    import os
    import threading
    import time
    titre = os.path.basename(str(dossier))
    try:
        avant = set(_fenetres_explorateur(titre))
    except Exception:                                # noqa: BLE001
        avant = set()
    os.startfile(str(dossier))

    def _devant():
        try:
            import ctypes
            u = ctypes.windll.user32
            k = ctypes.windll.kernel32
            h = None
            for _ in range(40):                      # jusqu'a 4 s
                time.sleep(0.1)
                neuves = [x for x in _fenetres_explorateur(titre) if x not in avant]
                if neuves:
                    h = neuves[-1]
                    break
            if h is None:
                existantes = _fenetres_explorateur(titre)
                if not existantes:
                    return
                h = existantes[-1]                   # l'explorateur a reutilise la sienne
            time.sleep(0.3)                          # le temps qu'elle soit prete
            SWP = 0x0001 | 0x0002 | 0x0040           # NOSIZE | NOMOVE | SHOWWINDOW
            for essai in range(6):
                if u.GetForegroundWindow() == h:
                    return
                if essai % 3 == 2:
                    # En dernier : reduire puis restaurer. Si la restauration
                    # n'a pas le droit d'activer, le premier plan part au
                    # voisin -- on ne le tente qu'apres le reste.
                    u.ShowWindow(h, 6)               # SW_MINIMIZE
                    time.sleep(0.05)
                    u.ShowWindow(h, 9)               # SW_RESTORE
                elif essai % 3 == 1:
                    u.SetWindowPos(h, -1, 0, 0, 0, 0, SWP)   # HWND_TOPMOST
                    u.SetWindowPos(h, -2, 0, 0, 0, 0, SWP)   # HWND_NOTOPMOST
                    u.BringWindowToTop(h)
                else:
                    devant = u.GetForegroundWindow()
                    fil_devant = u.GetWindowThreadProcessId(devant, None) if devant else 0
                    fil_nous = k.GetCurrentThreadId()
                    attache = bool(fil_devant and fil_devant != fil_nous
                                   and u.AttachThreadInput(fil_devant, fil_nous, True))
                    u.keybd_event(0x12, 0, 0, 0)
                    u.keybd_event(0x12, 0, 2, 0)
                    u.SetForegroundWindow(h)
                    try:
                        u.SwitchToThisWindow(h, True)
                    except Exception:                # noqa: BLE001
                        pass
                    if attache:
                        u.AttachThreadInput(fil_devant, fil_nous, False)
                time.sleep(0.25)
        except Exception:                            # noqa: BLE001
            pass                                     # derriere, comme avant

    threading.Thread(target=_devant, daemon=True).start()


def _traiter(ctx: Contexte, route: str, charge: dict, veille=None) -> dict:
    """Une route, une operation. Aucune logique metier ici : que de l'aiguillage.

    Toute erreur d'`operations` est rendue telle quelle par l'appelant, avec
    son type : c'est sur lui que la page branche son comportement (redemander
    le montant URSSAF, montrer les champs fautifs), jamais sur le message.
    """
    if route == "etat":
        return {"configuration": _configuration(ctx),
                "historique": _historique(ctx),
                # Les listes ou l'on CHOISIT : les fiches courantes
                # seulement. Une archive reste dans `configuration`, ou on
                # peut la relire et la reactiver -- mais on ne l'embauche pas
                # par megarde depuis un deroulant.
                "salaries": [{"cle": k,
                              "libelle": "%s %s" % (v["nom"],
                                                    v.get("prenom_affichage") or v["prenom"])}
                             for k, v in sorted(ctx.salaries_actifs.items())],
                "spectacles": [{"cle": k, "titre": v["titre"],
                                "numero_objet": v.get("numero_objet")}
                               for k, v in ctx.spectacles_actifs.items()],
                # Le catalogue qui paie, deja dans l'ordre ou le proposer :
                # les rubriques cochees d'abord, la plus utilisee en tete.
                # La page n'a donc rien a trier, et surtout rien a decider.
                "rubriques": ops.rubriques(ctx),
                # Le catalogue des metiers, deja dans l'ordre des familles :
                # le deroulant << Metier >> d'un engagement le lit tel quel.
                "emplois": ops.metiers(ctx),
                "familles_emplois": _emplois.familles()}

    if route == "verifier-fiche":
        # On rend aussi ce qui SERA declare : la page l'affiche a mesure que
        # l'on tape, pour qu'on voie la machine faire son travail.
        return {"anomalies": ops.verifier_fiche(charge["nom"], charge["donnees"]),
                "declare": champs.apercu_derive(charge["nom"], charge["donnees"])}

    if route == "changements-declares":
        # Ce que cet enregistrement ferait CHANGER dans ce qui part aux
        # organismes, et ce que l'ancienne valeur a deja servi a declarer.
        # L'ecran s'en sert pour demander la date d'effet -- il ne la devine
        # pas, et il ne decide pas non plus s'il faut demander.
        return {"changements": ops.changements_declares(
            ctx, charge["nom"], charge.get("cle"), charge["donnees"])}

    if route == "enregistrer-fiche":
        f = ops.enregistrer_fiche(ctx, charge["nom"], charge.get("cle"),
                                  charge["donnees"], forcer=charge.get("forcer"),
                                  depuis=charge.get("depuis"),
                                  note=charge.get("note", ""))
        return {"fiche": _fiche_verifiee(f),
                "configuration": _configuration(Contexte(ctx.racine))}

    if route == "normaliser":
        c = next((x for x in champs.FICHES[charge["nom"]]
                  if x.cle == charge["champ"]), None)
        return {"valeur": champs.normaliser(c, charge["valeur"]) if c
                else charge["valeur"]}

    if route == "saisie":
        p = ctx.racine / "paies" / ("%s.json" % charge["mois"])
        # `ctx` au squelette : un mois neuf s'ouvre VIDE, avec le dernier taux
        # saisi. Voir `ops.squelette` -- l'exemple a deux engagements reste
        # celui de la ligne de commande.
        saisie = (ops.lire_saisie(p) if p.exists()
                  else ops.squelette(charge["mois"], ctx))
        return {"mois": charge["mois"], "existe": p.exists(),
                "saisie": _resoudre_noms(ctx, saisie)}

    if route == "contrats-en-cours":
        # Les contrats ouverts un mois precedent et qui courent encore sur
        # celui-ci : ce que << reprendre un contrat en cours >> propose.
        return {"mois": charge["mois"],
                "contrats": [dict(js.contrat_en_cours(c),
                                  engagement=ops.engagement_de_reprise(c, charge["mois"], ctx))
                             for c in ops.contrats_en_cours(ctx, charge["mois"])]}

    if route == "emploi":
        # Un metier du catalogue traduit en champs de fiche, pour le
        # formulaire salarie. Meme resolution qu'un engagement : une seule
        # regle, dans emplois.py.
        return _emplois.resoudre(charge["metier"], cadre=charge.get("cadre"),
                                 feminin=bool(charge.get("feminin")))

    if route == "apercu":
        a = ops.apercu_mois(ctx, charge["saisie"])
        return js.apercu(a, lignes=charge.get("lignes", False))

    if route == "rubriques-actives":
        # Ce que la compagnie coche. C'est une preference d'affichage, pas une
        # donnee de paie : elle change l'ordre du deroulant, jamais un calcul.
        return {"rubriques": ops.choisir_rubriques(ctx, charge["actives"])}

    if route == "enregistrer-saisie":
        p = ops.enregistrer_saisie(ctx, charge["mois"], charge["saisie"])
        return {"chemin": str(p)}

    if route == "produire":
        # On produit depuis la saisie EN MEMOIRE, et on ne l'enregistre
        # qu'ensuite. La premiere version ecrivait le fichier d'abord : un
        # refus faute de montant URSSAF laissait quand meme une trace et une
        # copie de sauvegarde -- treize en une seance de tests. « Rien n'est
        # ecrit avant que tout soit calcule » vaut aussi pour la saisie.
        r = ops.produire_mois(
            ctx, dict(charge["saisie"], mois=charge["mois"]),
            urssaf=charge.get("urssaf"),
            accepter_estimation=charge.get("urssaf_estime", False),
            sans_contrat=charge.get("sans_contrat", False),
            envoi_test=charge.get("test", False), qui="interface")
        ops.enregistrer_saisie(ctx, charge["mois"], charge["saisie"])
        return js.mois_produit(r)

    if route == "dpae":
        # `paies` absent : tout le mois, comme avant. Present : ces embauches
        # seulement, dans un fichier horodate a cote du complet. C'est
        # `operations` qui refuse une selection introuvable, pas cette route.
        #
        # LE CHEMIN, ET NON LE MOIS. `produire_dpae` attend une SOURCE, que
        # `charger` resout comme un chemin : un << 2026-09 >> nu tombait sur
        # un FileNotFoundError. La route est nee avec ce defaut le 11/09/2026
        # et personne ne l'a vu -- aucune des deux faces ne l'appelait, et une
        # route que rien n'appelle ne tombe jamais. Trouve le 12/09 en lui
        # donnant enfin un bouton.
        r = ops.produire_dpae(ctx,
                              ctx.racine / "paies" / ("%s.json" % charge["mois"]),
                              heure=charge.get("heure", "0800"),
                              paies=charge.get("paies"))
        return js.dpae_produite(r)

    if route == "valider-paie":
        # Fermer (ou rouvrir) l'edition d'une paie. Rien ne part, rien n'est
        # produit, aucun compteur ne bouge : pas de preuve demandee. Ce qui
        # protege ici, c'est que l'operation refuse une paie absente de la
        # saisie ENREGISTREE.
        return ops.valider_paie(ctx, charge["mois"], charge["salarie"],
                                charge["debut"],
                                valide=bool(charge.get("valide", True)),
                                qui="interface")

    if route == "contrat-recu":
        # Un humain dit que le contrat signe est revenu (ou retire la note).
        # Rien ne part, rien ne se produit : pas de preuve demandee.
        return ops.contrat_recu(ctx, charge["mois"], charge["salarie"],
                                charge["debut"],
                                recu=bool(charge.get("recu", True)),
                                qui="interface")

    if route == "etat-par-paie":
        # Ou en est chaque paie du mois. Chaque etat dit a quelle MAILLE il
        # est connu -- paie, salarie ou mois -- et l'ecran doit l'ecrire :
        # une DSN est mensuelle, elle ne se depose pas pour une paie.
        return {"mois": charge["mois"],
                "paies": ops.etat_par_paie(ctx, charge["mois"])}

    # ------------------------------------------------ ce qui part d'ici
    # Chacune de ces routes n'aiguille. La preuve, le secret de l'organisme,
    # le refus : tout est dans `operations`, et la ligne de commande passe
    # par les memes fonctions.
    if route == "etat-du-mois":
        from . import journal
        m = charge["mois"]
        actes = journal.etat_du_mois(ctx, m)
        recus = journal.contrats_recus(ctx)
        return {"mois": m,
                "actes": {k: v for k, v in actes.items()},
                # La phrase est celle du MOTEUR. Elle distingue trois etats
                # qu'un ecran aurait vite fait de confondre -- jamais parti,
                # parti sans reponse, parti et repondu -- et une declaration
                # en attente ne doit pas se lire comme une declaration
                # conforme. La ligne de commande dira la meme.
                "resumes": {k: journal.resume(v, recus) for k, v in actes.items()},
                # Les derniers envois, tests compris, LE PLUS RECENT EN
                # PREMIER -- << le plus recent, test ou pas test, en premier >>
                #. Le reel y figure comme les autres.
                "derniers": {k: [{"quand": l.get("quand"), "mode": l.get("mode"),
                                  "fichier": l.get("fichier"),
                                  "resume": journal.resume(l, recus)}
                                 for l in reversed(v)]
                             for k, v in journal.dernieres_du_mois(ctx, m).items()},
                # Quel fichier du mois se depose : c'est `operations` qui
                # tranche, pas la page. Voir `fichiers_deposables`.
                "fichiers": ops.fichiers_deposables(ctx, m),
                # Le mois en un coup d'oeil, par acte : phrase et couleur,
                # decidees par le moteur (bilan_du_mois).
                "bilans": ops.bilan_du_mois(ctx, m),
                "lignes": journal.lire(ctx, mois=m),
                "seance": ops.seance(ctx)}

    if route == "documents-liste":
        return {"mois": charge["mois"],
                "fichiers": ops.documents_du_mois(ctx, charge["mois"], charge.get("quoi"))}

    if route == "ouvrir-dossier":
        # Les documents a la main, pour qui n'a pas lie de compte Google :
        # on ouvre le dossier des sorties du mois dans l'explorateur. Local,
        # sans reseau, rien n'est envoye. Le chemin est celui du moteur,
        # jamais un chemin recu de la page.
        import os
        dossier = ctx.racine / "sorties" / charge["mois"]
        # `envoi/` : ce qui part a chaque salarie -- ses bulletins, ses
        # contrats un a un. C'est la qu'on cherche un document a remettre.
        envoi = dossier / "envoi"
        if envoi.exists() and (
                charge.get("quoi") == "documents"
                or (charge.get("quoi") == "contrats" and any(envoi.glob("Contrat*.pdf")))):
            dossier = envoi
        if not dossier.exists():
            raise ops.ErreurOperation("Rien n'est encore ecrit pour %s." % charge["mois"])
        _ouvrir_devant(dossier)
        return {"dossier": str(dossier)}

    if route == "depot-apercu":
        if charge["quoi"] == "dsn":
            return ops.apercu_depot_dsn(ctx, charge["fichier"])
        return ops.apercu_depot_dpae(ctx, charge["fichier"])

    if route == "deposer":
        # `motdepasse` est celui DU LOGICIEL, et il ne sert qu'a prouver la
        # presence. Il arrive par le corps du POST, il n'est ni journalise ni
        # renvoye, et rien d'autre de cette page ne le voit.
        preuve = ops.Preuve(motdepasse=charge.get("motdepasse"))
        if charge["quoi"] == "dsn":
            # `forcer` : l'annule-et-remplace voulu, apres l'avertissement
            # que la page affiche sur DsnDejaDeposee. Jamais par defaut.
            fait = ops.deposer_dsn(ctx, charge["fichier"],
                                   reel=bool(charge.get("reel")),
                                   preuve=preuve, qui="interface",
                                   forcer=bool(charge.get("forcer")))
        else:
            fait = ops.deposer_dpae(ctx, charge["fichier"],
                                    reel=bool(charge.get("reel")),
                                    preuve=preuve, qui="interface")
        return {"quoi": fait.quoi, "mois": fait.mois, "reel": fait.reel,
                "reponse": fait.reponse, "flux": fait.flux,
                "trace": str(fait.trace) if fait.trace else None,
                "ligne": fait.ligne, "deja": fait.deja}

    if route == "journal-reprise":
        # La reprise du journal (ETAT.md §19.11). `ecrire` absent : elle DIT
        # ce qu'elle ferait. Aucun reseau, aucun depot : elle lit les pieces
        # deja archivees dans retours/ et ecrit ce qu'elles disent.
        #
        # Pas de mot de passe, et c'est justifie : rien ne part. Une reprise
        # n'engage l'employeur en rien -- elle corrige ce que le logiciel
        # CROIT de depots qui ont deja eu lieu. Exiger la preuve ici aurait
        # aligne un geste sans consequence sur les quatre qui en ont, et
        # affaibli la lecture des quatre.
        return ops.reconstruire_journal(ctx, ecrire=bool(charge.get("ecrire")),
                                        qui="interface")

    if route == "embauches-a-declarer":
        return {"embauches": ops.embauches_a_declarer(ctx, charge.get("mois"))}

    if route == "envoi-apercu":
        return ops.apercu_envoi(ctx, charge["mois"])

    if route == "envoyer-documents":
        r = ops.envoyer_documents(ctx, charge["mois"],
                                  preuve=ops.Preuve(motdepasse=charge.get("motdepasse")),
                                  qui="interface")
        return {"partis": r["partis"], "messages": r["messages"],
                "expediteur": r["expediteur"],
                "avertissements": r["avertissements"], "ligne": r["ligne"]}

    if route == "signature-apercu":
        return ops.apercu_signature(ctx, charge["mois"])

    if route == "demander-signature":
        # `contrats` : la selection PAR CONTRAT (salarie, debut) -- ce que la
        # boite a coche, et rien d'autre. `salaries` reste lu pour un appel
        # ancien, mais la page n'envoie plus que `contrats`.
        r = ops.demander_signature(
            ctx, charge["mois"], salaries=charge.get("salaries"),
            contrats_voulus=charge.get("contrats"),
            preuve=ops.Preuve(motdepasse=charge.get("motdepasse")),
            qui="interface")
        return {"partis": r["partis"], "contrats": r["contrats"],
                "expediteur": r["expediteur"], "ligne": r["ligne"]}

    if route == "importation-apercu":
        # Ce que l'import ferait : rien n'est ecrit. `export` vide = le
        # dossier trouve a cote des donnees (contexte.trouver_export).
        return js.importation(ops.apercu_importation(ctx, charge.get("export") or None))
    if route == "importer":
        return js.importation(ops.importer(ctx, charge.get("export") or None))
    if route == "veille":
        # Ce que le logiciel a fait tout seul depuis qu'il est ouvert. Aucun
        # secret ne passe par la : `coffre.etat` ne rend que des presences.
        return veille.etat() if veille else {"minutes": 0, "dernier": {},
                                             "en_cours": False}

    if route == "veille-maintenant":
        if not veille:
            raise ops.ErreurOperation("Pas de veille sur cette interface.")
        return veille.tour(veille=False)

    raise ops.ErreurOperation("Route inconnue : %r" % route)


# ------------------------------------------------------------------- la veille
class Veille:
    """Le travail de fond de l'interface : sauvegarder, et relever les retours.

    La demande : que ca se fasse A L'OUVERTURE, puis
    « frequemment quand l'application est ouverte ». D'ou ce fil, demarre avec
    le serveur et qui meurt avec lui.

    Trois precautions, chacune payee par un ennui previsible :

    1. **En arriere-plan, jamais dans une requete.** Un premier tour qui
       televerse 16 Mo ne doit pas retarder l'affichage de la page. La page
       demande l'etat quand elle veut, et voit « en cours » si ca tourne.
    2. **Rien ne remonte tant que rien n'a bouge.** Le tour periodique compare
       d'abord les tailles et les dates en local (`sauvegarde.rien_n_a_bouge`)
       et ne touche au reseau que si quelque chose a change. Vingt minutes,
       c'est souvent quand personne ne travaille.
    3. **Un tour a la fois.** Deux tours simultanes ecriraient le meme index
       de sauvegarde et le meme journal de retours.

    La veille ne DEPOSE rien et ne peut pas le faire : elle appelle
    `operations.ouverture`, qui ne connait que la sauvegarde et la lecture des
    retours. C'est la meme regle que pour le reste de l'interface -- produire
    oui, transmettre non.
    """

    def __init__(self, ctx: Contexte, minutes: int = 20, jours: int = 30):
        self.ctx = ctx
        self.minutes = max(0, int(minutes))
        self.jours = jours
        self.dernier = None
        self.en_cours = False
        self.erreur = ""
        self._verrou = threading.Lock()

    # -- ce que la page lit
    def etat(self) -> dict:
        from . import coffre, sauvegarde as _sauvegarde
        s = coffre.seance(self.ctx)
        return {
            "en_cours": self.en_cours,
            "minutes": self.minutes,
            "dernier": self.dernier or ops.derniere_ouverture(self.ctx),
            "erreur": self.erreur,
            "sauvegarde": _sauvegarde.derniere(self.ctx),
            "coffre": [{"service": x.service, "libelle": x.libelle, "pose": x.pose,
                        "pose_le": x.pose_le, "environnement": x.dans_environnement}
                       for x in coffre.etat(self.ctx)],
            "seance": {"exigee": s.exigee, "ouverte": s.ouverte,
                       "ouverte_le": s.ouverte_le},
        }

    # -- le travail
    def tour(self, veille: bool = True) -> dict:
        if not self._verrou.acquire(blocking=False):
            return self.etat()
        self.en_cours, self.erreur = True, ""
        try:
            r = ops.ouverture(self.ctx, jours=self.jours, veille=veille)
            self.dernier = ops.derniere_ouverture(self.ctx)
        except Exception as e:                                    # noqa: BLE001
            # Une ouverture qui echoue ne doit pas emporter l'interface : on
            # garde le message et la page continue de servir a faire des paies.
            self.erreur = str(e)
        finally:
            self.en_cours = False
            self._verrou.release()
        return self.etat()

    def demarrer(self) -> None:
        def boucle():
            self.tour(veille=False)              # le premier tour est complet
            while self.minutes:
                time.sleep(self.minutes * 60)
                self.tour(veille=True)
        threading.Thread(target=boucle, daemon=True).start()


# ---------------------------------------------------------------- le serveur
def _poignee(ctx: Contexte, jeton: str, veille=None):
    class Poignee(BaseHTTPRequestHandler):
        # HTTP/1.1, ET C'EST UNE CORRECTION (15/09/2026). En HTTP/1.0, le
        # serveur ferme la connexion sitot la reponse ecrite, et Windows
        # envoie parfois un RST avant que le client ait tout lu : mesure
        # sur interface.js (158 Ko), 4 a 6 chargements sur 40 coupes --
        # ERR_CONNECTION_RESET dans le navigateur, une page sans script, et
        # le meme WinError 10054 un test sur trente dans test_interface.py.
        # Les petits fichiers passaient toujours. En HTTP/1.1 la connexion
        # reste ouverte et c'est le client qui la ferme ; toutes nos
        # reponses portent deja leur Content-Length (`_envoyer`).
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass                                  # le terminal reste lisible

        # -- garde-fou : sans le jeton, rien ---------------------------------
        def _autorise(self, params) -> bool:
            fourni = (params.get("jeton", [None])[0]
                      or self.headers.get("X-Jeton")
                      or self._cookie_jeton())
            return secrets.compare_digest(str(fourni or ""), jeton)

        def _cookie_jeton(self):
            from http.cookies import SimpleCookie
            c = SimpleCookie()
            try:
                c.load(self.headers.get("Cookie", ""))
            except Exception:                                     # noqa: BLE001
                return None
            return c["jeton"].value if "jeton" in c else None

        def _envoyer(self, code, corps: bytes, type_mime: str):
            self.send_response(code)
            self.send_header("Content-Type", type_mime)
            self.send_header("Content-Length", str(len(corps)))
            # La page ne doit rien charger d'ailleurs, ni etre encadree.
            self.send_header("Content-Security-Policy",
                             "default-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(corps)

        def _json(self, charge: dict, code: int = 200):
            self._envoyer(code, json.dumps(charge, ensure_ascii=False).encode("utf-8"),
                          "application/json; charset=utf-8")

        def do_GET(self):
            u = urlparse(self.path)
            params = parse_qs(u.query)
            if u.path in ("/", "/index.html"):
                if not self._autorise(params):
                    return self._envoyer(403, b"jeton absent ou invalide",
                                         "text/plain; charset=utf-8")
                if params.get("jeton") and u.path == "/":
                    # Le jeton passe en cookie, et l'adresse redevient propre.
                    # (`/index.html?jeton=` sert la page telle quelle : c'est
                    # le chemin des tests, et une echappatoire si un
                    # navigateur refusait le cookie.)
                    self.send_response(303)
                    self.send_header("Location", "/")
                    self.send_header("Set-Cookie",
                                     "jeton=%s; Path=/; HttpOnly; SameSite=Strict"
                                     % jeton)
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                page = (RESSOURCES / "index.html").read_text(encoding="utf-8")
                page = page.replace("{{JETON}}", jeton)
                return self._envoyer(200, page.encode("utf-8"),
                                     "text/html; charset=utf-8")
            if u.path in ("/interface.css", "/interface.js"):
                if not (RESSOURCES / u.path.lstrip("/")).exists():
                    return self._envoyer(404, b"", "text/plain")
                corps = (RESSOURCES / u.path.lstrip("/")).read_bytes()
                mime = ("text/css" if u.path.endswith(".css")
                        else "application/javascript")
                return self._envoyer(200, corps, mime + "; charset=utf-8")
            self._envoyer(404, b"", "text/plain")

        def do_POST(self):
            u = urlparse(self.path)
            # Lire le corps AVANT toute reponse, meme pour refuser : repondre
            # sans consommer ce que le client envoie fait fermer la connexion
            # par le systeme (WinError 10054), et l'appelant recoit une erreur
            # reseau au lieu du 403 qui lui dirait quoi faire.
            longueur = int(self.headers.get("Content-Length") or 0)
            corps = self.rfile.read(longueur) if longueur else b"{}"

            if not self._autorise(parse_qs(u.query)):
                return self._json({"ok": False, "erreur": {
                    "type": "NonAutorise", "message": "jeton absent"}}, 403)
            if not u.path.startswith("/api/"):
                return self._json({"ok": False, "erreur": {
                    "type": "Inconnue", "message": "route inconnue"}}, 404)

            try:
                charge = json.loads(corps or b"{}")
            except json.JSONDecodeError as e:
                return self._json({"ok": False, "erreur": {
                    "type": "JSONInvalide", "message": str(e)}}, 400)

            route = u.path[len("/api/"):]
            # Un contexte NEUF a chaque appel : la configuration a pu changer
            # dans l'onglet d'a cote, ou par une commande. Un contexte garde
            # en memoire servirait des donnees perimees.
            frais = Contexte(ctx.racine)
            try:
                return self._json({"ok": True,
                                   "resultat": _traiter(frais, route, charge,
                                                        veille)})
            except ops.FicheRefusee as e:
                return self._json({"ok": False, "erreur": {
                    "type": "FicheRefusee", "message": str(e),
                    "anomalies": e.verifiee.anomalies}}, 200)
            except ops.DsnDejaDeposee as e:
                return self._json({"ok": False, "erreur": {
                    "type": "DsnDejaDeposee", "message": str(e),
                    "etat": e.etat}}, 200)
            except ops.DpaeDejaDeclaree as e:
                return self._json({"ok": False, "erreur": {
                    "type": "DpaeDejaDeclaree", "message": str(e),
                    "embauches": e.embauches}}, 200)
            except ops.UrssafManquant as e:
                return self._json({"ok": False, "erreur": {
                    "type": "UrssafManquant", "message": str(e),
                    "estimation": js.brut(e.estimation),
                    "marge": js.brut(e.marge),
                    "apercu": js.apercu(e.apercu)}}, 200)
            except ops.ErreurOperation as e:
                return self._json({"ok": False, "erreur": {
                    "type": type(e).__name__, "message": str(e)}}, 200)
            except (KeyError, ValueError, FileNotFoundError) as e:
                # Salarie ou spectacle inconnu, date impossible, bareme absent :
                # ce sont des messages ecrits pour etre lus, on les rend tels quels.
                return self._json({"ok": False, "erreur": {
                    "type": type(e).__name__, "message": str(e)}}, 200)
            except Exception as e:                                # noqa: BLE001
                # Tout le reste est un DEFAUT DU LOGICIEL -- pas une raison de
                # couper la connexion. Sans cette branche, le serveur HTTP
                # ecrit la trace sur son terminal et ferme la socket sans
                # repondre : le navigateur voit « Failed to fetch », et la page
                # conclut que le serveur est mort alors qu'il tourne (le
                # 12/09/2026, un TypeError de contrat.py a ete pris pour une
                # fenetre fermee). On rend donc l'erreur, nommee, avec sa
                # trace sur le terminal pour qui veut la corriger.
                traceback.print_exc()
                return self._json({"ok": False, "erreur": {
                    "type": type(e).__name__,
                    "message": "Defaut du logiciel (%s) : %s -- la trace est "
                               "dans la fenetre PuppetPaie."
                               % (type(e).__name__, e)}}, 200)

    return Poignee


# UN PORT FIXE ET UN NOM, ET C'EST POUR CHROME (Leandre, 15/09/2026 : << j'aimerais
# qu'on puisse enregistrer le mot de passe dans ce champ >>). Chrome memorise un
# mot de passe par ORIGINE -- hote et port. Un port tire au hasard a chaque
# lancement faisait de chaque ouverture un site nouveau, sans mot de passe
# connu. Le port est donc fixe (le hasard ne revient que s'il est pris), et
# l'adresse porte un nom : tout `*.localhost` est resolu vers la machine par
# Chrome, Edge et Firefox sans rien configurer. Le serveur, lui, n'ecoute
# toujours que 127.0.0.1.
PORT_DEFAUT = 7331
HOTE_AFFICHE = "puppetpaie.localhost"
FICHIER_JETON = ".jeton-interface"


def jeton_interface(ctx: Contexte) -> str:
    """Le jeton de cette installation : tire une fois, garde dans config/.

    Voir l'en-tete (« le jeton n'est plus dans la barre d'adresse ») : c'est
    ce qui permet au cookie, et donc a un favori, de survivre a un
    redemarrage. Un fichier illisible ou vide est simplement retire.
    """
    p = ctx.racine / "config" / FICHIER_JETON
    try:
        j = p.read_text(encoding="ascii").strip()
        if len(j) >= 24 and all(c.isalnum() or c in "-_" for c in j):
            return j
    except (OSError, UnicodeDecodeError):
        pass
    j = secrets.token_urlsafe(24)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(j, encoding="ascii")
    except OSError:
        pass                     # pas grave : le jeton vaut pour ce lancement
    return j


def servir(ctx: Contexte, ouvrir: bool = True, port: int = None,
           annoncer=None, minutes_veille: int = 20) -> str:
    """Demarre l'interface et rend son adresse. Bloque jusqu'a Ctrl+C.

    `port` : None = le port fixe PORT_DEFAUT, ou un port libre s'il est pris ;
    0 = un port libre au hasard ; sinon celui-la.

    `annoncer` recoit l'adresse AVANT que le serveur ne bloque : sans elle,
    `--sans-navigateur` demarrerait un serveur dont personne ne connait le
    jeton, donc inatteignable. Ce module n'imprime pas lui-meme -- c'est le
    front qui sait s'il a un terminal.

    `minutes_veille` a 0 : pas de travail de fond. Le premier tour part quand
    meme -- « a l'ouverture » est la demande, la repetition n'en est que le
    prolongement.
    """
    jeton = jeton_interface(ctx)
    veille = Veille(ctx, minutes=minutes_veille)
    poignee = _poignee(ctx, jeton, veille)
    if port is None:
        try:
            serveur = ThreadingHTTPServer(("127.0.0.1", PORT_DEFAUT), poignee)
        except OSError:
            serveur = ThreadingHTTPServer(("127.0.0.1", 0), poignee)
    else:
        serveur = ThreadingHTTPServer(("127.0.0.1", port), poignee)
    adresse = "http://%s:%d/?jeton=%s" % (HOTE_AFFICHE, serveur.server_address[1], jeton)
    if annoncer:
        annoncer(adresse)
    veille.demarrer()
    if ouvrir:
        threading.Timer(0.4, lambda: webbrowser.open(adresse)).start()
    try:
        serveur.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        serveur.shutdown()
    return adresse
