"""Ce que fait le logiciel -- sans dire comment cela s'affiche.

PuppetPaie a deux faces : la ligne de commande (celle que Claude Code utilise
aussi) et l'interface. Elles doivent etre INTERCHANGEABLES : tout ce qui se
fait dans l'une se fait dans l'autre, et les deux produisent exactement les
memes octets. Cela n'est vrai que si aucune des deux ne porte de decision.

D'ou ce module. Il tient l'orchestration -- l'ordre de production, les
compteurs, les garde-fous -- et il ne connait ni `print`, ni HTML, ni
argparse. Il rend des DONNEES : des fichiers ecrits, des totaux, des
avertissements, et des etapes suivantes qu'un front affiche comme il veut.

Trois regles, dans cet ordre d'importance :

1. **Un garde-fou vit ici, jamais dans un front.** Le refus de produire une
   DSN sans le montant URSSAF etait un `return 2` dans la ligne de commande :
   une interface qui aurait appele `dsn.ecrire` directement l'aurait contourne
   sans le savoir. C'est desormais une exception levee ici, que les deux
   faces attrapent.
2. **Les compteurs sont un etat partage.** Deux fronts ouverts en meme temps,
   c'est deux paies qui prennent le meme numero de bulletin -- et rien ne le
   dirait. Toute operation qui ecrit `config/compteurs.json` passe par
   `verrou_compteurs`.
3. **Rien n'est ecrit avant que tout soit calcule.** Une erreur doit laisser
   le disque comme elle l'a trouve, compteurs compris.

Ce module n'ouvre pas de navigateur et n'imprime pas : les actes qui
demandent un oeil humain (la page de relecture avant envoi, l'autorisation
Google) sont declenches par le front, qui sait s'il a un ecran.

UN NOM, NEUF FICHIERS. Les deux faces et les tests importent `operations` et
ne connaissent que lui ; ce qu'il expose vit dans des modules par domaine,
qu'il reexporte ici sans en changer une signature :

    operations_socle         l'erreur, le verrou, la preuve, le filet
    operations_paies         charger, apercevoir, produire, valider une saisie
    operations_declarations  produire une DPAE, deposer une DSN ou une DPAE
    operations_retours       relever les retours, reprendre le journal,
                             l'etat du mois qu'ils donnent
    operations_documents     preparer, envoyer, faire signer, archiver
    operations_ouverture     l'ouverture et la veille, le compte Google
    operations_fiches        lire, verifier, enregistrer, dater une fiche
    operations_catalogues    metiers, rubriques, sources
    operations_importation   reprendre les fiches et l'historique de CoolPaie

Une operation neuve s'ecrit dans le module de son domaine et s'ajoute ici.
Les modules ne dependent que du socle et, pour ceux qui lisent une saisie,
de `operations_paies` : aucun cycle.
"""
from __future__ import annotations

from .operations_socle import (                                  # noqa: F401
    DELAI_VERROU, GARDER_COPIES,
    CompteursVerrouilles, ErreurOperation, Preuve, PreuveInsuffisante,
    SeanceFermee,
    seance, verrou_compteurs,
)
from .operations_paies import (                                  # noqa: F401
    ApercuMois, ContratEnCours, Etape, FichierExistant, MoisConnu, MoisProduit,
    Numeros, PositionDroits, Saisie, UrssafManquant,
    apercu_mois, calibrer, charger, contrats_en_cours, dates_engagement,
    dernier_taux, droits, engagement_de_reprise, enregistrer_saisie,
    figer_numeros, libelle_mois,
    lire_saisie, mois_connus, mois_precedents_du_contrat, nouvelle_saisie,
    paie_du_contrat_entier, paies_validees, produire_mois, squelette,
    valider_paie,
)
from .operations_declarations import (                           # noqa: F401
    DepotFait, DpaeDejaDeclaree, DpaeProduite, DsnDejaDeposee, LigneDpae,
    apercu_depot_dpae, apercu_depot_dsn, deposer_dpae, deposer_dsn,
    embauches_a_declarer, fichiers_deposables, libelle_dsn_deposee,
    libelle_embauche_declaree, produire_dpae,
)
from .operations_retours import (                                # noqa: F401
    DepotAtteste, ReleveRetours, RetourArchive,
    bilan_du_mois, depots_attestes, embauches_attestees, etat_par_paie,
    reconstruire_journal, reconstruire_journal_dpae, relever_retours,
    relever_retours_dpae, reprendre_depot,
)
from .operations_documents import (                              # noqa: F401
    CORPS_SIGNATURE, SUJET_SIGNATURE, SUJET_SIGNATURE_PLURIEL,
    Archivage, EnvoiPrepare, FichierArchive, GoogleNonAutorise, SortieAbsente,
    apercu_envoi, apercu_signature, archiver, confirmer_et_envoyer,
    contrat_recu, demander_signature, documents_du_mois, documents_prets,
    envoyer_documents, preparer_envoi,
    ReleveSignatures, SignatureRecue, code_signature, relever_signatures,
)
from .operations_ouverture import (                              # noqa: F401
    EtatGoogle, MiseAJour, Ouverture, VeilleSources,
    appliquer_maj, derniere_ouverture, google_autoriser, google_etat, google_oublier,
    ouverture, publier_maj, revenir_maj, verifier_maj, version,
)
from .operations_fiches import (                                 # noqa: F401
    FICHIERS_CONFIG,
    Fiche, FicheRefusee, FicheVerifiee,
    changements_declares, cle_neuve, configuration, enregistrer_fiche, fiche,
    garder_notes_internes, usages_declares, verifier_fiche,
)
from .operations_catalogues import (                             # noqa: F401
    choisir_rubriques, metiers, rubriques, sources,
)
from .operations_importation import (                            # noqa: F401
    ExportIntrouvable, FicheImportee, Importation,
    apercu_importation, chemin_historique, importer, lire_historique,
)
