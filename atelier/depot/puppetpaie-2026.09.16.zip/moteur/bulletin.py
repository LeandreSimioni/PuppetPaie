"""Bulletin de paie PDF, au format de la Compagnia UEUEUE.

Rendu par PyMuPDF (Story/HTML) : pas de dependance a installer, le PDF sort
directement. Une page par bulletin, plusieurs bulletins dans un meme fichier.
"""
from __future__ import annotations
from decimal import Decimal
from pathlib import Path

import pymupdf

from . import plafond as _plafond
from .contexte import GABARITS
from .util import fmt_eur, fmt_taux, jj_mm_aaaa, MOIS_FR

# Charte de la compagnie, reprise des gabarits de devis et de contrat de cession
# (gabarits/identite/) : rouge d'accent, bleu ardoise pour le texte, Arial.
ROUGE = "#B22222"
ARDOISE = "#2C3E50"

CSS = """
* { font-family: Arial, sans-serif; }
body { font-size: 7.4pt; color: #2C3E50; }
.entete td { vertical-align: top; padding: 0; }
.rs { font-size: 13pt; color: #2C3E50; font-weight: bold; }
.coord { font-size: 6.6pt; color: #555; }
h1 { font-size: 11pt; color: #B22222; margin: 8pt 0 1pt 0;
     text-transform: uppercase; letter-spacing: 0.6pt; }
.sub { font-size: 7pt; color: #555; margin: 0 0 5pt 0; }
table { width: 100%; border-collapse: collapse; }
td, th { padding: 1.4pt 3pt; vertical-align: top; }
.ident td { font-size: 7pt; border: 0.5pt solid #ddd; }
.ident .k { color: #777; }
.cot th { background: #B22222; color: #fff; font-size: 6.6pt; text-align: right; }
.cot th.l { text-align: left; }
.cot td { font-size: 7pt; border-bottom: 0.3pt solid #e4e4e4; }
.fam td { background: #f4f0f0; font-weight: bold; font-size: 6.8pt;
          color: #B22222; }
.brut td { background: #fbf7f7; font-weight: bold; }
.r { text-align: right; }
.tot td { font-weight: bold; border-top: 0.6pt solid #B22222; }
.net td { font-weight: bold; font-size: 9.5pt; background: #B22222; color: #fff; }
.cumul th { background: #f4f0f0; color: #B22222; font-size: 6.8pt;
            text-align: right; border-top: 0.8pt solid #B22222; }
.cumul th.l { text-align: left; color: #2C3E50; }
.cumul td { font-size: 7pt; text-align: right; border-bottom: 0.3pt solid #eee; }
.cumul td.l { text-align: left; }
.cumul .reste td { font-weight: bold; color: #B22222; }
.pied { font-size: 6.2pt; color: #777; margin-top: 5pt; }
"""

def _bloc_cumul(colonnes) -> str:
    """Le cumul en bas du bulletin : periode, annee civile, droits.

    Trois fenetres qui ne se recouvrent pas volontairement -- voir
    moteur/cumul.py. La colonne « Droits » n'apparait que si une date
    anniversaire a ete notifiee : on n'invente pas de fenetre.
    """
    if not colonnes:
        return ""
    entete = "".join('<th>%s<br/><span style="font-weight:normal">%s</span></th>'
                     % (c.titre, c.sous_titre) for c in colonnes)
    lignes = []
    # Les deux lignes d'enseignement ne s'impriment que s'il y en a : un
    # bulletin de cachets ne doit pas porter une ligne a zero qui n'apprend
    # rien. Quand il y en a, elles s'imposent -- ces heures ouvrent les
    # droits sans augmenter l'ARE, et le salarie ne peut pas le deviner.
    enseigne = any(getattr(c, "enseignement", 0) for c in colonnes)
    rangs = [("Cachets", "cachets", ""),
             ("Heures d&eacute;clar&eacute;es", "heures", " h"),
             ("Total heures (cachets &times; 12 + heures)",
              "heures_equivalentes", " h")]
    if enseigne:
        rangs += [("dont enseignement (droits seuls, pas le montant)",
                   "enseignement", " h"),
                  ("Heures retenues pour les 507 h", "heures_ouverture", " h")]
    rangs.append(("Salaire brut", "brut", " &euro;"))
    for libelle, attr, suffixe in rangs:
        cells = "".join("<td>%s%s</td>" % (
            fmt_eur(getattr(c, attr)) if attr == "brut" else getattr(c, attr),
            suffixe) for c in colonnes)
        lignes.append("<tr><td class=\"l\">%s</td>%s</tr>" % (libelle, cells))
    droits = colonnes[-1]
    if droits.reste is not None:
        vides = "<td></td>" * (len(colonnes) - 1)
        valeur = ("%d h" % droits.reste) if droits.reste else "seuil atteint"
        lignes.append(
            '<tr class="reste"><td class="l">Reste avant les 507 h '
            '(annexes 8 et 10)</td>%s<td>%s</td></tr>' % (vides, valeur))
    return ("""
<table class="cumul">
 <tr><th class="l" width="40%%">CUMULS</th>%s</tr>
 %s
</table>""" % (entete, "".join(lignes)))


def _bloc_remuneration(p) -> str:
    """Le haut du bulletin : ce qui est paye, ligne par ligne.

    Ces lignes viennent du moteur (`Paie.remuneration`), pas d'une relecture
    de `cachets` et `taux_cachet` : un contrat d'une journee de 5 h et d'une
    masterclass n'a pas de cachet, et l'ancienne ligne unique l'aurait
    imprime « 0 Cachets isoles a 130,00 ».

    Un contrat a une seule ligne garde la forme d'origine -- la designation,
    le taux et SALAIRE BRUT sur le meme rang. Des qu'il y en a plusieurs,
    chacune a son rang et le brut devient un total.
    """
    lignes = p.remuneration or []
    if len(lignes) <= 1:
        titre = ("%s &agrave; %s" % (lignes[0].designation, fmt_eur(lignes[0].taux))
                 if lignes else "SALAIRE")
        return ('<tr class="brut"><td>%s &mdash; SALAIRE BRUT</td>'
                '<td class="r"><b>%s</b></td>'
                '<td></td><td></td><td></td><td></td></tr>'
                % (titre, fmt_eur(p.brut)))
    out = []
    for l in lignes:
        out.append('<tr><td>%s &agrave; %s</td><td class="r">%s</td>'
                   '<td></td><td></td><td></td><td></td></tr>'
                   % (l.designation, fmt_eur(l.taux), fmt_eur(l.montant)))
    out.append('<tr class="brut"><td>SALAIRE BRUT</td>'
               '<td class="r"><b>%s</b></td>'
               '<td></td><td></td><td></td><td></td></tr>' % fmt_eur(p.brut))
    return "".join(out)


def _html_un(p, ent, colonnes=None) -> str:
    s, e, sp = p.salarie, p.engagement, p.spectacle
    bloc_cumul = _bloc_cumul(colonnes or [])
    dates = ", ".join(jj_mm_aaaa(x) for x in e.dates_travail)
    # Une paie d'un contrat qui deborde du mois : la periode est celle du
    # mois, le contrat est dit a cote, pour que le bulletin de novembre ne
    # ressemble pas a celui d'un contrat de novembre.
    contrat_long = (" (contrat du %s au %s)" % (jj_mm_aaaa(e.debut), jj_mm_aaaa(e.fin))
                    if e.a_cheval else "")
    brut_lignes = _bloc_remuneration(p)
    lignes, fam = [], None
    for l in p.lignes:
        if l.famille != fam:
            fam = l.famille
            lignes.append(f'<tr class="fam"><td colspan="6">{fam}</td></tr>')
        base = "" if l.masquer_base_et_taux else fmt_eur(l.base)
        tp = "" if (l.taux_pat is None or l.masquer_base_et_taux) else fmt_taux(l.taux_pat)
        ts = "" if l.taux_sal is None else fmt_taux(l.taux_sal)
        mp = fmt_eur(l.montant_pat) if l.montant_pat else ""
        ms = fmt_eur(l.montant_sal) if l.montant_sal else ""
        lignes.append(
            f'<tr><td>{l.libelle}</td><td class="r">{base}</td>'
            f'<td class="r">{tp}</td><td class="r">{mp}</td>'
            f'<td class="r">{ts}</td><td class="r">{ms}</td></tr>')

    return f"""
<table class="entete"><tr>
  <td width="72%">
    <span class="rs">{ent['nom_affichage']}</span><br/>
    <span class="coord">{ent.get('adresse_affichage', ent['adresse'])} &mdash;
      {ent['code_postal']} {ent.get('commune_affichage', ent['commune'])}<br/>
      Siret {ent['siret']} &nbsp;&middot;&nbsp; APE {ent['naf']}
      &nbsp;&middot;&nbsp; Licence {ent['licence_spectacle']}</span>
  </td>
  <td width="28%">&nbsp;</td>
</tr></table>

<h1>Bulletin de paie n&deg; {p.numero_bulletin or ''}</h1>
<p class="sub">Num&eacute;ro d'objet : {sp['numero_objet']} &nbsp;&mdash;&nbsp;
   Spectacle : {sp['titre']}</p>

<table class="ident"><tr>
  <td width="50%">
    <b>{s['nom']} {s['prenom']}</b><br/>{s['adresse']}<br/>{s['code_postal']} {s['commune']}<br/><br/>
    <span class="k">N&deg; S&eacute;curit&eacute; sociale :</span> {s['nir']}{s['nir_cle']}<br/>
    <span class="k">Date de naissance :</span> {jj_mm_aaaa(s['date_naissance'])}<br/>
    <span class="k">Emploi :</span> {s['emploi']} &nbsp; <span class="k">Statut :</span> {s['statut']}<br/>
    <span class="k">N&deg; Cong&eacute;s Spectacles :</span> {s.get('num_conges_spectacles') or '-'}<br/>
    <span class="k">Abattement :</span> 0 %
  </td>
  <td width="50%">
    <b>EMPLOYEUR</b><br/><br/>
    <span class="k">N&deg; Siret :</span> {ent['siret']}<br/>
    <span class="k">NAF (APE) :</span> {ent['naf']}<br/>
    <span class="k">Urssaf :</span> {ent['urssaf_compte']}<br/>
    <span class="k">Conv. collective :</span> IDCC {ent['idcc']} - {ent['convention_collective']}<br/>
    <span class="k">Licence spec. :</span> {ent['licence_spectacle']}
  </td>
</tr></table>

<p class="sub"><b>P&eacute;riode :</b> du {jj_mm_aaaa(e.debut_periode)} au {jj_mm_aaaa(e.fin_periode)}{contrat_long}
   &nbsp;&mdash;&nbsp; <b>Dates travaill&eacute;es :</b> {dates}</p>

<table class="cot">
 <tr><th class="l" width="40%">LIBELLE</th><th width="12%">Base</th>
     <th colspan="2">Part Employeur</th><th colspan="2">Part Salari&eacute;</th></tr>
 <tr><th class="l"></th><th></th><th width="10%">Taux</th><th width="12%">Montant</th>
     <th width="10%">Taux</th><th width="12%">Montant</th></tr>
 {brut_lignes}
 {''.join(lignes)}
 <tr class="tot"><td colspan="3">Total des cotisations et contributions</td>
     <td class="r">{fmt_eur(p.total_pat)}</td><td></td><td class="r">{fmt_eur(p.total_sal)}</td></tr>
 <tr class="net"><td colspan="5">NET SOCIAL / NET A PAYER AVANT IMP&Ocirc;T</td>
     <td class="r">{fmt_eur(p.net_a_payer)}</td></tr>
 <tr><td colspan="5">Net imposable</td><td class="r">{fmt_eur(p.net_imposable)}</td></tr>
 <tr><td colspan="5">Imp&ocirc;t sur le revenu pr&eacute;lev&eacute; &agrave; la source
     (taux {fmt_taux(s.get('taux_pas', 0))} %)</td><td class="r">0,00</td></tr>
</table>

{bloc_cumul}

<p class="pied">
  Co&ucirc;t total employeur : {fmt_eur(p.cout_employeur)} &euro; &nbsp;|&nbsp;
  Plafond Urssaf de la p&eacute;riode : {fmt_eur(_plafond.pour_paie(p))} &euro;
  &nbsp;|&nbsp; SMIC retenu pour la r&eacute;duction g&eacute;n&eacute;rale :
  {fmt_eur(p.plafond)} &euro; ({p.heures} h &agrave; {fmt_eur(p.smic)}) &nbsp;|&nbsp;
  R&egrave;glement le {jj_mm_aaaa(e.date_paiement or e.fin_periode)} par virement.<br/>
  Contrat n&deg; {e.numero or '-'} &mdash; CDD d'usage, convention collective
  IDCC {ent['idcc']}. Conservez ce bulletin sans limitation de dur&eacute;e.
</p>
"""


IDENTITE = GABARITS / "identite"


LOGO_SVG = IDENTITE / "logo.svg"

# Emplacement du logo sur la page, en points PDF (A4 = 595 x 842).
LOGO_LARGEUR = 74
LOGO_MARGE_DROITE = 34
LOGO_MARGE_HAUT = 28


def _poser_logo(chemin: Path) -> None:
    """Incruste le logo EN VECTORIEL sur chaque page, apres le rendu du texte.

    Le SVG est converti en PDF par MuPDF -- une page PDF, donc des courbes, pas
    des pixels -- puis projetee sur chaque page. Le trait reste net a n'importe
    quel zoom et a l'impression, et le fichier ne grossit presque pas : le
    dessin n'est stocke qu'une fois et referencie par les autres pages.

    Le detour par une image matricielle avait produit un PDF de 13 Mo pour six
    bulletins, et un logo qui piquait a l'agrandissement. On ne rasterise pas.
    """
    if not LOGO_SVG.exists():
        return
    svg = pymupdf.open(str(LOGO_SVG))
    logo_pdf = pymupdf.open("pdf", svg.convert_to_pdf())
    svg.close()
    proportion = logo_pdf[0].rect.height / logo_pdf[0].rect.width
    doc = pymupdf.open(str(chemin))
    for page in doc:
        x1 = page.rect.width - LOGO_MARGE_DROITE
        cadre = pymupdf.Rect(x1 - LOGO_LARGEUR, LOGO_MARGE_HAUT, x1,
                             LOGO_MARGE_HAUT + LOGO_LARGEUR * proportion)
        page.show_pdf_page(cadre, logo_pdf, 0)
    doc.saveIncr()
    doc.close()
    logo_pdf.close()


def ecrire(paies: list, ent: dict, chemin, ctx=None, mois: str = None) -> Path:
    """Ecrit un PDF contenant un bulletin par page.

    `ctx` et `mois` sont facultatifs : sans eux le bloc de cumul est omis
    plutot que devine.
    """
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    mediabox = pymupdf.paper_rect("A4")
    zone = mediabox + (34, 34, -34, -34)
    writer = pymupdf.DocumentWriter(str(chemin))
    colonnes_par_salarie = {}
    if ctx is not None and mois:
        from . import cumul
        # Tout ce que la compagnie a declare, ce mois-ci compris : les paies
        # qu'on imprime remplacent le fichier de leur mois (cumul.py).
        engagements = cumul.lire_engagements(ctx, paies_courantes=paies)
        for pa in paies:
            cle = pa.salarie["_cle"]
            if cle not in colonnes_par_salarie:
                colonnes_par_salarie[cle] = cumul.tableau_cumul(
                    ctx, cle, mois, engagements)
    for p in paies:
        if p.engagement.sans_paie:
            # Un mois du contrat sans cachet : rien n'est paye, pas de bulletin.
            continue
        cols = colonnes_par_salarie.get(p.salarie["_cle"])
        story = pymupdf.Story(html=_html_un(p, ent, cols), user_css=CSS)
        more = 1
        while more:
            dev = writer.begin_page(mediabox)
            more, _ = story.place(zone)
            story.draw(dev)
            writer.end_page()
    writer.close()
    _poser_logo(chemin)
    return chemin
