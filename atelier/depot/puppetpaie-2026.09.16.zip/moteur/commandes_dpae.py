"""Commande `deposer-dpae` : le seul endroit du moteur qui envoie une declaration.

Separee de `cli.py` pour la meme raison que `commandes_retours.py` : on veut
voir d'un coup d'oeil tout ce qui sort de la machine. La difference avec les
retours est de nature -- lire est reversible, deposer ne l'est pas.

Les garde-fous, poses avant d'ecrire la moindre ligne de reseau :

- **essai a blanc par defaut.** Sans `--reel`, la commande fait tout sauf le
  POST : elle relit le fichier, affiche chaque personne declaree, verifie les
  delais, et s'arrete.
- **confirmation explicite du mois.** `--reel` exige `--confirmer AAAA-MM`, et
  le mois doit etre celui des embauches contenues dans le fichier. On ne
  depose pas « le dernier fichier produit » : on depose un mois nomme.
- **jamais enchainee.** Ni `mois` ni `dpae` n'appellent cette commande.
  Produire et deposer sont deux gestes, deux moments, deux decisions.
- **relecture avant envoi.** Ce qui part est relu depuis le disque et affiche
  en clair. Le fichier n'est pas reconstruit a la volee.
- **archivage.** La reponse du SI DPAE est ecrite dans `retours/` avant tout
  commentaire, comme piece justificative.
"""
from __future__ import annotations
import datetime as _dt
from pathlib import Path

from .util import d, jj_mm_aaaa


_SANS_MOTDEPASSE = """
Le mot de passe URSSAF n'est pas dans l'environnement.

Attention : ce n'est PAS le mot de passe net-entreprises de la DSN. La DPAE
passe par un compte Urssaf distinct -- CoolPaie les tient dans deux panneaux
separes, avec deux mots de passe differents.

Le moteur ne le stocke jamais. Il le lit dans la variable %s,
le temps de la commande, et ne l'ecrit nulle part.

  Le plus simple : double-cliquer sur « Depot DPAE.cmd », qui ouvre une
  fenetre ou le taper.

  Sinon, PowerShell, pour cette fenetre seulement :
      $env:%s = (Read-Host "mot de passe Urssaf")
      python -m moteur %s ...
"""

_PISTES_401 = """
Ne pas enchainer les essais : au-dela de quelques tentatives, l'Urssaf bloque
le compte. Les causes, dans l'ordre :

  1. LE COMPTE. C'est le mot de passe URSSAF qu'il faut, pas celui de
     net-entreprises. Dans CoolPaie, panneau DUE et non panneau DSN.
  2. La casse du mot de passe. Le moteur l'envoie tel qu'il est tape, ce qui
     est ce qui marche ici ; `--majuscules` force la casse haute.
  3. Le code service, dans config/entreprise.json, cle `api_dpae.service`.
     Il doit valoir 25 pour un declarant (98 pour un concentrateur). Sans lui,
     l'authentification repond 404 : c'etait la cause du blocage du 04/09/2026.

Un 404 ici ne veut pas dire « page introuvable » : dans cette API, c'est
« service ou identifiant inconnu ». Le service repond, il ne reconnait pas ce
qu'on lui donne.
"""


def _mois_du_fichier(enregistrements: list) -> set:
    """Mois d'embauche presents dans le fichier, format AAAA-MM."""
    mois = set()
    for e in enregistrements:
        j = e["date_embauche"]
        if len(j) == 8 and j.isdigit():
            mois.add("%s-%s" % (j[4:], j[2:4]))
    return mois


def cmd_tester_dpae(ctx, args) -> int:
    """Ouvre une session et s'arrete la. Rien n'est declare.

    C'est le « bouton de test des connexions MtoM DUE » de CoolPaie
    (journal de version 4.0.0.8.273) : il verifie les identifiants, pas la
    declaration. C'est la seule facon de savoir si le compte passe, sans rien
    envoyer -- et donc la premiere chose a faire.
    """
    from . import coffre, dpae_api
    from .dpae_api import VARIABLE_MOTDEPASSE_DPAE as VARIABLE_MOTDEPASSE
    from .netentreprises import ErreurApi

    # Tester la connexion ne declare rien : c'est une consultation, et le
    # coffre suffit. C'est meme la premiere chose qu'on veut pouvoir faire
    # sans ceremonie quand on doute du compte.
    mdp = coffre.lire(ctx, coffre.URSSAF, usage=coffre.CONSULTATION)
    if not mdp:
        print(_SANS_MOTDEPASSE % (VARIABLE_MOTDEPASSE, VARIABLE_MOTDEPASSE,
                                  "tester-dpae"))
        return 2

    client = dpae_api.ClientDpae(ctx, majuscules=args.majuscules, motdepasse=mdp)
    soucis = client.verifier_identifiants()
    for s in soucis:
        print("  ! %s" % s)
    if soucis:
        print("\nCes points font echouer la connexion MtoM. Rien n'est tente.")
        return 2

    print("Test de la connexion DUE MtoM (%s)" % dpae_api.ADRESSES_DPAE["authentification"])
    print("  declarant : SIRET %s, %s %s" % (client.declarant.get("siret"),
                                             client.declarant.get("nom"),
                                             client.declarant.get("prenom")))
    print("  mot de passe envoye %s"
          % ("force en MAJUSCULES (--majuscules)" if client.majuscules
             else "tel qu'il a ete tape"))
    try:
        client.authentifier()
    except ErreurApi as e:
        print("\nConnexion refusee. Aucune declaration n'a ete envoyee.\n%s" % e)
        print(_PISTES_401)
        return 1
    print("\nConnexion acceptee%s."
          % (" (session valide jusqu'a %s)" % client.expire_le
             if client.expire_le else ""))
    print("Le compte passe : le depot peut se faire d'ici.")
    return 0


def cmd_deposer_dpae(ctx, args) -> int:
    from . import dpae, dpae_api
    from .dpae_api import VARIABLE_MOTDEPASSE_DPAE as VARIABLE_MOTDEPASSE
    from .netentreprises import ErreurApi

    from .contexte import resoudre
    chemin = resoudre(args.fichier, ctx.racine)
    if not chemin.exists():
        print("Fichier introuvable : %s" % chemin)
        print("Le produire d'abord :  python -m moteur dpae paies/AAAA-MM.json")
        return 1
    if chemin.suffix.lower() == ".zip":
        print("Le SI DPAE refuse les archives : deposer le .txt, pas le .zip.")
        return 1

    contenu = chemin.read_bytes()
    if not contenu or len(contenu) % dpae.LONGUEUR:
        print("Ce fichier ne fait pas un multiple de %d octets : ce n'est pas un\n"
              "flux DPAE a plat. Rien n'est envoye." % dpae.LONGUEUR)
        return 1
    enregistrements = dpae.relire(chemin)

    # ------------------------------------------------------------- relecture
    print("\n%s -- %d declaration(s), %d octets\n%s"
          % (chemin.name, len(enregistrements), len(contenu), "-" * 66))
    aujourdhui = _dt.date.today()
    hors_delai, trop_tot = [], []
    for e in enregistrements:
        deb = d("%s-%s-%s" % (e["date_embauche"][4:], e["date_embauche"][2:4],
                              e["date_embauche"][:2]))
        reste = (deb - aujourdhui).days
        if reste < 0:
            etat, _ = "EMBAUCHE PASSEE - hors delai", hors_delai.append(e)
        elif reste > 8:
            etat, _ = "dans %d jours - trop tot pour declarer" % reste, trop_tot.append(e)
        else:
            etat = "dans %d jour(s)" % reste if reste else "aujourd'hui"
        print("  %-22s %-12s ne(e) le %s   embauche le %s a %sh%s   %s"
              % (e["nom"].strip(), e["prenom"].strip(),
                 jj_mm_aaaa(d("%s-%s-%s" % (e["date_naissance"][4:],
                                            e["date_naissance"][2:4],
                                            e["date_naissance"][:2]))),
                 jj_mm_aaaa(deb), e["heure_embauche"][:2], e["heure_embauche"][2:],
                 etat))
    print("-" * 66)

    # --------------------------------------------------------------- controles
    ind = dpae_api.indicateur(contenu)
    if not dpae_api.est_reel(contenu):
        print("""
ARRET - champ C_VERSION %r en position %d-%d, attendu %r.

Le fichier produit par le moteur porte toujours %r. Un flux dont on ignore
s'il sera traite comme un test ou comme une declaration ne part pas d'ici.
Pour un depot de test, ne pas bricoler le fichier : utiliser --test, qui
bascule C_VERSION en %r en memoire, au moment de l'envoi.
""" % (ind, dpae_api.INDICATEUR[0], dpae_api.INDICATEUR[1],
       dpae_api.INDICATEUR_REEL, dpae_api.INDICATEUR_REEL,
       dpae_api.INDICATEUR_TEST))
        return 2

    if args.test and args.reel:
        print("\nARRET - --test et --reel s'excluent. Choisir l'un des deux.")
        return 2

    if trop_tot and not args.test:
        print("\nARRET - %d embauche(s) a plus de 8 jours." % len(trop_tot))
        print("La DPAE ne s'envoie que dans les 8 jours qui precedent l'embauche.")
        print("Produire un fichier pour les seules dates proches, et deposer plus")
        print("tard pour les autres.")
        return 2

    mois = _mois_du_fichier(enregistrements)
    if hors_delai:
        print("\n>>> %d embauche(s) deja commencee(s) : la declaration est en retard."
              % len(hors_delai))
        print(">>> La deposer quand meme, telle quelle, sans antidater.")

    # ------------------------------------------------------------ essai a blanc
    if not args.reel and not args.test:
        print("""
ESSAI A BLANC - rien n'a ete envoye.

Ce qui partirait :
  %d declaration(s), %d octets, gzip
  POST %s
  authentification %s

Pour un depot de TEST (rien n'est declare, C_VERSION bascule en %s) :
  python -m moteur deposer-dpae %s --test

Pour deposer pour de vrai :
  python -m moteur deposer-dpae %s --reel --confirmer %s
""" % (len(enregistrements), len(contenu), dpae_api.ADRESSES_DPAE["depot"],
       dpae_api.ADRESSES_DPAE["authentification"], dpae_api.INDICATEUR_TEST,
       args.fichier, args.fichier, sorted(mois)[0] if mois else "AAAA-MM"))
        return 0

    # ---------------------------------------------------------- confirmation
    if args.reel:
        if not args.confirmer:
            print("\nARRET - `--reel` exige `--confirmer AAAA-MM`.")
            print("Le mois attendu pour ce fichier : %s" % ", ".join(sorted(mois)))
            return 2
        if args.confirmer not in mois:
            print("\nARRET - mois confirme (%s) different des embauches du fichier (%s)."
                  % (args.confirmer, ", ".join(sorted(mois))))
            return 2

    # LE DEPOT LUI-MEME EST DANS `operations`, ET LES DEUX FACES Y PASSENT.
    # Le mot de passe de l'Urssaf, la bascule en test, l'ecriture au journal
    # des depots : tout cela vit la-bas. Ici on affiche, avant et apres.
    from . import operations as ops

    if args.test:
        print("""
DEPOT DE TEST - C_VERSION bascule de %s en %s sur les %d enregistrement(s).

Le service de production accepte les depots de test : la FAQ de l'Urssaf le
prevoit explicitement. Rien ne sera declare, et les retours porteront la
mention de test. Le fichier sur le disque n'est pas modifie.
""" % (dpae_api.INDICATEUR_REEL, dpae_api.INDICATEUR_TEST, len(enregistrements)))

    quoi = "TEST" if args.test else args.confirmer
    print("\nDepot de %d declaration(s) -- %s..." % (len(enregistrements), quoi))
    try:
        fait = ops.deposer_dpae(
            ctx, chemin, reel=bool(args.reel),
            preuve=ops.Preuve(mois_recopie=args.confirmer),
            qui="ligne de commande", majuscules=args.majuscules)
    except ops.PreuveInsuffisante as e:
        print("\nRefus : %s" % e)
        return 2
    except ops.SeanceFermee as e:
        print("\n%s" % e)
        return 2
    except ops.ErreurOperation as e:
        print("\n%s" % e)
        return 2
    except ErreurApi as e:
        print("\nLe depot a echoue.\n%s" % e)
        if not args.test:
            print("\nRien ne garantit qu'il n'a pas ete pris en compte : verifier le")
            print("tableau de bord DPAE avant de recommencer, pour ne pas declarer")
            print("deux fois les memes embauches.")
        return 1

    if fait.deja:
        print("\nA SAVOIR : ce fichier exact avait deja ete depose le %s."
              % fait.deja.get("quand", "?"))
    print("\nDepot %s accepte par le SI DPAE."
          % ("DE TEST" if args.test else "REEL"))
    print("Reponse archivee : %s" % fait.trace)
    print("\n%s" % (fait.reponse or "")[:2000])
    if args.test:
        print("""
C'etait un TEST : rien n'a ete declare, aucune embauche n'est enregistree.
La chaine complete est validee -- authentification, depot, reponse.
""")
    else:
        print("""
Ensuite : les retours (accuse, certificat de conformite, bilan
d'identification des salaries) sont publies par l'Urssaf et se consultent sur
le tableau de bord DPAE. Ils ont une retention de 3 mois.

Les embauches deposees sont notees au journal : `python -m moteur dpae
--restantes` dit celles dont aucune trace d'envoi n'existe encore.
""")
    return 0


def enregistrer_commandes(sub) -> None:
    t = sub.add_parser("tester-dpae",
                       help="tester la connexion DUE MtoM Urssaf, sans rien declarer")
    t.add_argument("--majuscules", action="store_true",
                   help="forcer le mot de passe en MAJUSCULES (le defaut est "
                        "de l'envoyer tel qu'il est tape)")
    t.set_defaults(fn=cmd_tester_dpae)

    p = sub.add_parser("deposer-dpae",
                       help="deposer une DPAE deja produite (essai a blanc par defaut)")
    p.add_argument("fichier", help="sorties/AAAA-MM/DPAE_<Mois><Annee>.txt")
    p.add_argument("--test", action="store_true",
                   help="depot de TEST : C_VERSION bascule en TST en memoire, "
                        "rien n'est declare")
    p.add_argument("--reel", action="store_true",
                   help="envoyer pour de vrai ; exige --confirmer")
    p.add_argument("--confirmer", metavar="AAAA-MM",
                   help="mois des embauches, a recopier a la main")
    p.add_argument("--majuscules", action="store_true",
                   help="forcer le mot de passe en MAJUSCULES (le defaut est "
                        "de l'envoyer tel qu'il est tape)")
    p.set_defaults(fn=cmd_deposer_dpae)
