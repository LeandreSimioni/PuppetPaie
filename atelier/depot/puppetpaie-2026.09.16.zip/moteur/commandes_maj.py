"""La version du logiciel et sa mise a jour, en ligne de commande.

    python -m moteur version                  la version, ce qui est pret
    python -m moteur version --controle       le code s'importe-t-il en entier ?
                                              (ce que la mise a jour verifie
                                              avant de declarer une version prete)
    python -m moteur maj                      aller voir le depot, preparer
    python -m moteur maj --appliquer          basculer (PuppetPaie ferme)
    python -m moteur maj --revenir            reprendre la version d'avant
    python -m moteur maj --publier [DOSSIER]  chez l'editeur : poser l'archive

Tout passe par `operations` : le lanceur et l'interface font les memes appels.
"""
from __future__ import annotations

import json

from . import operations as ops, sortie_json as js


def cmd_version(ctx, args) -> int:
    if args.controle:
        from . import maj
        echecs = maj.importer_tout()
        if args.json:
            print(json.dumps(js.enveloppe("version", {"courante": maj.courante(), "echecs": echecs}),
                             ensure_ascii=False, indent=2))
        elif echecs:
            print("Le code ne s'importe pas en entier :")
            for e in echecs:
                print("  ! %s" % e)
        else:
            print("PuppetPaie %s : tout s'importe." % maj.courante())
        return 1 if echecs else 0
    v = ops.version(ctx)
    if args.json:
        print(json.dumps(js.enveloppe("version", v), ensure_ascii=False, indent=2))
        return 0
    print("PuppetPaie %s%s" % (v["courante"], " (poste de l'editeur)" if v["editeur"] else ""))
    print("  depot : %s" % (v["depot"] or "aucun (config/maj.json)"))
    if v["prete"]:
        print("  prete : %s -- s'applique au prochain demarrage, ou `maj --appliquer`" % v["prete"])
    if v["avant"]:
        print("  avant : %s dans .avant/ -- `maj --revenir` pour y retourner" % v["avant"])
    return 0


def cmd_maj(ctx, args) -> int:
    try:
        if args.publier is not None:
            r = ops.publier_maj(ctx, depot=args.publier or None, notes=args.notes or "",
                                calcul=args.calcul or "")
            if args.json:
                print(json.dumps(js.enveloppe("maj", r), ensure_ascii=False, indent=2))
            else:
                print("Publiee : %s (%s, %d Ko) dans %s" % (
                    r["version"], r["archive"], r["octets"] // 1024, r["dossier"]))
                if r["calcul"]:
                    print("  note calcul : %s" % r["calcul"])
            return 0
        if args.appliquer:
            r = ops.appliquer_maj(ctx, forcer=args.forcer)
            if args.json:
                print(json.dumps(js.enveloppe("maj", r), ensure_ascii=False, indent=2))
            else:
                print("Version %s en place ; la precedente est dans %s" % (r["version"], r["avant"]))
            return 0
        if args.revenir:
            r = ops.revenir_maj(ctx, forcer=args.forcer)
            if args.json:
                print(json.dumps(js.enveloppe("maj", r), ensure_ascii=False, indent=2))
            else:
                print("Retour a la version %s" % r["version"])
            return 0
    except ops.ErreurOperation as e:
        if args.json:
            print(json.dumps(js.erreur("maj", e), ensure_ascii=False, indent=2))
        else:
            print("! %s" % e)
        return 2
    m = ops.verifier_maj(ctx, telecharger=not args.sans_telecharger)
    if args.json:
        print(json.dumps(js.enveloppe("maj", {
            "courante": m.courante, "derniere": m.derniere, "prete": m.prete,
            "message": m.message, "detail": m.detail,
            "telechargee_maintenant": m.telechargee_maintenant}), ensure_ascii=False, indent=2))
        return 0
    print(m.message)
    if m.detail:
        print("  %s" % m.detail)
    if m.telechargee_maintenant:
        print("  telechargee, controlee, prete : `python -m moteur maj --appliquer` "
              "(PuppetPaie ferme), ou au prochain demarrage.")
    return 0


def enregistrer_commandes(sub) -> None:
    v = sub.add_parser("version", help="la version du logiciel, et ce qui est pret")
    v.add_argument("--controle", action="store_true",
                   help="importer tout le code et rendre 0 si tout passe")
    v.set_defaults(fn=cmd_version)

    m = sub.add_parser("maj", help="mise a jour : chercher, appliquer, revenir, publier")
    m.add_argument("--appliquer", action="store_true", help="basculer sur la version prete")
    m.add_argument("--revenir", action="store_true", help="reprendre la version d'avant")
    m.add_argument("--forcer", action="store_true",
                   help="meme si l'interface semble tourner (a eviter)")
    m.add_argument("--sans-telecharger", action="store_true",
                   help="dire s'il y a du nouveau, sans le prendre")
    m.add_argument("--publier", nargs="?", const="", metavar="DOSSIER",
                   help="chez l'editeur : poser l'archive et derniere.json dans le depot")
    m.add_argument("--notes", help="avec --publier : ce que la version apporte")
    m.add_argument("--calcul", help="avec --publier : la phrase montree une fois si un CALCUL change")
    m.set_defaults(fn=cmd_maj)
