"""Les sources des donnees livrees avec le logiciel, et leur veille.

`sources.json` dit, pour chaque texte dont derive un fichier de donnees
(nomenclature des emplois, catalogue des metiers, minima), ce qu'il contient,
de quand il date, quand on l'a releve, ou en est la copie et quel est son
condensat. Ce module le lit et sait retourner voir si la source en ligne a
bouge.

Le principe : une donnee ne se recopie pas d'un editeur, elle se lit dans le
texte qui fait foi ; la copie est gardee sur disque (reference/sources/, hors
depot public) pour qu'on puisse toujours montrer d'ou vient un nombre ; et
quand le condensat en ligne ne colle plus, c'est le signal de RELIRE -- pas
de remplacer le fichier a l'aveugle, puisque les donnees derivees ont ete
ecrites a la main depuis la lecture.

Legifrance refuse les telechargements automatiques : ces sources-la sont en
verification << manuelle >> -- la copie ne se reverifie pas en ligne. Mais
quand la source porte un bloc `kali` (IDCC, conteneur, texte), on lit les
livraisons open data KALI de la DILA depuis le releve (`kali.py`) : elles
disent si la convention ou le texte ont bouge, et la commande dit quelle page
ouvrir.
"""
from __future__ import annotations

import hashlib
import json
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Optional

MANIFESTE = Path(__file__).parent / "sources.json"
DOSSIER = ("reference", "sources")
AGENT = "PuppetPaie (veille des sources ; +https://github.com/puppetpaie)"


def manifeste() -> dict:
    return json.loads(MANIFESTE.read_text(encoding="utf-8"))


def dossier(ctx) -> Path:
    return Path(ctx.racine).joinpath(*DOSSIER)


@dataclass
class EtatSource:
    ident: str
    titre: str
    editeur: str
    url: str
    contenu: str
    version: Optional[str]
    releve_le: Optional[str]
    verification: str
    nourrit: list
    fichier: str
    copie_presente: bool
    copie_conforme: Optional[bool]      # la copie sur disque a le sha du manifeste
    # Apres `--verifier` seulement :
    en_ligne: Optional[str] = None      # inchangee / changee / injoignable / manuelle
    detail: str = ""
    page_de_veille: Optional[str] = None
    age_jours: Optional[int] = None
    extra: dict = field(default_factory=dict)
    kali: Optional[dict] = None         # {idcc, conteneur, texte} : veille par la DILA
    evenements: list = field(default_factory=list)   # ce que KALI a livre depuis le releve


def etats(ctx) -> list:
    """Ce que le manifeste dit, confronte au disque -- sans reseau."""
    m = manifeste()
    d = dossier(ctx)
    out = []
    for ident, s in m["sources"].items():
        p = d / s["fichier"]
        presente = p.exists()
        conforme = None
        if presente:
            conforme = hashlib.sha256(p.read_bytes()).hexdigest() == s["sha256"]
        age = None
        if s.get("releve_le"):
            age = (date.today() - date.fromisoformat(s["releve_le"])).days
        out.append(EtatSource(
            ident=ident, titre=s["titre"], editeur=s["editeur"], url=s["url"],
            contenu=s["contenu"], version=s.get("version"),
            releve_le=s.get("releve_le"), verification=s["verification"],
            nourrit=list(s.get("nourrit", [])), fichier=s["fichier"],
            copie_presente=presente, copie_conforme=conforme,
            page_de_veille=s.get("page_de_veille"), age_jours=age,
            extra={k: s[k] for k in ("en_vigueur", "etendu_le", "verification_comment")
                   if k in s},
            kali=s.get("kali")))
    return out


def _telecharger(url: str, delai: int = 30) -> tuple:
    req = urllib.request.Request(url, headers={"User-Agent": AGENT})
    with urllib.request.urlopen(req, timeout=delai) as r:
        return r.read(), r.headers.get("Last-Modified")


def verifier(ctx, seulement: Optional[list] = None, relever: bool = False) -> list:
    """Retourne voir chaque source en ligne.

    Pour une source << telechargement >> : on la reprend, on compare le
    condensat a celui du manifeste. `inchangee` : rien a faire. `changee` :
    la source a bouge, il faut la RELIRE et mettre a jour les donnees qu'elle
    nourrit ; avec `relever=True` la nouvelle version est posee a cote de
    l'ancienne, suffixee de la date, jamais par-dessus. `injoignable` : pas de
    reseau, ou le lien a change -- ce qui est aussi une information.

    Pour une source << manuelle >> : on rend la page a ouvrir. On ne cache pas
    qu'on ne sait pas la verifier. Si elle porte un bloc `kali`, on lit ce que
    la DILA a livre depuis le releve : `inchangee` quand rien ne touche la
    convention, `changee` quand sa fiche a ete relivree ou qu'un de ses
    textes a bouge -- avec la liste, pour que la relecture sache ou aller.
    """
    out = []
    d = dossier(ctx)
    liste = [e for e in etats(ctx) if not seulement or e.ident in seulement]
    kali_etat = _veiller_kali(d, [e for e in liste if e.kali], relever)
    for e in liste:
        if e.verification != "telechargement":
            e.en_ligne = "manuelle"
            e.detail = e.extra.get("verification_comment", "")
            if e.kali:
                _etat_kali(e, kali_etat)
            out.append(e)
            continue
        try:
            octets, modifie = _telecharger(e.url)
        except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError) as exc:
            e.en_ligne = "injoignable"
            e.detail = str(exc)
            out.append(e)
            continue
        sha = hashlib.sha256(octets).hexdigest()
        attendu = manifeste()["sources"][e.ident]["sha256"]
        if sha == attendu:
            e.en_ligne = "inchangee"
            e.detail = "Last-Modified : %s" % (modifie or "non donne")
        else:
            e.en_ligne = "changee"
            e.detail = ("le fichier en ligne n'est plus celui qui a ete lu "
                        "(Last-Modified : %s). Relire, puis mettre a jour : %s"
                        % (modifie or "non donne", ", ".join(e.nourrit) or "rien"))
            if relever:
                p = d / e.fichier
                neuf = p.with_name("%s.%s%s" % (p.stem, date.today().isoformat(), p.suffix))
                d.mkdir(parents=True, exist_ok=True)
                neuf.write_bytes(octets)
                e.detail += ". Copie posee : %s" % neuf.name
        out.append(e)
    return out


# ------------------------------------------------------------- la veille KALI
# Ce qui, dans le titre d'un texte KALI, fait qu'on le classe << salaires >>.
# C'est un tri d'affichage, pas une regle de droit : les autres mouvements
# sont montres aussi, en second, avec leur titre, pour que l'oeil tranche.
MOTS_SALAIRES = ("salaire", "minim", "remuneration", "rémunération",
                 "nao", "cachet", "grille", "barème", "bareme")


def _parle_salaires(titre: str) -> bool:
    t = (titre or "").lower()
    return any(m in t for m in MOTS_SALAIRES)


def _veiller_kali(d: Path, sources_kali: list, relever: bool):
    """Une seule lecture des livraisons pour toutes les sources qui en ont
    besoin, depuis le releve le plus ancien ; chaque source filtre ensuite
    sur le sien. Rend le rapport de `kali.veiller`, ou l'exception."""
    if not sources_kali:
        return None
    from . import kali
    suivis = {}
    for e in sources_kali:
        c = suivis.setdefault(e.kali["conteneur"], {"idcc": e.kali["idcc"], "textes": []})
        c["textes"].append(e.kali["texte"])
    depuis = min(e.releve_le for e in sources_kali if e.releve_le)
    try:
        return kali.veiller(d, suivis, depuis, AGENT, relever=relever)
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError) as exc:
        return exc


def _etat_kali(e: EtatSource, rapport) -> None:
    """Traduit le rapport en etat de CETTE source : ses evenements sont ceux
    de sa convention, posterieurs a son propre releve."""
    if isinstance(rapport, Exception):
        e.en_ligne = "injoignable"
        e.detail = "livraisons KALI (DILA) : %s" % rapport
        return
    depuis = e.releve_le or ""
    evts = [x for x in rapport["evenements"].get(e.kali["conteneur"], [])
            if x["livraison"] > depuis]
    e.evenements = evts
    lues = [j for j in rapport["livraisons_lues"] if j > depuis]
    ou = "IDCC %s, %d livraison(s) KALI lue(s) depuis le %s" % (
        e.kali["idcc"], len(lues), depuis)
    forts, faibles = [], []
    for x in evts:
        if x["genre"] == "convention":
            nouveaux = x.get("nouveaux") or {}
            sal = {k: v for k, v in nouveaux.items() if _parle_salaires(v)}
            if sal:
                forts.append("%s : texte(s) nouveau(x) attache(s) a la convention -- %s"
                             % (x["livraison"], " ; ".join(sorted(sal.values()))))
            autres = [v for k, v in nouveaux.items() if k not in sal]
            if autres:
                faibles.append("%s : %d texte(s) nouveau(x) -- %s"
                               % (x["livraison"], len(autres), " ; ".join(sorted(autres))))
            if x.get("premiere"):
                faibles.append("%s : %s" % (x["livraison"], x["titre"]))
        else:
            ligne = "%s : texte %s modifie -- %s (du %s, etat %s%s)" % (
                x["livraison"], x["ident"], x["titre"], x["date_texte"] or "?",
                x["etat"] or "?", ", " + x["extension"] if x.get("extension") else "")
            if x["ident"] == e.kali["texte"] or _parle_salaires(x["titre"]):
                forts.append(ligne)
            else:
                faibles.append(ligne)
    if forts:
        e.en_ligne = "changee"
        e.detail = ("%s : un texte SALAIRES a bouge. %s. Relire, puis mettre a jour : %s"
                    % (ou, " | ".join(forts), ", ".join(e.nourrit) or "rien"))
        if faibles:
            e.detail += ". Autres mouvements : %s" % " | ".join(faibles)
    elif faibles:
        e.en_ligne = "inchangee"
        e.detail = ("%s : la convention a bouge, mais rien qui parle de salaires d'apres "
                    "les titres -- %s" % (ou, " | ".join(faibles)))
    else:
        e.en_ligne = "inchangee"
        e.detail = "%s : rien ne touche la convention" % ou
    am = rapport.get("amorces", {}).get(e.kali["conteneur"])
    e.detail += (" (liste de reference : %d textes, fiche du %s)" % (am["textes"], am["livraison"])
                 if am else " (ATTENTION : aucune fiche de la convention trouvee dans "
                 "l'index, seul le texte cite par le manifeste est suivi)")
    if rapport.get("trou"):
        e.detail += ". ATTENTION, %s" % rapport["trou"]
