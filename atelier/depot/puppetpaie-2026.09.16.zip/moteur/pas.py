"""Prelevement a la source : le taux et son identifiant, tels que la DGFiP les donne.

Trois rubriques de la DSN en dependent, dans le bloc Versement individu :

    S21.G00.50.006  taux de prelevement a la source
    S21.G00.50.007  type de taux (01 = transmis par la DGFiP, 13 = bareme...)
    S21.G00.50.008  identifiant du taux, "porte par le CRM PAS transmis par la
                    DGFIP" (cahier technique 2026.1, p. 244)

Aucune des trois ne se calcule. Elles se LISENT, dans le compte-rendu metier
DGFiP de nature 94 (« CR donnees nominatives (Taux du PAS) »), que le SI DSN
met a disposition apres chaque depot. Voir moteur/retours.py.

Le moteur a longtemps fabrique .008 comme une suite croissante. Le depouillement
des 56 DSN deposees depuis 2021 montre que c'est faux dans sa structure meme :

  - l'identifiant est attache au SALARIE, pas au depot ni au flux ;
  - il reste stable plusieurs mois, puis change quand un nouveau CRM arrive ;
  - deux salaries d'une meme DSN peuvent porter deux identifiants differents
    (avril et mai 2026 : SIMIONI 423640633, PUPPIS 428811523), parce que l'un
    n'avait pas ete declare le mois precedent et n'a donc pas eu de CRM neuf.

D'ou ce magasin : un etat courant par salarie, alimente par la lecture des
retours, et un journal de ce qui a ete recu. Sans entree, le moteur refuse de
produire la DSN plutot que d'inventer un identifiant - meme doctrine que le
montant URSSAF.
"""
from __future__ import annotations
import datetime as _dt
import json
from pathlib import Path

FICHIER = "pas.json"

# Types de taux, cahier technique 2026.1 rubrique S21.G00.50.007
TYPES = {
    "01": "Taux transmis par la DGFIP",
    "13": "Bareme mensuel metropole",
    "17": "Bareme mathematique sur base mensuelle metropole",
    "23": "Bareme mensuel Guadeloupe, Reunion et Martinique",
    "27": "Bareme mathematique sur base mensuelle Guadeloupe, Reunion, Martinique",
    "33": "Bareme mensuel Guyane et Mayotte",
    "37": "Bareme mathematique sur base mensuelle Guyane et Mayotte",
    "99": "Indu relatif a un exercice anterieur - pas de taux de PAS",
}


class PasInconnu(Exception):
    """Aucun taux de PAS connu pour ce salarie : il faut lire les retours."""


def _chemin(ctx) -> Path:
    return ctx.racine / "config" / FICHIER


def charger(ctx) -> dict:
    p = _chemin(ctx)
    if not p.exists():
        return {"salaries": {}, "journal": []}
    d = json.loads(p.read_text(encoding="utf-8"))
    d.setdefault("salaries", {})
    d.setdefault("journal", [])
    return d


def ecrire(ctx, data: dict) -> None:
    _chemin(ctx).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ------------------------------------------------------------------ lecture
def etat(ctx, cle_salarie: str) -> dict:
    """Taux de PAS courant d'un salarie.

    Leve PasInconnu plutot que de renvoyer une valeur par defaut : un
    identifiant invente part dans une declaration fiscale nominative.
    """
    e = charger(ctx)["salaries"].get(cle_salarie)
    if not e:
        raise PasInconnu(
            "Aucun taux de prelevement a la source connu pour %s.\n"
            "Il vient du compte-rendu metier DGFiP (retour de nature 94), pas\n"
            "d'un calcul. Le recuperer avec :\n"
            "    python -m moteur retours\n"
            "ou, a defaut, amorcer le magasin depuis les DSN deja deposees :\n"
            "    python -m moteur pas --amorcer" % cle_salarie)
    return e


def rubriques(ctx, cle_salarie: str) -> tuple[str, str, str]:
    """Renvoie (taux, type, identifiant) prets pour S21.G00.50.006/.007/.008."""
    e = etat(ctx, cle_salarie)
    return e["taux"], e["type"], e["identifiant"]


def connu(ctx, cle_salarie: str) -> bool:
    return cle_salarie in charger(ctx)["salaries"]


# ------------------------------------------------------------------ ecriture
def enregistrer(ctx, releves: list[dict], source: str) -> list[str]:
    """Applique des releves de CRM. Renvoie la liste des changements lisibles.

    Un releve : {"salarie": "PUPPIS", "taux": "0.00", "type": "01",
                 "identifiant": "444207754", "periode": "2026-07"}
    """
    data = charger(ctx)
    changements = []
    horodatage = _dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    for r in releves:
        cle = r["salarie"]
        avant = data["salaries"].get(cle)
        neuf = {
            "taux": r["taux"],
            "type": r["type"],
            "identifiant": r["identifiant"],
            "periode": r.get("periode"),
            "source": source,
            "releve_le": horodatage,
        }
        if avant and all(avant.get(k) == neuf[k]
                         for k in ("taux", "type", "identifiant")):
            continue
        data["salaries"][cle] = neuf
        if avant:
            changements.append(
                "%s : taux %s -> %s, type %s -> %s, identifiant %s -> %s"
                % (cle, avant["taux"], neuf["taux"], avant["type"], neuf["type"],
                   avant["identifiant"], neuf["identifiant"]))
        else:
            changements.append(
                "%s : premier releve - taux %s, type %s, identifiant %s"
                % (cle, neuf["taux"], neuf["type"], neuf["identifiant"]))
        data["journal"].append(dict(neuf, salarie=cle))
    if changements:
        ecrire(ctx, data)
    return changements


# --------------------------------------------------------------- amorcage
def releves_historiques(ctx, dossier_export: Path) -> dict[str, list[dict]]:
    """Depouille les DSN deja deposees : par salarie, l'historique des taux.

    Ce n'est pas un calcul : c'est la lecture de ce qui a reellement ete
    declare. Sert a amorcer le magasin sans attendre le premier CRM, et a
    rejouer l'historique a l'identique.
    """
    par_nir = {s["nir"]: cle for cle, s in ctx.salaries.items()}
    trouve: dict[str, dict[str, dict]] = {}
    for f in sorted(Path(dossier_export).rglob("*.dsn")):
        mois = nir = None
        cur: dict[str, str] = {}
        for ligne in f.read_text(encoding="latin-1", errors="replace").splitlines():
            if "," not in ligne:
                continue
            code, val = ligne.strip().split(",", 1)
            val = val.strip().strip("'")
            if code == "S20.G00.05.005":
                mois = "%s-%s" % (val[4:8], val[2:4])
            elif code == "S21.G00.30.001":
                nir = val
            elif code.startswith("S21.G00.50.00"):
                cur[code] = val
                if code == "S21.G00.50.008":
                    cle = par_nir.get(nir)
                    if cle and mois:
                        trouve.setdefault(cle, {})[mois] = {
                            "taux": cur.get("S21.G00.50.006"),
                            "type": cur.get("S21.G00.50.007"),
                            "identifiant": val,
                            "periode": mois,
                        }
                    cur = {}
    return {cle: [mois_val[m] for m in sorted(mois_val)]
            for cle, mois_val in trouve.items()}


def amorcer(ctx, dossier_export: Path) -> list[str]:
    """Pose l'etat courant a partir de la derniere DSN deposee de chaque salarie."""
    hist = releves_historiques(ctx, dossier_export)
    releves = []
    for cle, entrees in hist.items():
        dernier = entrees[-1]
        releves.append(dict(dernier, salarie=cle))
    return enregistrer(
        ctx, releves,
        "amorcage depuis les DSN deposees (%s)" % Path(dossier_export).name)


def historique_par_mois(ctx, dossier_export: Path) -> dict[tuple[str, str], dict]:
    """(cle_salarie, 'AAAA-MM') -> rubriques declarees ce mois-la.

    Utilise par le rejeu : chaque mois doit se reproduire avec l'identifiant
    qui etait effectivement en vigueur, pas avec l'etat courant.
    """
    out = {}
    for cle, entrees in releves_historiques(ctx, dossier_export).items():
        for e in entrees:
            out[(cle, e["periode"])] = e
    return out
