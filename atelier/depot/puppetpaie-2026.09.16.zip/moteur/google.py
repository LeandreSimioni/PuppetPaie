"""Compte Google : autorisation OAuth, envoi Gmail, depot Drive.

Remplace le mot de passe d'application et le couple SMTP/IMAP. L'application
est declaree chez Google, l'utilisateur voit une vraie fenetre d'autorisation,
et il peut retirer l'acces quand il veut depuis myaccount.google.com. Deux
raisons de faire ce chemin plutot que le SMTP :

* le **Drive** n'a aucun equivalent SMTP. L'archivage des sauvegardes et des
  documents (bulletins, AEM, contrats, certificats) passe forcement par l'API ;
* un mot de passe d'application est un secret complet sur le compte ; ici on
  n'obtient que trois permissions etroites, revocables separement.

LES PERMISSIONS DEMANDEES, ET POURQUOI CELLES-LA
------------------------------------------------
Google classe ses permissions en trois niveaux, et la facture n'est pas la
meme :

    drive.file      non sensible   ecrire dans le Drive, mais seulement les
                                   fichiers crees par cette application --
                                   elle ne voit rien d'autre du Drive
    userinfo.email  non sensible   l'adresse du compte autorise, pour n'avoir
                                   pas a la demander ni risquer un desaccord
    gmail.send      sensible       envoyer un message
    gmail.readonly  RESTREINT      lire la boite -- pour relever les contrats
                                   signes par courriel (voir plus bas)
    gmail.compose   RESTREINT      deposer un brouillon -> audit de securite
                                   CASA obligatoire pour etre verifie

Le mode « brouillon » coute donc plus cher que l'envoi direct, alors qu'il
etait cense etre le mode prudent. Il a ete abandonne le 09/09/2026 : la page de
relecture locale de `envoi.py` joue deja ce role -- on lit les messages, on
ouvre les pieces jointes, on clique.

LA LECTURE DE LA BOITE -- 15/09/2026
------------------------------------
Le salarie signe son contrat d'un clic : le courriel qu'il recoit porte un
bouton « Je signe » qui ouvre une reponse toute ecrite, avec un code unique
dans l'objet. Pour que le logiciel SACHE que la reponse est arrivee sans que
personne ne la cherche dans Gmail, il faut lire la boite -- et la moindre
permission de lecture Gmail est classee « restreinte » par Google. C'est
assume : « s'il faut ajouter des autorisations Gmail pour la lecture, pas de
soucis » (Leandre, 15/09/2026). Ce que ca coute : si le logiciel etait
diffuse un jour, la verification Google passerait par un audit de securite
(CASA) au lieu de la simple verification « sensible ». Tant qu'il n'est pas
verifie, l'ecran « application non verifiee » s'affiche et le projet est
plafonne a 100 comptes -- ce qui etait deja le cas.

Ce que le logiciel lit, et rien d'autre : `operations_documents.
relever_signatures` cherche les messages dont l'OBJET porte un code de
signature en attente, et ne telecharge que ceux-la. Il ne parcourt pas la
boite.

POUR CELUI QUI UTILISE LE LOGICIEL : UNE COMMANDE, RIEN D'AUTRE
---------------------------------------------------------------
    python -m moteur google autoriser

Une fenetre Google s'ouvre, on choisit son compte, on accepte. C'est tout.
Pas de console, pas de projet a creer, pas d'identifiant a recopier : le
logiciel embarque **PuppetPaie**, l'application declaree une fois par la
Compagnia UEUEUE (voir APPLICATION, plus bas). C'est le fonctionnement de tous
les outils du genre -- rclone, gcloud : une application publiee par l'editeur,
que chaque utilisateur autorise sur son propre compte.

L'IDENTIFIANT DE L'APPLICATION N'EST PAS UN SECRET
--------------------------------------------------
Google le dit explicitement pour les applications de bureau : elles ne peuvent
rien garder confidentiel, donc le « client_secret » n'en est pas un. Il ne
donne acces a rien sans l'autorisation explicite d'un utilisateur, sur son
compte, revocable a tout moment. Il peut donc vivre dans le code, y compris
dans un depot public.

Ce qu'il porte, en revanche, c'est **notre quota et notre plafond de 100
comptes** tant que l'application n'est pas verifiee par Google. D'ou la
possibilite, pour qui veut, de mettre la sienne dans `config/google.json` --
c'est une echappatoire, pas le chemin normal.

CE QUE LEANDRE A FAIT UNE FOIS, POUR TOUT LE MONDE
--------------------------------------------------
Ces etapes ne sont a refaire par personne. Elles sont ecrites ici pour que
l'application puisse etre recreee si le projet Google etait perdu.

1. console.cloud.google.com : creer un projet.
2. Activer les API **Gmail** et **Google Drive**.
3. Ecran de consentement OAuth, type « Externe », et surtout le passer
   **« En production »**, pas « Test ». En mode Test, Google revoque le jeton
   de rafraichissement au bout de **7 jours** : il faudrait se reautoriser a
   chaque paie. En production non verifiee, chaque utilisateur voit un ecran
   d'avertissement la premiere fois, et le projet est plafonne a 100 comptes.
4. Identifiants > creer un ID client OAuth de type **Application de bureau**.
5. Recopier l'identifiant et le secret dans APPLICATION, plus bas.

FAIRE DISPARAITRE L'ECRAN « APPLICATION NON VERIFIEE »
------------------------------------------------------
C'est la verification Google. Depuis `gmail.readonly` (15/09/2026), elle
comprend un audit de securite (CASA), payant, en plus de ce qu'exige la
verification « sensible » : un domaine verifie (ueueue.eu, que la compagnie
possede deja), une page de politique de confidentialite dessus, une page
d'accueil decrivant le logiciel, et une video montrant le parcours
d'autorisation. Compter quelques semaines de delai. A faire avant de diffuser
largement, pas avant de faire essayer des amis.

AJOUTER UNE PERMISSION A L'APPLICATION DECLAREE
-----------------------------------------------
Quand PERMISSIONS s'allonge (comme le 15/09/2026 pour la lecture) :

1. console.cloud.google.com > API et services > Ecran de consentement OAuth
   (« Data Access » / « Acces aux donnees ») > Ajouter ou supprimer des
   champs d'application > cocher la permission (ici
   `.../auth/gmail.readonly`) > Mettre a jour > Enregistrer.
2. Sur chaque poste : `python -m moteur google autoriser`, qui redemande le
   consentement avec la liste complete. Un jeton accorde avant l'ajout ne
   porte pas la nouvelle permission -- le fichier de jeton garde la liste
   accordee (`permissions_accordees`), et l'ecran des contrats dit quand il
   faut reautoriser.

LE SECRET SUR DISQUE -- UNE ENTORSE ASSUMEE
-------------------------------------------
Contrairement a NET_ENTREPRISES_MOTDEPASSE, le jeton de rafraichissement doit
survivre entre deux sessions, sinon l'interet disparait. Il est donc ecrit dans
`config/google-jeton.bin`, **chiffre par DPAPI** : Windows le lie au compte
utilisateur courant, un autre compte de la machine ne peut pas le relire, et
copier le fichier ailleurs ne sert a rien. Hors Windows, il est ecrit en clair
avec un avertissement -- il n'y a pas d'equivalent portable en bibliotheque
standard.

Aucune dependance : `urllib` et `ctypes`, comme `netentreprises.py`. Le portage
Rust n'aura donc pas de SDK Google a traduire.
"""
from __future__ import annotations
import base64
import hashlib
import json
import mimetypes
import secrets
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Optional

AUTORISATION = "https://accounts.google.com/o/oauth2/v2/auth"
JETONS = "https://oauth2.googleapis.com/token"
GMAIL_ENVOI = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"
DRIVE_FICHIERS = "https://www.googleapis.com/drive/v3/files"
DRIVE_TELEVERSEMENT = "https://www.googleapis.com/upload/drive/v3/files"

USERINFO = "https://www.googleapis.com/oauth2/v3/userinfo"

GMAIL_MESSAGES = "https://gmail.googleapis.com/gmail/v1/users/me/messages"

LECTURE_GMAIL = "https://www.googleapis.com/auth/gmail.readonly"

PERMISSIONS = [
    "https://www.googleapis.com/auth/gmail.send",
    # Restreinte (voir l'en-tete). Sert a une seule chose : relever les
    # reponses « Je signe » des salaries, par leur code dans l'objet.
    LECTURE_GMAIL,
    "https://www.googleapis.com/auth/drive.file",
    # Non sensible. Elle evite de demander son adresse a l'utilisateur, et
    # surtout de le laisser en saisir une autre que celle qu'il vient
    # d'autoriser -- Gmail refuse un expediteur qui n'est pas le compte.
    "https://www.googleapis.com/auth/userinfo.email",
]

# PuppetPaie, l'application declaree par la Compagnia UEUEUE. La meme pour
# tout le monde : c'est le nom que chaque utilisateur lira dans la fenetre
# d'autorisation Google.
# Ce n'est pas un secret (voir l'en-tete) : c'est une carte de visite, pas une
# cle. Chaque utilisateur autorise son propre compte, et le revoque quand il
# veut sur myaccount.google.com.
APPLICATION = {
    "client_id": "316730526059-rrb8c7q1luvdqm7huvma2g3te757o071"
                 ".apps.googleusercontent.com",
    "client_secret": "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",
}

DOSSIER_DRIVE = "application/vnd.google-apps.folder"

# Au-dela, l'API Gmail veut un televersement en plusieurs morceaux. Nos envois
# font quelques centaines de kilo-octets ; si la limite est atteinte un jour,
# c'est que quelque chose ne va pas -- mieux vaut s'arreter avec un message
# clair qu'un « HTTP 413 » nu.
TAILLE_MAX_MESSAGE = 4_500_000

FICHIER_IDENTIFIANTS = "google.json"
FICHIER_JETON = "google-jeton.bin"


class ErreurGoogle(Exception):
    """Erreur de l'API ou de la configuration, deja traduite en francais."""


# ------------------------------------------------------------------ le disque
def _config(ctx) -> Path:
    return Path(ctx.racine) / "config"


def identifiants(ctx) -> dict:
    """L'application a utiliser : celle du logiciel, sauf override local.

    Le chemin normal ne demande rien a l'utilisateur -- APPLICATION suffit.
    `config/google.json` n'existe que pour qui veut faire tourner le logiciel
    sur sa propre application Google (parce qu'il ne veut pas de la notre, ou
    parce que le plafond de 100 comptes est atteint).
    """
    p = _config(ctx) / FICHIER_IDENTIFIANTS
    if p.exists():
        donnees = json.loads(p.read_text(encoding="utf-8"))
        manque = [c for c in ("client_id", "client_secret") if not donnees.get(c)]
        if manque:
            raise ErreurGoogle("%s incomplet, il manque : %s.\n"
                               "Le supprimer suffit a revenir a l'application "
                               "du logiciel." % (p, ", ".join(manque)))
        return dict(donnees, origine=str(p))
    if not APPLICATION.get("client_id"):
        raise ErreurGoogle(
            "L'application Google du logiciel n'est pas renseignee.\n\n"
            "C'est une chose a faire UNE FOIS, par l'editeur, pas par chaque\n"
            "utilisateur : creer le projet sur console.cloud.google.com et\n"
            "recopier l'identifiant dans APPLICATION, en tete de\n"
            "moteur/google.py. La marche a suivre y est ecrite en entier.\n\n"
            "En attendant, on peut utiliser sa propre application en creant\n"
            "%s :\n\n"
            "  {\n"
            '    "client_id": "....apps.googleusercontent.com",\n'
            '    "client_secret": "...."\n'
            "  }\n" % p)
    return dict(APPLICATION, origine="le logiciel")


def _dpapi(donnees: bytes, sens: str) -> bytes:
    """Chiffre (sens='proteger') ou dechiffre par DPAPI, lie au compte Windows.

    L'appel lui-meme vit dans `coffre.py` depuis le 11/09/2026 : le coffre des
    mots de passe d'organismes utilise exactement le meme mecanisme, et deux
    implementations de DPAPI, c'est une de trop le jour ou l'une se trompe de
    drapeau. Ne reste ici que le message d'erreur, qui parle du jeton Google et
    dit quoi faire.
    """
    from . import coffre
    try:
        return (coffre.proteger(donnees, "moteur de paie - jeton Google")
                if sens == "proteger"
                else coffre.deproteger(donnees, "moteur de paie - jeton Google"))
    except coffre.ErreurCoffre as e:
        raise ErreurGoogle(
            "%s Pour le jeton Google, le remede est : relancer "
            "`python -m moteur google autoriser`." % e) from None


def _ecrire_jeton(ctx, rafraichissement: str, compte: str,
                  permissions: Optional[list] = None) -> Path:
    """Le jeton et l'adresse du compte autorise, dans un seul fichier chiffre.

    L'adresse est rangee la et pas dans une config en clair : elle vient de
    l'autorisation elle-meme, donc elle ne peut pas etre en desaccord avec le
    compte qui enverra les messages.

    `permissions` : celles que Google a REELLEMENT accordees. Elles sont
    gardees pour qu'un jeton d'avant l'ajout d'une permission (la lecture,
    15/09/2026) se reconnaisse sans appel reseau, et que l'ecran dise
    « reautoriser » plutot que d'echouer en 403 au premier releve.
    """
    p = _config(ctx) / FICHIER_JETON
    brut = json.dumps({"rafraichissement": rafraichissement,
                       "compte": compte,
                       "permissions": list(permissions or [])}).encode("utf-8")
    if sys.platform == "win32":
        p.write_bytes(_dpapi(brut, "proteger"))
    else:
        print("Attention : pas de DPAPI hors Windows, le jeton est ecrit en clair.")
        p.write_bytes(brut)
    return p


def _lire_jeton(ctx):
    """{'rafraichissement': ..., 'compte': ...}, ou None."""
    p = _config(ctx) / FICHIER_JETON
    if not p.exists():
        return None
    brut = p.read_bytes()
    if sys.platform == "win32":
        brut = _dpapi(brut, "deproteger")
    return json.loads(brut.decode("utf-8"))


def autorise(ctx) -> bool:
    """Y a-t-il un jeton utilisable, sans rien demander au reseau."""
    try:
        return bool((_lire_jeton(ctx) or {}).get("rafraichissement"))
    except (ErreurGoogle, ValueError):
        return False


def compte_autorise(ctx):
    """L'adresse du compte autorise, sans reseau. None si pas autorise."""
    try:
        return (_lire_jeton(ctx) or {}).get("compte")
    except (ErreurGoogle, ValueError):
        return None


def permissions_accordees(ctx) -> list:
    """Ce que Google a accorde a l'autorisation, tel qu'enregistre.

    Un fichier de jeton d'avant le 15/09/2026 n'a pas de liste : on lui
    prete celles de l'epoque (envoi, Drive, adresse), et surtout PAS la
    lecture, qu'il n'a jamais demandee.
    """
    try:
        j = _lire_jeton(ctx) or {}
    except (ErreurGoogle, ValueError):
        return []
    if not j.get("rafraichissement"):
        return []
    if "permissions" in j:
        return list(j["permissions"])
    return [p for p in PERMISSIONS if p != LECTURE_GMAIL]


def lecture_autorisee(ctx) -> bool:
    """Le jeton porte-t-il la lecture de la boite ? Sans reseau."""
    return LECTURE_GMAIL in permissions_accordees(ctx)


def oublier(ctx) -> bool:
    """Efface le jeton local. Ne revoque rien cote Google."""
    p = _config(ctx) / FICHIER_JETON
    if p.exists():
        p.unlink()
        return True
    return False


# ------------------------------------------------------------------- transport
def _poster(url: str, champs: dict) -> dict:
    donnees = urllib.parse.urlencode(champs).encode("ascii")
    req = urllib.request.Request(
        url, data=donnees, method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise ErreurGoogle(_traduire(e)) from None
    except urllib.error.URLError as e:
        raise ErreurGoogle("Reseau injoignable : %s" % e.reason) from None


def _traduire(e) -> str:
    """Message lisible a partir de la reponse d'erreur de Google."""
    try:
        corps = e.read().decode("utf-8", "replace")
    except Exception:
        corps = ""
    detail, code = corps[:500], ""
    try:
        # Deux formes selon le service : {"error": "invalid_grant", ...} pour
        # OAuth, {"error": {"status": ..., "message": ...}} pour Gmail et Drive.
        brut = json.loads(corps).get("error")
        if isinstance(brut, str):
            code = brut
            detail = json.loads(corps).get("error_description") or detail
        elif isinstance(brut, dict):
            code = brut.get("status", "")
            detail = brut.get("message") or detail
    except Exception:
        pass
    if code == "invalid_grant" or "invalid_grant" in corps:
        return ("Autorisation Google perdue ou expiree.\n"
                "  Cause la plus frequente : l'ecran de consentement est reste\n"
                "  en mode « Test », ou Google revoque le jeton au bout de 7\n"
                "  jours. Le passer « En production » dans la console, puis :\n"
                "      python -m moteur google autoriser")
    if e.code == 403 and "insufficient" in corps.lower():
        return ("Permission refusee : l'autorisation en cours ne couvre pas\n"
                "  cette action. Relancer `python -m moteur google autoriser`\n"
                "  pour redemander les permissions.")
    return "HTTP %d : %s" % (e.code, detail)


# --------------------------------------------------------------- autorisation
PAGE_RETOUR = """<!doctype html><html lang="fr"><meta charset="utf-8">
<title>%(titre)s</title>
<style>body{font:16px/1.6 system-ui,"Segoe UI",sans-serif;background:#14141a;
color:#e8e8ec;display:grid;place-items:center;height:100vh;margin:0;text-align:center}
h1{font-size:20px;color:%(couleur)s;margin:0 0 8px}p{color:#9a9aa8;margin:0}</style>
<div><h1>%(titre)s</h1><p>%(texte)s</p></div></html>"""


def autoriser(ctx, ouvrir: bool = True) -> str:
    """Ouvre la fenetre d'autorisation Google et enregistre le jeton.

    Flux « application de bureau » : Google renvoie le code sur un petit
    serveur qui n'ecoute que sur 127.0.0.1, sur un port tire au hasard --
    le meme schema que la page de relecture des envois. PKCE en plus, pour
    qu'un autre programme de la machine ne puisse pas reutiliser le code
    intercepte.
    """
    ids = identifiants(ctx)
    verificateur = secrets.token_urlsafe(64)
    defi = base64.urlsafe_b64encode(
        hashlib.sha256(verificateur.encode("ascii")).digest()).rstrip(b"=").decode()
    etat = secrets.token_urlsafe(24)
    recu = {}
    fini = threading.Event()

    class Poignee(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if not secrets.compare_digest(q.get("state", [""])[0], etat):
                self.send_response(403)
                self.end_headers()
                return
            recu["code"] = q.get("code", [""])[0]
            recu["erreur"] = q.get("error", [""])[0]
            page = PAGE_RETOUR % (
                {"titre": "Autorisation refusee", "couleur": "#d05353",
                 "texte": recu["erreur"]} if recu["erreur"] else
                {"titre": "C'est bon.", "couleur": "#4f9f6f",
                 "texte": "Tu peux fermer cette fenetre et revenir au terminal."})
            corps = page.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(corps)))
            self.end_headers()
            self.wfile.write(corps)
            fini.set()

    serveur = HTTPServer(("127.0.0.1", 0), Poignee)
    redirection = "http://127.0.0.1:%d/" % serveur.server_address[1]
    url = AUTORISATION + "?" + urllib.parse.urlencode({
        "client_id": ids["client_id"],
        "redirect_uri": redirection,
        "response_type": "code",
        "scope": " ".join(PERMISSIONS),
        "access_type": "offline",
        # Sans « consent », Google ne renvoie le jeton de rafraichissement
        # qu'a la toute premiere autorisation : une reautorisation rendrait
        # alors un jeton d'acces seul, et le fichier resterait vide.
        "prompt": "consent",
        "code_challenge": defi,
        "code_challenge_method": "S256",
        "state": etat,
    })
    threading.Thread(target=serveur.serve_forever, daemon=True).start()
    print("Fenetre d'autorisation Google : %s\n" % url)
    if ouvrir:
        webbrowser.open(url)
    try:
        while not fini.wait(0.3):
            pass
    except KeyboardInterrupt:
        raise ErreurGoogle("Abandon : aucune autorisation enregistree.") from None
    finally:
        serveur.shutdown()

    if recu.get("erreur"):
        raise ErreurGoogle("Google a refuse : %s" % recu["erreur"])
    reponse = _poster(JETONS, {
        "client_id": ids["client_id"],
        "client_secret": ids["client_secret"],
        "code": recu["code"],
        "code_verifier": verificateur,
        "grant_type": "authorization_code",
        "redirect_uri": redirection,
    })
    if not reponse.get("refresh_token"):
        raise ErreurGoogle(
            "Google n'a pas renvoye de jeton de rafraichissement. Retirer\n"
            "l'acces de l'application sur myaccount.google.com > Securite >\n"
            "Vos connexions a des applications tierces, puis recommencer.")
    accordees = set(reponse.get("scope", "").split())
    oubliees = [p for p in PERMISSIONS if p not in accordees]
    if oubliees:
        print("Attention : permission(s) non accordee(s) : %s.\n"
              "  Les cases correspondantes n'ont pas ete cochees dans la fenetre."
              % ", ".join(p.rsplit("/", 1)[-1] for p in oubliees))
    _ecrire_jeton(ctx, reponse["refresh_token"],
                  _adresse(reponse["access_token"]),
                  permissions=sorted(accordees))
    return compte_autorise(ctx)


def _adresse(jeton_acces: str) -> str:
    """L'adresse du compte qui vient d'autoriser, demandee a Google."""
    req = urllib.request.Request(
        USERINFO, headers={"Authorization": "Bearer %s" % jeton_acces})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode("utf-8")).get("email", "")
    except urllib.error.HTTPError as e:
        raise ErreurGoogle(_traduire(e)) from None
    except urllib.error.URLError as e:
        raise ErreurGoogle("Reseau injoignable : %s" % e.reason) from None


# ------------------------------------------------------------------- le client
class Client:
    """Appels Gmail et Drive. Le jeton d'acces ne vit qu'en memoire."""

    def __init__(self, ctx):
        self.ctx = ctx
        self.identifiants = identifiants(ctx)
        self.compte = compte_autorise(ctx)
        self._acces = None

    # ------------------------------------------------------------- transport
    def jeton_acces(self) -> str:
        if self._acces:
            return self._acces
        enregistre = _lire_jeton(self.ctx) or {}
        if not enregistre.get("rafraichissement"):
            raise ErreurGoogle(
                "Compte Google pas encore autorise.\n"
                "  python -m moteur google autoriser")
        reponse = _poster(JETONS, {
            "client_id": self.identifiants["client_id"],
            "client_secret": self.identifiants["client_secret"],
            "refresh_token": enregistre["rafraichissement"],
            "grant_type": "refresh_token",
        })
        self._acces = reponse["access_token"]
        return self._acces

    def appel(self, url: str, donnees: bytes = None, content_type: str = None,
              methode: str = None) -> dict:
        entetes = {"Authorization": "Bearer %s" % self.jeton_acces()}
        if content_type:
            entetes["Content-Type"] = content_type
        req = urllib.request.Request(
            url, data=donnees, headers=entetes,
            method=methode or ("POST" if donnees else "GET"))
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                brut = r.read()
                return json.loads(brut.decode("utf-8")) if brut else {}
        except urllib.error.HTTPError as e:
            raise ErreurGoogle(_traduire(e)) from None
        except urllib.error.URLError as e:
            raise ErreurGoogle("Reseau injoignable : %s" % e.reason) from None

    # ----------------------------------------------------------------- Gmail
    def envoyer(self, message_mime: bytes) -> str:
        """Envoie un message deja assemble. Rend son identifiant Gmail."""
        if len(message_mime) > TAILLE_MAX_MESSAGE:
            raise ErreurGoogle(
                "Message de %d Mo : au-dela de %d Mo l'API Gmail demande un "
                "televersement en plusieurs morceaux, que ce module ne fait "
                "pas. Verifier les pieces jointes."
                % (len(message_mime) // 1_000_000,
                   TAILLE_MAX_MESSAGE // 1_000_000))
        corps = json.dumps({
            "raw": base64.urlsafe_b64encode(message_mime).decode("ascii")
        }).encode("utf-8")
        return self.appel(GMAIL_ENVOI, corps, "application/json").get("id", "")

    def rechercher(self, requete: str, maximum: int = 50) -> list:
        """Les identifiants des messages qui repondent a une recherche Gmail.

        La syntaxe est celle de la barre de recherche de Gmail
        (`subject:...`, `from:...`, `newer_than:30d`). Demande la permission
        de lecture (LECTURE_GMAIL) ; sans elle, Google repond 403 et
        `_traduire` le dit.
        """
        r = self.appel(GMAIL_MESSAGES + "?" + urllib.parse.urlencode(
            {"q": requete, "maxResults": str(maximum)}))
        return [m["id"] for m in r.get("messages", [])]

    def message_brut(self, identifiant: str) -> bytes:
        """Un message entier, tel que recu (RFC 822), pour l'archiver et le lire."""
        r = self.appel("%s/%s?format=raw" % (GMAIL_MESSAGES, identifiant))
        return base64.urlsafe_b64decode(r.get("raw", "") + "==")

    # ----------------------------------------------------------------- Drive
    def dossier(self, nom: str, parent: str = "root") -> str:
        """Identifiant du dossier `nom` sous `parent`, cree s'il n'existe pas.

        `drive.file` ne laisse voir que ce que l'application a cree : la
        recherche ne retrouvera donc jamais un dossier fait a la main dans
        Drive, meme s'il porte le meme nom. C'est voulu -- l'application ne
        touche qu'a son propre coin.
        """
        requete = ("name = '%s' and mimeType = '%s' and '%s' in parents "
                   "and trashed = false"
                   % (nom.replace("'", "\\'"), DOSSIER_DRIVE, parent))
        trouves = self.appel(
            DRIVE_FICHIERS + "?" + urllib.parse.urlencode(
                {"q": requete, "fields": "files(id,name)", "pageSize": "10"}))
        if trouves.get("files"):
            return trouves["files"][0]["id"]
        corps = json.dumps({"name": nom, "mimeType": DOSSIER_DRIVE,
                            "parents": [parent]}).encode("utf-8")
        return self.appel(DRIVE_FICHIERS, corps, "application/json")["id"]

    def chemin(self, *noms: str) -> str:
        """Cree au besoin toute une suite de dossiers et rend le dernier."""
        parent = "root"
        for nom in noms:
            parent = self.dossier(nom, parent)
        return parent

    def lister(self, parent: str) -> dict:
        """Les FICHIERS deja deposes dans un dossier : {nom: {id, md5, octets}}.

        Sert a la sauvegarde du dossier prive : c'est en comparant ce que
        Drive a (`md5Checksum`, calcule par Google) a ce que le disque a qu'on
        sait quoi renvoyer et quoi laisser. Les sous-dossiers sont ecartes --
        la sauvegarde les traite un par un, et un dossier n'a pas d'empreinte.
        """
        fichiers, page = {}, None
        while True:
            params = {
                "q": "'%s' in parents and trashed = false" % parent,
                "fields": "nextPageToken,files(id,name,md5Checksum,size,mimeType)",
                "pageSize": "200",
            }
            if page:
                params["pageToken"] = page
            r = self.appel(DRIVE_FICHIERS + "?" + urllib.parse.urlencode(params))
            for f in r.get("files", []):
                if f.get("mimeType") == DOSSIER_DRIVE:
                    continue
                fichiers[f["name"]] = {"id": f["id"], "md5": f.get("md5Checksum"),
                                       "octets": int(f.get("size") or 0)}
            page = r.get("nextPageToken")
            if not page:
                return fichiers

    def _existant(self, nom: str, parent: str):
        """L'identifiant du fichier `nom` deja depose dans `parent`, ou None."""
        requete = ("name = '%s' and '%s' in parents and trashed = false"
                   % (nom.replace("'", "\\'"), parent))
        trouves = self.appel(
            DRIVE_FICHIERS + "?" + urllib.parse.urlencode(
                {"q": requete, "fields": "files(id)", "pageSize": "1"}))
        return (trouves.get("files") or [{}])[0].get("id")

    def televerser(self, fichier, parent: str, nom: str = None) -> dict:
        """Depose un fichier dans un dossier Drive. Rend {id, name, webViewLink}.

        Si le nom existe deja dans le dossier, **le contenu est remplace** au
        lieu d'un second depot : Drive accepte deux fichiers de meme nom, et
        `archiver` est fait pour etre relance -- on reproduit un mois quand un
        montant URSSAF arrive, quand un bareme change. Sans cela, le dossier
        du mois se remplirait de copies dont plus rien ne dirait laquelle fait
        foi. Le fichier garde son identifiant, donc son lien et son historique
        de versions cote Drive.
        """
        fichier = Path(fichier)
        nom = nom or fichier.name
        type_mime = mimetypes.guess_type(nom)[0] or "application/octet-stream"

        deja = self._existant(nom, parent)
        if deja:
            url = "%s/%s?%s" % (DRIVE_TELEVERSEMENT, deja,
                                urllib.parse.urlencode(
                                    {"uploadType": "media",
                                     "fields": "id,name,webViewLink"}))
            depose = self.appel(url, fichier.read_bytes(), type_mime,
                                methode="PATCH")
            depose["remplace"] = True
            return depose

        limite = "----%s" % secrets.token_hex(16)
        meta = json.dumps({"name": nom, "parents": [parent]}).encode("utf-8")
        corps = b"".join([
            b"--", limite.encode(), b"\r\n",
            b"Content-Type: application/json; charset=UTF-8\r\n\r\n", meta,
            b"\r\n--", limite.encode(), b"\r\n",
            ("Content-Type: %s\r\n\r\n" % type_mime).encode(),
            fichier.read_bytes(),
            b"\r\n--", limite.encode(), b"--\r\n",
        ])
        url = DRIVE_TELEVERSEMENT + "?" + urllib.parse.urlencode(
            {"uploadType": "multipart", "fields": "id,name,webViewLink"})
        return self.appel(url, corps,
                          "multipart/related; boundary=%s" % limite)
