"""Les retours des organismes, le journal, et l'etat du mois qu'ils donnent.

Deux canaux, pas un : la DSN repond sur net-entreprises, la DPAE sur
`consultation.dpae-edi.urssaf.fr`. Relever est une LECTURE -- on archive
sans rien demander a personne, aucune seance n'est exigee, rien n'est
applique. Les reprises du journal lisent des pieces deja sur le disque et
ecrivent ce qu'elles disent ; `reprendre_depot` est le seul chemin manuel,
et il exige une note qui dise par ou le depot s'est fait.

`etat_par_paie` et `bilan_du_mois` sont la lecture du journal que l'ecran
affiche : ou en est chaque paie, et le mois en une phrase par acte.
"""
from __future__ import annotations

import datetime as _dt
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from .contexte import Contexte
from .operations_paies import charger, paies_validees
from .operations_socle import ErreurOperation
from .util import quand_lisible


@dataclass
class RetourArchive:
    retour: dict
    chemin: Path
    contenu: bytes = b""


@dataclass
class ReleveRetours:
    debut: Any
    fin: Any
    trouves: list = field(default_factory=list)
    nouveaux: list = field(default_factory=list)
    archives: list = field(default_factory=list)
    incidents: list = field(default_factory=list)
    session_jusqu_a: str = ""
    # Combien de ces retours ont trouve le depot auquel ils repondent.
    rattaches: int = 0

    def resume(self) -> str:
        if not self.trouves:
            return "Aucun retour sur la periode."
        return ("%d retour(s), dont %d nouveau(x), %d archive(s)."
                % (len(self.trouves), len(self.nouveaux), len(self.archives)))


def _tranches(debut, fin, heures=24):
    """Le SI DSN limite l'etendue d'une recherche : on decoupe par jour."""
    pas_ = _dt.timedelta(hours=heures)
    t = debut
    while t < fin:
        yield t, min(t + pas_, fin)
        t += pas_


def relever_retours(ctx: Contexte, *, debut=None, fin=None, tout: bool = False,
                    environnement: str = "production",
                    motdepasse: Optional[str] = None,
                    client=None, canal: str = "") -> ReleveRetours:
    """Telecharge et archive ce que les organismes ont publie. Rend des donnees.

    C'est une LECTURE : on archive sans rien demander a personne. Rien de ce
    qui arrive ici n'est applique -- un taux de PAS n'entre dans la
    configuration que sur `--appliquer`, vu par un humain (voir
    `commandes_retours.py`). L'archive brute, elle, est la piece justificative :
    elle est ecrite avant toute analyse.

    `motdepasse` a None : le mot de passe est cherche dans l'environnement puis
    dans le coffre, pour un usage de consultation. Aucun autre usage ne peut
    passer par ici.
    """
    from . import coffre, retours as _retours
    from .netentreprises import Client, ErreurApi, archiver, noter, deja_vus

    fin = fin or _dt.datetime.now()
    debut = debut or (fin - _dt.timedelta(days=30))
    releve = ReleveRetours(debut=debut, fin=fin)

    if client is None:
        mdp = motdepasse or coffre.lire(ctx, coffre.NET_ENTREPRISES,
                                        usage=coffre.CONSULTATION)
        if not mdp:
            releve.incidents.append(
                "Mot de passe net-entreprises absent : ni dans l'environnement, "
                "ni dans le coffre. `python -m moteur coffre poser net-entreprises`.")
            return releve
        client = Client(ctx, environnement, motdepasse=mdp)

    try:
        client.authentifier()
        releve.session_jusqu_a = client.expire_le or ""
    except ErreurApi as e:
        releve.incidents.append("Authentification refusee : %s" % e)
        return releve

    connus = deja_vus(ctx, canal)
    # UN 404 SUR UNE TRANCHE VEUT DIRE << RIEN SUR CETTE TRANCHE >>, et non
    # << ce service n'existe pas >>. Observe le 12/09/2026 sur le canal DPAE :
    # la meme adresse rend 404 pour le 8 septembre et la liste complete pour
    # le 4. Enveloppee autour de la boucle entiere -- ce qu'elle etait --
    # l'erreur arretait le balayage des le premier jour vide, et une reprise
    # qui commencait par un jour sans retour ne trouvait jamais rien.
    #
    # Tout autre code arrete : un 401 ne s'ameliorera pas au jour suivant, et
    # continuer ne ferait qu'empiler des refus.
    for t0, t1 in _tranches(debut, fin):
        try:
            trouves = client.lister_retours(t0, t1)
        except ErreurApi as e:
            if getattr(e, "code", 0) == 404:
                continue
            releve.incidents.append("Consultation interrompue : %s" % e)
            break
        for r in trouves:
            releve.trouves.append(r)
            if (r.get("flux"), r.get("nature"), r.get("publication")) not in connus:
                releve.nouveaux.append(r)
    if releve.incidents and not releve.trouves:
        return releve

    for r in (releve.trouves if tout else releve.nouveaux):
        if not r.get("url"):
            continue
        try:
            contenu, ctype = client.telecharger(r["url"])
        except ErreurApi as e:
            releve.incidents.append(
                "Telechargement du retour nature %s : %s" % (r.get("nature"), e))
            continue
        releve.archives.append(RetourArchive(
            retour=r, chemin=archiver(ctx, r, contenu, ctype, canal),
            contenu=contenu))

    if releve.trouves:
        noter(ctx, releve.trouves, canal)
        # Un depot n'est fini que quand sa reponse est la. Chaque retour va
        # se ranger en face du depot qui l'a provoque -- par le flux, et par
        # rien d'autre (voir journal.rattacher_retours).
        from . import journal
        releve.rattaches = journal.rattacher_retours(
            ctx, releve.trouves,
            {(a.retour.get("flux"), a.retour.get("nature"),
              a.retour.get("publication")): a.contenu for a in releve.archives})
    return releve


# ================================================ la reprise du journal
#
# LE PROBLEME : une liste d'embauches << sans trace >> qui reclamait de
# renvoyer ce qu'on avait deja envoye, traces de depot a l'appui.
#
# L'objection etait juste sur les faits, et l'ecran avait raison sur ce
# qu'il savait.
# Le journal des depots est ne le 11/09/2026 au soir (ETAT.md §19.3) ; tout ce
# qui est parti avant s'est fait par un chemin qui ne l'ecrivait pas --
# CoolPaie, la saisie directe sur le site, ou nos propres depots de la veille.
# D'ou << pas encore envoye >> partout, DSN d'aout comprise.
#
# Vivre avec une liste qu'on sait fausse a un cout reel : c'est une liste
# qu'on cesse de lire. D'ou cette reprise.
#
# CE QU'ELLE NE FAIT PAS, ET C'EST LE POINT : elle ne DECLARE rien, elle ne
# depose rien, elle n'appelle aucun reseau. Elle lit des pieces deja sur le
# disque et ecrit ce qu'elles disent. Une ligne reprise porte `origine` -- le
# nom de la piece -- et l'ecran doit la lire pour ce qu'elle est : la trace
# d'un depot ATTESTE, pas la preuve que ce logiciel-ci l'a fait.


@dataclass
class DepotAtteste:
    """Un depot dont une piece de retours/ temoigne."""
    flux: str
    bilan: Any                  # retours.BilanDepot
    pieces: list                # les fichiers qui l'attestent
    deja_au_journal: bool = False


def depots_attestes(ctx: Contexte) -> tuple:
    """Les depots DSN dont `retours/` porte une piece. Rend (liste, illisibles).

    Une seule entree par flux : un depot rend souvent deux rapports -- l'accuse
    de transport puis le bilan de la declaration -- et `fusionner_bilans` en
    fait un seul etat, ou le verdict de la declaration l'emporte.

    LECTURE PURE. Rien n'est ecrit, rien n'est envoye. C'est ce qui permet de
    la montrer avant de la faire.
    """
    from . import netentreprises as ne, retours as _retours

    dossier = ne.dossier_archive(ctx)
    par_flux, illisibles = {}, []
    for f in sorted(dossier.glob("*.xml")):
        try:
            b = _retours.parse_bilan_depot(f.read_bytes())
        except Exception as e:                                 # noqa: BLE001
            # Un fichier casse ne doit pas faire echouer la reprise entiere :
            # on le compte et on le nomme, et les autres passent.
            illisibles.append("%s (%s)" % (f.name, type(e).__name__))
            continue
        if b is None:
            continue
        par_flux.setdefault(b.flux, []).append((b, f.name))

    from . import journal
    connus = {l.get("flux") for l in journal.lire(ctx) if l.get("flux")}

    out = []
    for flux, couples in par_flux.items():
        fusion = _retours.fusionner_bilans([b for b, _ in couples])
        out.append(DepotAtteste(flux=flux, bilan=fusion,
                                pieces=sorted(n for _, n in couples),
                                deja_au_journal=flux in connus))
    out.sort(key=lambda d: d.bilan.recu_le or "")
    return out, illisibles


def reconstruire_journal(ctx: Contexte, *, ecrire: bool = False,
                         qui: str = "?") -> dict:
    """Remet au journal les depots DSN que les retours attestent.

    `ecrire` a False -- le defaut, et il est voulu -- ne fait que dire ce qui
    SERAIT ecrit. Une reprise qui s'execute au premier appel est une reprise
    qu'on lance << pour voir >> et qui laisse des lignes qu'on n'a pas lues.

    Idempotente : un flux deja present au journal est saute, quel que soit
    l'acte. On peut donc la relancer apres chaque releve de retours sans
    empiler des doublons.
    """
    from . import journal, retours as _retours

    attestes, illisibles = depots_attestes(ctx)
    rapport = {"trouves": [], "ajoutes": [], "deja": [], "sans_mois": [],
               "illisibles": illisibles, "ecrit": bool(ecrire),
               "rattaches": 0}

    for d in attestes:
        b = d.bilan
        vue = {
            "flux": d.flux,
            "quand": b.recu_le,
            "mois": b.mois,
            "mode": journal.REEL if b.reel else journal.TEST,
            "accepte": b.accepte,
            "verdict_connu": b.verdict_connu,
            "logiciel": b.logiciel,
            "pieces": d.pieces,
            "deja": d.deja_au_journal,
        }
        rapport["trouves"].append(vue)
        if d.deja_au_journal:
            rapport["deja"].append(vue)
            continue
        if not b.recu_le:
            # Sans date, la ligne ne saurait pas dire QUAND, et c'est la
            # seule chose qu'on lui demande. On refuse plutot que de dater
            # d'aujourd'hui un depot d'il y a trois semaines.
            rapport["sans_mois"].append(vue)
            continue
        rapport["ajoutes"].append(vue)

    if not ecrire:
        return rapport

    for vue in rapport["ajoutes"]:
        d = next(x for x in attestes if x.flux == vue["flux"])
        b = d.bilan
        journal.noter(
            ctx, journal.DSN,
            mois=b.mois or None,
            mode=journal.REEL if b.reel else journal.TEST,
            qui=qui, accepte=b.accepte,
            destinataire="net-entreprises", flux=d.flux,
            # La piece elle-meme, en clair : c'est le certificat qui libere
            # des obligations declaratives, et c'est lui qu'on relira le jour
            # ou quelqu'un demandera de quoi on se prevaut.
            reponse=b.certificat or "",
            quand=b.recu_le,
            origine="retours/" + (d.pieces[-1] if d.pieces else "?"),
            detail={
                "reconstruit": True,
                # Lu, pas annote a la main : le certificat de conformite porte
                # le nom du logiciel declarant. C'est ce qui distingue un
                # depot CoolPaie d'un depot PuppetPaie sans que personne
                # n'ait a s'en souvenir.
                "logiciel": b.logiciel,
                "type": b.type_declaration,
                "fraction": b.fraction, "ordre": b.ordre,
                "salaries": b.salaries, "contrats": b.contrats,
                "etat_envoi": b.etat_envoi,
                "etat_declaration": b.etat_declaration,
                "verdict_connu": b.verdict_connu,
                "pieces": d.pieces,
            })

    # Les retours deja archives se rangent maintenant en face des lignes qui
    # viennent d'apparaitre -- par le flux, et par rien d'autre.
    from .netentreprises import journal as _journal_retours
    p = _journal_retours(ctx)
    if p.exists():
        rapport["rattaches"] = journal.rattacher_retours(
            ctx, json.loads(p.read_text(encoding="utf-8")))
    return rapport


# ------------------------------------------- la reprise du canal DPAE
#
# LE CAS QUI L'A FAIT ECRIRE : une DPAE deposee par CoolPaie, et la question
# << tu la vois dans tes retours ? >>. Le premier << non >> etait faux -- les
# retours DSN et les retours DPAE ne sont pas les memes. L'API DPAE a SON canal de
# retours (`consultation.dpae-edi.urssaf.fr`), avec ses natures a elle, et
# PuppetPaie ne l'avait jamais consulte. La preuve etait la depuis le
# 04/09/2026 : un retour de NATURE 41, << certificat de conformite des
# DPAE >>, qui est l'accuse de reception des declarations d'embauche.
#
# CE QUI REND CETTE REPRISE-LA MEILLEURE QUE CELLE DE LA DSN : le retour 41
# porte les DECLARATIONS ELLES-MEMES, au format a plat de 990 caracteres --
# celui que `dpae.relire` sait deja lire. On n'y lit donc pas seulement
# << un depot a eu lieu >>, mais QUI a ete declare et A PARTIR DE QUAND. C'est
# exactement la maille (salarie, premier jour) dont la liste des embauches
# sans trace a besoin, et elle est LUE, pas saisie a la main.
#
# Le rattachement se fait par le NIR. Pas par le nom : deux orthographes, un
# accent, un nom d'usage, et on declarerait quelqu'un d'autre.


def _salarie_par_nir(ctx: Contexte) -> dict:
    return {(v.get("nir") or "").strip(): k
            for k, v in ctx.salaries.items() if v.get("nir")}


def embauches_attestees(ctx: Contexte) -> tuple:
    """Les DPAE dont `retours/dpae/` porte le certificat. (liste, inconnus).

    Une entree par FLUX, avec les embauches qu'il declare :

        {"flux", "quand", "mois", "piece", "embauches": [{"salarie", "debut"}],
         "inconnus": [NIR non rattaches]}

    LECTURE PURE, comme `depots_attestes`.
    """
    from . import dpae, netentreprises as ne

    dossier = ne.dossier_archive(ctx, "dpae")
    par_nir = _salarie_par_nir(ctx)
    out, inconnus = [], []
    for f in sorted(dossier.glob("*nature41*")):
        try:
            lignes = dpae.relire(f)
        except Exception as e:                                 # noqa: BLE001
            inconnus.append("%s (%s)" % (f.name, type(e).__name__))
            continue
        embauches, quand, mois = [], "", ""
        for l in lignes:
            nir = (l.get("nir") or "").strip()
            emb = (l.get("date_embauche") or "").strip()       # JJMMAAAA
            if len(emb) != 8:
                continue
            debut = "%s-%s-%s" % (emb[4:], emb[2:4], emb[:2])
            cle = par_nir.get(nir)
            if not cle:
                # On ne devine pas qui c'est. Un NIR qu'on ne reconnait pas
                # est peut-etre une fiche archivee sous une autre cle, ou une
                # declaration faite pour quelqu'un d'autre : dans les deux cas
                # inventer un rattachement serait pire que de le dire.
                inconnus.append("NIR %s (%s), embauche du %s"
                                % (nir, f.name, debut))
                continue
            embauches.append({"salarie": cle, "debut": debut})
            mois = mois or debut[:7]
            h = (l.get("horodatage") or "").strip()            # JJMMAAAAHHMM
            if not quand and len(h) == 12:
                quand = "%s-%s-%sT%s:%s:00" % (h[4:8], h[2:4], h[:2],
                                               h[8:10], h[10:12])
        if embauches:
            out.append({"flux": _flux_du_nom(f.name), "quand": quand,
                        "mois": mois, "piece": f.name, "embauches": embauches})
    out.sort(key=lambda x: x["quand"] or "")
    return out, inconnus


def _flux_du_nom(nom: str) -> str:
    """`20260904-224552_nature41_WSxxxx.txt` -> `WSxxxx`.

    Le format a plat ne porte pas l'idflux -- c'est le nom du fichier archive
    qui le garde (`netentreprises.archiver`). Tronque a 24 caracteres par
    l'archivage, ce qui suffit a dedoublonner mais pas a rattacher un retour :
    d'ou le bilan XML a cote, qui porte l'idflux entier.
    """
    reste = nom.split("_", 2)[-1]
    return reste.rsplit(".", 1)[0]


def reconstruire_journal_dpae(ctx: Contexte, *, ecrire: bool = False,
                              qui: str = "?") -> dict:
    """Remet au journal les DPAE que les certificats de l'Urssaf attestent.

    Meme forme et memes regles que `reconstruire_journal` : `ecrire` a False
    par defaut, idempotente par le flux, et chaque ligne porte `origine`.
    """
    from . import journal, retours as _retours, netentreprises as ne

    attestees, inconnus = embauches_attestees(ctx)
    connus = {l.get("flux") for l in journal.lire(ctx) if l.get("flux")}

    # Le bilan XML du meme flux, quand il est la : il porte l'idflux ENTIER et
    # dit si le depot etait reel ou de test. Le format a plat ne le dit pas.
    bilans = {}
    for f in sorted(ne.dossier_archive(ctx, "dpae").glob("*.xml")):
        try:
            b = _retours.parse_bilan_depot(f.read_bytes())
        except Exception:                                      # noqa: BLE001
            continue
        if b:
            bilans.setdefault(b.flux, []).append((b, f.name))

    rapport = {"trouves": [], "ajoutes": [], "deja": [], "inconnus": inconnus,
               "ecrit": bool(ecrire)}
    for e in attestees:
        # Le nom de fichier tronque le flux ; le bilan XML porte l'entier. On
        # rattache par prefixe, et on garde l'entier quand on le trouve.
        entier = next((k for k in bilans if k.startswith(e["flux"])), e["flux"])
        b = _retours.fusionner_bilans([x for x, _ in bilans.get(entier, [])]) \
            if entier in bilans else None
        vue = dict(e, flux=entier,
                   mode=(journal.TEST if (b and not b.reel) else journal.REEL),
                   accepte=(b.accepte if b else True),
                   deja=entier in connus)
        rapport["trouves"].append(vue)
        (rapport["deja"] if vue["deja"] else rapport["ajoutes"]).append(vue)

    if not ecrire:
        return rapport

    for vue in rapport["ajoutes"]:
        journal.noter(
            ctx, journal.DPAE, mois=vue["mois"] or None, mode=vue["mode"],
            qui=qui, accepte=vue["accepte"], destinataire="urssaf-dpae",
            flux=vue["flux"], quand=vue["quand"],
            origine="retours/dpae/" + vue["piece"],
            detail={"reconstruit": True,
                    "embauches": vue["embauches"],
                    "certificat": True})
    return rapport


def reprendre_depot(ctx: Contexte, quoi: str, *, mois: str, quand: str,
                    note: str, embauches: Optional[list] = None,
                    mode: str = None, qui: str = "?") -> dict:
    """Declare au journal un depot fait AILLEURS, que rien n'atteste ici.

    C'est le chemin des DPAE, et il est manuel parce qu'il ne peut pas ne pas
    l'etre : une DPAE ne rend aucun retour du genre de l'accuse DSN. Rien sur
    ce disque ne dit qu'elle est partie -- ni fichier, ni date, ni accuse. La
    seule source est ce que l'employeur SAIT avoir fait.

    D'ou la forme : on exige une date et une NOTE, en clair, qui dise par quel
    chemin ca s'est fait. La ligne portera `origine` = cette note, et personne
    ne la confondra avec un depot que le logiciel a vu passer.

    On ne devine pas les embauches : `embauches` est la liste
    [{"salarie": cle, "debut": "AAAA-MM-JJ"}, ...] que l'ecran fait cocher.
    Sans elle, la ligne ne retirerait rien de la liste des embauches sans
    trace -- ce qui est precisement ce qu'on cherche a corriger.
    """
    from . import journal

    if quoi not in journal.ACTES:
        raise ErreurOperation("Acte inconnu : %r." % quoi)
    if not note.strip():
        raise ErreurOperation(
            "Une reprise doit dire par quel chemin le depot s'est fait "
            "(par exemple : << depose par CoolPaie le 28/08 >>). Sans cette "
            "phrase, la ligne se lira comme un depot de PuppetPaie.")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2})?)?",
                        (quand or "").strip()):
        raise ErreurOperation(
            "Date de depot attendue en AAAA-MM-JJ (heure facultative), "
            "recu %r. C'est la date qui situe le depot ; aujourd'hui ne "
            "conviendrait pas." % quand)
    if quoi == journal.DPAE and not embauches:
        raise ErreurOperation(
            "Reprendre une DPAE sans dire QUELLES embauches elle declare ne "
            "retirerait rien de la liste des embauches sans trace. "
            "Passer `embauches`.")

    return journal.noter(
        ctx, quoi, mois=mois,
        mode=mode or journal.REEL, qui=qui, accepte=True,
        destinataire="", flux="",
        quand=quand.strip().replace(" ", "T"),
        origine=note.strip(),
        detail={"reconstruit": True, "hors_puppetpaie": True,
                "embauches": list(embauches or [])})


def relever_retours_dpae(ctx: Contexte, *, debut=None, fin=None,
                         tout: bool = False, flux: str = "",
                         motdepasse: Optional[str] = None) -> ReleveRetours:
    """Les retours de l'API DPAE. UN AUTRE SERVICE QUE CELUI DE LA DSN.

    Les retours DSN et les retours DPAE ne sont pas les memes, et c'etait
    un angle mort : `relever_retours` ne
    consultait que net-entreprises, et la reponse << aucune trace de DPAE dans
    les retours >> voulait seulement dire << on n'a jamais regarde la >>.

    Le canal existe et il est deja cable : `ClientDpae` porte les adresses de
    `consultation.dpae-edi.urssaf.fr`, et le transport est le meme -- le guide
    d'implementation dit que l'API DPAE est << entierement compatible avec le
    mode API disponible pour la DSN >>. Il ne manquait que l'appel.

    Les natures n'ont PAS le meme sens qu'en DSN (voir `dpae_api.NATURES`) :
    41 est le certificat de conformite des DPAE, celui qui atteste qu'une
    declaration d'embauche est passee. D'ou l'archivage dans `retours/dpae/`,
    a part -- une nature 11 de DPAE dans le meme dossier se lirait comme un
    bilan de DSN.

    C'est une LECTURE : aucune seance n'est exigee, comme pour les retours DSN
    (CLAUDE.md). Rien n'est declare, rien n'est depose.
    """
    from . import coffre
    from .dpae_api import ClientDpae

    mdp = motdepasse or coffre.lire(ctx, coffre.URSSAF,
                                    usage=coffre.CONSULTATION)
    if not mdp:
        r = ReleveRetours(debut=debut or _dt.datetime.now(),
                          fin=fin or _dt.datetime.now())
        r.incidents.append(
            "Mot de passe DPAE absent : ni dans l'environnement, ni dans le "
            "coffre. `python -m moteur coffre poser urssaf`.")
        return r
    client = ClientDpae(ctx, motdepasse=mdp)
    if flux:
        # LE SEUL CHEMIN DOCUMENTE (FAQ officielle). Le listage par declarant
        # rend 404 sur ce service -- voir `dpae_api.ADRESSES_DPAE`.
        from .netentreprises import ErreurApi, archiver, noter
        r = ReleveRetours(debut=debut or _dt.datetime.now(),
                          fin=fin or _dt.datetime.now())
        try:
            client.authentifier()
            r.trouves = client.lister_retours_du_flux(flux)
        except ErreurApi as e:
            r.incidents.append("Consultation du flux %s : %s" % (flux, e))
            return r
        for x in r.trouves:
            if not x.get("url"):
                continue
            try:
                contenu, ctype = client.telecharger(x["url"])
            except ErreurApi as e:
                r.incidents.append("Telechargement nature %s : %s"
                                   % (x.get("nature"), e))
                continue
            r.archives.append(RetourArchive(
                retour=x, chemin=archiver(ctx, x, contenu, ctype, "dpae"),
                contenu=contenu))
        if r.trouves:
            noter(ctx, r.trouves, "dpae")
            # Le chemin par flux n'accrochait pas ce qu'il trouvait au journal
            # (vu le 12/09/2026) : un retour archive dont le depot ne savait
            # rien, et un ecran qui disait << pas encore de retour >>.
            from . import journal
            r.rattaches = journal.rattacher_retours(
                ctx, r.trouves,
                {(a.retour.get("flux"), a.retour.get("nature"),
                  a.retour.get("publication")): a.contenu for a in r.archives})
        return r
    return relever_retours(ctx, debut=debut, fin=fin, tout=tout,
                           client=client, canal="dpae")


# -------------------------------------------- l'etat du mois, lu au journal
def etat_par_paie(ctx: Contexte, mois: str) -> list:
    """Ou en est CHAQUE paie du mois. Ce que l'ecran met dans chaque bloc.

    Plusieurs cases dans chaque paie, pour voir en un coup d'oeil si la DPAE
    est faite, si le contrat est envoye : c'est ce que l'ecran montre, et
    voici d'ou il le tient.

    CHAQUE ETAT DIT A QUELLE MAILLE IL EST CONNU, et c'est le coeur de cette
    fonction. Les quatre actes ne se declarent pas au meme grain, et un ecran
    qui les alignerait tous sur << cette paie-ci >> promettrait une precision
    que le journal n'a pas :

      dpae       la PAIE.     La DPAE declare une embauche : (salarie, premier
                              jour). C'est le seul acte qui descende jusque-la.
      signature  la PAIE.     Un contrat par salarie et par engagement.
      documents  le SALARIE.  On envoie a quelqu'un ses documents DU MOIS, en
                              un message, quels que soient ses contrats.
      dsn        le MOIS.     Une DSN est mensuelle par nature : il n'existe
                              pas de DSN d'une paie.

    Rendre << mois >> ou << salarie >> dans `maille` n'est pas un aveu de
    faiblesse : c'est ce que l'ecran doit ecrire a cote de la pastille, pour
    que personne ne croie avoir deposer une DSN pour une seule paie.

    Ne dit rien de la VALIDATION : une paie validee est une paie dont
    l'edition est fermee, et ca ne se lit pas au journal des envois -- rien
    n'est parti. C'est un etat de la saisie, pas un acte.
    """
    from . import journal

    s = charger(ctx, ctx.racine / "paies" / ("%s.json" % mois))
    # La validation vit A COTE des quatre actes, et jamais dedans. Les actes
    # disent ce qui est PARTI ; la validation dit que l'edition est fermee, et
    # rien n'est parti. Les melanger ferait croire qu'une paie verte a ete
    # declaree quelque part.
    validees = paies_validees(ctx, mois)
    dpae = journal.etat_des_embauches(ctx)
    contrats = journal.contrats_demandes(ctx)
    recus = journal.contrats_recus(ctx)
    recus_par = journal.contrats_recus_comment(ctx)
    docs = journal.documents_envoyes(ctx, mois)
    actes = journal.etat_du_mois(ctx, mois)
    depot_dsn = actes.get(journal.DSN)

    lignes = []
    for p in s.paies:
        cle, debut = p.salarie["_cle"], str(p.engagement.debut)
        lignes.append({
            "salarie": cle,
            "nom": "%s %s" % (p.salarie["nom"],
                              p.salarie.get("prenom_affichage")
                              or p.salarie["prenom"]),
            "spectacle": p.spectacle["titre"],
            "numero": p.engagement.numero,
            "debut": debut, "fin": str(p.engagement.fin),
            "emploi": p.salarie.get("emploi"),
            "statut": p.salarie.get("statut"),
            "brut": str(p.brut),
            "valide": validees.get((cle, debut)),
            # Ou en est le CONTRAT par rapport au mois : un contrat qui
            # deborde n'a sa DPAE et sa signature qu'a son premier mois, et
            # son certificat CS qu'au dernier. L'ecran le dit a cote des
            # pastilles (<< faite en octobre -- contrat en cours >>).
            "contrat": {"premier_mois": p.engagement.premier_mois,
                        "dernier_mois": p.engagement.dernier_mois,
                        "depuis": p.engagement.mois_du_contrat[0],
                        "jusqu_a": p.engagement.mois_du_contrat[-1]},
            "etats": {
                # `passee` : le certificat de conformite est arrive pour LE
                # depot qui porte cette embauche -- par paie, et non « le
                # dernier depot du mois », qui n'en dit rien pour les autres.
                "dpae": {"fait": (dpae.get((cle, debut)) or {}).get("quand"),
                         "passee": bool((dpae.get((cle, debut)) or {}).get("passee")),
                         "refusee": bool((dpae.get((cle, debut)) or {}).get("refusee")),
                         "anomalies": (dpae.get((cle, debut)) or {}).get("anomalies") or [],
                         "dossier": (dpae.get((cle, debut)) or {}).get("dossier") or "",
                         "deja_existante": bool((dpae.get((cle, debut)) or {}).get("deja_existante")),
                         "maille": "paie"},
                # `recu` : le contrat signe est revenu -- dit par un humain,
                # pas su par le logiciel (contrat_recu). Envoye = orange,
                # revenu signe = vert ; c'est la demande du 12/09/2026.
                "signature": {"fait": contrats.get((cle, debut)),
                              "recu": recus.get((cle, debut)),
                              "recu_par": recus_par.get((cle, debut)),
                              "maille": "paie"},
                "documents": {"fait": docs.get(cle), "maille": "salarie"},
                "dsn": {"fait": depot_dsn.get("quand") if depot_dsn else None,
                        "maille": "mois"},
            },
        })
    return lignes


def bilan_du_mois(ctx: Contexte, mois: str) -> dict:
    """Le mois en un coup d'oeil, acte par acte : une phrase et une couleur.

    << Tous les contrats sont signes >> se lit en vert, << toutes les DPAE
    sont faites >> aussi ; ce qui n'est pas fait se lit en orange -- un code
    couleur qui se comprend en un coup d'oeil. Un << envoye le ... -- tous
    revenus signes >> en orange etait faux : l'acte etait fini.

    La couleur repond a la question du mois entier, pas au dernier envoi :
    << vert >> = plus rien a faire pour cet acte sur ce mois ; << alerte >>
    (orange) = il reste quelque chose, ou un retour attendu ; << refus >>
    (rouge) = un organisme a dit non ; vide = rien n'est parti. Le detail
    (les envois, tests compris) reste en dessous, et les boutons aussi.
    """
    from . import journal
    # Un mois sans fichier de saisie n'a pas de paies : rien a promettre.
    fichier = ctx.racine / "paies" / ("%s.json" % mois)
    paies = etat_par_paie(ctx, mois) if fichier.exists() else []
    n = len(paies)
    out = {}

    def _pluriel(k, un, des):
        return un if k == 1 else des

    # --- DPAE : par embauche -- celles du mois. Un contrat en cours depuis
    # un mois precedent a eu sa DPAE et son contrat AVEC ce mois-la ; le
    # compter ici reclamerait une seconde DPAE pour un seul contrat.
    embauches = [p for p in paies if p["contrat"]["premier_mois"]]
    en_cours = n - len(embauches)
    n = len(embauches)
    d = [p["etats"]["dpae"] for p in embauches]
    passees = sum(1 for e in d if e.get("passee"))
    refusees = sum(1 for e in d if e.get("refusee"))
    parties = sum(1 for e in d if e.get("fait") and not e.get("passee") and not e.get("refusee"))
    if not n and en_cours:
        # Vert = plus rien a faire pour cet acte sur CE mois. La DPAE, elle,
        # releve du premier mois du contrat : on ne dit pas qu'elle est
        # faite, on dit ou la regarder.
        out[journal.DPAE] = {"couleur": "bien", "courte": "rien ce mois-ci", "phrase":
                             "rien à déclarer ce mois-ci — %d contrat%s en cours depuis un mois précédent, la DPAE relève de son premier mois"
                             % (en_cours, _pluriel(en_cours, "", "s"))}
    elif not n:
        out[journal.DPAE] = {"couleur": "", "phrase": "aucune paie ce mois-ci"}
    elif refusees:
        out[journal.DPAE] = {"couleur": "refus", "phrase":
                             "%d DPAE refusée%s — à corriger et à renvoyer" % (refusees, _pluriel(refusees, "", "s"))}
    elif passees == n:
        out[journal.DPAE] = {"couleur": "bien", "phrase":
                             "Toutes les DPAE sont faites (%d) — passées à l'Urssaf" % n}
    elif passees + parties == n:
        out[journal.DPAE] = {"couleur": "alerte", "phrase":
                             "Toutes les DPAE sont parties (%d) — %d retour%s attendu%s" % (
                                 n, parties, _pluriel(parties, "", "s"), _pluriel(parties, "", "s"))}
    elif passees + parties:
        out[journal.DPAE] = {"couleur": "alerte", "phrase":
                             "%d DPAE sur %d déclarée%s — il en reste %d" % (
                                 passees + parties, n, _pluriel(passees + parties, "", "s"), n - passees - parties)}
    else:
        out[journal.DPAE] = {"couleur": "", "phrase": "aucune DPAE déclarée — %d à faire" % n}

    # --- Contrats : envoyes, puis revenus signes -- ceux du mois, memes
    # raisons que la DPAE.
    s = [p["etats"]["signature"] for p in embauches]
    recus = sum(1 for e in s if e.get("recu"))
    envoyes = sum(1 for e in s if e.get("fait"))
    if not n and en_cours:
        out[journal.SIGNATURE] = {"couleur": "bien", "courte": "rien ce mois-ci", "phrase":
                                  "rien à signer ce mois-ci — %d contrat%s en cours depuis un mois précédent, la signature relève de son premier mois"
                                  % (en_cours, _pluriel(en_cours, "", "s"))}
    elif not n:
        out[journal.SIGNATURE] = {"couleur": "", "phrase": "aucune paie ce mois-ci"}
    elif recus == n:
        out[journal.SIGNATURE] = {"couleur": "bien", "phrase":
                                  "Tous les contrats sont signés et reçus (%d)" % n}
    elif envoyes == n:
        out[journal.SIGNATURE] = {"couleur": "alerte", "phrase":
                                  "Tous les contrats sont envoyés (%d) — %d reçu%s signé%s, %d à recevoir" % (
                                      n, recus, _pluriel(recus, "", "s"), _pluriel(recus, "", "s"), n - recus)}
    elif envoyes:
        out[journal.SIGNATURE] = {"couleur": "alerte", "phrase":
                                  "%d contrat%s sur %d envoyé%s — %d reçu%s signé%s" % (
                                      envoyes, _pluriel(envoyes, "", "s"), n, _pluriel(envoyes, "", "s"),
                                      recus, _pluriel(recus, "", "s"), _pluriel(recus, "", "s"))}
    else:
        out[journal.SIGNATURE] = {"couleur": "", "phrase": "aucun contrat envoyé — %d à faire signer" % n}

    # --- Documents : par salarie du mois.
    salaries = {p["salarie"] for p in paies}
    faits = {p["salarie"] for p in paies if p["etats"]["documents"].get("fait")}
    if not salaries:
        out[journal.DOCUMENTS] = {"couleur": "", "phrase": "aucune paie ce mois-ci"}
    elif faits == salaries:
        out[journal.DOCUMENTS] = {"couleur": "bien", "phrase":
                                  "Documents envoyés à tous les salariés du mois (%d)" % len(salaries)}
    elif faits:
        out[journal.DOCUMENTS] = {"couleur": "alerte", "phrase":
                                  "Documents envoyés à %d salarié%s sur %d" % (
                                      len(faits), _pluriel(len(faits), "", "s"), len(salaries))}
    else:
        out[journal.DOCUMENTS] = {"couleur": "", "phrase":
                                  "Documents pas encore envoyés — %d salarié%s" % (
                                      len(salaries), _pluriel(len(salaries), "", "s"))}

    # --- DSN : le mois entier.
    e = journal.etat_dsn_du_mois(ctx, mois)
    if not e:
        out[journal.DSN] = {"couleur": "", "phrase": "DSN pas encore déposée"}
    elif e.get("refusee"):
        out[journal.DSN] = {"couleur": "refus", "phrase":
                            "DSN REFUSÉE — " + (" ; ".join(e.get("anomalies") or []) or "motif non lu")}
    elif e.get("passee"):
        out[journal.DSN] = {"couleur": "bien", "phrase":
                            "DSN déposée le %s — passée" % quand_lisible(e.get("quand"))}
    else:
        out[journal.DSN] = {"couleur": "alerte", "phrase":
                            "DSN déposée le %s — retour attendu" % quand_lisible(e.get("quand"))}
    return out
