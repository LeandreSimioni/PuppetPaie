"""La version du logiciel, et sa mise a jour dans l'ombre.

Ce que Leandre a demande le 16/09/2026 : << a l'ouverture, une verification
du depot ; si une nouvelle version existe, un telechargement, et une fois
telecharge un message : une nouvelle version est disponible, veuillez
redemarrer. [...] J'aimerais que la mise a jour soit quasiment invisible, et
que tout se fasse dans l'ombre. >> C'est le mecanisme de Claude Code :
telecharger derriere, poser a cote, basculer au redemarrage suivant.

Trois temps, trois fonctions :

  verifier   a l'ouverture, dans le fil de fond. Lit `derniere.json` au
             depot ; si la version est plus recente que la notre, prend
             l'archive, verifie son condensat, la deballe dans
             prive/maj/<version>/, la CONTROLE (le nouveau code doit
             s'importer en entier), et pose prive/maj/prete.json. Rien
             d'autre : le logiciel en cours ne change pas.
  appliquer  au demarrage suivant, par le lanceur, AVANT que le serveur ne
             parte : ce qui est dans logiciel/ va dans logiciel/.avant/,
             la version prete prend sa place. Si ca casse en route, tout
             revient. `.avant/` reste, pour `revenir`.
  publier    chez l'editeur : fabrique l'archive et `derniere.json` dans
             le depot. C'est ce qui se fait deux fois par mois, apres la
             relecture des taux, avec Claude Code.

Le depot n'est qu'une adresse : un dossier sur le disque aujourd'hui, une
URL le jour ou le depot public existe. Le format est le meme :

    <depot>/derniere.json      {"version", "archive", "sha256", "notes", "calcul"}
    <depot>/<archive>.zip      le contenu de logiciel/, sans __pycache__

`calcul` est la seule chose qui s'affiche apres coup : une phrase, quand
la version change un CALCUL (un bug de paie), montree une fois au premier
passage suivant la bascule. Un taux qui change n'en est pas : la
declaration est mensuelle, le mois suivant rattrape.

La version est une date, `AAAA.MM.JJ`, dans le fichier VERSION a la racine
du code. Elle se compare comme des entiers, pas comme du texte.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

CODE = Path(__file__).resolve().parent.parent
FICHIER_VERSION = "VERSION"
DERNIERE = "derniere.json"
AGENT = "PuppetPaie (mise a jour)"
# L'adresse du depot public, le jour ou il existe. Tant qu'elle est vide, une
# installation sans `maj.json` ne cherche pas de mise a jour -- et le dit.
DEPOT_PAR_DEFAUT: Optional[str] = None
# Ce qui ne part jamais dans une archive, ni ne bouge a la bascule.
EXCLUS = {".git", ".avant", "__pycache__", ".pytest_cache"}
NE_PAS_TOUCHER = {".git", ".avant"}


# ------------------------------------------------------------------ version
def courante(code: Path = CODE) -> str:
    p = code / FICHIER_VERSION
    return p.read_text(encoding="utf-8").strip() if p.exists() else "0.0.0"


def _cle(version: str) -> tuple:
    try:
        return tuple(int(x) for x in version.strip().split("."))
    except ValueError:
        return (0,)


def plus_recente(candidate: str, reference: str) -> bool:
    return _cle(candidate) > _cle(reference)


def controler(code: Path, racine: Path) -> str:
    """Le nouveau code s'importe-t-il en entier, et lit-il NOS donnees ?
    Rend "" si oui, sinon ce qui a casse. C'est un sous-processus, sur la
    racine de donnees de cette installation : on ne melange pas deux
    versions dans le meme interpreteur, et une version qui ne sait plus
    lire la configuration de la compagnie n'est pas prete."""
    exe = sys.executable
    if exe.lower().endswith("pythonw.exe"):
        exe = exe[:-len("pythonw.exe")] + "python.exe"
    env = dict(os.environ, PUPPETPAIE_DONNEES=str(racine))
    try:
        r = subprocess.run([exe, "-m", "moteur", "version", "--controle"],
                           cwd=str(code), capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=120, env=env,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except (OSError, subprocess.TimeoutExpired) as e:
        return str(e)
    if r.returncode != 0:
        return (r.stderr or r.stdout).strip()[-800:] or "code de retour %d" % r.returncode
    return ""


def importer_tout() -> list:
    """Importe chaque module de `moteur` ; rend ceux qui refusent."""
    import importlib
    import pkgutil
    from . import __path__ as chemins
    echecs = []
    for m in pkgutil.iter_modules(chemins):
        if m.name.startswith("__"):
            continue
        try:
            importlib.import_module("moteur." + m.name)
        except Exception as e:                                    # noqa: BLE001
            echecs.append("%s : %s" % (m.name, e))
    return echecs


# ------------------------------------------------------------ configuration
def configuration(ctx) -> dict:
    """prive/config/maj.json : {"depot": adresse, "editeur": bool}. Absent :
    une compagnie, avec le depot par defaut."""
    p = Path(ctx.racine) / "config" / "maj.json"
    d = {}
    if p.exists():
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except ValueError as e:
            # On ne devine pas : un fichier illisible se dit, il ne fait pas
            # d'une installation de l'editeur une compagnie.
            raise ValueError("config/maj.json illisible : %s" % e)
    return {"depot": d.get("depot") or DEPOT_PAR_DEFAUT,
            "editeur": bool(d.get("editeur", False))}


def editeur(ctx) -> bool:
    """Le poste de l'editeur : celui qui relit les sources et publie. Chez
    lui, pas de mise a jour automatique -- c'est lui qui fabrique la
    version, avec Claude Code."""
    return configuration(ctx)["editeur"]


def dossier_maj(ctx) -> Path:
    return Path(ctx.racine) / "maj"


# ------------------------------------------------------------------- depot
def _lire(depot: str, nom: str) -> bytes:
    if depot.startswith(("http://", "https://")):
        url = depot.rstrip("/") + "/" + nom
        req = urllib.request.Request(url, headers={"User-Agent": AGENT})
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.read()
    return (Path(depot) / nom).read_bytes()


def derniere(depot: str) -> dict:
    d = json.loads(_lire(depot, DERNIERE).decode("utf-8"))
    for k in ("version", "archive", "sha256"):
        if not d.get(k):
            raise ValueError("derniere.json sans « %s »" % k)
    return d


# --------------------------------------------------------------- verifier
@dataclass
class EtatMaj:
    courante: str
    depot: Optional[str]
    derniere: Optional[str] = None
    prete: Optional[str] = None          # version telechargee, controlee, a appliquer
    telechargee_maintenant: bool = False
    message: str = ""                    # ce que le bandeau dit, en une ligne
    detail: str = ""                     # pourquoi, quand ca ne s'est pas passe
    note_calcul: str = ""                # a montrer une fois, apres une bascule
    extra: dict = field(default_factory=dict)


def prete(ctx) -> Optional[dict]:
    p = dossier_maj(ctx) / "prete.json"
    if not p.exists():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except ValueError:
        return None
    if not (dossier_maj(ctx) / d.get("version", "") / "logiciel" / "moteur").is_dir():
        return None                       # le dossier a disparu : rien de pret
    return d


def verifier(ctx, telecharger: bool = True, code: Path = CODE) -> EtatMaj:
    """A l'ouverture. Ne leve jamais : ce qui n'a pas pu se faire est dans
    `detail`, le bandeau reste calme -- une compagnie hors ligne n'a pas
    besoin d'un avertissement, elle a besoin de faire sa paie."""
    try:
        cfg = configuration(ctx)
    except ValueError as exc:
        return EtatMaj(courante=courante(code), depot=None,
                       message="version %s" % courante(code), detail=str(exc))
    e = EtatMaj(courante=courante(code), depot=cfg["depot"])
    e.note_calcul = _note_a_montrer(ctx)
    deja = prete(ctx)
    if deja and plus_recente(deja["version"], e.courante):
        e.prete = deja["version"]
    if not e.depot:
        e.message = "version %s" % e.courante
        e.detail = "aucun depot de mises a jour configure (config/maj.json)"
        return _avec_prete(e)
    try:
        d = derniere(e.depot)
    except Exception as exc:                                      # noqa: BLE001
        e.message = "version %s" % e.courante
        e.detail = "depot injoignable : %s" % exc
        return _avec_prete(e)
    e.derniere = d["version"]
    if not plus_recente(d["version"], e.courante):
        e.message = "version %s, a jour" % e.courante
        return e
    if e.prete == d["version"] or not telecharger:
        return _avec_prete(e)
    try:
        _telecharger(ctx, e.depot, d)
        e.prete, e.telechargee_maintenant = d["version"], True
    except Exception as exc:                                      # noqa: BLE001
        e.message = "version %s" % e.courante
        e.detail = "la %s existe mais n'a pas pu etre preparee : %s" % (d["version"], exc)
        return e
    return _avec_prete(e)


def _avec_prete(e: EtatMaj) -> EtatMaj:
    if e.prete:
        e.message = ("version %s -- la %s est prete : redemarrez PuppetPaie quand "
                     "vous voulez" % (e.courante, e.prete))
    elif not e.message:
        e.message = "version %s" % e.courante
    return e


def _telecharger(ctx, depot: str, d: dict) -> Path:
    """L'archive, verifiee, deballee, controlee ; puis prete.json."""
    octets = _lire(depot, d["archive"])
    sha = hashlib.sha256(octets).hexdigest()
    if sha != d["sha256"]:
        raise ValueError("archive alteree (condensat %s… attendu %s…)" % (sha[:12], d["sha256"][:12]))
    cible = dossier_maj(ctx) / d["version"]
    if cible.exists():
        shutil.rmtree(cible)
    (cible / "logiciel").mkdir(parents=True)
    with zipfile.ZipFile(io.BytesIO(octets)) as z:
        for nom in z.namelist():
            if nom.startswith("/") or ".." in Path(nom).parts:
                raise ValueError("archive suspecte : %s" % nom)
        z.extractall(cible / "logiciel")
    if courante(cible / "logiciel") != d["version"]:
        raise ValueError("l'archive dit %s, derniere.json dit %s"
                         % (courante(cible / "logiciel"), d["version"]))
    probleme = controler(cible / "logiciel", Path(ctx.racine))
    if probleme:
        shutil.rmtree(cible, ignore_errors=True)
        raise ValueError("le nouveau code ne demarre pas : %s" % probleme)
    (dossier_maj(ctx) / "prete.json").write_text(json.dumps({
        "version": d["version"], "quand": _dt.datetime.now().isoformat(timespec="minutes"),
        "notes": d.get("notes", ""), "calcul": d.get("calcul", ""),
    }, ensure_ascii=False, indent=1), encoding="utf-8")
    return cible


# --------------------------------------------------------------- appliquer
def _interface_tourne() -> bool:
    import socket
    from .web import PORT_DEFAUT
    try:
        with socket.create_connection(("127.0.0.1", PORT_DEFAUT), timeout=0.5):
            return True
    except OSError:
        return False


def appliquer(ctx, code: Path = CODE, forcer: bool = False) -> dict:
    """La bascule. A faire AVANT de demarrer le serveur -- le lanceur le
    fait. Rend {"version", "avant", "quand"} ; ValueError quand il n'y a
    rien de pret, ou que l'interface tourne encore (deux versions dans un
    meme processus, c'est le seul vrai danger)."""
    d = prete(ctx)
    if not d:
        raise ValueError("aucune version prete a appliquer")
    if not forcer and _interface_tourne():
        raise ValueError("PuppetPaie tourne : fermer la fenetre, puis appliquer")
    neuf = dossier_maj(ctx) / d["version"] / "logiciel"
    avant = code / ".avant"
    if avant.exists():
        shutil.rmtree(avant)
    avant.mkdir()
    deplaces = []
    try:
        for p in list(code.iterdir()):
            if p.name in NE_PAS_TOUCHER:
                continue
            shutil.move(str(p), str(avant / p.name))
            deplaces.append(p.name)
        for p in list(neuf.iterdir()):
            if p.name in NE_PAS_TOUCHER:
                continue
            shutil.move(str(p), str(code / p.name))
    except Exception:
        # Retour a l'etat d'avant, dans l'ordre inverse : ce qui est venu du
        # neuf repart, ce qui etait la revient.
        for p in list(code.iterdir()):
            if p.name not in NE_PAS_TOUCHER and p.name not in deplaces:
                shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)
        for nom in deplaces:
            if (avant / nom).exists() and not (code / nom).exists():
                shutil.move(str(avant / nom), str(code / nom))
        raise
    quand = _dt.datetime.now().isoformat(timespec="minutes")
    (dossier_maj(ctx) / "appliquee.json").write_text(json.dumps({
        "version": d["version"], "quand": quand, "notes": d.get("notes", ""),
        "calcul": d.get("calcul", ""), "vue": False,
    }, ensure_ascii=False, indent=1), encoding="utf-8")
    (dossier_maj(ctx) / "prete.json").unlink(missing_ok=True)
    shutil.rmtree(dossier_maj(ctx) / d["version"], ignore_errors=True)
    return {"version": d["version"], "avant": str(avant), "quand": quand}


def revenir(ctx, code: Path = CODE, forcer: bool = False) -> dict:
    """Reprendre la version d'avant, gardee dans .avant/. Une seule marche
    arriere : ce qui est remplace est perdu."""
    avant = code / ".avant"
    if not (avant / "moteur").is_dir():
        raise ValueError("pas de version d'avant dans %s" % avant)
    if not forcer and _interface_tourne():
        raise ValueError("PuppetPaie tourne : fermer la fenetre, puis revenir")
    version_avant = courante(avant)
    for p in list(code.iterdir()):
        if p.name in NE_PAS_TOUCHER:
            continue
        shutil.rmtree(p) if p.is_dir() else p.unlink()
    for p in list(avant.iterdir()):
        shutil.move(str(p), str(code / p.name))
    avant.rmdir()
    (dossier_maj(ctx) / "appliquee.json").unlink(missing_ok=True)
    return {"version": version_avant}


def _note_a_montrer(ctx) -> str:
    """La phrase « cette version change un calcul », une fois. La lire la
    marque comme vue : c'est le premier passage qui la montre."""
    p = dossier_maj(ctx) / "appliquee.json"
    if not p.exists():
        return ""
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except ValueError:
        return ""
    if d.get("vue") or not d.get("calcul"):
        return ""
    d["vue"] = True
    p.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    return "La version %s change un calcul : %s" % (d.get("version", "?"), d["calcul"])


# ----------------------------------------------------------------- publier
def archiver(code: Path = CODE) -> bytes:
    """Le contenu de logiciel/, sans caches ni depot git ni version d'avant,
    dans un zip deterministe (memes fichiers -> meme condensat)."""
    buf = io.BytesIO()
    fichiers = []
    for racine, dossiers, noms in os.walk(code):
        dossiers[:] = sorted(d for d in dossiers if d not in EXCLUS)
        for n in sorted(noms):
            if n.endswith((".pyc", ".pyo")):
                continue
            fichiers.append(Path(racine) / n)
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in fichiers:
            info = zipfile.ZipInfo(f.relative_to(code).as_posix(), date_time=(2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, f.read_bytes())
    return buf.getvalue()


def publier(depot: str, notes: str = "", calcul: str = "", code: Path = CODE) -> dict:
    """Pose l'archive et derniere.json dans le depot (un dossier). Refuse si
    la version du code n'est pas plus recente que celle du depot : on ne
    republie pas un numero, on l'augmente d'abord dans VERSION."""
    if depot.startswith(("http://", "https://")):
        raise ValueError("publier ecrit dans un dossier ; pour un depot en ligne, "
                         "y deposer ensuite les deux fichiers")
    version = courante(code)
    if version == "0.0.0":
        raise ValueError("pas de fichier VERSION dans %s" % code)
    d = Path(depot)
    d.mkdir(parents=True, exist_ok=True)
    if (d / DERNIERE).exists():
        avant = derniere(str(d))
        if not plus_recente(version, avant["version"]):
            raise ValueError("le depot est deja en %s ; augmenter VERSION (%s) avant de publier"
                             % (avant["version"], version))
    octets = archiver(code)
    nom = "puppetpaie-%s.zip" % version
    (d / nom).write_bytes(octets)
    manifeste = {"version": version, "archive": nom,
                 "sha256": hashlib.sha256(octets).hexdigest(),
                 "publiee_le": _dt.date.today().isoformat(),
                 "notes": notes, "calcul": calcul}
    (d / DERNIERE).write_text(json.dumps(manifeste, ensure_ascii=False, indent=1) + "\n",
                              encoding="utf-8")
    return dict(manifeste, octets=len(octets), dossier=str(d))
