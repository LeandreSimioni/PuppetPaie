"""Le plafond de Securite sociale d'une periode d'emploi.

CE QUE C'EST. Le plafond de la Securite sociale (PSS) borne l'assiette des
cotisations dites plafonnees. Sur un mois complet il vaut le PSS mensuel ; sur
un contrat plus court il se proratise. CoolPaie l'imprime en bas du bulletin
sous « Plafond Urssaf ». Chez nous il ne mord jamais -- les bruts sont trop
petits -- et c'est pourquoi il n'apparait dans AUCUNE des 50 DSN deposees : la
rubrique S21.G00.79.001 = « 07 - Plafond de Securite Sociale applique » n'y est
jamais valorisee. C'est un affichage, pas une declaration.

LA REGLE, retrouvee sur les bulletins CoolPaie de 2021 a 2026 :

    plafond = max( PSS mensuel x jours calendaires du contrat / jours du mois,
                   PSS horaire x 12 h x nombre de cachets )

Le premier terme est le prorata de droit commun. Le second est un PLANCHER
propre aux artistes : chaque cachet emporte 12 heures de plafond, la meme
equivalence que l'annexe 10 (voir moteur/cumul.py). Un contrat d'un jour avec
un cachet garde donc son plafond de 12 heures, la ou le seul prorata
calendaire lui en donnerait le trentieme d'un mois.

Verifiee sur **29 bulletins CoolPaie sur 30**, de 2021 a 2026, chez DEUX
employeurs (Compagnia UEUEUE et AKD) et sur plusieurs versions du logiciel. Les
deux branches du `max` sont exercees, donc la regle est contrainte des deux
cotes et non ajustee sur un seul cas.

LA SEULE EXCEPTION, non expliquee : un bulletin AKD du 20 au 25/03/2023,
6 cachets, brut 1 250,00. CoolPaie y affiche 709,55 -- le prorata calendaire --
la ou la regle donne 1 944,00, le plancher. C'est le seul cas rencontre ou le
prorata l'emporte alors qu'il est INFERIEUR au plancher. Aucune hypothese
testee ne le distingue des autres : ni la version du logiciel, ni la duree, ni
le fait que le brut depasse le prorata (le bulletin PUPPIS du 24/05/2026 est
dans ce cas et suit pourtant le plancher). C'est note pour qu'un contre-exemple
futur ne passe pas pour une nouveaute -- et parce qu'une regle a 29/30 doit
dire ou elle echoue.

Detail de la verification, extraits :

| Bulletin                     | jours | cachets | prorata  | plancher | affiche  |
|------------------------------|-------|---------|----------|----------|----------|
| PUPPIS 01-02/07/2021         |  2/31 |    2    |   221,16 |   624,00 |   624,00 |
| SIMIONI 04-22/01/2021        | 19/31 |    9    | 2 101,16 | 2 808,00 | 2 808,00 |
| PUPPIS 16-25/11/2023         | 10/30 |    3    | 1 222,00 |   972,00 | 1 222,00 |
| PUPPIS 13-22/05/2026         | 10/31 |    1    | 1 291,94 |   360,00 | 1 291,94 |
| PUPPIS 24/05/2026            |  1/31 |    1    |   129,19 |   360,00 |   360,00 |

Les deux premieres lignes viennent d'une version de CoolPaie de 2021, la
troisieme de 2023, les deux dernieres de 2026 : la regle traverse les versions.

NE PAS CONFONDRE avec S21.G00.79.001 = « 01 », que le moteur appelait
« plafond » depuis le debut. La norme le definit comme le « Montant du SMIC
retenu pour le calcul de la Reduction generale des cotisations patronales » :
c'est le SMIC x heures, pas un plafond. La valeur etait juste -- elle rejoue au
centime -- mais le nom etait faux.
"""
from __future__ import annotations
import calendar
import datetime as _dt
from decimal import Decimal

from .util import d, eur

# Annexe 10 : un cachet emporte 12 heures.
HEURES_PAR_CACHET = 12

# Plafonds de la Securite sociale, metropole.
# Source : table des parametres du BOSS, reference/boss-table-parametres-2026.csv
# (codes PSS_M_METROP et PSS_H_METROP). A completer chaque janvier.
PSS_MENSUEL = {2021: 3428, 2022: 3428, 2023: 3666, 2024: 3864, 2025: 3925,
               2026: 4005}
PSS_HORAIRE = {2021: 26, 2022: 26, 2023: 27, 2024: 29, 2025: 29, 2026: 30}


class PlafondInconnu(Exception):
    """Pas de plafond connu pour cette annee : il faut le saisir."""


def _valeurs(annee: int) -> tuple[int, int]:
    if annee not in PSS_MENSUEL or annee not in PSS_HORAIRE:
        raise PlafondInconnu(
            "Pas de plafond de Securite sociale pour %d.\n"
            "Le relever sur la table des parametres du BOSS (codes "
            "PSS_M_METROP et PSS_H_METROP) et completer moteur/plafond.py."
            % annee)
    return PSS_MENSUEL[annee], PSS_HORAIRE[annee]


def prorata_calendaire(debut, fin) -> Decimal:
    """PSS mensuel x jours calendaires du contrat / jours du mois.

    Les deux bornes sont incluses : du 24 au 24 fait un jour. Un contrat a
    cheval sur deux mois est proratise mois par mois, puis somme.
    """
    debut, fin = d(debut), d(fin)
    if fin < debut:
        raise ValueError("fin %s anterieure au debut %s" % (fin, debut))
    total = Decimal("0")
    jour = debut
    while jour <= fin:
        dans_le_mois = calendar.monthrange(jour.year, jour.month)[1]
        derniere = _dt.date(jour.year, jour.month, dans_le_mois)
        borne = min(fin, derniere)
        jours = (borne - jour).days + 1
        mensuel, _ = _valeurs(jour.year)
        total += Decimal(mensuel) * Decimal(jours) / Decimal(dans_le_mois)
        jour = borne + _dt.timedelta(days=1)
    return total


def plancher_cachets(annee: int, cachets: int) -> Decimal:
    """PSS horaire x 12 h x nombre de cachets. Le plancher propre aux artistes.

    IL NE COMPTE QUE LES CACHETS, et c'est deliberement qu'il n'a pas ete
    etendu aux heures le 10/09/2026, quand la saisie par rubrique a rendu
    possible un contrat sans aucun cachet.

    La tentation etait d'ecrire PSS horaire x heures : ce serait la meme regle,
    dite en heures. Mais AUCUN des 30 bulletins releves ne permet de trancher.
    Le seul contrat mixte du lot -- PUPPIS 13-22/05/2026, un cachet plus 20
    heures -- a un prorata (1 291,94) qui ecrase les deux versions du plancher
    (360 avec les cachets seuls, 960 avec les heures) : il ne discrimine pas.

    Donc on s'en tient au releve. Un contrat sans cachet garde le prorata
    calendaire, qui est la regle de droit commun ; il n'y a pas d'invention,
    seulement un plancher qui ne s'applique pas. Le jour ou un bulletin
    CoolPaie mixte tranchera, ce sera ici, avec sa source.
    """
    _, horaire = _valeurs(annee)
    return Decimal(horaire) * HEURES_PAR_CACHET * Decimal(cachets)


def plafond_urssaf(debut, fin, cachets: int) -> Decimal:
    """Le « Plafond Urssaf » du bas de bulletin, arrondi au centime."""
    prorata = prorata_calendaire(debut, fin)
    plancher = plancher_cachets(d(fin).year, cachets)
    return eur(max(prorata, plancher))


def pour_paie(paie) -> Decimal:
    e = paie.engagement
    return plafond_urssaf(e.debut, e.fin, e.cachets)
