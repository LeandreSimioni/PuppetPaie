"""Client de l'API DSN de net-entreprises -- LECTURE SEULE.

Guide d'implementation de l'API DSN v6.8 du 06/07/2026, dans
reference/norme-dsn/. Les trois services utilises ici :

    POST https://services.net-entreprises.fr/authentifier/1.0/
    GET  https://consultation.dsnrg.net-entreprises.fr/lister-depots/1.0/<debut>[/<fin>]
    GET  https://consultation.dsnrg.net-entreprises.fr/lister-retours-declarant/1.0/<debut>[/<fin>]
    GET  <url renvoyee par la recherche>          (telechargement d'un retour)

CE MODULE NE DEPOSE RIEN. Il n'y a volontairement aucune fonction de depot :
le depot est une decision separee, et un fichier « transmis pour test mais code
comme reel est traite comme reel » (cahier technique). Tant que cet arbitrage
n'est pas rendu, la seule facon de deposer reste net-entreprises.fr a la main.

LE MOT DE PASSE. Le guide impose de le chiffrer s'il est stocke. CE MODULE N'EN
STOCKE AUCUN et n'en cherche aucun : on le lui passe (`Client(motdepasse=...)`),
ou il lit la variable d'environnement NET_ENTREPRISES_MOTDEPASSE. Il l'utilise
le temps d'une requete d'authentification et ne l'ecrit jamais : ni sur disque,
ni dans un journal, ni dans un message d'erreur, ni dans la ligne de commande
(ou il serait visible de tout le systeme et garde dans l'historique du shell).

    PowerShell, pour la session courante seulement :
        $env:NET_ENTREPRISES_MOTDEPASSE = (Read-Host "mot de passe")

Depuis le 11/09/2026 il existe un COFFRE (`moteur/coffre.py`), chiffre par le
compte Windows, qui permet au logiciel de relever les retours tout seul. Ce
module ne l'ouvre pas : c'est la couche qui a vu l'humain -- une commande, une
fenetre -- qui y puise et passe le resultat ici. Un test verifie que ce fichier
ne mentionne pas le coffre, parce que c'est cette separation qui fait qu'un
depot ne peut pas partir d'un secret ramasse tout seul.

Le jeton renvoye vaut pour une session limitee ; il reste en memoire.
"""
from __future__ import annotations
import datetime as _dt
import gzip
import json
import os
import urllib.error
import urllib.request
from pathlib import Path

VARIABLE_MOTDEPASSE = "NET_ENTREPRISES_MOTDEPASSE"

# Code du service Net-Entreprises (guide, section 3.1.1)
SERVICE_DSN_REGIME_GENERAL = "25"
SERVICE_DSN_REGIME_GENERAL_TEST = "97"

ADRESSES = {
    "production": {
        "authentification": "https://services.net-entreprises.fr/authentifier/1.0/",
        "depots": "https://consultation.dsnrg.net-entreprises.fr/lister-depots/1.0/",
        "retours": "https://consultation.dsnrg.net-entreprises.fr/lister-retours-declarant/1.0/",
        "retours_flux": "https://consultation.dsnrg.net-entreprises.fr/lister-retours-flux/1.0/",
        "fiches": "https://fpoc.net-entreprises.fr/lister-fiches-declarant/1.0/",
        "service": SERVICE_DSN_REGIME_GENERAL,
    },
    "editeur": {
        "authentification": "https://test-services.net-entreprises.fr/authentifier/1.0/",
        "depots": "https://consultation-edit.dsnrg.net-entreprises.fr/lister-depots/1.0/",
        "retours": "https://consultation-edit.dsnrg.net-entreprises.fr/lister-retours-declarant/1.0/",
        "retours_flux": "https://consultation-edit.dsnrg.net-entreprises.fr/lister-retours-flux/1.0/",
        "fiches": "https://test-fpoc.net-entreprises.fr/lister-fiches-declarant/1.0/",
        "service": SERVICE_DSN_REGIME_GENERAL_TEST,
    },
}

# Guide section 8.1 : identification obligatoire du logiciel de paie.
NOM_LOGICIEL = "PuppetPaie"
VERSION_LOGICIEL = "1.0"
EDITEUR = "Compagnia UEUEUE"
USER_AGENT = "Client-DSN (%s/%s; %s)" % (NOM_LOGICIEL, VERSION_LOGICIEL, EDITEUR)


class ErreurApi(Exception):
    """Erreur renvoyee par l'API, deja traduite en francais.

    `code` porte le statut HTTP quand il y en a un. Il sert a distinguer ce
    qu'un message ne distingue pas : un 404 sur une plage de consultation veut
    dire << rien sur cette plage >> (observe sur le service DPAE le
    12/09/2026), et un 401 veut dire qu'il faut s'arreter.
    """

    def __init__(self, message, code: int = 0):
        super().__init__(message)
        self.code = code


MESSAGES = {
    401: "Authentification refusee, ou declarant non inscrit au service DSN.",
    403: "Compte temporairement bloque (trop de tentatives), ou tentative "
         "d'acces a des donnees deposees par quelqu'un d'autre.",
    404: "Service ou identifiant inconnu. Peut aussi signaler une interruption "
         "de service.",
    406: "Format de reponse demande non supporte.",
    422: "Parametres invalides.",
    429: "Contraintes de consultation non respectees : trop d'appels, ou plage "
         "de recherche trop large. Attendre et relancer.",
    503: "Service indisponible.",
}


def _declarant(ent: dict) -> dict:
    """Identite du declarant inscrit au service DSN, telle que net-entreprises l'attend.

    Elle est deja dans config/entreprise.json sous `declarant_dsn.nom_prenom`
    (« NOM PRENOM » du declarant), qui alimente le bloc S10.G00.02 de chaque
    DSN. On la
    reutilise plutot que d'ajouter une deuxieme source de verite. Une cle
    `declarant` explicite, si elle existe, l'emporte.
    """
    if ent.get("declarant"):
        return ent["declarant"]
    brut = (ent.get("declarant_dsn") or {}).get("nom_prenom", "").strip()
    morceaux = brut.split()
    if len(morceaux) < 2:
        return {"siret": ent.get("siret")}
    return {"siret": ent.get("siret"), "nom": morceaux[0],
            "prenom": " ".join(morceaux[1:])}


def motdepasse_disponible(variable: str = VARIABLE_MOTDEPASSE) -> bool:
    return bool(os.environ.get(variable))


class Client:
    def __init__(self, ctx, environnement: str = "production",
                 motdepasse: str = None):
        """`motdepasse` : donne, il l'emporte sur la variable d'environnement.

        CE MODULE NE VA JAMAIS CHERCHER UN SECRET. Il en recoit un, ou il lit
        la variable d'environnement, et c'est tout : il n'ouvre pas le coffre
        (`moteur/coffre.py`), il ne sait meme pas qu'il existe. C'est la couche
        qui a vu l'humain -- une commande, une fenetre -- qui decide d'y puiser
        et passe le resultat ici. Un test verifie que ce fichier ne mentionne
        pas le coffre.

        Le mot de passe reste en memoire le temps de l'authentification et
        n'est jamais ecrit : ni sur disque, ni dans un journal, ni dans un
        message d'erreur, ni sur la ligne de commande.
        """
        if environnement not in ADRESSES:
            raise ValueError("environnement inconnu : %r" % environnement)
        self.ctx = ctx
        self.env = environnement
        self.adresses = ADRESSES[environnement]
        self._motdepasse = motdepasse
        # Quelle variable d'environnement porte le mot de passe. La DPAE en a
        # une autre : ce n'est pas le meme compte (voir dpae_api.py).
        self.variable_motdepasse = VARIABLE_MOTDEPASSE
        self.jeton = None
        self.expire_le = None
        self.declarant = _declarant(ctx.entreprise)

    # ------------------------------------------------------------ transport
    def _appel(self, url: str, donnees: bytes = None,
               content_type: str = None) -> tuple[bytes, dict]:
        entetes = {"User-Agent": USER_AGENT, "Accept-Encoding": "gzip"}
        if content_type:
            entetes["Content-Type"] = content_type
        if self.jeton:
            entetes["Authorization"] = "DSNLogin jeton=%s" % self.jeton
        req = urllib.request.Request(url, data=donnees, headers=entetes,
                                     method="POST" if donnees else "GET")
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                brut = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    brut = gzip.decompress(brut)
                return brut, dict(r.headers)
        except urllib.error.HTTPError as e:
            detail = MESSAGES.get(e.code, "")
            corps = ""
            try:
                corps = e.read().decode("utf-8", "replace")[:400]
            except Exception:
                pass
            raise ErreurApi("HTTP %d sur %s\n  %s%s"
                            % (e.code, _sans_secret(url), detail,
                               ("\n  " + corps) if corps.strip() else ""),
                            code=e.code) from None
        except urllib.error.URLError as e:
            raise ErreurApi("Reseau injoignable pour %s : %s"
                            % (_sans_secret(url), e.reason)) from None

    # -------------------------------------------------------- authentification
    def authentifier(self) -> None:
        """Ouvre une session. Le mot de passe ne survit pas a cet appel."""
        mdp = self._motdepasse or os.environ.get(self.variable_motdepasse)
        if not mdp:
            raise ErreurApi(
                "Mot de passe absent.\n"
                "Trois facons de le fournir, dans cet ordre de priorite :\n\n"
                "  1. le passer a Client(motdepasse=...) -- ce que font les\n"
                "     fenetres et les commandes apres avoir vu l'humain ;\n"
                "  2. la variable d'environnement %s ;\n"
                "     PowerShell :  $env:%s = (Read-Host \"mot de passe\")\n"
                "  3. le coffre, pour les lectures automatiques :\n"
                "     python -m moteur coffre poser net-entreprises\n"
                % (self.variable_motdepasse, self.variable_motdepasse))
        manquants = [c for c in ("siret", "nom", "prenom") if not self.declarant.get(c)]
        if manquants:
            raise ErreurApi(
                "Identite du declarant incomplete dans config/entreprise.json :\n"
                "  \"declarant\": {\"siret\": ..., \"nom\": ..., \"prenom\": ...}\n"
                "Manque : %s.\n"
                "Ce sont le SIRET, le nom et le prenom inscrits au service DSN\n"
                "sur net-entreprises.fr (sans accent)." % ", ".join(manquants))
        # Le code service designe la teleprocedure (25 = DSN regime general).
        # L'API DPAE a son propre point d'authentification ; le code qui lui
        # correspond n'est pas publie dans son guide, d'ou `service` a None,
        # qui fait tomber la balise. Voir dpae_api.py.
        service = self.adresses.get("service")
        corps = ("<identifiants>"
                 "<siret>%s</siret><nom>%s</nom><prenom>%s</prenom>"
                 "<motdepasse>%s</motdepasse>%s"
                 "</identifiants>") % (
            self.declarant["siret"], self.declarant["nom"],
            self.declarant["prenom"], _echapper(self._preparer_motdepasse(mdp)),
            ("<service>%s</service>" % service) if service else "")
        try:
            brut, entetes = self._appel(self.adresses["authentification"],
                                        corps.encode("utf-8"), "application/xml")
        finally:
            corps = None
            mdp = None
        self.jeton = brut.decode("ascii", "replace").strip()
        self.expire_le = entetes.get("Expires")

    def _preparer_motdepasse(self, mdp: str) -> str:
        """Dernier passage avant l'envoi. Rien a faire pour la DSN.

        La DPAE, elle, a ses propres exigences : voir `dpae_api.ClientDpae`.
        """
        return mdp

    def _assurer_session(self) -> None:
        if not self.jeton:
            self.authentifier()

    # ------------------------------------------------------------- services
    def lister_depots(self, debut: _dt.datetime, fin: _dt.datetime = None) -> list[dict]:
        from .retours import parse_liste_depots
        brut, _ = self._consulter(self.adresses["depots"], debut, fin)
        return parse_liste_depots(brut)

    def lister_retours(self, debut: _dt.datetime, fin: _dt.datetime = None) -> list[dict]:
        from .retours import parse_liste_retours
        brut, _ = self._consulter(self.adresses["retours"], debut, fin)
        return parse_liste_retours(brut)

    def lister_retours_du_flux(self, idflux: str) -> list[dict]:
        from .retours import parse_liste_retours
        self._assurer_session()
        brut, _ = self._appel(self.adresses["retours_flux"] + idflux)
        return parse_liste_retours(brut)

    def lister_fiches_parametrage(self, debut: _dt.datetime,
                                  fin: _dt.datetime = None) -> bytes:
        brut, _ = self._consulter(self.adresses["fiches"], debut, fin)
        return brut

    def _consulter(self, base: str, debut, fin=None) -> tuple[bytes, dict]:
        self._assurer_session()
        url = base + _horodatage(debut)
        if fin is not None:
            url += "/" + _horodatage(fin)
        return self._appel(url)

    def telecharger(self, url: str) -> tuple[bytes, str]:
        """Recupere un retour. Renvoie (contenu brut, type de contenu)."""
        self._assurer_session()
        brut, entetes = self._appel(url)
        return brut, entetes.get("Content-Type", "")


# ------------------------------------------------------------------ archivage
def dossier_archive(ctx, canal: str = "") -> Path:
    """Ou s'archivent les retours d'un canal.

    `canal` vide : la DSN, dans `retours/` -- c'est l'historique, et on ne le
    deplace pas. Tout autre canal a son SOUS-DOSSIER, et ce n'est pas du
    rangement : les natures de retour se RESSEMBLENT d'un canal a l'autre.
    L'API DPAE a elle aussi une nature 10 et une nature 11, qui ne veulent pas
    dire la meme chose que celles de la DSN. Melangees dans un meme dossier,
    un certificat de conformite de DPAE se lirait comme un bilan de DSN -- et
    la reprise du journal (operations.depots_attestes) fabriquerait une ligne
    de DSN a partir d'une declaration d'embauche.
    """
    p = ctx.racine / "retours"
    if canal:
        p = p / canal
    p.mkdir(parents=True, exist_ok=True)
    return p


def archiver(ctx, retour: dict, contenu: bytes, content_type: str,
             canal: str = "") -> Path:
    """Ecrit un retour tel quel, avant toute analyse. C'est la piece justificative.

    Nom : AAAAMMJJ-HHMMSS_nature_flux.ext -- lisible et triable a l'oeil.
    """
    ext = ".pdf" if "pdf" in content_type else (
        ".xml" if "xml" in content_type or contenu[:200].lstrip().startswith(b"<")
        else ".txt")
    pub = (retour.get("publication") or "")[:14]
    horo = ("%s-%s" % (pub[:8], pub[8:14])) if len(pub) == 14 else \
        _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    nom = "%s_nature%s_%s%s" % (horo, retour.get("nature", "??"),
                                (retour.get("flux") or "sansflux")[:24], ext)
    dest = dossier_archive(ctx, canal) / nom
    if not dest.exists():
        dest.write_bytes(contenu)
    return dest


def journal(ctx, canal: str = "") -> Path:
    return dossier_archive(ctx, canal) / "journal.json"


def noter(ctx, entrees: list[dict], canal: str = "") -> None:
    """Tient la liste de ce qui a ete vu, pour ne pas retelecharger."""
    p = journal(ctx, canal)
    deja = json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
    connus = {(e.get("flux"), e.get("nature"), e.get("publication")) for e in deja}
    for e in entrees:
        if (e.get("flux"), e.get("nature"), e.get("publication")) not in connus:
            deja.append(e)
    p.write_text(json.dumps(deja, ensure_ascii=False, indent=2), encoding="utf-8")


def deja_vus(ctx, canal: str = "") -> set:
    p = journal(ctx, canal)
    if not p.exists():
        return set()
    return {(e.get("flux"), e.get("nature"), e.get("publication"))
            for e in json.loads(p.read_text(encoding="utf-8"))}


# --------------------------------------------------------------------- outils
def _horodatage(x) -> str:
    if isinstance(x, str):
        return x
    return x.strftime("%Y%m%d%H%M%S")


def _echapper(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _sans_secret(url: str) -> str:
    """Ne jamais laisser filtrer un identifiant dans un message d'erreur."""
    return url.split("?", 1)[0]
