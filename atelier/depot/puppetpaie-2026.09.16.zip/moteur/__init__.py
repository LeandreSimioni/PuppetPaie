"""Moteur de paie intermittents - Compagnia UEUEUE."""
__all__ = ["util", "contexte", "calcul", "bulletin", "aem", "dsn", "contrat", "dpae"]
