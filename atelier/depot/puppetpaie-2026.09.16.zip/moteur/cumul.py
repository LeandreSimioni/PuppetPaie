"""Cumuls : ce qui s'accumule d'un bulletin a l'autre.

Deux usages, et il ne faut pas les confondre.

1. LE CUMUL DE PAIE, celui que CoolPaie imprime en bas du bulletin. Fenetre =
   annee civile. Sert a la paie et aux declarations : brut, cout employeur, net
   imposable, plafond. Il repart a zero le 1er janvier, et c'est normal.

2. LES DROITS A L'ASSURANCE CHOMAGE. Fenetre = les 12 mois precedant la fin du
   dernier contrat retenu (annexes 8 et 10). Elle ne coincide avec aucune annee
   civile, et c'est exactement pour cela qu'on ne peut pas lire l'un pour
   l'autre : au 1er janvier le cumul de paie repart de zero alors que les
   droits, eux, continuent de courir.

LE COMPTE D'HEURES. Un artiste declare parfois des heures, parfois des cachets,
parfois les deux sur un meme contrat. Le total qui compte est la SOMME des deux,
le cachet isole valant 12 heures en annexe 10 :

    heures equivalentes = heures declarees + 12 x cachets isoles

Compter les cachets sans les heures, ou l'inverse, sous-estime la position.

LA SOURCE DES HEURES : NOS DONNEES, ET RIEN D'AUTRE (depuis le 15/09/2026).

Deux fichiers, et une regle pour les departager :

    historique/engagements.json   les contrats attestes AVANT ce logiciel --
                                  les AEM de CoolPaie, importees une fois
                                  (`python -m moteur importer`). Ce sont les
                                  documents que France Travail a effectivement
                                  recus pendant cinq ans ; ils ne se
                                  reconstituent pas.
    paies/AAAA-MM.json            les mois produits par ce logiciel. Depuis
                                  le 01/06/2026 la compagnie est en 100 % DSN :
                                  il n'y a plus d'AEM, c'est France Travail qui
                                  edite l'attestation a partir de la DSN. La
                                  saisie de paie EST donc ce qui a ete declare.

    Un mois qui a son fichier de paie est lu LA, et l'historique se tait pour
    ce mois-la. Pendant le double run (aout 2026 : CoolPaie et ce logiciel
    ont tous deux declare), les deux disent la meme chose -- c'est verifie --
    et c'est le fichier de paie qui compte, une seule fois.

Jusqu'au 15/09/2026 ce module lisait `export/AEM_EDI`, le dossier de
CoolPaie, directement. Cela liait les droits a un logiciel qu'on resilie en
janvier 2027, et laissait de cote les mois produits ici. `lire_aem` reste :
c'est lui qui depouille un dossier d'AEM (l'import s'en sert, et nos propres
AEM de `sorties/`), mais plus personne ne l'appelle pour les droits.

Voir moteur/aem.py pour le decoupage des enregistrements.

LES AUTRES EMPLOYEURS. Un intermittent travaille rarement pour une seule
compagnie, et le seuil se compte sur TOUT ce qu'il a declare, tous employeurs
confondus. Ce module ne compte QUE les AEM de la compagnie, deliberement : c'est
a chaque salarie d'ajouter ses autres employeurs, sur son propre releve. Le
total rendu ici est donc un PLANCHER, et il est affiche comme tel -- ce n'est
pas la position reelle et il ne faut pas le lire comme telle.
"""
from __future__ import annotations
import datetime as _dt
import glob
import json
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path

from .aem import CHAMPS
from . import catalogue as cat

# Equivalence horaire d'un cachet. Elle ne vit plus ici : elle est une donnee
# du catalogue, avec sa source (annexe X, art. 3), comme tout ce qui change
# sans nous. Le nom reste, parce que la ligne de commande s'en sert.
#
# Il n'y a PLUS de cachet groupe a 8 heures : le decret du 13 juillet 2016 a
# supprime la distinction isole / groupe, et tous les cachets valent 12
# heures quelle que soit la duree du contrat. La constante a 8 qui vivait ici
# a ete retiree le 10/09/2026 -- le catalogue de CoolPaie la porte encore.
HEURES_PAR_CACHET = int(cat.rubrique("cachet").heures_forfait)
HEURES_PAR_CACHET_ISOLE = HEURES_PAR_CACHET      # ancien nom, meme valeur

# Seuil d'ouverture ou de renouvellement des droits, annexes VIII et X.
SEUIL_HEURES = 507

# LES HEURES D'ENSEIGNEMENT : deux decomptes, et non un.
#
# Elles font atteindre les 507 heures -- dans la limite de 70 h avant 50 ans,
# 120 h a partir de 50 ans -- mais elles n'entrent PAS dans le calcul du
# MONTANT de l'ARE. Les fondre dans le total annoncerait une allocation plus
# elevee qu'elle ne sera. D'ou deux totaux ici : `heures_ouverture`, qui les
# retient dans la limite du plafond, et `heures_montant`, qui les ecarte.
#
# L'AEM ne sait pas les distinguer : une masterclass que nous payons tombe
# dans les memes trois positions [650:653] qu'une heure de plateau. Ce qui
# sait, c'est le fichier de paie, ou chaque ligne porte sa rubrique et ou le
# catalogue dit `compte_pour`. On lit donc le TOTAL dans l'AEM -- le document
# depose fait foi -- et la PART d'enseignement dans les paies, rapprochee par
# contrat (salarie, debut, fin).
#
# Les heures enseignees chez un AUTRE employeur ne sont dans aucun de nos deux
# fichiers ; elles manquent comme manquent ses autres cachets. Le total rendu
# ici reste un plancher.


def plafond_enseignement(date_naissance, a_la_date: _dt.date) -> int:
    """Heures d'enseignement retenables : 70 h, ou 120 h a partir de 50 ans.

    L'age retenu est celui a la fin du contrat servant a l'ouverture des
    droits -- donc a la fin de la fenetre. Le plafond lui-meme vient du
    catalogue, avec sa source : ce n'est pas au moteur de le porter.

    Sans date de naissance, on retient le plafond le plus BAS. Une position
    sous-estimee se corrige en regardant le releve ; une position surestimee
    fait rater un reexamen.
    """
    p = cat.rubrique("enseignement").plafond_annuel_heures or {}
    bas = int(p.get("moins_de_50_ans", 0))
    haut = int(p.get("50_ans_et_plus", bas))
    if not date_naissance:
        return bas
    age = (a_la_date.year - date_naissance.year
           - ((a_la_date.month, a_la_date.day)
              < (date_naissance.month, date_naissance.day)))
    return haut if age >= 50 else bas


@dataclass
class Engagement:
    """Une ligne d'AEM, telle qu'elle a ete declaree."""
    salarie: str
    debut: _dt.date
    fin: _dt.date
    numero_objet: str
    heures: int
    cachets: int
    jours: int
    brut: Decimal
    # Part des `heures` ci-dessus qui est de l'enseignement. Elle est DEDANS,
    # pas en plus : l'AEM les a declarees avec les autres. Zero par defaut,
    # c'est-a-dire tant que le fichier de paie ne dit pas le contraire.
    heures_enseignement: int = 0

    @property
    def heures_equivalentes(self) -> int:
        """Heures declarees PLUS cachets convertis. Le total, tel que declare."""
        return self.heures + self.cachets * HEURES_PAR_CACHET_ISOLE

    @property
    def heures_montant(self) -> int:
        """Ce qui entre dans le calcul du montant de l'ARE : tout sauf
        l'enseignement."""
        return self.heures_equivalentes - self.heures_enseignement


@dataclass
class Position:
    """Etat d'un salarie sur une fenetre donnee."""
    salarie: str
    debut: _dt.date
    fin: _dt.date
    libelle_fenetre: str
    engagements: list = field(default_factory=list)
    # Pour le plafond d'enseignement : l'age a la fin de la fenetre. Absente,
    # le plafond bas s'applique -- voir plafond_enseignement().
    date_naissance: _dt.date = None

    @property
    def cachets(self) -> int:
        return sum(e.cachets for e in self.engagements)

    @property
    def heures(self) -> int:
        return sum(e.heures for e in self.engagements)

    @property
    def heures_equivalentes(self) -> int:
        """Le total declare, enseignement compris. Ce que disent les AEM."""
        return sum(e.heures_equivalentes for e in self.engagements)

    @property
    def heures_enseignement(self) -> int:
        """La part d'enseignement de ces heures-la, telle que les fichiers de
        paie la disent. Elle est DEDANS `heures`, pas en plus."""
        return sum(e.heures_enseignement for e in self.engagements)

    @property
    def plafond_enseignement(self) -> int:
        """70 h, ou 120 h a partir de 50 ans a la fin de la fenetre."""
        return plafond_enseignement(self.date_naissance, self.fin)

    @property
    def heures_enseignement_retenues(self) -> int:
        """Ce que le plafond laisse passer. Le reste est enseigne, paye,
        declare -- et sans effet sur les droits."""
        return min(self.heures_enseignement, self.plafond_enseignement)

    @property
    def heures_montant(self) -> int:
        """Les heures qui entrent dans le calcul du MONTANT de l'ARE :
        tout sauf l'enseignement."""
        return self.heures_equivalentes - self.heures_enseignement

    @property
    def heures_ouverture(self) -> int:
        """Les heures qui comptent pour les 507. C'est ce total que le seuil
        regarde -- l'enseignement y entre, plafonne."""
        return self.heures_montant + self.heures_enseignement_retenues

    @property
    def enseignement_perdu(self) -> int:
        """Heures d'enseignement au-dela du plafond. A dire, plutot que de
        laisser croire qu'elles comptent."""
        return self.heures_enseignement - self.heures_enseignement_retenues

    @property
    def jours(self) -> int:
        return sum(e.jours for e in self.engagements)

    @property
    def brut(self) -> Decimal:
        return sum((e.brut for e in self.engagements), Decimal("0.00"))

    @property
    def manque(self) -> int:
        """Heures restant a acquerir pour atteindre le seuil. 0 si atteint.

        Compte sur `heures_ouverture` : l'enseignement compte pour le seuil,
        dans la limite de son plafond.
        """
        return max(0, SEUIL_HEURES - self.heures_ouverture)

    @property
    def atteint(self) -> bool:
        return self.heures_ouverture >= SEUIL_HEURES

    def jours_restants(self, aujourdhui: _dt.date = None) -> int:
        """Jours restant avant la fin de la fenetre. Negatif si elle est passee."""
        return (self.fin - (aujourdhui or _dt.date.today())).days

    def cachets_manquants(self) -> int:
        """Nombre de cachets isoles a jouer pour combler le manque."""
        return -(-self.manque // HEURES_PAR_CACHET_ISOLE)


# ------------------------------------------------------------------- lecture
def _champ(ligne: str, nom: str) -> str:
    a, b = CHAMPS[nom]
    return ligne[a:b]


def lire_aem(ctx, dossier=None, enseignement=None) -> list[Engagement]:
    """Depouille les AEM deposees. Dedoublonne : un meme contrat peut avoir ete
    reedite plusieurs fois (rectificatifs, reimpressions).

    `enseignement` : la part d'enseignement par contrat. Elle est lue dans les
    fichiers de paie par defaut -- et c'est voulu qu'elle le soit sans qu'on
    ait a le demander : un appelant qui l'oublierait obtiendrait des heures
    d'enseignement comptees comme des heures de plateau, donc un montant d'ARE
    annonce trop haut, sans que rien ne le signale. Passer {} pour s'en
    passer explicitement.
    """
    dossier = Path(dossier or (ctx.export / "AEM_EDI"))
    ens = enseignement_par_contrat(ctx) if enseignement is None else enseignement
    par_nir = {s["nir"]: cle for cle, s in ctx.salaries.items()}
    vus = {}
    for f in sorted(glob.glob(str(dossier / "*.txt"))):
        data = Path(f).read_text(encoding="latin-1", errors="replace")
        # Un enregistrement par LIGNE (1000 caracteres + CRLF, voir aem.ecrire).
        # Les decouper par offsets fixes de 1000 fait deriver de 2 octets par
        # enregistrement : le premier tombe juste, les suivants sont illisibles
        # et disparaissent en silence. C'est arrive.
        for ligne in data.splitlines():
            if len(ligne) < 700:
                continue
            cle = par_nir.get(_champ(ligne, "nir")[:13])
            if not cle:
                continue
            try:
                debut = _dt.datetime.strptime(_champ(ligne, "date_debut"), "%Y%m%d").date()
                fin = _dt.datetime.strptime(_champ(ligne, "date_fin"), "%Y%m%d").date()
                heures = int(_champ(ligne, "nb_heures"))
                cachets = int(_champ(ligne, "nb_cachets"))
                jours = int(_champ(ligne, "nb_jours"))
                brut = Decimal(_champ(ligne, "brut_cts")) / 100
            except ValueError:
                continue
            objet = _champ(ligne, "numero_objet").strip()
            vus[(cle, debut, fin, objet, heures, cachets, jours, brut)] = None
    return [Engagement(*k, heures_enseignement=min(
        ens.get((k[0], k[1], k[2]), 0), k[4])) for k in sorted(vus)]


def _heures_enseignement(ctx, lignes) -> int:
    """La part d'enseignement d'une liste de lignes de paie, en heures
    entieres : les rubriques dont le catalogue dit `compte_pour =
    ouverture_des_droits`."""
    heures = 0.0
    for l in lignes or ():
        r = cat.rubrique(l["rubrique"], ctx)
        if r.compte_pour != "ouverture_des_droits":
            continue
        heures += float(r.heures(float(l["quantite"]), l.get("heures")))
    return int(round(heures))


def lire_historique(ctx) -> list[Engagement]:
    """Les contrats attestes avant ce logiciel, tels que l'import les a
    ecrits (operations_importation). Vide tant qu'on n'a rien importe."""
    from .util import d as _jour
    from .operations_importation import lire_historique as _lire

    out = []
    for e in _lire(ctx)["engagements"]:
        try:
            out.append(Engagement(
                salarie=e["salarie"], debut=_jour(e["debut"]), fin=_jour(e["fin"]),
                numero_objet=e.get("numero_objet", ""),
                heures=int(e.get("heures", 0)), cachets=int(e.get("cachets", 0)),
                jours=int(e.get("jours", 0)), brut=Decimal(str(e.get("brut", "0"))),
                heures_enseignement=int(e.get("heures_enseignement", 0))))
        except (KeyError, ValueError, TypeError):
            continue                      # une ligne abimee ne fait pas tomber les autres
    return out


def engagements_des_paies(ctx, paies_courantes=None) -> tuple:
    """Ce que nos fichiers de paie declarent : (engagements, mois couverts).

    Chaque fichier de `paies/` est charge comme le ferait une production
    (`operations.charger`, sans reserver de numero) : un seul chemin de
    calcul, donc les memes cachets, heures et brut que le bulletin et la
    DSN. Un fichier qui ne se charge pas -- un brouillon en cours, un mois
    sans bareme -- est laisse de cote, et son mois n'est pas couvert : c'est
    l'historique qui parlera pour lui, s'il a quelque chose a dire.

    `paies_courantes` : les paies du mois qu'on est en train de produire,
    deja calculees. Elles remplacent le fichier de leur mois -- c'est ce que
    le bulletin imprime, et il n'a pas a relire le disque pour se compter
    lui-meme.

    Les bornes d'un engagement sont celles de sa PERIODE DE PAIE, le contrat
    borne au mois : un contrat d'octobre a decembre compte ses cachets
    d'octobre en octobre, pas en decembre. Un mois du contrat sans cachet ne
    compte rien.
    """
    from .operations_paies import charger
    from .operations_socle import ErreurOperation

    couverts, par_mois = set(), {}
    if paies_courantes:
        for p in paies_courantes:
            par_mois.setdefault(p.engagement.mois, []).append(p)
    dossier = Path(ctx.racine) / "paies"
    for f in sorted(dossier.glob("*.json")) if dossier.is_dir() else ():
        if f.stem in par_mois or len(f.stem) != 7:
            continue
        try:
            par_mois[f.stem] = charger(ctx, f, sans_numeros=True).paies
        except (ErreurOperation, ValueError, KeyError, FileNotFoundError):
            continue
    out = []
    for mois, paies in par_mois.items():
        couverts.add(mois)
        for p in paies:
            e = p.engagement
            if e.sans_paie:
                continue
            out.append(Engagement(
                salarie=p.salarie["_cle"], debut=e.debut_periode, fin=e.fin_periode,
                numero_objet=p.spectacle.get("numero_objet", ""),
                heures=int(round(float(e.heures or 0))), cachets=int(e.cachets),
                jours=int(e.jours or 0), brut=Decimal(str(p.brut)),
                heures_enseignement=min(_heures_enseignement(ctx, e.lignes),
                                        int(round(float(e.heures or 0))))))
    return out, couverts


def lire_engagements(ctx, paies_courantes=None) -> list[Engagement]:
    """TOUT ce que la compagnie a declare : l'historique importe, puis nos
    paies -- et pour un mois qui a les deux, les paies seulement."""
    des_paies, couverts = engagements_des_paies(ctx, paies_courantes)
    anciens = [e for e in lire_historique(ctx)
               if e.fin.strftime("%Y-%m") not in couverts]
    return sorted(anciens + des_paies, key=lambda e: (e.debut, e.fin, e.salarie))


def enseignement_par_contrat(ctx, dossier=None) -> dict:
    """{(salarie, debut, fin): heures d'enseignement} lu dans les paies.

    L'AEM ne distingue pas une heure de masterclass d'une heure de plateau :
    les deux tombent dans `nb_heures`. Le fichier de paie, lui, porte la
    rubrique de chaque ligne, et le catalogue dit laquelle ne compte que pour
    l'ouverture des droits. C'est donc lui qu'on interroge, contrat par
    contrat.

    Le rapprochement se fait sur (salarie, debut, fin), qui sont exactement
    les dates que l'AEM a recopiees de l'engagement. Une saisie sans AEM
    correspondante -- un mois prepare, pas encore depose -- ne compte pas :
    ces heures ne sont pas declarees.

    Les heures sont arrondies a l'entier : l'AEM ne declare que des heures
    entieres, une demi-heure d'enseignement n'y est pas distinguable.
    """
    from .util import d as _jour

    dossier = Path(dossier or (Path(ctx.racine) / "paies"))
    out = {}
    if not dossier.is_dir():
        return out
    for f in sorted(dossier.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except ValueError:
            continue                      # brouillon en cours d'edition
        for e in data.get("engagements", ()):
            lignes = e.get("lignes")
            if not lignes:
                continue
            heures = _heures_enseignement(ctx, lignes)
            if not heures:
                continue
            # Les jours peuvent venir de l'engagement (l'ancienne ecriture)
            # ou des lignes de paie (la neuve, 12/09/2026) : `util.d` lit les
            # deux formes de date, `dates_engagement` sait ou les chercher.
            from .operations import dates_engagement
            dates = sorted(_jour(x) for x in dates_engagement(e))
            if not dates:
                continue
            debut = _jour(e["debut"]) if e.get("debut") else dates[0]
            fin = _jour(e["fin"]) if e.get("fin") else dates[-1]
            cle = ctx.salarie(e["salarie"])["_cle"]
            k = (cle, debut, fin)
            out[k] = out.get(k, 0) + heures
    return out


# ------------------------------------------------------------------ fenetres
def fenetre_annee_civile(annee: int) -> tuple:
    return (_dt.date(annee, 1, 1), _dt.date(annee, 12, 31),
            "annee civile %d" % annee)


def fenetre_douze_mois(fin: _dt.date) -> tuple:
    """Les 12 mois precedant une date. La fenetre des annexes 8 et 10."""
    return (fin - _dt.timedelta(days=365), fin,
            "12 mois au %s" % fin.strftime("%d/%m/%Y"))


def fenetre_anniversaire(anniversaire: _dt.date) -> tuple:
    """Les 12 mois PRECEDANT la date anniversaire des droits.

    L'anniversaire est la date de reexamen : les 507 heures se comptent sur les
    douze mois qui la precedent. C'est donc la FIN de la fenetre, pas son debut
    -- l'erreur inverse ferait compter une periode qui n'a pas encore eu lieu.

    Quand France Travail a notifie cette date, elle prime sur toute deduction.
    """
    return (anniversaire - _dt.timedelta(days=365), anniversaire,
            "12 mois au %s (anniversaire des droits)"
            % anniversaire.strftime("%d/%m/%Y"))


def position(engagements: list, salarie: str, fenetre: tuple,
             date_naissance=None) -> Position:
    debut, fin, libelle = fenetre
    dedans = [e for e in engagements
              if e.salarie == salarie and debut <= e.fin <= fin]
    return Position(salarie=salarie, debut=debut, fin=fin,
                    libelle_fenetre=libelle, engagements=dedans,
                    date_naissance=date_naissance)


def naissance(ctx, salarie: str):
    """Date de naissance du salarie, ou None. Sert au plafond d'enseignement."""
    from .util import d
    v = (ctx.salaries.get(salarie) or {}).get("date_naissance")
    return d(v) if v else None


def derniere_fin(engagements: list, salarie: str):
    """Fin du dernier contrat declare. Point de depart de la fenetre par defaut."""
    fins = [e.fin for e in engagements if e.salarie == salarie]
    return max(fins) if fins else None


def position_droits(ctx, salarie: str, engagements=None,
                    anniversaire=None, a_la_date=None) -> Position:
    """Position au regard des annexes 8 et 10.

    `anniversaire` : date de reexamen notifiee par France Travail, si elle est
    connue. Elle prime, et la fenetre est alors les 12 mois qui la precedent.
    A defaut, la fenetre est celle des 12 mois precedant la fin du dernier
    contrat declare -- une approximation raisonnable, pas la regle officielle,
    qui depend du contrat retenu pour l'examen des droits.
    """
    engagements = engagements if engagements is not None else lire_engagements(ctx)
    if anniversaire:
        f = fenetre_anniversaire(anniversaire)
    else:
        fin = a_la_date or derniere_fin(engagements, salarie) or _dt.date.today()
        f = fenetre_douze_mois(fin)
    return position(engagements, salarie, f, naissance(ctx, salarie))


# ------------------------------------------------------- bloc du bulletin
@dataclass
class Colonne:
    """Une colonne du bloc de cumul imprime en bas du bulletin."""
    titre: str
    sous_titre: str
    cachets: int
    heures: int
    heures_equivalentes: int
    brut: Decimal
    reste: int = None          # heures restantes avant le seuil, colonne droits
    echeance: _dt.date = None  # date d'anniversaire, colonne droits
    # L'enseignement, quand il y en a. `heures_equivalentes` le contient ;
    # ces deux-la disent ce qu'il devient. Zero partout tant que la compagnie
    # n'a paye aucune masterclass -- le bloc du bulletin ne change pas.
    enseignement: int = 0
    heures_ouverture: int = None


def tableau_cumul(ctx, salarie: str, mois: str, engagements=None,
                  aujourdhui: _dt.date = None) -> list[Colonne]:
    """Les trois colonnes : le mois, l'annee civile, la fenetre des droits.

    - PERIODE : le mois du bulletin.
    - CUMUL : l'annee civile, comme CoolPaie. Repart a zero le 1er janvier.
    - DROITS : les 12 mois precedant la date anniversaire, et ce qui reste a
      acquerir. C'est la colonne qui repond a « combien il m'en reste ».

    Les trois ne se recouvrent pas : c'est voulu, et c'est tout l'interet de les
    mettre cote a cote.
    """
    engagements = engagements if engagements is not None else lire_engagements(ctx)
    annee, mo = int(mois[:4]), int(mois[5:7])
    aujourdhui = aujourdhui or _dt.date.today()

    debut_mois = _dt.date(annee, mo, 1)
    fin_mois = (_dt.date(annee + (mo == 12), (mo % 12) + 1, 1)
                - _dt.timedelta(days=1))
    ne = naissance(ctx, salarie)
    p_mois = position(engagements, salarie, (debut_mois, fin_mois, "periode"), ne)
    p_annee = position(engagements, salarie, fenetre_annee_civile(annee), ne)

    def _col(titre, sous_titre, p, **kw):
        return Colonne(titre, sous_titre, p.cachets, p.heures,
                       p.heures_equivalentes, p.brut,
                       enseignement=p.heures_enseignement,
                       heures_ouverture=p.heures_ouverture, **kw)

    colonnes = [
        _col("Periode", "%02d/%d" % (mo, annee), p_mois),
        _col("Cumul", "annee %d" % annee, p_annee),
    ]

    anniv = anniversaire_configure(ctx, salarie)
    if anniv:
        p_droits = position(engagements, salarie, fenetre_anniversaire(anniv), ne)
        colonnes.append(_col("Droits", "au %s" % anniv.strftime("%d/%m/%Y"),
                             p_droits, reste=p_droits.manque, echeance=anniv))
    return colonnes


def anniversaire_configure(ctx, salarie: str):
    """Date anniversaire des droits, si elle est dans config/salaries.json.

    Cle attendue : "anniversaire_droits": "AAAA-MM-JJ". Absente tant que France
    Travail ne l'a pas notifiee -- on ne l'invente pas.
    """
    from .util import d
    v = ctx.salaries.get(salarie, {}).get("anniversaire_droits")
    return d(v) if v else None
