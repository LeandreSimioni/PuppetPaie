"""DSN mensuelle - norme NEODeS P26V01.

Le fichier est une suite de lignes `RUBRIQUE,'valeur'`. La structure produite
ici reprend l'ordre des blocs des DSN deja deposees ; `python -m moteur
calibrer` rejoue les mois passes et signale toute ligne qui differerait de ce
que CoolPaie avait produit.
"""
from __future__ import annotations
import calendar
import json
import math
from collections import OrderedDict
from decimal import Decimal
import re
from pathlib import Path

from . import champs, pas
from .util import eur, pct, jjmmaaaa, d

NORME = "P26V01"
LOGICIEL = "PUPPETPAIE"
VERSION = "1.0.0"


class Fichier:
    """Accumulateur de lignes DSN."""

    def __init__(self):
        self.lignes: list[str] = []

    def add(self, rubrique: str, valeur) -> None:
        self.lignes.append("%s,'%s'" % (rubrique, valeur))

    def texte(self) -> str:
        return "\r\n".join(self.lignes) + "\r\n"


def _mt(x) -> str:
    return "%.2f" % Decimal(str(x))


def _qt(x) -> str:
    return "%.2f" % Decimal(str(x))


def _bases(paie, bar) -> dict:
    bases = {
        "brut": paie.brut,
        "csg": paie.base_csg,
        "brut_x115": eur(paie.brut * Decimal(str(bar["majoration_conges_115"]))),
        "brut_x110": eur(paie.brut * Decimal(str(bar["majoration_conges_110"]))),
        "zero": Decimal("0.00"),
    }
    if bar.get("plafond_journalier"):
        # La T1 journaliere des cadres : 220 EUR x jours travailles.
        bases["t1_journaliere"] = min(
            paie.brut, eur(Decimal(str(bar["plafond_journalier"])) * paie.engagement.jours))
    return bases


def cotisations(paie, bar) -> list:
    """Les cotisations d'un versement, dans l'ordre du bareme.

    LE BAREME DU STATUT, pas celui du corps : `cotisations_dsn` d'un
    technicien n'est pas celui d'un artiste. Jusqu'au 13/09/2026 la DSN
    lisait le corps pour tout le monde -- sans effet tant que le moteur
    refuse les techniciens, mais faux le jour ou il les accepte.
    """
    from .calcul import bareme_du_statut, bareme_cadre
    bar = bareme_cadre(bareme_du_statut(bar, paie.salarie.get("statut")), paie.salarie)
    bases = _bases(paie, bar)
    out = []
    for c in bar["cotisations_dsn"]:
        ligne = {
            "bloc78": c["bloc78"],
            "base78": bases[c["base78"]],
            "code81": c["code81"],
            "org": c.get("org"),
            "affectation": c.get("affectation"),
        }
        if c.get("lignes"):
            # Le montant est la somme de lignes du bulletin, chacune deja
            # arrondie : l'Agirc-Arrco d'un cadre << y compris Apec >>.
            ligne["montant"] = sum(
                (l.montant_pat + l.montant_sal for l in getattr(paie, "lignes", [])
                 if l.id in c["lignes"]), Decimal("0.00"))
        elif c["taux"] is not None:
            base = bases[c["base"]]
            ligne["base81"] = base
            ligne["taux"] = c["taux"]
            if c.get("composants"):
                # Contributions arrondies separement mais declarees en une ligne.
                ligne["montant"] = sum((pct(base, t) for t in c["composants"]),
                                       Decimal("0.00"))
            else:
                ligne["montant"] = pct(base, c["taux"])
        out.append(ligne)
    # LA REDUCTION GENERALE (techniciens) : sa part Urssaf, bloc 81 code 018
    # sur le bloc 78 type 03, en montant positif comme les autres reductions
    # du bloc 81. Les parts chomage et Agirc-Arrco ne sont pas ecrites --
    # codes non etablis, voir le bareme (`reduction_generale._dsn`).
    rg = getattr(paie, "reduction_generale", None)
    if rg and rg.get("montant"):
        dsn = (bar.get("reduction_generale") or {}).get("dsn") or {}
        # Comme dans la DSN CoolPaie de mai 2025 : trois blocs 81 negatifs,
        # avec assiette, sous le bloc 78 type 03 -- part securite sociale a
        # l'Urssaf, part chomage a France Travail (l'Urssaf ne recouvre pas
        # l'AC des intermittents), part retraite sans organisme (106).
        # `cle_total` distingue les deux 018 dans les totaux par versement.
        urssaf = next((c["org"] for c in bar["cotisations_dsn"]
                       if c["code81"] == "075"), None)
        ft = next((c["org"] for c in bar["cotisations_dsn"]
                   if c["code81"] == "040"), None)
        for code, org, part, cle in (
                (dsn.get("code81_urssaf", "018"), urssaf, rg["urssaf"], "018:urssaf"),
                (dsn.get("code81_chomage", "018"), ft, rg["chomage"], "018:chomage"),
                (dsn.get("code81_retraite", "106"), None, rg["agirc_arrco"], "106")):
            if part:
                out.append({"bloc78": "03", "base78": bases["brut"],
                            "code81": code, "org": org, "affectation": None,
                            "base81": bases["brut"], "montant": -part,
                            "cle_total": cle})
    return out


# ------------------------------------------------------------------ generation
def generer(ctx, paies: list, mois: str, date_constitution=None,
            fraction: str = "11", type_declaration: str = "01",
            versement_urssaf=None, pas_par_salarie=None,
            envoi_test: bool = False, ordre: int = 1,
            remplace=None) -> str:
    """`mois` au format AAAA-MM ; `paies` : toutes les paies du mois.

    `pas_par_salarie` : {cle_salarie: (taux, type, identifiant)}. A defaut, le
    magasin config/pas.json fait foi. Le moteur ne fabrique jamais ces valeurs :
    elles viennent du compte-rendu metier DGFiP (voir moteur/pas.py).

    `envoi_test` met S10.G00.00.005 a '01' : controles executes et bilan rendu,
    donnees transmises aux organismes pour analyse mais NON CONSERVEES. Un
    fichier code '02' est traite comme reel, quoi qu'on en dise par ailleurs.

    ANNULE ET REMPLACE. `type_declaration='03'` et un `ordre` superieur a
    celui de la declaration remplacee. C'est TOUT ce qu'il faut : la
    plate-forme retrouve la declaration a remplacer par son mois, sa fraction
    et son SIREN.

    LA RUBRIQUE S20.G00.05.006 EST INTERDITE ICI. C'est ecrit noir sur blanc
    dans le « tableau des usages » du cahier technique 2026.1, p. 362-363 :
    par colonne, pour cette rubrique, on lit « I C C C C I C », et la premiere
    colonne est « 01 - DSN mensuelle ». I = interdite. Elle n'est
    conditionnelle que pour les signalements (arret de travail, reprise, fin
    de contrat, amorcage) et la DPAE.
    Le cahier technique la decrit comme « l'identifiant de la derniere
    declaration, relative au meme EVENEMENT, validee par le point de depot ».
    « Evenement » est le vocabulaire des SIGNALEMENTS (fin de contrat, arret
    de travail), pas celui d'une DSN mensuelle. Nous avons lu la definition
    trop vite, rempli la rubrique, et depose en test. Reponse de la
    plate-forme, deux anomalies bloquantes :

        CST-04      Presence de la rubrique interdite S20.G00.05.006.
        B1-208-08   'annule et remplace' ou 'annule' sans normale prealable.

    D'ou `remplace` : on peut le passer, mais uniquement pour un signalement,
    et le moteur n'en emet pas encore. Il est donc REFUSE pour une mensuelle.
    Le jour ou un signalement sera ecrit, cette porte est deja la -- et le
    commentaire dit pourquoi elle etait fermee.

    LE NUMERO D'ORDRE EST LE SEUL RATTACHEMENT -- etabli le 10/09/2026 en
    deposant en test, et lisible dans une troisieme anomalie :

        B1-208-11   'annule et remplace' d'ordre 2026092 inferieur (ou egal)
                    au dernier ordre accepte 2026092.

    La plate-forme construit donc un rang « AAAAMM + ordre » a partir du MOIS
    DE CONSTITUTION, et elle exige qu'un annule-et-remplace soit STRICTEMENT
    superieur au dernier rang accepte pour cet etablissement. C'est ce rang,
    et lui seul, qui designe la declaration remplacee : il n'y a rien d'autre
    a fournir, et c'est pour ca que S20.G00.05.006 est interdite.

    Consequence pratique : `ordre` ne se met pas a 2 par habitude. Il se
    choisit au-dessus du dernier ordre ACCEPTE du mois civil en cours, qui se
    lit sur le certificat de conformite du depot precedent (`moteur retours`).

    IL REMPLACE, IL N'AJOUTE PAS -- Y COMPRIS LES ORDRES DE TELEPAIEMENT.
    Question posee le 10/09/2026, tranchee le 11 par le cahier technique
    2026.1, p. 15 : « lorsque la derniere DSN mensuelle transmise pour une date
    d'exigibilite donnee est de type "Annule et remplace integral", elle doit
    porter les elements de cotisations destines aux organismes de recouvrement,
    MEME SI ces elements ont deja ete transmis dans une DSN mensuelle relative
    a la meme date d'exigibilite. » C'est la DERNIERE qui vaut. Exiger qu'elle
    re-porte ce qui a deja ete transmis n'aurait aucun sens si l'on
    additionnait. Le mecanisme le confirme : le telepaiement s'execute a la
    DATE D'EXIGIBILITE, pas au depot -- l'ordre precedent n'a jamais ete
    execute, il est remplace en attente.

    ET SON ECHEANCE N'EST PAS CELLE D'UNE DSN NORMALE -- cahier technique,
    p. 13. Une DSN « normale » se depose jusqu'au jour de l'echeance (5 ou 15)
    a midi ; un annule-et-remplace, lui, « au plus tard la veille a minuit ».
    Au-dela, la rectification se porte dans les paies des mois suivants. Le
    moteur ne refuse pas de produire passe cette heure -- il ne connait pas
    l'echeance de l'etablissement (5 ou 15) -- mais qui depose doit la savoir.

    ET LE MODE TEST NE SAIT PAS VALIDER UN ANNULE-ET-REMPLACE. Le meme jour,
    la premiere tentative avait rendu :

        B1-208-08   'annule et remplace' ou 'annule' sans normale prealable.

    alors que la declaration d'aout existait bel et bien, deposee le 03/09 et
    certifiee conforme. L'anomalie a disparu des qu'une declaration NORMALE a
    ete deposee EN TEST juste avant. Le mode test a donc sa propre base : il
    valide la structure, jamais le rattachement a une declaration reelle. Un
    annule-et-remplace ne peut etre prouve qu'en reel -- et un depot reel
    rejete ne declare rien, ce qui rend l'essai sans danger.
    """
    ent = ctx.entreprise
    orgs = json.loads((ctx.racine / "config" / "organismes.json").read_text(encoding="utf-8"))
    an, mo = int(mois[:4]), int(mois[5:7])
    debut_mois = d("%d-%02d-01" % (an, mo))
    fin_mois = _fin_mois(an, mo)
    bar = ctx.bareme(debut_mois)
    # Le numero de licence change dans le temps : c'est celui en vigueur sur le
    # mois declare qui doit partir, pas celui du jour (voir Contexte.licence).
    ent = dict(ent, licence_spectacle=ctx.licence(debut_mois))
    # UN MOIS SANS AUCUN SALARIE (15/09/2026, Leandre : << il faut toujours
    # des DSN, meme les mois sans paye >>) : la « declaration normale sans
    # individu », cahier technique 2026.1 §2.4 -- type 02 (05 en annule et
    # remplace), envoi « neant » (S10.G00.00.008 = 02), et S20.G00.08 qui
    # nomme les organismes sans individu rattache ce mois-ci (codes dans
    # organismes.json, avec la page qui les donne). Le reste du fichier est
    # celui d'un mois ordinaire sans salarie : entreprise, etablissement,
    # adhesions, versements a zero, bordereau Urssaf a zero.
    sans_individu = not paies
    if date_constitution:
        constitution = d(date_constitution)
    elif sans_individu:
        constitution = fin_mois
    else:
        constitution = max(p.engagement.fin_periode for p in paies)
    if sans_individu:
        type_declaration = {"01": "02", "03": "05"}.get(type_declaration, type_declaration)

    # Coherence de l'annule-et-remplace, verifiee AVANT d'ecrire une ligne.
    if remplace:
        # Voir le docstring : la plate-forme la refuse sur une DSN mensuelle
        # (CST-04). On ne laisse pas produire un fichier qu'on sait rejete.
        raise ValueError(
            "S20.G00.05.006 est interdite sur une DSN mensuelle : la "
            "plate-forme a repondu CST-04 le 10/09/2026. Un annule et "
            "remplace se code par type_declaration='03' et un numero d'ordre "
            "superieur, sans identifiant de declaration remplacee.")
    if type_declaration in ("03", "05") and int(ordre) < 2:
        raise ValueError(
            "Un annule et remplace doit porter un numero d'ordre STRICTEMENT "
            "superieur au dernier ordre accepte du mois civil en cours "
            "(recu ordre=%s). La plate-forme rend B1-208-11 sinon ; le dernier "
            "ordre accepte se lit sur le certificat de conformite du depot "
            "precedent." % ordre)

    pas_par_salarie = dict(pas_par_salarie or {})
    for cle in {p.salarie["_cle"] for p in paies}:
        if cle not in pas_par_salarie:
            pas_par_salarie[cle] = pas.rubriques(ctx, cle)
    f = Fichier()

    # ---------------------------------------------------------------- S10 envoi
    f.add("S10.G00.00.001", LOGICIEL)
    f.add("S10.G00.00.002", LOGICIEL)
    f.add("S10.G00.00.003", VERSION)
    f.add("S10.G00.00.005", "01" if envoi_test else "02")
    f.add("S10.G00.00.006", NORME)
    f.add("S10.G00.00.007", "01")
    f.add("S10.G00.00.008", "02" if sans_individu else "01")
    f.add("S10.G00.01.001", ent["siren"])
    f.add("S10.G00.01.002", ent["nic"])
    f.add("S10.G00.01.003", ent["raison_sociale"])
    f.add("S10.G00.01.004", ent["adresse"])
    f.add("S10.G00.01.005", ent["code_postal"])
    f.add("S10.G00.01.006", ent["commune"])
    f.add("S10.G00.02.001", "01")
    f.add("S10.G00.02.002", "%s %s" % (ent["signataire"]["nom"], ent["signataire"]["prenom"]))
    f.add("S10.G00.02.004", ent["declarant_dsn"]["email"])
    f.add("S10.G00.02.005", ent["declarant_dsn"]["tel"])

    # -------------------------------------------------------------- S20 declar.
    f.add("S20.G00.05.001", "01")
    f.add("S20.G00.05.002", type_declaration)
    f.add("S20.G00.05.003", fraction)
    f.add("S20.G00.05.004", str(int(ordre)))
    f.add("S20.G00.05.005", jjmmaaaa(debut_mois))
    if remplace:
        # Rubrique interdite hors type 03/04 (CCH-12) : elle n'apparait donc
        # que quand on remplace vraiment quelque chose.
        f.add("S20.G00.05.006", str(remplace))
    f.add("S20.G00.05.007", jjmmaaaa(constitution))
    f.add("S20.G00.05.008", "01")
    f.add("S20.G00.05.010", "01")
    f.add("S20.G00.07.001", ent["declarant_dsn"]["nom_prenom"])
    f.add("S20.G00.07.002", ent["declarant_dsn"]["tel"])
    f.add("S20.G00.07.003", ent["declarant_dsn"]["email"])
    f.add("S20.G00.07.004", ent["declarant_dsn"]["qualite"])
    if sans_individu:
        for code in orgs["sans_individu"]["absence_de_rattachement"]:
            f.add("S20.G00.08.001", code)

    # ------------------------------------------------------- S21 entreprise
    f.add("S21.G00.06.001", ent["siren"])
    f.add("S21.G00.06.002", ent["nic"])
    f.add("S21.G00.06.003", ent["naf"])
    f.add("S21.G00.06.004", ent["adresse"])
    f.add("S21.G00.06.005", ent["code_postal"])
    f.add("S21.G00.06.006", ent["commune"])
    f.add("S21.G00.11.001", ent["nic"])
    f.add("S21.G00.11.002", ent["naf"])
    f.add("S21.G00.11.003", ent["adresse"])
    f.add("S21.G00.11.004", ent["code_postal"])
    f.add("S21.G00.11.005", ent["commune"])
    f.add("S21.G00.11.022", ent["code_convention_dsn"])
    for a in orgs["adhesions_prevoyance"]:
        f.add("S21.G00.15.001", a["libelle"])
        f.add("S21.G00.15.002", a["delegataire"])
        # Sans salarie, aucune adhesion ne couvre personne ce mois-ci :
        # 15.004 = « 02 - ne concerne aucun salarie » pour toutes. Le depot de
        # test du 15/09/2026 a refuse un « 01 » sans affiliation (CCH-13).
        f.add("S21.G00.15.004", "02" if sans_individu else a["type"])
        f.add("S21.G00.15.005", a["reference"])

    # ------------------------------------- totaux du mois, par code cotisation
    totaux = OrderedDict()
    par_affectation = OrderedDict()
    for p in paies:
        for c in cotisations(p, bar):
            if "montant" not in c:
                continue
            cle = c.get("cle_total", c["code81"])
            totaux[cle] = totaux.get(cle, Decimal("0.00")) + c["montant"]
            if c["code81"] == "059":
                a = c["affectation"]
                par_affectation[a] = par_affectation.get(a, Decimal("0.00")) + c["montant"]

    echeances = {"13000548100010": _15_mois_suivant(an, mo),
                 "P0983": _fin_trimestre(an, mo)}
    brut_mois = sum((p.brut for p in paies), Decimal("0.00"))
    for v in orgs["versements"]:
        # Sans salarie, un seul versement, a zero : l'Urssaf, avec son
        # bordereau. Les organismes de S20.G00.08 n'ont rien a recevoir, et
        # un versement de prevoyance sans composant 55 est refuse (CCH-12 du
        # bloc 20, depot de test du 15/09/2026).
        if sans_individu and v["libelle"] != "URSSAF":
            continue
        montant = _montant_versement(v, totaux, brut_mois, versement_urssaf)
        f.add("S21.G00.20.001", v["siret"])
        if v.get("reference"):
            f.add("S21.G00.20.002", v["reference"])
        f.add("S21.G00.20.003", ent["banque"]["bic"])
        f.add("S21.G00.20.004", ent["banque"]["iban"])
        f.add("S21.G00.20.005", _mt(montant))
        f.add("S21.G00.20.006", jjmmaaaa(debut_mois))
        f.add("S21.G00.20.007", jjmmaaaa(fin_mois))
        f.add("S21.G00.20.010", "05")
        if v["siret"] in echeances:
            f.add("S21.G00.20.011", jjmmaaaa(echeances[v["siret"]]))
        if v["siret"] == "P0983":
            trim = "%dT%02d" % (an, (mo - 1) // 3 + 1)
            for aff, libelle in (("202", "TSINTERMITTENTS"), ("203", "INTERBRANCHE")):
                if aff in par_affectation:
                    f.add("S21.G00.55.001", _mt(par_affectation[aff]))
                    f.add("S21.G00.55.003", libelle)
                    f.add("S21.G00.55.004", trim)

    # ---------------------------------------- bordereau + assiettes agregees
    urssaf = next(v for v in orgs["versements"] if v["libelle"] == "URSSAF")
    mt_urssaf = _montant_versement(urssaf, totaux, brut_mois, versement_urssaf)
    f.add("S21.G00.22.001", urssaf["siret"])
    f.add("S21.G00.22.003", jjmmaaaa(debut_mois))
    f.add("S21.G00.22.004", jjmmaaaa(fin_mois))
    f.add("S21.G00.22.005", _mt(mt_urssaf))

    somme = {k: sum((_bases(p, bar)[k] for p in paies), Decimal("0.00"))
             for k in ("brut", "csg", "brut_x115", "brut_x110")}
    # Les assiettes propres aux techniciens (CTP 100, 332) et le montant de
    # leur reduction generale (CTP 671) : nuls sans technicien, et un CTP
    # marque `statut` ne s'ecrit pas a zero -- le mois reste identique.
    techs = [p for p in paies if (p.salarie.get("statut") or "artiste") == "technicien"]
    artistes = [p for p in paies if p not in techs]
    somme["brut_technicien"] = sum((p.brut for p in techs), Decimal("0.00"))
    somme["brut_x115_technicien"] = sum(
        (_bases(p, bar)["brut_x115"] for p in techs), Decimal("0.00"))
    # Et les CTP abattus (312 AT, 334 FNAL) ne portent que les artistes :
    # 1040 et 1160 en mai 2025, sans les 56,00 du technicien.
    somme["brut_artiste"] = sum((p.brut for p in artistes), Decimal("0.00"))
    somme["brut_x115_artiste"] = sum(
        (_bases(p, bar)["brut_x115"] for p in artistes), Decimal("0.00"))
    somme["reduction_generale_urssaf"] = sum(
        ((p.reduction_generale or {}).get("urssaf", Decimal("0.00")) for p in techs),
        Decimal("0.00"))
    for ctp in orgs["ctp_urssaf"]:
        valeur = somme[ctp["montant"]] if ctp.get("montant") else somme[ctp["assiette"]]
        if ctp.get("statut") and not valeur:
            continue
        f.add("S21.G00.23.001", ctp["code"])
        f.add("S21.G00.23.002", ctp["qualifiant"])
        if ctp.get("taux_at"):
            f.add("S21.G00.23.003", ctp["taux_at"])
        if ctp.get("montant"):
            f.add("S21.G00.23.005", _mt(round(valeur)))
        else:
            f.add("S21.G00.23.004", _mt(round(valeur)))

    # ------------------------------------------------------------- salaries
    for cle in _ordre_salaries(paies):
        lot = [p for p in paies if p.salarie["_cle"] == cle]
        s = lot[0].salarie
        f.add("S21.G00.30.001", s["nir"])
        f.add("S21.G00.30.002", s["nom"])
        f.add("S21.G00.30.004", s["prenom"])
        f.add("S21.G00.30.006", jjmmaaaa(s["date_naissance"]))
        f.add("S21.G00.30.007", s["lieu_naissance"])
        f.add("S21.G00.30.008", s["adresse"])
        f.add("S21.G00.30.009", s["code_postal"])
        f.add("S21.G00.30.010", s["commune"])
        f.add("S21.G00.30.013", s["code_nationalite_dsn"])
        f.add("S21.G00.30.014", s["departement_naissance"])
        f.add("S21.G00.30.015", s["pays_naissance"])
        f.add("S21.G00.30.018", s["email"])
        f.add("S21.G00.30.019", s["code_salarie"])

        for i, p in enumerate(lot, 1):
            _bloc_contrat(f, p, ent, i)
        for i, p in enumerate(lot, 1):
            _bloc_versement(f, p, bar, i, pas_par_salarie[cle])
        anciennete = (fin_mois - d(s.get("date_anciennete", "2019-12-01"))).days + 1
        for p in lot:
            f.add("S21.G00.86.001", "07")
            f.add("S21.G00.86.002", "01")
            f.add("S21.G00.86.003", anciennete)
            f.add("S21.G00.86.005", p.engagement.numero)

    f.add("S90.G00.90.001", len(f.lignes) + 2)
    f.add("S90.G00.90.002", "1")
    return f.texte()


def _somme_codes81(v, totaux):
    return sum((totaux.get(code, Decimal("0.00")) for code in v["codes81"]),
               Decimal("0.00"))


def _montant_versement(v, totaux, brut_mois, forcage=None):
    """Montant de l'ordre de telepaiement (bloc S21.G00.20.005).

    Pour presque tous les organismes : la somme des cotisations qui leur sont
    affectees, et c'est exact. L'URSSAF fait exception - elle facture des
    elements que la DSN ne detaille pas, plus des regularisations annuelles -
    si bien que son montant n'est PAS calculable depuis la paie. Il doit venir
    du bordereau URSSAF, d'ou `forcage`. A defaut, on produit une estimation
    explicitement signalee comme telle (voir `estimation_urssaf`).
    """
    if forcage is not None and v["libelle"] == "URSSAF":
        return Decimal(str(forcage))
    regle = v.get("montant")
    if regle and regle.get("mode") == "cotisations_plus_residu":
        m = _somme_codes81(v, totaux)             + brut_mois * Decimal(str(regle["taux_residuel"])) / Decimal(100)
        return Decimal(round(m))
    if regle and regle.get("mode") == "taux_sur_brut":
        m = brut_mois * Decimal(str(regle["taux"])) / Decimal(100)
        return Decimal(round(m)) if regle.get("arrondi") == "euro" else eur(m)
    return _somme_codes81(v, totaux)


def estimation_urssaf(ctx, paies, mois):
    """Estimation du telepaiement URSSAF, avec sa marge d'erreur mesuree.

    Renvoie (montant, marge). Cette valeur n'a pas valeur de bordereau : elle
    sert a reperer une saisie aberrante, pas a remplacer le bordereau. La
    marge est celle constatee sur l'historique CoolPaie (voir le champ
    `_ecart_max_constate` de config/organismes.json).
    """
    orgs = json.loads(
        (ctx.racine / "config" / "organismes.json").read_text(encoding="utf-8"))
    v = next(o for o in orgs["versements"] if o["libelle"] == "URSSAF")
    bar = ctx.bareme(d("%s-%s-01" % (mois[:4], mois[5:7])))
    totaux = OrderedDict()
    for p in paies:
        for c in cotisations(p, bar):
            if "montant" in c:
                totaux[c["code81"]] = totaux.get(c["code81"], Decimal("0.00"))                     + c["montant"]
    brut = sum((p.brut for p in paies), Decimal("0.00"))
    return (_montant_versement(v, totaux, brut),
            Decimal(str(v["montant"].get("_ecart_max_constate", 0))))


def _bloc_contrat(f, p, ent, rang: int) -> None:
    e, s = p.engagement, p.salarie
    f.add("S21.G00.40.001", jjmmaaaa(e.debut))
    # Le classement conventionnel, et NON une constante du logiciel. Il
    # depend de l'emploi du contrat : 05 pour un artiste, 07 pour un ouvrier,
    # 04 + 003=01 pour un cadre. Les defauts sont ceux des artistes, parce
    # que c'est ce que portent les 146 contrats de l'historique -- mais une
    # fiche ou un engagement peuvent les dire autrement.
    f.add("S21.G00.40.002", s.get("statut_conventionnel")
          or champs.defaut("salarie", "statut_conventionnel"))
    f.add("S21.G00.40.003", s.get("statut_categoriel_rc")
          or champs.defaut("salarie", "statut_categoriel_rc"))
    f.add("S21.G00.40.004", s["pcs_ese"])
    f.add("S21.G00.40.005", s["code_emploi_ft"])
    f.add("S21.G00.40.006", s["emploi"])
    f.add("S21.G00.40.007", "02")
    f.add("S21.G00.40.008", "99")
    f.add("S21.G00.40.009", e.numero)
    f.add("S21.G00.40.010", jjmmaaaa(e.fin))
    f.add("S21.G00.40.011", "12")
    # LA QUOTITE : les jours du CONTRAT ENTIER, les memes chaque mois, jamais
    # zero (Engagement.jours_contrat, tranche le 15/09/2026 par le cahier
    # technique 2026.1 : bloc 40 CCH-11 et CCH-12, bloc 41 rubrique 007).
    # Sur un contrat qui tient dans son mois, ce sont ses dates, comme
    # toujours. CCH-12 plafonne a 31.00 en unite journee : au-dela on
    # refuse plutot que de declarer un nombre faux.
    if e.quotite > 31:
        raise ValueError(
            "Contrat %s du %s au %s : %d jours, et la norme DSN plafonne la "
            "quotite de travail en journees a 31 (S21.G00.40.013, CCH-12). "
            "Un contrat de plus de 31 dates n'est pas prevu -- a trancher "
            "avant de le declarer."
            % (e.numero, jjmmaaaa(e.debut), jjmmaaaa(e.fin), e.quotite))
    f.add("S21.G00.40.012", _qt(e.quotite))
    f.add("S21.G00.40.013", _qt(e.quotite))
    f.add("S21.G00.40.014", "99")
    f.add("S21.G00.40.016", "99")
    f.add("S21.G00.40.017", ent["idcc"])
    f.add("S21.G00.40.018", "200")
    f.add("S21.G00.40.019", ent["siret"])
    f.add("S21.G00.40.020", "200")
    f.add("S21.G00.40.021", "05")
    f.add("S21.G00.40.022", ent["congesspectacles_affiliation"])
    f.add("S21.G00.40.024", "99")
    f.add("S21.G00.40.026", "99")
    f.add("S21.G00.40.036", "01")
    f.add("S21.G00.40.037", "03")
    f.add("S21.G00.40.039", "200")
    f.add("S21.G00.40.040", "923AD")
    f.add("S21.G00.40.043", "1.50")
    f.add("S21.G00.40.049", ent["licence_spectacle"])
    f.add("S21.G00.40.050", p.spectacle["numero_objet"])
    f.add("S21.G00.40.051", "02")
    # LA FIN DE CONTRAT (bloc 62) NE PART QUE LE MOIS OU LE CONTRAT FINIT.
    # Fiche net-entreprises n° 3344 : le bloc << ne s'utilise que lors de la
    # fin effective du contrat de travail >>. Un contrat d'octobre a decembre
    # porte le meme bloc 40 dans ses trois DSN (debut, numero, fin
    # previsionnelle sont ses identifiants) ; l'emettre en octobre
    # declarerait une rupture qui n'a pas eu lieu. Sur un contrat qui tient
    # dans son mois -- tout l'historique -- il part comme toujours.
    if e.dernier_mois:
        f.add("S21.G00.62.001", jjmmaaaa(e.fin))
        f.add("S21.G00.62.002", "031")
        f.add("S21.G00.62.006", jjmmaaaa(e.fin))
        f.add("S21.G00.62.017", "01")
    base = 199 + 3 * rang
    f.add("S21.G00.70.012", str(base))
    f.add("S21.G00.70.013", "103")
    f.add("S21.G00.70.012", str(base + 1))
    f.add("S21.G00.70.013", "102")
    f.add("S21.G00.71.002", "RUAA")


def _bloc_versement(f, p, bar, rang: int, taux_pas: tuple) -> None:
    e = p.engagement
    # LA PERIODE DE PAIE, PAS CELLE DU CONTRAT. Les blocs 50, 51, 54, 58 et
    # 78 portent le mois paye : controles CCH-11 (debut de periode >= debut
    # du contrat - 2 j) et CCH-13 (fin de periode <= fin du contrat + 2 j,
    # dans le mois principal declare). Sur un contrat qui tient dans son
    # mois, `debut_periode`/`fin_periode` SONT `debut`/`fin` : rien ne bouge
    # pour l'historique. Sur un contrat a cheval, c'est le contrat borne au
    # mois. Le bloc 40, lui, garde les bornes du contrat.
    debut, fin = e.debut_periode, e.fin_periode
    f.add("S21.G00.50.001", jjmmaaaa(fin))
    f.add("S21.G00.50.002", _mt(p.net_imposable))
    f.add("S21.G00.50.003", "%02d" % rang)
    f.add("S21.G00.50.004", _mt(p.net_a_payer))
    taux, type_taux, identifiant = taux_pas
    f.add("S21.G00.50.006", taux)
    f.add("S21.G00.50.007", type_taux)
    # CCH-11 : .008 n'est obligatoire que si le taux vient de la DGFiP (type 01).
    if type_taux == "01":
        f.add("S21.G00.50.008", identifiant)
    f.add("S21.G00.50.009", _mt(pct(p.net_imposable, taux)))
    f.add("S21.G00.50.013", _mt(p.net_imposable))

    jours = len(set(e.dates_travail))
    for code in ("001", "002", "003", "010"):
        f.add("S21.G00.51.001", jjmmaaaa(debut))
        f.add("S21.G00.51.002", jjmmaaaa(fin))
        f.add("S21.G00.51.010", e.numero)
        f.add("S21.G00.51.011", code)
        f.add("S21.G00.51.013", _mt(p.brut))
        if code == "002":
            # Unites de mesure S21.G00.53.003, cahier technique NEODeS 2026.1 :
            # « Pour les conges spectacles, il est necessaire pour calculer les
            # droits, de renseigner a la fois une unite de mesure "jours" et
            # "cachets" ». D'ou les deux blocs -- 12 = journee, 37 = cachets
            # isoles, exactement ce que CoolPaie declarait, prouve par le rejeu
            # de 50 DSN.
            f.add("S21.G00.53.001", "01")
            f.add("S21.G00.53.002", _qt(jours))
            f.add("S21.G00.53.003", "12")
            if e.cachets:
                f.add("S21.G00.53.001", "01")
                f.add("S21.G00.53.002", _qt(e.cachets))
                f.add("S21.G00.53.003", "37")
            # LES HEURES SE DECLARENT EN PLUS, PAS A LA PLACE. Corrige le
            # 10/09/2026 : c'etait un `elif`, et un contrat mixte -- des
            # cachets ET des heures -- ne declarait donc que ses cachets. Les
            # heures partaient a la poubelle en silence.
            #
            # L'ancien commentaire disait la faute a l'envers : « non verifie
            # contre CoolPaie, tous les contrats portent au moins un cachet ».
            # C'est faux. ONZE contrats de l'historique portent les trois
            # unites ensemble, dont PU1.25.14 et SI2.25.17 d'octobre 2025 :
            #
            #     11.00 unite 12 (jours) + 1.00 unite 37 (cachet)
            #                            + 40.00 unite 35 (heures)
            #
            # Le rejeu ne l'a pas attrape parce qu'il ne rejoue que 2026,
            # faute de baremes anterieurs, et que les mois mixtes de 2026
            # divergent deja pour d'autres raisons.
            #
            # Ce que ca coute : les heures comptent dans les 507 heures des
            # annexes 8 et 10. Une heure non declaree est un droit perdu pour
            # le salarie, et rien ne le signale.
            if e.heures:
                # « 35 - heures intermittents du spectacle », cahier technique
                # NEODeS. C'est aussi la seule ligne d'un contrat sans cachet
                # (une masterclass, un technicien paye a l'heure) : declarer
                # « 0 cachet isole » serait faux.
                f.add("S21.G00.53.001", "01")
                f.add("S21.G00.53.002", _qt(e.heures))
                f.add("S21.G00.53.003", "35")

    if e.sans_paie:
        # UN MOIS DU CONTRAT SANS CACHET (15/09/2026). Le cahier technique
        # 2026.1 impose le bloc 50 (1,*) et ses quatre remunerations 51
        # (CCH-11) des que l'individu est la, admet le zero sur ces
        # montants, et exige un bloc 53 en unite journee (bloc 40, CCH-15)
        # -- il est parti ci-dessus, a 0.00 jour. Le bloc 54 interdit le
        # zero, et aucune cotisation (81) n'est due. Le net social (58),
        # obligatoire (CCH-14), vaut 0.00. Et UNE BASE 78 << 31 >> A ZERO PAR
        # AFFILIATION PREVOYANCE, AVEC SA COTISATION 059 A ZERO : le depot
        # de test du 15/09/2026 a refuse fevrier deux fois de suite --
        # S21.G00.78.001/CCH-13, << au moins une base assujettie de code 31
        # pour chaque identifiant technique d'affiliation >>, puis
        # S21.G00.81.001/CCH-15, << une et une seule cotisation de type 059 >>
        # sous chaque base 31. Le bareme dit quelles affiliations existent ;
        # base et cotisation valent 0.00.
        f.add("S21.G00.58.001", jjmmaaaa(debut))
        f.add("S21.G00.58.002", jjmmaaaa(fin))
        f.add("S21.G00.58.003", "03")
        f.add("S21.G00.58.004", "0.00")
        vues = set()
        for c in cotisations(p, bar):
            if c["bloc78"] != "31" or c.get("affectation") in vues:
                continue
            vues.add(c.get("affectation"))
            f.add("S21.G00.78.001", "31")
            f.add("S21.G00.78.002", jjmmaaaa(debut))
            f.add("S21.G00.78.003", jjmmaaaa(fin))
            f.add("S21.G00.78.004", "0.00")
            if c.get("affectation"):
                f.add("S21.G00.78.005", str(int(c["affectation"]) + 3 * (rang - 1)))
            f.add("S21.G00.78.006", e.numero)
            f.add("S21.G00.79.001", "11")
            f.add("S21.G00.79.004", "0.00")
            f.add("S21.G00.81.001", c["code81"])
            f.add("S21.G00.81.004", "0.00")
        return

    f.add("S21.G00.54.001", "93")
    # S21.G00.54.001 = "93 - Cotisation prevoyance et retraite supplementaire"
    # (cahier technique NEODeS CT2026.1, dans reference/norme-dsn/) : un MONTANT
    # en euros, arrondi a l'euro. Taux dans le bareme - voir sa note de source.
    from .calcul import bareme_du_statut, bareme_cadre
    bp = bareme_cadre(bareme_du_statut(bar, p.salarie.get("statut")), p.salarie)
    supp = bp["cotisation_prevoyance_retraite_supp"]
    base_54 = _bases(p, bp).get(supp.get("base", "brut"), p.brut)
    f.add("S21.G00.54.002", _qt(round(pct(base_54, supp["taux_sur_brut"]))))
    f.add("S21.G00.54.003", jjmmaaaa(debut))
    f.add("S21.G00.54.004", jjmmaaaa(fin))
    f.add("S21.G00.54.005", e.numero)
    f.add("S21.G00.58.001", jjmmaaaa(debut))
    f.add("S21.G00.58.002", jjmmaaaa(fin))
    f.add("S21.G00.58.003", "03")
    f.add("S21.G00.58.004", _mt(p.net_a_payer))

    bloc_courant = object()
    for c in cotisations(p, bar):
        if c.get("affectation"):
            c["affectation"] = str(int(c["affectation"]) + 3 * (rang - 1))
        cle = (c["bloc78"], c.get("affectation"))
        if cle != bloc_courant:
            bloc_courant = cle
            f.add("S21.G00.78.001", c["bloc78"])
            f.add("S21.G00.78.002", jjmmaaaa(debut))
            f.add("S21.G00.78.003", jjmmaaaa(fin))
            f.add("S21.G00.78.004", _mt(c["base78"]))
            if c.get("affectation"):
                f.add("S21.G00.78.005", c["affectation"])
            f.add("S21.G00.78.006", e.numero)
            if c["bloc78"] == "03":
                f.add("S21.G00.79.001", "01")
                # Le SMIC retenu pour la reduction generale. Pour un
                # technicien, c'est celui du calcul (12,02 x heures, gele) ;
                # pour un artiste, la valeur que CoolPaie a toujours declaree.
                rg = getattr(p, "reduction_generale", None)
                f.add("S21.G00.79.004", _mt(rg["smic_reference"] if rg else p.plafond))
            elif c["bloc78"] == "31":
                f.add("S21.G00.79.001", "11")
                f.add("S21.G00.79.004", _mt(p.brut))
        if "montant" not in c:
            continue
        f.add("S21.G00.81.001", c["code81"])
        if c.get("org"):
            f.add("S21.G00.81.002", c["org"])
        if c.get("org") or c.get("cle_total"):
            # L'assiette : avec l'organisme, et sur les reductions (018, 106)
            # meme sans -- controle CCH-16 du cahier technique.
            f.add("S21.G00.81.003", _mt(c["base81"]))
        f.add("S21.G00.81.004", _mt(c["montant"]))
        if c.get("org") and c.get("taux") is not None:
            f.add("S21.G00.81.007", "%.3f" % Decimal(str(c["taux"])))


def _ordre_salaries(paies) -> list:
    vus = []
    for p in paies:
        if p.salarie["_cle"] not in vus:
            vus.append(p.salarie["_cle"])
    return vus


def _fin_mois(an, mo):
    return d("%d-%02d-%02d" % (an, mo, calendar.monthrange(an, mo)[1]))


def _15_mois_suivant(an, mo):
    return d("%d-%02d-15" % (an + (mo == 12), (mo % 12) + 1))


def _fin_trimestre(an, mo):
    m = ((mo - 1) // 3 + 1) * 3 + 1
    an2, m = (an + 1, 1) if m > 12 else (an, m)
    return _fin_mois(an2, m)


def ecrire(ctx, paies, mois, chemin, **kw) -> Path:
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    chemin.write_bytes(generer(ctx, paies, mois, **kw).encode("latin-1"))
    return chemin
