"""Importer ce que CoolPaie a deja declare : fiches et historique.

Le but est explicite depuis le 11/09/2026 : *faciliter la migration*. Une
compagnie qui arrive de CoolPaie ne ressaisit rien -- ses salaries, ses
spectacles et cinq ans de contrats attestes sont dans son dossier `export/`,
et c'est de la qu'on les prend.

Ce que l'importation fait, dans l'ordre, et ce qu'elle ne fait pas :

1. **L'entreprise**, seulement si la fiche est vide (pas de SIREN). Une
   fiche qui existe est celle de la compagnie : on n'y touche pas.
2. **Les salaries**, par NIR. Un NIR inconnu devient une fiche neuve, avec
   ce que la derniere DSN a declare de lui. Un NIR deja la n'est PAS
   modifie : la fiche fait foi, et ce que la DSN disait d'autre est
   seulement SIGNALE -- c'est a l'humain de dater un changement, pas a un
   import de l'ecraser (voir operations_fiches, « un champ declare ne
   s'ecrase pas, il se date »).
3. **Les spectacles**, par numero d'objet. Un numero inconnu devient une
   fiche `objet-<numero>`, titre « A COMPLETER » : ni la DSN ni l'AEM ne
   portent le titre, et on ne l'invente pas. L'annee se lit dans le numero
   (266Z... = 2026) ; seul un numero de l'annee est actif.
4. **L'historique des contrats** (`historique/engagements.json`) : chaque
   AEM attestee, rattachee a sa fiche salarie par le NIR. C'est ce que
   `cumul.py` lit pour les droits -- et c'est ce qui fait que le logiciel
   n'a plus besoin du dossier `export/` de CoolPaie une fois l'import fait.

Rien n'est ecrit par `apercu_importation` ; `importer` ecrit, et rend le
meme compte rendu, complete de ce qui a ete ecrit. Les deux faces montrent
l'apercu avant d'ecrire.

Un import se rejoue sans dommage : ce qui existe est laisse, ce qui manque
est ajoute. Une compagnie peut donc importer une premiere fois, produire des
mois, puis reimporter un export plus recent.
"""
from __future__ import annotations

import datetime as _dt
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from . import champs as _champs
from . import emplois as _emplois
from . import importation as _imp
from .contexte import Contexte
from .operations_fiches import TITRE_A_COMPLETER, enregistrer_fiche, FicheRefusee
from .operations_socle import ErreurOperation, _lire_json, _sauver_avant

FICHIER_HISTORIQUE = "engagements.json"


class ExportIntrouvable(ErreurOperation):
    """Le dossier donne ne contient ni DSN ni AEM de CoolPaie."""


@dataclass
class FicheImportee:
    """Une fiche que l'import cree, laisse, ou sur laquelle il a a redire."""
    nom: str                      # "entreprise" | "salarie" | "spectacle"
    cle: Optional[str]
    libelle: str
    etat: str                     # "a_creer" | "creee" | "existante"
    # Ce que la DSN declarait et que la fiche dit autrement. Signale, jamais
    # applique : {champ: {"fiche": ..., "dsn": ..., "mois": ...}}.
    ecarts: dict = field(default_factory=dict)
    # Les anomalies de la fiche telle qu'elle est (ou serait) ecrite.
    anomalies: list = field(default_factory=list)
    donnees: dict = field(default_factory=dict)


@dataclass
class Importation:
    source: str
    dsn: int = 0
    aem: int = 0
    premier_mois: str = ""
    dernier_mois: str = ""
    entreprise: Optional[FicheImportee] = None
    salaries: list = field(default_factory=list)
    spectacles: list = field(default_factory=list)
    # L'historique : combien de contrats, sur quelle periode, et combien
    # etaient deja la.
    contrats: int = 0
    contrats_nouveaux: int = 0
    contrats_du: str = ""
    contrats_au: str = ""
    # Contrats dont le NIR ne correspond a aucune fiche, meme apres creation.
    contrats_sans_fiche: int = 0
    avertissements: list = field(default_factory=list)
    ecrit: bool = False
    fichiers: list = field(default_factory=list)

    @property
    def a_creer(self) -> list:
        return [f for f in [self.entreprise] + self.salaries + self.spectacles
                if f and f.etat == "a_creer"]

    @property
    def rien_a_faire(self) -> bool:
        return not self.a_creer and not self.contrats_nouveaux


# ------------------------------------------------------------- l'historique
def chemin_historique(ctx: Contexte) -> Path:
    return Path(ctx.racine) / "historique" / FICHIER_HISTORIQUE


def lire_historique(ctx: Contexte) -> dict:
    """Le fichier tel qu'il est, ou un squelette vide."""
    p = chemin_historique(ctx)
    data = _lire_json(p) if p.exists() else {}
    data.setdefault("engagements", [])
    return data


def _cle_engagement(e: dict) -> tuple:
    return (e["salarie"], e["debut"], e["fin"], e.get("numero_objet", ""),
            int(e.get("heures", 0)), int(e.get("cachets", 0)),
            int(e.get("jours", 0)), str(e.get("brut", "0")))


# ---------------------------------------------------------------- l'apercu
def _fiche_salarie(decl: _imp.SalarieDeclare) -> dict:
    """Ce qu'une fiche neuve recoit d'une DSN : les formes declarees, leurs
    formes lisibles (casse de titre, l'accent manquant se corrige a l'ecran),
    la cle du NIR, le statut de bareme deduit du metier declare."""
    f = dict(decl.fiche)
    f["nir_cle"] = _champs.cle_nir(decl.nir) or ""
    f["nir"] = decl.nir
    if decl.initiales:
        f["initiales_contrat"] = decl.initiales
    # Le statut de bareme (artiste / technicien) n'est pas dans la DSN : il
    # se deduit du code emploi France Travail, par le catalogue des metiers.
    # A defaut, de la PCS : 354x, ce sont les artistes des spectacles.
    m = _emplois.metier(f.get("code_emploi_ft", "")) or {}
    f["statut"] = m.get("statut") or (
        "artiste" if str(f.get("pcs_ese", "")).startswith("354") else "technicien")
    f = _champs.combler_affichage("salarie", f)
    f["actif"] = True
    return f


def _fiche_spectacle(o: _imp.ObjetDeclare, aujourdhui: _dt.date) -> dict:
    """Un numero d'objet sans titre. Actif seulement s'il est de l'annee :
    France Travail en delivre un nouveau chaque annee."""
    return {"titre": TITRE_A_COMPLETER, "numero_objet": o.numero, "alias": [],
            "annee": o.annee, "actif": o.annee == str(aujourdhui.year),
            "_vu_dans": "%s de %s a %s (%d contrat(s))"
                        % (o.source, o.premier_mois, o.dernier_mois, o.contrats)}


def _fiche_entreprise(lecture: _imp.LectureDsn) -> dict:
    e = dict(lecture.entreprise)
    if e.get("siren") and e.get("nic"):
        e["siret"] = e["siren"] + e["nic"]
    if lecture.licences:
        e["licence_spectacle"] = [{"depuis": "%s-01" % mois, "numero": num}
                                  for mois, num in lecture.licences]
    e = _champs.combler_affichage("entreprise", e)
    if e.get("raison_sociale") and not e.get("nom_affichage"):
        e["nom_affichage"] = e["raison_sociale"].title()
    return e


def _ecarts(nom: str, fiche: dict, declare: dict, mois: str) -> dict:
    """Les champs DECLARES que la DSN disait autrement que la fiche."""
    out = {}
    for c in _champs.FICHES[nom]:
        if not c.declare or c.cle not in declare:
            continue
        a, b = fiche.get(c.cle), declare[c.cle]
        if a in (None, "") or str(a) == str(b):
            continue
        out[c.cle] = {"fiche": a, "dsn": b, "mois": mois}
    return out


def apercu_importation(ctx: Contexte, dossier=None,
                       aujourdhui: Optional[_dt.date] = None) -> Importation:
    """Ce que l'import ferait. Rien n'est ecrit."""
    # Les fiches TELLES QU'ELLES SONT SUR LE DISQUE, pas telles que l'appelant
    # les a lues : un contexte garde en memoire pendant qu'un import ecrit
    # verrait encore le salarie absent, et le creerait une deuxieme fois.
    ctx = Contexte(ctx.racine)
    aujourdhui = aujourdhui or _dt.date.today()
    export = Path(dossier) if dossier else ctx.export
    where = _imp.dossiers(export)
    if not where["dsn"] and not where["aem"]:
        raise ExportIntrouvable(
            "Aucune DSN ni AEM de CoolPaie sous %s. Le dossier attendu est "
            "celui que CoolPaie appelle `export/`, avec ses sous-dossiers "
            "`DSN/` et `AEM_EDI/`." % export)
    imp = Importation(source=str(export))

    lecture = _imp.lire_dsn(where["dsn"]) if where["dsn"] else _imp.LectureDsn()
    imp.dsn = lecture.fichiers
    imp.premier_mois, imp.dernier_mois = lecture.premier_mois, lecture.dernier_mois
    for f in lecture.illisibles:
        imp.avertissements.append("DSN illisible, ignoree : %s" % f)

    # 1. L'entreprise : seulement si la fiche est vide.
    if lecture.entreprise:
        if not str(ctx.entreprise.get("siren") or "").strip():
            donnees = _fiche_entreprise(lecture)
            imp.entreprise = FicheImportee(
                "entreprise", None, donnees.get("raison_sociale", "?"), "a_creer",
                anomalies=_champs.verifier_fiche("entreprise", donnees),
                donnees=donnees)
        else:
            imp.entreprise = FicheImportee(
                "entreprise", None, ctx.entreprise.get("raison_sociale", ""),
                "existante",
                ecarts=_ecarts("entreprise", ctx.entreprise, lecture.entreprise,
                               lecture.dernier_mois))

    # 2. Les salaries, par NIR.
    par_nir = {s["nir"]: cle for cle, s in ctx.salaries.items()}
    for nir, decl in sorted(lecture.salaries.items(), key=lambda kv: kv[1].mois):
        libelle = "%s %s" % (decl.fiche.get("nom", ""),
                             (decl.fiche.get("prenom") or "").title())
        if nir in par_nir:
            cle = par_nir[nir]
            imp.salaries.append(FicheImportee(
                "salarie", cle, libelle, "existante",
                ecarts=_ecarts("salarie", ctx.salaries[cle], decl.fiche, decl.mois)))
            continue
        donnees = _fiche_salarie(decl)
        imp.salaries.append(FicheImportee(
            "salarie", None, libelle, "a_creer",
            anomalies=_champs.verifier_fiche("salarie", donnees), donnees=donnees))

    # 3. Les spectacles, par numero d'objet -- ceux des DSN et ceux des AEM.
    contrats, illisibles = (_imp.lire_aem(where["aem"]) if where["aem"]
                            else ([], []))
    for f in illisibles:
        imp.avertissements.append("AEM illisible, ignoree : %s" % f)
    imp.aem = len({c.fichier for c in contrats})
    objets = dict(lecture.objets)
    for c in contrats:
        if not c.numero_objet:
            continue
        m = c.fin.strftime("%Y-%m")
        if c.numero_objet not in objets:
            objets[c.numero_objet] = _imp.ObjetDeclare(c.numero_objet, m, m, 0, "AEM")
        o = objets[c.numero_objet]
        if o.source == "AEM":
            o.dernier_mois, o.contrats = max(o.dernier_mois, m), o.contrats + 1
    connus = {sp.get("numero_objet", "").upper(): cle
              for cle, sp in ctx.spectacles.items()}
    for numero, o in sorted(objets.items(), key=lambda kv: kv[1].premier_mois):
        if numero.upper() in connus:
            imp.spectacles.append(FicheImportee(
                "spectacle", connus[numero.upper()],
                "%s (%s)" % (ctx.spectacles[connus[numero.upper()]].get("titre", "?"), numero),
                "existante"))
            continue
        donnees = _fiche_spectacle(o, aujourdhui)
        imp.spectacles.append(FicheImportee(
            "spectacle", None, "objet %s (%s)" % (numero, o.annee or "?"),
            "a_creer", anomalies=_champs.verifier_fiche("spectacle", donnees),
            donnees=donnees))

    # 4. L'historique : les contrats attestes, rattaches par NIR aux fiches
    # -- existantes ou a creer.
    cles_a_venir = {s.donnees["nir"]: None for s in imp.salaries
                    if s.etat == "a_creer"}
    deja = {_cle_engagement(e) for e in lire_historique(ctx)["engagements"]}
    imp.contrats = len(contrats)
    if contrats:
        imp.contrats_du = str(min(c.debut for c in contrats))
        imp.contrats_au = str(max(c.fin for c in contrats))
    for c in contrats:
        if c.nir not in par_nir and c.nir not in cles_a_venir:
            imp.contrats_sans_fiche += 1
            continue
        cle = par_nir.get(c.nir, "<a creer>")
        if (cle, str(c.debut), str(c.fin), c.numero_objet, c.heures, c.cachets,
                c.jours, str(c.brut)) not in deja:
            imp.contrats_nouveaux += 1
    if imp.contrats_sans_fiche:
        imp.avertissements.append(
            "%d contrat(s) atteste(s) portent un NIR qu'aucune DSN ne declare : "
            "ils ne seront pas rattaches a une fiche, donc pas comptes dans "
            "les droits. Creer la fiche a la main, puis reimporter."
            % imp.contrats_sans_fiche)
    imp._contrats = contrats                      # pour `importer`, pas pour le front
    return imp


# ------------------------------------------------------------------ l'ecriture
def importer(ctx: Contexte, dossier=None,
             aujourdhui: Optional[_dt.date] = None) -> Importation:
    """Ecrit ce que l'apercu annonce. Rend l'apercu, complete de ce qui a
    ete ecrit.

    Les fiches passent par `enregistrer_fiche`, comme celles de l'ecran :
    meme cle, meme matricule, meme verification, meme filet. Une fiche
    importee avec des anomalies est ecrite quand meme (`forcer`) : elle
    porte ce que CoolPaie a declare pendant des annees, et l'ecran de
    configuration montre ce qui reste a completer. Refuser la fiche, ce
    serait perdre les contrats qui s'y rattachent.
    """
    imp = apercu_importation(ctx, dossier, aujourdhui)
    note = "Importe de CoolPaie le %s" % (aujourdhui or _dt.date.today()).strftime("%d/%m/%Y")
    ecrits = []

    def _ecrire(f: FicheImportee):
        try:
            v = enregistrer_fiche(ctx, f.nom, f.cle, f.donnees, forcer=True, note=note)
        except FicheRefusee as e:          # forcer=True : ne devrait pas arriver
            imp.avertissements.append("%s %s : %s" % (f.nom, f.libelle, e))
            return
        f.cle, f.etat, f.anomalies = v.cle, "creee", v.anomalies
        ecrits.append(f)

    if imp.entreprise and imp.entreprise.etat == "a_creer":
        _ecrire(imp.entreprise)
    for f in imp.salaries:
        if f.etat == "a_creer":
            _ecrire(f)
    for f in imp.spectacles:
        if f.etat == "a_creer":
            _ecrire(f)
    if ecrits:
        imp.fichiers.extend(sorted({
            str(Path(ctx.racine) / "config" / {"entreprise": "entreprise.json",
                                                "salarie": "salaries.json",
                                                "spectacle": "spectacles.json"}[f.nom])
            for f in ecrits}))

    # L'historique, avec les fiches telles qu'elles sont MAINTENANT.
    frais = Contexte(ctx.racine)
    par_nir = {s["nir"]: cle for cle, s in frais.salaries.items()}
    data = lire_historique(ctx)
    deja = {_cle_engagement(e) for e in data["engagements"]}
    ajoutes = 0
    for c in imp._contrats:
        cle = par_nir.get(c.nir)
        if not cle:
            continue
        e = {"salarie": cle, "debut": str(c.debut), "fin": str(c.fin),
             "numero_objet": c.numero_objet, "heures": c.heures,
             "cachets": c.cachets, "jours": c.jours, "brut": str(c.brut),
             "atteste_par": "AEM", "numero_attestation": c.numero_attestation,
             "atteste_le": c.date_attestation, "fichier": c.fichier}
        if _cle_engagement(e) in deja:
            continue
        deja.add(_cle_engagement(e))
        data["engagements"].append(e)
        ajoutes += 1
    if ajoutes or not chemin_historique(ctx).exists():
        data["engagements"].sort(key=lambda e: (e["debut"], e["fin"], e["salarie"]))
        data.setdefault("_note", (
            "Les contrats attestes AVANT ce logiciel, importes des AEM de "
            "CoolPaie. cumul.py les lit pour les droits (annexes 8 et 10) "
            "quand aucun fichier de paie ne couvre leur mois. Un mois qui a "
            "son fichier dans paies/ est lu la, jamais ici."))
        data["importe_le"] = (aujourdhui or _dt.date.today()).isoformat()
        data["source"] = imp.source
        p = chemin_historique(ctx)
        p.parent.mkdir(parents=True, exist_ok=True)
        _sauver_avant(p)
        p.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        imp.fichiers.append(str(p))
    imp.contrats_nouveaux = ajoutes
    imp.ecrit = True
    return imp
