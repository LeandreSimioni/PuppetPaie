"""Lire ce que CoolPaie a depose -- pour ne pas le ressaisir.

Une compagnie qui quitte CoolPaie a deja tout declare pendant des annees :
ses salaries (NIR, adresse, emploi), ses spectacles (les numeros d'objet
France Travail), et chaque contrat (les AEM). Ressaisir cela a la main est le
genre de travail ou l'on se trompe d'un chiffre sur un NIR -- et une DSN au
NIR faux, c'est un salarie que France Travail ne rapproche plus.

Ce module LIT le dossier `export/` de CoolPaie et rend des donnees. Il
n'ecrit rien : c'est `operations_importation` qui decide quoi creer, et qui
passe par les memes fiches que l'ecran.

Deux sources, et chacune sait une chose que l'autre ignore :

    export/DSN/*.dsn       l'identite des salaries (bloc S21.G00.30), leur
                           emploi declare (bloc 40), les numeros d'objet
                           (40.050), l'entreprise (S10, blocs 06 et 11)
    export/AEM_EDI/*.txt   les contrats un par un, tels qu'ils ont ete
                           attestes a France Travail : dates, cachets, heures,
                           jours, brut. C'est LA source des droits (cumul.py)

La base CoolPaie elle-meme (`bases/*.CSOC`) est chiffree : on ne la lit pas,
et on n'en a pas besoin. Ce qui manque -- le TITRE des spectacles, que ni la
DSN ni l'AEM ne portent -- se complete a l'ecran, une fois.

Rien de ce module ne connait un front. Aucune donnee reelle ici : les
valeurs viennent du dossier qu'on lui donne.
"""
from __future__ import annotations

import datetime as _dt
import glob
from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import Optional

from .aem import CHAMPS


# ----------------------------------------------------------------- les DSN
# Bloc S21.G00.30 (individu) -> champ de `salaries.json`. Ce que la DSN
# declare, sous le nom que la fiche lui donne. Les formes lisibles
# (`nom_affichage`...) se fabriquent ensuite, par `champs.combler_affichage`.
IDENTITE = {
    "S21.G00.30.001": "nir",
    "S21.G00.30.002": "nom",
    "S21.G00.30.004": "prenom",
    "S21.G00.30.006": "date_naissance",        # JJMMAAAA, converti
    "S21.G00.30.007": "lieu_naissance",
    "S21.G00.30.008": "adresse",
    "S21.G00.30.009": "code_postal",
    "S21.G00.30.010": "commune",
    "S21.G00.30.013": "code_nationalite_dsn",
    "S21.G00.30.014": "departement_naissance",
    "S21.G00.30.015": "pays_naissance",
    "S21.G00.30.018": "email",
    "S21.G00.30.019": "code_salarie",
}

# Bloc S21.G00.40 (contrat) -> ce que la fiche salarie porte de l'emploi.
EMPLOI = {
    "S21.G00.40.002": "statut_conventionnel",
    "S21.G00.40.003": "statut_categoriel_rc",
    "S21.G00.40.004": "pcs_ese",
    "S21.G00.40.005": "code_emploi_ft",
    "S21.G00.40.006": "emploi",
}

# L'entreprise : l'en-tete S10 et les blocs 06 / 11 / 40.
ENTREPRISE = {
    "S10.G00.01.001": "siren",
    "S10.G00.01.002": "nic",
    "S10.G00.01.003": "raison_sociale",
    "S10.G00.01.004": "adresse",
    "S10.G00.01.005": "code_postal",
    "S10.G00.01.006": "commune",
    "S21.G00.06.003": "naf",
    "S21.G00.11.022": "code_convention_dsn",
    "S21.G00.40.017": "idcc",
    "S21.G00.40.022": "congesspectacles_affiliation",
}


def _jjmmaaaa(v: str) -> str:
    """'14051991' -> '1991-05-14'. Une date illisible est rendue telle quelle :
    la verification de la fiche la signalera, on ne l'invente pas."""
    if len(v) == 8 and v.isdigit():
        return "%s-%s-%s" % (v[4:8], v[2:4], v[0:2])
    return v


def _mois_dsn(v: str) -> str:
    """S20.G00.05.005 '01072026' -> '2026-07'."""
    return "%s-%s" % (v[4:8], v[2:4]) if len(v) == 8 else ""


@dataclass
class SalarieDeclare:
    """Ce qu'une DSN dit d'un salarie : son identite, et l'emploi de son
    dernier contrat. `mois` et `depot` disent quelle DSN l'a dit."""
    nir: str
    fiche: dict
    mois: str
    depot: str
    # Le prefixe des numeros de contrat (`PU1.26.11` -> `PU`) : c'est
    # `initiales_contrat` dans la fiche, et il ne se lit que la.
    initiales: str = ""


@dataclass
class ObjetDeclare:
    numero: str
    premier_mois: str
    dernier_mois: str
    contrats: int = 0
    source: str = "DSN"           # ou "AEM" : vu seulement dans une attestation

    @property
    def annee(self) -> str:
        """France Travail delivre un numero par spectacle ET par annee, et
        l'annee se lit dans le numero : 216Z = 2021, 266Z = 2026 : les deux premiers chiffres."""
        n = self.numero
        return "20" + n[0:2] if len(n) >= 4 and n[0:2].isdigit() else ""


@dataclass
class LectureDsn:
    fichiers: int = 0
    salaries: dict = field(default_factory=dict)      # nir -> SalarieDeclare
    objets: dict = field(default_factory=dict)        # numero -> ObjetDeclare
    entreprise: dict = field(default_factory=dict)
    # Les licences dans l'ordre ou elles apparaissent : [(mois, numero)].
    licences: list = field(default_factory=list)
    premier_mois: str = ""
    dernier_mois: str = ""
    illisibles: list = field(default_factory=list)


def lire_une_dsn(chemin) -> Optional[dict]:
    """Une DSN deposee : son mois, ses individus, ses contrats.

    Le fichier est lu ligne a ligne, en gardant l'individu courant : les
    blocs 40 qui suivent un bloc 30 sont ses contrats. C'est la structure de
    la norme, et c'est tout ce qu'on suppose d'elle.
    """
    try:
        lignes = Path(chemin).read_text(encoding="latin-1").splitlines()
    except OSError:
        return None
    mois = depot = ""
    entreprise, individus, contrats = {}, [], []
    cur = None
    for l in lignes:
        if "," not in l:
            continue
        k, v = l.split(",", 1)
        v = v.strip().strip("'")
        if k == "S20.G00.05.005":
            mois = _mois_dsn(v)
        elif k == "S20.G00.05.007":
            depot = _jjmmaaaa(v)
        elif k in ENTREPRISE:
            entreprise.setdefault(ENTREPRISE[k], v)
        elif k == "S21.G00.40.049":
            entreprise.setdefault("licence", v)
        elif k == "S21.G00.30.001":
            cur = {"nir": v}
            individus.append(cur)
        elif k in IDENTITE and cur is not None:
            champ = IDENTITE[k]
            cur[champ] = _jjmmaaaa(v) if champ == "date_naissance" else v
        elif k == "S21.G00.40.001" and cur is not None:
            contrats.append({"nir": cur["nir"], "debut": _jjmmaaaa(v)})
        elif k in EMPLOI and contrats:
            contrats[-1][EMPLOI[k]] = v
        elif k == "S21.G00.40.009" and contrats:
            contrats[-1]["numero"] = v
        elif k == "S21.G00.40.010" and contrats:
            contrats[-1]["fin"] = _jjmmaaaa(v)
        elif k == "S21.G00.40.050" and contrats:
            contrats[-1]["objet"] = v
    if not mois:
        return None
    return {"mois": mois, "depot": depot, "entreprise": entreprise,
            "individus": individus, "contrats": contrats,
            "fichier": Path(chemin).name}


def lire_dsn(dossier) -> LectureDsn:
    """Toutes les DSN d'un dossier, la plus recente faisant foi par salarie.

    Une meme personne apparait dans des dizaines de DSN ; c'est la DERNIERE
    qui dit son adresse d'aujourd'hui et son dernier emploi. Les numeros
    d'objet, eux, sont tous gardes : un spectacle de 2023 ne se joue plus,
    mais ses AEM le citent, et la fiche archivee reste lisible.
    """
    out = LectureDsn()
    lues = []
    for f in sorted(glob.glob(str(Path(dossier) / "*.dsn"))):
        info = lire_une_dsn(f)
        if info is None:
            out.illisibles.append(Path(f).name)
            continue
        lues.append(info)
    # Par mois declare, puis par date de depot : un annule-et-remplace
    # d'aout depose en septembre passe apres l'original, et fait foi.
    lues.sort(key=lambda i: (i["mois"], i["depot"], i["fichier"]))
    out.fichiers = len(lues)
    if lues:
        out.premier_mois, out.dernier_mois = lues[0]["mois"], lues[-1]["mois"]
    for info in lues:
        for k, v in info["entreprise"].items():
            if k == "licence":
                if not out.licences or out.licences[-1][1] != v:
                    out.licences.append((info["mois"], v))
            else:
                out.entreprise[k] = v
        dernier_contrat = {}
        for c in info["contrats"]:
            dernier_contrat[c["nir"]] = c
            objet = c.get("objet")
            if objet:
                o = out.objets.setdefault(objet, ObjetDeclare(
                    objet, info["mois"], info["mois"]))
                o.dernier_mois = info["mois"]
                o.contrats += 1
        for ind in info["individus"]:
            fiche = {k: v for k, v in ind.items() if k != "nir"}
            c = dernier_contrat.get(ind["nir"], {})
            for champ in EMPLOI.values():
                if c.get(champ):
                    fiche[champ] = c[champ]
            numero = c.get("numero", "")
            initiales = "".join(ch for ch in numero.split(".")[0]
                                if ch.isalpha())[:2]
            out.salaries[ind["nir"]] = SalarieDeclare(
                ind["nir"], fiche, info["mois"], info["depot"], initiales)
    return out


# ----------------------------------------------------------------- les AEM
@dataclass
class ContratAtteste:
    """Un enregistrement AEM : un contrat tel qu'il a ete atteste."""
    nir: str
    nom: str
    prenom: str
    date_naissance: str
    debut: _dt.date
    fin: _dt.date
    numero_objet: str
    heures: int
    cachets: int
    jours: int
    brut: Decimal
    numero_attestation: str
    date_attestation: str
    fichier: str

    @property
    def cle_contrat(self) -> tuple:
        """Ce qui fait qu'un contrat est le meme d'une reedition a l'autre.
        La meme cle que `cumul.lire_aem`."""
        return (self.nir, self.debut, self.fin, self.numero_objet,
                self.heures, self.cachets, self.jours, self.brut)


def _champ(ligne: str, nom: str) -> str:
    a, b = CHAMPS[nom]
    return ligne[a:b]


def lire_aem(dossier) -> tuple:
    """Tous les contrats attestes d'un dossier AEM_EDI, dedoublonnes.

    Rend (contrats, illisibles). Un enregistrement par LIGNE -- 1000
    caracteres suivis d'un CRLF ; les decouper par offsets fixes fait deriver
    de deux octets par enregistrement, et les suivants disparaissent sans
    erreur (voir cumul.lire_aem, ou c'est arrive).

    Un meme contrat reedite (rectificatif, reimpression) n'est garde qu'une
    fois ; c'est la PREMIERE attestation qui est citee.
    """
    vus, illisibles = {}, []
    for f in sorted(glob.glob(str(Path(dossier) / "*.txt"))):
        try:
            data = Path(f).read_text(encoding="latin-1", errors="replace")
        except OSError:
            illisibles.append(Path(f).name)
            continue
        for ligne in data.splitlines():
            if len(ligne) < 700:
                continue
            try:
                c = ContratAtteste(
                    nir=_champ(ligne, "nir")[:13],
                    nom=_champ(ligne, "nom").strip(),
                    prenom=_champ(ligne, "prenom").strip(),
                    date_naissance=_aaaammjj(_champ(ligne, "date_naissance")),
                    debut=_dt.datetime.strptime(_champ(ligne, "date_debut"), "%Y%m%d").date(),
                    fin=_dt.datetime.strptime(_champ(ligne, "date_fin"), "%Y%m%d").date(),
                    numero_objet=_champ(ligne, "numero_objet").strip(),
                    heures=int(_champ(ligne, "nb_heures")),
                    cachets=int(_champ(ligne, "nb_cachets")),
                    jours=int(_champ(ligne, "nb_jours")),
                    brut=(Decimal(_champ(ligne, "brut_cts")) / 100).quantize(Decimal("0.01")),
                    numero_attestation=_champ(ligne, "num_attestation").strip(),
                    date_attestation=_aaaammjj(_champ(ligne, "date_signature")),
                    fichier=Path(f).name)
            except ValueError:
                illisibles.append("%s : un enregistrement illisible" % Path(f).name)
                continue
            vus.setdefault(c.cle_contrat, c)
    return sorted(vus.values(), key=lambda c: (c.debut, c.fin, c.nir)), illisibles


def _aaaammjj(v: str) -> str:
    """'19910514' -> '1991-05-14' (les dates de l'AEM)."""
    if len(v) == 8 and v.isdigit():
        return "%s-%s-%s" % (v[0:4], v[4:6], v[6:8])
    return v


# --------------------------------------------------------------- le dossier
def dossiers(export) -> dict:
    """Ou sont les DSN et les AEM sous un dossier `export/` de CoolPaie.

    On accepte aussi qu'on nous donne directement le dossier des DSN ou
    celui des AEM : une compagnie qui a copie l'un sans l'autre ne doit pas
    avoir a reconstituer l'arborescence de CoolPaie.
    """
    export = Path(export)
    dsn = export / "DSN"
    aem = export / "AEM_EDI"
    if not dsn.is_dir() and glob.glob(str(export / "*.dsn")):
        dsn = export
    if not aem.is_dir() and glob.glob(str(export / "*EDIV5*.txt")):
        aem = export
    return {"dsn": dsn if dsn.is_dir() else None,
            "aem": aem if aem.is_dir() else None}
