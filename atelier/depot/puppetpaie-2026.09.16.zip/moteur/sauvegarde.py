"""La sauvegarde du dossier prive dans le Drive, par differences.

    python -m moteur sauvegarder              ce qui a change, et rien d'autre
    python -m moteur sauvegarder --tout       tout renvoyer, sans regarder

CE QU'ELLE SAUVE, ET CE QU'ELLE NE SAUVE PAS
---------------------------------------------
Tout le dossier des DONNEES : `config/`, `paies/`, `sorties/`, `retours/`,
`gabarits/`, `journal/`, `reference/`. C'est-a-dire ce qui n'existe qu'ici et
que personne d'autre ne peut reconstituer -- le code, lui, sera sur GitHub.

Trois familles restent a terre, et pour des raisons differentes :

    coffre.bin, google-jeton.bin   des SECRETS. Ils sont chiffres par DPAPI,
                                   donc illisibles ailleurs de toute facon :
                                   les televerser n'aiderait personne et
                                   mettrait un secret dans un nuage.
    .seance, .compteurs.verrou     de l'etat de la machine, vrai ici et
                                   maintenant. Restaure ailleurs, il ment.
    __pycache__, *.pyc, *.tmp      du rebut.

ELLE NE SUPPRIME JAMAIS RIEN. Un fichier efface ici reste la-bas. Une
sauvegarde qui repercute les suppressions n'est pas une sauvegarde : c'est un
miroir, et un miroir recopie fidelement les accidents.

COMMENT ELLE SAIT CE QUI A CHANGE
----------------------------------
Par l'empreinte MD5, que Google calcule de son cote et publie pour chaque
fichier (`md5Checksum`). On liste un dossier Drive, on compare, on ne renvoie
que ce qui differe. C'est exact : ni la date ni la taille ne sont crues sur
parole.

Un INDEX local (`config/.sauvegarde.json`) garde en plus, pour chaque fichier,
sa taille et sa date de modification au dernier passage, et l'identifiant des
dossiers Drive deja crees. Il sert a deux choses :

  - `rien_n_a_bouge()` repond SANS TOUCHER AU RESEAU. C'est ce qui permet a
    l'interface de repasser toutes les vingt minutes sans rien couter quand
    personne n'a rien produit ;
  - les identifiants de dossiers evitent de re-resoudre l'arborescence a
    chaque fois (deux appels par dossier, une vingtaine de dossiers).

L'index n'est jamais cru pour DECIDER d'un televersement : la decision se
prend sur l'empreinte que Drive renvoie. Un index perdu coute un passage plus
lent, pas une sauvegarde fausse.

`drive.file` ne voit que ce que cette application a cree. La sauvegarde ne
peut donc ni lire ni ecraser quoi que ce soit d'autre dans le Drive.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path

RACINE_DRIVE = "PuppetPaie"
DOSSIER_DRIVE = "sauvegarde"
INDEX = ".sauvegarde.json"

# Ce qui ne monte pas, et pourquoi : voir le docstring.
NOMS_EXCLUS = {"coffre.bin", "google-jeton.bin", ".seance", ".jeton-interface",
               ".compteurs.verrou", ".sauvegarde.json", ".ouverture.json"}
SUFFIXES_EXCLUS = (".pyc", ".tmp", ".lock", ".part")
DOSSIERS_EXCLUS = {"__pycache__", ".git"}


@dataclass
class Fichier:
    relatif: str
    octets: int
    etat: str                 # "neuf" | "modifie" | "identique"


@dataclass
class Sauvegarde:
    racine_drive: str
    compte: str
    deposes: list = field(default_factory=list)
    identiques: int = 0
    octets_deposes: int = 0
    exclus: int = 0
    disparus: int = 0         # purges entre l'inventaire et l'envoi : pas un incident
    secondes: float = 0.0
    incidents: list = field(default_factory=list)

    @property
    def a_change(self) -> bool:
        return bool(self.deposes)

    def resume(self) -> str:
        if not self.deposes:
            return "Sauvegarde a jour (%d fichiers)." % self.identiques
        return ("Sauvegarde : %d fichier(s) envoye(s), %s, %d inchange(s)."
                % (len(self.deposes), _lisible(self.octets_deposes),
                   self.identiques))


# ---------------------------------------------------------------- l'inventaire
def _ecarte(chemin: Path, racine: Path) -> bool:
    if chemin.name in NOMS_EXCLUS or chemin.name.endswith(SUFFIXES_EXCLUS):
        return True
    return any(part in DOSSIERS_EXCLUS for part in chemin.relative_to(racine).parts)


def empreinte(chemin: Path) -> str:
    """MD5 du contenu -- le meme que Drive publie. Lu par morceaux."""
    h = hashlib.md5()
    with open(chemin, "rb") as f:
        for bloc in iter(lambda: f.read(1024 * 256), b""):
            h.update(bloc)
    return h.hexdigest()


def inventaire(racine) -> tuple:
    """({relatif: {octets, mtime}}, nombre d'ecartes). Ne lit aucun contenu.

    Volontairement paresseux : l'empreinte n'est calculee que pour les
    fichiers qu'on s'apprete a comparer, pas pour les 14 Mo de `reference/` a
    chaque passage.
    """
    racine = Path(racine)
    trouves, ecartes = {}, 0
    for p in sorted(racine.rglob("*")):
        if not p.is_file():
            continue
        if _ecarte(p, racine):
            ecartes += 1
            continue
        etat = p.stat()
        trouves[p.relative_to(racine).as_posix()] = {
            "octets": etat.st_size, "mtime": int(etat.st_mtime)}
    return trouves, ecartes


# --------------------------------------------------------------------- l'index
def chemin_index(ctx) -> Path:
    """`config/`, et pas `journal/` : c'est de l'etat machine, pas un document.

    Il est ECARTE de la sauvegarde (voir NOMS_EXCLUS). Sans cela, ecrire
    l'index serait un changement du dossier prive, donc quelque chose a
    sauvegarder -- et le passage suivant trouverait toujours du neuf.
    """
    return Path(ctx.racine) / "config" / INDEX


def _lire_index(ctx) -> dict:
    p = chemin_index(ctx)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except ValueError:
        return {}


def _ecrire_index(ctx, index: dict) -> None:
    p = chemin_index(ctx)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(index, ensure_ascii=False, indent=1), encoding="utf-8")


def rien_n_a_bouge(ctx) -> bool:
    """Le disque est-il identique au dernier passage ? SANS RESEAU.

    Taille et date de modification suffisent ici : on ne decide pas d'un
    televersement, on decide seulement s'il vaut la peine d'aller voir. Au
    moindre doute -- index absent, fichier apparu ou disparu -- la reponse est
    non, et le passage complet tranche.
    """
    index = _lire_index(ctx)
    connus = index.get("fichiers")
    if not connus:
        return False
    presents, _ = inventaire(ctx.racine)
    if set(presents) != set(connus):
        return False
    for relatif, etat in presents.items():
        ancien = connus[relatif]
        if (etat["octets"] != ancien.get("octets")
                or etat["mtime"] != ancien.get("mtime")):
            return False
    return True


def derniere(ctx) -> dict:
    """Ce que dit l'index du dernier passage : quand, combien. Pour l'affichage."""
    index = _lire_index(ctx)
    return {"quand": index.get("quand", ""),
            "fichiers": len(index.get("fichiers") or {}),
            "racine_drive": index.get("racine_drive", "")}


# ---------------------------------------------------------------- le passage
def sauvegarder(ctx, racine_drive: str = RACINE_DRIVE,
                tout: bool = False, client=None) -> Sauvegarde:
    """Envoie ce qui a change. Rend le compte rendu, n'imprime rien.

    `client` n'est la que pour les tests : en usage normal la sauvegarde
    fabrique le sien.
    """
    from . import google

    debut = time.time()
    client = client or google.Client(ctx)
    racine = Path(ctx.racine)
    presents, ecartes = inventaire(racine)
    index = _lire_index(ctx)
    dossiers = dict(index.get("dossiers") or {}) if not tout else {}

    resultat = Sauvegarde(racine_drive=racine_drive,
                          compte=getattr(client, "compte", ""), exclus=ecartes)
    # Ce qui n'a PAS pu etre depose, par chemin relatif. Ces fichiers n'entrent
    # pas dans l'index : sans ca, le passage suivant les croirait a jour.
    en_echec = set()

    # Par dossier : un seul listage Drive sert a tous les fichiers qu'il porte.
    par_dossier = {}
    for relatif in presents:
        par_dossier.setdefault(str(Path(relatif).parent.as_posix()), []).append(relatif)

    for dossier, fichiers in sorted(par_dossier.items()):
        segments = [racine_drive, DOSSIER_DRIVE]
        if dossier not in (".", ""):
            segments += dossier.split("/")
        cle = "/".join(segments)
        try:
            parent = dossiers.get(cle) or client.chemin(*segments)
            dossiers[cle] = parent
            deja = {} if tout else client.lister(parent)
        except Exception as e:                                    # noqa: BLE001
            # Un dossier qui resiste ne doit pas emporter les autres : la
            # sauvegarde est partielle, elle le dit, et le prochain passage
            # reprendra celui-la.
            resultat.incidents.append("%s : %s" % (dossier, e))
            dossiers.pop(cle, None)
            en_echec.update(fichiers)
            continue

        for relatif in sorted(fichiers):
            chemin = racine / relatif
            nom = chemin.name
            try:
                locale = empreinte(chemin)
                distante = (deja.get(nom) or {}).get("md5")
                if distante and distante == locale:
                    resultat.identiques += 1
                    continue
                client.televerser(chemin, parent)
                resultat.deposes.append(Fichier(
                    relatif=relatif, octets=presents[relatif]["octets"],
                    etat="modifie" if distante else "neuf"))
                resultat.octets_deposes += presents[relatif]["octets"]
            except FileNotFoundError:
                # LE FICHIER A DISPARU ENTRE L'INVENTAIRE ET L'ENVOI, et ce
                # n'est pas un incident : `paies/avant/` et `config/avant/`
                # ne gardent que les dernieres copies, et l'interface
                # enregistre a chaque frappe. Une copie de secours purgee
                # pendant que la sauvegarde tourne est le fonctionnement
                # normal des deux ; l'annoncer en rouge dans le bandeau
                # apprend a ne plus lire les vrais incidents. On ne l'inscrit
                # pas non plus a l'index : elle n'est pas sauvegardee.
                resultat.disparus += 1
                en_echec.add(relatif)
            except Exception as e:                                # noqa: BLE001
                resultat.incidents.append("%s : %s" % (relatif, e))
                en_echec.add(relatif)

    # L'index n'est ecrit qu'a la fin, et seulement pour ce qui est passe.
    index = {
        "quand": time.strftime("%Y-%m-%d %H:%M"),
        "racine_drive": racine_drive,
        "dossiers": dossiers,
        "fichiers": {r: e for r, e in presents.items() if r not in en_echec},
    }
    _ecrire_index(ctx, index)
    resultat.secondes = round(time.time() - debut, 1)
    return resultat


def _lisible(octets: int) -> str:
    if octets >= 1024 * 1024:
        return "%.1f Mo" % (octets / (1024 * 1024))
    if octets >= 1024:
        return "%d Ko" % (octets // 1024)
    return "%d o" % octets
