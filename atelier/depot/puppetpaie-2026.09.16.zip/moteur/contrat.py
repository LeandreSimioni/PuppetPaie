"""Contrat d'engagement a duree determinee d'usage (CDDU) - artiste du spectacle.

Le texte du contrat n'est PAS dans ce fichier. Il vit dans
`gabarits/contrat-cddu.modele`, un fichier de donnees editable par n'importe
qui : une compagnie change ses clauses, en ajoute, en retire, sans qu'une
ligne de code bouge. Ce module lit ce modele, y substitue les valeurs de la
paie et le met en page a l'identite de la compagnie.

C'est la meme regle que pour le bareme : ce qui varie d'une compagnie a
l'autre est une donnee, jamais du code.
"""
from __future__ import annotations
import html
import re
from pathlib import Path

import pymupdf

from .bulletin import _poser_logo
from .contexte import GABARITS
from .util import fmt_eur, jj_mm_aaaa

IDENTITE = GABARITS / "identite"
MODELE = GABARITS / "contrat-cddu.modele"
SIGNATURE = IDENTITE / "signature.png"

CLES = ("TITRE:", "SOUSTITRE:", "PREAMBULE:", "ARTICLE:", "SIGNATURES:")

CSS = """
* { font-family: Arial, sans-serif; }
body { font-size: 7.5pt; color: #2C3E50; line-height: 1.25; }
.rs { font-size: 11pt; color: #2C3E50; font-weight: bold; }
.coord { font-size: 6.3pt; color: #555; }
h1 { font-size: 11pt; color: #B22222; margin: 10pt 0 1pt 0;
     text-transform: uppercase; letter-spacing: 0.5pt; }
.sub { font-size: 6.8pt; color: #555; margin: 0 0 7pt 0; }
h2 { font-size: 7.7pt; color: #B22222; margin: 4.5pt 0 1pt 0; }
p { margin: 0 0 2.6pt 0; text-align: justify; }
.fait { margin-top: 6pt; }
table { width: 100%; }
td { vertical-align: top; padding-top: 4pt; font-size: 7.5pt; }
.sign td { border-top: 0.5pt solid #ccc; padding-top: 5pt; }
.sign .label { font-size: 6.6pt; font-weight: bold; color: #B22222;
               text-transform: uppercase; letter-spacing: 0.7pt; }
.pt { font-size: 7pt; color: #777; }
"""


def lire_modele(chemin=None) -> dict:
    """Decoupe le fichier modele en titre, preambule, articles et signatures.

    Format volontairement pauvre, pour rester lisible et modifiable a la main
    dans n'importe quel editeur, et trivial a reimplementer ailleurs : une
    ligne-cle, puis son texte jusqu'a la cle suivante. Les lignes commencant
    par # sont des commentaires.
    """
    chemin = Path(chemin or MODELE)
    m = {"titre": "", "soustitre": "", "preambule": [], "articles": [],
         "signatures": []}
    etat = {"cle": None, "titre_art": None}
    tampon = []

    def vider():
        cle = etat["cle"]
        if cle == "PREAMBULE:":
            m["preambule"] = _paragraphes(tampon)
        elif cle == "ARTICLE:":
            m["articles"].append((etat["titre_art"], _paragraphes(tampon)))
        elif cle == "SIGNATURES:":
            m["signatures"] = _paragraphes(tampon)

    for ligne in chemin.read_text(encoding="utf-8").splitlines():
        if ligne.lstrip().startswith("#"):
            continue
        trouvee = None
        for k in CLES:
            if ligne.startswith(k):
                trouvee = k
                break
        if trouvee:
            vider()
            etat["cle"] = trouvee
            tampon = []
            reste = ligne[len(trouvee):].strip()
            if trouvee == "TITRE:":
                m["titre"] = reste
            elif trouvee == "SOUSTITRE:":
                m["soustitre"] = reste
            elif trouvee == "ARTICLE:":
                etat["titre_art"] = reste
        elif etat["cle"]:
            tampon.append(ligne)
    vider()
    if not m["articles"]:
        raise ValueError("%s ne contient aucun article" % chemin)
    return m


def _paragraphes(lignes) -> list:
    """Une ligne vide separe deux paragraphes ; le reste est recolle."""
    blocs, courant = [], []
    for l in lignes:
        if l.strip():
            courant.append(l.strip())
        elif courant:
            blocs.append(" ".join(courant))
            courant = []
    if courant:
        blocs.append(" ".join(courant))
    return blocs


def _aff(d: dict, cle: str) -> str:
    """Forme lisible si elle existe, forme administrative sinon.

    Les champs de `salaries.json` et `entreprise.json` viennent des DSN et des
    AEM : majuscules, sans accents, comme ces formats a largeur fixe
    l'exigent. Un contrat, lui, s'ecrit en francais normal. Les champs
    `*_affichage` portent cette seconde forme et ne sont jamais declares --
    c'est la seule difference entre les deux, et elle doit rester purement
    typographique : meme rue, meme commune.
    """
    return d.get(cle + "_affichage") or d[cle]


def _remuneration_detaillee(p) -> str:
    """La remuneration en une phrase : « 2 cachets a 130,00 EUR », ou
    « 1 journee de travail a 200,00 EUR et 6 h de masterclass a 40,00 EUR ».

    Elle est construite a partir des lignes que le MOTEUR a comprises, et non
    de `cachets` x `taux_cachet` : un contrat sans cachet -- une journee, une
    masterclass -- se serait signe « 0 cachet(s) de 130,00 EUR ». Un contrat
    signe ne se rattrape pas.
    """
    morceaux = []
    for l in p.remuneration or []:
        # La designation ouvre une phrase : « 2 Cachets » y devient
        # « 2 cachets ». On ne touche qu'a la premiere majuscule.
        texte = l.designation
        for i, c in enumerate(texte):
            if c.isupper():
                texte = texte[:i] + c.lower() + texte[i + 1:]
                break
        morceaux.append("%s à %s €" % (texte, fmt_eur(l.taux)))
    phrase = _et(morceaux)
    # Un contrat qui se poursuit apres le mois : l'engagement ne porte que
    # la remuneration du mois ou le contrat est imprime. Le contrat le dit,
    # plutot que de faire passer deux cachets pour la tournee entiere ; le
    # total et le net qui suivent dans le gabarit restent ceux du mois, et
    # l'apercu le rappelle avant signature.
    e = p.engagement
    if not e.dernier_mois:
        from .envoi import MOIS_ACCENTS
        quand = "%s %d" % (MOIS_ACCENTS[int(e.mois[5:7]) - 1], int(e.mois[:4]))
        # Le gabarit fait suivre cette valeur de << brut >> : la phrase doit
        # finir sur ce qui est brut. Le total et le net du gabarit restent
        # ceux du mois -- c'est dans le gabarit (prive/gabarits/) que la
        # tournure d'une tournee se change, pas ici.
        if e.planning_connu():
            n = len(e.planning)
            phrase += (" pour %s et, pour %s du planning, payée%s dans %s mois, le même montant"
                       % (quand, "les %d dates suivantes" % n if n > 1 else "la date suivante",
                          "s" if n > 1 else "", "leur" if n > 1 else "son"))
        else:
            phrase += " pour %s et, pour les dates suivantes du planning, payées dans leur mois, le même montant" % quand
    return phrase


def _periode_remuneration(e) -> str:
    if e.dernier_mois:
        return ""
    from .envoi import MOIS_ACCENTS
    nom = MOIS_ACCENTS[int(e.mois[5:7]) - 1]
    # << d'octobre >>, << d'août >> : l'elision, sinon le contrat ecrit mal.
    de = "d'" if nom[0] in "aeiouyâàéèêîôû" else "de "
    return " pour le mois %s%s %d" % (de, nom, int(e.mois[:4]))


def _et(morceaux: list) -> str:
    """« a, b et c ». Une enumeration francaise, pas une liste separee par des
    virgules jusqu'au bout."""
    if not morceaux:
        return ""
    if len(morceaux) == 1:
        return morceaux[0]
    return "%s et %s" % (", ".join(morceaux[:-1]), morceaux[-1])


def _dates_travail(e) -> str:
    """Les jours joues, et OU chacun se joue quand ils different.

    Un seul lieu (le cas courant, et celui de toutes les saisies d'avant) :
    la phrase ne change pas d'un caractere -- « 02/10/2026, 09/10/2026 ». Le
    lieu est dit une fois, a l'article << Lieu de travail >>, et le repeter
    sur chaque date alourdirait un contrat pour ne rien apprendre.

    Plusieurs lieux : chaque groupe de dates porte le sien --
    « 02/10/2026 à Berlin, 09/10/2026 à Paris, 16/10/2026 et 17/10/2026 à
    Varzy ». C'est la raison d'etre de tout ceci : une tournee est UNE paie,
    un contrat, un bulletin, une AEM -- et le contrat doit nommer les villes.
    """
    if len(e.lieux_joues()) < 2:
        texte = ", ".join(jj_mm_aaaa(x) for x in e.dates_du_contrat())
    else:
        groupes = []
        for ou, jours in e.dates_par_lieu():
            dates = _et([jj_mm_aaaa(x) for x in jours])
            groupes.append("%s à %s" % (dates, ou) if ou else dates)
        texte = ", ".join(groupes)
    # Un contrat qui se poursuit apres le mois liste son planning quand il a
    # ete coche (les dates des mois suivants, pas encore payees). Sans
    # planning, l'engagement ne porte que les jours du mois ou il est
    # imprime : le contrat le dit plutot que de laisser croire que la liste
    # est complete.
    if not e.dernier_mois and not e.planning_connu():
        texte += ", puis les dates du planning jusqu'au %s" % jj_mm_aaaa(e.fin)
    return texte


def _lieu_du_contrat(e) -> str:
    """L'article « Lieu de travail », qui suit ce que les dates ont dit.

    Trois cas, et le troisieme est celui qui compte : quand les dates nomment
    plusieurs villes, cet article ne doit pas en choisir une. Il renvoie a la
    liste, qui est juste au-dessus dans le modele.
    """
    lieux = e.lieux_joues()
    if len(lieux) > 1:
        return "aux lieux indiqués ci-dessus"
    if lieux:
        return "à %s" % lieux[0]
    return "au lieu de la représentation"


def marqueurs(p, ent: dict) -> dict:
    """Les valeurs offertes au modele.

    Toute cle ajoutee ici devient utilisable dans le fichier .modele, et doit
    etre documentee dans la liste en bas de celui-ci.
    """
    s, e, sp = p.salarie, p.engagement, p.spectacle
    sig = ent["signataire"]
    licence = ent["licence_spectacle"]
    if not isinstance(licence, str):
        raise TypeError(
            "licence_spectacle non resolue : elle vaut %r. Le numero change "
            "de date en date ; l'appelant doit le fixer pour le mois produit "
            "avec Contexte.licence(), comme le fait cli.cmd_mois. Un contrat "
            "ne s'imprime pas avec une liste de licences a la place du "
            "numero." % (licence,))
    return {
        "employeur.raison_sociale": ent["raison_sociale"],
        "employeur.adresse": _aff(ent, "adresse"),
        "employeur.code_postal": ent["code_postal"],
        "employeur.commune": _aff(ent, "commune"),
        "employeur.siret": ent["siret"],
        "employeur.naf": ent["naf"],
        "employeur.licence": licence,
        "employeur.idcc": str(ent["idcc"]),
        "employeur.convention": ent["convention_collective"],
        "employeur.congesspectacles": str(ent["congesspectacles_affiliation"]),
        "employeur.signataire": "%s %s" % (_aff(sig, "prenom"), _aff(sig, "nom")),
        "employeur.signataire_fonction": sig["fonction"],
        "salarie.nom": s["nom"],
        "salarie.prenom": _aff(s, "prenom"),
        "salarie.nom_complet": "%s %s" % (_aff(s, "prenom"), s["nom"]),
        "salarie.date_naissance": jj_mm_aaaa(s["date_naissance"]),
        "salarie.lieu_naissance": _aff(s, "lieu_naissance"),
        "salarie.adresse": _aff(s, "adresse"),
        "salarie.code_postal": s["code_postal"],
        "salarie.commune": _aff(s, "commune"),
        "salarie.nir": "%s%s" % (s["nir"], s["nir_cle"]),
        "salarie.emploi": s["emploi"].lower(),
        "contrat.numero": str(e.numero),
        "contrat.debut": jj_mm_aaaa(e.debut),
        "contrat.fin": jj_mm_aaaa(e.fin),
        "contrat.dates_travail": _dates_travail(e),
        # La preposition voyage avec la valeur : sans lieu saisi, la phrase
        # doit rester francaise (« executees au lieu de la representation »,
        # pas « executees a le lieu de la representation »).
        "contrat.lieu": _lieu_du_contrat(e),
        "contrat.date_paiement": jj_mm_aaaa(e.date_paiement or e.fin),
        # `detail` vaut pour toutes les formes de contrat ; `cachets` et
        # `taux_cachet` ne veulent rien dire d'un contrat sans cachet, et ne
        # sont gardes que pour les modeles qui les utilisent deja.
        "remuneration.detail": _remuneration_detaillee(p),
        # << pour le mois de mai 2026 >> quand le contrat se poursuit apres le
        # mois -- le total et le net du gabarit sont ceux du mois, et le
        # contrat doit le dire (Leandre, 15/09/2026 : << oui pour le "pour le
        # mois", plus cale >>). Vide sur un contrat qui tient dans son mois :
        # la phrase ne change pas d'un caractere.
        "remuneration.periode": _periode_remuneration(p.engagement),
        "remuneration.cachets": str(e.cachets),
        "remuneration.taux_cachet": fmt_eur(e.taux_cachet),
        "remuneration.brut": fmt_eur(p.brut),
        "remuneration.net_estime": fmt_eur(p.net_a_payer),
        "spectacle.titre": sp["titre"],
        "spectacle.numero_objet": sp["numero_objet"],
    }


_MARQUEUR = re.compile(r"\{\{\s*([a-z_]+\.[a-z_]+)\s*\}\}")
_GRAS = re.compile(r"\*\*(.+?)\*\*")


def rendre(texte: str, vals: dict) -> str:
    """Substitue les marqueurs, echappe le HTML, puis applique le gras.

    Un marqueur inconnu leve une exception plutot que d'imprimer un trou :
    on ne signe pas un contrat a moitie rempli. Le message nomme la cle
    fautive, seule chose utile a qui edite le modele.

    Les valeurs substituees sont echappees comme le reste : une raison
    sociale contenant « & » ne doit pas casser la mise en page.
    """
    manquants = []

    def remplacer(m):
        cle = m.group(1)
        if cle not in vals:
            manquants.append(cle)
            return ""
        return vals[cle]

    texte = _MARQUEUR.sub(remplacer, texte)
    if manquants:
        raise KeyError(
            "marqueur inconnu dans le modele de contrat : %s. Marqueurs "
            "disponibles : %s" % (", ".join("{{%s}}" % c for c in manquants),
                                  ", ".join(sorted(vals))))
    texte = html.escape(texte, quote=False)
    return _GRAS.sub(r"<b>\1</b>", texte)


def _bloc_signatures(v: dict) -> str:
    """Les deux cases de signature, celle de l'employeur pre-signee.

    Pas de bandeau d'en-tete au-dessus du contrat : le preambule repete deja
    raison sociale, adresse, SIRET, APE et licence. Seul le logo marque le
    papier, comme sur le bulletin.

    L'image de signature est facultative : sans fichier, la case reste vide
    et le contrat se signe a la main.

    Pas de « lu et approuve » sous la case de l'artiste : la mention n'a
    aucune valeur juridique (Cass. soc., 20 avril 2005, n° 03-40.169 -- la
    signature seule engage), et elle a ete retiree : « ca sert
    a rien et ca alourdit ».
    """
    return (
        '<table class="sign"><tr>'
        '<td width="50%%"><span class="label">L\'employeur</span><br/>%s<br/>'
        '<span class="pt">%s</span><br/><br/><br/></td>'
        '<td width="50%%"><span class="label">L\'artiste</span><br/>%s<br/>'
        '<span class="pt">signature</span>'
        '<br/><br/><br/></td></tr></table>'
        % (html.escape(v["employeur.signataire"]),
           html.escape(v["employeur.signataire_fonction"]),
           html.escape(v["salarie.nom_complet"])))


SIGNATURE_LARGEUR = 92          # points ; l'image fait 792 x 384 px
SIGNATURE_RATIO = 384 / 792


def _finaliser(chemin: Path, fonction: str) -> None:
    """Depose la signature de l'employeur sous sa fonction, page par page.

    Elle n'est pas dans le flux HTML : PyMuPDF/Story perd la cellule suivante
    d'un tableau des qu'une <img> est placee dans l'une d'elles -- la colonne
    de l'artiste disparaissait purement et simplement. On ecrit donc le PDF
    sans image, puis on la depose en reperant la derniere occurrence de la
    fonction du signataire, qui est son intitule dans le bloc de signature.
    La position suit ainsi le contenu, dont la longueur change d'un contrat a
    l'autre.

    Sans fichier de signature, ou si l'ancre est introuvable, la case reste
    vide : le contrat se signe alors a la main, ce qui reste le cas nominal.

    Cette passe est aussi celle qui COMPACTE le fichier. `_poser_logo` ecrit
    en incrementiel (`saveIncr`) : chaque retouche empile une couche, sans
    jamais deduplicquer ni compresser. Deux passes de suite laissaient un
    contrat d'une page a 1,4 Mo, pour 179 Ko de trace de logo. Une sauvegarde
    finale avec ramasse-miettes et deflate le ramene a sa taille utile.
    """
    doc = pymupdf.open(str(chemin))
    if SIGNATURE.exists() and fonction:
        for page in doc:
            ancres = page.search_for(fonction)
            if not ancres:
                continue
            a = ancres[-1]
            cadre = pymupdf.Rect(a.x0, a.y1 + 3,
                                 a.x0 + SIGNATURE_LARGEUR,
                                 a.y1 + 3 + SIGNATURE_LARGEUR * SIGNATURE_RATIO)
            page.insert_image(cadre, filename=str(SIGNATURE))
    # Recriture en memoire plutot que par fichier temporaire : sous Windows,
    # renommer par-dessus le PDF que l'on vient de fermer echoue tant qu'un
    # lecteur le tient ouvert (WinError 5).
    compacte = doc.tobytes(garbage=4, deflate=True, clean=True)
    doc.close()
    chemin.write_bytes(compacte)


ANCRE_ARTISTE = "signature"     # le mot sous le nom de l'artiste (_bloc_signatures)


def contresigner(source, sortie, *, nom: str, quand: str, adresse: str,
                 code: str) -> Path:
    """Le contrat renvoye au salarie une fois qu'il a signe d'un clic.

    Le salarie n'a pas dessine sa signature : il a repondu au courriel par le
    bouton « Je signe », et sa reponse porte un code unique dans l'objet. Ce
    que le logiciel depose dans SA case, c'est la trace de ce clic -- qui, de
    quelle adresse, quand, quel code -- pour que l'exemplaire qu'il garde et
    celui que la compagnie garde disent la meme chose. C'est l'article 1367 du
    code civil : un procede qui identifie le signataire et le lie a l'acte.

    Chaque page porte un contrat (ou la fin d'un contrat) : la case se trouve
    par le mot `ANCRE_ARTISTE` dans la colonne de droite, la derniere
    occurrence de la page. Une page sans ancre (suite d'un long contrat) est
    laissee telle quelle.
    """
    source, sortie = Path(source), Path(sortie)
    doc = pymupdf.open(str(source))
    # La colonne de droite commence a la moitie de la page, et l'ancre y est
    # a un demi-point pres : on tranche au tiers, ce qui exclut la colonne
    # de l'employeur sans jouer sur l'arrondi.
    milieu = doc[0].rect.width / 3
    texte = ("Signé électroniquement le %s\npar %s\n%s\ncode de signature %s"
             % (quand, nom, adresse, code))
    for page in doc:
        ancres = [a for a in page.search_for(ANCRE_ARTISTE) if a.x0 > milieu]
        if not ancres:
            continue
        a = ancres[-1]
        cadre = pymupdf.Rect(a.x0, a.y1 + 3, page.rect.width - 52, a.y1 + 3 + 46)
        page.draw_rect(cadre, color=(0.7, 0.7, 0.7), width=0.5)
        reste = page.insert_textbox(cadre + (4, 3, -4, 0), texte, fontsize=6.6,
                                    fontname="helv", color=(0.17, 0.24, 0.31),
                                    lineheight=1.35)
        if reste < 0:
            raise ValueError("La mention de signature ne tient pas dans la case "
                             "(%s)." % source.name)
    sortie.parent.mkdir(parents=True, exist_ok=True)
    # « Un PDF plus modifiable » : le fichier est verrouille en modification
    # (mot de passe proprietaire tire au hasard et oublie aussitot), lecture
    # et impression libres. Un lecteur qui respecte le PDF refusera d'y
    # toucher ; ce n'est pas un chiffrement du contenu, c'est un scelle.
    import secrets as _secrets
    sortie.write_bytes(doc.tobytes(
        garbage=4, deflate=True, clean=True,
        encryption=pymupdf.PDF_ENCRYPT_AES_256, user_pw="",
        owner_pw=_secrets.token_urlsafe(24),
        permissions=pymupdf.PDF_PERM_PRINT | pymupdf.PDF_PERM_COPY
        | pymupdf.PDF_PERM_ACCESSIBILITY))
    doc.close()
    return sortie


def _html_un(p, ent: dict, m: dict) -> str:
    v = marqueurs(p, ent)
    parts = ["<h1>%s</h1>" % rendre(m["titre"], v)]
    if m["soustitre"]:
        parts.append('<p class="sub">%s</p>' % rendre(m["soustitre"], v))
    parts += ["<p>%s</p>" % rendre(b, v) for b in m["preambule"]]
    for n, (titre, corps) in enumerate(m["articles"], 1):
        parts.append("<h2>Article %d &mdash; %s</h2>" % (n, rendre(titre, v)))
        parts += ["<p>%s</p>" % rendre(b, v) for b in corps]
    parts += ['<p class="fait">%s</p>' % rendre(b, v) for b in m["signatures"]]
    parts.append(_bloc_signatures(v))
    return "".join(parts)


def ecrire(paies: list, ent: dict, chemin, modele=None) -> Path:
    """Un contrat par page.

    `modele` permet a une compagnie de pointer son propre fichier de clauses ;
    sans lui, le modele livre avec le logiciel est utilise.
    """
    m = lire_modele(modele)
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    mediabox = pymupdf.paper_rect("A4")
    # Le haut de la zone laisse passer le logo, pose ensuite en haut a droite :
    # sans cette reserve, le preambule court sous le dessin.
    zone = mediabox + (52, 106, -52, -46)
    writer = pymupdf.DocumentWriter(str(chemin))
    for p in paies:
        story = pymupdf.Story(html=_html_un(p, ent, m), user_css=CSS)
        more = 1
        while more:
            dev = writer.begin_page(mediabox)
            more, _ = story.place(zone)
            story.draw(dev)
            writer.end_page()
    writer.close()
    _poser_logo(chemin)
    _finaliser(chemin, ent["signataire"].get("fonction", ""))
    return chemin
