"""Commandes `retours`, `aer` et `pas` : ce qui revient des organismes.

Separe de cli.py parce que ce sont les seules commandes qui parlent au monde
exterieur, et qu'on veut voir d'un coup d'oeil tout ce qui sort de la machine.

Regle de conduite : on telecharge et on archive sans rien demander (c'est une
lecture), mais on n'ECRIT JAMAIS un taux de PAS dans la configuration sans
`--appliquer`. Un taux faux se propage dans une declaration fiscale nominative ;
il doit etre vu par un humain avant d'entrer.

`aer` ne parle a personne : elle ouvre des retours DEJA archives par `retours`
et range les attestations la ou l'envoi ira les chercher. C'est la seule piece
du mois que nous ne fabriquons plus -- depuis le 01/06/2026 France Travail
l'edite a partir de notre DSN et nous la renvoie en nature 46.
"""
from __future__ import annotations
import datetime as _dt
import json
import pathlib

from . import operations as ops, pas, retours
from .util import d, jj_mm_aaaa


def _fenetre(args) -> tuple[_dt.datetime, _dt.datetime]:
    """Plage de recherche. Par defaut : les 30 derniers jours, par tranches.

    Le SI DSN limite l'etendue d'une recherche (en-tete Accept-Ranges) ; on
    decoupe donc en tranches d'un jour, ce qui reste sous toutes les limites
    observees et suffit largement a notre volume (une DSN par mois).
    """
    fin = _dt.datetime.combine(d(args.jusqu_a), _dt.time(23, 59, 59)) \
        if args.jusqu_a else _dt.datetime.now()
    debut = _dt.datetime.combine(d(args.depuis), _dt.time(0, 0, 0)) \
        if args.depuis else fin - _dt.timedelta(days=30)
    return debut, fin


def _tranches(debut, fin, heures=24):
    pas_ = _dt.timedelta(hours=heures)
    t = debut
    while t < fin:
        yield t, min(t + pas_, fin)
        t += pas_


_SANS_LISTAGE_PAR_DECLARANT = """
Le listage PAR DECLARANT rend 404 sur le service DPAE : cette adresse etait
deduite de l'API DSN, et l'Urssaf ne documente que le listage PAR FLUX.

  python -m moteur retours --dpae --flux IDFLUX

L'idflux est celui que le SI DPAE rend au deposant. Pour une DPAE deposee par
CoolPaie, il est du cote de CoolPaie ou du tableau de bord Urssaf, pas ici.
A defaut, la reprise se declare a la main, datee et annotee.

Et le temps compte : les retours DPAE sont purges au bout de TROIS MOIS
(guide NAT/5492, contraintes d'exploitation). Passe ce delai, il n'y a plus
rien a relever.
"""


def cmd_retours_dpae(ctx, args) -> int:
    """Le canal DPAE, qui n'est PAS celui de la DSN.

    Deux services distincts, deux jeux de natures, deux mots de passe. Un
    certificat de conformite de DPAE (nature 41) ne se lit pas au meme endroit
    qu'un certificat de DSN, et la compagnie depose des DPAE par ce canal
    depuis des annees -- par CoolPaie. C'est donc la, et nulle part ailleurs,
    que se trouve la preuve qu'une embauche a ete declaree.
    """
    from . import dpae_api
    from .netentreprises import dossier_archive

    debut, fin = _fenetre(args)
    flux = getattr(args, "flux", "") or ""
    r = ops.relever_retours_dpae(ctx, debut=debut, fin=fin, tout=args.tout,
                                 flux=flux)
    for i in r.incidents:
        print(i)
    if not r.trouves:
        if flux:
            print("Aucun retour pour le flux %s." % flux)
        else:
            print("Aucun retour DPAE sur la periode %s -> %s."
                  % (debut.strftime("%d/%m/%Y"), fin.strftime("%d/%m/%Y")))
            print(_SANS_LISTAGE_PAR_DECLARANT)
        return 0 if not r.incidents else 1
    print("%d retour(s) DPAE, %d nouveau(x) :\n" % (len(r.trouves),
                                                    len(r.nouveaux)))
    for x in sorted(r.trouves, key=lambda e: e.get("publication") or ""):
        n = str(x.get("nature"))
        print("  %s  nature %-3s %-45s flux %s" % (
            (x.get("publication") or "")[:14], n,
            dpae_api.NATURES.get(n, "nature inconnue de ce moteur"),
            x.get("flux")))
    if r.archives:
        print("\n%d fichier(s) archives dans %s"
              % (len(r.archives), dossier_archive(ctx, "dpae")))
    return 0


def cmd_retours(ctx, args) -> int:
    """Le releve lui-meme est dans `operations` : l'interface le fait aussi.

    Ici il ne reste que ce qui s'affiche -- et le traitement du taux de PAS,
    qui demande un oeil humain et n'a donc pas sa place dans une operation
    automatique.
    """
    from . import coffre
    from .netentreprises import dossier_archive, VARIABLE_MOTDEPASSE

    if getattr(args, "dpae", False):
        return cmd_retours_dpae(ctx, args)

    mdp = coffre.lire(ctx, coffre.NET_ENTREPRISES, usage=coffre.CONSULTATION)
    if not mdp:
        print("""
Le mot de passe net-entreprises n'est nulle part : ni dans l'environnement,
ni dans le coffre.

Le poser une fois pour toutes -- chiffre par le compte Windows, jamais
affiche, et c'est lui qui permet au logiciel de relever les retours seul :

      python -m moteur coffre poser net-entreprises

Ou, pour cette fenetre seulement, sans rien ecrire :

      $env:%s = (Read-Host "mot de passe net-entreprises")
      python -m moteur retours
""" % VARIABLE_MOTDEPASSE)
        return 2

    debut, fin = _fenetre(args)
    print("Consultation des retours %s, du %s au %s."
          % (args.environnement, jj_mm_aaaa(debut.date()), jj_mm_aaaa(fin.date())))
    releve = ops.relever_retours(ctx, debut=debut, fin=fin, tout=args.tout,
                                 environnement=args.environnement, motdepasse=mdp)
    if releve.session_jusqu_a:
        print("Session ouverte (valide jusqu'a %s).\n" % releve.session_jusqu_a)
    for incident in releve.incidents:
        print("  %s" % incident)
    if not releve.trouves:
        if releve.incidents:
            return 1
        print("Aucun retour sur la periode. Elargir avec --depuis JJ/MM/AAAA.")
        return 0

    print("%d retour(s) sur la periode, dont %d nouveau(x).\n"
          % (len(releve.trouves), len(releve.nouveaux)))
    for r in sorted(releve.trouves, key=lambda x: x.get("publication") or ""):
        marque = "NEUF" if r in releve.nouveaux else "    "
        print("  %s %s  nature %-4s %-8s %s"
              % (marque, _date_lisible(r.get("publication")), r.get("nature"),
                 r.get("statut"), retours.libelle_nature(r.get("nature"))))

    telecharges = [(a.retour, a.chemin, a.contenu) for a in releve.archives]
    if telecharges:
        print("\n%d fichier(s) archive(s) dans %s :"
              % (len(telecharges), dossier_archive(ctx)))
        for r, chemin, _ in telecharges:
            print("  %s" % chemin.name)

    # ------------------------------------------- France Travail, spectacle
    spectacle = [(r, c, contenu) for r, c, contenu in telecharges
                 if str(r.get("nature")) in (retours.NATURE_CRM_SPECTACLE,
                                             retours.NATURE_AER_SPECTACLE)]
    if spectacle:
        print("\nFrance Travail, cinema-spectacle :")
    for r, chemin, contenu in spectacle:
        if str(r.get("nature")) == retours.NATURE_CRM_SPECTACLE:
            print("  compte-rendu metier recu (%s) : nos contrats spectacle "
                  "ont ete pris en compte." % chemin.name)
            continue
        att = retours.aer_spectacle(contenu)
        if not att:
            print("  %s : archive illisible. Le fichier brut est garde, on "
                  "peut recommencer." % chemin.name)
            continue
        periodes = sorted({a.periode for a in att if a.periode})
        print("  %d attestation(s) AER, periode %s (%s)"
              % (len(att), ", ".join(periodes) or "non lue", chemin.name))
        print("    les ranger pour l'envoi :  python -m moteur aer")

    # ------------------------------------------------------------- taux de PAS
    crm = [(r, c, contenu) for r, c, contenu in telecharges
           if str(r.get("nature")) == retours.NATURE_TAUX_PAS]
    if not crm:
        print("""
Aucun compte-rendu DGFiP de nature 94 (taux du PAS) dans ce lot.
C'est le retour le plus tardif de la chaine : il arrive apres l'accuse, le
certificat de conformite et les bilans. Relancer quelques jours apres un depot.
""")
        return 0
    return _traiter_crm_pas(ctx, crm, args)


def _traiter_crm_pas(ctx, crm, args) -> int:
    tous = []
    for r, chemin, contenu in crm:
        res = retours.extraire_taux_pas(contenu)
        print("\nCRM DGFiP du %s (%s)" % (_date_lisible(r.get("publication")), chemin.name))
        if not res["releves"]:
            print("""  Aucun taux reconnu dans ce fichier.

  Le format harmonise des retours n'a jamais ete confronte a un vrai CRM 94 :
  c'est attendu, et sans gravite. Le fichier est archive tel quel. M'envoyer
  %s et j'ajuste l'extraction dessus.""" % chemin.name)
            continue
        print("  Reconnu par : %s" % res["strategie"])
        rattaches, orphelins = retours.releves_vers_salaries(ctx, res["releves"])
        for o in orphelins:
            print("  NIR non rattache a une fiche salarie : %s" % o.get("nir"))
        for x in rattaches:
            print("  %-12s taux %s  type %s (%s)  identifiant %s"
                  % (x["salarie"], x["taux"], x["type"],
                     pas.TYPES.get(x["type"], "?"), x["identifiant"]))
        tous.extend(dict(x, periode=r.get("production", "")[:6]) for x in rattaches)

    if not tous:
        return 0
    if not args.appliquer:
        print("""
Rien n'a ete ecrit. Verifier les valeurs ci-dessus, puis :
    python -m moteur retours --appliquer
""")
        return 0
    chgts = pas.enregistrer(ctx, tous, "CRM DGFiP nature 94")
    if chgts:
        print("\nconfig/pas.json mis a jour :")
        for c in chgts:
            print("  %s" % c)
    else:
        print("\nconfig/pas.json inchange : les valeurs recues sont deja celles connues.")
    return 0


# ------------------------------------------------------------------ pas
def cmd_pas(ctx, args) -> int:
    if args.amorcer:
        export = ctx.export / "DSN"
        if not export.exists():
            print("Dossier introuvable : %s" % export)
            return 1
        chgts = pas.amorcer(ctx, export)
        print("Amorcage depuis les DSN deposees (%s) :" % export)
        for c in chgts:
            print("  %s" % c)
        if not chgts:
            print("  rien a changer.")
        print("""
Ces valeurs sont celles REELLEMENT DECLAREES dans les dernieres DSN, pas des
valeurs calculees. Elles tiennent jusqu'au prochain compte-rendu DGFiP :
    python -m moteur retours
""")
        return 0

    etat = pas.charger(ctx)
    if not etat["salaries"]:
        print("Magasin vide. `python -m moteur pas --amorcer` pour partir de "
              "l'historique, ou `python -m moteur retours` pour lire un CRM.")
        return 0
    print("Taux de prelevement a la source connus\n" + "-" * 62)
    for cle, e in etat["salaries"].items():
        print("  %-12s taux %-6s type %s (%s)"
              % (cle, e["taux"], e["type"], pas.TYPES.get(e["type"], "?")))
        print("  %-12s identifiant %s" % ("", e["identifiant"]))
        print("  %-12s source : %s%s\n"
              % ("", e["source"],
                 " (periode %s)" % e["periode"] if e.get("periode") else ""))
    print("""S21.G00.50.006/.007/.008 sortent d'ici. Aucune n'est calculee : elles
viennent du compte-rendu metier DGFiP de nature 94.""")
    return 0


def _date_lisible(horodatage: str) -> str:
    if not horodatage or len(horodatage) < 8:
        return "?"
    return "%s/%s/%s" % (horodatage[6:8], horodatage[4:6], horodatage[0:4])


def cmd_aer(ctx, args) -> int:
    """Range les AER deja recues la ou l'envoi ira les chercher.

    Cette commande ne parle a aucun service : `retours` a deja telecharge et
    archive les fichiers, et un retour archive est une piece justificative
    qu'on ne redemande pas. Ici on ouvre les archives de nature 46 et on ecrit
    un PDF par salarie dans sorties/<mois>/envoi/, sous le meme nom de famille
    que le bulletin et le certificat CS -- c'est ce qui permet a `envoi` de les
    ramasser sans rien savoir de France Travail.

    On ne touche pas aux CHIFFRES du PDF : ils sont de France Travail et ils
    font foi. On remplit le cadre 5, celui que le formulaire laisse vide et
    qui est a la charge de l'employeur -- « je soussigne... certifie que les
    renseignements indiques sont exacts ». Voir moteur/aer.py.

    Et parce qu'on signe, on verifie d'abord : si l'attestation n'affiche pas
    les memes cachets et les memes heures que la paie du mois, la commande
    REFUSE de signer et dit lequel. Un ecart n'est pas un detail d'affichage,
    c'est un renseignement inexact au sens de l'article L. 5429-1.
    """
    from . import aer as mod_aer
    from .conges_spectacles import SIGNATURE
    from .envoi import etiquette, nom_fichier

    archives = ctx.racine / "retours"
    fichiers = sorted(archives.glob("*_nature%s_*"
                                    % retours.NATURE_AER_SPECTACLE))
    if not fichiers:
        print("""
Aucun retour de nature %s (AER « cinema, spectacle ») dans %s.

Depuis le passage en 100 %% DSN, l'attestation employeur est editee par France
Travail a partir de notre DSN, quelques jours apres le depot. La recuperer :

    python -m moteur retours
""" % (retours.NATURE_AER_SPECTACLE, archives))
        return 2

    # Un meme retour a pu etre retelecharge (--tout) : on dedoublonne sur
    # (periode, salarie), la derniere lecture gagne.
    vues = {}
    for f in fichiers:
        for att, cle in retours.rattacher(
                retours.aer_spectacle(f.read_bytes()), ctx.salaries):
            if args.mois and att.periode != args.mois:
                continue
            vues[(att.periode, att.qui)] = (att, cle, f)

    if not vues:
        print("Aucune attestation%s dans les %d archive(s) lue(s)."
              % (" pour %s" % args.mois if args.mois else "", len(fichiers)))
        return 2

    # Les paies du mois, une fois par periode : elles servent a verifier ce
    # que l'attestation affiche. Une periode sans fichier de paie n'est pas une
    # erreur -- on signe alors sans verifier, et on le dit.
    paies_par_periode, sans_paie = {}, set()
    for periode, _ in vues:
        if not periode or periode in paies_par_periode or periode in sans_paie:
            continue
        try:
            paies_par_periode[periode] = ops.charger(
                ctx, "paies/%s.json" % periode).paies
        except Exception:
            sans_paie.add(periode)

    ecrits, a_ranger, refusees = [], [], []
    for (periode, qui), (att, cle, source) in sorted(vues.items()):
        if not periode or not cle:
            a_ranger.append((att, source))
            continue
        paies = [p for p in paies_par_periode.get(periode, [])
                 if p.salarie["_cle"] == cle]
        try:
            donnees = mod_aer.authentifier(
                att.donnees, ctx.entreprise,
                signature=SIGNATURE if SIGNATURE.exists() else None,
                paies=paies or None, forcer=args.forcer)
        except mod_aer.AttestationInexacte as e:
            refusees.append((cle, periode, e.ecarts))
            continue
        cible = ctx.racine / "sorties" / periode / "envoi"
        cible.mkdir(parents=True, exist_ok=True)
        chemin = cible / nom_fichier("AER", cle, etiquette(periode))
        chemin.write_bytes(donnees)
        ecrits.append((periode, cle, chemin))

    for periode in sorted({p for p, _, _ in ecrits}):
        lot = [(c, ch) for p, c, ch in ecrits if p == periode]
        print("%s : %d attestation(s) dans %s"
              % (periode, len(lot), lot[0][1].parent))
        for cle, chemin in lot:
            print("   %-12s %s" % (cle, chemin.name))

    if a_ranger:
        # On ne devine pas. Un nom que le rapprochement ne reconnait pas est
        # peut-etre un salarie archive sous une autre orthographe, ou un
        # homonyme : c'est a un humain de trancher.
        refuge = ctx.racine / "retours" / "aer-a-ranger"
        refuge.mkdir(parents=True, exist_ok=True)
        print("\n%d attestation(s) non rattachee(s) -- deposees dans %s :"
              % (len(a_ranger), refuge))
        for att, source in a_ranger:
            (refuge / pathlib.Path(att.nom_archive).name).write_bytes(att.donnees)
            print("   %s  (%s)" % (att.qui, att.nom_archive))
        print("Verifier le nom et le prenom dans config/salaries.json, puis "
              "relancer, ou les renommer a la main.")

    if refusees:
        print("\n%d attestation(s) NON SIGNEE(S) -- elles ne disent pas ce que"
              " la paie dit :" % len(refusees))
        for cle, periode, ecarts in refusees:
            print("   %s, %s" % (cle, periode))
            for e in ecarts:
                print("      %s" % e)
        print("""
Signer reviendrait a certifier exacts des renseignements qui ne le sont pas.
La correction ne se fait PAS sur le PDF : elle se fait sur la DSN, et France
Travail reedite l'attestation. Une DSN mensuelle « annule et remplace » est
possible tant que la date d'exigibilite n'est pas depassee ; a defaut, la
rectification passe par la DSN du mois suivant.

Si l'ecart est connu et assume, --forcer signe quand meme.""")

    if ecrits:
        mois = sorted({p for p, _, _ in ecrits})[-1]
        print("\nElles partiront avec le message aux salaries :")
        print("   python -m moteur envoi paies/%s.json" % mois)
    return 2 if refusees else 0


def cmd_depots(ctx, args) -> int:
    """La liste des depots vus par net-entreprises, telle quelle.

    Lecture seule, et volontairement BRUTE : on imprime tous les champs que
    le service renvoie, sans en choisir. C'est une commande d'enquete -- on
    s'en sert quand il faut retrouver quelque chose sur un depot passe, par
    exemple la date de constitution d'un fichier qu'on n'a plus, pour composer
    l'identifiant d'une annule-et-remplace (S20.G00.05.006).
    """
    from . import coffre
    from .netentreprises import Client, ErreurApi

    if getattr(args, "dpae", False):
        return cmd_retours_dpae(ctx, args)

    mdp = coffre.lire(ctx, coffre.NET_ENTREPRISES, usage=coffre.CONSULTATION)
    if not mdp:
        print("Mot de passe absent. Le poser une fois : `python -m moteur "
              "coffre poser net-entreprises`.")
        return 2

    debut, fin = _fenetre(args)
    client = Client(ctx, args.environnement, motdepasse=mdp)
    print("Depots %s, du %s au %s.\n"
          % (args.environnement, jj_mm_aaaa(debut.date()), jj_mm_aaaa(fin.date())))
    try:
        client.authentifier()
        depots = []
        for t0, t1 in _tranches(debut, fin):
            depots.extend(client.lister_depots(t0, t1))
    except ErreurApi as e:
        print("Echec : %s" % e)
        return 1

    if not depots:
        print("Aucun depot sur la periode. Elargir avec --depuis JJ/MM/AAAA.")
        return 0

    for i, dep in enumerate(depots, 1):
        print("  depot %d" % i)
        for k, v in dep.items():
            print("     %-24s %s" % (k, v))
        print()
    print("%d depot(s)." % len(depots))
    return 0


def _phrase_depot(v: dict) -> str:
    """Une ligne de reprise, lisible. Trois choses, dans cet ordre : quand,
    ce que ca vaut, et QUI l'a depose -- c'est la troisieme qui repond a la
    question qui revient (<< on l'a deja envoye >>)."""
    return "  %s  %-4s  %-7s  %-8s  %-11s  %s" % (
        (v["quand"] or "?")[:16].replace("T", " "),
        "REEL" if v["mode"] == "reel" else "test",
        "accepte" if v["accepte"] else "REJETE",
        v["mois"] or "-",
        v["logiciel"] or "?",
        v["flux"])


def cmd_journal(ctx, args) -> int:
    """Le journal des depots : le lire, et le reprendre depuis les retours.

    La reprise ne depose rien et n'appelle aucun reseau : elle lit les pieces
    deja archivees dans `retours/` et ecrit ce qu'elles disent. Elle ne
    s'execute pas sans `--ecrire`, et c'est voulu -- une reprise qui part au
    premier appel est une reprise qu'on lance << pour voir >> et qui laisse
    des lignes que personne n'a relues.
    """
    from . import journal

    if args.reprendre:
        # LES DEUX CANAUX. La DSN et la DPAE ne repondent pas au meme service
        # et n'ont pas les memes natures ; les reprendre separement ferait
        # relancer deux commandes pour une seule question (<< qu'est-ce qui
        # est deja parti ? >>).
        d = ops.reconstruire_journal_dpae(ctx, ecrire=args.ecrire, qui="cli")
        if d["trouves"]:
            print("DPAE attestees par les certificats de l'Urssaf : %d"
                  % len(d["trouves"]))
            print("")
            for v in d["trouves"]:
                print("  %s  %-4s  %-8s  %s"
                      % ((v["quand"] or "?")[:16].replace("T", " "),
                         "REEL" if v["mode"] == "reel" else "test",
                         v["mois"] or "-", v["flux"])
                      + ("   [deja au journal]" if v["deja"] else ""))
                for e in v["embauches"]:
                    print("        %s a partir du %s" % (e["salarie"], e["debut"]))
            print("")
        for x in d["inconnus"]:
            print("Non rattache : %s" % x)
        r = ops.reconstruire_journal(ctx, ecrire=args.ecrire, qui="cli")
        r["_dpae_ajoutes"] = len(d["ajoutes"])
        r["_dpae_trouves"] = len(d["trouves"])
        if r["illisibles"]:
            print("Pieces illisibles, sautees : %s\n"
                  % ", ".join(r["illisibles"]))
        if not r["trouves"] and not r["_dpae_trouves"]:
            print("Aucune piece de depot dans retours/. Rien a reprendre.\n"
                  "Les accuses (nature 10) et les bilans (nature 11) "
                  "s'archivent avec `python -m moteur retours`.")
            return 0
        if r["trouves"]:
            print("Depots DSN attestes par les retours : %d\n" % len(r["trouves"]))
        for v in r["trouves"]:
            print(_phrase_depot(v) + ("   [deja au journal]" if v["deja"] else ""))
        print()
        if r["sans_mois"]:
            print("%d piece(s) sans date de reception : non reprises.\n"
                  % len(r["sans_mois"]))
        if not r["ajoutes"] and not r["_dpae_ajoutes"]:
            print("Rien de nouveau : le journal connait deja tout cela.")
            return 0
        total = len(r["ajoutes"]) + r["_dpae_ajoutes"]
        if not args.ecrire:
            print("%d ligne(s) SERAIENT ajoutees (dont %d DPAE). "
                  "Rien n'a ete ecrit.\n"
                  "Relancer avec --ecrire pour les poser."
                  % (total, r["_dpae_ajoutes"]))
            return 0
        print("%d ligne(s) ajoutees au journal (dont %d DPAE)."
              % (total, r["_dpae_ajoutes"]))
        if r["rattaches"]:
            print("%d retour(s) rattaches a ces depots." % r["rattaches"])
        return 0

    lignes = journal.lire(ctx, quoi=args.quoi, mois=args.mois)
    if not lignes:
        print("Le journal est vide" + (" pour ce filtre." if (args.quoi or args.mois)
                                       else ".\nRien n'est encore parti par ce "
                                            "logiciel -- ou le journal n'a pas "
                                            "ete repris :\n  python -m moteur "
                                            "journal --reprendre"))
        return 0
    for l in lignes:
        retours_ = l.get("retours") or []
        print("%s  %-16s %-4s %-7s %-8s %s" % (
            (l.get("quand") or "")[:16].replace("T", " "),
            l.get("quoi"), l.get("mode"),
            "accepte" if l.get("accepte") else "REFUSE",
            l.get("mois") or "-",
            l.get("fichier") or l.get("flux") or ""))
        if l.get("origine"):
            # La ligne n'est pas un acte de ce logiciel : elle a ete
            # reconstituee. Le dire a chaque affichage, pas une fois en
            # en-tete -- on lit une ligne, pas un tableau.
            print("        repris de : %s" % l["origine"])
        for r in retours_:
            print("        retour %s %s (%s)" % (r.get("nature"),
                                                 r.get("libelle") or "",
                                                 r.get("publication") or ""))
    return 0


def enregistrer_commandes(sub) -> None:
    r = sub.add_parser("retours", help="recuperer les retours DSN (lecture seule)")
    r.add_argument("--flux", metavar="IDFLUX",
                   help="avec --dpae : lister les retours de CE flux. Seul "
                        "chemin documente par l'Urssaf ; le listage par "
                        "declarant rend 404 sur le service DPAE.")
    r.add_argument("--dpae", action="store_true",
                   help="relever le canal DPAE de l'Urssaf au lieu de la DSN "
                        "(archive a part, dans retours/dpae/)")
    r.add_argument("--depuis", help="debut de la plage (JJ/MM/AAAA), defaut J-30")
    r.add_argument("--jusqu-a", dest="jusqu_a", help="fin de la plage (JJ/MM/AAAA)")
    r.add_argument("--environnement", default="production",
                   choices=["production", "editeur"])
    r.add_argument("--tout", action="store_true",
                   help="retelecharger meme ce qui est deja archive")
    r.add_argument("--appliquer", action="store_true",
                   help="ecrire dans config/pas.json les taux lus dans le CRM 94")
    r.set_defaults(fn=cmd_retours)

    a = sub.add_parser(
        "aer", help="ranger les attestations France Travail deja recues")
    a.add_argument("--mois", help="ne traiter que ce mois (AAAA-MM)")
    a.add_argument("--forcer", action="store_true",
                   help="signer malgre un ecart entre l'attestation et la paie")
    a.set_defaults(fn=cmd_aer)

    dp = sub.add_parser(
        "depots", help="lister les depots vus par net-entreprises (enquete)")
    dp.add_argument("--depuis", help="debut de la plage (JJ/MM/AAAA), defaut J-30")
    dp.add_argument("--jusqu-a", dest="jusqu_a", help="fin de la plage (JJ/MM/AAAA)")
    dp.add_argument("--environnement", default="production",
                    choices=["production", "editeur"])
    dp.set_defaults(fn=cmd_depots)

    j = sub.add_parser(
        "journal", help="le journal des depots -- le lire, ou le reprendre")
    j.add_argument("--quoi", choices=["dsn", "dpae", "documents",
                                      "contrat-signature"],
                   help="n'afficher qu'un acte")
    j.add_argument("--mois", help="n'afficher qu'un mois (AAAA-MM)")
    j.add_argument("--reprendre", action="store_true",
                   help="remettre au journal les depots attestes par retours/")
    j.add_argument("--ecrire", action="store_true",
                   help="avec --reprendre : ecrire pour de bon (defaut : dire)")
    j.set_defaults(fn=cmd_journal)

    p = sub.add_parser("pas", help="taux de prelevement a la source connus")
    p.add_argument("--amorcer", action="store_true",
                   help="poser l'etat courant depuis les DSN deja deposees")
    p.set_defaults(fn=cmd_pas)
