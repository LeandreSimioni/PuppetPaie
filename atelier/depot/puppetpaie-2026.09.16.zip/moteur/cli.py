"""Ligne de commande de PuppetPaie -- l'une des deux faces du logiciel.

    python -m moteur mois paies/2026-10.json      # tout produire pour un mois
    python -m moteur nouveau 2026-10              # creer un fichier de saisie
    python -m moteur dpae paies/2026-10.json      # la DPAE seule, avant l'embauche
    python -m moteur calibrer                     # non-regression contre CoolPaie
    python -m moteur fiche                        # rappel des donnees connues
    python -m moteur retours                      # lire les retours DSN
    python -m moteur pas                          # taux de prelevement a la source
    python -m moteur droits                       # heures et cachets cumules
    python -m moteur importer --ecrire            # reprendre fiches et historique CoolPaie

Toute commande accepte `--json` : meme travail, memes garde-fous, sortie
lisible par un programme au lieu d'un humain. C'est par la que passeront
l'interface et une eventuelle API -- pas par un appel direct aux modules de
rendu, qui contournerait les garde-fous.

Ce fichier n'AFFICHE que. Toute decision -- l'ordre de production, les
compteurs, le refus de produire une DSN sans montant URSSAF -- vit dans
`operations` (un nom, neuf modules par domaine), que l'interface appelle
exactement de la meme facon. Une regle a tenir dans le temps : si l'on est
tente d'ecrire ici un `if` qui change ce qui est produit, il va dans le
module `operations_*` de son domaine.
"""
from __future__ import annotations
import argparse
import datetime as _dt
import json
import os
import sys

from . import operations as ops
from . import sortie_json as js
from .contexte import Contexte
from .util import fmt_eur, MOIS


# Le module a longtemps porte `charger` et `squelette` : ils sont partis dans
# `operations` (aujourd'hui `operations_paies.py`), ou ils servent aux deux faces. Reexportes pour ne pas
# casser un appelant existant.
charger = ops.charger
squelette = ops.squelette


def _rendre(charge: dict) -> int:
    """Emet la reponse machine et rend le code de sortie qui va avec.

    Un appelant automatique lit `ok`, un script shell lit le code de retour :
    les deux doivent dire la meme chose.

    La console Windows ecrit en cp1252 : « Compagnia » passe, « privé » non, et
    un accent perdu casse le JSON pour celui qui le relit. On force donc UTF-8
    sur la sortie -- c'est un format de donnees, il ne se plie pas a la
    machine sur laquelle il est produit.
    """
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):      # sortie deja capturee : tant pis
        pass
    print(json.dumps(charge, ensure_ascii=False, indent=2))
    return 0 if charge.get("ok") else 2


def _json(args) -> bool:
    return getattr(args, "json", False)


def _afficher_etapes(etapes: list, titre: str = "A faire ensuite :") -> None:
    print("\n%s" % titre)
    for i, e in enumerate(etapes, 1):
        print("  %d. %-9s %s" % (i, e.titre, e.detail))
        if e.commande:
            print("     %s" % e.commande)


def _afficher_fichiers(fichiers: list, dossier) -> None:
    print("\nFichiers produits dans %s :" % dossier)
    for f in fichiers:
        print("  %s  (%d o)" % (f.name, f.stat().st_size))


def _afficher_apercu(apercu) -> None:
    s = apercu.saisie
    print("\n%s - %d paie(s)\n%s" % (s.libelle, len(s.paies), "-" * 58))
    for p in s.paies:
        # Ce que le moteur a compris, et non « N cachet(s) » : un contrat
        # d'une journee de 5 h n'a pas de cachet, et l'apercu est ce qu'on
        # relit avant de produire.
        quoi = ", ".join(l.designation for l in p.remuneration)
        print("  %-9s %-22s %-30s brut %8s  net %8s  cout %8s" % (
            p.numero_bulletin,
            p.salarie["nom"] + " " + p.salarie["prenom_affichage"],
            quoi[:30], fmt_eur(p.brut), fmt_eur(p.net_a_payer),
            fmt_eur(p.cout_employeur)))
    print("%s\n  TOTAL                              brut %8s              cout %8s\n"
          % ("-" * 58, fmt_eur(apercu.total_brut), fmt_eur(apercu.total_cout)))
    for a in apercu.avertissements:
        print("  /!\\  %s" % a)
    if apercu.avertissements:
        print("")


# ------------------------------------------------------------------ commandes
def cmd_nouveau(ctx, args):
    try:
        p = ops.nouvelle_saisie(ctx, args.mois, force=args.force,
                                reprendre=args.reprendre)
    except ops.FichierExistant as e:
        if _json(args):
            return _rendre(js.erreur("nouveau", e, chemin=str(e.chemin)))
        print("%s  (--force pour ecraser)" % e)
        return 1
    en_cours = ops.contrats_en_cours(ctx, args.mois)
    if _json(args):
        return _rendre(js.enveloppe("nouveau", {
            "mois": args.mois, "chemin": str(p), "saisie": ops.lire_saisie(p),
            "contrats_en_cours": [js.contrat_en_cours(c) for c in en_cours]}))
    print("Cree : %s" % p)
    if en_cours:
        print()
        print("%d contrat(s) en cours depuis un mois precedent :" % len(en_cours))
        for c in en_cours:
            print("  %-24s %s -> %s  n° %s  (depuis %s)%s" % (
                c.nom, c.debut, c.fin, c.numero or "?", ops.libelle_mois(c.depuis),
                "  -- ecrit dans le fichier, poser les jours" if args.reprendre else ""))
        if not args.reprendre:
            print("  Pour les reprendre : recopier `debut`, `fin` et `numero` dans un "
                  "engagement du fichier (ou `nouveau --force --reprendre`). Ni "
                  "contrat ni DPAE ne seront refaits : ils datent du premier mois.")
    print("Modifier les dates et les noms, puis :  python -m moteur mois %s" % p)
    return 0


def cmd_mois(ctx, args):
    try:
        r = ops.produire_mois(
            ctx, args.fichier, urssaf=args.urssaf,
            accepter_estimation=args.urssaf_estime,
            sans_contrat=args.sans_contrat, date_constitution=args.constitution,
            envoi_test=args.envoi_test, qui="cli")
    except ops.UrssafManquant as e:
        if _json(args):
            return _rendre(js.erreur("mois", e, estimation=e.estimation,
                                     marge=e.marge, apercu=js.apercu(e.apercu)))
        _afficher_apercu(e.apercu)
        print("""
ARRET - montant du telepaiement URSSAF (bloc S21.G00.20) manquant.

Ce bloc est un ORDRE DE TELEPAIEMENT : L'URSSAF preleve ce montant. Il n'est
pas calculable depuis la paie (l'organisme facture des elements que la DSN ne
detaille pas, et regularise chaque annee en avril). Il doit etre recopie du
bordereau URSSAF.

  Estimation pour ce mois : %s EUR  (a +/- %s EUR environ)

  Avec le bordereau  : python -m moteur mois %s --urssaf MONTANT
  Sans le bordereau  : python -m moteur mois %s --urssaf-estime
                       (produit la DSN avec l'estimation ci-dessus - a ne
                        deposer qu'apres verification)
""" % (e.estimation, e.marge, args.fichier, args.fichier))
        return 2
    except ops.CompteursVerrouilles as e:
        if _json(args):
            return _rendre(js.erreur("mois", e, detenteur=e.detenteur,
                                     age=e.age, verrou=str(e.verrou)))
        print("%s" % e)
        return 2

    if _json(args):
        return _rendre(js.enveloppe("mois", js.mois_produit(r)))
    _afficher_apercu(r.apercu)
    for a in r.avertissements:
        print(">>> %s" % a)
    if r.avertissements:
        print()
    _afficher_fichiers(r.fichiers, r.dossier)
    _afficher_etapes(r.etapes)
    print("\n  Les pieces individuelles sont deja ecrites dans %s."
          % (r.dossier / "envoi"))
    return 0


def cmd_envoi(ctx, args):
    """Prepare les messages aux salaries et ouvre la page de relecture.

    Commande separee, jamais enchainee a `mois` : un courriel parti ne revient
    pas. L'envoi demande un clic dans le navigateur et une confirmation.
    """
    from . import google

    try:
        prep = ops.preparer_envoi(ctx, args.fichier)
    except ops.SortieAbsente as e:
        if _json(args):
            return _rendre(js.erreur("envoi", e, dossier=str(e.dossier)))
        print("Rien a envoyer : %s\n"
              "Produire le mois d'abord :  python -m moteur mois %s"
              % (e, args.fichier))
        return 1
    except ops.GoogleNonAutorise as e:
        if _json(args):
            return _rendre(js.erreur("envoi", e))
        print("Compte Google pas encore autorise.\n"
              "  python -m moteur google autoriser")
        return 1
    except google.ErreurGoogle as e:
        if _json(args):
            return _rendre(js.erreur("envoi", e))
        print("%s" % e)
        return 1

    # En JSON on s'arrete a la preparation : un envoi demande une
    # confirmation humaine, et un programme ne confirme pas. C'est la
    # seule commande ou `--json` fait MOINS, et c'est voulu.
    if _json(args):
        return _rendre(js.enveloppe("envoi", dict(
            js.envoi_prepare(prep), envoye=False,
            note="Preparation seulement : l'expedition demande la page "
                 "de relecture. Relancer sans --json pour envoyer.")))

    for a in prep.avertissements:
        print("Note : %s\n" % a)
    print("\n%s - %d message(s)\n%s"
          % (prep.saisie.libelle, len(prep.messages), "-" * 62))
    for m in prep.messages:
        print("  %-22s %-30s %d piece(s), %d ko"
              % (m.nom, m.destinataire, len(m.pieces), m.taille() // 1024))
    print("%s\n  Expediteur : %s\n" % ("-" * 62, prep.expediteur))

    r = ops.confirmer_et_envoyer(prep, ouvrir=not args.sans_navigateur)
    if r["action"] == "abandon":
        print("Aucun message n'est parti.")
        return 1
    if r["erreur"]:
        print("Echec : %s" % r["erreur"])
        return 2
    print("%d message(s) ENVOYES :" % len(r["faits"]))
    for adresse in r["faits"]:
        print("  %s" % adresse)
    return 0


def cmd_google(ctx, args):
    """Autorisation du compte Google, etat, et retrait du jeton local."""
    from . import google

    try:
        if args.quoi == "etat":
            e = ops.google_etat(ctx)
            if _json(args):
                _rendre(js.enveloppe("google", js.etat_google(e)))
                return 0 if e.compte else 1
            print("Application : %s" % e.application)
            print("Permissions : %s" % ", ".join(e.permissions))
            if not e.compte:
                print("Compte      : aucun\n"
                      "\nPas encore autorise :  python -m moteur google autoriser")
                return 1
            print("Compte      : %s" % e.compte)
            print("Verification: le compte repond, l'autorisation tient.")
            return 0
        if args.quoi == "autoriser":
            compte = ops.google_autoriser(ctx, ouvrir=not args.sans_navigateur)
            print("C'est bon : %s est autorise.\n"
                  "Rien d'autre a faire, l'autorisation tient tant qu'elle "
                  "n'est pas retiree." % compte)
            return 0
        if args.quoi == "oublier":
            if ops.google_oublier(ctx):
                print("Jeton local efface. L'acces reste accorde cote Google :\n"
                      "  le retirer sur myaccount.google.com > Securite >\n"
                      "  Vos connexions a des applications tierces.")
            else:
                print("Il n'y avait pas de jeton local.")
            return 0
    except google.ErreurGoogle as e:
        if _json(args):
            return _rendre(js.erreur("google", e))
        print("%s" % e)
        return 2
    return 2


def cmd_archiver(ctx, args):
    from . import google

    try:
        r = ops.archiver(ctx, args.mois, racine_drive=args.racine_drive)
    except ops.SortieAbsente as e:
        if _json(args):
            return _rendre(js.erreur("archiver", e, dossier=str(e.dossier)))
        print("Rien a archiver : %s" % e)
        return 1
    except google.ErreurGoogle as e:
        if _json(args):
            return _rendre(js.erreur("archiver", e))
        print("%s" % e)
        return 2

    if _json(args):
        return _rendre(js.enveloppe("archiver", js.archivage(r)))
    print("Drive : %s / %s   (compte %s)\n%s"
          % (r.racine_drive, r.mois, r.compte, "-" * 62))
    for f in r.fichiers:
        print("  %-40s %6d ko  %s"
              % (f.nom, f.octets // 1024, "remplace" if f.remplace else "nouveau"))
    print("%s\n%d fichier(s) archive(s)." % ("-" * 62, len(r.fichiers)))
    return 0


def cmd_dpae(ctx, args):
    # `--seulement PUPPIS:2026-08-23` : la DPAE d'une PARTIE du mois. Le
    # fichier complet reste a cote, intact -- voir `ops.produire_dpae`.
    choix = None
    if args.seulement:
        choix = []
        for x in args.seulement:
            if ":" not in x:
                print("--seulement attend SALARIE:AAAA-MM-JJ, recu %r" % x)
                return 2
            cle, debut = x.split(":", 1)
            choix.append({"salarie": cle.strip(), "debut": debut.strip()})
    r = ops.produire_dpae(ctx, args.fichier, heure=args.heure, paies=choix,
                          forcer=getattr(args, "force", False))

    if _json(args):
        _rendre(js.enveloppe("dpae", js.dpae_produite(r)))
        return 3 if r.retard else 0
    print("\n%s - %d contrat(s) a declarer\n%s"
          % (r.saisie.libelle, len(r.lignes), "-" * 58))
    for l in r.lignes:
        print("  %-22s %s a %sh%s  %s"
              % (l.salarie, l.debut.strftime("%d/%m/%Y"),
                 l.heure[:2], l.heure[2:], l.libelle))
    print("-" * 58)

    _afficher_fichiers(r.fichiers, r.dossier)
    _afficher_etapes(r.etapes, "A faire :")
    if r.retard:
        print("\n>>> Au moins une embauche est deja passee : la DPAE est hors delai.")
        print(">>> La deposer quand meme, sans antidater.")
        return 3
    return 0


def cmd_droits(ctx, args):
    """Position au regard des annexes 8 et 10 : heures + cachets, sur 12 mois."""
    from . import cumul

    positions = ops.droits(ctx, mois=args.mois)
    if _json(args):
        return _rendre(js.enveloppe("droits", {
            "mois": args.mois,
            "salaries": [js.position_droits(x) for x in positions]}))
    if not positions:
        print("Aucun contrat connu : ni historique importe (python -m moteur "
              "importer), ni mois produit.")
        return 1

    for d in positions:
        p, s = d.position, d.salarie
        print()
        print("%s %s - %s" % (s["nom"], s["prenom"], p.libelle_fenetre))
        print("-" * 62)
        print("  %-34s %6d" % ("cachets declares", p.cachets))
        print("  %-34s %6d h" % ("  convertis (12 h par cachet)",
                                 p.cachets * cumul.HEURES_PAR_CACHET_ISOLE))
        print("  %-34s %6d h" % ("heures declarees", p.heures))
        print("  %-34s %6d h" % ("TOTAL heures equivalentes", p.heures_equivalentes))
        if p.heures_enseignement:
            # Deux decomptes des qu'il y a de l'enseignement : ces heures
            # ouvrent les droits (plafonnees) mais n'augmentent pas l'ARE.
            print("  %-34s %6d h" % ("  dont enseignement", p.heures_enseignement))
            print("  %-34s %6d h" % ("  retenues (plafond %d h)"
                                     % p.plafond_enseignement,
                                     p.heures_enseignement_retenues))
            print("  %-34s %6d h" % ("POUR L'OUVERTURE des droits",
                                     p.heures_ouverture))
            print("  %-34s %6d h" % ("POUR LE MONTANT de l'ARE",
                                     p.heures_montant))
        print("  %-34s %6d h" % ("seuil annexes 8 et 10", cumul.SEUIL_HEURES))
        if p.atteint:
            print("  => seuil atteint, avec %d h de marge."
                  % (p.heures_ouverture - cumul.SEUIL_HEURES))
        else:
            print("  => il manque %d h, soit environ %d cachets."
                  % (p.manque, d.cachets_manquants))
        if d.anniversaire and d.jours_restants > 0:
            print("  %-34s %6d j" % ("avant le reexamen", d.jours_restants))
        if p.enseignement_perdu:
            print("  (%d h d'enseignement depassent le plafond : payees et"
                  % p.enseignement_perdu)
            print("   declarees, mais sans effet sur les droits.)")
        if p.heures_enseignement and not p.date_naissance:
            print("  (date de naissance absente de config/salaries.json : le")
            print("   plafond bas est applique, ce qui sous-estime peut-etre.)")
        if not d.anniversaire:
            print("  (fenetre deduite du dernier contrat declare. Renseigner")
            print("   'anniversaire_droits' dans config/salaries.json des que")
            print("   France Travail l'a notifiee : elle prime sur ce calcul.)")
        cols = d.colonnes
        print()
        print("  %-22s%s" % ("", "".join("%14s" % c.titre for c in cols)))
        print("  %-22s%s" % ("", "".join("%14s" % c.sous_titre for c in cols)))
        for lib, attr, suf in (("Cachets", "cachets", ""),
                               ("Heures declarees", "heures", " h"),
                               ("TOTAL heures", "heures_equivalentes", " h"),
                               ("Salaire brut", "brut", "")):
            vals = "".join("%14s" % ("%s%s" % (getattr(c, attr), suf)) for c in cols)
            print("  %-22s%s" % (lib, vals))
        droits_col = cols[-1]
        if droits_col.reste is not None:
            print("  %-22s%s" % ("RESTE avant le seuil",
                                 "%42s" % ("%d h" % droits_col.reste
                                           if droits_col.reste else "seuil atteint")))
        if args.detail:
            print()
            for e in sorted(p.engagements, key=lambda e: e.fin):
                print("     %s -> %s  obj %-12s h=%-3d cachets=%-2d = %3d h"
                      % (e.debut.strftime("%d/%m/%y"), e.fin.strftime("%d/%m/%y"),
                         e.numero_objet, e.heures, e.cachets, e.heures_equivalentes))
    print("""
Ce compte vaut ce que valent les AEM deposees : il ne remplace pas le releve de
France Travail, qui seul fait foi et qui peut retenir un autre contrat de
reference. Il sert a voir venir, pas a decider a la place de l'organisme.""")
    print("""
Et ce ne sont QUE les AEM de la compagnie. Le seuil se compte sur tous les
employeurs : a chacun d'ajouter les siens. Ces totaux sont un plancher.""")
    return 0


def cmd_rubriques(ctx, args):
    """Le catalogue des rubriques : ce que le logiciel sait payer.

    C'est `moteur/rubriques-base.json`, construit depuis les textes, augmente
    de ce que la compagnie a ajoute. Les rubriques cochees sont marquees d'une
    etoile et remontent en tete, la plus utilisee d'abord : c'est l'ordre dans
    lequel la saisie les proposera.
    """
    liste = ops.rubriques(ctx, actives_seulement=args.actives)
    if _json(args):
        return _rendre(js.enveloppe("rubriques", {
            "total": len(liste), "rubriques": liste}))
    if not liste:
        print("Aucune rubrique. Attendu : moteur/rubriques-base.json")
        return 1

    print()
    print("%d rubrique(s)%s" % (len(liste),
                                " cochee(s)" if args.actives else ""))
    print("-" * 78)
    print("   %-22s %-34s %-11s %7s" % ("code", "libelle", "unite", "heures"))
    for r in liste:
        marque = "*" if r["active"] else " "
        propre = " +" if r["origine"] == "compagnie" else ""
        heures = ("%g" % r["heures_forfait"]) if r["heures_forfait"] else "saisies"
        print(" %s %-22s %-34s %-11s %7s%s" % (
            marque, r["code"], (r["libelle"] or "")[:34], r["unite"],
            heures, propre))
    print("-" * 78)
    if args.detail:
        for r in liste:
            print()
            print("  %s -- %s" % (r["code"], r["libelle"]))
            print("     %s" % r["source"])
    print("""
* cochee par la compagnie   + rubrique propre a la compagnie

Une rubrique dit ce qu'elle paie (unite, saisie), si elle cotise et si elle
est imposable, ce qu'elle declare (plafond, AEM, DSN), et D'OU VIENT SA REGLE.
`--detail` affiche cette derniere.

Les JOURS travailles ne sont portes par aucune rubrique : ce sont les jours
ou le salarie a travaille, et ils se saisissent avec les dates.

`config/rubriques.json` est autre chose : la copie des 81 rubriques de
CoolPaie, gardee pour comprendre et verifier. Elle ne paie rien.""")
    return 0


def cmd_emplois(ctx, args):
    """Le catalogue des metiers : ce qu'un engagement declare quand il dit
    `metier`. Groupe par famille ; `--tous` deroule la nomenclature France
    Travail entiere (cinema, audiovisuel, radio...) a la suite."""
    liste = ops.metiers(ctx, tous=args.tous)
    if args.chercher:
        q = args.chercher.lower()
        liste = [m for m in liste if q in m["libelle"].lower() or q in m["code"].lower()]
    if _json(args):
        return _rendre(js.enveloppe("emplois", {"total": len(liste), "emplois": liste}))
    print()
    print("%d metier(s)%s" % (len(liste), " (catalogue + nomenclature)" if args.tous else ""))
    print("-" * 78)
    famille = None
    for m in liste:
        if m["famille"] != famille:
            famille = m["famille"]
            print()
            print("  %s" % famille.upper())
        cadre = " cadre" if m["cadre_par_defaut"] else ""
        print("   %-7s %-44s %-10s %-5s%s" % (
            m["code"], m["libelle"][:44], m["statut"], m["pcs_ese"] or "-", cadre))
    print("-" * 78)
    print("""
code = code emploi France Travail (DSN S21.G00.40.005) ; PCS-ESE (40.004) ;
statut = artiste (annexe 10, taux abattus) ou technicien (annexe 8).
Dans une paie : "metier": "REG120", et au besoin "cadre": true.
Sources : `python -m moteur sources`.""")
    return 0


def cmd_sources(ctx, args):
    """D'ou viennent les donnees livrees, de quand elles datent, et -- avec
    `--verifier` -- si la source en ligne a bouge depuis qu'on l'a lue."""
    liste = ops.sources(ctx, verifier=args.verifier, relever=args.relever)
    if _json(args):
        return _rendre(js.enveloppe("sources", {"total": len(liste), "sources": liste}))
    print()
    for e in liste:
        print("%s" % e["ident"])
        print("   %s" % e["titre"])
        print("   %s -- version %s, relevee le %s (il y a %s j)" % (
            e["editeur"], e["version"] or "?", e["releve_le"] or "?",
            e["age_jours"] if e["age_jours"] is not None else "?"))
        print("   %s" % e["contenu"])
        copie = ("copie conforme" if e["copie_conforme"] else
                 "COPIE DIFFERENTE du manifeste" if e["copie_presente"] else
                 "copie absente (reference/sources/%s)" % e["fichier"])
        print("   %s ; nourrit : %s" % (copie, ", ".join(e["nourrit"]) or "rien (verification)"))
        if e["en_ligne"]:
            marque = {"inchangee": "OK", "changee": "A RELIRE", "injoignable": "??",
                      "manuelle": "A LA MAIN"}[e["en_ligne"]]
            print("   en ligne : %s %s" % (marque, e["detail"]))
            if e["en_ligne"] in ("manuelle", "changee") and e["page_de_veille"]:
                print("   ouvrir : %s" % e["page_de_veille"])
        print()
    if not args.verifier:
        print("`--verifier` retelecharge chaque source et compare ; `--relever` pose "
              "la nouvelle version a cote de l'ancienne quand elle a change.")
    return 0


def cmd_interface(ctx, args):
    """L'autre face du logiciel. Elle appelle `operations`, comme ici.

    Le serveur bloque jusqu'a Ctrl+C : c'est une fenetre, pas un service. On
    ne le lance pas en arriere-plan, et il ne survit pas au terminal -- un
    serveur oublie qui tourne sur une machine, personne ne le veut.
    """
    from . import coffre, web
    from .commandes_ouverture import _demander

    # Le mot de passe du logiciel, s'il en existe un ET que la seance est
    # fermee : tape UNE fois ici, il l'ouvre -- et c'est elle qui autorisera un
    # depot pendant deux heures. Voir moteur/coffre.py.
    #
    # « ET QUE LA SEANCE EST FERMEE » N'EST PAS UN DETAIL. La premiere version
    # demandait des qu'un mot de passe etait pose, seance ouverte ou non. Deux
    # consequences : on le retapait pour rien, et surtout `lanceur_interface`
    # -- qui ouvre la seance lui-meme puis lance cette commande en
    # sous-processus, sans terminal -- restait bloque pour toujours sur un
    # `getpass` que personne ne pouvait voir. Attrape par un test de bout en
    # bout, pas par la lecture.
    seance = coffre.seance(ctx)
    if seance.exigee and not seance.ouverte:
        mdp = _demander("Mot de passe PuppetPaie : ")
        if mdp is None:
            return 2
        try:
            # Le proprietaire est CE processus : c'est lui qui sert
            # l'interface, et la seance ne doit pas lui survivre.
            coffre.ouvrir_seance(ctx, mdp, proprietaire=os.getpid())
        except coffre.ErreurCoffre as e:
            print("%s" % e)
            return 1
        finally:
            del mdp
        print("Seance ouverte : elle dure tant que cette fenetre est la.\n")

    print("Interface PuppetPaie")
    print("  donnees : %s" % ctx.racine)
    print("  Le serveur n'ecoute que la machine (127.0.0.1), sur le port 7331")
    print("  -- fixe, pour que le navigateur reconnaisse le site et retrouve")
    print("  le mot de passe -- et exige un jeton.")
    # Cette fenetre a longtemps annonce << rien ne part et rien n'est depose
    # depuis l'interface >>. C'etait vrai jusqu'au 11/09/2026, et le §19.4 du
    # journal l'a leve : la seance prouve la presence, le mot de passe du
    # logiciel retape prouve la lecture. Une phrase qu'on laisse apres coup
    # est une phrase sur laquelle quelqu'un se fie.
    print("  Les depots et les envois sont possibles depuis l'interface :")
    print("  seance ouverte, et le mot de passe du logiciel retape a chaque")
    print("  acte. Le secret d'un organisme, lui, ne quitte jamais le moteur.")
    if args.veille:
        print("  A l'ouverture puis toutes les %d minutes : sauvegarde du"
              % args.veille)
        print("  dossier prive dans le Drive, et releve des retours.")
    print()
    def annoncer(adresse):
        print("  %s" % adresse)
        print()
        print("  Ctrl+C pour arreter.")
        print()

    try:
        web.servir(ctx, ouvrir=not args.sans_navigateur, port=args.port,
                   annoncer=annoncer, minutes_veille=args.veille)
    except KeyboardInterrupt:
        pass
    print("Interface arretee.")
    return 0


def cmd_calibrer(ctx, args):
    return 0 if ops.calibrer(ctx, args.export) else 1


def cmd_importer(ctx, args):
    """Reprendre de CoolPaie ce qui est deja declare : fiches et historique.

    Sans `--ecrire`, l'apercu seulement -- ce que l'import creerait, et ce
    que les DSN disaient autrement que les fiches. C'est le meme apercu que
    l'ecran montre avant son bouton.
    """
    try:
        imp = (ops.importer if args.ecrire else ops.apercu_importation)(ctx, args.export)
    except ops.ExportIntrouvable as e:
        if _json(args):
            return _rendre(js.erreur("importer", e))
        print(e)
        return 1
    if _json(args):
        return _rendre(js.enveloppe("importer", js.importation(imp)))

    print("Export CoolPaie : %s" % imp.source)
    print("  %d DSN (%s a %s), %d fichier(s) AEM, %d contrat(s) atteste(s)%s"
          % (imp.dsn, imp.premier_mois or "?", imp.dernier_mois or "?", imp.aem,
             imp.contrats, " du %s au %s" % (imp.contrats_du, imp.contrats_au)
             if imp.contrats else ""))
    verbe = "creee" if imp.ecrit else "a creer"
    for f in [imp.entreprise] + imp.salaries + imp.spectacles:
        if f is None:
            continue
        if f.etat == "existante":
            etat = "existe deja"
        elif f.etat == "creee":
            etat = "CREEE (%s)" % f.cle
        else:
            etat = "A CREER"
        print("  %-10s %-32s %s" % (f.nom, f.libelle[:32], etat))
        for champ, e in f.ecarts.items():
            print("             la DSN de %s disait %s = %r, la fiche dit %r "
                  "-- la fiche fait foi" % (e["mois"], champ, e["dsn"], e["fiche"]))
        for a in f.anomalies:
            if a["gravite"] == "erreur":
                print("             ! %s : %s" % (a["champ"], a["message"]))
    print("  historique : %d contrat(s) %s, %d deja connu(s)%s"
          % (imp.contrats_nouveaux, "ajoute(s)" if imp.ecrit else "a ajouter",
             imp.contrats - imp.contrats_nouveaux - imp.contrats_sans_fiche,
             ", %d sans fiche" % imp.contrats_sans_fiche if imp.contrats_sans_fiche else ""))
    for a in imp.avertissements:
        print("  ! %s" % a)
    if imp.ecrit:
        for f in imp.fichiers:
            print("  ecrit : %s" % f)
    elif imp.rien_a_faire:
        print("  Rien a importer : tout est deja la.")
    else:
        print("  Rien n'est ecrit. Pour ecrire : python -m moteur importer --ecrire")
    return 0


def cmd_fiche(ctx, args):
    from .contexte import archivee

    f = ops.fiche(ctx, archives=getattr(args, "archives", False))
    if _json(args):
        return _rendre(js.enveloppe("fiche", js.fiche(f)))
    print("Entreprise : %s - SIRET %s - IDCC %s"
          % (f.entreprise["raison_sociale"], f.entreprise["siret"],
             f.entreprise["idcc"]))
    print("\nSalaries :")
    for k, s in f.salaries.items():
        print("  %-10s %s %s  NIR %s%s  code %s%s"
              % (k, s["nom"], s["prenom"], s["nir"], s["nir_cle"],
                 s["code_salarie"], "   [archive]" if archivee(s) else ""))
    print("\nSpectacles :")
    for k, sp in f.spectacles.items():
        print("  %-22s %-24s objet %s%s"
              % (k, sp["titre"], sp["numero_objet"],
                 "   [archive]" if archivee(sp) else ""))
    if not args.archives and (f.salaries_archives or f.spectacles_archives):
        # Le dire, et ne pas les lister : une fiche archivee dont personne ne
        # parle passe pour perdue, et on la ressaisit.
        print("")
        print("Archives : %d salarie(s), %d spectacle(s). `--archives` les montre."
              % (len(f.salaries_archives), len(f.spectacles_archives)))
    print("\nCompteurs :")
    print("  %s" % json.dumps(f.compteurs, ensure_ascii=False))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m moteur",
                                 description="Paie intermittents - Compagnia UEUEUE")
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("nouveau", help="creer un fichier de saisie pour un mois")
    a.add_argument("mois", help="AAAA-MM")
    a.add_argument("--force", action="store_true")
    a.add_argument("--reprendre", action="store_true",
                   help="y ecrire les contrats en cours des mois precedents "
                        "(bornes et numero), a completer avec les jours du mois")
    a.set_defaults(fn=cmd_nouveau)

    b = sub.add_parser("mois", help="produire contrats, DPAE, bulletins, AEM et DSN")
    b.add_argument("fichier")
    b.add_argument("--sans-contrat", action="store_true",
                   help="ne pas regenerer contrats et DPAE (deja faits)")
    b.add_argument("--constitution", help="date de constitution de la DSN (JJ/MM/AAAA)")
    # `--audiens` est un NOM HERITE ET FAUX : ce montant est celui du
    # bordereau URSSAF (voir _note_libelles dans organismes.json,
    # 10/09/2026). `--urssaf` est le nom juste ; l'ancien reste
    # accepte pour ne pas casser les habitudes et les scripts.
    b.add_argument("--urssaf", "--audiens", dest="urssaf", type=float,
                   help="montant du telepaiement URSSAF (bloc S21.G00.20), "
                        "recopie du bordereau URSSAF - obligatoire")
    b.add_argument("--test", dest="envoi_test", action="store_true",
                   help="produire la DSN en ENVOI DE TEST (S10.G00.00.005 = 01) : "
                        "controles executes et bilan rendu, donnees non conservees")
    b.add_argument("--urssaf-estime", "--audiens-estime",
                   dest="urssaf_estime", action="store_true",
                   help="a defaut de bordereau, accepter l'estimation du moteur "
                        "(la DSN est alors a verifier avant depot)")
    b.set_defaults(fn=cmd_mois)

    dp = sub.add_parser("dpae", help="produire la seule DPAE, avant l'embauche")
    dp.add_argument("fichier")
    dp.add_argument("--heure", default="0800", metavar="HHMM",
                    help="heure d'embauche, format HHMM (defaut 0800)")
    dp.add_argument("--seulement", nargs="+", metavar="SALARIE:AAAA-MM-JJ",
                    help="ne declarer que ces embauches, dans un fichier "
                         "horodate a cote du complet (le complet n'est pas "
                         "touche). Ex. : --seulement PUPPIS:2026-08-23")
    dp.add_argument("--force", action="store_true",
                    help="reecrire meme une embauche deja declaree (depot "
                         "rejete par l'Urssaf, a refaire). Sans lui, une "
                         "embauche deja partie bloque, et dit ou en est son "
                         "retour.")
    dp.set_defaults(fn=cmd_dpae)

    en = sub.add_parser("envoi", help="envoyer bulletin, certificat CS et AEM aux salaries")
    en.add_argument("fichier")
    en.add_argument("--sans-navigateur", action="store_true",
                    help="ne pas ouvrir le navigateur ; l'URL est affichee")
    en.set_defaults(fn=cmd_envoi)

    g = sub.add_parser("google", help="autoriser le compte Google (Gmail + Drive)")
    g.add_argument("quoi", choices=["etat", "autoriser", "oublier"],
                   nargs="?", default="etat")
    g.add_argument("--sans-navigateur", action="store_true",
                   help="ne pas ouvrir le navigateur ; l'URL est affichee")
    g.set_defaults(fn=cmd_google)

    ar = sub.add_parser("archiver", help="deposer les sorties d'un mois dans le Drive")
    ar.add_argument("mois", help="AAAA-MM")
    ar.add_argument("--racine-drive", default="PuppetPaie",
                    help="dossier racine dans le Drive (defaut : PuppetPaie)")
    ar.set_defaults(fn=cmd_archiver)

    dr = sub.add_parser("droits", help="heures et cachets cumules (annexes 8 et 10)")
    dr.add_argument("--detail", action="store_true", help="lister les contrats")
    dr.add_argument("--mois", default=_dt.date.today().strftime("%Y-%m"),
                    help="mois de la colonne Periode (AAAA-MM), defaut le mois courant")
    dr.set_defaults(fn=cmd_droits)

    c = sub.add_parser("calibrer", help="rejouer l'historique CoolPaie")
    c.add_argument("--export", help="dossier export/ de CoolPaie")
    c.set_defaults(fn=cmd_calibrer)

    im = sub.add_parser("importer", help="reprendre de CoolPaie les fiches "
                        "(salaries, spectacles, entreprise) et l'historique des "
                        "contrats attestes")
    im.add_argument("--export", help="dossier export/ de CoolPaie (defaut : "
                    "celui trouve a cote des donnees)")
    im.add_argument("--ecrire", action="store_true",
                    help="ecrire ce que l'apercu annonce. Sans lui, rien n'est ecrit.")
    im.set_defaults(fn=cmd_importer)

    e = sub.add_parser("fiche", help="rappeler les donnees de reference")
    e.add_argument("--archives", action="store_true",
                   help="montrer aussi les fiches archivees (`actif: false`)")
    e.set_defaults(fn=cmd_fiche)

    ru = sub.add_parser("rubriques", help="le catalogue des rubriques de paie")
    ru.add_argument("--actives", action="store_true",
                    help="seulement celles que la compagnie a cochees")
    ru.add_argument("--detail", action="store_true",
                    help="afficher la source de chaque rubrique")
    ru.set_defaults(fn=cmd_rubriques)

    em = sub.add_parser("emplois", help="le catalogue des metiers (codes emploi, PCS, statut)")
    em.add_argument("--tous", action="store_true",
                    help="ajouter la nomenclature France Travail entiere (1 236 codes)")
    em.add_argument("--chercher", metavar="MOT", help="filtrer sur le libelle ou le code")
    em.set_defaults(fn=cmd_emplois)

    so = sub.add_parser("sources", help="les sources des donnees livrees, et leur veille")
    so.add_argument("--verifier", action="store_true",
                    help="retelecharger chaque source et comparer au manifeste (reseau)")
    so.add_argument("--relever", action="store_true",
                    help="avec --verifier : garder la nouvelle version a cote de l'ancienne")
    so.set_defaults(fn=cmd_sources)

    it = sub.add_parser("interface", help="ouvrir l'interface dans le navigateur")
    it.add_argument("--sans-navigateur", action="store_true",
                    help="ne pas ouvrir le navigateur ; l'URL est affichee")
    it.add_argument("--port", type=int, default=None,
                    help="port d'ecoute (defaut : 7331, pour que le navigateur "
                         "reconnaisse le site et son mot de passe ; 0 = au hasard)")
    it.add_argument("--veille", type=int, default=20, metavar="MINUTES",
                    help="sauvegarde et releve des retours a l'ouverture puis "
                         "toutes les N minutes (0 : seulement a l'ouverture)")
    it.set_defaults(fn=cmd_interface)

    from .commandes_ouverture import enregistrer_commandes as enregistrer_ouverture
    enregistrer_ouverture(sub)

    from .commandes_retours import enregistrer_commandes
    enregistrer_commandes(sub)

    from .commandes_dsn import enregistrer_commandes as enregistrer_depot_dsn
    enregistrer_depot_dsn(sub)

    from .commandes_dpae import enregistrer_commandes as enregistrer_dpae
    enregistrer_dpae(sub)

    from .commandes_maj import enregistrer_commandes as enregistrer_maj
    enregistrer_maj(sub)

    # `--json` est offert a TOUTES les sous-commandes, y compris celles des
    # modules `commandes_*`, en le posant apres coup sur chaque sous-parseur.
    # Celles qui ne savent pas encore le rendre l'acceptent sans rien changer :
    # mieux vaut une option ignoree qu'une option qui existe ici et pas la.
    for nom, sp in sub.choices.items():
        if not any(a.dest == "json" for a in sp._actions):
            sp.add_argument("--json", action="store_true",
                            help="sortie lisible par un programme "
                                 "(interface, API) plutot que par un humain")

    args = ap.parse_args(argv)
    return args.fn(Contexte(), args)


if __name__ == "__main__":
    sys.exit(main())
