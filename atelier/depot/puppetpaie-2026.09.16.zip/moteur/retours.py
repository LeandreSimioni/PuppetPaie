"""Lecture des retours DSN : ce que les organismes repondent apres un depot.

Chaine des retours, du plus rapide au plus tardif :

    10  accuse d'enregistrement / avis de rejet   (synchrone, au depot)
    11  certificat de conformite / bilan d'anomalies
    20  bilan d'identification des salaries
    21  controles de coherence inter-declarations
    40..46  France Travail (dont 45/46 « cinema, spectacle »)
    60/61   URSSAF
    92..95  DGFiP -- dont 94, « CR donnees nominatives (Taux du PAS) »
    n/a     fiches de parametrage OC (Audiens)

Le retour 94 est la raison d'etre de ce module : il porte le taux de
prelevement a la source de chaque salarie et son identifiant, seule source
possible de S21.G00.50.006/.007/.008 (voir moteur/pas.py).

DEUX PRINCIPES, parce que ce module parle a un service exterieur.

1. On archive AVANT de comprendre. Chaque retour telecharge est ecrit tel quel
   dans retours/, horodate, avant toute tentative d'analyse. Un parseur qui se
   trompe ne coute alors rien : le fichier est sur le disque et on recommence.

2. On dit ce qu'on n'a pas compris. L'extraction du CRM 94 procede par quatre
   strategies, de la plus sure a la plus large, et ANNONCE laquelle a repondu.
   Ce n'est pas une precaution de style : ecrit a l'aveugle faute de XSD, le
   parseur est tombe au premier essai sur la strategie de dernier recours et a
   rendu « identifiant 1 » et « identifiant 2 » -- les matricules internes. Le
   fait que la strategie soit affichee a rendu l'erreur evidente en une seconde,
   et rien n'avait ete ecrit puisque l'ecriture demande --appliquer.

Le format reel du CRM 94, releve le 19/08/2026 :

    <ns2:rapport identifiant="450189378" type="CRM nominatif" version="v02r01">
      <envoi>...<idflux>...</idflux>...</envoi>
      <declaration><declaration_bilan>
        <salarie>
          <NIR>1880275999999</NIR>
          <matricule>2</matricule>
          <taux_imposition_PAS>0.00</taux_imposition_PAS>
        </salarie>
      </declaration_bilan></declaration>
    </ns2:rapport>
"""
from __future__ import annotations
import io
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import dataclass, replace
from pathlib import Path

from .util import cle_recherche

# Natures de retour, guide d'implementation de l'API DSN v6.8, section 1.3
NATURES = {
    "10": "Accuse d'enregistrement electronique / avis de rejet",
    "11": "Certificat de conformite / bilan d'anomalies",
    "20": "Bilan d'identification des salaries",
    "21": "Controles inter-declarations / signalement AT-RT",
    "22": "Controles arret de plus de 6 mois",
    "23": "Controles temps partiel therapeutique",
    "40": "Accuse de reception France Travail",
    "42": "Compte-rendu metier CDDU-D",
    "43": "AER CDDU-D (archive PDF)",
    "44": "AER ou compte-rendu metier FCTU",
    "45": "Compte-rendu metier « cinema, spectacle, expatries »",
    "46": "AER « cinema, spectacle » (archive PDF)",
    "50": "Accuse de distribution a l'organisme complementaire",
    "51": "Compte-rendu metier de l'organisme complementaire",
    "60": "Accuse de reception URSSAF",
    "61": "Compte-rendu metier URSSAF, donnees agregees",
    "70": "Accuse de reception AGIRC-ARRCO",
    "71": "Compte-rendu metier AGIRC-ARRCO",
    "92": "Accuse de reception DGFiP",
    "93": "Compte-rendu metier DGFiP, donnees agregees",
    "94": "Compte-rendu metier DGFiP, donnees nominatives (taux du PAS)",
    "95": "Compte-rendu metier DGFiP, controles taux sur taux",
    "117": "Compte-rendu metier bonus-malus contribution chomage",
    "118": "Compte-rendu metier effectifs",
    "119": "Compte-rendu metier URSSAF H+4 (immediat)",
    "120": "Compte-rendu metier URSSAF J+5 (opposable)",
    "121": "Compte-rendu metier identite",
    "124": "Compte-rendu metier URSSAF de rappel",
}

NATURE_TAUX_PAS = "94"

# FRANCE TRAVAIL, SPECTACLE -- ce qui a change le 01/06/2026.
#
# La compagnie etait en phase pilote DSN ; France Travail l'a notifiee le
# 28/05/2026 de son passage en 100 % DSN au 1er juin. Depuis, nous n'emettons
# PLUS d'AEM : c'est France Travail qui edite l'attestation employeur a partir
# de notre DSN, et nous la renvoie dans les retours. Il ne reste qu'a la
# remettre au salarie.
#
#   45  compte-rendu metier : nos contrats spectacle ont-ils ete pris
#   46  l'attestation elle-meme -- une archive d'un PDF par salarie
NATURE_CRM_SPECTACLE = "45"
NATURE_AER_SPECTACLE = "46"

# Retours qu'il faut conserver comme preuve
A_ARCHIVER_ABSOLUMENT = {"10", "11"}


def libelle_nature(code: str) -> str:
    return NATURES.get(str(code), "nature %s (inconnue de ce moteur)" % code)


# ------------------------------- AER « cinema, spectacle », retour de nature 46
#
# Le retour est une ARCHIVE ZIP. L'API la sert avec un type qui la fait
# archiver en `.txt` : ne pas se fier a l'extension, ouvrir et voir. Elle
# contient un PDF par salarie, nomme par France Travail :
#
#     AER_<siret>__<MMAAAA>_<code>_<JJMMAAAA>_<NOM>_<PRENOM>_<rang>_<id>.pdf
#
# Le nom porte tout ce qu'il faut pour ranger le document sans l'ouvrir. Et on
# ne l'ouvre pas : c'est une piece de France Travail, elle se transmet telle
# quelle. Nous ne la regenerons pas, contrairement a l'AEM papier d'avant --
# c'est justement ce qui a disparu de notre charge.


@dataclass
class Attestation:
    """Une AER, telle qu'elle sort de l'archive."""
    nom_archive: str
    periode: str            # AAAA-MM, vide si le nom n'a pas pu etre lu
    qui: str                # « NOM PRENOM », tel que France Travail l'ecrit
    donnees: bytes


_NOM_AER = re.compile(
    r"^AER_(?P<siret>\d+)_+(?P<periode>\d{6})_(?P<code>[^_]*)_"
    r"(?P<genere>\d{8})_(?P<qui>.+?)_(?P<rang>\d+)_(?P<identifiant>\d+)"
    r"\.pdf$", re.IGNORECASE)


def aer_spectacle(contenu: bytes) -> list:
    """Les attestations contenues dans un retour de nature 46.

    Rend une liste VIDE si le contenu n'est pas une archive lisible, au lieu
    de lever : un retour illisible est un fait a signaler a l'ecran, pas une
    exception. Le fichier brut reste archive, on peut toujours recommencer --
    meme principe que pour le CRM 94.

    Un PDF dont le nom ne suit pas le motif est rendu quand meme, periode
    vide : mieux vaut un document a ranger a la main qu'un document perdu.
    """
    try:
        arch = zipfile.ZipFile(io.BytesIO(contenu))
    except (zipfile.BadZipFile, OSError):
        return []
    out = []
    for nom in arch.namelist():
        if nom.endswith("/"):
            continue
        m = _NOM_AER.match(Path(nom).name)
        if m:
            mmaaaa = m.group("periode")
            periode = "%s-%s" % (mmaaaa[2:], mmaaaa[:2])
            qui = m.group("qui").replace("_", " ")
        else:
            periode, qui = "", Path(nom).stem
        out.append(Attestation(nom_archive=nom, periode=periode, qui=qui,
                               donnees=arch.read(nom)))
    return out


def rattacher(attestations: list, salaries: dict) -> list:
    """[(Attestation, cle du salarie ou None)] pour chaque attestation.

    Le rapprochement se fait sur le nom et le prenom NORMALISES, jamais sur la
    cle de `config/salaries.json` : France Travail ecrit ce qu'il a recu dans
    la DSN, et la cle est a nous seuls (« PERE-CLET » pour « PERE LAHAILLE
    CLET »). On essaie la correspondance la plus longue d'abord, pour qu'un
    nom contenu dans un autre ne gagne pas la place du bon.
    """
    index = sorted(
        ((cle_recherche("%s %s" % (v.get("nom", ""), v.get("prenom", ""))), cle)
         for cle, v in salaries.items() if isinstance(v, dict)),
        key=lambda x: -len(x[0]))
    out = []
    for a in attestations:
        cible = cle_recherche(a.qui)
        trouve = next((cle for nom, cle in index
                       if nom and (nom in cible or cible in nom)), None)
        out.append((a, trouve))
    return out


# ------------------------------- bilans de depot : les natures 10 et 11
#
# Ces deux retours sont les seuls qui parlent du DEPOT lui-meme plutot que de
# son contenu, et c'est ce qui les rend reconstructibles. Un retour de nature
# 10 (rapport `AEE`, accuse d'enregistrement electronique) atteste qu'un envoi
# est arrive et dit quand ; un retour de nature 11 (rapport `CCO`, certificat
# de conformite) dit en plus CE QUI a ete declare -- le mois, le type, le
# nombre de salaries -- et, c'est la trouvaille, LE NOM DU LOGICIEL QUI L'A
# DEPOSE.
#
# Ce dernier point resout seul la question que le journal ne savait pas
# trancher : distinguer << depose par PuppetPaie >> de << depose par
# CoolPaie >>. On ne l'annote donc pas a la main, on le LIT.
#
# `essai_reel` est la meme valeur que `S10.G00.00.005` du fichier depose :
# 01 = envoi de test (rien n'est conserve), 02 = envoi reel (c'est une
# declaration). Ne pas la confondre avec l'etat : un envoi de TEST peut etre
# OK, et il n'a rien declare pour autant.
ESSAI_TEST = "01"
ESSAI_REEL = "02"

# Les deux natures qui attestent un depot. Les autres retours parlent de ce
# qui a ete declare (identification, taux, AER...) : ils se rattachent a un
# depot, ils n'en temoignent pas.
NATURES_BILAN_DEPOT = ("10", "11")

# Les trois formes de rapport qui attestent un depot, et la distinction qui
# compte :
#
#   AEE  accuse d'enregistrement (nature 10). Il dit que l'envoi est ARRIVE.
#   CCO  certificat de conformite (nature 11). La declaration est acceptee.
#   BAN  bilan d'anomalies (nature 11). La declaration est REJETEE.
#
# UN AEE << OK >> NE VEUT PAS DIRE ACCEPTE. C'est un accuse de TRANSPORT : il
# vaut OK des que le fichier est arrive lisible, meme quand le bilan qui suit
# le rejette quelques secondes plus tard. Deux des huit depots de la compagnie
# sont exactement dans ce cas -- AEE OK, puis BAN KO -- et une reprise qui
# aurait cru l'accuse aurait note deux declarations faites qui n'existent pas.
#
# Les autres retours (45, 61, 71, 94, 118-121...) sont aussi des `rapport`
# mais parlent du CONTENU declare, pas du depot. Ils se rattachent a une ligne
# de journal par leur flux ; ils n'en fondent pas une.
RAPPORTS_DEPOT = ("CCO", "BAN", "AEE")


@dataclass
class BilanDepot:
    """Ce qu'un accuse (10) ou un certificat (11) dit du depot qui l'a cause.

    Les champs vides le RESTENT. Un accuse de nature 10 ne porte pas le mois
    declare : `mois` vaut alors "", et c'est au lecteur d'en tenir compte --
    pas a ce module de deviner lequel des mois ouverts c'etait.
    """
    flux: str
    recu_le: str = ""          # ISO, de date_reception + heure_reception
    essai_reel: str = ""       # "01" test, "02" reel, "" si absent
    # DEUX ETATS, ET ILS NE DISENT PAS LA MEME CHOSE. Voir la propriete
    # `accepte` : trois des huit depots de la compagnie sont OK a l'envoi et
    # KO a la declaration.
    etat_envoi: str = ""       # le TRANSPORT : le fichier est-il arrive
    etat_declaration: str = ""  # la DECLARATION : est-elle retenue
    mois: str = ""             # "2026-08", depuis <mois>01082026</mois>
    logiciel: str = ""         # COOLPAIE, PUPPETPAIE...
    type_rapport: str = ""     # AEE (nature 10) ou CCO (nature 11)
    type_declaration: str = ""
    fraction: str = ""
    ordre: str = ""
    salaries: str = ""
    contrats: str = ""
    conformite: str = ""       # etat_conformite, quand il y en a un
    certificat: str = ""       # le certificat de conformite, en entier
    siret_declarant: str = ""

    @property
    def reel(self) -> bool:
        return self.essai_reel == ESSAI_REEL

    @property
    def verdict_connu(self) -> bool:
        """Vrai quand un bilan de DECLARATION a repondu (CCO ou BAN).

        Faux quand on n'a que l'accuse de transport : le depot a eu lieu, et
        on ne sait pas encore ce qu'il devient. L'ecran doit dire << parti,
        pas encore de retour >>, pas << conforme >>.
        """
        return bool(self.etat_declaration)

    @property
    def accepte(self) -> bool:
        """LA DECLARATION est-elle retenue -- et non : le fichier est-il arrive.

        La distinction a failli coûter trois lignes fausses. `envoi_etat` vaut
        OK des que le fichier est arrive lisible ; le bilan qui suit peut
        rejeter la declaration quelques secondes plus tard, et c'est
        exactement ce qui s'est passe les 10 et 11/09/2026 sur trois depots :

            envoi_etat=OK   etat=KO   etat_conformite=KO   (rapport BAN)

        Le verdict de la declaration l'emporte donc des qu'il existe. Tant
        qu'il n'existe pas, on s'en tient a ce que le transport dit -- le
        depot a bien eu lieu, et `verdict_connu` dit qu'on attend la suite.

        Un refus se note quand meme au journal : << on a essaye, ca a casse >>
        est l'information qui manque le plus quand on reprend le lendemain.
        Mais il ne doit jamais compter comme fait.
        """
        etat = self.etat_declaration or self.etat_envoi
        return (etat or "").upper() == "OK"


def _mois_lisible(brut: str) -> str:
    """'01082026' -> '2026-08'. Meme conversion que `dsn_api.mois_lisible`."""
    m = re.fullmatch(r"01(\d{2})(\d{4})", (brut or "").strip())
    return "%s-%s" % (m.group(2), m.group(1)) if m else ""


def parse_bilan_depot(contenu: bytes | str) -> BilanDepot | None:
    """Un rapport AEE ou CCO du GIP-MDS, en dict. None si ce n'en est pas un.

    On ne leve pas sur un fichier qui n'est pas un rapport : la reconstruction
    balaie un dossier d'archives ou cohabitent des XML de toutes natures et des
    PDF. Un fichier illisible doit etre SAUTE et compte, pas faire echouer la
    reprise entiere.
    """
    if isinstance(contenu, bytes):
        contenu = contenu.decode("utf-8", "replace")
    try:
        racine = ET.fromstring(contenu.strip())
    except ET.ParseError:
        return None
    if _localname(racine.tag) != "rapport":
        return None
    if racine.get("type") not in RAPPORTS_DEPOT:
        # Un CRM metier, un retour France Travail : un `rapport`, mais qui ne
        # temoigne pas d'un depot. L'accepter aurait fabrique une ligne de
        # journal sans date et sans mois, a partir d'un fichier qui ne parle
        # pas de ca.
        return None

    # Un balayage a plat, premiere occurrence gagnante. Les noms utiles ne se
    # repetent pas d'un bloc a l'autre, sauf <salaries> -- present au niveau
    # de l'envoi ET de la declaration, avec la meme valeur quand il n'y a
    # qu'une declaration, ce qui est notre cas depuis toujours.
    champs = {}
    for el in racine.iter():
        nom = _localname(el.tag)
        texte = (el.text or "").strip()
        if texte and nom not in champs:
            champs[nom] = texte

    flux = champs.get("idflux", "")
    if not flux:
        # Sans flux, la ligne ne pourrait pas recevoir ses retours et ne
        # pourrait pas etre dedoublonnee. On prefere ne rien reconstruire.
        return None
    d, h = champs.get("date_reception", ""), champs.get("heure_reception", "")
    return BilanDepot(
        flux=flux,
        recu_le=("%sT%s" % (d, h)) if d and h else (d or ""),
        essai_reel=champs.get("essai_reel", ""),
        etat_envoi=champs.get("envoi_etat", ""),
        # `etat` est celui de `declaration_bilan` ; `etat_conformite` le
        # redit, et les huit rapports de l'historique les portent d'accord.
        # On prend le premier present : un BAN sans <etat> resterait lisible
        # par sa conformite.
        etat_declaration=(champs.get("etat")
                          or champs.get("etat_conformite", "")),
        mois=_mois_lisible(champs.get("mois", "")),
        logiciel=champs.get("nom_logiciel", ""),
        type_rapport=racine.get("type", ""),
        type_declaration=champs.get("type", ""),
        fraction=champs.get("fraction", ""),
        ordre=champs.get("ordre", ""),
        salaries=champs.get("salaries", ""),
        contrats=champs.get("contrats", ""),
        conformite=champs.get("etat_conformite", ""),
        # LA piece. C'est lui qui << libere de ses obligations declaratives >>,
        # et c'est donc lui qu'on garde en clair dans la ligne de journal --
        # pas un resume de notre facon.
        certificat=champs.get("certificat_conformite", ""),
        siret_declarant=champs.get("siret", ""),
    )


def anomalies_du_bilan(contenu) -> list[str]:
    """Les motifs d'un bilan d'anomalies (BAN), en phrases lisibles.

    << Code URSSAF invalide -- PUPPIS >> vaut mieux que << KO >> : c'est le
    motif qui dit quoi corriger. Chaque anomalie porte sa categorie, son
    message et, quand il y en a un, le salarie concerne.
    """
    import xml.etree.ElementTree as ET
    try:
        racine = ET.fromstring(contenu if isinstance(contenu, bytes)
                               else str(contenu).encode("utf-8"))
    except ET.ParseError:
        return []
    out = []
    for a in racine.iter():
        if _localname(a.tag) != "declaration_anomalie":
            continue
        message = categorie = nom = ""
        for e in a.iter():
            n = _localname(e.tag)
            if n == "message":
                message = (e.text or "").strip()
            elif n == "categorie":
                categorie = (e.text or "").strip()
            elif n == "nom_famille":
                nom = (e.text or "").strip()
        if message:
            out.append("%s%s%s" % (message,
                                   " (%s)" % categorie if categorie else "",
                                   " -- %s" % nom if nom else ""))
    return out


def fusionner_bilans(bilans: list) -> "BilanDepot | None":
    """Un seul bilan par flux, le plus complet.

    Un meme depot rend souvent DEUX rapports : l'accuse (10) tout de suite, le
    certificat (11) juste apres. Le second sait tout ce que le premier sait,
    et davantage -- mois, logiciel, conformite. On part donc du plus riche et
    on ne complete que ce qui lui manque, au lieu de choisir l'un des deux :
    un accuse sans certificat reste exploitable, et un certificat sans accuse
    aussi.
    """
    if not bilans:
        return None
    # LE BILAN DE DECLARATION L'EMPORTE SUR L'ACCUSE DE TRANSPORT, et c'est
    # tout l'interet de cette fonction. CCO et BAN sont a EGALITE devant AEE :
    # ranger BAN apres AEE -- ce que faisait la premiere version -- laissait
    # l'accuse << OK >> recouvrir le rejet, et deux depots refuses passaient
    # pour faits. Un meme flux ne rend jamais un CCO et un BAN a la fois.
    ordre = {"CCO": 0, "BAN": 0, "AEE": 1}
    tries = sorted(bilans, key=lambda b: ordre.get(b.type_rapport, 2))
    base = replace(tries[0])
    for autre in tries[1:]:
        for champ in ("recu_le", "essai_reel", "etat_envoi", "etat_declaration",
                      "mois", "logiciel",
                      "type_declaration", "fraction", "ordre", "salaries",
                      "contrats", "conformite", "certificat",
                      "siret_declarant"):
            if not getattr(base, champ):
                setattr(base, champ, getattr(autre, champ))
    return base


# ------------------------------------------------------- reponses de recherche
def _localname(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_liste_retours(contenu: bytes | str) -> list[dict]:
    """Reponse de lister-retours-declarant / -flux, en XML (1.0) ou JSON (2.0).

    Structure documentee : retours > flux[@id] > retour{publication, production,
    nature, statut, id, url, ops, delegataire}.
    """
    if isinstance(contenu, bytes):
        contenu = contenu.decode("utf-8", "replace")
    texte = contenu.strip()
    if texte.startswith("{"):
        return _liste_retours_json(json.loads(texte))
    racine = ET.fromstring(texte)
    out = []
    for flux in racine.iter():
        if _localname(flux.tag) != "flux":
            continue
        idf = flux.get("id") or _texte_enfant(flux, "id")
        for r in flux:
            if _localname(r.tag) != "retour":
                continue
            e = {_localname(c.tag): (c.text or "").strip() for c in r}
            e["flux"] = idf
            out.append(e)
    return out


def _texte_enfant(el, nom: str) -> str | None:
    for c in el:
        if _localname(c.tag) == nom:
            return (c.text or "").strip()
    return None


def _liste_retours_json(d: dict) -> list[dict]:
    out = []
    racine = d.get("retours", d)
    flux = racine.get("flux", [])
    if isinstance(flux, dict):
        flux = [flux]
    for f in flux:
        idf = f.get("id")
        retours = f.get("retour", [])
        if isinstance(retours, dict):
            retours = [retours]
        for r in retours:
            out.append(dict(r, flux=idf))
    return out


def parse_liste_depots(contenu: bytes | str) -> list[dict]:
    """Reponse de lister-depots : depots > declarant > depot{idflux, date, statut}."""
    if isinstance(contenu, bytes):
        contenu = contenu.decode("utf-8", "replace")
    texte = contenu.strip()
    if texte.startswith("{"):
        d = json.loads(texte)
        decl = d.get("depots", d).get("declarant", {})
        depots = decl.get("depot", [])
        if isinstance(depots, dict):
            depots = [depots]
        return list(depots)
    racine = ET.fromstring(texte)
    out = []
    for el in racine.iter():
        if _localname(el.tag) == "depot":
            out.append({_localname(c.tag): (c.text or "").strip() for c in el})
    return out


# ----------------------------------------------------------- CRM 94 : taux PAS
RUBRIQUES_PAS = {
    "S21.G00.50.006": "taux",
    "S21.G00.50.007": "type",
    "S21.G00.50.008": "identifiant",
}

# Noms metier NEODeS des memes rubriques (cahier technique 2026.1, p. 244)
NOMS_METIER = {
    "tauxpas": "taux",
    "typetauxpas": "type",
    "idtauxpas": "identifiant",
}

_NIR = re.compile(r"^[12][0-9]{12}([0-9]{2})?$")


def _plat(xml: str) -> list[tuple[str, dict, str]]:
    """(nom local, attributs, texte) pour chaque element, dans l'ordre du document."""
    racine = ET.fromstring(xml)
    return [(_localname(e.tag), dict(e.attrib), (e.text or "").strip())
            for e in racine.iter()]


def extraire_taux_pas(contenu: bytes | str) -> dict:
    """Extrait les taux de PAS d'un CRM de nature 94.

    Renvoie {"strategie": ..., "releves": [{nir, taux, type, identifiant}, ...]}.
    La strategie dit COMMENT la donnee a ete reconnue ; elle doit etre affichee,
    pour qu'un format inattendu se voie au lieu de passer pour un succes.

    La premiere strategie correspond au format REEL, observe sur le CRM du
    19/08/2026. Les suivantes sont des filets, gardees au cas ou le format
    changerait ; « balayage large » est volontairement grossier et ne doit
    jamais etre pris pour un succes sans relecture.
    """
    if isinstance(contenu, bytes):
        contenu = contenu.decode("utf-8", "replace")
    for nom, fn in (("rapport CRM nominatif", _pas_rapport_crm),
                    ("rubriques codees", _pas_par_code),
                    ("noms metier NEODeS", _pas_par_nom_metier),
                    ("balayage large", _pas_par_balayage)):
        releves = fn(contenu)
        if releves:
            return {"strategie": nom, "releves": releves}
    return {"strategie": None, "releves": []}


def _nouvelle_entree() -> dict:
    return {"nir": None, "taux": None, "type": None, "identifiant": None}


def _complete(e: dict) -> bool:
    return e["identifiant"] is not None and e["nir"] is not None


def _pas_rapport_crm(xml: str) -> list[dict]:
    """Le format reel du CRM 94, releve sur le retour du 19/08/2026.

        <ns2:rapport identifiant="450189378" type="CRM nominatif" version="v02r01">
          ...
          <salarie>
            <NIR>1880275999999</NIR>
            <matricule>2</matricule>
            <taux_imposition_PAS>0.00</taux_imposition_PAS>
          </salarie>

    Deux choses a ne pas confondre :

    - l'identifiant est un ATTRIBUT DE LA RACINE. C'est celui du compte-rendu,
      pas celui d'un salarie : tous les salaries du meme CRM le partagent. C'est
      ce qui explique l'historique - un salarie non declare un mois ne recoit
      pas de CRM neuf et garde donc l'identifiant du precedent, d'ou les
      divergences d'avril et mai 2026 ;
    - le `matricule` (1, 2...) est le numero interne du salarie. Il ne va nulle
      part dans la DSN. Le premier parseur ecrit a l'aveugle l'avait pris pour
      l'identifiant : c'est exactement le genre d'erreur que l'annonce de la
      strategie sert a rendre visible.

    Le type de taux n'est pas porte par le CRM. Il se deduit : un taux
    communique, c'est « 01 - Taux transmis par la DGFIP ». A defaut, le rapport
    le dit lui-meme -- « le taux applicable est le taux issu des grilles de taux
    par defaut definies par la loi de finances » --, soit le bareme, type 13, et
    l'identifiant ne s'applique plus.
    """
    try:
        racine = ET.fromstring(xml)
    except ET.ParseError:
        return []
    if _localname(racine.tag) != "rapport":
        return []
    identifiant = racine.get("identifiant")
    if not identifiant:
        return []
    releves = []
    for el in racine.iter():
        if _localname(el.tag) != "salarie":
            continue
        champs = {_localname(c.tag): (c.text or "").strip() for c in el}
        nir = champs.get("NIR")
        if not nir:
            continue
        taux = champs.get("taux_imposition_PAS")
        if taux:
            releves.append({"nir": nir, "taux": taux, "type": "01",
                            "identifiant": identifiant})
        else:
            # Pas de taux DGFiP : bareme par defaut, et .008 sans objet.
            releves.append({"nir": nir, "taux": "0.00", "type": "13",
                            "identifiant": "-1"})
    return releves


def _pas_par_code(xml: str) -> list[dict]:
    """Le retour porte les codes de rubrique DSN, en attribut ou en texte.

    <rubrique code="S21.G00.50.008">444207754</rubrique>  ou
    <donnee><code>S21.G00.50.008</code><valeur>444207754</valeur></donnee>
    """
    elements = _plat(xml)
    if not any("S21.G00.50.008" in (str(a) + t)
               for _, attribs, t in elements
               for a in [attribs]):
        return []
    releves, cur = [], _nouvelle_entree()
    attente = None
    for nom, attribs, texte in elements:
        valeurs = list(attribs.values()) + [texte]
        for v in valeurs:
            if _NIR.match(v or ""):
                if _complete(cur):
                    releves.append(cur)
                    cur = _nouvelle_entree()
                cur["nir"] = v[:13]
        for v in valeurs:
            if v in RUBRIQUES_PAS:
                attente = RUBRIQUES_PAS[v]
                # forme attribut : la valeur est dans le texte du meme element
                if texte and texte not in RUBRIQUES_PAS:
                    cur[attente] = texte
                    attente = None
                break
        else:
            if attente and texte:
                cur[attente] = texte
                attente = None
        if _complete(cur) and cur["taux"] is not None and cur["type"] is not None:
            releves.append(cur)
            cur = _nouvelle_entree()
    if _complete(cur):
        releves.append(cur)
    return [r for r in releves if _complete(r)]


def _pas_par_nom_metier(xml: str) -> list[dict]:
    """Le retour nomme les balises comme le cahier technique : TauxPAS, IdTauxPAS."""
    elements = _plat(xml)
    if not any(_localname(n).lower() in NOMS_METIER for n, _, _ in elements):
        return []
    releves, cur = [], _nouvelle_entree()
    for nom, attribs, texte in elements:
        bas = nom.lower()
        for v in list(attribs.values()) + [texte]:
            if _NIR.match(v or ""):
                if _complete(cur):
                    releves.append(cur)
                    cur = _nouvelle_entree()
                cur["nir"] = v[:13]
        if bas in NOMS_METIER and texte:
            champ = NOMS_METIER[bas]
            if cur[champ] is not None:
                releves.append(cur)
                cur = dict(_nouvelle_entree(), nir=cur["nir"])
            cur[champ] = texte
    if _complete(cur):
        releves.append(cur)
    return [r for r in releves if _complete(r)]


def _pas_par_balayage(xml: str) -> list[dict]:
    """Dernier recours : un NIR, puis un taux, un type a deux chiffres, un entier.

    Volontairement grossier. Sert a ne pas rentrer les mains vides d'un format
    inattendu, et a montrer ce qui a ete vu pour qu'un humain tranche.
    """
    elements = _plat(xml)
    valeurs = [v for _, attribs, texte in elements
               for v in list(attribs.values()) + [texte] if v]
    releves, cur = [], _nouvelle_entree()
    for v in valeurs:
        if _NIR.match(v):
            if _complete(cur):
                releves.append(cur)
            cur = _nouvelle_entree()
            cur["nir"] = v[:13]
        elif cur["nir"]:
            if cur["taux"] is None and re.fullmatch(r"[0-9]{1,2}\.[0-9]{2}", v):
                cur["taux"] = v
            elif cur["type"] is None and v in (
                    "01", "13", "17", "23", "27", "33", "37", "99"):
                cur["type"] = v
            elif cur["identifiant"] is None and re.fullmatch(r"-1|[0-9]{1,18}", v):
                cur["identifiant"] = v
    if _complete(cur):
        releves.append(cur)
    return [r for r in releves if _complete(r)]


def releves_vers_salaries(ctx, releves: list[dict]) -> tuple[list[dict], list[dict]]:
    """Rattache chaque releve a une fiche salarie par le NIR.

    Renvoie (rattaches, orphelins). Un NIR inconnu n'est jamais devine.
    """
    par_nir = {s["nir"]: cle for cle, s in ctx.salaries.items()}
    ok, orphelins = [], []
    for r in releves:
        cle = par_nir.get((r.get("nir") or "")[:13])
        if cle:
            ok.append(dict(r, salarie=cle))
        else:
            orphelins.append(r)
    return ok, orphelins


# ------------------------------------------------- fiches de parametrage OC
def parse_fiche_parametrage(contenu: bytes | str) -> dict:
    """Fiche de parametrage OC (Audiens) : les taux contractuels et leurs dates.

    C'est la table que `reference/veille-taux.md` disait inexistante. Elle donne,
    par groupe de population et par periode de validite, le taux attendu par
    l'organisme complementaire - dont la prevoyance intermittents.
    """
    if isinstance(contenu, bytes):
        contenu = contenu.decode("latin-1", "replace")
    racine = ET.fromstring(contenu)
    prod = racine.find("ProducteurFiche")
    out = {
        "identifiant": racine.get("IdentifiantFiche"),
        "version": racine.get("Version"),
        "creee_le": racine.get("DateHeureCreation"),
        "producteur": prod.get("RaisonSocialeProducteur") if prod is not None else None,
        "groupes": [],
    }
    for g in racine.iter("GROUPE"):
        groupe = {"numero": g.get("NumeroGrp"), "libelle": g.get("LibelleGrp"),
                  "contrats": []}
        for pc in g.findall("ParametresContrats"):
            c = pc.find("Contrat")
            taux = []
            ec = pc.find("ElementsDeCalculAttendus")
            for el in (ec if ec is not None else []):
                for enfant in el:
                    if _localname(enfant.tag) == "Taux" and enfant.text:
                        taux.append({
                            "assiette": el.tag,
                            "nature": el.get("LibelleCodeNature"),
                            "taux": enfant.text.strip(),
                        })
            groupe["contrats"].append({
                "debut": pc.get("DateDebutValidite"),
                "fin": pc.get("DateFinValidite"),
                "libelle": c.get("LibelleContrat") if c is not None else None,
                "reference": c.get("ReferenceContrat") if c is not None else None,
                "taux": taux,
            })
        out["groupes"].append(groupe)
    return out
