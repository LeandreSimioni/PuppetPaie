"""Les referentiels livres avec le logiciel : metiers, rubriques, sources.

Ce que les deux faces proposent dans un deroulant, et ce que la compagnie y
coche. Les catalogues eux-memes sont des fichiers de donnees du moteur
(`emplois-base.json`, `rubriques-base.json`, `sources.json`) ; ici on les
lit dans l'ordre ou les proposer, et on enregistre la preference.
"""
from __future__ import annotations

import json

from . import emplois as _emplois
from .contexte import Contexte
from .operations_socle import ErreurOperation, _lire_json, _sauver_avant


# -------------------------------------------------------------------- metiers
def metiers(ctx: Contexte, tous: bool = False) -> list:
    """Le catalogue des metiers, pret pour un deroulant ou une commande.

    Groupe par famille dans l'ordre de `emplois.familles()` : les artistes en
    tete, parce que c'est le cas de presque toutes les paies de la compagnie.
    `tous` ajoute la nomenclature France Travail entiere en fin de liste.
    """
    ordre = {f: i for i, f in enumerate(_emplois.familles())}
    liste = _emplois.catalogue(tous=tous)
    liste.sort(key=lambda m: (ordre.get(m["famille"], len(ordre)), m["libelle"].lower()))
    return liste


def sources(ctx: Contexte, verifier: bool = False, relever: bool = False) -> list:
    """Les sources des donnees livrees, et -- avec `verifier` -- leur etat en
    ligne. Rend des dictionnaires : les deux faces affichent, elles ne
    decident pas ce qu'il faut relire."""
    from . import sources as _sources
    from dataclasses import asdict
    liste = _sources.verifier(ctx, relever=relever) if verifier else _sources.etats(ctx)
    return [asdict(e) for e in liste]


# ------------------------------------------------------------------ rubriques
def rubriques(ctx: Contexte, actives_seulement: bool = False) -> list:
    """Le catalogue qui PAIE, dans l'ordre ou le proposer.

    C'est `moteur/rubriques-base.json` -- construit depuis les textes, chaque
    rubrique portant sa source -- augmente de ce que la compagnie a ajoute et
    trie selon ce qu'elle a coche. Ce n'est PAS `config/rubriques.json`, la
    copie de CoolPaie : celle-la sert a comprendre et a verifier, pas a payer.

    `actives_seulement` ne garde que les rubriques cochees : c'est ce que la
    liste deroulante de la saisie propose en premier rang.
    """
    from . import catalogue as cat
    out = []
    for r in cat.catalogue(ctx):
        if actives_seulement and not r.active:
            continue
        out.append({
            "code": r.code, "libelle": r.libelle, "unite": r.unite,
            "nature": r.nature, "saisie": list(r.saisie), "sens": r.sens,
            "heures_forfait": r.heures_forfait, "plafond": r.plafond,
            "aem": r.aem, "dsn_type": r.dsn_type,
            "dsn_autres_bruts": r.dsn_autres_bruts, "annexe": r.annexe,
            "soumis": r.soumis, "imposable": r.imposable,
            "conges_spectacles": r.conges_spectacles,
            "compte_pour": r.compte_pour,
            "plafond_mensuel": r.plafond_mensuel,
            "plafond_annuel_heures": r.plafond_annuel_heures,
            "origine": r.origine, "active": r.active, "usages": r.usages,
            "source": r.source})
    return out



def choisir_rubriques(ctx: Contexte, actives: list) -> list:
    """Cocher les rubriques que la compagnie veut voir dans le deroulant.

    « On clique les rubriques que l'on veut voir apparaitre dans le deroulant
    et il met la plus utilisee en premier. » Les compteurs d'usage ne sont pas
    touches ici : ils s'incrementent quand une rubrique sert vraiment, pas
    quand on la coche.

    Une rubrique inconnue est refusee plutot qu'ignoree : une faute de frappe
    dans un code produirait une liste qui ne propose pas ce qu'on croit.
    """
    from . import catalogue as cat
    connus = {r.code for r in cat.catalogue(ctx)}
    inconnues = [c for c in actives if c not in connus]
    if inconnues:
        raise ErreurOperation(
            "Rubrique(s) inconnue(s) : %s. Connues : %s."
            % (", ".join(inconnues), ", ".join(sorted(connus))))
    p = ctx.racine / "config" / "rubriques-actives.json"
    donnees = _lire_json(p) if p.exists() else {}
    donnees["actives"] = list(dict.fromkeys(actives))
    donnees.setdefault("usages", {})
    donnees["_quoi"] = (
        "Les rubriques que cette compagnie a cochees, et combien de fois "
        "chacune a servi. Preference d'affichage : cela change l'ordre du "
        "deroulant de saisie, jamais un calcul. Le catalogue lui-meme est "
        "livre avec le logiciel (moteur/rubriques-base.json).")
    p.parent.mkdir(parents=True, exist_ok=True)
    _sauver_avant(p)
    p.write_text(json.dumps(donnees, ensure_ascii=False, indent=2) + "\n",
                 encoding="utf-8")
    return rubriques(ctx)
