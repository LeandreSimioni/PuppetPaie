"""Le journal des depots : ce qu'un fichier produit est DEVENU.

Jusqu'ici le logiciel savait fabriquer une DSN et savait la deposer, mais il
ne savait pas dire si elle etait partie. Le dossier `sorties/` ne repond pas a
la question : un `.dsn` sur le disque a exactement la meme tete avant et apres
le depot. Alors on regardait le tableau de bord net-entreprises, ou on se
souvenait -- et §18.8 raconte ce que vaut le souvenir.

D'ou ce fichier, et la seule chose qu'il fait : **ecrire une ligne apres
chaque acte sortant**, et savoir la relire. Un depot DSN, un depot DPAE, un
courriel a un salarie, un contrat envoye a la signature.

CE QU'IL PERMET, ET QUI EST LE VRAI SUJET
-----------------------------------------
Une case « lancer la DPAE » a cote d'une paie n'a de sens que si l'ecran sait
afficher « deja deposee ». Un bouton qui envoie les DPAE des contrats qui
n'ont pas encore ete declares n'a de sens que si l'on sait lesquels. Le
bouton n'est que l'affichage de ce journal -- c'est pour cela qu'il vient
avant lui.

UN DEPOT N'EST PAS FINI QUAND IL EST PARTI
------------------------------------------
La demande : « c'est pas seulement depose mais aussi
recu (le retour) ». Et c'est la bonne maille -- un depot accepte par le point
de depot n'est qu'un accuse de TRANSPORT. Ce qui dit qu'une declaration est
conforme, c'est le certificat de conformite ; ce qui dit que les salaries
sont identifies, c'est le bilan d'identification. Ils arrivent des heures
plus tard, parfois le lendemain.

Chaque ligne porte donc un `flux` -- l'identifiant que le point de depot rend
-- et une liste `retours` que `rattacher_retours` remplit a mesure. Un depot
sans retour n'est pas un depot rate : c'est un depot dont on attend encore la
reponse, et l'ecran doit le dire ainsi.

CE QU'IL N'EST PAS
------------------
Ce n'est pas une preuve. La preuve d'un depot, c'est l'accuse de reception de
l'organisme, et il vit dans `retours/`. Ce journal dit ce que CE logiciel a
fait ; il ignore ce qui est parti par CoolPaie, par le site en saisie directe
ou depuis une autre machine. Il dit donc « je ne l'ai pas envoye », jamais
« il n'est pas parti » -- et l'ecran doit reprendre cette nuance, sous peine
de faire declarer deux fois la meme embauche.

FORME
-----
`prive/journal/depots.json` : une liste, on n'y ajoute qu'a la fin, on n'y
retire rien. Une ligne qui disparait est une ligne qui ment.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
from pathlib import Path
from typing import Optional

from .contexte import Contexte
from .util import quand_lisible

# Les actes que l'on note. Un acte absent de cette liste est refuse : le
# journal se relit par ces cles, et une faute de frappe le rendrait muet sans
# rien casser de visible.
DSN = "dsn"
DPAE = "dpae"
DOCUMENTS = "documents"          # bulletin, certificat CS, AEM au salarie
SIGNATURE = "contrat-signature"  # contrat envoye pour signature
CONTRAT_RECU = "contrat-recu"    # le contrat signe est revenu (clic humain, ou releve)
CONTRESIGNE = "contrat-contresigne"  # le contrat contresigne renvoye au salarie
ACTES = (DSN, DPAE, DOCUMENTS, SIGNATURE, CONTRAT_RECU, CONTRESIGNE)

REEL = "reel"
TEST = "test"


def chemin(ctx: Contexte) -> Path:
    return ctx.racine / "journal" / "depots.json"


def empreinte(contenu) -> str:
    """Ce qui a REELLEMENT ete envoye, resume en 16 caracteres.

    Le nom d'un fichier ne dit rien : `DSN_Aout2026.dsn` peut etre regenere
    dix fois et ne plus rien avoir de commun avec celui qui est parti. Les
    octets, eux, ne mentent pas -- et c'est la seule facon de repondre a
    « est-ce que c'est CE fichier-la qui a ete depose ? ».
    """
    if isinstance(contenu, (str, Path)):
        contenu = Path(contenu).read_bytes()
    return hashlib.sha256(contenu).hexdigest()[:16]


def lire(ctx: Contexte, quoi: Optional[str] = None,
         mois: Optional[str] = None, reel_seulement: bool = False) -> list:
    """Les lignes du journal, les plus recentes en dernier."""
    p = chemin(ctx)
    if not p.exists():
        return []
    lignes = json.loads(p.read_text(encoding="utf-8"))
    if quoi:
        lignes = [l for l in lignes if l.get("quoi") == quoi]
    if mois:
        lignes = [l for l in lignes if l.get("mois") == mois]
    if reel_seulement:
        lignes = [l for l in lignes if l.get("mode") == REEL]
    return lignes


def noter(ctx: Contexte, quoi: str, *, mois: Optional[str] = None,
          fichier=None, mode: str = REEL, qui: str = "?",
          accepte: bool = True, destinataire: str = "", flux: str = "",
          reponse: str = "", trace=None, detail: Optional[dict] = None,
          quand: Optional[str] = None, origine: str = "") -> dict:
    """Ajoute une ligne. Appele APRES l'acte, jamais avant.

    Noter avant serait plus simple a ecrire et faux a lire : un depot qui
    echoue laisserait une ligne disant qu'il a eu lieu, et c'est precisement
    la ligne sur laquelle quelqu'un se fiera pour ne pas recommencer.

    Un echec se note quand meme (`accepte=False`) : « on a essaye, ca a
    casse » est une information, et c'est meme celle qui manque le plus quand
    on reprend le travail le lendemain.

    `quand` ET `origine` : LES DEUX, OU AUCUN DES DEUX.
    ------------------------------------------------
    Une ligne porte normalement l'heure de son ecriture, parce que le logiciel
    ecrit juste apres avoir agi. La reprise du journal (§19.11) fait
    l'inverse : elle note en septembre un depot du 3 septembre, lu dans un
    accuse d'enregistrement. La date DOIT alors etre celle du depot, sans quoi
    le journal raconterait que tout est parti le jour de la reprise.

    Pouvoir dater une ligne, c'est pouvoir en fabriquer une fausse. Le
    garde-fou est donc qu'une date choisie EXIGE de dire d'ou elle vient :
    `origine` nomme la piece (le fichier de retour, par exemple). Une ligne
    datee sans origine est refusee, et une ligne avec origine se lit pour ce
    qu'elle est -- une reconstitution, pas un acte de ce logiciel.
    """
    if quoi not in ACTES:
        raise ValueError("acte inconnu : %r (attendu %s)" % (quoi, ", ".join(ACTES)))
    if quand and not origine:
        raise ValueError(
            "Une ligne datee doit dire d'ou vient sa date : passer `origine`. "
            "Sans ca, rien ne distingue une reprise d'une ligne fabriquee.")
    ligne = {
        "quoi": quoi,
        "quand": quand or _dt.datetime.now().isoformat(timespec="seconds"),
        # Vide : ce logiciel a fait l'acte lui-meme, et l'a note dans la
        # seconde. Rempli : la ligne a ete reconstituee a partir d'une piece,
        # qui est nommee ici. L'ecran doit le dire -- une reprise n'est pas
        # une preuve que NOUS avons depose.
        "origine": origine,
        "mois": mois,
        "fichier": Path(fichier).name if fichier else None,
        "empreinte": empreinte(fichier) if fichier and Path(fichier).exists() else None,
        "mode": mode,
        "qui": qui,
        "accepte": bool(accepte),
        "destinataire": destinataire,
        # L'identifiant que le point de depot rend, et par lequel les retours
        # se rattacheront. Vide quand la reponse ne le porte pas : on ne
        # l'invente pas, et l'ecran dira « retour non rattachable ».
        "flux": flux or "",
        "retours": [],
        # La reponse de l'organisme est parfois longue et parfois bavarde ;
        # on en garde de quoi reconnaitre, le detail vit dans `trace`.
        "reponse": (reponse or "")[:600],
        "trace": str(trace) if trace else None,
        "detail": detail or {},
    }
    p = chemin(ctx)
    p.parent.mkdir(parents=True, exist_ok=True)
    lignes = json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
    lignes.append(ligne)
    p.write_text(json.dumps(lignes, ensure_ascii=False, indent=2) + "\n",
                 encoding="utf-8")
    return ligne


# ----------------------------------------------------- ce que l'ecran demande
def embauches_declarees(ctx: Contexte) -> set:
    """Les embauches que CE logiciel a deja declarees en DPAE, pour de vrai.

    Une embauche s'identifie par (salarie, premier jour) -- et non par le
    numero de contrat, qui se renumerote des que les compteurs avancent
    (§18.14), ni par le nom du fichier, qui se regenere.

    Les depots de TEST n'y sont pas : un test ne declare rien, et l'y mettre
    ferait croire l'embauche faite.
    """
    faites = set()
    for l in lire(ctx, DPAE, reel_seulement=True):
        if not l.get("accepte"):
            continue
        for e in l.get("detail", {}).get("embauches", []):
            faites.add((e.get("salarie"), e.get("debut")))
    return faites


def embauches_declarees_le(ctx: Contexte) -> dict:
    """Comme `embauches_declarees`, mais avec la DATE du depot.

    L'ecran ne dit pas seulement << faite >> : il dit quand. Une DPAE deposee
    le 26 pour un contrat qui commence le 25 est faite ET en retard, et c'est
    la date qui le montre.
    """
    quand = {}
    for l in lire(ctx, DPAE, reel_seulement=True):
        if not l.get("accepte"):
            continue
        for e in l.get("detail", {}).get("embauches", []):
            quand[(e.get("salarie"), e.get("debut"))] = l.get("quand")
    return quand


NATURE_CERTIFICAT_DPAE = "41"    # le retour Urssaf qui prouve qu'une DPAE est passee


def etat_dsn_du_mois(ctx: Contexte, mois: str) -> Optional[dict]:
    """Le dernier depot REEL accepte de DSN pour ce mois, et ou en est son retour.

    {"quand", "fichier", "flux", "passee", "refusee", "anomalies"} -- ou None
    si rien de reel n'est parti. `passee` : un bilan (CCO, nature 11) a dit
    OK ; `refusee` : un bilan a dit KO ; ni l'un ni l'autre : on attend.

    C'est ce qui bloque un second depot (operations.deposer_dsn) : la regle,
    le 12/09/2026 -- << pareil DSN, on attend le retour, et si vraiment on y
    tient, apres un avertissement, on peut renvoyer >>.
    """
    faites = [l for l in lire(ctx, DSN, mois, reel_seulement=True)
              if l.get("accepte")]
    if not faites:
        return None
    l = faites[-1]
    retours = l.get("retours") or []
    verdicts = [(r.get("verdict") or "") for r in retours
                if str(r.get("nature")) == "11"]
    refus = [r for r in retours if (r.get("verdict") or "") == "KO"]
    return {"quand": l.get("quand"), "fichier": l.get("fichier"),
            "flux": l.get("flux"),
            "passee": "OK" in verdicts and not refus,
            "refusee": bool(refus),
            "anomalies": [a for r in refus for a in (r.get("anomalies") or [])],
            # L'AER (nature 46, France Travail) revient quelques heures apres
            # la DSN : c'est elle qui manque aux documents du salarie tant
            # qu'elle n'est pas la.
            "aer_recue": any(str(r.get("nature")) == "46" for r in retours)}


def etat_des_embauches(ctx: Contexte) -> dict:
    """Pour chaque embauche declaree pour de vrai : quand, et ou en est le retour.

    (salarie, premier jour) -> {"quand", "fichier", "passee", "retours"}, sur
    le DERNIER depot reel accepte qui la porte. `passee` est vrai des que ce
    depot a recu le certificat de conformite des DPAE (nature 41) : la DPAE
    est enregistree a l'Urssaf, il n'y a plus rien a faire de notre cote.
    Sinon elle est partie et l'on attend le retour -- ce qui n'est PAS une
    raison de la renvoyer.

    C'est ce qui bloque un second envoi (operations.produire_dpae) : la regle,
    le 12/09/2026, apres avoir depose deux fois les memes embauches a trois
    minutes d'intervalle -- << il faut bloquer le fait d'envoyer la DPAE deux
    fois d'affilee, garder en memoire que c'est deja envoye pour ces paies,
    et dire soit on attend le retour, soit le retour est arrive, la DPAE est
    passee, rien a faire de notre cote >>.
    """
    etat = {}
    for l in lire(ctx, DPAE, reel_seulement=True):
        if not l.get("accepte"):
            continue
        retours = l.get("retours") or []
        # PASSEE des que l'Urssaf a dit oui : le bilan de conformite (nature
        # 11, verdict OK) suffit -- le certificat 41 qui suit dix minutes
        # plus tard le confirme, il ne le decide pas. La demande,
        # devant une pastille orange sous un << bilan OK, aucune anomalie >> :
        # une DPAE acceptee se lit acceptee, pas << en attente >>.
        passee = any(str(r.get("nature")) == NATURE_CERTIFICAT_DPAE
                     or (str(r.get("nature")) == "11"
                         and (r.get("verdict") or "") == "OK")
                     for r in retours)
        # REFUSEE : un bilan a dit KO et aucun certificat n'est venu. C'est
        # la seule embauche << deja partie >> qu'il faut RENVOYER -- apres
        # avoir corrige ce que les motifs disent.
        refus = [r for r in retours if (r.get("verdict") or "") == "KO"]
        refusee = bool(refus) and not passee
        anomalies = [a for r in refus for a in (r.get("anomalies") or [])]
        # LA REFERENCE DE DOSSIER, lue dans le certificat 41 : c'est sous
        # elle que l'Urssaf a enregistre la DPAE, et c'est elle qu'on cite
        # si l'on doit en parler. `deja_existante` : l'Urssaf n'a rien cree
        # parce qu'une DPAE identique existait -- l'embauche est declaree
        # quand meme, par la premiere.
        dossiers = dossiers_urssaf(retours)
        for e in l.get("detail", {}).get("embauches", []):
            cert = next((v for (nom, emb), v in dossiers.items()
                         if emb == e.get("debut")
                         and _meme_nom(e.get("salarie"), nom)), None)
            etat[(e.get("salarie"), e.get("debut"))] = {
                "quand": l.get("quand"), "fichier": l.get("fichier"),
                "passee": passee, "refusee": refusee,
                "anomalies": anomalies, "retours": retours,
                "dossier": (cert or {}).get("dossier") or "",
                "deja_existante": bool((cert or {}).get("deja_existante"))}
    return etat


def contrats_demandes(ctx: Contexte) -> dict:
    """Les (salarie, premier jour) dont le contrat est parti a la signature.

    Meme maille que les embauches, et pour la meme raison : le numero de
    contrat se renumerote (§18.14), le nom de fichier se regenere. Ce qui ne
    bouge pas, c'est qui travaille et a partir de quand.

    Attention a ce que ca ne dit PAS : que le contrat est revenu signe. Le
    journal garde la date de la DEMANDE, et rien de plus -- il n'y a pas de
    service tiers ici, et ce qui revient se range a la main.
    """
    quand = {}
    for l in lire(ctx, SIGNATURE):
        if not l.get("accepte"):
            continue
        for c in l.get("detail", {}).get("contrats", []):
            quand[(c.get("salarie"), c.get("debut"))] = l.get("quand")
    return quand


def contrats_recus(ctx: Contexte) -> dict:
    """Les (salarie, premier jour) dont le contrat SIGNE est revenu, et quand.

    Deux sources, une seule maille. Quelqu'un l'a dit d'un clic en rangeant
    le contrat (operations.contrat_recu) -- c'est le suivi que la demande
    disait le 12/09/2026, << cliquer pour dire contrat signe recu, pour
    pouvoir suivre >>. Ou la releve des signatures l'a lu dans Gmail
    (15/09/2026) : la ligne porte alors `origine: courriel` et la date de
    la signature. La ligne porte `recu` vrai ou faux -- on peut se tromper
    de clic -- et c'est la DERNIERE qui compte pour chaque paie.
    """
    etat = {}
    for l in lire(ctx, CONTRAT_RECU):
        if not l.get("accepte"):
            continue
        d = l.get("detail", {})
        cle = (d.get("salarie"), d.get("debut"))
        etat[cle] = l.get("quand") if d.get("recu") else None
    return {k: v for k, v in etat.items() if v}


def contrats_recus_comment(ctx: Contexte) -> dict:
    """Pour chaque contrat revenu : « courriel » (releve dans Gmail, avec le
    code) ou « main » (un clic humain). L'ecran le dit a cote de la date."""
    etat = {}
    for l in lire(ctx, CONTRAT_RECU):
        if not l.get("accepte"):
            continue
        d = l.get("detail", {})
        etat[(d.get("salarie"), d.get("debut"))] = (
            (d.get("origine") or "main") if d.get("recu") else None)
    return {k: v for k, v in etat.items() if v}


def signatures_attendues(ctx: Contexte, mois: Optional[str] = None) -> list:
    """Les demandes de signature parties avec un code et pas encore revenues.

    Une entree par CODE -- donc par courriel envoye : un salarie a qui deux
    contrats sont partis dans un seul message les signe d'un seul clic, et
    la reponse vaut pour les deux. Une demande dont TOUS les contrats sont
    revenus (contrats_recus, d'un clic ou par courriel) n'est plus attendue ;
    une relance a un nouveau code, et les deux codes restent valables tant
    que le contrat n'est pas revenu.

    Les demandes d'avant le 15/09/2026 n'ont pas de code : elles ne peuvent
    pas revenir par courriel, et ne figurent pas ici.
    """
    recus = contrats_recus(ctx)
    par_code = {}
    for l in lire(ctx, SIGNATURE, mois):
        if not l.get("accepte"):
            continue
        for c in l.get("detail", {}).get("contrats", []):
            code = c.get("code")
            if not code:
                continue
            e = par_code.get(code)
            if e is None:
                fiche = ctx.salaries.get(c.get("salarie"), {}) if hasattr(ctx, "salaries") else {}
                e = par_code[code] = {
                    "code": code, "mois": l.get("mois"), "quand": l.get("quand"),
                    "salarie": c.get("salarie"), "adresse": c.get("adresse", ""),
                    "fichier": c.get("fichier", ""),
                    "envoyes": set(),
                    "prenom": fiche.get("prenom_affichage") or fiche.get("prenom", ""),
                    "nom": "%s %s" % (fiche.get("prenom_affichage") or fiche.get("prenom", ""),
                                      fiche.get("nom_affichage") or fiche.get("nom", c.get("salarie"))),
                    "contrats": []}
            if c.get("message"):
                e["envoyes"].add(c["message"])
            e["contrats"].append({
                "salarie": c.get("salarie"), "debut": c.get("debut"),
                "fin": c.get("fin"), "numero": c.get("numero"),
                "spectacle": c.get("spectacle", "")})
    return [e for e in par_code.values()
            if any((c["salarie"], c["debut"]) not in recus for c in e["contrats"])]


def documents_envoyes(ctx: Contexte, mois: str) -> dict:
    """Les salaries a qui les documents du mois sont partis, et quand.

    A LA MAILLE DU SALARIE ET DU MOIS, pas du contrat -- et ce n'est pas un
    pis-aller, c'est la realite de l'acte : on envoie a quelqu'un ses
    documents DU MOIS, en un seul message, quels que soient ses contrats. Un
    salarie qui a joue trois spectacles en aout recoit un courriel, pas trois.

    L'ecran doit donc le dire a cette maille-la. Afficher << documents
    envoyes >> sur une paie en laissant croire que c'est cette paie-la qui est
    partie serait une precision que le journal n'a pas.
    """
    quand = {}
    for l in lire(ctx, DOCUMENTS, mois):
        if not l.get("accepte"):
            continue
        for s in l.get("detail", {}).get("salaries", []):
            quand[s.get("cle")] = l.get("quand")
    return quand

def etat_du_mois(ctx: Contexte, mois: str) -> dict:
    """Ce qui est parti pour ce mois-la, par acte. Ce que l'ecran affiche.

    Rend, pour chaque acte, la DERNIERE ligne acceptee en mode reel -- c'est
    celle qui repond a « est-ce fait ? ». Les tentatives ratees restent
    lisibles par `lire`, mais elles ne doivent pas faire croire que c'est
    fait.
    """
    etat = {}
    for acte in ACTES:
        faites = [l for l in lire(ctx, acte, mois, reel_seulement=True)
                  if l.get("accepte")]
        etat[acte] = faites[-1] if faites else None
    return etat


def dernieres_du_mois(ctx: Contexte, mois: str, n: int = 3) -> dict:
    """Les `n` dernieres lignes de chaque acte pour ce mois, TESTS COMPRIS.

    `etat_du_mois` repond a << est-ce fait ? >> et ne regarde que le reel.
    Ceci repond a << que s'est-il passe en dernier ? >> -- la question, le
    12/09/2026, apres trois tests : << j'aimerais avoir les derniers retours
    ici >>. Un test refuse ou accepte est une information, et c'est meme
    celle qu'on attend quand on vient de cliquer << Depot de test >>.
    """
    return {acte: lire(ctx, acte, mois)[-n:] for acte in ACTES}


def resume(ligne: Optional[dict], recus: Optional[dict] = None) -> str:
    """Une ligne de journal en une phrase. Ce que l'ecran met sur un bouton.

    Trois etats, et il faut les trois : jamais parti, parti sans reponse,
    parti et repondu. Les confondre ferait passer une declaration en attente
    pour une declaration conforme.

    `recus` : `contrats_recus(ctx)`, pour les lignes de SIGNATURE. Un
    courriel n'a pas de retour d'organisme ; ce qui << revient >>, c'est le
    contrat signe, range a la main. Sans ce croisement, la colonne disait
    << pas encore de retour >> sous des contrats que les fiches montraient
    recus : << pourquoi a droite ils sont pas signes
    alors que j'ai clique dans les fiches ? >>
    """
    if not ligne:
        return "pas encore envoyé"
    quand = quand_lisible(ligne.get("quand"))
    if ligne.get("mode") == TEST:
        quand = "en TEST le " + quand
    retours = ligne.get("retours") or []
    if not ligne.get("accepte"):
        return "envoi du %s refusé au dépôt — %s" % (quand, (ligne.get("reponse") or "")[:120])
    prefixe = "envoyé %s" % (quand if quand.startswith("en TEST") else "le " + quand)
    if ligne.get("quoi") == SIGNATURE:
        contrats = ligne.get("detail", {}).get("contrats") or []
        revenus = [c for c in contrats
                   if (c.get("salarie"), c.get("debut")) in (recus or {})]
        if not contrats:
            return prefixe
        if len(revenus) == len(contrats):
            return prefixe + " — %s" % (
                "revenu signé" if len(contrats) == 1 else "tous revenus signés (%d)" % len(contrats))
        if revenus:
            return prefixe + " — %d contrat%s sur %d revenu%s signé%s" % (
                len(revenus), "s" if len(revenus) > 1 else "", len(contrats),
                "s" if len(revenus) > 1 else "", "s" if len(revenus) > 1 else "")
        return prefixe + " — pas encore revenu signé"
    if ligne.get("quoi") in (DOCUMENTS, CONTRESIGNE):
        return prefixe
    if not retours:
        return prefixe + " — pas encore de retour"
    refus = [r for r in retours if (r.get("verdict") or "") == "KO"]
    if refus and not any(str(r.get("nature")) == NATURE_CERTIFICAT_DPAE
                         for r in retours):
        motifs = [a for r in refus for a in (r.get("anomalies") or [])]
        return "envoyé %s — REFUSÉ%s" % (
            quand if quand.startswith("en TEST") else "le " + quand,
            " : " + " ; ".join(dict.fromkeys(motifs)) if motifs else "")
    certs = [r for r in retours if str(r.get("nature")) == NATURE_CERTIFICAT_DPAE]
    if certs:
        lignes = certs[-1].get("dpae") or []
        dossiers = [l["dossier"] for l in lignes if l.get("enregistree") and l.get("dossier")]
        existantes = [l["nom"] for l in lignes if l.get("deja_existante")]
        fin = " — certificat de conformité reçu : passée"
        if dossiers:
            fin += " (dossier%s %s)" % ("s" if len(dossiers) > 1 else "",
                                        ", ".join(dossiers))
        if existantes:
            fin += " ; déjà existante à l'Urssaf, rien de créé : %s" % ", ".join(existantes)
        return prefixe + fin
    if any(str(r.get("nature")) == "11" and (r.get("verdict") or "") == "OK"
           for r in retours):
        # LE BILAN D'ABORD, et il ne bouge plus : c'est lui qui dit que la
        # DSN est acceptee. Les comptes-rendus des organismes qui arrivent
        # ensuite (Urssaf, France Travail, Audiens, AGIRC-ARRCO...) sont
        # comptes, pas substitues -- le resume affichait << accuse de
        # distribution a l'organisme complementaire >> a la place du
        # certificat, et une DSN conforme se lisait comme un retour
        # quelconque (§19).
        apres = [r for r in retours if str(r.get("nature")) not in ("10", "11")]
        return prefixe + " — bilan OK, aucune anomalie" + (
            " ; %d compte%s-rendu%s d'organismes reçu%s" % (
                len(apres), "s" if len(apres) > 1 else "",
                "s" if len(apres) > 1 else "", "s" if len(apres) > 1 else "")
            if apres else "")
    dernier = retours[-1]
    return "%s — %s" % (prefixe, dernier.get("libelle")
                        or dernier.get("nature") or "retour reçu")


def _archive_du_retour(ctx: Contexte, r: dict, quoi: str):
    """Le fichier archive de ce retour, s'il est la. Nomme par `archiver`."""
    from .netentreprises import dossier_archive
    dossier = dossier_archive(ctx, "dpae" if quoi == DPAE else "")
    flux = (r.get("flux") or "sansflux")[:24]
    for f in sorted(dossier.glob("*_nature%s_%s*" % (r.get("nature"), flux))):
        if f.name != "journal.json":
            return f
    return None


def verdict_du_retour(ctx: Contexte, r: dict, quoi: str, contenu=None) -> dict:
    """Ce que le retour DIT de la declaration -- pas seulement qu'il existe.

    Un accuse (10) ou un bilan (11) porte un etat : OK, ou KO avec des
    motifs. Le 12/09/2026, deux depots de DPAE ont ete refuses en douze
    secondes (<< Code URSSAF invalide >>) et l'ecran a dit << pas encore de
    retour >> pendant une heure, parce que le journal ne lisait pas les
    retours qu'il avait pourtant archives. Rend {} quand le retour n'est
    pas un bilan (le certificat 41 n'a pas de verdict : il EST le verdict).
    """
    from . import retours as _retours
    nature = str(r.get("nature"))
    if nature not in ("10", "11") and not (
            quoi == DPAE and nature == NATURE_CERTIFICAT_DPAE):
        return {}
    if contenu is None:
        f = _archive_du_retour(ctx, r, quoi)
        if f is None:
            return {}
        contenu = f.read_bytes()
    if nature == NATURE_CERTIFICAT_DPAE:
        return _verdict_du_certificat(contenu)
    b = _retours.parse_bilan_depot(contenu)
    if b is None:
        return {}
    return {"verdict": (b.etat_declaration or b.etat_envoi or "").upper(),
            "anomalies": _retours.anomalies_du_bilan(contenu)}


def _verdict_du_certificat(contenu: bytes) -> dict:
    """Ce que dit le certificat de conformite (41), DPAE par DPAE.

    Il ne decide pas qu'une embauche est passee -- le bilan 11 l'a dit avant
    lui -- mais il est le seul a porter la REFERENCE DE DOSSIER sous laquelle
    l'Urssaf a enregistre chaque DPAE, et le seul a dire << deja existante :
    rien n'a ete cree >> (code 98). `dpae` : une entree par enregistrement,
    telle que la rend `dpae.lire_certificat` ; `anomalies` : les codes qui ne
    sont ni << enregistree >> ni << deja existante >>, nommes par le Format
    120 ; `verdict` : KO des qu'il y en a une.
    """
    from . import dpae as _dpae
    try:
        lignes = _dpae.lire_certificat(contenu)
    except Exception:                                          # noqa: BLE001
        return {}
    if not lignes:
        return {}
    anomalies = []
    for l in lignes:
        if l["lot"] not in ("00", "") and l["lot"] in _dpae.CODES_RET_AR_LOT:
            anomalies.append("%s (lot)" % _dpae.CODES_RET_AR_LOT[l["lot"]])
        if not l["enregistree"] and not l["deja_existante"]:
            anomalies.append("%s -- %s" % (l["libelle"], l["nom"]))
    anomalies = list(dict.fromkeys(anomalies))
    return {"verdict": "KO" if anomalies else "OK",
            "anomalies": anomalies,
            "dpae": [{k: l[k] for k in ("nom", "prenom", "embauche", "dossier",
                                        "code", "libelle", "enregistree",
                                        "deja_existante", "formalites")}
                     for l in lignes]}


def _meme_nom(cle: str, nom: str) -> bool:
    """La cle d'une fiche (`PERE-LAHAILLE`) contre le nom d'un certificat."""
    def plat(s):
        return "".join(c for c in (s or "").upper() if c.isalnum())
    return bool(plat(cle)) and plat(cle) == plat(nom)


def dossiers_urssaf(retours: list) -> dict:
    """(nom, embauche) -> la ligne du dernier certificat 41 qui la porte."""
    out = {}
    for r in retours:
        if str(r.get("nature")) != NATURE_CERTIFICAT_DPAE:
            continue
        for l in r.get("dpae") or []:
            out[(l.get("nom"), l.get("embauche"))] = l
    return out


def rattacher_retours(ctx: Contexte, retours: list, contenus: Optional[dict] = None) -> int:
    """Accroche a chaque depot les retours qui lui repondent. Rend le nombre ajoute.

    `contenus` : {(flux, nature, publication): bytes} pour les retours qu'on
    vient de telecharger ; sans lui, le contenu se relit dans l'archive. Le
    verdict (OK/KO et motifs) se pose sur le retour rattache : c'est lui que
    l'ecran lit.

    Le rattachement se fait par le `flux`, et par rien d'autre. On pourrait
    rapprocher par la date -- « ce retour est arrive deux heures apres ce
    depot, ce doit etre lui » -- et ce serait juste neuf fois sur dix. La
    dixieme, l'ecran afficherait « conforme » en face d'une declaration qui ne
    l'est pas. Un depot dont le flux est inconnu reste donc sans retour, et il
    le dit.
    """
    p = chemin(ctx)
    if not p.exists():
        return 0
    lignes = json.loads(p.read_text(encoding="utf-8"))
    par_flux = {}
    for l in lignes:
        if l.get("flux"):
            par_flux.setdefault(l["flux"], []).append(l)
    ajoutes = 0
    for r in retours:
        for l in par_flux.get(r.get("flux") or "", []):
            connus = l.setdefault("retours", [])
            cle = (r.get("nature"), r.get("publication"))
            verdict = verdict_du_retour(
                ctx, r, l.get("quoi"),
                (contenus or {}).get((r.get("flux"), r.get("nature"),
                                      r.get("publication"))))
            existant = next((x for x in connus
                             if (x.get("nature"), x.get("publication")) == cle), None)
            if existant is not None:
                # Deja rattache, mais peut-etre sans verdict (rattache avant
                # le 12/09/2026, ou l'archive n'etait pas encore la) : on le
                # complete, sans compter un retour de plus.
                if verdict and "verdict" not in existant:
                    existant.update(verdict)
                    ajoutes += 1
                continue
            connus.append({"nature": r.get("nature"),
                           **verdict,
                           # LE LIBELLE DEPEND DU CANAL. Les deux services
                           # numerotent leurs retours separement : la nature
                           # 41 n'existe pas en DSN et vaut << certificat de
                           # conformite des DPAE >> a l'Urssaf. Lire la table
                           # de la DSN pour un retour de DPAE affichait
                           # << nature 41 (inconnue de ce moteur) >> sur le
                           # seul retour qui prouve qu'une embauche est
                           # declaree.
                           "libelle": _libelle_nature(r.get("nature"),
                                                      l.get("quoi")),
                           "statut": r.get("statut"),
                           "publication": r.get("publication")})
            ajoutes += 1
    if ajoutes:
        p.write_text(json.dumps(lignes, ensure_ascii=False, indent=2) + "\n",
                     encoding="utf-8")
    return ajoutes


def _libelle_nature(code, acte: str = DSN) -> str:
    if not code:
        return ""
    if acte == DPAE:
        from .dpae_api import NATURES
        return NATURES.get(str(code)) or (
            "nature %s (inconnue du canal DPAE)" % code)
    from .retours import libelle_nature
    return libelle_nature(code)


def flux_de(reponse: str) -> str:
    """L'identifiant de flux, lu dans la reponse du point de depot.

    Les deux formes rencontrees : le XML (`<idflux>...</idflux>`) et le texte
    brut qui porte un identifiant seul. On ne prend que ce qui se reconnait
    sans ambiguite ; le reste rend une chaine vide, et le depot sera note sans
    flux plutot qu'avec un flux invente.
    """
    import re
    if not reponse:
        return ""
    m = re.search(r"<\s*idflux\s*>\s*([^<\s]+)\s*<", reponse, re.I)
    if m:
        return m.group(1)
    m = re.search(r'"idflux"\s*:\s*"([^"]+)"', reponse, re.I)
    if m:
        return m.group(1)
    # La reponse « nue » du point de depot DSN : un identifiant sur une ligne.
    nu = reponse.strip()
    if re.fullmatch(r"[A-Za-z0-9._-]{8,64}", nu):
        return nu
    return ""


def deja_depose(ctx: Contexte, quoi: str, fichier) -> Optional[dict]:
    """La ligne du depot REEL de ce fichier exact, s'il a deja eu lieu.

    Compare les octets, pas le nom : c'est la seule question interessante,
    et c'est celle a laquelle un dossier `sorties/` ne sait pas repondre.
    """
    e = empreinte(fichier)
    for l in reversed(lire(ctx, quoi, reel_seulement=True)):
        if l.get("accepte") and l.get("empreinte") == e:
            return l
    return None
