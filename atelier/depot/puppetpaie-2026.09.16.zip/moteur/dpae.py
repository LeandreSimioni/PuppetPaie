"""DPAE (ex-DUE) - Declaration Prealable A l'Embauche.

Format teletransmission (Format 120) : enregistrements a largeur fixe de 990
caracteres, saut de ligne compris (989 + LF), encodage latin-1. Le fichier se depose sur
net-entreprises.fr (rubrique DPAE), au plus tard dans les 8 jours qui precedent
l'embauche - et au minimum avant le debut du travail.

Comme pour l'AEM, on part d'un enregistrement reel (`gabarits/due_tel_gabarit.txt`)
et on ne remplace que les zones variables.
"""
from __future__ import annotations
import datetime as _dt
from pathlib import Path

from .contexte import GABARITS
from .util import jjmmaaaa, d

GABARIT = GABARITS / "due_tel_gabarit.txt"
LONGUEUR = 990

CHAMPS = {
    # POSITIONS 0-BASED, [debut, fin). Le dessin d'enregistrement officiel
    # (Format 120, `reference/norme-dpae/v5.3_FormatDPAE_EMAIL.pdf`) compte
    # a partir de 1 : sa position 122 est notre 121.
    #
    # LE PIEGE DE L'HORODATAGE, trouve le 12/09/2026 apres quatre refus
    # << Code URSSAF invalide >>. Le gabarit de CoolPaie porte
    # `28082026` `1512` `11` `7…` puis le SIRET, et on y avait lu
    # JJMMAAAAHHMMSS puis le SIRET. Faux : le dessin dit D_CREATION (122-129, JJMMAAAA),
    # H_CREATION (130-133, HHMM), puis **C_URSSAF (134-136)** -- le code de
    # l'Urssaf receptrice, 117 pour l'Ile-de-France -- puis le SIRET a 137.
    # `151211` n'etait pas 15h12m11s : c'etait 15h12 suivi de `11`, les deux
    # premiers chiffres de 117. En ecrivant les secondes, chaque DPAE
    # portait un code Urssaf fait de ses secondes d'envoi : `597`, `427`...
    # Elle ne passait que si l'on deposait a la onzieme seconde.
    #
    # Et `912` en 65-72, ce n'est pas un code Urssaf : c'est N_LG_MESS, la
    # longueur du message hors entete (990 - 77 - 1). Il ne bouge jamais.
    "horodatage":       (121, 133),  # JJMMAAAAHHMM, sans secondes
    "code_urssaf":      (133, 136),  # C_URSSAF, 3 chiffres, annexe II.1
    "nom":              (283, 315),
    "prenom":           (315, 347),
    "nir":              (347, 360),
    "date_naissance":   (360, 368),  # JJMMAAAA
    "lieu_naissance":   (368, 412),
    "date_embauche":    (412, 420),  # JJMMAAAA
    "heure_embauche":   (420, 424),  # HHMM
    "sexe":             (730, 731),  # M / F
    "dept_naissance":   (827, 829),
    "date_fin":         (865, 873),  # JJMMAAAA, fin prevue du CDD
}


# L'heure d'embauche portee par la DPAE quand personne n'en dit d'autre.
# 08h00 (<< l'heure d'embauche de base doit
# etre 0800, pas 1900, et pas besoin de poser la question lors de l'envoi
# >>). L'interface ne la demande plus ; la ligne de commande garde `--heure`.
HEURE_EMBAUCHE = "0800"

def _txt(v: str, largeur: int) -> str:
    return (v or "").upper()[:largeur].ljust(largeur)


def enregistrement(paie, horodatage: _dt.datetime, heure_embauche: str = HEURE_EMBAUCHE,
                   code_urssaf: str = "") -> str:
    gab = GABARIT.read_text(encoding="latin-1")[:LONGUEUR]
    if len(gab) != LONGUEUR:
        raise ValueError("gabarit DUE corrompu (%d != %d)" % (len(gab), LONGUEUR))
    buf = list(gab)
    if code_urssaf:
        a, b = CHAMPS["code_urssaf"]
        v = str(code_urssaf).strip()
        if len(v) != b - a or not v.isdigit():
            raise ValueError("code_urssaf: %r, attendu %d chiffres (annexe II.1)"
                             % (code_urssaf, b - a))
        buf[a:b] = list(v)

    def poser(champ, valeur):
        a, b = CHAMPS[champ]
        v = str(valeur)
        if len(v) != b - a:
            raise ValueError("%s: %r fait %d car., attendu %d" % (champ, v, len(v), b - a))
        buf[a:b] = list(v)

    s, e = paie.salarie, paie.engagement
    sexe = "F" if s["nir"].startswith("2") else "M"
    poser("horodatage", horodatage.strftime("%d%m%Y%H%M"))
    poser("nom", _txt(s["nom"], 32))
    poser("prenom", _txt(s["prenom"], 32))
    poser("nir", s["nir"])
    poser("date_naissance", jjmmaaaa(s["date_naissance"]))
    poser("lieu_naissance", _txt(s["lieu_naissance"], 44))
    poser("date_embauche", jjmmaaaa(e.debut))
    poser("heure_embauche", heure_embauche)
    poser("sexe", sexe)
    poser("dept_naissance", s["departement_naissance"])
    poser("date_fin", jjmmaaaa(e.fin))
    return "".join(buf)


def ecrire(paies: list, chemin, horodatage=None, heure_embauche: str = HEURE_EMBAUCHE,
           zipper: bool = True, code_urssaf: str = "") -> Path:
    """Un enregistrement par contrat, groupes par salarie comme le faisait CoolPaie.

    Ecrit aussi le .zip du meme nom : net-entreprises accepte les deux, et
    CoolPaie deposait le zip.
    """
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    h = horodatage or _dt.datetime.now()
    data = "".join(enregistrement(p, h, heure_embauche, code_urssaf) for p in paies)
    chemin.write_bytes(data.encode("latin-1"))
    if zipper:
        import zipfile
        with zipfile.ZipFile(chemin.with_suffix(chemin.suffix + ".zip"), "w",
                             zipfile.ZIP_DEFLATED) as z:
            z.write(chemin, chemin.name)
    return chemin


def recapitulatif(paies: list, heure_embauche: str = HEURE_EMBAUCHE) -> str:
    """Texte a recopier si l'on prefere la saisie en ligne sur net-entreprises."""
    heure = "%sh%s" % (heure_embauche[:2], heure_embauche[2:])
    lignes = ["DPAE - a declarer avant le debut de chaque contrat", ""]
    for p in paies:
        s, e = p.salarie, p.engagement
        lignes += [
            "%s %s - ne(e) le %s a %s (%s)" % (
                s["nom"], s["prenom"], d(s["date_naissance"]).strftime("%d/%m/%Y"),
                s["lieu_naissance"], s["departement_naissance"]),
            "  NIR %s%s" % (s["nir"], s["nir_cle"]),
            "  Embauche le %s a %s, fin prevue le %s" % (
                d(e.debut).strftime("%d/%m/%Y"), heure,
                d(e.fin).strftime("%d/%m/%Y")),
            "  Emploi : %s - CDD d'usage - %s" % (s["emploi"], p.spectacle["titre"]),
            "",
        ]
    return "\n".join(lignes)


def _enregistrements(contenu: bytes) -> list:
    """Les enregistrements d'un flux DPAE, 990 caracteres chacun.

    Le Format 120 dit << 990 en incluant le saut de ligne >> : 989 caracteres
    puis LF. C'est ce que porte le gabarit de CoolPaie, ce qu'on emet, et ce
    que l'Urssaf renvoie dans le certificat de conformite (nature 41). On a
    longtemps decrit ce fichier comme << colle bout a bout sans separateur
    >> : le separateur est la, c'est le 990e caractere. Un CRLF ou un flux
    reellement colle se lisent aussi ; le decoupage se fait sur le LF quand
    chaque morceau fait 989 ou 990, en largeur fixe sinon.
    """
    b = contenu.decode("latin-1").replace("\r\n", "\n")
    morceaux = [l for l in b.split("\n") if l.strip()]
    if morceaux and all(len(l) in (LONGUEUR - 1, LONGUEUR) for l in morceaux):
        return [(l + " " * LONGUEUR)[:LONGUEUR] for l in morceaux]
    return [b[i * LONGUEUR:(i + 1) * LONGUEUR] for i in range(len(b) // LONGUEUR)]


def relire(chemin) -> list:
    return [{k: r[a:z] for k, (a, z) in CHAMPS.items()}
            for r in _enregistrements(Path(chemin).read_bytes())]


# ---------------------------------------------------- ce que l'Urssaf repond
# Les codes retour du Format 120 (onglet << Codes retour >>, v5.3 du
# 13/06/2013), recopies du PDF le 13/09/2026. L'Urssaf les rend a deux
# endroits : dans le bilan de conformite (nature 11, XML, <code>02</code>),
# et dans le certificat de conformite (nature 41), qui est NOTRE enregistrement
# renvoye avec ses zones de retour remplies.
CODES_RET_AR_LOT = {           # C_RET_AR_LOT, 76-77 : le traitement du message
    "00": "Correct",
    "11": "Code version incorrect",
    "15": "Longueur du message incorrecte",
}
CODES_RETOUR_AR = {            # C_RETOUR_AR, 430-431 : chaque DPAE
    "00": "DPAE enregistrée",
    "01": "SIRET invalide - syntaxiquement incorrect",
    "02": "Code URSSAF invalide - n'appartenant pas à la liste des codes Urssaf",
    "03": "Code APE invalide - n'appartenant pas à la liste des codes APE (NAF)",
    "05": "Nom ou raison sociale invalide - non renseignée ou caractères interdits",
    "06": "Adresse invalide - non renseignée",
    "07": "Code postal invalide - ne comportant pas 5 caractères numériques",
    "08": "Commune invalide - non renseignée",
    "11": "Code origine application incorrect",
    "12": "Code origine saisie invalide - non renseigné",
    "31": "Nom salarié invalide - non renseigné",
    "32": "Prénom salarié invalide - non renseigné",
    "33": "Date de naissance salarié invalide - invraisemblable ou non renseignée",
    "34": "Lieu de naissance invalide - non renseigné",
    "35": "Date et/ou heure d'embauche invalide - invraisemblable ou non renseignée",
    "38": "Numéro de sécurité sociale invalide - invraisemblable, département inexistant…",
    "39": "Date de déclaration invalide - invraisemblable ou non renseignée",
    "40": "Heure de déclaration invalide - invraisemblable ou non renseignée",
    "43": "Sexe du salarié invalide - différent de M ou F, ou non renseigné",
    "44": "Type de contrat invalide - différent de 1, 2 ou 3, ou non renseigné",
    "45": "Code NAF invalide pour le type de contrat CTT",
    "46": "Date de fin de CDD obligatoire pour un CDD, ou invalide (antérieure à l'embauche…)",
    "47": "Département de naissance invalide - non renseigné",
    "50": "Code médecine du travail invalide - non renseigné",
    "98": "DPAE déjà existante (nom, prénom, date de naissance, date et heure d'embauche, SIRET)",
    "99": "Autre erreur (données facultatives)",
}
# ENREGISTREE, EN PRATIQUE : `00` ou `99` avec une reference de dossier. Le
# `99` (<< autre erreur, donnees facultatives >>) est ce que porte CHAQUE
# certificat recu depuis juin 2026, ceux de CoolPaie compris (juin, juillet,
# aout, 4/09 : 16 enregistrements sur 16), toujours avec un R_DOSSIER et les
# formalites CERTIF et MT levees. C'est l'etat nominal de ce service, pas une
# anomalie a corriger ; le tableau de 2013 est plus severe que le SI.
# Le `98` dit qu'une DPAE identique existait deja : rien n'a ete cree, et les
# formalites restent a N -- vu le 12/09/2026 sur le second TEST des memes
# embauches. L'embauche est declaree quand meme, par la premiere.
CODES_ENREGISTREE = ("00", "99")
CODE_DEJA_EXISTANTE = "98"

ZONES_RETOUR = {
    # 0-based, [debut, fin). Positions du Format 120 moins un.
    "ret_ar_lot":   (75, 77),      # C_RET_AR_LOT
    "dossier":      (424, 429),    # R_DOSSIER, la reference sous laquelle la DPAE est enregistree
    "retour_ar":    (429, 431),    # C_RETOUR_AR
    "certif":       (970, 971),    # I_CERTIF : donnees transmises pour la DADS (CRAM)
    "imma":         (973, 974),    # I_IMMA : demande d'immatriculation (CPAM)
    "mt":           (974, 975),    # I_MT : medecine du travail informee
    "pmf5":         (975, 976),    # I_PMF5 : premiere embauche dans l'etablissement (CFE-Urssaf)
}
FORMALITES = {"certif": "CERTIF", "imma": "IMMA", "mt": "MT", "pmf5": "PMF5"}


def lire_certificat(contenu: bytes) -> list:
    """Le certificat de conformite (nature 41), DPAE par DPAE.

    Rend, par enregistrement : `nom`, `prenom`, `nir`, `embauche` (AAAA-MM-JJ),
    `dossier` (R_DOSSIER), `code` et `libelle` (C_RETOUR_AR, Format 120),
    `enregistree` (00 ou 99 avec un dossier), `deja_existante` (98),
    `formalites` (celles a O : CERTIF, IMMA, MT, PMF5), `lot` (C_RET_AR_LOT).
    """
    out = []
    for r in _enregistrements(contenu):
        z = {k: r[a:b].strip() for k, (a, b) in ZONES_RETOUR.items()}
        c = {k: r[a:b].strip() for k, (a, b) in CHAMPS.items()}
        emb = c.get("date_embauche") or ""
        code = z["retour_ar"] or "00"
        out.append({
            "nom": c.get("nom", ""), "prenom": c.get("prenom", ""),
            "nir": c.get("nir", ""),
            "embauche": ("%s-%s-%s" % (emb[4:], emb[2:4], emb[:2])
                         if len(emb) == 8 else ""),
            "dossier": z["dossier"],
            "code": code,
            "libelle": CODES_RETOUR_AR.get(code, "code %s (inconnu du Format 120)" % code),
            "enregistree": code in CODES_ENREGISTREE and bool(z["dossier"]),
            "deja_existante": code == CODE_DEJA_EXISTANTE,
            "formalites": [FORMALITES[k] for k in FORMALITES if z[k] == "O"],
            "lot": z["ret_ar_lot"] or "00",
        })
    return out
