"""Envoi aux salaries : un message par salarie et par mois.

Bulletin, certificat d'emploi Conges Spectacles et attestation France Travail,
dans un seul message. C'est la demande : « on fera un
mail complet avec tout -- BS, CS et AEM -- le tout edite par nous. »

L'AEM N'EST PLUS LA TROISIEME PIECE -- 10/09/2026
-------------------------------------------------
La compagnie est passee en 100 % DSN le 01/06/2026. Nous n'emettons plus
d'AEM, donc plus d'AEM papier : la piece qui compte pour France Travail est
desormais l'AER Cinema Spectacle, que France Travail edite lui-meme a partir
de notre DSN et nous renvoie en retour de nature 46.

Consequence pour ce module : la troisieme piece n'est plus ECRITE par nous au
moment de la production, elle est RECUE plus tard. Elle peut donc manquer le
jour ou l'on prepare les messages -- `preparer` le dit alors au salarie au
lieu de faire comme si de rien n'etait.

CE QUI PART N'EST JAMAIS LE FICHIER GROUPE
------------------------------------------
`python -m moteur mois` produit un `Bulletins_<Mois><Annee>.pdf` qui contient
**tous** les salaries. L'envoyer a l'un d'eux lui donnerait la paie des autres.
Les pieces jointes viennent donc de `sorties/<mois>/envoi/`, ou chaque document
est ecrit salarie par salarie, avec les memes numeros -- meme numero de
bulletin, meme N° CE, meme numero d'attestation -- et donc le meme contenu que
le fichier groupe archive.

RIEN NE PART SANS UN CLIC
-------------------------
Le module ne sait pas envoyer tout seul depuis la production du mois : c'est
une action sortante et irreversible, elle a sa propre commande. `moteur envoi`
prepare les messages, ouvre le navigateur sur une page servie en local, et
attend. Trois garde-fous, les memes que pour le depot DSN :

* le serveur n'ecoute que sur **127.0.0.1**, sur un port libre tire au hasard,
  et l'URL porte un **jeton a usage unique** : une autre application de la
  machine ne peut pas declencher l'envoi ;
* **la page de relecture est le garde-fou** : chaque message y est affiche en
  entier, chaque piece jointe s'ouvre d'un clic, et un `confirm()` separe la
  lecture de l'envoi ;
* aucun enchainement automatique : `mois` ne lance jamais `envoi`.

PLUS DE BROUILLON, PLUS DE SMTP -- 09/09/2026
---------------------------------------------
La premiere version deposait les messages dans les brouillons Gmail par IMAP,
avec un mot de passe d'application, et envoyait par SMTP. Les deux ont ete
remplaces par l'API Gmail sur compte autorise (`moteur/google.py`), pour deux
raisons :

* le brouillon exige la permission `gmail.compose`, que Google classe
  **restreinte** -- audit de securite CASA obligatoire le jour ou le logiciel
  serait diffuse. L'envoi seul n'exige que `gmail.send`, classe sensible ;
* le brouillon faisait doublon avec la page de relecture, qui montre deja tout
  avant que quoi que ce soit ne parte.

Il n'y a donc plus de mot de passe du tout ici : l'autorisation se fait une
fois par `python -m moteur google autoriser`, et se retire cote Google.
"""
from __future__ import annotations
import html as _html
import json
import secrets
import threading
import webbrowser
from dataclasses import dataclass, field
from email.message import EmailMessage
from email.utils import formatdate
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .util import MOIS_FR

# `util.MOIS_FR` est sans accent : il sert aux formats a largeur fixe et aux
# noms de fichiers, ou l'accent est proscrit -- `etiq` en depend, il doit
# reproduire a l'identique le nom de fichier ecrit par `mois`. Un courriel, lui,
# s'ecrit en francais.
MOIS_ACCENTS = ["janvier", "février", "mars", "avril", "mai", "juin",
                "juillet", "août", "septembre", "octobre", "novembre",
                "décembre"]



# --------------------------------------------------------------- les messages
@dataclass
class Message:
    cle: str
    nom: str
    destinataire: str
    sujet: str
    corps: str
    pieces: list = field(default_factory=list)
    # La meme lettre en HTML, quand elle porte un bouton (le « Je signe » des
    # contrats). Le texte reste la version de reference : c'est lui que la
    # page de relecture montre, et lui que lit une messagerie sans HTML.
    html: str = ""

    def taille(self) -> int:
        return sum(p.stat().st_size for p in self.pieces if p.exists())


# Le seul texte de ce depot qui s'adresse a un humain : il porte donc ses
# accents, contrairement au code et aux formats a largeur fixe.
CORPS = """Bonjour {prenom},

Tu trouveras ci-joint tes documents pour {mois} {annee} :

{liste}

{notes}
Bien à toi,
{signataire}
{raison_sociale}
"""

# L'ordre des pieces, une fois pour toutes : il gouverne les pieces jointes,
# la liste du message et les notes qui la suivent.
PIECES = ("bulletin", "certificat_cs", "aer")

PREFIXES = {
    "bulletin": "Bulletin",
    "certificat_cs": "CertificatCS",
    "aer": "AER",
}

LIBELLES = {
    "bulletin": "le bulletin de paie",
    "certificat_cs": "le certificat d'emploi Congés Spectacles",
    "aer": "l'attestation employeur France Travail (AER Cinéma Spectacle)",
}

# Pour l'objet du message, ou l'on n'a pas la place des libellés longs.
COURTS = {
    "bulletin": "bulletin",
    "certificat_cs": "certificat Congés Spectacles",
    "aer": "attestation France Travail",
}

NOTES = {
    "bulletin":
        "Le bulletin est à conserver sans limitation de durée.",
    "certificat_cs":
        "Le certificat d'emploi Congés Spectacles te sert à faire valoir tes "
        "droits à congé auprès d'Audiens : garde-le, c'est la pièce qu'ils "
        "demandent.",
    "aer":
        "L'attestation employeur est celle qui compte pour France Travail. "
        "Elle est éditée par France Travail à partir de notre déclaration ; "
        "nous ne faisons que te la transmettre.",
}

# Quand l'AER n'est pas encore revenue. On le DIT, plutôt que d'envoyer un
# message qui laisse croire que le dossier est complet.
NOTE_SANS_AER = (
    "Ton attestation employeur France Travail (AER Cinéma Spectacle) n'est pas "
    "encore revenue : France Travail l'édite à partir de notre déclaration, "
    "quelques jours après le dépôt. Elle te sera envoyée dès réception.")


def etiquette(mois: str) -> str:
    """« Aout2026 » a partir de « 2026-08 » : l'etiquette des noms de fichier.

    Sans accent, comme tout ce qui devient un nom de fichier -- c'est la seule
    raison pour laquelle elle ne se deduit pas de MOIS_ACCENTS.
    """
    an, mo = int(mois[:4]), int(mois[5:7])
    return "%s%s" % (MOIS_FR[mo - 1].capitalize(), an)


def nom_fichier(prefixe: str, cle: str, etiq: str) -> str:
    return "%s_%s_%s.pdf" % (prefixe, cle, etiq)


_nom_fichier = nom_fichier          # ancien nom, garde pour l'existant


def pieces_individuelles(paies, ent: dict, dossier, etiq: str,
                         premier_cs: int, ctx=None,
                         mois: str = None, pour_certificat: dict = None) -> dict:
    """Ecrit un jeu de documents PAR SALARIE, avec les numeros du mois.

    Renvoie {cle_salarie: {"bulletin": Path, "certificat_cs": Path}}.

    `pour_certificat` : {(cle_salarie, debut): paie_du_certificat}, pour les
    contrats qui debordent du mois -- None quand aucun certificat n'est du
    ce mois-ci (contrat en cours), la paie du contrat entier au dernier mois.
    Absent : un certificat par paie, comme toujours.

    Les numeros sont ceux du fichier groupe : on repasse les memes compteurs,
    contrat par contrat, pour que le document remis au salarie et celui qui est
    archive portent le meme numero. C'est la raison d'etre de cette fonction --
    sans elle il faudrait decouper les PDF a la page, ce qui casse des qu'un
    bulletin deborde sur deux pages.

    La troisieme piece, l'AER, ne s'ecrit PAS ici : elle vient de France
    Travail et arrive plus tard. `moteur aer` la depose dans ce meme dossier,
    sous le meme nom de famille, et `preparer` la ramasse si elle est la.
    """
    from . import bulletin, conges_spectacles

    dossier = Path(dossier)
    dossier.mkdir(parents=True, exist_ok=True)
    out, numero_cs = {}, premier_cs
    for p in paies:
        cle = p.salarie["_cle"]
        jeu = {}
        if not p.engagement.sans_paie:
            jeu["bulletin"] = bulletin.ecrire(
                [p], ent, dossier / nom_fichier("Bulletin", cle, etiq),
                ctx=ctx, mois=mois)
        pc = (pour_certificat.get((cle, str(p.engagement.debut)))
              if pour_certificat is not None else p)
        if pc is not None:
            jeu["certificat_cs"] = conges_spectacles.ecrire(
                [pc], ent, dossier / nom_fichier("CertificatCS", cle, etiq),
                premier_numero=numero_cs)
            numero_cs += len(conges_spectacles.decouper(pc.engagement))
        out.setdefault(cle, {}).update(jeu)
    return out


def preparer(paies, ent: dict, mois: str, dossier) -> list:
    """Un Message par salarie, a partir des pieces individuelles deja ecrites.

    Un salarie peut avoir plusieurs contrats dans le mois : ses pieces sont
    ecrites une fois, sous sa cle, et il ne recoit qu'un seul message.
    """
    dossier = Path(dossier)
    an, mo = int(mois[:4]), int(mois[5:7])
    etiq = etiquette(mois)
    vus, messages = set(), []
    for p in paies:
        s = p.salarie
        cle = s["_cle"]
        if cle in vus:
            continue
        vus.add(cle)
        if not s.get("email"):
            raise ValueError(
                "Pas d'adresse e-mail pour %s %s : completer config/salaries.json "
                "avant d'envoyer." % (s["nom"], s["prenom"]))
        pieces, libelles, presents = [], [], []
        for champ in PIECES:
            chemin = dossier / nom_fichier(PREFIXES[champ], cle, etiq)
            if chemin.exists():
                pieces.append(chemin)
                libelles.append("  - %s" % LIBELLES[champ])
                presents.append(champ)
        notes = [NOTES[c] for c in presents]
        if "aer" not in presents:
            notes.append(NOTE_SANS_AER)
        messages.append(Message(
            cle=cle, nom="%s %s" % (s["prenom_affichage"], s["nom"]),
            destinataire=s["email"].lower(),
            sujet="%s %d — %s"
                  % (MOIS_ACCENTS[mo - 1].capitalize(), an,
                     _enumerer([COURTS[c] for c in presents])),
            corps=CORPS.format(
                prenom=s["prenom_affichage"], mois=MOIS_ACCENTS[mo - 1], annee=an,
                liste="\n".join(libelles),
                notes="\n\n".join(notes) + "\n" if notes else "",
                signataire=ent["signataire"].get("prenom_affichage")
                           or ent["signataire"]["prenom"],
                raison_sociale=ent["nom_affichage"]),
            pieces=pieces))
    return messages


def _enumerer(mots: list) -> str:
    """« a, b et c ». Suit les pieces REELLEMENT jointes : promettre dans
    l'objet une AER qui n'est pas la serait un mensonge en premiere ligne."""
    if not mots:
        return "documents"
    if len(mots) == 1:
        return mots[0]
    return "%s et %s" % (", ".join(mots[:-1]), mots[-1])


def en_mime(message: Message, expediteur: str) -> EmailMessage:
    """Le message complet, pieces jointes comprises."""
    m = EmailMessage()
    m["From"] = expediteur
    m["To"] = message.destinataire
    m["Subject"] = message.sujet
    m["Date"] = formatdate(localtime=True)
    m.set_content(message.corps)
    if message.html:
        m.add_alternative(message.html, subtype="html")
    for piece in message.pieces:
        m.add_attachment(piece.read_bytes(), maintype="application",
                         subtype="pdf", filename=piece.name)
    return m


# --------------------------------------------------------------------- l'envoi
def envoyer(messages: list, expediteur: str, client,
            identifiants: list = None) -> list:
    """Envoie pour de bon. Irreversible : un courriel parti ne revient pas.

    `identifiants` : une liste a remplir, si l'appelant la passe, des
    identifiants Gmail des messages partis, dans l'ordre. La releve des
    signatures s'en sert pour ne jamais prendre notre propre envoi pour une
    reponse -- quand le salarie, c'est nous, en test.

    `client` est un `google.Client` deja construit -- il l'est **avant**
    d'ouvrir la page de relecture, pour qu'un compte non autorise se voie au
    terminal et non apres le clic (voir `cli.cmd_envoi`).

    Les envois sont faits un par un et la liste rendue ne porte que ceux qui
    sont reellement partis : si le troisieme echoue, les deux premiers sont
    partis, et l'appelant doit le savoir plutot que de croire a un tout ou rien.
    """
    faits = []
    for message in messages:
        try:
            ident = client.envoyer(en_mime(message, expediteur).as_bytes())
        except Exception as exc:
            if faits:
                raise RuntimeError(
                    "%s : %s\nATTENTION, %d message(s) etaient deja partis : %s"
                    % (message.destinataire, exc, len(faits), ", ".join(faits))
                ) from None
            raise
        faits.append(message.destinataire)
        if identifiants is not None:
            identifiants.append(ident)
    return faits


# ------------------------------------------------- la page de relecture locale
PAGE = """<!doctype html><html lang="fr"><meta charset="utf-8">
<title>Envoi aux salaries - %(mois)s</title>
<style>
 :root { color-scheme: light dark; }
 body { font: 15px/1.5 system-ui, "Segoe UI", sans-serif; margin: 0;
        background: #14141a; color: #e8e8ec; }
 main { max-width: 860px; margin: 0 auto; padding: 28px 22px 90px; }
 h1 { font-size: 21px; margin: 0 0 2px; }
 .sub { color: #9a9aa8; font-size: 13px; margin: 0 0 22px; }
 .msg { border: 1px solid #2f2f3a; border-radius: 10px; padding: 16px 18px;
        margin-bottom: 14px; background: #1c1c24; }
 .msg h2 { font-size: 15px; margin: 0 0 2px; color: #c9a227; }
 .dest { font-family: ui-monospace, Consolas, monospace; font-size: 13px;
         color: #9a9aa8; }
 .obj { margin: 10px 0 6px; font-weight: 600; font-size: 14px; }
 pre { white-space: pre-wrap; font: 13px/1.45 ui-monospace, Consolas, monospace;
       background: #14141a; border: 1px solid #2a2a33; border-radius: 7px;
       padding: 11px 13px; margin: 0 0 11px; color: #cfcfd8; }
 .pj a { display: inline-block; border: 1px solid #3a3a47; border-radius: 6px;
         padding: 5px 10px; margin: 0 7px 7px 0; font-size: 13px;
         color: #e8e8ec; text-decoration: none; }
 .pj a:hover { border-color: #c9a227; color: #c9a227; }
 footer { position: fixed; left: 0; right: 0; bottom: 0; background: #1c1c24;
          border-top: 1px solid #2f2f3a; padding: 13px 22px; display: flex;
          gap: 12px; align-items: center; justify-content: center; }
 button { font: inherit; font-weight: 600; border: 0; border-radius: 8px;
          padding: 11px 20px; cursor: pointer; }
 .envoi { background: #8a2f2f; color: #fff; }
 button:disabled { opacity: .5; cursor: wait; }
 #etat { font-size: 13px; color: #9a9aa8; }
 .alerte { color: #d0a353; font-size: 13px; margin: 0 0 18px; }
</style>
<main>
 <h1>Envoi aux salari&eacute;s &mdash; %(mois)s</h1>
 <p class="sub">%(nb)d message(s), %(nb_pieces)d pi&egrave;ce(s) jointe(s),
    depuis %(expediteur)s. Rien n'est parti tant que tu n'as pas cliqu&eacute;.</p>
 <p class="alerte">Chaque message ne porte que les documents de son
    destinataire. Clique une pi&egrave;ce jointe pour la relire avant d'agir.</p>
 %(messages)s
</main>
<footer>
 <button class="envoi" onclick="agir('envoyer')">Envoyer maintenant</button>
 <span id="etat"></span>
</footer>
<script>
const JETON = %(jeton)s;
async function agir(quoi) {
  if (!confirm('Confirmer : ENVOYER pour de bon ' + %(nb)d + ' message(s) ?')) return;
  for (const b of document.querySelectorAll('button')) b.disabled = true;
  document.getElementById('etat').textContent = 'en cours...';
  const r = await fetch('/' + quoi + '?jeton=' + JETON, {method: 'POST'});
  const t = await r.text();
  document.getElementById('etat').textContent = t;
  if (r.ok) setTimeout(() => window.close(), 2500);
  else for (const b of document.querySelectorAll('button')) b.disabled = false;
}
</script>
</html>"""


def _page(messages: list, mois_libelle: str, jeton: str, expediteur: str) -> str:
    blocs = []
    for i, m in enumerate(messages):
        pj = "".join(
            '<a href="/piece?jeton=%s&amp;i=%d&amp;j=%d" target="_blank">%s</a>'
            % (jeton, i, j, _html.escape(p.name))
            for j, p in enumerate(m.pieces))
        blocs.append(
            '<div class="msg"><h2>%s</h2>'
            '<div class="dest">%s</div>'
            '<div class="obj">%s</div><pre>%s</pre>'
            '<div class="pj">%s</div></div>'
            % (_html.escape(m.nom), _html.escape(m.destinataire),
               _html.escape(m.sujet), _html.escape(m.corps), pj))
    return PAGE % {
        "mois": _html.escape(mois_libelle), "nb": len(messages),
        "nb_pieces": sum(len(m.pieces) for m in messages),
        "expediteur": _html.escape(expediteur),
        "messages": "".join(blocs), "jeton": json.dumps(jeton),
    }


def relire_et_agir(messages: list, expediteur: str, mois_libelle: str,
                   client, ouvrir: bool = True) -> dict:
    """Sert la page de relecture en local et attend une decision.

    Rend {"action": "envoyer"|"abandon", "faits": [...]}.
    Le serveur s'arrete des qu'une action a abouti, ou si la fenetre est
    fermee sans rien faire (Ctrl+C dans le terminal).
    """
    jeton = secrets.token_urlsafe(24)
    resultat = {"action": "abandon", "faits": [], "erreur": None}
    fini = threading.Event()

    class Poignee(BaseHTTPRequestHandler):
        def log_message(self, *a):        # pas de journal : il porterait le jeton
            pass

        def _refuser(self):
            self.send_response(403)
            self.end_headers()

        def _jeton_ok(self) -> bool:
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            return secrets.compare_digest(q.get("jeton", [""])[0], jeton)

        def do_GET(self):
            from urllib.parse import urlparse, parse_qs
            chemin = urlparse(self.path).path
            if not self._jeton_ok():
                return self._refuser()
            if chemin == "/":
                corps = _page(messages, mois_libelle, jeton,
                              expediteur).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(corps)))
                self.end_headers()
                self.wfile.write(corps)
                return
            if chemin == "/piece":
                q = parse_qs(urlparse(self.path).query)
                try:
                    piece = messages[int(q["i"][0])].pieces[int(q["j"][0])]
                except (KeyError, ValueError, IndexError):
                    return self._refuser()
                data = piece.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/pdf")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            self._refuser()

        def do_POST(self):
            from urllib.parse import urlparse
            chemin = urlparse(self.path).path
            if not self._jeton_ok() or chemin != "/envoyer":
                return self._refuser()
            try:
                faits = envoyer(messages, expediteur, client)
                resultat.update(action="envoyer", faits=faits)
                texte = "%d message(s) envoye(s)." % len(faits)
                code = 200
            except Exception as exc:      # remonte a l'ecran, pas seulement au terminal
                resultat["erreur"] = str(exc)
                texte, code = "Echec : %s" % exc, 500
            corps = texte.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(corps)))
            self.end_headers()
            self.wfile.write(corps)
            if code == 200:
                fini.set()

    serveur = ThreadingHTTPServer(("127.0.0.1", 0), Poignee)
    port = serveur.server_address[1]
    url = "http://127.0.0.1:%d/?jeton=%s" % (port, jeton)
    threading.Thread(target=serveur.serve_forever, daemon=True).start()
    print("Page de relecture : %s" % url)
    if ouvrir:
        webbrowser.open(url)
    try:
        while not fini.wait(0.3):
            pass
    except KeyboardInterrupt:
        print("\nAbandon : rien n'a ete envoye.")
    finally:
        serveur.shutdown()
    return resultat
