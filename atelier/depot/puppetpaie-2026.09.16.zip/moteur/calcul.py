"""Le moteur de paie : d'un contrat (cachets x taux) au bulletin chiffre.

Tout part de trois nombres - le brut, l'assiette CSG et le plafond - puis
chaque rubrique du bareme est appliquee et arrondie separement, comme le
faisait CoolPaie. Les tests de non-regression rejouent les mois 2021-2026
et comparent au centime.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Optional

from .util import eur, pct, d, jj_mm_aaaa
from .contexte import Contexte
from . import catalogue as cat


# --------------------------------------------------------------------- entree
@dataclass
class Engagement:
    """Un contrat = un salarie, un spectacle, des lignes de paie datees."""
    salarie: str                     # "PUPPIS" / "Ana" / "Lenadre"...
    spectacle: str                   # "oooh teresina" / numero d'objet
    # Les jours reellement joues : la reunion des dates des lignes de paie
    # (`operations.dates_engagement`). Une date peut venir nue ou detaillee :
    #
    #     "2026-10-02"                                  ou
    #     {"jour": "2026-10-02", "lieu": "Berlin"}
    #
    # Apres construction, `dates_travail` est toujours une liste de dates
    # triees -- tout ce qui la lit (AEM, DSN, bulletin) n'a rien a savoir de
    # tout ceci. Le lieu, lui, part dans `lieux`.
    dates_travail: list
    # LA SAISIE : des lignes de paie, [{rubrique, quantite, taux, heures,
    # dates, lieu}]. C'est la seule ecriture depuis le 13/09/2026 -- l'ancienne
    # (`cachets` + `heures` + leurs taux sur l'engagement) a ete convertie
    # une fois pour toutes (outils/convertir_saisies.py), et le rejeu de
    # l'historique CoolPaie (verif.py) construit lui aussi des lignes. Une
    # seule ecriture, c'est un seul chemin de calcul, et rien a garder egal.
    lignes: Optional[list] = None
    # LE CONTRAT PEUT DEBORDER DU MOIS (decide le 15/09/2026, option B1 de
    # prive/journal/CONTRATS-PLURIMENSUELS.md). `debut` et `fin` sont les
    # bornes du CONTRAT SIGNE -- ce que la DSN declare en 40.001 et 40.010,
    # identiques chaque mois -- et non celles de la paie du mois. Ce qui
    # borne la paie, c'est le mois : `debut_periode`/`fin_periode`. Un
    # engagement ne porte que ce qui s'y joue ce mois-ci ; un contrat
    # d'octobre a decembre est trois engagements, un par fichier de mois,
    # qui disent tous << du 12/10 au 20/12 >> et portent le meme numero.
    debut: Optional[str] = None      # defaut : 1re date travaillee
    fin: Optional[str] = None        # defaut : derniere date travaillee
    numero: Optional[str] = None     # ex. PU1.26.13 (genere si absent)
    # Le mois de paie, AAAA-MM. Defaut : celui des dates jouees, qui ne
    # sortent jamais du mois (le fichier de paie EST le mois).
    mois: Optional[str] = None
    # LE PLANNING : les jours du contrat APRES le mois, coches depuis le
    # calendrier de l'ecran (15/09/2026 : << avec une fleche on pourrait
    # aller au mois suivant >>). Ce ne sont pas des jours payes ce mois-ci
    # -- ils le seront dans le fichier de leur mois, ou << reprendre un
    # contrat en cours >> les retrouve deja coches. Ils servent au contrat
    # imprime, qui peut alors lister toutes les dates de la tournee, et a
    # `fin`, qui se cale sur le dernier d'entre eux. Meme ecriture que les
    # dates jouees : nue, ou {"jour", "lieu"}.
    planning: list = field(default_factory=list)
    planning_lieux: dict = field(init=False, default_factory=dict)
    jours: Optional[int] = None      # jours travailles (AEM) ; defaut : nb de dates
    # LA QUOTITE DU CONTRAT (S21.G00.40.012/013) : les jours du contrat
    # ENTIER, tels que connus a la signature -- dates du premier mois et
    # planning. Tranche le 15/09/2026 par le cahier technique 2026.1 : la
    # quotite est << la duree contractuelle de travail >>, le bloc 41 declare
    # son << ancienne >> valeur a chaque changement (41.007), et la valeur
    # zero est interdite en unite journee (bloc 40, CCH-11). Les jours du
    # mois, qui variaient (2, 1, 3) et tombaient a 0 sur un mois sans cachet,
    # etaient donc trois changements de contrat non declares. Defaut : les
    # dates de ce mois + le planning, ce qui vaut exactement les dates sur un
    # contrat qui tient dans son mois -- tout l'historique. Sur une reprise,
    # `operations` le recopie du premier mois.
    jours_contrat: Optional[int] = None
    date_paiement: Optional[str] = None
    # Le taux du cachet, tel que le contrat et le certificat Conges Spectacles
    # l'impriment : celui de la premiere ligne `cachet`. Pose a la
    # construction ; la valeur passee ne sert que s'il n'y a aucun cachet.
    taux_cachet: float = 130.00
    # CE QUE LA DECLARATION COMPTE, zone AEM [650:659] et DSN bloc 53 : les
    # cachets, les heures hors cachets. DERIVES des lignes, jamais saisis --
    # un engagement se connait lui-meme, et l'AEM n'a pas a attendre qu'un
    # calcul ait eu lieu pour savoir combien de cachets elle declare.
    cachets: int = field(init=False, default=0)
    heures: Optional[float] = field(init=False, default=None)
    # LE LIEU PAR DEFAUT DE L'ENGAGEMENT, et le lieu de chaque date quand elle
    # s'en ecarte. Decide sur son propre exemple --
    # quatre Teresina dans le mois, un a Berlin, un a Paris, deux a Varzy :
    # c'est UNE paie (meme spectacle, donc meme numero d'objet), donc UN
    # contrat, qui doit nommer les trois villes.
    #
    # La cascade a un etage de plus que le reste : la date l'emporte sur
    # l'engagement, qui l'emporte sur le mois. << Par defaut ca reste le meme
    # mais on doit pouvoir changer >>, et le 12/09 : << c'est ce changement
    # qui fait foi >>.
    #
    # Le lieu ne se declare NULLE PART -- ni DSN, ni AEM, ni DPAE. Il figure
    # au contrat, et nulle part ailleurs.
    lieu: str = ""
    lieux: dict = field(default_factory=dict)   # date -> lieu, quand elle s'ecarte
    # L'EMPLOI DE CET ENGAGEMENT, et non celui de la fiche salarie.
    #
    # Un meme salarie n'exerce pas le meme metier d'un contrat a l'autre :
    # << il y en a une de base -- ici artiste dramatique -- mais on peut faire
    # 8 h de production (ca fera un nouveau contrat) >>. Huit heures de
    # production ne sont pas de l'artistique, et la difference n'est pas
    # cosmetique : elle change le PCS-ESE declare (S21.G00.40.004), le code
    # emploi France Travail (S21.G00.40.005), le libelle (S21.G00.40.006) --
    # et le BAREME, parce que l'abattement de 30 % sur les taux (arrete du
    # 24/01/1975) ne vaut que pour les artistes.
    #
    # `None` = on prend ce que dit la fiche. C'est le cas general, et c'est
    # ce qui fait que toutes les saisies d'avant continuent de se rejouer.
    emploi: Optional[str] = None
    pcs_ese: Optional[str] = None
    code_emploi_ft: Optional[str] = None
    statut: Optional[str] = None
    # Ce que la DSN declare du classement conventionnel (S21.G00.40.002 et
    # .003). Ils suivent l'emploi, pas la personne : la meme salariee est
    # << profession intermediaire >> sur un contrat d'artiste et
    # << ouvrier >> sur un contrat de production.
    statut_conventionnel: Optional[str] = None
    statut_categoriel_rc: Optional[str] = None

    def __post_init__(self):
        # Les deux ecritures d'une date se rejoignent ici, et nulle part
        # ailleurs : au sortir de ce bloc, `dates_travail` est une liste de
        # dates triees, comme elle l'a toujours ete.
        jours, lieux = [], dict(self.lieux or {})
        for x in self.dates_travail:
            if isinstance(x, dict):
                if "jour" not in x:
                    raise ValueError(
                        "Une date ecrite en detail doit dire son `jour` : "
                        "{\"jour\": \"2026-10-02\", \"lieu\": \"Berlin\"}. "
                        "Recu : %r" % (x,))
                jour = d(x["jour"])
                if str(x.get("lieu") or "").strip():
                    lieux[jour] = str(x["lieu"]).strip()
            else:
                jour = d(x)
            jours.append(jour)
        jours.sort()
        self.dates_travail = jours
        # On ne garde que ce qui concerne des jours joues : un lieu attache a
        # une date qu'on vient de retirer n'a plus de sens, et le trainer
        # ferait reapparaitre Berlin le jour ou on retape la date.
        self.lieux = {j: v for j, v in lieux.items() if j in set(jours)}
        if self.lignes is None:
            raise ValueError(
                "Un engagement se saisit en lignes de paie ([{rubrique, "
                "quantite, taux, dates}]). L'ancienne ecriture -- `dates`, "
                "`cachets`, `heures`, `taux_horaire` sur l'engagement -- "
                "n'est plus lue : convertir le fichier une fois avec "
                "outils/convertir_saisies.py.")
        # UN MOIS DU CONTRAT SANS AUCUN CACHET (15/09/2026, Leandre : << il
        # faut toujours des DSN, meme les mois sans paye >>). Le contrat est
        # en cours, la DSN du mois doit le porter -- individu, contrat,
        # versement a zero (bloc 50 obligatoire, cahier technique 2026.1) --
        # et rien d'autre n'est du : ni bulletin, ni contrat, ni certificat
        # sauf si c'est le dernier mois. Il s'ecrit `lignes: []`, avec les
        # bornes du contrat dites, puisque rien ne permet de les deduire.
        if not self.lignes and not (self.debut and self.fin):
            raise ValueError(
                "Un engagement sans aucune ligne de paie est un mois du "
                "contrat sans cachet : il doit dire `debut` et `fin` du "
                "contrat (et `numero` s'il est connu), rien ne permet de les "
                "deduire.")
        if not self.lignes and not self.mois:
            raise ValueError(
                "Un engagement sans aucune ligne de paie doit dire son mois.")
        # Ce que la declaration compte, zone AEM [650:659] : les heures
        # ([650:653]), les cachets ([653:655]), les jours ([655:659]).
        #
        # Les 12 heures d'un cachet ne vont PAS dans les heures : elles sont
        # impliquees par le nombre de cachets, et les compter deux fois
        # doublerait les droits du salarie.
        self.cachets = int(sum(
            float(l["quantite"]) for l in self.lignes
            if cat.rubrique(l["rubrique"]).unite == "cachet"))
        autres = sum(
            cat.rubrique(l["rubrique"]).heures(float(l["quantite"]),
                                               l.get("heures"))
            for l in self.lignes
            if cat.rubrique(l["rubrique"]).unite != "cachet")
        self.heures = float(autres) if autres else None
        premier_cachet = next((l for l in self.lignes
                               if cat.rubrique(l["rubrique"]).unite == "cachet"), None)
        if premier_cachet is not None:
            self.taux_cachet = float(premier_cachet["taux"])
        if self.jours is None:
            self.jours = len(self.dates_travail)
        # Le planning se lit comme les dates jouees, et se range a part.
        futur, lieux_futurs = [], {}
        for x in self.planning or []:
            jour = d(x["jour"]) if isinstance(x, dict) else d(x)
            if isinstance(x, dict) and str(x.get("lieu") or "").strip():
                lieux_futurs[jour] = str(x["lieu"]).strip()
            if jour not in futur:
                futur.append(jour)
        futur.sort()
        self.planning, self.planning_lieux = futur, lieux_futurs
        self.debut = d(self.debut) if self.debut else self.dates_travail[0]
        self.fin = d(self.fin) if self.fin else max(
            self.dates_travail[-1], futur[-1] if futur else self.dates_travail[-1])
        if not self.lignes and not (self.debut < self.debut_mois_de(self.mois)
                                    or self.fin > self.fin_mois_de(self.mois)):
            raise ValueError(
                "Contrat du %s au %s sans aucune ligne de paie : un contrat "
                "qui tient dans son mois sans rien jouer n'a pas de sens. Un "
                "mois sans cachet n'existe que pour un contrat qui deborde du "
                "mois." % (jj_mm_aaaa(self.debut), jj_mm_aaaa(self.fin)))
        if self.debut > self.fin:
            raise ValueError(
                "Contrat du %s au %s : la fin precede le debut."
                % (jj_mm_aaaa(self.debut), jj_mm_aaaa(self.fin)))
        # Les dates jouees d'un engagement tiennent dans son mois -- c'est ce
        # qui fait qu'un fichier de paie est UN mois. Une date d'a cote est
        # une faute de frappe, pas un contrat plus long : celui-ci s'ecrit en
        # allongeant `fin`, et ses cachets de novembre dans le fichier de
        # novembre. Le controle ne vaut que quand le mois est DIT (par le
        # fichier de paie) : un engagement construit sans mois -- le contrat
        # entier recompose pour son certificat Conges Spectacles, un test --
        # prend celui de sa premiere date et n'est pas borne.
        hors = [j for j in self.dates_travail
                if self.mois and j.strftime("%Y-%m") != self.mois]
        self.mois = self.mois or self.dates_travail[0].strftime("%Y-%m")
        if self.jours_contrat is None:
            self.jours_contrat = len(set(self.dates_du_contrat()))
        if hors:
            raise ValueError(
                "Le %s n'est pas dans le mois %s. Les jours joues d'un "
                "engagement sont ceux du mois de paie ; un contrat qui se "
                "poursuit le mois suivant garde `fin` au-dela du mois et "
                "porte ses jours suivants dans le fichier du mois suivant."
                % (jj_mm_aaaa(hors[0]), self.mois))
        # Un jour de planning est un jour d'un mois SUIVANT : dans le mois,
        # c'est un jour joue, qui se paie ici et se coche comme tel.
        dedans = [j for j in self.planning if j <= self.fin_mois]
        if dedans:
            raise ValueError(
                "Le %s est dans le mois %s : c'est un jour joue de ce mois, "
                "a cocher comme tel, pas un jour de planning."
                % (jj_mm_aaaa(dedans[0]), self.mois))
        if self.planning and self.planning[-1] > self.fin:
            raise ValueError(
                "Contrat du %s au %s, mais un jour de planning le %s : le "
                "planning ne depasse pas la fin du contrat."
                % (jj_mm_aaaa(self.debut), jj_mm_aaaa(self.fin),
                   jj_mm_aaaa(self.planning[-1])))
        # Un contrat contient ses jours joues. Un cachet hors du contrat
        # n'est couvert par aucune DPAE, et la DSN le refuserait (CCH-11).
        if self.dates_travail and (
                self.dates_travail[0] < self.debut or self.dates_travail[-1] > self.fin):
            raise ValueError(
                "Contrat du %s au %s, mais des jours joues le %s et le %s : "
                "un jour joue hors du contrat n'est couvert par aucune DPAE."
                % (jj_mm_aaaa(self.debut), jj_mm_aaaa(self.fin),
                   jj_mm_aaaa(self.dates_travail[0]),
                   jj_mm_aaaa(self.dates_travail[-1])))

    # ------------------------------------------------- le contrat et le mois
    @staticmethod
    def debut_mois_de(mois: str):
        return d(mois + "-01")

    @staticmethod
    def fin_mois_de(mois: str):
        import calendar
        an, mo = int(mois[:4]), int(mois[5:7])
        return d("%d-%02d-%02d" % (an, mo, calendar.monthrange(an, mo)[1]))

    @property
    def debut_mois(self):
        return self.debut_mois_de(self.mois)

    @property
    def fin_mois(self):
        return self.fin_mois_de(self.mois)

    @property
    def sans_paie(self) -> bool:
        """Un mois du contrat sans aucun cachet : DSN oui, bulletin non."""
        return not self.lignes

    @property
    def quotite(self) -> int:
        """S21.G00.40.012/013 : les jours du contrat entier, jamais zero."""
        return self.jours_contrat

    @property
    def premier_mois(self) -> bool:
        """Le contrat commence ce mois-ci : contrat a imprimer, DPAE a faire."""
        return self.debut >= self.debut_mois

    @property
    def dernier_mois(self) -> bool:
        """Le contrat finit ce mois-ci : bloc 62 en DSN, certificat CS."""
        return self.fin <= self.fin_mois

    @property
    def a_cheval(self) -> bool:
        return not (self.premier_mois and self.dernier_mois)

    @property
    def debut_periode(self):
        """Le premier jour de la periode de paie : le contrat borne au mois.

        C'est ce que la DSN met en 51.001 (et 54, 58, 78) : la periode de
        paie du mois, pas celle du contrat -- controle CCH-11/13 du cahier
        technique. Sur un contrat qui tient dans son mois, c'est `debut`.
        """
        return max(self.debut, self.debut_mois)

    @property
    def fin_periode(self):
        return min(self.fin, self.fin_mois)

    @property
    def mois_du_contrat(self) -> list:
        """Les mois AAAA-MM que couvre le contrat, du premier au dernier."""
        out, an, mo = [], self.debut.year, self.debut.month
        while (an, mo) <= (self.fin.year, self.fin.month):
            out.append("%d-%02d" % (an, mo))
            an, mo = (an + 1, 1) if mo == 12 else (an, mo + 1)
        return out

    # ------------------------------------------------------------ les lieux
    def lieu_de(self, jour) -> str:
        """Ou se joue CE jour-la. La date l'emporte, l'engagement supplee."""
        jour = d(jour)
        return self.lieux.get(jour) or self.planning_lieux.get(jour) or self.lieu

    def dates_du_contrat(self) -> list:
        """Tous les jours connus du contrat : ceux du mois, puis le planning.

        C'est ce que le contrat imprime liste. Les mois deja passes d'un
        contrat en cours n'y sont pas -- ils sont dans leurs fichiers, et le
        contrat s'imprime au premier mois, quand rien n'est encore passe.
        """
        return list(self.dates_travail) + list(self.planning)

    def planning_connu(self) -> bool:
        return bool(self.planning)

    def lieux_joues(self) -> list:
        """Les lieux du contrat, dans l'ordre des dates, sans repetition.

        Vide quand personne n'a rien dit : un contrat sans lieu saisi doit
        rester une phrase francaise, pas une liste vide imprimee.
        """
        out = []
        for jour in self.dates_du_contrat():
            ou = self.lieu_de(jour)
            if ou and ou not in out:
                out.append(ou)
        return out

    def dates_par_lieu(self, planning: bool = True) -> list:
        """[(lieu, [dates]), ...] dans l'ordre des dates, pour le contrat.

        Groupe par lieu SANS retrier : deux passages a Varzy separes par Paris
        font deux groupes, parce que c'est la verite du calendrier -- et un
        contrat qui recompose l'ordre des dates fait douter du reste.
        `planning=False` : les seuls jours du mois (l'ecran qui rouvre une
        saisie ancienne).
        """
        out = []
        for jour in (self.dates_du_contrat() if planning else self.dates_travail):
            ou = self.lieu_de(jour)
            if out and out[-1][0] == ou:
                out[-1][1].append(jour)
            else:
                out.append((ou, [jour]))
        return out


# ------------------------------------------------------------ lignes de brut
@dataclass(frozen=True)
class LigneBrut:
    """Une ligne de remuneration : une rubrique, une quantite, un taux.

    C'est ce que CoolPaie appelle une rubrique de paie, et ce que le bulletin
    imprime au-dessus des cotisations. Le montant est arrondi ICI, ligne par
    ligne, parce que c'est ainsi que les cotisations se calculent ensuite --
    verifie sur le bulletin 27/2026, ou le calcul global donne un centime de
    plus.
    """
    code: str
    libelle: str
    unite: str
    quantite: Decimal
    taux: Decimal
    montant: Decimal
    heures_annexes: Decimal      # ce que la ligne apporte aux 507 heures
    soumis: bool
    imposable: bool

    @property
    def designation(self) -> str:
        """La ligne en francais : « 2 Cachets », « 1 Journee de travail »,
        « 6 h de Masterclass / action culturelle ».

        C'est le MOTEUR qui l'ecrit, et non le bulletin ni le contrat. Deux
        documents qui la fabriqueraient chacun de leur cote finiraient par ne
        plus dire la meme chose du meme contrat -- et l'un des deux est signe.
        """
        q = self.quantite.normalize()
        nb = ("%d" % q) if q == q.to_integral_value() else str(q).replace(".", ",")

        def _pluriel(texte):
            # Le pluriel porte sur le PREMIER mot : « Journees de travail »,
            # « Services de repetition ». Le mettre a la fin donnerait
            # « Journee de travails ».
            if q <= 1:
                return texte
            mots = texte.split(" ", 1)
            tete = mots[0] if mots[0].endswith("s") else mots[0] + "s"
            return " ".join([tete] + mots[1:])

        if self.unite == "heure" and not self.libelle.lower().startswith("heure"):
            # « 6 h de Masterclass » : l'unite doit apparaitre, le libelle ne
            # la dit pas. Quand il la dit deja (« Heure de travail »), la
            # repeter donnerait « 6 h de Heure de travail ».
            return "%s h de %s" % (nb, self.libelle)
        return "%s %s" % (nb, _pluriel(self.libelle))


def lignes_brut(eng: Engagement, ctx: Contexte = None) -> list:
    """Les lignes de remuneration d'un engagement : une par ligne de paie.

    Chaque ligne porte sa rubrique du catalogue (unite, 12 h d'un cachet,
    assujettissement), sa quantite et son taux. Le montant est arrondi ligne
    par ligne, parce que les cotisations se calculent ensuite rubrique par
    rubrique -- verifie sur un bulletin mixte, ou un calcul global donne un
    centime de plus.
    """
    out = []
    for l in eng.lignes:
        r = cat.rubrique(l["rubrique"], ctx)
        q = Decimal(str(l["quantite"]))
        taux = Decimal(str(l["taux"]))
        heures = l.get("heures")
        signe = Decimal("-1") if r.sens == "-" else Decimal("1")
        out.append(LigneBrut(
            code=r.code, libelle=r.libelle, unite=r.unite,
            quantite=q, taux=taux,
            montant=signe * eur(taux * q),
            heures_annexes=Decimal(str(r.heures(float(q), heures))),
            soumis=r.soumis, imposable=r.imposable))
    return out


# --------------------------------------------------------------------- sortie
@dataclass
class LigneCotisation:
    id: str
    famille: str
    libelle: str
    base: Decimal
    taux_pat: Optional[float]
    montant_pat: Decimal
    taux_sal: Optional[float]
    montant_sal: Decimal
    masquer_base_et_taux: bool = False


@dataclass
class Paie:
    engagement: Engagement
    salarie: dict
    spectacle: dict
    brut: Decimal
    base_csg: Decimal
    plafond: Decimal
    smic: float
    heures: Decimal
    lignes: list = field(default_factory=list)
    total_pat: Decimal = Decimal("0.00")
    total_sal: Decimal = Decimal("0.00")
    net_social: Decimal = Decimal("0.00")
    net_a_payer: Decimal = Decimal("0.00")
    net_imposable: Decimal = Decimal("0.00")
    cout_employeur: Decimal = Decimal("0.00")
    numero_bulletin: Optional[str] = None
    # Les lignes de REMUNERATION (le haut du bulletin), a ne pas confondre
    # avec `lignes`, qui sont les cotisations. Elles sont posees ici pour que
    # le bulletin et le contrat les LISENT au lieu de les redeviner depuis
    # `cachets` et `taux_cachet` -- ce qui perdait une journee de 5 h.
    remuneration: list = field(default_factory=list)
    # La reduction generale degressive unique, quand elle s'applique
    # (techniciens) : coefficient, montant et repartition -- ce que la DSN
    # declare. None pour un artiste.
    reduction_generale: Optional[dict] = None
    # La deduction forfaitaire specifique appliquee, quand la fiche l'exerce :
    # {"categorie", "taux", "assiette"}. None sinon.
    deduction_forfaitaire: Optional[dict] = None
    # Ce que le calcul a a dire sans refuser : un mecanisme suivi aux textes
    # mais jamais confronte a un bulletin reel. `apercu_mois` le remonte.
    avertissements: list = field(default_factory=list)

    def ligne(self, id_: str) -> Optional[LigneCotisation]:
        return next((l for l in self.lignes if l.id == id_), None)

    def resume(self) -> str:
        s = self.salarie
        e = self.engagement
        # Ce que porte le contrat, ligne par ligne : « 2 Cachets, 1 Journee
        # de travail ». Dire « 0 cachet(s) x 130,00 » d'une journee de 5 h
        # serait faux, et c'est ce que faisait cette ligne.
        quoi = ", ".join(l.designation for l in self.remuneration) or "sans ligne"
        return (f"{s['nom']} {s['prenom_affichage']} - {self.spectacle['titre']} - "
                f"{quoi} = {self.brut} brut, "
                f"net {self.net_a_payer}, cout employeur {self.cout_employeur}")


# ----------------------------------------------------------------- le calcul
# Les statuts que le corps du bareme calcule, quand il ne le dit pas lui-meme.
#
# Le corps d'un bareme decrit les ARTISTES : l'abattement de 30 % (arrete du
# 24/01/1975) n'y est pas applique comme un facteur qu'on pourrait retirer, il
# est CUIT dans les taux -- `rubriques_bulletin[atmp]` le dit en toutes
# lettres. Les autres statuts vivent dans `par_statut`, et y apportent leurs
# propres taux.
STATUTS_PAR_DEFAUT = ("artiste",)


def bareme_du_statut(bar: dict, statut: str) -> dict:
    """Le bareme applicable a ce statut, ou une erreur qui dit ce qui manque.

    TROIS ISSUES, ET LA TROISIEME EST LA RAISON D'ETRE DE CETTE FONCTION :

    1. Le statut est celui du corps du bareme (artiste) : on rend le bareme.
    2. `par_statut[statut]` existe ET se dit verifie ET ne porte aucun trou :
       on rend le bareme avec ses sections remplacees.
    3. Sinon : on LEVE, en nommant ce qui manque.

    Le troisieme cas couvre deux choses qu'on aurait tort de distinguer : le
    statut inconnu, et le statut connu mais dont les taux ne sont pas
    confirmes. Dans les deux cas le moteur ne SAIT pas, et produire donnerait
    des cotisations fausses a quelqu'un de reel. Un taux a `null` n'est donc
    pas un trou a combler par une valeur plausible -- c'est une question posee
    a un humain, et elle attend sa reponse.

    `_verifie: false` est volontairement separe des trous : un bareme peut
    etre complet et pas encore relu. Tant qu'il ne l'est pas, il ne paie
    personne.
    """
    statut = (statut or "").strip().lower()
    if not statut or statut in tuple(bar.get("statuts") or STATUTS_PAR_DEFAUT):
        return bar

    section = (bar.get("par_statut") or {}).get(statut)
    if not section:
        raise ValueError(
            "Statut '%s' : le bareme %s ne sait pas le calculer.\n"
            "  Il decrit les statuts %s. L'abattement de 30 %% sur les taux "
            "(arrete du 24/01/1975) ne vaut que pour les artistes, et il est "
            "cuit dans ces taux : s'en servir pour un autre statut donnerait "
            "des cotisations d'artiste a quelqu'un qui n'en est pas, sans que "
            "rien ne le signale.\n"
            "  Ajouter une section par_statut['%s'] au bareme."
            % (statut, bar.get("annee", "?"),
               ", ".join(bar.get("statuts") or STATUTS_PAR_DEFAUT), statut))

    trous = []
    for r in section.get("rubriques_bulletin") or []:
        if r.get("taux_pat") is None and r.get("taux_sal") is None \
                and not r.get("composants"):
            trous.append("%s (%s)" % (r.get("id"),
                                      r.get("_a_confirmer") or "taux absent"))
    if trous or not section.get("_verifie"):
        # On dit TOUT ce qui bloque, pas seulement le premier obstacle. Un
        # refus qui ne nomme qu'un trou fait croire qu'il suffit de le combler,
        # et on rebascule `_verifie` en pensant avoir fini.
        detail = []
        if trous:
            detail.append("%d rubrique(s) sans taux :\n    - %s"
                          % (len(trous), "\n    - ".join(trous)))
        absents = section.get("_mecanismes_absents") or []
        if absents:
            detail.append("%d mecanisme(s) que le moteur ne calcule pas :\n"
                          "    - %s" % (len(absents), "\n    - ".join(absents)))
        inferes = [r.get("id") for r in section.get("rubriques_bulletin") or []
                   if r.get("_infere")]
        if inferes:
            detail.append("taux INFERE, pas releve : %s" % ", ".join(inferes))
        raise ValueError(
            "Statut '%s', bareme %s : refus de payer.\n"
            "  %s\n  %s\n"
            "  Rien de tout cela ne se devine : un taux se releve (Urssaf, "
            "BOSS, fiche de parametrage Audiens, bulletin de reference), un "
            "mecanisme se decide. Tant que la section n'est pas marquee "
            "\"_verifie\": true par un humain, le moteur refuse."
            % (statut, bar.get("annee", "?"),
               section.get("_etat") or "Section non marquee verifiee.",
               "\n  ".join(detail) or "(rien de precis n'est signale)"))

    applique = dict(bar)
    for cle in ("rubriques_bulletin", "cotisations_dsn", "taux_chomage_aem",
                "reduction_generale"):
        if cle in section:
            applique[cle] = section[cle]
    return applique


# ------------------------------------------------------------ les cadres
def est_cadre(sal: dict) -> bool:
    """S21.G00.40.003 = 01 : cadre au sens de la retraite complementaire."""
    return str(sal.get("statut_categoriel_rc") or "").strip() == "01"


def bareme_cadre(bar: dict, sal: dict) -> dict:
    """Le bareme du statut, avec la surcouche cadre si la fiche le dit.

    Un cadre n'est pas un troisieme statut : la metteuse en scene de juin
    2025 est payee en artiste (taux abattus, cachets) ET en cadre (prevoyance
    et retraite cadres, Apec). La section `par_categorie.cadre` du bareme
    remplace des rubriques, en ajoute (T2, Apec, CET), et dit quoi declarer.
    Sans elle, un cadre est refuse : ses cotisations ne sont pas celles d'un
    non-cadre, et les calculer comme tel serait une paie fausse en silence.
    """
    if not est_cadre(sal):
        return bar
    sec = (bar.get("par_categorie") or {}).get("cadre")
    if not sec or not sec.get("_verifie"):
        raise ValueError(
            "Cadre (statut categoriel 01) : le bareme %s n'a pas de section "
            "par_categorie['cadre'] verifiee. Prevoyance, retraite et Apec "
            "d'un cadre ne sont pas celles d'un non-cadre." % bar.get("annee", "?"))
    applique = dict(bar)
    rubriques = []
    for r in bar["rubriques_bulletin"]:
        r = dict(r)
        if r["id"] in sec["rubriques"]:
            r.update(sec["rubriques"][r["id"]])
        rubriques.append(r)
    # Les ajouts se placent << apres >> une rubrique -- existante ou ajoutee
    # juste avant (T1, puis T2, puis Apec, puis CET), dans l'ordre du bareme.
    for a in sec.get("rubriques_ajoutees") or []:
        i = next((k for k, r in enumerate(rubriques) if r["id"] == a.get("apres")),
                 len(rubriques) - 1)
        rubriques.insert(i + 1, {k: v for k, v in a.items() if k != "apres"})
    applique["rubriques_bulletin"] = rubriques
    if "cotisation_prevoyance_retraite_supp" in sec:
        applique["cotisation_prevoyance_retraite_supp"] = sec["cotisation_prevoyance_retraite_supp"]
    dsn = sec.get("cotisations_dsn") or {}
    cots = []
    for c in bar["cotisations_dsn"]:
        c = dict(c)
        cle = c["code81"] if not c.get("affectation") else "%s:%s" % (c["code81"], c["affectation"])
        if cle in dsn:
            c.update({k: v for k, v in dsn[cle].items() if not k.startswith("_")})
        cots.append(c)
    applique["cotisations_dsn"] = cots
    applique["plafond_journalier"] = sec["plafond_journalier"]
    return applique


# ------------------------------------------- la reduction generale (RGDU)
FAMILLE_ALLEGEMENTS = "EXONÉRATIONS ET ALLÈGEMENTS DE COTISATIONS"


def reduction_generale(bar: dict, statut: str, brut: Decimal,
                       heures: Decimal) -> Optional[dict]:
    """La reduction generale degressive unique d'un contrat, ou None.

    Art. D. 241-7 CSS (version au 15/06/2026) :

        coefficient = Tmin + Tdelta x [ 1/2 x (3 x SMIC / remuneration - 1) ]^P

    arrondi a quatre decimales au dix-millieme le plus proche, nul des que la
    remuneration atteint 3 SMIC, et << pour les salaries en CDD aupres d'un
    meme employeur, le coefficient est determine pour chaque contrat >> --
    d'ou un calcul PAR CONTRAT, sans regularisation annuelle. Le SMIC de
    reference d'un contrat qui ne couvre pas le mois est corrige au prorata
    de ce qui est du : pour un intermittent paye a l'heure, SMIC horaire du
    1er janvier x heures remunerees. Les parametres (Tmin, Tdelta, P, SMIC
    gele) sont dans le bareme, section `reduction_generale`, avec leurs
    sources ; rien n'est ecrit ici.

    Les artistes n'y ont pas droit (taux abattus de 30 %) : la section dit
    a quels statuts elle s'applique, et la reponse est None pour les autres.
    """
    rg = bar.get("reduction_generale")
    if not rg or (statut or "artiste") not in (rg.get("statuts") or ()):
        return None
    if brut <= 0 or heures <= 0:
        return None
    smic_ref = eur(Decimal(str(rg["smic_horaire_reference"])) * heures)
    plafond = Decimal(str(rg.get("plafond_smic", 3)))
    if brut >= plafond * smic_ref:
        coefficient = Decimal("0")
    else:
        # Le crochet est borne a 1 : sous le SMIC de reference (ce qui ne
        # devrait pas arriver), la reduction est maximale, pas superieure.
        crochet = min(Decimal("1"),
                      (plafond * smic_ref / brut - 1) / 2)
        puissance = Decimal(str(rg["puissance"]))
        # Decimal ne sait pas elever a une puissance non entiere : on passe
        # par float pour ce seul terme, puis on arrondit comme le texte le
        # demande. Quatre decimales, l'erreur du float est loin derriere.
        terme = Decimal(str(float(crochet) ** float(puissance)))
        coefficient = (Decimal(str(rg["tmin"]))
                       + Decimal(str(rg["tdelta"])) * terme
                       ).quantize(Decimal("0.0001"))
    montant = eur(brut * coefficient)
    total_points = Decimal(str(rg["tmin"])) + Decimal(str(rg["tdelta"]))
    imput = rg.get("imputation") or {}
    chomage = eur(montant * Decimal(str(imput.get("chomage", 0))) / 100
                  / total_points) if montant else Decimal("0.00")
    agirc = eur(montant * Decimal(str(imput.get("agirc_arrco", 0))) / 100
                / total_points) if montant else Decimal("0.00")
    return {"coefficient": coefficient, "montant": montant,
            "smic_reference": smic_ref, "heures": heures,
            "urssaf": montant - chomage - agirc,
            "chomage": chomage, "agirc_arrco": agirc}


def deduction_forfaitaire(bar: dict, sal: dict) -> Optional[dict]:
    """La DFS que la fiche exerce, ou None.

    `deduction_forfaitaire` de la fiche : "" (aucune, le cas de tous les
    salaries de la compagnie), "20" ou "25" -- la CATEGORIE de depart, dont
    le taux de l'annee se lit dans le bareme (16 et 18 % en 2026, en
    extinction jusqu'en 2032). On stocke la categorie et non le taux : c'est
    elle qui ne bouge pas d'une annee sur l'autre.
    """
    cat_ = str(sal.get("deduction_forfaitaire") or "").strip()
    if not cat_:
        return None
    dfs = bar.get("deduction_forfaitaire")
    if not dfs or cat_ not in (dfs.get("taux") or {}):
        raise ValueError(
            "Deduction forfaitaire '%s' : le bareme %s n'en connait pas le "
            "taux. Categories connues : %s." % (
                cat_, bar.get("annee", "?"),
                ", ".join((dfs or {}).get("taux") or {}) or "aucune"))
    return {"categorie": cat_, "taux": Decimal(str(dfs["taux"][cat_])),
            "rubriques": tuple(dfs.get("rubriques_abattues") or ())}


def emploi_de(sal: dict, eng: Engagement) -> dict:
    """La fiche salarie telle qu'elle vaut POUR CET ENGAGEMENT.

    Ce que l'engagement dit l'emporte ; ce qu'il ne dit pas vient de la fiche.
    On rend un dictionnaire complet plutot que quatre valeurs parce que tout
    ce qui suit -- la DSN, l'AEM, le bulletin, le contrat, la DPAE, le
    certificat Conges Spectacles -- lit `paie.salarie[...]`. Poser la
    substitution ICI, une fois, evite de la repeter dans six modules et d'en
    oublier un : celui qu'on oublierait declarerait l'autre metier.
    """
    pris = {c: getattr(eng, c) for c in
            ("emploi", "pcs_ese", "code_emploi_ft", "statut",
             "statut_conventionnel", "statut_categoriel_rc")
            if getattr(eng, c)}
    return dict(sal, **pris) if pris else sal


def calculer(ctx: Contexte, eng: Engagement) -> Paie:
    sal = emploi_de(ctx.salarie(eng.salarie), eng)
    spec = ctx.spectacle(eng.spectacle)
    # Le bareme et le SMIC de la PERIODE PAYEE, pas de la fin du contrat : un
    # contrat de decembre a fevrier se paie en decembre au bareme de
    # decembre. Sur un contrat qui tient dans son mois, c'est `fin`.
    bar = ctx.bareme(eng.fin_periode)

    # LE BAREME CONTRE LE STATUT, et c'est un refus, pas un avertissement.
    #
    # Jusqu'ici `statut` n'etait lu nulle part dans ce fichier. Un engagement
    # << technicien >> ne se calculait donc pas faux : il se calculait avec le
    # MAUVAIS BAREME, en silence, et partait en DSN. C'est la faute que la
    # regle 1 de CLAUDE.md interdit -- le moteur refuse de produire plutot que
    # d'inventer -- et elle etait d'autant plus dangereuse qu'elle ne
    # ressemblait pas a une invention : les nombres tombaient, ils etaient
    # simplement ceux d'un autre metier.
    bar = bareme_du_statut(bar, sal.get("statut"))
    bar = bareme_cadre(bar, sal)

    # Un contrat peut meler cachets et heures : l'AEM les compte dans deux
    # champs distincts ([653:655] et [650:653]).
    #
    # CoolPaie calcule les cotisations RUBRIQUE PAR RUBRIQUE, arrondit chaque
    # ligne, puis somme : verifie sur le bulletin 27/2026 (1 cachet a 130 EUR
    # + 12 h a 20 EUR), ou le calcul global donne 1 centime de plus.
    # Invisible sur un contrat pur cachets, qui n'a qu'une seule rubrique.
    # `calculer` ne touche plus a l'engagement : il le LIT. Les nombres que la
    # declaration compte sont poses par l'engagement lui-meme, a sa
    # construction (voir Engagement.__post_init__).
    lb = lignes_brut(eng, ctx)
    rubriques = [l.montant for l in lb if l.soumis]
    brut = sum(rubriques, Decimal("0.00"))

    # Assiette CSG = 98,25 % du brut + part patronale de prevoyance, calculee
    # par rubrique elle aussi. Les cotisations CSG, elles, se calculent une
    # seule fois sur cette assiette agregee.
    prev = next(r for r in bar["rubriques_bulletin"] if r["id"] == "prevoyance")
    taux_prev = Decimal(str(prev["taux_pat"]))
    # LA PART PATRONALE DE PREVOYANCE ENTRE DANS L'ASSIETTE CSG SANS ETRE
    # ARRONDIE : arrondi(brut x 0,9825 + brut x taux), en une fois. Trouve le
    # 13/09/2026 sur le bulletin CoolPaie 31/2026 (cadre, 250 EUR, prevoyance
    # sur 220) : 245,625 + 3,718 = 249,343 -> 249,34, la ou deux arrondis
    # donnaient 249,35. Verifie sur l'historique : 130 -> 127,725 + 1,352 =
    # 129,08 (juin 2025), 320 -> 319,58, 260 -> 258,34 ; le rejeu 2026 est
    # identique. Pour un cadre, la prevoyance est sur la T1 journaliere,
    # pas sur le brut : sa part se calcule sur cette assiette-la, ventilee
    # au prorata des rubriques de salaire.
    plafond_prev = None
    if prev.get("base") == "t1_journaliere" and bar.get("plafond_journalier"):
        plafond_prev = eur(Decimal(str(bar["plafond_journalier"])) * eng.jours)

    def _assiettes(montant):
        base_prev = montant
        if plafond_prev is not None and brut > 0:
            base_prev = min(brut, plafond_prev) * montant / brut
        return {"brut": montant,
                "csg": eur(montant * Decimal(str(bar["abattement_csg"]))
                           + base_prev * taux_prev / 100),
                "brut_x115": eur(montant * Decimal(str(bar["majoration_conges_115"]))),
                "brut_x110": eur(montant * Decimal(str(bar["majoration_conges_110"])))}

    par_rubrique = [_assiettes(m) for m in rubriques]
    base_csg = sum((b["csg"] for b in par_rubrique), Decimal("0.00"))

    # LA DEDUCTION FORFAITAIRE SPECIFIQUE, si la fiche l'exerce : une assiette
    # abattue pour les cotisations de securite sociale et celles qui suivent
    # leur assiette (liste dans le bareme), calculee rubrique par rubrique
    # comme le reste. Chomage, CSG et le brut lui-meme ne bougent pas.
    dfs = deduction_forfaitaire(bar, sal)
    if dfs:
        for b in par_rubrique:
            b["brut_dfs"] = eur(b["brut"] * (1 - dfs["taux"] / 100))

    # Plafond declare en DSN : SMIC horaire x 7 h par cachet.
    smic = ctx.smic(eng.fin_periode)
    # Heures servant au plafond declare en DSN (S21.G00.79.004) :
    #     min(heures equivalentes des annexes, 7 h x jours travailles)
    # Les heures equivalentes viennent des rubriques : 12 h pour un cachet
    # (annexe X, art. 3), les heures faites pour une rubrique horaire. Les
    # JOURS, eux, ne viennent d'aucune rubrique -- ce sont les jours
    # travailles, une saisie. Sur un contrat pur, jours = cachets et le second
    # terme l'emporte : on retrouve les 7 h par cachet. Verifie sur mars, mai,
    # juillet et aout 2026 (contrats mixtes) et sur tous les contrats purs.
    hpc = Decimal(str(bar["heures_par_cachet"]))
    heures_annexes = sum((l.heures_annexes for l in lb), Decimal("0"))
    heures = min(heures_annexes, hpc * eng.jours)
    plafond = eur(Decimal(str(smic)) * heures)

    bases = {
        "brut": brut,
        "csg": base_csg,
        "brut_x115": sum((b["brut_x115"] for b in par_rubrique), Decimal("0.00")),
        "brut_x110": sum((b["brut_x110"] for b in par_rubrique), Decimal("0.00")),
    }
    # LES TRANCHES JOURNALIERES DES CADRES (Audiens, Parametres 2026 p. 2) :
    # T1 = 220 EUR x jours travailles, T2 = 7 x T1 au-dela ; l'Apec sur
    # T1 x 4 ; la CET sur tout si le salaire depasse T1. Assiettes GLOBALES
    # du contrat, pas par rubrique de salaire : un plafond se compare au
    # total. Pour un non-cadre elles ne servent a rien et ne sont pas lues.
    if bar.get("plafond_journalier"):
        t1 = eur(Decimal(str(bar["plafond_journalier"])) * eng.jours)
        bases["t1_journaliere"] = min(brut, t1)
        bases["t2_journaliere"] = max(Decimal("0.00"), min(brut, 8 * t1) - t1)
        bases["apec"] = min(brut, 4 * t1)
        bases["cet"] = brut if brut > t1 else Decimal("0.00")
    GLOBALES = ("csg", "t1_journaliere", "t2_journaliere", "apec", "cet")

    if dfs:
        bases["brut_dfs"] = sum((b["brut_dfs"] for b in par_rubrique), Decimal("0.00"))

    lignes, tot_pat, tot_sal = [], Decimal("0.00"), Decimal("0.00")
    for r in bar["rubriques_bulletin"]:
        cle_base = r["base"]
        if dfs and cle_base == "brut" and r["id"] in dfs["rubriques"]:
            cle_base = "brut_dfs"
        base = bases[cle_base]
        # Sur le brut : une fois par rubrique de salaire, chaque montant
        # arrondi, puis somme. Sur l assiette CSG : une seule fois.
        assiettes = ([base] if cle_base in GLOBALES
                     else [b[cle_base] for b in par_rubrique])
        m_pat = m_sal = Decimal("0.00")
        taux_pat, taux_sal = r["taux_pat"], r["taux_sal"]
        comp_pat, comp_sal = r.get("composants_pat"), r.get("composants_sal")
        cet = r.get("cet_si_depasse")
        if cet and bases.get("cet"):
            # LA CET DES CADRES, fondue dans les lignes T1 et T2 quand le brut
            # depasse la T1 -- c'est ainsi que CoolPaie l'imprime (bulletin
            # 31/2026 : 5,440 = 3,94 + 1,29 + 0,21), et l'arrondi se fait en
            # deux parts : la retraite, puis CEG + CET ensemble.
            comp_pat = list(comp_pat or [taux_pat]); comp_pat[-1] += cet["pat"]
            comp_sal = list(comp_sal or [taux_sal]); comp_sal[-1] += cet["sal"]
            taux_pat = round(taux_pat + cet["pat"], 3)
            taux_sal = round(taux_sal + cet["sal"], 3)
        for a in assiettes:
            if r.get("composants"):
                # Contributions arrondies separement, affichees en une ligne.
                m_pat += sum((pct(a, t) for t in r["composants"]), Decimal("0.00"))
            elif comp_pat:
                m_pat += sum((pct(a, t) for t in comp_pat), Decimal("0.00"))
            elif taux_pat is not None:
                m_pat += pct(a, taux_pat)
            if comp_sal:
                m_sal += sum((pct(a, t) for t in comp_sal), Decimal("0.00"))
            elif taux_sal is not None:
                m_sal += pct(a, taux_sal)
        lignes.append(LigneCotisation(
            id=r["id"], famille=r["famille"], libelle=r["libelle"], base=base,
            taux_pat=taux_pat, montant_pat=m_pat,
            taux_sal=taux_sal, montant_sal=m_sal,
            masquer_base_et_taux=r.get("masquer_base_et_taux", False)))
        tot_pat += m_pat
        tot_sal += m_sal

    lignes = [l for l in lignes
              if not (l.base == 0 and l.montant_pat == 0 and l.montant_sal == 0
                      and l.id in ("retraite_t2", "apec_t2"))]

    avertissements = []
    if dfs:
        avertissements.append(
            "%s %s : deduction forfaitaire specifique de %s %% exercee "
            "(categorie %s %%). Le calcul suit les textes, il n'a jamais ete "
            "confronte a un bulletin reel : prevoyance, Conges Spectacles et "
            "CASC restent sur le brut. A verifier sur le premier bulletin."
            % (sal["nom"], sal.get("prenom_affichage") or sal.get("prenom", ""),
               dfs["taux"], dfs["categorie"]))

    # LA REDUCTION GENERALE, apres les cotisations : une ligne negative cote
    # employeur, calculee sur le brut et les heures remunerees du contrat.
    rg = reduction_generale(bar, sal.get("statut"), brut, heures_annexes)
    if rg and rg["montant"]:
        lignes.append(LigneCotisation(
            id="reduction_generale", famille=FAMILLE_ALLEGEMENTS,
            libelle="Réduction générale dégressive unique",
            base=brut, taux_pat=None, montant_pat=-rg["montant"],
            taux_sal=None, montant_sal=Decimal("0.00"),
            masquer_base_et_taux=True))
        tot_pat -= rg["montant"]

    net = brut - tot_sal
    csg_nd = next(l.montant_sal for l in lignes if l.id == "csg_crds_nd")

    return Paie(
        engagement=eng, salarie=sal, spectacle=spec,
        brut=brut, base_csg=base_csg, plafond=plafond, smic=smic, heures=heures,
        lignes=lignes, total_pat=tot_pat, total_sal=tot_sal,
        net_social=net, net_a_payer=net, net_imposable=net + csg_nd,
        cout_employeur=brut + tot_pat, remuneration=lb,
        reduction_generale=rg, deduction_forfaitaire=dfs,
        avertissements=avertissements)


def numeroter(ctx: Contexte, paies: list, annee: int) -> None:
    """Attribue numeros de contrat (PU1.26.13) et de bulletin (17/2026).

    Un engagement qui PORTE DEJA son numero de contrat le garde : c'est le
    cas d'un mois produit (`produire_mois` le fige dans la saisie) et d'un
    contrat en cours depuis un mois precedent, qui doit partir en DSN sous
    le numero declare la premiere fois (S21.G00.40.009 identifie le
    contrat). Les numeros de bulletin, eux, se reservent toujours : un
    bulletin est mensuel.
    """
    n_bull = ctx.prochain("bulletin", annee)
    seqs = {}
    for p in paies:
        s = p.salarie
        # Un mois sans cachet n'a pas de bulletin : rien n'est paye, aucun
        # numero de bulletin ne se reserve. Le numero de CONTRAT, lui, se
        # prend comme pour les autres si le contrat commence ce mois-ci.
        if p.engagement.sans_paie:
            if not p.engagement.numero:
                cle = f"contrat_{s['_cle']}"
                seqs[cle] = seqs[cle] + 1 if cle in seqs else ctx.prochain(cle, annee)
                p.engagement.numero = (f"{s['initiales_contrat']}{s['code_salarie']}"
                                       f".{str(annee)[2:]}.{seqs[cle]:02d}")
            continue
        if not p.engagement.numero:
            cle = f"contrat_{s['_cle']}"
            if cle not in seqs:
                seqs[cle] = ctx.prochain(cle, annee)
            else:
                seqs[cle] += 1
            p.engagement.numero = (f"{s['initiales_contrat']}{s['code_salarie']}"
                                   f".{str(annee)[2:]}.{seqs[cle]:02d}")
        p.numero_bulletin = f"{n_bull}/{annee}"
        n_bull += 1
    ctx.enregistrer_compteur("bulletin", annee, n_bull - 1)
    for cle, v in seqs.items():
        ctx.enregistrer_compteur(cle, annee, v)
