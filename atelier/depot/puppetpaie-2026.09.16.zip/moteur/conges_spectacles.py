"""Certificat d'emploi Conges Spectacles - le papier du a chaque salarie.

Ce n'est pas une declaration : depuis la DSN, il n'y a plus rien a envoyer a
Audiens (la cotisation de 15,50 % part dans le bloc S21.G00.78 type 27). Ce
document-ci ne va nulle part ailleurs que dans les mains du salarie, a qui il
sert a reclamer ses conges payes. Audiens : « Les certificats d'emploi que
vous delivrez ont valeur de cheque emis sur votre compte aux Conges
spectacles. » D'ou la prudence sur la numerotation, plus bas.

Un certificat par contrat, remis a la fin du contrat, plus une coupure au
31 mars (la periode de reference des conges va du 1er avril au 31 mars).

CE MODULE NE MET PAS EN PAGE, IL REMPLIT UN FORMULAIRE
------------------------------------------------------
C'est un imprime reglementaire, pas un document de la compagnie : ni charte,
ni logo, ni police maison. Tous les salaries en recoivent depuis des annees,
toujours identique, et un employeur qui le redessine a sa sauce sort un papier
que personne ne reconnait. Le fond et les libelles sont donc **recopies au
point pres** sur un vrai certificat edite sur papier blanc :

    reference/exemples/CERTIFICAT CS - Les Ateliers Frappaz - 2026-01-16.pdf

Chaque coordonnee de `FOND`, `TRAITS` et `CASES` a ete relevee dans ce PDF
(`page.get_text("dict")`, champ `origin` = ligne de base, et
`page.get_drawings()` pour les traits). Times pour le fond, Courier pour les
valeurs saisies, exactement comme l'original. On dessine directement sur la
page : pas de HTML, pas de Story, rien qui puisse deplacer une case d'un
millimetre au prochain changement de moteur de rendu.

Deux choix a connaitre :

* **On ne repart pas du vierge de CoolPaie** (`affichage/CS_vide.pdf`,
  `affichage/cs3.pdf`). Ce sont 59 fragments d'image sans une lettre de texte,
  et surtout c'est une version **perimee** du formulaire : elle porte encore
  « 7, rue du Helder 75440 PARIS Cedex 09 », `www.conges-spectacles.org`, le
  minitel « 3614 HELDER » et le « Tel. 01 48 24 73 16 ». Audiens est a Vanves
  depuis, et le numero des intermittents est le 0 173 173 434.

* **Le « SIL1 » du certificat Frappaz n'est pas reproduit** : c'est du texte
  BLANC sur un rectangle BLANC (couleur 16777215), invisible a l'impression.
  Un marqueur interne de l'emetteur, pas une mention du formulaire.

Voir CONGES-SPECTACLES.md pour les sources, l'obligation et ce qui reste
ouvert.
"""
from __future__ import annotations
import datetime as _dt
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import pymupdf

from .contexte import GABARITS
from .util import d

IDENTITE = GABARITS / "identite"
SIGNATURE = IDENTITE / "signature.png"

# Polices de base PDF, celles de l'original : Times pour le fond imprime,
# Courier pour tout ce que le logiciel remplit.
TIMES = "tiro"
TIMES_GRAS = "tibo"
COURIER = "cour"

# Le certificat Frappaz place la signature manuscrite en Rect(457.7, 771.8,
# 494.2, 822.0) : elle demarre AU-DESSUS du libelle « Signature », comme une
# vraie signature posee a la main en travers de la case. La notre est un
# tampon a l'italienne : meme coin, largeur bornee pour ne pas courir sous le
# repere d'angle a x=528. Remontee de 0,3 cm par rapport a la ligne de base du
# libelle (09/09/2026) : la demande était de 0,7, mais a cette hauteur le
# tampon recouvre le nom du signataire -- ce qu'une signature manuscrite,
# ajouree, se permet sans genre.
SIGNATURE_CADRE = pymupdf.Rect(441.84, 775.50, 521.84, 809.10)


# ---------------------------------------------------------------------- fond
# (x, ligne_de_base, texte, police, corps) - releve tel quel sur l'original.
FOND = [
    # Bandeau d'en-tete
    (48.96, 441.12, "CERTIFICAT D'EMPLOI", TIMES_GRAS, 10.08),
    (48.96, 453.12, "DESTINÉ AU SALARIÉ", TIMES_GRAS, 10.08),
    (212.16, 441.84, "LES CONGES SPECTACLES", TIMES_GRAS, 13.92),
    (219.36, 453.12, "Audiens TSA 30400 92177 Vanves Cedex", TIMES_GRAS, 10.08),
    (435.12, 441.36, "Information des Intermittents", TIMES, 9.12),
    (456.48, 453.36, "www.audiens.org", TIMES, 9.12),
    (450.48, 474.24, "Tél. : 0 173 173 434", TIMES, 9.12),
    (382.32, 484.32, "de 9h30 à 18 h : accueil sur place et téléphone",
     TIMES, 9.12),
    # Notice au salarie
    (49.92, 504.24,
     "Si vous n'êtes pas inscrit à notre Caisse, contactez-nous à "
     "l'adresse ci-dessus mentionnée afin que nous procédions à "
     "votre immatriculation.", TIMES_GRAS, 7.92),
    (48.00, 513.36,
     "Votre demande de congé doit être adressée chaque année, "
     "quinze jours au moins avant votre départ en congé, dûment "
     "complétée et signée. Votre formulaire de", TIMES, 7.92),
    (48.00, 522.48,
     "demande de congé vous sera adressé automatiquement chaque "
     "début d'année en même temps que les sommes à "
     "déclarer à l'administration fiscale. Si tel n'est", TIMES, 7.92),
    (48.00, 531.83,
     "pas le cas, vous pouvez le demander par courrier ou 24h/24h : sur notre "
     "site internet ou notre serveur vocal téléphonique.", TIMES, 7.92),
    (48.00, 540.95,
     "La loi n°2004-801 du 6 août 2004 relative à la protection "
     "des personnes physiques à l'égard des traitements  de "
     "données à caractère personnel s'applique aux", TIMES, 7.92),
    (48.00, 550.07,
     "informations portées sur ce certificat. Elle garantit un droit "
     "d'accès et de rectification auprès du service Information des "
     "Intermittents.", TIMES, 7.92),
    # Libelles des cases
    (48.00, 579.84, "N° SIRET", TIMES, 13.92),
    (253.92, 579.84, "COMPTE", TIMES, 13.92),
    (431.04, 579.84, "N° CE", TIMES, 13.92),
    (54.96, 614.87, "NIR", TIMES, 13.92),
    (58.08, 633.36, "NOM DE NAISSANCE", TIMES, 7.92),
    (58.08, 643.44, "NOM D'USAGE", TIMES, 7.92),
    (57.84, 653.28, "EMPLOI", TIMES, 7.92),
    (57.84, 663.36, "CADRE", TIMES, 7.92),
    (318.96, 633.36, "PRENOM", TIMES, 7.92),
    (318.96, 643.44, "PSEUDONYME", TIMES, 7.92),
    (157.44, 683.28, " DATES DE TRAVAIL", TIMES, 10.08),
    (396.96, 683.28, "    NB JOURS OU CACHETS", TIMES, 10.08),
    (51.84, 704.88, "DEBUT", TIMES, 13.92),
    (234.96, 704.88, "FIN", TIMES, 13.92),
    (70.80, 737.76, "BASE CONGE", TIMES, 13.92),
    (72.00, 747.36, "Arrondie à l'euro le plus proche", TIMES, 7.92),
    (318.96, 737.76, "SALAIRE BRUT", TIMES, 13.92),
    (318.96, 747.36, "Arrondi à l'euro le plus proche", TIMES, 7.92),
    (354.96, 759.12, "Date :", TIMES, 10.08),
    (354.00, 771.12, "Nom du signataire", TIMES, 10.08),
    (354.96, 782.16, "Signature", TIMES, 10.08),
]

# Traits : reperes d'angle (3,12 pt), traits de pliage et filets encadrant
# « DATES DE TRAVAIL » (0,24 pt).
TRAITS = [
    # reperes d'angle
    (40.80, 419.28, 63.84, 419.28, 3.12),
    (42.48, 441.84, 42.48, 418.80, 3.12),
    (530.88, 419.28, 553.92, 419.28, 3.12),
    (552.48, 440.88, 552.48, 417.84, 3.12),
    (40.80, 800.40, 63.84, 800.40, 3.12),
    (42.48, 801.84, 42.48, 778.80, 3.12),
    (528.96, 800.40, 552.00, 800.40, 3.12),
    (551.28, 801.84, 551.28, 778.80, 3.12),
    # traits de pliage (enveloppe a fenetre)
    (18.96, 279.84, 38.88, 279.84, 0.24),
    (554.88, 279.84, 574.80, 279.84, 0.24),
    # filets de part et d'autre de « DATES DE TRAVAIL »
    (48.96, 678.96, 148.80, 678.96, 0.24),
    (258.96, 678.96, 358.80, 678.96, 0.24),
]

# Position de chaque valeur remplie : (x, ligne_de_base, police, corps).
CASES = {
    "dest_nom":      (322.80, 157.20, TIMES_GRAS, 10.08),
    "dest_adresse":  (322.80, 173.28, TIMES, 10.08),
    "dest_commune":  (322.80, 189.12, TIMES, 10.08),
    "dest_pays":     (322.80, 221.28, TIMES, 10.08),
    "siret":         (123.60, 579.60, COURIER, 13.92),
    "compte":        (338.40, 579.60, COURIER, 13.92),
    "num_ce":        (503.52, 579.60, COURIER, 13.92),
    "nir":           (112.80, 614.64, COURIER, 13.92),
    "raison_sociale": (318.96, 614.64, COURIER, 13.92),
    "nom_naissance": (174.00, 633.36, TIMES, 7.92),
    "nom_usage":     (174.00, 643.44, TIMES, 7.92),
    "emploi":        (174.00, 653.28, TIMES, 7.92),
    "cadre":         (174.00, 663.36, TIMES, 7.92),
    "prenom":        (390.00, 633.36, TIMES, 7.92),
    "pseudonyme":    (390.00, 643.44, TIMES, 7.92),
    "debut":         (126.00, 704.64, COURIER, 13.92),
    "fin":           (266.88, 704.64, COURIER, 13.92),
    "nb_cachets":    (457.44, 704.64, COURIER, 13.92),
    "base_conge":    (248.64, 737.52, COURIER, 13.92),
    "salaire_brut":  (470.64, 737.52, COURIER, 13.92),
    "date":          (441.84, 758.16, COURIER, 10.08),
    "signataire":    (441.84, 771.12, COURIER, 10.08),
    # Le numero d'agrement se compose avec son libelle, en Times : sur
    # l'original les deux ne font qu'une seule chaine a cette position.
    "agrement":      (105.12, 781.68, TIMES, 10.08),
}

# Bord droit a ne pas depasser, quand la case a un voisin. Le formulaire a ete
# dessine pour les valeurs d'un autre employeur : le compte de Frappaz tenait
# en 9 caracteres, notre numero d'adherent en fait 11 et venait coller le
# libelle « N° CE ». Plutot que deborder en silence, on reduit le corps de la
# case juste ce qu'il faut (`_poser`).
LIMITES = {
    "siret": 253.92,          # libelle COMPTE
    "compte": 431.04,         # libelle N° CE
    "num_ce": 549.00,         # repere d'angle droit
    "nir": 318.96,            # raison sociale
    "raison_sociale": 549.00,
    "nom_naissance": 318.96,  # libelle PRENOM
    "nom_usage": 318.96,
    "emploi": 318.96,
    "cadre": 318.96,
    "prenom": 549.00,
    "pseudonyme": 549.00,
    "debut": 234.96,          # libelle FIN
    "fin": 396.96,            # libelle NB JOURS OU CACHETS
    "nb_cachets": 549.00,
    "base_conge": 318.96,     # libelle SALAIRE BRUT
    "salaire_brut": 549.00,
    "date": 549.00,
    "signataire": 549.00,
}

# Blanc laisse entre une valeur et son voisin de droite.
RESPIRATION = 3.0


# ------------------------------------------------------------------ chiffres
def arrondi_euro(x) -> int:
    """Arrondi a l'euro le plus proche, moitie superieure.

    Le formulaire le dit lui-meme, en toutes lettres sous les deux cases :
    « Arrondi a l'euro le plus proche ». Ce n'est pas l'arrondi au centime de
    `util.eur` : les cases SALAIRE BRUT et BASE CONGE ne portent pas de
    decimales.
    """
    return int(Decimal(str(x)).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def base_conge(brut, salarie: dict) -> Decimal:
    """Base de calcul de l'indemnite de conge, avant arrondi.

    Elle vaut le brut. Le mode d'emploi employeur (Audiens, avril 2023) decrit
    le salaire a declarer comme « la remuneration brute versee au salarie au
    titre du contrat de travail effectue [...] avant toute deduction
    forfaitaire specifique pour frais professionnels et toute retenue », et
    les deux cases sont egales sur les deux certificats reels que nous avons
    (Frappaz : 200 et 200 ; extranet Audiens : 260 et 260).

    Une seule reserve, prevue par le reglement : « Si la convention collective
    applicable dans l'entreprise definit un salaire minimum, l'entreprise peut
    plafonner la base de calcul au triple du montant du salaire minimum de la
    categorie professionnelle concernee. » Sur des cachets a 130 EUR, aucun
    plafonnement n'est possible, et nous n'avons pas releve le minimum de la
    categorie a l'IDCC 3090. Le plafond ne s'applique donc que si la fiche du
    salarie porte `minimum_conventionnel_cachet` : tant qu'il est absent, on
    n'invente pas de chiffre, on ecrit le brut.
    """
    brut = Decimal(str(brut))
    mini = salarie.get("minimum_conventionnel_cachet")
    if mini:
        return min(brut, Decimal(str(mini)) * 3)
    return brut


# ------------------------------------------------------- decoupage au 31 mars
def bornes_31_mars(debut, fin) -> list:
    """Les 31 mars strictement traverses par un contrat."""
    debut, fin = d(debut), d(fin)
    return [b for b in (_dt.date(an, 3, 31)
                        for an in range(debut.year, fin.year + 1))
            if debut <= b < fin]


def decouper(eng) -> list:
    """Un contrat -> une ou plusieurs periodes de certificat.

    La periode de reference des conges va du 1er avril au 31 mars. Une
    activite en cours au 31 mars donne donc DEUX certificats : celui de la
    periode qui s'arrete au 31 mars, remis avant le depart en conge, et celui
    de la periode ouverte le 1er avril, remis a la fin de l'emploi.

    Nos contrats sont courts et n'en croisent aucun aujourd'hui. Le decoupage
    est ecrit quand meme, et volontairement strict : des qu'il faudrait
    repartir autre chose que des cachets dates -- des heures, ou un nombre de
    cachets qui ne colle pas aux dates travaillees -- on refuse plutot que de
    repartir au juge un document qui vaut cheque sur notre compte.

    Renvoie une liste de (debut, fin, dates_travail, nb, jours), ou `nb` est
    ce que le formulaire appelle « NB JOURS OU CACHETS » : les cachets quand
    il y en a, les jours travailles sinon. Un contrat d'une journee de 5 h
    n'a aucun cachet, et la case ne peut pas porter zero -- c'est elle qui
    dit ce qui est du.
    """
    bornes = bornes_31_mars(eng.debut, eng.fin)
    if not bornes:
        return [(eng.debut, eng.fin, list(eng.dates_travail),
                 eng.cachets or eng.jours, eng.jours)]

    if eng.heures:
        raise ValueError(
            "Contrat %s a cheval sur le 31 mars ET porteur d'heures (%s h) : "
            "les heures ne sont pas datees, le moteur ne sait pas les repartir "
            "entre les deux periodes de conges. Scinder le contrat en deux "
            "engagements dans le fichier de paie."
            % (eng.numero or "sans numero", eng.heures))
    if eng.cachets != len(eng.dates_travail) or eng.jours != len(eng.dates_travail):
        raise ValueError(
            "Contrat %s a cheval sur le 31 mars : %d cachet(s) et %d jour(s) "
            "declares pour %d date(s) travaillee(s). La repartition entre les "
            "deux periodes de conges serait arbitraire. Scinder le contrat en "
            "deux engagements dans le fichier de paie."
            % (eng.numero or "sans numero", eng.cachets, eng.jours,
               len(eng.dates_travail)))

    periodes, debut = [], d(eng.debut)
    for borne in bornes + [d(eng.fin)]:
        dates = [x for x in eng.dates_travail if debut <= x <= borne]
        periodes.append((debut, borne, dates, len(dates), len(dates)))
        debut = borne + _dt.timedelta(days=1)
    return periodes


# -------------------------------------------------------------- le certificat
@dataclass
class Certificat:
    numero: int
    paie: object
    debut: _dt.date
    fin: _dt.date
    # La case du formulaire s'intitule « NB JOURS OU CACHETS » : elle porte
    # les cachets quand il y en a, les jours travailles sinon.
    nb_jours_ou_cachets: int
    brut: Decimal
    base: Decimal
    emission: _dt.date


def certificats(paie, premier_numero: int, date_emission=None) -> list:
    """Les certificats dus au titre d'une paie, dans l'ordre des periodes."""
    e = paie.engagement
    parts = decouper(e)
    out, numero = [], premier_numero
    for debut, fin, _dates, nb, _jours in parts:
        brut = (Decimal(str(paie.brut)) if len(parts) == 1
                else Decimal(str(e.taux_cachet)) * nb)
        out.append(Certificat(
            numero=numero, paie=paie, debut=debut, fin=fin,
            nb_jours_ou_cachets=nb,
            brut=brut, base=base_conge(brut, paie.salarie),
            emission=d(date_emission or fin)))
        numero += 1
    if len(parts) > 1:
        total = sum((c.brut for c in out), Decimal("0"))
        if total != Decimal(str(paie.brut)):
            raise ValueError(
                "Decoupage au 31 mars incoherent pour %s : %s EUR repartis "
                "pour un brut de %s EUR."
                % (e.numero or paie.salarie["nom"], total, paie.brut))
    return out


def nombre(paies: list) -> int:
    """Combien de numeros de certificat un mois va consommer."""
    return sum(len(decouper(p.engagement)) for p in paies)


# --------------------------------------------------------------------- rendu
def _cases_date(x) -> str:
    """16/01/2026 -> '16 01 2026', comme les cases du formulaire."""
    return d(x).strftime("%d %m %Y")


def _siret_espace(siret: str) -> str:
    """12345678900017 -> '123456789 00017' (siren, puis nic)."""
    s = str(siret)
    return "%s %s" % (s[:9], s[9:]) if len(s) == 14 else s


def valeurs(c: Certificat, ent: dict) -> dict:
    """Ce qui va dans chaque case, avant tout dessin.

    Isole pour etre relisible et testable sans produire un PDF.
    """
    s = c.paie.salarie
    sig = ent["signataire"]
    agrement = ent.get("congesspectacles_agrement") or ""
    return {
        "dest_nom": "%s %s" % (s["prenom"], s["nom"]),
        "dest_adresse": s.get("adresse_affichage", s["adresse"]),
        "dest_commune": "%s %s" % (s["code_postal"],
                                   s.get("commune_affichage", s["commune"])),
        "dest_pays": "France",
        "siret": _siret_espace(ent["siret"]),
        "compte": ent.get("congesspectacles_adherent") or "",
        "num_ce": str(c.numero),
        "nir": "%s %s" % (s["nir"], s["nir_cle"]),
        "raison_sociale": ent["raison_sociale"],
        "nom_naissance": s["nom"],
        "nom_usage": s.get("nom_usage") or "",
        "emploi": s["emploi"],
        "cadre": "OUI" if s.get("cadre") else "NON",
        "prenom": s["prenom"],
        "pseudonyme": s.get("pseudonyme") or "",
        "debut": _cases_date(c.debut),
        "fin": _cases_date(c.fin),
        "nb_cachets": str(c.nb_jours_ou_cachets),
        "base_conge": str(arrondi_euro(c.base)),
        "salaire_brut": str(arrondi_euro(c.brut)),
        "date": d(c.emission).strftime("%d/%m/%y"),
        "signataire": sig["nom"],
        # Le libelle existe sur le formulaire meme sans numero : l'original
        # vierge de CoolPaie porte « N° d'agrement : » suivi d'un blanc.
        "agrement": "N° d'agrément : %s" % agrement if agrement
                    else "N° d'agrément :",
    }


def corps_qui_tient(texte: str, champ: str) -> float:
    """Le corps a utiliser pour que la valeur tienne dans sa case.

    Rend le corps d'origine tant que la valeur y tient, un corps reduit sinon.
    Ne descend jamais en dessous de 6 pt : sous cette taille la case est de
    toute facon illisible, et c'est le signe que la donnee ne va pas.
    """
    x, _y, police, corps = CASES[champ]
    limite = LIMITES.get(champ)
    if not limite:
        return corps
    place = limite - RESPIRATION - x
    largeur = pymupdf.get_text_length(texte, fontname=police, fontsize=corps)
    if largeur <= place:
        return corps
    return max(6.0, corps * place / largeur)


def _dessiner(page, c: Certificat, ent: dict) -> None:
    """Pose le fond, les traits, puis les valeurs, sur une page vierge."""
    for x0, y0, x1, y1, epaisseur in TRAITS:
        page.draw_line(pymupdf.Point(x0, y0), pymupdf.Point(x1, y1),
                       color=(0, 0, 0), width=epaisseur)
    for x, y, texte, police, corps in FOND:
        page.insert_text(pymupdf.Point(x, y), texte, fontname=police,
                         fontsize=corps, color=(0, 0, 0))
    for champ, texte in valeurs(c, ent).items():
        if not texte:
            continue
        x, y, police, _corps = CASES[champ]
        page.insert_text(pymupdf.Point(x, y), texte, fontname=police,
                         fontsize=corps_qui_tient(texte, champ),
                         color=(0, 0, 0))
    if SIGNATURE.exists():
        page.insert_image(SIGNATURE_CADRE, filename=str(SIGNATURE))


def ecrire(paies: list, ent: dict, chemin, premier_numero: int,
           date_emission=None) -> Path:
    """Ecrit un PDF contenant un certificat d'emploi par page.

    `premier_numero` est le N° CE de depart : une sequence propre a
    l'employeur, dont Audiens delivre la premiere valeur (la notre commence a
    1, notifiee le 07/09/2026). Elle ne repart pas a zero chaque annee -- voir
    `Contexte.prochain_continu`.
    """
    if not ent.get("congesspectacles_adherent"):
        raise ValueError(
            "`congesspectacles_adherent` manquant dans config/entreprise.json : "
            "c'est le numero qui va dans la case COMPTE du certificat.")
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    doc = pymupdf.open()
    numero = premier_numero
    for p in paies:
        for c in certificats(p, numero, date_emission):
            numero = c.numero + 1
            _dessiner(doc.new_page(width=595.22, height=842.0), c, ent)
    doc.save(str(chemin), garbage=4, deflate=True, clean=True)
    doc.close()
    return chemin


def recapitulatif(paies: list, ent: dict, premier_numero: int,
                  date_emission=None) -> str:
    """Le meme contenu en texte : ce qui va etre imprime, et sous quels numeros.

    Les N° CE consommes ne se relisent pas dans un PDF ; ce recapitulatif est
    la trace a garder, comme celui de la DPAE.
    """
    lignes = ["Certificats d'emploi Conges Spectacles",
              "Compte (adherent Audiens) : %s"
              % (ent.get("congesspectacles_adherent") or "?"),
              "-" * 76]
    numero = premier_numero
    for p in paies:
        for c in certificats(p, numero, date_emission):
            numero = c.numero + 1
            lignes.append(
                "  N CE %-6d %-22s %s -> %s  %2d jour(s)/cachet(s)  brut %5d  base %5d"
                % (c.numero,
                   p.salarie["nom"] + " " + p.salarie["prenom_affichage"],
                   d(c.debut).strftime("%d/%m/%Y"),
                   d(c.fin).strftime("%d/%m/%Y"), c.nb_jours_ou_cachets,
                   arrondi_euro(c.brut), arrondi_euro(c.base)))
    lignes.append("-" * 76)
    lignes.append("A remettre au salarie a la fin de son contrat. Rien a envoyer a")
    lignes.append("Audiens : la cotisation part deja par la DSN (S21.G00.78 type 27).")
    return "\n".join(lignes) + "\n"
