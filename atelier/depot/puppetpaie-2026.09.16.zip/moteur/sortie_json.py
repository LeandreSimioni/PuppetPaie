"""Les resultats d'`operations`, en JSON -- pour l'interface et pour une API.

Une troisieme facon d'appeler le logiciel : ni un humain devant un terminal,
ni un humain devant une page, mais un PROGRAMME. C'est ce qui permettra a une
interface de parler au moteur, et a une API (Claude par l'API plutot que par
Claude Code) de faire une paie.

Le principe ne change pas d'un iota : le programme appelle `operations`, qui
porte les garde-fous. Ce module ne fait que traduire ce qu'`operations` a deja
decide. Il ne calcule rien, ne decide rien, et surtout **il n'a pas le droit
de rendre plus que ce que les autres faces montrent** -- sinon on aurait deux
verites.

Trois regles de forme, parce qu'un consommateur automatique n'a pas d'oeil :

  - **Les montants sont des chaines**, pas des flottants. `201.32` en flottant
    vaut 201.31999999999999 ; sur une paie, cela finit par se voir. Le moteur
    travaille en `Decimal` et le JSON garde la chaine exacte.
  - **Les dates sont en AAAA-MM-JJ**, jamais au format francais : c'est un
    format de donnees, pas d'affichage.
  - **Une erreur metier reste une reponse**, avec `ok: false` et de quoi la
    traiter. Un appelant automatique ne lit pas un message d'arret.
"""
from __future__ import annotations

import dataclasses
import datetime as _dt
from decimal import Decimal
from pathlib import Path


# ------------------------------------------------------------- la conversion
def brut(valeur, _racine: Path = None):
    """Rend un objet JSON-able : dataclasses, Decimal, Path, dates, listes."""
    if valeur is None or isinstance(valeur, (bool, int, str)):
        return valeur
    if isinstance(valeur, Decimal):
        return str(valeur)
    if isinstance(valeur, float):
        return valeur
    if isinstance(valeur, (_dt.date, _dt.datetime)):
        return valeur.isoformat()[:10]
    if isinstance(valeur, Path):
        return valeur.name
    if isinstance(valeur, dict):
        return {k: brut(v) for k, v in valeur.items() if not k.startswith("_")}
    if isinstance(valeur, (list, tuple, set)):
        return [brut(v) for v in valeur]
    if dataclasses.is_dataclass(valeur):
        return {f.name: brut(getattr(valeur, f.name))
                for f in dataclasses.fields(valeur)}
    return str(valeur)


def enveloppe(commande: str, resultat) -> dict:
    return {"commande": commande, "ok": True, "resultat": resultat}


def erreur(commande: str, exc: Exception, **extra) -> dict:
    """Une erreur metier est une reponse, pas un plantage.

    `type` porte le nom de la classe : c'est sur lui qu'un appelant branche
    son comportement (redemander le montant URSSAF, proposer d'autoriser
    Google, attendre que le verrou tombe), jamais sur le texte du message.
    """
    corps = {"type": type(exc).__name__, "message": str(exc)}
    corps.update({k: brut(v) for k, v in extra.items()})
    return {"commande": commande, "ok": False, "erreur": corps}


# ------------------------------------------------------------------- les vues
def salarie(p) -> dict:
    """Qui est paye. Le NIR n'y est PAS : rien ne le demande a ce niveau, et
    une sortie machine finit toujours par etre journalisee quelque part."""
    s = p.salarie
    return {"cle": s.get("_cle"), "nom": s["nom"],
            "prenom": s.get("prenom_affichage") or s["prenom"]}


def paie(p, lignes: bool = False) -> dict:
    e = p.engagement
    d = {
        "numero_bulletin": p.numero_bulletin,
        "numero_contrat": e.numero,
        "salarie": salarie(p),
        "spectacle": {"titre": p.spectacle["titre"],
                      "numero_objet": p.spectacle.get("numero_objet")},
        "debut": brut(e.debut), "fin": brut(e.fin),
        # Le contrat par rapport au mois : un contrat qui deborde n'a pas
        # de DPAE ni de contrat imprime hors de son premier mois, ni de
        # certificat CS avant son dernier. L'ecran le lit ici.
        "contrat": {"premier_mois": e.premier_mois, "dernier_mois": e.dernier_mois,
                    "a_cheval": e.a_cheval,
                    # Un mois du contrat sans cachet : DSN oui, bulletin non.
                    "sans_paie": e.sans_paie,
                    "depuis": e.mois_du_contrat[0], "jusqu_a": e.mois_du_contrat[-1],
                    "periode": {"debut": brut(e.debut_periode),
                                "fin": brut(e.fin_periode)}},
        "dates_travail": [brut(x) for x in e.dates_travail],
        "cachets": e.cachets, "taux_cachet": e.taux_cachet,
        "heures": e.heures,
        # Ce qui est paye, tel que le moteur l'a compris. `cachets` reste,
        # parce que l'AEM le declare -- mais un contrat d'une journee de 5 h
        # en a zero, et une page qui n'aurait que ce nombre afficherait
        # « 0 cachet(s) » d'un contrat de 200 EUR.
        "remuneration": [{"rubrique": l.code, "designation": l.designation,
                          "quantite": brut(l.quantite), "taux": brut(l.taux),
                          "montant": brut(l.montant)}
                         for l in p.remuneration],
        "jours": e.jours, "lieu": e.lieu,
        "brut": brut(p.brut), "base_csg": brut(p.base_csg),
        "plafond": brut(p.plafond), "smic": p.smic,
        "total_patronal": brut(p.total_pat), "total_salarial": brut(p.total_sal),
        "net_social": brut(p.net_social), "net_a_payer": brut(p.net_a_payer),
        "net_imposable": brut(p.net_imposable),
        "cout_employeur": brut(p.cout_employeur),
        # Ce que le moteur a a dire de CETTE paie -- minima conventionnels,
        # DFS -- pour qu'un ecran le pose sous le bon bloc.
        "avertissements": list(p.avertissements),
        "emploi": {"libelle": p.salarie.get("emploi"),
                   "code_emploi_ft": p.salarie.get("code_emploi_ft"),
                   "statut": p.salarie.get("statut"),
                   "cadre": p.salarie.get("statut_categoriel_rc") == "01"},
    }
    if lignes:
        d["lignes"] = [brut(l) for l in p.lignes]
    return d


def contrat_en_cours(c) -> dict:
    return {"salarie": c.salarie, "nom": c.nom, "spectacle": c.spectacle,
            "debut": c.debut, "fin": c.fin, "numero": c.numero,
            "depuis": c.depuis, "metier": c.metier, "cadre": c.cadre,
            "taux_cachet": c.taux_cachet, "lieu": c.lieu,
            "deja_repris": c.deja_repris}


def apercu(a, lignes: bool = False) -> dict:
    return {
        "mois": a.mois, "libelle": a.saisie.libelle,
        "paies": [paie(p, lignes) for p in a.paies],
        "total_brut": brut(a.total_brut), "total_cout": brut(a.total_cout),
        "urssaf_estimation": brut(a.urssaf_estimation),
        "urssaf_marge": brut(a.urssaf_marge),
        "avertissements": a.avertissements,
    }


def fichier(f: Path) -> dict:
    return {"nom": f.name, "chemin": str(f),
            "octets": f.stat().st_size if f.exists() else None}


def mois_produit(r) -> dict:
    return {
        "mois": r.saisie.mois, "libelle": r.saisie.libelle,
        "dossier": str(r.dossier),
        "paies": [paie(p) for p in r.apercu.paies],
        "total_brut": brut(r.apercu.total_brut),
        "total_cout": brut(r.apercu.total_cout),
        "urssaf": r.urssaf, "urssaf_estime": r.urssaf_estime,
        "envoi_test": r.envoi_test,
        "numeros": brut(r.numeros),
        "fichiers": [fichier(f) for f in r.fichiers],
        "avertissements": r.avertissements,
        "etapes": [brut(e) for e in r.etapes],
    }


def dpae_produite(r) -> dict:
    return {
        "mois": r.saisie.mois, "libelle": r.saisie.libelle,
        "dossier": str(r.dossier), "retard": r.retard,
        "lignes": [brut(l) for l in r.lignes],
        "fichiers": [fichier(f) for f in r.fichiers],
        "etapes": [brut(e) for e in r.etapes],
    }


def envoi_prepare(p) -> dict:
    """Ce qui PARTIRAIT. Rien n'est envoye par une sortie JSON : l'envoi
    demande une confirmation humaine, et un programme ne confirme pas."""
    return {
        "mois": p.saisie.mois, "expediteur": p.expediteur,
        "avertissements": p.avertissements,
        "messages": [{"cle": m.cle, "nom": m.nom, "destinataire": m.destinataire,
                      "sujet": m.sujet,
                      "pieces": [x.name for x in m.pieces],
                      "octets": m.taille()} for m in p.messages],
    }


def archivage(r) -> dict:
    return {"mois": r.mois, "racine_drive": r.racine_drive, "compte": r.compte,
            "fichiers": [brut(f) for f in r.fichiers]}


def position_droits(d) -> dict:
    p = d.position
    return {
        "salarie": {"cle": d.cle, "nom": d.salarie["nom"],
                    "prenom": d.salarie.get("prenom_affichage") or d.salarie["prenom"]},
        "fenetre": {"libelle": p.libelle_fenetre, "debut": brut(p.debut),
                    "fin": brut(p.fin),
                    "anniversaire_configure": brut(d.anniversaire),
                    "jours_restants": d.jours_restants},
        "cachets": p.cachets, "heures": p.heures,
        "heures_equivalentes": p.heures_equivalentes,
        # Deux totaux, parce qu'ils repondent a deux questions : ai-je mes 507
        # heures, et sur combien d'heures l'allocation sera-t-elle calculee.
        "heures_enseignement": p.heures_enseignement,
        "plafond_enseignement": p.plafond_enseignement,
        "heures_enseignement_retenues": p.heures_enseignement_retenues,
        "heures_ouverture": p.heures_ouverture,
        "heures_montant": p.heures_montant,
        "seuil_atteint": p.atteint, "manque": p.manque,
        "cachets_manquants": d.cachets_manquants,
        "colonnes": [brut(c) for c in d.colonnes],
    }


def importation(i) -> dict:
    """L'apercu ou le compte rendu d'un import CoolPaie. Les donnees des
    fiches a creer sont rendues telles quelles : c'est ce que l'ecran montre
    avant d'ecrire."""
    def _f(f):
        return None if f is None else {
            "nom": f.nom, "cle": f.cle, "libelle": f.libelle, "etat": f.etat,
            "ecarts": brut(f.ecarts), "anomalies": brut(f.anomalies),
            "donnees": brut(f.donnees)}
    return {"source": i.source, "dsn": i.dsn, "aem": i.aem,
            "premier_mois": i.premier_mois, "dernier_mois": i.dernier_mois,
            "entreprise": _f(i.entreprise),
            "salaries": [_f(f) for f in i.salaries],
            "spectacles": [_f(f) for f in i.spectacles],
            "contrats": i.contrats, "contrats_nouveaux": i.contrats_nouveaux,
            "contrats_du": i.contrats_du, "contrats_au": i.contrats_au,
            "contrats_sans_fiche": i.contrats_sans_fiche,
            "avertissements": list(i.avertissements),
            "rien_a_faire": i.rien_a_faire,
            "ecrit": i.ecrit, "fichiers": list(i.fichiers)}


def fiche(f) -> dict:
    """Les donnees de reference. Le NIR y EST : c'est la fiche d'identite, et
    l'interface doit pouvoir l'afficher pour le verifier. A ne pas journaliser."""
    return {
        "entreprise": {k: brut(v) for k, v in f.entreprise.items()
                       if not k.startswith("_")},
        "salaries": {k: brut(v) for k, v in f.salaries.items()},
        "spectacles": {k: brut(v) for k, v in f.spectacles.items()},
        # Les cles seules : de quoi dire qu'elles existent, sans les remettre
        # dans une liste ou l'on choisit qui l'on paie.
        "salaries_archives": sorted(f.salaries_archives),
        "spectacles_archives": sorted(f.spectacles_archives),
        "compteurs": f.compteurs,
    }


def etat_google(e) -> dict:
    return {"application": e.application, "permissions": e.permissions,
            "compte": e.compte, "autorise": bool(e.compte),
            "verifie": e.verifie}
