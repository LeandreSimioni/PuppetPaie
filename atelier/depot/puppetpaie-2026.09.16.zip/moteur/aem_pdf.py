"""AEM papier - l'attestation employeur mensuelle remise AU SALARIE.

A ne pas confondre avec `moteur/aem.py`, qui produit le fichier EDI V5 deposé
sur declarationspectacle.francetravail.fr. Ce sont deux sorties du meme
contrat, pour deux destinataires : le fichier part a France Travail, ce
formulaire-ci va dans les mains de l'artiste. Le formulaire le dit lui-meme,
en tete : « À REMPLIR PAR L'EMPLOYEUR ET À REMETTRE AU SALARIÉ », et en pied :
« Vous devez conserver cette attestation mensuelle ».

Les deux ne peuvent pas diverger : le numero d'attestation et le montant de
contribution viennent des memes fonctions (`aem.contribution`,
`aem.taux_chomage`) et du meme compteur. Un salarie qui compare son
attestation au depot doit trouver le meme chiffre.

COMMENT C'EST FABRIQUE
----------------------
On ne redessine pas le formulaire : on **remplit le vierge officiel**.
`gabarits/aem_v5_formulaire.pdf` est la page 1 de l'imprime Unedic « AEM V5 »
(reference DAJ 110 07/2017), copiee depuis `affichage/aemV5/aemV501.pdf` de
CoolPaie. Il est entierement vectoriel -- 91 traces, pas une image -- donc il
s'imprime net a n'importe quelle taille. On le projette en fond de page, puis
on pose les valeurs en Courier 12 par-dessus, exactement comme le faisait
CoolPaie.

Les coordonnees de `CASES` sont relevees sur de vraies AEM produites par
CoolPaie et archivees dans `export/` : `AEM 022022 PUPPIS.pdf` pour la plupart
des champs, et `AEM 102022 SIMIONI.pdf` pour la seule case « heures », la
seule attestation de tout l'historique qui en porte (24 h).

DEUX CHAMPS D'EN-TETE QUE COOLPAIE REMPLIT ET QUE NOUS TRAITONS AUTREMENT
------------------------------------------------------------------------
* **`ATTESTATION N°`** : CoolPaie imprime `WKVW000018`, un prefixe maison suivi
  du numero. Le rapprochement avec le fichier EDI reellement depose le tranche :
  `_260222_16h42m16s_EDIV5.txt` porte `num_attestation=000018` pour la meme
  attestation. Le numero est donc `000018` ; `WKVW` n'appartient pas au
  formulaire et nous ne le reproduisons pas.

* **La case a x=449, sans libelle sur le vierge**, ou CoolPaie ecrit un nombre
  qui suit le numero d'attestation avec un decalage constant de +25 (18 -> 43,
  5 -> 30, 26 -> 51, verifie sur 14 attestations). C'est un compteur interne de
  CoolPaie, pas une rubrique du formulaire : laisse vide.

Enfin, le vierge de CoolPaie porte **son propre nom, « COOLPAIE », imprime en
haut a droite**. Il est masque : ce n'est pas notre logiciel, et ce sera encore
moins vrai le jour ou CoolPaie sera abandonne.
"""
from __future__ import annotations
from decimal import Decimal
from pathlib import Path

import pymupdf

from . import aem
from .contexte import GABARITS
from .util import d

GABARIT = GABARITS / "aem_v5_formulaire.pdf"
IDENTITE = GABARITS / "identite"
SIGNATURE = IDENTITE / "signature.png"

COURIER = "cour"
CORPS = 12.0

# Motif de cessation, en clair sous « ... est le suivant ». Nos contrats sont
# tous des CDD d'usage arrivant a terme ; CoolPaie ecrivait la meme chose.
MOTIF_CESSATION = "Fin de contrat"

# Le nom de l'editeur imprime dans le vierge, a masquer.
MARQUE_EDITEUR = "COOLPAIE"

# Sous « Signature de l'employeur ou de son representant » (345.8, 735.7).
SIGNATURE_CADRE = pymupdf.Rect(350.0, 748.0, 440.0, 785.8)

# (x, ligne_de_base) en points PDF, corps 12 sauf mention. Releve sur les AEM
# reelles de `export/` -- voir l'en-tete du module.
CASES = {
    # 1. ATTESTATION
    "mois_dizaine":     (178.51, 86.97),
    "mois_unite":       (192.22, 86.87),
    "annee_dizaine":    (218.30, 86.95),
    "annee_unite":      (232.26, 86.74),
    "attestation":      (321.52, 87.03),
    # 2. EMPLOYEUR
    "siret":            (80.89, 145.33),
    "naf":              (327.26, 145.33),
    "affiliation_ft":   (459.35, 145.41),
    "idcc":             (77.93, 163.34),
    "raison_sociale":   (100.61, 181.08),
    "telephone":        (429.35, 193.59),
    "code_postal":      (91.85, 207.65),
    "commune":          (191.29, 207.65),
    "courriel":         (429.38, 206.81),
    "licence":          (137.29, 239.92),
    "conges_spectacles": (361.27, 240.09),
    # 3. SALARIE
    "sal_nom":          (100.53, 298.58),
    "sal_prenom":       (381.05, 298.51),
    "sal_nir":          (100.67, 327.86),
    "sal_naissance":    (409.71, 327.81),
    "sal_adresse":      (100.48, 357.79),
    "sal_code_postal":  (100.59, 386.81),
    "sal_commune":      (225.06, 387.05),
    # 4. PRESTATION DE TRAVAIL
    "emploi":           (108.90, 424.51),
    "numero_objet":     (401.11, 424.12),
    "retraite":         (117.58, 443.15),
    "date_embauche":    (109.07, 462.56),
    "date_fin":         (429.48, 463.42),
    "heures":           (79.60, 535.08),
    "cachets":          (161.69, 535.06),
    "jours":            (267.96, 535.72),
    # REMUNERATIONS VERSEES AU COURS DU MOIS
    "brut":             (75.52, 597.65),
    "assiette":         (217.10, 597.65),
    "taux":             (369.83, 597.18),
    "contributions":    (471.79, 597.63),
    "total":            (471.51, 645.36),
    # 5. AUTHENTIFICATION PAR L'EMPLOYEUR
    "sig_nom":          (122.91, 679.07),
    "sig_prenom":       (378.69, 679.48),
    "sig_qualite":      (123.36, 696.03),
    "motif":            (94.50, 720.93, 10.0),
    "fait_a":           (66.31, 738.48),
    "fait_le":          (227.96, 739.82),
    "contact":          (213.54, 753.19, 8.74),
    "contact_tel":      (94.91, 772.78),
}


def _montant(x) -> str:
    """130 -> '130,00' : deux decimales et la virgule francaise, comme CoolPaie."""
    return ("%.2f" % Decimal(str(x))).replace(".", ",")


def _cases_date(x) -> str:
    """25/02/2022 -> '25 02 2022', comme les cases du formulaire."""
    return d(x).strftime("%d %m %Y")


def valeurs(paie, ent: dict, num_attestation: int) -> dict:
    """Ce qui va dans chaque case, avant tout dessin.

    Isole pour etre relisible et testable sans produire un PDF.
    """
    s, e = paie.salarie, paie.engagement
    fin = d(e.fin)
    sig = ent["signataire"]
    taux = aem.taux_chomage(paie)
    montant = aem.contribution(paie)

    licence = ent.get("licence_spectacle")
    if isinstance(licence, (list, tuple)):
        raise ValueError(
            "licence_spectacle non resolue : passer ent avec la valeur du mois "
            "(Contexte.licence), pas la liste datee de config/entreprise.json.")

    return {
        "mois_dizaine": fin.strftime("%m")[0],
        "mois_unite": fin.strftime("%m")[1],
        "annee_dizaine": fin.strftime("%y")[0],
        "annee_unite": fin.strftime("%y")[1],
        "attestation": "%06d" % num_attestation,
        "siret": ent["siret"],
        "naf": ent["naf"],
        "affiliation_ft": ent.get("affiliation_france_travail")
                          or ent.get("code_employeur_france_travail", ""),
        "idcc": str(ent["idcc"]),
        "raison_sociale": ent["raison_sociale"],
        "telephone": sig.get("tel", ""),
        "code_postal": ent["code_postal"],
        "commune": ent["commune"],
        "courriel": sig.get("email", ""),
        "licence": licence or "",
        "conges_spectacles": ent.get("congesspectacles_adherent") or "",
        "sal_nom": s["nom"],
        "sal_prenom": s["prenom"],
        "sal_nir": s["nir"] + s["nir_cle"],
        "sal_naissance": _cases_date(s["date_naissance"]),
        "sal_adresse": s["adresse"],
        "sal_code_postal": s["code_postal"],
        "sal_commune": s["commune"],
        "emploi": s["emploi"],
        "numero_objet": paie.spectacle["numero_objet"],
        "retraite": ent.get("retraite_complementaire", ""),
        "date_embauche": _cases_date(e.debut),
        "date_fin": _cases_date(fin),
        "heures": str(int(e.heures)) if e.heures else "",
        "cachets": str(e.cachets) if e.cachets else "",
        "jours": str(e.jours) if e.jours else "",
        "brut": _montant(paie.brut),
        "assiette": _montant(paie.brut),
        "taux": _montant(taux),
        "contributions": _montant(montant),
        "total": _montant(montant),
        "sig_nom": sig["nom"],
        "sig_prenom": sig["prenom"],
        "sig_qualite": (sig.get("fonction") or "").upper(),
        "motif": MOTIF_CESSATION,
        "fait_a": ent["commune"],
        "fait_le": _cases_date(fin),
        "contact": sig["nom"],
        "contact_tel": sig.get("tel", ""),
    }


def _dessiner(page, fond, paie, ent: dict, num_attestation: int) -> None:
    """Projette le vierge officiel, masque la marque de l'editeur, remplit."""
    page.show_pdf_page(page.rect, fond, 0)
    for zone in page.search_for(MARQUE_EDITEUR):
        page.draw_rect(zone + (-1, -2, 2, 2), color=None, fill=(1, 1, 1))
    for champ, valeur in valeurs(paie, ent, num_attestation).items():
        if not valeur:
            continue
        position = CASES[champ]
        x, y = position[0], position[1]
        corps = position[2] if len(position) > 2 else CORPS
        page.insert_text(pymupdf.Point(x, y), str(valeur), fontname=COURIER,
                         fontsize=corps, color=(0, 0, 0))
    if SIGNATURE.exists():
        page.insert_image(SIGNATURE_CADRE, filename=str(SIGNATURE))


def ecrire(paies: list, ent: dict, chemin, premier_numero: int) -> Path:
    """Ecrit un PDF contenant une AEM papier par page, une par contrat.

    `premier_numero` est le meme que celui du fichier EDI : les deux sorties
    d'un meme mois portent les memes numeros d'attestation, dans le meme ordre.
    """
    chemin = Path(chemin)
    chemin.parent.mkdir(parents=True, exist_ok=True)
    fond = pymupdf.open(str(GABARIT))
    doc = pymupdf.open()
    for i, paie in enumerate(paies):
        page = doc.new_page(width=fond[0].rect.width, height=fond[0].rect.height)
        _dessiner(page, fond, paie, ent, premier_numero + i)
    doc.save(str(chemin), garbage=4, deflate=True, clean=True)
    doc.close()
    fond.close()
    return chemin
