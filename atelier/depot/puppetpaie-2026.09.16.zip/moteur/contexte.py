"""Chargement des donnees de reference et resolution des noms parles.

L'idee : dans le chat on ecrit "Ana", "Lenadre", "oooh teresina" ; ici on
retrouve la bonne fiche sans se plaindre d'une faute de frappe.
"""
from __future__ import annotations
import json
import os
import datetime as _dt
from pathlib import Path

from .util import cle_recherche, d

# --------------------------------------------------------------- les chemins
# Le CODE et les DONNEES sont deux choses distinctes, et c'est volontaire :
# le code est destine a un depot public, les donnees ne doivent jamais en
# approcher (NIR, adresses, remunerations). Le logiciel les cherche donc, il
# ne suppose pas qu'elles sont a cote de lui.
#
#   claude/
#     logiciel/   <- CODE   : ce module, le depot public
#     prive/      <- DONNEES: config/, paies/, sorties/, retours/, gabarits/
#
# Trois emplacements essayes dans l'ordre. Le troisieme laisse une
# installation d'un seul tenant fonctionner (code et donnees melanges), ce qui
# est le cas de figure d'une autre compagnie qui deballerait le logiciel.
CODE = Path(__file__).resolve().parent.parent


def racine_donnees() -> Path:
    depuis_env = os.environ.get("PUPPETPAIE_DONNEES")
    if depuis_env:
        return Path(depuis_env)
    voisin = CODE.parent / "prive"
    if (voisin / "config").is_dir():
        return voisin
    return CODE


RACINE = racine_donnees()
CONFIG = RACINE / "config"
# Les gabarits sont des DONNEES : enregistrements AEM et DPAE reels,
# logo et signature. Ils vivent avec le reste du prive, pas avec le code.
GABARITS = RACINE / "gabarits"


def trouver_export(depart: Path) -> Path:
    """Les declarations deja deposees par CoolPaie -- `calibrer` et `droits`.

    Ce dossier n'est PAS a nous : CoolPaie y ecrit encore, tant que dure le
    double run. On ne le deplace pas, on le trouve. D'ou cette remontee de
    dossier en dossier plutot qu'un chemin fige.
    """
    for base in (depart, depart.parent, depart.parent.parent):
        p = base / "export"
        if p.is_dir():
            return p
    return depart / "export"       # absent : les commandes le diront elles-memes


def resoudre(chemin, racine: Path = None) -> Path:
    """Un chemin tape a la main : tel quel s'il existe, sinon sous les donnees.

    Le code et les donnees ayant ete separes, `paies/2026-10.json` n'est plus
    relatif au dossier courant. Plutot que d'imposer `../prive/paies/...` a
    tout le monde -- et de reecrire les competences Claude, les lanceurs et
    cinq ans d'habitude -- on essaie les deux. Ce qui existe l'emporte.
    """
    p = Path(chemin)
    if p.exists() or p.is_absolute():
        return p
    candidat = (Path(racine) if racine else racine_donnees()) / p
    return candidat if candidat.exists() else p


def _lire(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def archivee(fiche: dict) -> bool:
    """Une fiche est archivee quand elle porte `actif: false`.

    L'ABSENCE de la cle vaut actif : aucune fiche existante n'a a etre
    modifiee pour rester courante, et une compagnie qui ne connait pas cet
    etat n'en subit rien.

    Ce que l'archivage fait, et ce qu'il ne fait pas -- c'est toute la
    notion : une fiche archivee **reste en base**, parce que ses paies
    passees doivent se rejouer et que ses AEM deposees restent vraies. Elle
    sort seulement de ce qu'on propose : les listes deroulantes, `moteur
    fiche`, la recherche approchante. On ne supprime rien, jamais : une
    declaration deposee renvoie a une fiche, et effacer la fiche rendrait la
    declaration illisible.
    """
    return fiche.get("actif") is False


def telle_qu_au(fiche: dict, date_ref) -> dict:
    """La fiche telle qu'elle etait a cette date-la.

    UNE FICHE N'EST PAS UN ETAT, C'EST UNE SUITE D'ETATS. Un salarie
    demenage, change de telephone ; une valeur declaree se corrige. Ecraser
    la valeur precedente rend le passe illisible : la DSN de juillet est
    partie avec l'adresse de juillet, et un rejeu qui la compare a l'adresse
    d'aujourd'hui hurle sur une difference qui n'est pas une regression.

    D'ou `historique`, dans la fiche, a cote des valeurs courantes :

        "historique": [
          {"champ": "adresse", "valeur": "3 RUE DES LILAS",
           "jusqu_au": "2026-09-10", "note": "demenagement"}
        ]

    Chaque entree dit : jusqu'a cette date INCLUSE, ce champ valait cela.
    Au-dela, la valeur courante de la fiche reprend la main. Plusieurs
    entrees sur un meme champ se lisent dans l'ordre : on prend la premiere
    fenetre qui couvre encore la date demandee.

    `date_ref` est la date a laquelle la DECLARATION est faite, et non celle
    du contrat : c'est l'identite connue le jour de l'envoi qui part aux
    organismes.
    """
    hist = fiche.get("historique")
    if not hist:
        return fiche
    jour = d(date_ref)
    sortie = dict(fiche)
    for champ in {e["champ"] for e in hist}:
        fenetres = sorted((e for e in hist if e["champ"] == champ),
                          key=lambda e: d(e["jusqu_au"]))
        for e in fenetres:
            if jour <= d(e["jusqu_au"]):
                sortie[champ] = e["valeur"]
                break
    return sortie


class Contexte:
    """Les donnees de la compagnie, lues une fois.

    `date` fige la LECTURE des fiches : par defaut aujourd'hui, donc les
    valeurs courantes. Un rejeu de l'historique passe la date du depot
    d'origine et retrouve les fiches telles qu'elles etaient -- c'est le seul
    moyen de comparer une declaration deposee a ce que le moteur produirait
    des memes donnees. Voir `telle_qu_au`.
    """

    def __init__(self, racine: Path = None, date=None):
        self.racine = Path(racine) if racine else racine_donnees()
        self.code = CODE
        self.export = trouver_export(self.racine)
        self.date = str(d(date)) if date else str(_dt.date.today())
        cfg = self.racine / "config"
        self.entreprise = telle_qu_au(_lire(cfg / "entreprise.json"), self.date)
        self.salaries = {k: telle_qu_au(v, self.date)
                         for k, v in _lire(cfg / "salaries.json").items()
                         if not k.startswith("_")}
        self.spectacles = {k: telle_qu_au(v, self.date)
                           for k, v in _lire(cfg / "spectacles.json").items()
                           if not k.startswith("_")}
        self._baremes: dict[int, dict] = {}
        # Numeros attribues mais pas encore valides : ils ne sont ecrits
        # sur disque qu'apres production reussie des fichiers du mois
        # (voir valider_compteurs). Un essai ou un run interrompu ne doit
        # jamais consommer un numero de bulletin.
        self._compteurs_en_attente: dict = {}

    # ---------------------------------------------------------------- archives
    @property
    def salaries_actifs(self) -> dict:
        """Les salaries qu'on peut encore embaucher. Les archives restent
        dans `salaries`, et c'est la difference qui compte."""
        return {k: v for k, v in self.salaries.items() if not archivee(v)}

    @property
    def spectacles_actifs(self) -> dict:
        """Idem pour les spectacles. France Travail delivre un numero d'objet
        par spectacle ET PAR ANNEE : ceux des annees passees ne serviront plus
        a declarer quoi que ce soit, mais ils doivent rester lisibles."""
        return {k: v for k, v in self.spectacles.items() if not archivee(v)}

    # ---------------------------------------------------------------- baremes
    def bareme(self, date_ref) -> dict:
        an = d(date_ref).year
        if an not in self._baremes:
            p = self.racine / "config" / "baremes" / f"{an}.json"
            if not p.exists():
                dispo = sorted(x.stem for x in (self.racine / "config" / "baremes").glob("*.json"))
                raise FileNotFoundError(
                    f"Pas de bareme pour {an}. Baremes disponibles : {', '.join(dispo)}.\n"
                    f"Creer config/baremes/{an}.json (partir du plus recent, mettre a jour "
                    f"SMIC et taux, puis relancer `python -m moteur calibrer`)."
                )
            self._baremes[an] = _lire(p)
        return self._baremes[an]

    def smic(self, date_ref) -> float:
        """SMIC horaire applicable a la date (le bareme liste les revalorisations)."""
        jour = d(date_ref)
        val = None
        for e in sorted(self.bareme(jour)["smic_horaire"], key=lambda e: e["depuis"]):
            if d(e["depuis"]) <= jour:
                val = e["valeur"]
        if val is None:
            raise ValueError(f"Aucun SMIC applicable au {jour} dans le bareme.")
        return val

    def licence(self, date_ref) -> str:
        """Numero de licence d'entrepreneur de spectacles applicable a la date.

        Date car il change : le recepisse de 2019 (2019001116) puis la licence
        L-R-24-2. Le rejeu de l'historique doit reproduire ce qui a ete
        reellement declare, pas la valeur du jour -- meme raison que pour le
        SMIC. Une chaine simple reste acceptee, pour ne rien casser ailleurs.
        """
        v = self.entreprise["licence_spectacle"]
        if isinstance(v, str):
            return v
        jour = d(date_ref)
        retenu = None
        for e in sorted(v, key=lambda e: e["depuis"]):
            if d(e["depuis"]) <= jour:
                retenu = e["numero"]
        if retenu is None:
            raise ValueError(
                "Aucun numero de licence applicable au %s. Completer "
                "config/entreprise.json." % jour)
        return retenu

    # -------------------------------------------------------------- recherche
    def salarie(self, nom: str) -> dict:
        """Retrouve un salarie par nom, prenom, diminutif ou faute de frappe.

        UNE REGLE, ET ELLE EST LE COEUR DE L'ARCHIVAGE : le nom EXACT retrouve
        n'importe qui, archive compris -- sans quoi une paie passee cesserait
        de se rejouer. La recherche APPROCHANTE, elle, ne va chercher que
        parmi les actifs : c'est elle qui ferait ressortir une fiche mise de
        cote sur une faute de frappe, et personne ne le verrait.
        """
        q = cle_recherche(nom)
        for cle, s in self.salaries.items():
            candidats = {cle_recherche(cle), cle_recherche(s["nom"]),
                         cle_recherche(s["prenom"]),
                         cle_recherche(f"{s['nom']} {s['prenom']}"),
                         cle_recherche(f"{s['prenom']} {s['nom']}")}
            if q in candidats:
                return dict(s, _cle=cle)
        # tolerance : prefixe (Ana -> ANASTASIA) puis distance d'edition,
        # sur les seuls actifs.
        actifs = self.salaries_actifs
        for cle, s in actifs.items():
            for c in (cle_recherche(s["prenom"]), cle_recherche(s["nom"])):
                if c.startswith(q) and len(q) >= 3:
                    return dict(s, _cle=cle)
        best, score = None, 99
        for cle, s in actifs.items():
            for c in (cle_recherche(s["prenom"]), cle_recherche(s["nom"])):
                dist = _levenshtein(q, c)
                if dist < score:
                    best, score = cle, dist
        if best and score <= 3:
            return dict(actifs[best], _cle=best)
        # Rien parmi les actifs : si une archive ressemble, le dire plutot que
        # « inconnu ». Sinon on cherche une faute de frappe qui n'existe pas.
        for cle, s in self.salaries.items():
            if archivee(s) and any(
                    cle_recherche(x).startswith(q) or _levenshtein(q, cle_recherche(x)) <= 3
                    for x in (s["prenom"], s["nom"], cle)):
                raise KeyError(
                    f"Salarie archive : {nom!r} ressemble a {s['nom']} "
                    f"{s['prenom']} (cle {cle!r}), dont la fiche porte "
                    f"`actif: false`. L'appeler par sa cle exacte pour rejouer "
                    f"une paie passee ; pour l'embaucher a nouveau, remettre "
                    f"`actif: true` dans config/salaries.json.")
        raise KeyError(f"Salarie inconnu : {nom!r}. Connus : "
                       f"{', '.join(actifs)}.")

    def spectacle(self, nom: str) -> dict:
        q = cle_recherche(nom)
        for cle, sp in self.spectacles.items():
            noms = [cle, sp["titre"]] + list(sp.get("alias", []))
            if q in {cle_recherche(n) for n in noms}:
                return dict(sp, _cle=cle)
            if sp.get("numero_objet", "").upper() == nom.strip().upper():
                return dict(sp, _cle=cle)
        for cle, sp in self.spectacles.items():
            noms = [cle, sp["titre"]] + list(sp.get("alias", []))
            if any(q in cle_recherche(n) or cle_recherche(n) in q for n in noms if n):
                return dict(sp, _cle=cle)
        raise KeyError(
            f"Spectacle inconnu : {nom!r}. Connus : "
            + ", ".join(f"{v['titre']}" for v in self.spectacles.values())
            + ".\nAjouter une entree dans config/spectacles.json avec son numero d'objet "
              "France Travail."
        )

    # --------------------------------------------------------------- rubriques
    def rubriques(self) -> dict:
        """Le catalogue des rubriques de paie, en donnee et non en code.

        Meme regle que le bareme : ce qui change sans nous ne vit pas dans le
        moteur. Aujourd'hui le catalogue ne SERT pas encore au calcul -- le
        moteur ne sait faire que les cachets et les heures -- mais il est la,
        complet, et c'est lui qui portera les coefficients le jour de la
        saisie par rubrique.

        Absent, il rend un dictionnaire vide : aucune commande n'en depend
        pour produire une paie.
        """
        p = self.racine / "config" / "rubriques.json"
        if not p.exists():
            return {}
        return _lire(p).get("rubriques", {})

    def rubrique(self, code: str) -> dict:
        """Une rubrique par son code. Leve si elle n'existe pas : mieux vaut
        s'arreter que produire une paie avec un coefficient invente."""
        cat = self.rubriques()
        if code not in cat:
            raise KeyError(
                "Rubrique inconnue : %r. Connues : %s."
                % (code, ", ".join(sorted(cat)) if cat else "aucune, "
                   "config/rubriques.json est absent"))
        return dict(cat[code], code=code)

    # --------------------------------------------------------------- compteurs
    def _fichier_compteurs(self) -> Path:
        return self.racine / "config" / "compteurs.json"

    def compteurs(self) -> dict:
        p = self._fichier_compteurs()
        return _lire(p) if p.exists() else {}

    def prochain(self, cle: str, annee: int, defaut: int = 1) -> int:
        an = str(annee)
        attente = self._compteurs_en_attente.get(an, {})
        if cle in attente:
            return int(attente[cle]) + 1
        c = self.compteurs()
        return int(c.get(an, {}).get(cle, defaut - 1)) + 1

    def prochain_continu(self, cle: str, annee: int, defaut: int = 1) -> int:
        """Comme `prochain`, mais sur une sequence qui ne repart PAS a 1 chaque an.

        Le N° CE des certificats Conges Spectacles est une sequence propre a
        l'employeur, delivree par Audiens et continue d'une annee sur l'autre
        (l'employeur du certificat de reference en etait a 3152). La relire
        annee par annee la ferait repartir a 1 chaque janvier, et deux
        certificats porteraient le meme numero -- or Audiens ecrit qu'ils ont
        « valeur de cheque emis sur votre compte ».

        On garde neanmoins l'ecriture par annee dans compteurs.json, comme le
        reste : c'est la LECTURE qui balaie toutes les annees et retient le
        maximum.
        """
        vu = defaut - 1
        for source in (self.compteurs(), self._compteurs_en_attente):
            for valeurs in source.values():
                if isinstance(valeurs, dict) and cle in valeurs:
                    vu = max(vu, int(valeurs[cle]))
        return vu + 1

    def enregistrer_compteur(self, cle: str, annee: int, valeur: int) -> None:
        """Reserve un numero SANS l'ecrire : valider_compteurs le confirme."""
        self._compteurs_en_attente.setdefault(str(annee), {})[cle] = int(valeur)

    def valider_compteurs(self) -> None:
        """Ecrit les numeros reserves. A n'appeler qu'une fois le mois produit."""
        if not self._compteurs_en_attente:
            return
        c = self.compteurs()
        for an, valeurs in self._compteurs_en_attente.items():
            c.setdefault(an, {}).update(valeurs)
        self._fichier_compteurs().write_text(
            json.dumps(c, ensure_ascii=False, indent=2), encoding="utf-8")
        self._compteurs_en_attente = {}


def _levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]
