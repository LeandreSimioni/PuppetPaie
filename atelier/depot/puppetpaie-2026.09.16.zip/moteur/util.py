"""Arrondis, dates et formats francais."""
from __future__ import annotations
import datetime as _dt
import unicodedata
from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")


def eur(x) -> Decimal:
    """Arrondi monetaire a 2 decimales, moitie superieure (regle paie francaise).

    Python arrondit au pair le plus proche (round(2.675, 2) == 2.67) ; la paie
    arrondit toujours vers le haut a partir de 5. D'ou Decimal ici, partout.
    """
    return Decimal(str(x)).quantize(CENT, rounding=ROUND_HALF_UP)


def pct(base, taux) -> Decimal:
    """Applique un taux exprime en pourcentage et arrondit au centime."""
    return eur(Decimal(str(base)) * Decimal(str(taux)) / Decimal(100))


def fmt_eur(x) -> str:
    """1234.5 -> '1 234,50'"""
    s = f"{Decimal(str(x)):,.2f}".replace(",", " ").replace(".", ",")
    return s


def fmt_taux(x) -> str:
    """9.1 -> '9,100'"""
    return f"{Decimal(str(x)):.3f}".replace(".", ",")


def d(s) -> _dt.date:
    """Accepte 'AAAA-MM-JJ', 'JJ/MM/AAAA', 'JJMMAAAA', un date, ou une date
    detaillee {"jour": ..., "lieu": ...}.

    Le dictionnaire est l'ecriture d'un jour joue qui dit OU il se joue (voir
    `calcul.Engagement`). Il est accepte ICI, dans le seul endroit du moteur
    qui sache lire une date, pour que tout ce qui parcourt des dates de
    travail continue de marcher sans le savoir : `cumul.py` compte des heures,
    il n'a rien a faire du lieu, et il ne doit pas avoir a l'ignorer
    explicitement.
    """
    if isinstance(s, _dt.date):
        return s
    if isinstance(s, dict):
        if "jour" not in s:
            raise ValueError("date detaillee sans `jour` : %r" % (s,))
        return d(s["jour"])
    s = str(s).strip()
    for f in ("%Y-%m-%d", "%d/%m/%Y", "%d%m%Y", "%Y%m%d", "%d-%m-%Y"):
        try:
            return _dt.datetime.strptime(s, f).date()
        except ValueError:
            pass
    raise ValueError(f"date illisible : {s!r}")


def jjmmaaaa(x) -> str:
    return d(x).strftime("%d%m%Y")


def jj_mm_aaaa(x) -> str:
    return d(x).strftime("%d/%m/%Y")


def aaaammjj(x) -> str:
    return d(x).strftime("%Y%m%d")


MOIS = ["Janvier", "Fevrier", "Mars", "Avril", "Mai", "Juin",
        "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Decembre"]

MOIS_FR = ["janvier", "fevrier", "mars", "avril", "mai", "juin",
           "juillet", "aout", "septembre", "octobre", "novembre", "decembre"]


def sans_accent(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")


def cle_recherche(s: str) -> str:
    """Normalise pour la recherche floue : minuscules, sans accent ni ponctuation."""
    s = sans_accent(str(s)).lower()
    return "".join(c if c.isalnum() else " " for c in s).split() and \
        " ".join("".join(c if c.isalnum() else " " for c in s).split()) or ""


def quand_lisible(iso, liaison: str = " à ") -> str:
    """Un horodatage ISO (2026-09-12T18:18:08) en francais : 12/09/2026 à 18:18.

    On travaille en France : une date a l'americaine dans une phrase se lit
    mal. Les fichiers gardent l'ISO, qui se trie ; ce
    qui s'affiche passe par ici.
    """
    s = str(iso or "")
    if len(s) < 10 or s[4] != "-" or s[7] != "-":
        return s
    jour = "%s/%s/%s" % (s[8:10], s[5:7], s[:4])
    heure = s[11:16] if len(s) >= 16 else ""
    return jour + (liaison + heure if heure else "")
