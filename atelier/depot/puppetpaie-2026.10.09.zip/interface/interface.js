/* L'interface : elle affiche et elle demande, elle ne calcule jamais.
 *
 * Tout chiffre visible ici vient du moteur, par /api. Pas un brut, pas un
 * net, pas un plafond n'est recalcule en JavaScript -- c'est la meme regle
 * que pour Claude : le calcul est du code Python teste et cale au centime,
 * et deux calculateurs, c'est deux resultats le jour ou l'un derive.
 *
 * Les erreurs metier arrivent avec un `type` : c'est sur lui qu'on branche,
 * jamais sur le texte du message.
 */
"use strict";

const JETON = document.body.dataset.jeton;
let ETAT = null;            // configuration + historique, rafraichis a la demande

/* LA DÉMONSTRATION (moteur/simulation.py) : même interface, mêmes étapes,
   mais ce qui part est joué — dépôts, retours, courriels, signatures. Le
   moteur le dit dans `etat` ; la page ne fait que ne pas demander de mot de
   passe, et le dire au moment de l'acte. */
const enDemonstration = () => !!(ETAT && ETAT.simulation);
const noteDemonstration = (vers, reponse = true) => `<p class="note"><b>Démonstration</b> —
  rien ne part vers ${echapper(vers)} : l'envoi est simulé${reponse
  ? ", et sa réponse arrive comme la vraie, quelques secondes plus tard" : ""}.</p>`;
/* LA DPAE PRÉPARÉE D'AVANCE, DITE DANS LA DÉMONSTRATION (27/09/2026) : le
   test part en silence (operations_filet) et le filet n'y existe pas — une
   ligne, là où naissent les contrats, pour que le visiteur sache l'un et
   l'autre. */
const noteDpaeAvance = () => enDemonstration() ? `<p class="note"><b>La DPAE préparée
  d'avance</b> — dès que les contrats sont écrits ou envoyés, la DPAE de chaque
  embauche se prépare et part en test, d'elle-même : le jour venu, il ne reste
  qu'à l'envoyer. Dans la version complète, une option (Configuration › Mots de
  passe) envoie en plus un courriel de rappel si elle n'est pas partie la veille
  de l'embauche.</p>` : "";
let SAISIE = null;          // le mois en cours d'edition
let MINUTEUR = null;        // anti-rebond de l'apercu

/* ------------------------------------------------------------- le tuyau */

/* « Failed to fetch » : le serveur ne répond plus.
 *
 * C'est arrivé le 11/09/2026, et le message du navigateur n'apprenait rien —
 * une fiche en cours d'édition n'a pas été enregistrée, sans qu'on sache
 * pourquoi. La page survit à son serveur : elle a l'air de marcher, les
 * champs se remplissent, et seul l'enregistrement échoue.
 *
 * On le dit donc en toutes lettres, et on le dit de façon PERSISTANTE : un
 * message qui s'efface au bout de six secondes n'aide pas quelqu'un qui
 * était en train de taper. */
let SERVEUR_PERDU = false;

function serveurPerdu() {
  if (SERVEUR_PERDU) return;
  SERVEUR_PERDU = true;
  const zone = document.getElementById("veille");
  zone.hidden = false;
  zone.classList.add("souci");
  document.getElementById("veille-texte").innerHTML =
    "<b>Le serveur ne répond plus.</b> La fenêtre PuppetPaie a été fermée, ou le "
    + "terminal qui la faisait tourner. <b>Rien de ce qui est à l'écran n'est "
    + "enregistré.</b> Relancer PuppetPaie, puis recharger cette page.";
  document.getElementById("veille-maintenant").hidden = true;
}

/* L'ÉCRAN D'UN MOIS SE LIT D'UN COUP (Leandre, 09/10/2026 : « juste de la
 * lecture » ; PLAN-MOIS-INSTANTANE.md). Les lectures d'un mois (la saisie, les
 * contrats en cours, les états, les embauches, les fins, les arrêts, la
 * reprise du journal, l'aperçu) ne partent plus une à une au moteur : une
 * seule demande `mois` les rend toutes, lues dans `paies/AAAA-MM.etat.json`
 * par la fenêtre elle-même, sans calcul. Le calcul s'est fait avant, quand
 * quelque chose a changé. Chaque lecture garde sa forme (résultat ou refus) :
 * les fonctions qui dessinent n'ont pas changé.
 *
 * Toute autre route peut écrire : ce qui a été lu part alors, avant ET après
 * elle — on n'affiche jamais un état qu'on aurait pu changer soi-même. */
const LECTURES_DU_MOIS = new Set(["saisie", "contrats-en-cours", "etat-du-mois",
  "embauches-a-declarer", "fins-de-contrat", "etat-par-paie"]);
// Elles ne dépendent pas du mois : n'importe quelle lecture `mois` les porte.
const LECTURES_DE_LA_COMPAGNIE = new Set(["arrets", "journal-reprise"]);
// Des lectures que la page fait souvent, sans rien changer : elles ne vident pas ce qui a été lu.
const ROUTES_SANS_EFFET = new Set(["veille", "rappels", "pour-demarrer", "organismes-contrats", "incident-navigateur", "diagnostic-etat",
  "verifier-fiche", "emploi", "signalements", "apercu"]);
let LU = null;            // { mois, lectures } : la dernière lecture `mois`
let LU_EN_COURS = null;   // { mois, promesse } : celle qui est en route
let LU_GENERATION = 0;

/** Une réponse du moteur, telle que `appelerMoteur` la rend : son résultat, ou son refus levé. */
function lireReponse(d) {
  if (!d) throw new Error("Lecture absente de l'état du mois.");
  if (!d.ok) { const e = new Error(d.erreur.message); e.detail = d.erreur; throw e; }
  return d.resultat;
}

/** Tout ce que l'écran de `mois` lit, en une demande (partagée si elle est déjà en route). */
function lireLeMois(mois) {
  if (LU && LU.mois === mois) return Promise.resolve(LU);
  if (LU_EN_COURS && LU_EN_COURS.mois === mois) return LU_EN_COURS.promesse;
  const generation = LU_GENERATION;
  const promesse = appelerMoteur("mois", { mois }).then((r) => {
    const lu = { mois, lectures: r.lectures || {} };
    if (generation === LU_GENERATION) LU = lu;
    if (LU_EN_COURS && LU_EN_COURS.promesse === promesse) LU_EN_COURS = null;
    return lu;
  }, (e) => {
    if (LU_EN_COURS && LU_EN_COURS.promesse === promesse) LU_EN_COURS = null;
    throw e;
  });
  LU_EN_COURS = { mois, promesse };
  return promesse;
}

function oublierLeMois() { LU = null; LU_EN_COURS = null; LU_GENERATION++; }

/** Le mois dont `route` est une lecture, ou `null` : `{mois}` pour une lecture du mois, `{}` pour une de la compagnie. */
function moisDeLaLecture(route, charge) {
  const cles = Object.keys(charge || {});
  if (LECTURES_DU_MOIS.has(route) && cles.length === 1 && cles[0] === "mois" && charge.mois) return charge.mois;
  if (LECTURES_DE_LA_COMPAGNIE.has(route) && !cles.length) return MOIS_AFFICHE || document.getElementById("mois").value || null;
  return null;
}

async function api(route, charge = {}) {
  const mois = moisDeLaLecture(route, charge);
  if (mois) {
    const lu = (LECTURES_DE_LA_COMPAGNIE.has(route) && LU) ? LU : await lireLeMois(mois);
    return structuredClone(lireReponse(lu.lectures[route]));
  }
  if (ROUTES_SANS_EFFET.has(route)) return appelerMoteur(route, charge);
  oublierLeMois();
  try { return await appelerMoteur(route, charge); } finally { oublierLeMois(); }
}

async function appelerMoteur(route, charge = {}) {
  let r;
  try {
    r = await fetch("/api/" + route + "?jeton=" + encodeURIComponent(JETON), {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Jeton": JETON },
      body: JSON.stringify(charge),
    });
  } catch (e) {
    // `fetch` ne rejette que sur un échec réseau — le serveur est parti.
    serveurPerdu();
    const perdu = new Error("Le serveur PuppetPaie ne répond plus. Rien n'a été enregistré.");
    // Ce n'est pas un défaut de la page, et de toute façon le journal des
    // incidents vit derrière ce serveur-là : le rapport n'arriverait nulle
    // part. Voir `noterIncident`.
    perdu.reseau = true;
    throw perdu;
  }
  const d = await r.json();
  if (!d.ok) { const e = new Error(d.erreur.message); e.detail = d.erreur; throw e; }
  return d.resultat;
}

/* ------------------------------ ce qui casse ICI, et qui mourait en silence
 *
 * Cinq mille lignes de JavaScript dont les exceptions s'imprimaient dans la
 * console du navigateur — que personne n'ouvre, et surtout pas une compagnie
 * à trois cents kilomètres. Le moteur, lui, note tout ce qui casse chez lui
 * depuis le 20/09/2026 ; la page était le dernier endroit d'où une erreur
 * pouvait disparaître sans laisser de trace.
 *
 * Elle poste donc ce qui casse à `/api/incident-navigateur`, et c'est
 * `incidents.depuis_navigateur` qui décide de la nature, regroupe et
 * caviarde. La page n'écrit pas le journal : elle le nourrit.
 *
 * DEUX GUETTEURS, PARCE QU'IL EN FAUT DEUX. `window.onerror` ne voit pas le
 * rejet d'une promesse, et cette page est asynchrone de bout en bout : un
 * `await` qui lève dans un gestionnaire de bouton non attendu ne passe QUE
 * par `unhandledrejection`.
 *
 * TROIS CHOSES NE REMONTENT PAS, et chacune pour sa raison :
 *   - une erreur métier venue de `/api` (elle porte `detail`) — le serveur
 *     l'a déjà notée, du côté où elle est née ; la reposter la compterait
 *     deux fois ;
 *   - le serveur parti (`reseau`) — ce n'est pas un défaut, et le journal
 *     vit derrière ce serveur-là ;
 *   - le même défaut deux fois, et au-delà de vingt en tout : une boucle qui
 *     lève à chaque image remplirait le journal d'une seule erreur. */
const INCIDENTS_VUS = new Set();
let INCIDENTS_POSTES = 0;
const INCIDENTS_MAX = 20;

/* Le jeton ouvre le serveur local : il ne voyage pas, même dans une pile
 * d'appels qui cite l'adresse d'un `fetch`. Le moteur le caviarde aussi —
 * deux serrures, comme pour le NIR. */
const sansJeton = (t) => String(t ?? "").replace(/jeton=[^&\s"']+/gi, "jeton=[retiré]");

/** L'onglet ouvert : ce que l'utilisatrice était en train de faire. */
function ouDansLaPage() {
  const b = document.querySelector(".onglets button.actif");
  return b ? String(b.dataset.vue || "") : "";
}

function noterIncident(rapport) {
  try {
    if (INCIDENTS_POSTES >= INCIDENTS_MAX) return;
    // Le message entre dans la clé, et pas seulement l'endroit : un rejet
    // de promesse n'a ni fichier ni ligne, et deux défauts différents s'y
    // confondraient. Le regroupement, lui, se fait à la lecture du journal.
    const cle = [rapport.genre, rapport.fichier, rapport.ligne,
                 String(rapport.message || "").slice(0, 80)].join("|");
    if (INCIDENTS_VUS.has(cle)) return;
    INCIDENTS_VUS.add(cle);
    INCIDENTS_POSTES += 1;
    // `fetch` nu, et non `api()` : `api()` lève, et une exception levée
    // depuis le guetteur d'exceptions rentrerait dans sa propre bouche.
    fetch("/api/incident-navigateur?jeton=" + encodeURIComponent(JETON), {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Jeton": JETON },
      body: JSON.stringify({
        genre: rapport.genre,
        message: sansJeton(rapport.message),
        fichier: rapport.fichier,
        ligne: rapport.ligne,
        colonne: rapport.colonne,
        pile: sansJeton(rapport.pile),
        canal: rapport.canal,
        ou_dans_la_page: ouDansLaPage(),
      }),
    }).catch(() => {});      // le serveur est parti : il n'y a rien à faire
  } catch (e) {
    /* Un guetteur qui lève remplacerait l'erreur qu'on cherche par la
     * sienne. Il se tait. */
  }
}

/** Ce qu'on ne remonte pas : voir l'en-tête. */
function incidentAIgnorer(e) {
  return !!(e && (e.detail || e.reseau));
}

window.addEventListener("error", (ev) => {
  // Une ressource qui ne se charge pas (image, feuille de style) déclenche
  // le même événement, sans `error` : ce n'est pas une exception, et
  // `ev.target` est l'élément fautif.
  if (!ev.error && ev.target && ev.target !== window) {
    return noterIncident({
      genre: "RessourceAbsente",
      message: String(ev.target.tagName || "?") + " n'a pas pu être chargé",
      fichier: ev.target.src || ev.target.href || "",
      ligne: 0, canal: "ressource",
    });
  }
  if (incidentAIgnorer(ev.error)) return;
  noterIncident({
    genre: (ev.error && ev.error.name) || "Erreur",
    message: ev.message || String(ev.error || ""),
    fichier: ev.filename, ligne: ev.lineno, colonne: ev.colno,
    pile: ev.error && ev.error.stack, canal: "erreur",
  });
// `true` — la PHASE DE CAPTURE. Une ressource qui ne se charge pas émet un
// événement qui NE REMONTE PAS : sans capture, `window` ne le voit jamais.
}, true);

window.addEventListener("unhandledrejection", (ev) => {
  const r = ev.reason;
  if (incidentAIgnorer(r)) return;
  // Une promesse peut être rejetée avec n'importe quoi — une chaîne, un
  // objet. Seule une vraie Error porte une pile et un nom.
  const estErreur = r instanceof Error;
  noterIncident({
    genre: estErreur ? (r.name || "Erreur") : "RejetNonRattrape",
    message: estErreur ? r.message : String(r),
    fichier: "interface.js", ligne: 0,
    pile: estErreur ? r.stack : "", canal: "promesse",
  });
});

function dire(texte, type) {
  const el = document.getElementById("message");
  el.textContent = texte;
  el.className = "message" + (type === "erreur" ? " erreur" : "");
  clearTimeout(dire._t);
  dire._t = setTimeout(() => el.classList.add("cachee"), 6000);
}

/** UN ACTE EN COURS SE VOIT (26/09/2026 : « quand on met envoyer les
 *  contrats, il faut un petit message pour dire envoi des contrats en
 *  cours »). Le bouton cliqué s'éteint et dit ce qui se passe, là où l'on
 *  regarde — dans la boîte, que le bandeau du bas ne traverse pas. Rend
 *  la fonction qui le rallume (une erreur : on peut réessayer). */
function occupe(bouton, texte) {
  if (!bouton) return () => {};
  const avant = bouton.innerHTML;
  bouton.disabled = true;
  bouton.classList.add("occupe");
  bouton.textContent = texte;
  return () => {
    if (!bouton.isConnected) return;
    bouton.disabled = false;
    bouton.classList.remove("occupe");
    bouton.innerHTML = avant;
  };
}

const echapper = (s) => String(s ?? "").replace(/[&<>"]/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* Une phrase du moteur qui porte un lien (le texte d'une convention, journal
 * §161) : echappee d'abord, puis l'adresse https devient cliquable. Le point
 * qui clot la phrase reste dehors. */
const echapperLiens = (s) => echapper(s).replace(
  /(https:\/\/[^\s<]+?)([.,;]?)(?=\s|$)/g,
  (_, url, fin) => `<a href="${url}" target="_blank" rel="noopener">texte de la convention</a>${fin}`);

/* ------------------------------------------------------------ navigation */
document.querySelectorAll(".onglets button").forEach((b) => {
  b.onclick = async () => {
    // Quitter une fiche en cours de saisie sans rien dire, c'est perdre ce
    // qui vient d'etre tape. La boite ne s'ouvre que si quelque chose a
    // change -- voir `quitterLaFiche`.
    if (!(await quitterLaFiche())) return;
    document.querySelectorAll(".onglets button").forEach((x) => x.classList.remove("actif"));
    b.classList.add("actif");
    document.querySelectorAll(".vue").forEach((v) => v.classList.add("cachee"));
    document.getElementById("vue-" + b.dataset.vue).classList.remove("cachee");
    if (b.dataset.vue === "historique") dessinerHistorique();
    if (b.dataset.vue === "configuration") dessinerConfig();
    if (b.dataset.vue === "exports") dessinerExports();
  };
});

/* =======================================================================
   PAIE
   ===================================================================== */
function moisCourant() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
}

/** La rubrique par son code, dans le catalogue rendu par le moteur. */
function rubriqueDe(code) {
  return (ETAT.rubriques || []).find((r) => r.code === code);
}

/** Le déroulant des rubriques : les cochées d'abord, le moteur a déjà trié.
 *  Un trait sépare ce que la compagnie utilise du reste, qui reste offert. */
function optionsRubriques(choisie, nat) {
  // CE QUI S'APPLIQUE À LA NATURE DU CONTRAT (30/09/2026, « si compagnie
  // simple, interface simple »). Le moteur dit à quelle forme de paie chaque
  // rubrique s'adresse (`reservee_a`, lu sur les champs que le calcul
  // applique) ; la page compare, elle ne connaît aucune rubrique. Sans
  // nature (`nat` absent) rien ne se filtre, et la rubrique DÉJÀ choisie
  // reste toujours offerte : une saisie ne change pas sous les doigts.
  const forme = nat ? (nat.mensuelle ? "mensuelle" : "activite") : null;
  const propose = (r) => !forme || !r.reservee_a || r.reservee_a === forme || r.code === choisie;
  const actives = (ETAT.rubriques || []).filter((r) => r.active && propose(r));
  const autres = (ETAT.rubriques || []).filter((r) => !r.active && propose(r));
  const opt = (r) => `<option value="${echapper(r.code)}" ${r.code === choisie ? "selected" : ""}>
      ${echapper(r.libelle)}</option>`;
  if (!actives.length) return autres.map(opt).join("");
  return actives.map(opt).join("")
    + `<optgroup label="── autres rubriques ──">` + autres.map(opt).join("") + `</optgroup>`;
}

/** Une ligne de rémunération : une rubrique, une quantité, un taux.
 *  Le champ « heures » n'apparaît que si la rubrique le demande — une journée
 *  de 5 h, une répétition de 3 h. Un cachet ne le demande pas : ses 12 heures
 *  viennent du règlement, pas de nous. */
function ligneRubrique(l = {}, nat) {
  const div = document.createElement("div");
  div.className = "rubrique";
  const code = l.rubrique || (ETAT.rubriques || [])[0]?.code || "cachet";
  // Une ligne neuve part du dernier taux donné, pas d'un champ vide : c'est
  // là que « on met de base le dernier taux » se voit. Le dernier taux DE SA
  // RUBRIQUE : « le cachet c'est le cachet, les heures c'est les heures ».
  // UNE LIGNE EN POURCENTAGE (majoration, précarité — 30/09/2026) : le
  // fichier dit `base` et `taux_majoration` ; les deux mêmes champs les
  // montrent, « 120 € à 25 % ».
  if (l.base !== undefined || l.taux_majoration !== undefined) {
    l = { ...l, quantite: l.base ?? "", taux: l.taux_majoration ?? "" };
  }
  if (l.taux === undefined || l.taux === null || l.taux === "") l = { ...l, taux: tauxParDefaut(code) };
  /* TOUT SUR LA MÊME LIGNE, et elle se lit comme une phrase :

       1 cachet à 130 €   Théâtre de la Ville   le 12
       4 cachets à 130 €  Théâtre 71            le 14 15 17 18

     « Pour moi tout est sur la même ligne : les dates, les lieux et le
     cachet » (12/09/2026). C'est la bonne maille, et elle règle le lieu par
     cachet d'un seul coup : une ligne de paie EST un groupe de cachets, à un
     taux, à un endroit, à des dates. Le lieu n'a plus à être rattaché à une
     date d'un côté et à un engagement de l'autre — il est là, sur la ligne
     qui le porte.

     Ce qui a disparu au passage : le rappel d'unité en fin de ligne
     (« cachet », qui redisait le déroulant) et les « 12 h » du cachet, qui
     sont une constante du règlement. Ce qui reste en mots : « à » et « € »,
     les deux seuls qui disent lequel des nombres est le taux. */
  div.innerHTML = `
    <!-- LES JOURS D'ABORD (23/09/2026) : ce sont eux qui situent la paie et
         qui comptent les cachets. -->
    <button type="button" class="r-jours-btn" title="cocher les jours dans le calendrier">—</button>
    <input class="r-quantite" type="number" min="0" step="0.5" placeholder="qté"
           value="${l.quantite ?? ""}">
    <select class="r-code">${optionsRubriques(code, nat)}</select>
    <span class="r-mot discret">à</span>
    <input class="r-taux" type="number" min="0" step="0.01" placeholder="taux"
           value="${l.taux ?? ""}">
    <span class="r-mot discret">€</span>
    <input class="r-lieu" placeholder="lieu — figure au contrat"
           value="${echapper(l.lieu || "")}">
    <!-- LE GENRE d'un avantage en nature (repas, logement, véhicule, NTIC,
         autres : S21.G00.54.001) — seulement sur la rubrique qui le demande,
         et ses valeurs viennent du moteur (« genres »). Vide : celui de la
         rubrique, qui n'est écrit nulle part. -->
    <select class="r-genre cachee" title="genre de l'avantage en nature (bloc 54)"></select>
    <!-- LES JOURS SE COCHENT DANS UN CALENDRIER (15/09/2026 : « plus
         esthétique et clair que de taper 12, 24, 26 »). Le bouton dit les
         jours cochés ; le champ caché garde l'écriture « 14 15 17 18 » que
         tout le reste de la page lit (joursDe). Les jours cochés dans un
         mois SUIVANT sont le planning de la ligne (data-planning). -->
    <input class="r-jours" type="hidden"
           value="${echapper((l.dates || []).map((x) => +jourDe(x).slice(8)).join(" "))}">
    <input class="r-heures" type="number" min="0" step="0.5" placeholder="heures"
           value="${l.heures ?? ""}">
    <button class="supprimer" title="retirer cette ligne">&times;</button>`;
  const majAffichage = () => {
    const r = rubriqueDe(div.querySelector(".r-code").value);
    const veutHeures = !!r && r.saisie.includes("heures");
    // `.cachee` et non l'attribut `hidden` : la feuille de style pose
    // `input { display: block }`, qui l'emporterait sur le defaut du
    // navigateur. Le champ resterait visible sans qu'on comprenne pourquoi.
    div.querySelector(".r-heures").classList.toggle("cachee", !veutHeures);
    // UNE LIGNE « MONTANT » (prime, acompte, indemnité, défraiement réel —
    // 30/09/2026) : ni quantité, ni jours, ni lieu. On tape la somme ; la
    // quantité vaut 1 et reste écrite, le moteur lit quantité × taux.
    const montant = !!r && r.saisie.includes("montant") && !r.saisie.includes("quantite");
    const q = div.querySelector(".r-quantite");
    if (montant && q.value === "") q.value = 1;
    q.classList.toggle("cachee", montant);
    div.querySelector(".r-jours-btn").classList.toggle("cachee", montant);
    div.querySelector(".r-lieu").classList.toggle("cachee", montant);
    div.querySelector(".r-mot").classList.toggle("cachee", montant);
    div.querySelector(".r-taux").placeholder = montant ? "montant" : "taux";
    // Une ligne en pourcentage : « base € à taux % », sans jours ni lieu.
    const pct = !!r && r.saisie.includes("taux_majoration");
    const mots = div.querySelectorAll(".r-mot");
    mots[0].textContent = pct ? "€ à" : "à";
    mots[1].textContent = pct ? "%" : "€";
    if (pct) {
      q.placeholder = "base €";
      div.querySelector(".r-taux").placeholder = "%";
      div.querySelector(".r-jours-btn").classList.add("cachee");
      div.querySelector(".r-lieu").classList.add("cachee");
    } else {
      q.placeholder = "qté";
    }
    // Le genre, sur la rubrique qui en a un : les valeurs sont celles du
    // moteur. Le choix se garde d'une rubrique à l'autre tant qu'il existe.
    const genres = (r && r.genres) || [];
    const g = div.querySelector(".r-genre");
    g.classList.toggle("cachee", !genres.length);
    const voulu = g.dataset.pose === "1" ? g.value : (l.genre || "");
    g.innerHTML = `<option value="">— genre par défaut —</option>`
      + genres.map((x) => `<option value="${echapper(x.code)}">${echapper(x.code)} — ${
        echapper(String(x.libelle).replace(/^Avantage en nature : /, ""))}</option>`).join("");
    g.value = genres.some((x) => x.code === voulu) ? voulu : "";
    g.dataset.pose = "1";
  };
  div.querySelector(".r-genre").onchange = rafraichirApercu;
  // Changer la rubrique d'une ligne dont le taux n'a pas été tapé : il suit
  // la rubrique. Un taux de cachet ne devient pas un taux horaire.
  div.dataset.code = code;
  div.querySelector(".r-code").onchange = () => {
    const neuf = div.querySelector(".r-code").value;
    const t = div.querySelector(".r-taux");
    if (t.value === "" || String(tauxParDefaut(div.dataset.code)) === t.value) {
      t.value = tauxParDefaut(neuf);
    }
    div.dataset.code = neuf;
    majAffichage(); rafraichirApercu();
  };
  div.querySelector(".supprimer").onclick = () => { div.remove(); rafraichirApercu(); };
  div.querySelectorAll("input").forEach((c) => { c.oninput = rafraichirApercu; });
  // Taper un taux ici, c'est décider du prochain DE LA MÊME RUBRIQUE : le
  // cachet par défaut ne bouge que sur une ligne de cachets (25/09/2026 : un
  // taux horaire était devenu « cachet à 200 € par défaut »).
  div.querySelector(".r-taux").oninput = () => {
    const v = div.querySelector(".r-taux").value;
    const r = div.querySelector(".r-code").value;
    if (v !== "" && +v > 0) {
      if (r === "cachet") { DERNIER_TAUX = +v; afficherRappelsMois(); }
      else TAUX_PAR_RUBRIQUE[r] = +v;
    }
    rafraichirApercu();
  };
  /* LES JOURS COMPTENT LES CACHETS. Taper « 14 15 17 18 » sur une ligne de
     cachets, c'est dire quatre cachets — les recompter à la main serait un
     deuxième endroit où se tromper, et l'AEM déclare les deux (nombre de
     cachets ET nombre de jours). On ne le fait QUE pour les rubriques dont
     l'unité est le cachet : six heures de masterclass tiennent en un jour, et
     là la quantité et les dates disent deux choses différentes. */
  div.querySelector(".r-jours").oninput = () => {
    const r = rubriqueDe(div.querySelector(".r-code").value);
    if (r && r.unite === "cachet") {
      const n = joursDe(div.querySelector(".r-jours")).length;
      div.querySelector(".r-quantite").value = n || "";
    }
    rafraichirApercu();
  };
  div.dataset.planning = JSON.stringify((l.planning || []).map(jourDe).filter(Boolean));
  div.querySelector(".r-jours-btn").onclick = (ev) => {
    ev.preventDefault();
    ouvrirCalendrier(div);
  };
  majJoursBouton(div);
  majAffichage();
  return div;
}

/* ------------------------------------------------------------ le calendrier
   « J'aime bien l'idée de pouvoir cocher les dates dans un petit planning,
   plus esthétique et clair que de taper 12, 24, 26. Du coup avec une flèche
   on pourrait aller au mois suivant. Avec un petit avertissement : vous êtes
   en train de créer un contrat sur plusieurs mois. Valider ? » (15/09/2026)

   Un mois à la fois, sous la ligne de paie. Les jours du mois de la saisie
   se cochent comme jours joués (ils comptent les cachets) ; ceux des mois
   suivants sont le PLANNING de la ligne — pas payés ce mois-ci, mais connus :
   le contrat imprimé les liste, la fin du contrat se cale sur le dernier, et
   le mois venu, le contrat repris d'office les retrouve déjà cochés.
   On remonte AUSSI avant le mois de la saisie, mais pour LIRE (16/09/2026,
   « j'aimerais pouvoir accéder à l'historique au moins des contrats dans le
   calendrier ») : les mois passés montrent les contrats déclarés des
   salariés du bloc — en plage grisée quand on ne connaît que début, fin et
   nombre de cachets (l'historique importé des AEM), en jours pleins quand le
   mois a été produit ici. Rien ne s'y coche : un cachet d'octobre se paie
   dans le fichier d'octobre. C'est un plancher, pas une position : les
   autres employeurs du salarié n'y sont pas. */
const JOURS_SEMAINE = ["L", "M", "M", "J", "V", "S", "D"];
const MOIS_ABR = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août",
                  "sept.", "oct.", "nov.", "déc."];

function planningDe(ligne) {
  try { return JSON.parse(ligne.dataset.planning || "[]"); } catch (e) { return []; }
}

/** Ce que dit le bouton : « le 12, 13 », puis le planning « +1 nov. +3 déc. ». */
function majJoursBouton(ligne) {
  const b = ligne.querySelector(".r-jours-btn");
  if (!b) return;
  const jours = joursDe(ligne.querySelector(".r-jours"));
  const plan = planningDe(ligne);
  const parMois = {};
  plan.forEach((iso) => { const m = iso.slice(0, 7); parMois[m] = (parMois[m] || 0) + 1; });
  let texte = jours.length ? jours.join(", ") : "— jours —";
  const suite = Object.keys(parMois).sort()
    .map((m) => `+${parMois[m]} ${MOIS_ABR[+m.slice(5, 7) - 1]}`).join(" ");
  b.textContent = texte + (suite ? " " + suite : "");
  b.classList.toggle("vide", !jours.length);
  b.classList.toggle("planning", !!suite);
}

/** Les cases d'un mois PASSÉ : une plage de contrat en gris, un jour joué
 *  connu en gris plein, le libellé au survol. Partagé entre le calendrier
 *  d'une ligne et la vue du mois. */
function casesMoisPasse(vue, contrats, avecNom) {
  const an = +vue.slice(0, 4), mo = +vue.slice(5, 7);
  const nb = new Date(an, mo, 0).getDate();
  const premier = (new Date(an, mo - 1, 1).getDay() + 6) % 7;
  const plage = new Map(), joue = new Map();
  contrats.forEach((c) => {
    const libelle = (avecNom ? c.nom.split(" ")[0] + " · " : "") + c.titre;
    (c.dates || []).forEach((iso) => joue.set(iso, (joue.get(iso) || []).concat(libelle)));
    for (let j = 1; j <= nb; j++) {
      const iso = `${vue}-${String(j).padStart(2, "0")}`;
      if (iso >= c.debut && iso <= c.fin) plage.set(iso, (plage.get(iso) || []).concat(libelle));
    }
  });
  let cases = "";
  for (let i = 0; i < premier; i++) cases += `<span class="c-vide"></span>`;
  for (let j = 1; j <= nb; j++) {
    const iso = `${vue}-${String(j).padStart(2, "0")}`;
    const cls = joue.has(iso) ? "hist-joue" : (plage.has(iso) ? "hist" : "");
    const titre = (joue.get(iso) || plage.get(iso) || []).join(" / ");
    cases += `<span class="c-jour lu ${cls}" ${titre ? `title="${echapper(titre)}"` : ""}>${j}</span>`;
  }
  return JOURS_SEMAINE.map((x) => `<span class="c-sem">${x}</span>`).join("") + cases;
}

/** Une ligne de la liste des contrats d'un mois passé. */
function ligneContratPasse(c, avecNom) {
  return `<div class="c-passe" title="${echapper(c.numero_objet)}">
      <span>${echapper((avecNom ? c.nom.split(" ")[0] + " · " : "") + c.titre)}</span>
      <span class="discret">${echapper(jjmmaaaa(c.debut).slice(0, 5))}→${echapper(jjmmaaaa(c.fin).slice(0, 5))}
        · ${c.cachets} cachet${c.cachets > 1 ? "s" : ""}${c.heures ? ` + ${c.heures} h` : ""}</span>
    </div>`;
}

function fermerCalendriers() {
  document.querySelectorAll(".calendrier").forEach((c) => c.remove());
}

function ouvrirCalendrier(ligne, moisForce) {
  fermerCalendriers();
  // `moisForce` : la correction d'un mois deja depose se coche dans SON mois,
  // pas dans celui qu'affiche l'ecran de paie (18/09/2026).
  const mois = moisForce || document.getElementById("mois").value;
  if (!mois) { dire("Choisir le mois d'abord."); return; }
  const bloc = ligne.closest(".engagement");
  const enCours = bloc && bloc.classList.contains("en-cours");
  const fin = bloc ? bloc.querySelector(".e-fin").value : "";
  const cal = document.createElement("div");
  cal.className = "calendrier";
  ligne.appendChild(cal);
  // Sous le bouton des jours, sans déborder de la ligne.
  const btn = ligne.querySelector(".r-jours-btn");
  cal.style.left = Math.max(0, Math.min(btn.offsetLeft, ligne.clientWidth - 272)) + "px";
  let vue = mois;                       // le mois affiché, AAAA-MM
  let attente = null;                   // un jour de planning qui attend « Valider »
  // Les contrats passés, par mois affiché, chargés à la demande. `null`
  // tant qu'on attend le serveur : la grille se dessine sans, puis se redessine.
  const passes = new Map();
  const salaries = bloc ? salariesDuBloc(bloc) : [];
  const chargerPasses = (m) => {
    if (passes.has(m)) return;
    passes.set(m, null);
    api("contrats-passes", { mois: m, salaries }).then((r) => {
      passes.set(m, r.contrats || []);
      if (vue === m && cal.isConnected) dessiner();
    }).catch(() => passes.set(m, []));
  };

  const dessiner = () => {
    const an = +vue.slice(0, 4), mo = +vue.slice(5, 7);
    const nb = new Date(an, mo, 0).getDate();
    const premier = (new Date(an, mo - 1, 1).getDay() + 6) % 7;   // lundi = 0
    const jours = new Set(joursDe(ligne.querySelector(".r-jours")));
    const plan = new Set(planningDe(ligne));
    const ici = vue === mois;
    const passe = vue < mois;
    if (passe) chargerPasses(vue);
    const contrats = passe ? (passes.get(vue) || []) : [];
    let cases = "";
    for (let i = 0; i < premier && !passe; i++) cases += `<span class="c-vide"></span>`;
    for (let j = 1; j <= nb && !passe; j++) {
      const iso = `${vue}-${String(j).padStart(2, "0")}`;
      const coche = ici ? jours.has(j) : plan.has(iso);
      const horsContrat = enCours && fin && iso > fin;
      cases += `<button type="button" class="c-jour ${coche ? (ici ? "joue" : "prevu") : ""}
        ${horsContrat ? "hors" : ""}" data-iso="${iso}" data-j="${j}"
        ${horsContrat ? "disabled title=\"après la fin du contrat\"" : ""}>${j}</button>`;
    }
    const nJoues = jours.size, nPlan = plan.size;
    const listePasses = !passe ? "" : (passes.get(vue) === null
      ? `<div class="c-passes discret">…</div>`
      : `<div class="c-passes">${contrats.length
          ? contrats.map((c) => ligneContratPasse(c, salaries.length !== 1)).join("")
          : `<span class="discret">${salaries.length ? "aucun contrat déclaré ce mois-là" : "cocher un salarié pour voir ses contrats"}</span>`}
        </div>`);
    cal.innerHTML = `
      <div class="c-tete">
        <button type="button" class="c-prec" title="mois précédent">‹</button>
        <b>${echapper(moisEnClair(vue))}</b>
        <button type="button" class="c-suiv" title="mois suivant">›</button>
      </div>
      <div class="c-grille">
        ${passe ? casesMoisPasse(vue, contrats, salaries.length !== 1)
                : JOURS_SEMAINE.map((x) => `<span class="c-sem">${x}</span>`).join("") + cases}
      </div>
      ${listePasses}
      ${attente ? `
        <div class="c-avert">
          <b>Vous êtes en train de créer un contrat sur plusieurs mois</b>
          — du ${echapper(jjmmaaaa(debutDuBloc(bloc) || mois + "-01"))} au
          ${echapper(jjmmaaaa(attente))}. Les cachets de ${echapper(moisEnClair(attente.slice(0, 7)))}
          se paieront dans le fichier de ce mois-là (« reprendre un contrat en
          cours » les retrouvera cochés) ; ce mois-ci partent le contrat et la
          DPAE pour le contrat entier. Valider ?
          <div class="c-actions">
            <button type="button" class="secondaire c-annuler">Annuler</button>
            <button type="button" class="primaire c-valider">Valider</button>
          </div>
        </div>` : `
        <div class="c-pied">
          <span class="discret">${passe ? "mois passé : ce qui a été déclaré, en lecture seule"
            : `${ici ? "jours joués ce mois-ci" : "planning : payé dans son mois"}
            · ${nJoues} joué${nJoues > 1 ? "s" : ""}${nPlan ? `, ${nPlan} prévu${nPlan > 1 ? "s" : ""}` : ""}`}</span>
          <button type="button" class="secondaire c-ok">OK</button>
        </div>`}`;
    cal.querySelector(".c-prec").onclick = () => { vue = moisPrecedent(vue); attente = null; dessiner(); };
    cal.querySelector(".c-suiv").onclick = () => { vue = moisSuivant(vue); attente = null; dessiner(); };
    const ok = cal.querySelector(".c-ok");
    if (ok) ok.onclick = fermerCalendriers;
    const valider = cal.querySelector(".c-valider");
    if (valider) valider.onclick = () => {
      bloc.dataset.pluriOk = "1";
      const iso = attente; attente = null;
      basculerPlanning(ligne, iso);
      dessiner();
    };
    const annuler = cal.querySelector(".c-annuler");
    if (annuler) annuler.onclick = () => { attente = null; dessiner(); };
    cal.querySelectorAll(".c-jour:not([disabled])").forEach((b) => {
      b.onclick = () => {
        if (ici) {
          basculerJour(ligne, +b.dataset.j);
        } else {
          const iso = b.dataset.iso;
          const dejaPluri = (bloc && bloc.dataset.pluriOk === "1") || enCours
            || planningDuBloc(bloc).length || (fin && fin.slice(0, 7) > mois);
          if (!planningDe(ligne).includes(iso) && !dejaPluri) { attente = iso; dessiner(); return; }
          basculerPlanning(ligne, iso);
        }
        dessiner();
      };
    });
  };
  dessiner();
  // Fermer en cliquant ailleurs, ou à la touche Échap.
  setTimeout(() => {
    const dehors = (ev) => {
      if (!cal.isConnected) { document.removeEventListener("click", dehors); return; }
      // `composedPath` et non `contains` : un clic sur un jour redessine la
      // grille, et le bouton cliqué n'est déjà plus dans la page quand on
      // arrive ici -- `contains` dirait « dehors » et refermerait tout.
      const chemin = ev.composedPath ? ev.composedPath() : [];
      if (!chemin.includes(cal) && ev.target !== ligne.querySelector(".r-jours-btn")) {
        fermerCalendriers(); document.removeEventListener("click", dehors);
      }
    };
    document.addEventListener("click", dehors);
  }, 0);
  cal.onkeydown = (ev) => { if (ev.key === "Escape") fermerCalendriers(); };
}

/** Coche ou décoche un jour du mois de la saisie : la ligne compte ses
 *  cachets, comme quand on tapait les jours. */
function basculerJour(ligne, j) {
  const champ = ligne.querySelector(".r-jours");
  const jours = new Set(joursDe(champ));
  if (jours.has(j)) jours.delete(j); else jours.add(j);
  champ.value = [...jours].sort((a, b) => a - b).join(" ");
  champ.dispatchEvent(new Event("input"));
  majJoursBouton(ligne);
}

/** Coche ou décoche un jour de planning (un mois suivant), et cale la fin
 *  du contrat sur le dernier jour prévu — sauf sur un contrat en cours, dont
 *  la fin a été fixée par son premier mois. */
function basculerPlanning(ligne, iso) {
  const plan = new Set(planningDe(ligne));
  if (plan.has(iso)) plan.delete(iso); else plan.add(iso);
  ligne.dataset.planning = JSON.stringify([...plan].sort());
  majJoursBouton(ligne);
  const bloc = ligne.closest(".engagement");
  if (bloc && !bloc.classList.contains("en-cours")) {
    const tout = planningDuBloc(bloc);
    const finChamp = bloc.querySelector(".e-fin");
    const dernier = tout.length ? tout[tout.length - 1] : "";
    if (dernier && (!finChamp.value || finChamp.value < dernier || finChamp.value === bloc.dataset.finAuto)) {
      finChamp.value = dernier; bloc.dataset.finAuto = dernier;
    } else if (!dernier && bloc.dataset.finAuto && finChamp.value === bloc.dataset.finAuto) {
      finChamp.value = ""; bloc.dataset.finAuto = "";
    }
    majContrat(bloc);
  }
  rafraichirApercu();
}

/** Tout le planning d'un bloc, toutes lignes confondues, trié. */
function planningDuBloc(bloc) {
  const vus = new Set();
  if (bloc) bloc.querySelectorAll(".rubrique").forEach((r) => planningDe(r).forEach((x) => vus.add(x)));
  return [...vus].sort();
}

function debutDuBloc(bloc) {
  if (!bloc) return "";
  const jours = joursDuBloc(bloc);
  return bloc.querySelector(".e-debut").value || jours[0] || "";
}

function moisPrecedent(mois) {
  const an = +mois.slice(0, 4), mo = +mois.slice(5, 7);
  return mo === 1 ? `${an - 1}-12` : `${an}-${String(mo - 1).padStart(2, "0")}`;
}

/** Les jours tapés « 14 15 17 18 », en nombres, sans doublon et triés. */
function joursDe(champ) {
  const vus = new Set();
  String(champ.value).split(/[^0-9]+/).filter(Boolean).forEach((x) => vus.add(+x));
  return [...vus].sort((a, b) => a - b);
}

/** Les lignes viennent du moteur, y compris pour une saisie ancienne écrite
 *  en `cachets` : c'est lui qui dit ce qu'il a compris, la page ne redevine
 *  rien. Une saisie neuve n'en a pas encore — on offre alors une ligne vide. */
function lignesDe(e) {
  return (e.lignes && e.lignes.length) ? e.lignes : [{}];
}

/* LE DERNIER TAUX DONNÉ, et c'est tout ce qui reste du « par défaut du mois ».
   « Pas besoin de taux de cachet : on met de base le dernier taux donné.
   Simple et efficace » (12/09/2026). Il se reprend de la saisie chargée, et
   il suit ce qu'on tape : la ligne de paie suivante, et le mois suivant,
   partent de là. Il continue d'être écrit dans le fichier — le moteur s'en
   sert comme défaut d'un engagement qui ne dit pas son taux — mais plus
   personne n'a à le saisir. */
let DERNIER_TAUX = 130;
/* Le dernier taux donné pour chaque AUTRE rubrique (heure, service de
 * répétition…). Le cachet garde le sien dans DERNIER_TAUX, qui s'enregistre. */
const TAUX_PAR_RUBRIQUE = {};
function tauxParDefaut(code) {
  return code === "cachet" ? DERNIER_TAUX : (TAUX_PAR_RUBRIQUE[code] ?? "");
}
let SAISIE_DATE_PAIEMENT = "";   // celle du fichier, ou la fin du mois

/** Le dernier jour du mois. La date de paiement, qui ne s'affiche plus :
 *  « c'est juste écrit dans le contrat, la fin du mois ». */
function finDuMois(mois) {
  // Un mois vide ou mal formé n'a pas de fin : `new Date(NaN).toISOString()`
  // levait « RangeError: Invalid time value » (incident du 01/10/2026).
  if (!/^\d{4}-\d{2}$/.test(String(mois || ""))) return "";
  const [an, mo] = String(mois).split("-").map(Number);
  // Le jour même, sans passer par l'UTC (à Paris, minuit local est encore la
  // veille en UTC : le 31 devenait le 30).
  return `${an}-${String(mo).padStart(2, "0")}-${String(new Date(an, mo, 0).getDate()).padStart(2, "0")}`;
}

/** Ce qui s'applique au mois, quand un engagement ne dit rien de lui-même.
 *  Il n'en reste que le taux : le lieu appartient au cachet, la date de
 *  paiement est la fin du mois, et le spectacle n'a jamais eu de défaut. */
function defautsDuMois() {
  return { taux_cachet: DERNIER_TAUX, lieu: "" };
}

function titreSpectacle(cle) {
  if (!cle) return "aucun spectacle";
  const s = (ETAT.spectacles || []).find((x) => x.cle === cle);
  return s ? s.titre : cle;
}

/* =======================================================================
   LE LIEU ET LES JOURS SONT SUR LA LIGNE DE PAIE
   =======================================================================
   Décidé le 11/09/2026 sur un exemple réel — quatre Zerbinette dans le
   mois, un à Berlin, un à Paris, deux à Avallon — écrit le 12, puis recadré par
   lui le même jour, et c'est le recadrage qui a tout simplifié :

     « Pour moi tout est sur la même ligne : les dates, les lieux et le
       cachet. Du coup on peut faire 1 cachet à 130 € au Théâtre de la Ville
       le 12. Ou 4 cachets à 130 € au Théâtre 71 le 14, 15, 17, 18. »

   La première version posait le lieu sur la DATE, avec un héritage à trois
   étages (la date, l'engagement, le mois) et une zone dépliante sous chaque
   engagement pour les cas où les villes diffèrent. Ça marchait, et c'était
   une mécanique à expliquer. Sa maille à lui n'a pas besoin d'héritage : une
   ligne de paie EST un groupe de cachets, à un taux, à un endroit, à des
   dates. Deux villes, deux lignes. Rien à hériter, rien à déplier, rien à
   trancher entre « ce qui est tapé » et « ce qui est repris ».

   C'est TOUJOURS UNE SEULE PAIE : même spectacle, donc même numéro d'objet,
   donc un contrat, un bulletin, une AEM. Les jours de l'engagement sont la
   réunion des jours de ses lignes — `joursDuBloc` ici, `dates_engagement`
   dans le moteur, et les deux composent la même liste.

   Le lieu ne se déclare NULLE PART : ni DSN, ni AEM, ni DPAE. Il figure au
   contrat, qui groupe les dates par lieu, et nulle part ailleurs. */

/** Le jour d'une date écrite d'une façon ou de l'autre — « 2026-10-02 » ou
 *  {"jour": "2026-10-02", "lieu": "Berlin"}. */
/** Le catalogue des métiers, tel que le moteur le rend (route « etat »),
 *  groupé par famille dans SON ordre. La page ne trie pas, elle affiche. */
function metierDe(code) {
  return (ETAT.emplois || []).find((m) => m.code === code) || null;
}

function optionsMetiers(choisi, vide = "— celui de la fiche —") {
  const familles = ETAT.familles_emplois || [];
  const parFamille = {};
  (ETAT.emplois || []).forEach((m) => { (parFamille[m.famille] ||= []).push(m); });
  let html = `<option value="">${echapper(vide)}</option>`;
  familles.forEach((f) => {
    if (!parFamille[f]) return;
    html += `<optgroup label="${echapper(f)}">` + parFamille[f].map((m) =>
      `<option value="${echapper(m.code)}">${echapper(m.libelle)}${m.cadre_par_defaut ? " (cadre)" : ""}</option>`)
      .join("") + `</optgroup>`;
  });
  // Un code hors catalogue mais présent dans le fichier reste proposé tel
  // quel : on ne perd pas un métier parce que l'écran ne le connaît pas.
  // Un métier décoché dans l'onglet Métiers garde son nom là où il est choisi.
  if (choisi && !metierDe(choisi)) {
    const ailleurs = (ETAT.emplois_autres || []).find((m) => m.code === choisi);
    html += `<option value="${echapper(choisi)}">${echapper(ailleurs ? ailleurs.libelle : choisi)}</option>`;
  }
  return html;
}

function jourDe(x) {
  return (x && typeof x === "object") ? String(x.jour || "") : String(x || "");
}

/** Un engagement : QUI, QUOI, QUAND, COMBIEN.
 *
 *  Le « quoi » était en haut du formulaire, une fois pour le mois. C'est juste
 *  la plupart du temps, et faux exactement quand ça compte : deux spectacles,
 *  deux lieux dans le même mois.
 *
 *  LE SPECTACLE N'EST PAS TRAITÉ COMME LES AUTRES, et c'est délibéré. Le lieu
 *  et le taux se répètent d'une paie à l'autre : ils ont un défaut de mois, et
 *  l'engagement s'en écarte quand il le faut. Le spectacle, lui, EST la raison
 *  d'avoir plusieurs paies — un contrat porte un numéro d'objet, donc un
 *  spectacle, et le mois en compte plusieurs. Il est donc une case de cet
 *  engagement, toujours visible, sans défaut et sans héritage. */
function ligneEngagement(e = {}) {
  const div = document.createElement("div");
  div.className = "engagement";
  const actifs = ETAT.salaries || [];
  // QUI : une liste à COCHER, pas un menu, et UN bloc pour tous les cochés.
  //
  // L'ancienne option « Les deux » qui dédoublait le bloc à la sélection
  // était taillée pour une compagnie à deux têtes, et dédoublait trop tôt.
  // La demande : « il faut pouvoir cocher dedans, x Célimène
  // x Marin, pas d'option les deux d'un coup » ; puis : « le dédoublement
  // doit se faire une fois validé, pas avant — c'est ce qui va me faire
  // aller vite quand j'ai plusieurs employés pour le même spectacle avec la
  // même paye ». Donc : on coche qui on veut, on saisit UNE fois, on valide
  // — et LÀ le bloc se démultiplie, un bloc par salarié (validerPlusieurs).
  //
  // Le moteur, lui, ne connaît toujours qu'un salarié par engagement : c'est
  // saisieCourante qui écrit un engagement par salarié coché, et chargerMois
  // qui regroupe au retour ce qui est identique et pas encore validé.
  const voulus = new Set(e.salaries || (e.salarie ? [e.salarie] : []));
  const connus = new Set(actifs.map((s) => s.cle));
  const cases = actifs.map(
    (s) => `<label><input type="checkbox" class="e-qui-case" value="${echapper(s.cle)}"
       ${voulus.has(s.cle) ? "checked" : ""}> ${echapper(s.libelle)}</label>`)
    // Un salarié du fichier absent des actifs (fiche mise de côté) garde sa
    // case, cochée : on ne perd pas une paie parce qu'on a archivé quelqu'un.
    .concat([...voulus].filter((c) => !connus.has(c)).map(
      (c) => `<label><input type="checkbox" class="e-qui-case" value="${echapper(c)}"
         checked> ${echapper(c)} <span class="discret">(fiche mise de côté)</span></label>`))
    .join("");
  div.innerHTML = `
    <div class="ligne1">
      <!-- Pas de « + » ici : une fiche neuve se crée dans Configuration.
           La saisie d'une paie doit rester simple et agréable ; on y choisit,
           on n'y administre pas (13/09/2026). -->
      <div class="champ">Salarié
        <details class="e-qui">
          <summary class="vide">— cocher —</summary>
          <div class="e-qui-liste">${cases}</div>
        </details>
      </div>
      <!-- LA NATURE DU CONTRAT (19/09/2026). Elle ne se devine pas : un
           engagement muet est un CDDU du spectacle, et c'est ce qu'ont été
           les 146 contrats de l'historique. Ce qui manquait, c'était de
           pouvoir dire AUTRE CHOSE — tant qu'elle n'était pas ici, un
           permanent n'avait aucun endroit où exister dans cet écran, et
           moteur/contrats-base.json le savait tout seul. Elle change la
           forme du bloc : un permanent n'a ni spectacle ni cachets, il a un
           salaire au mois et des faits. -->
      <label class="e-nature-bloc" title="ce que la DSN écrira de la structure de ce contrat">Nature
        <select class="e-nature"></select></label>
      <label class="e-spectacle-bloc">Spectacle
        <select class="e-spectacle"></select></label>
    </div>
    <!-- Les jours et le lieu ne sont plus ici : ils sont sur chaque ligne de
         paie, qui porte désormais la phrase entière — « 4 cachets à 130 € au
         Théâtre 71 le 14 15 17 18 ». Voir ligneRubrique(). -->
    <div class="rubriques"></div>
    <button class="ajouter-rubrique discret">+ une ligne de paie</button>
    <!-- UN PERMANENT NE SE SAISIT PAS EN LIGNES DE PAIE, ET C'EST TOUT
         L'INTÉRÊT. Ce qu'on tape, ce sont des FAITS — un salaire au mois,
         des congés pris, une absence, une prime — et c'est
         operations_permanents.lignes_du_mois qui en fait des lignes : le
         prorata d'un mois incomplet, les deux calculs de l'indemnité de
         congés, la retenue et l'indemnité qui la couvre, le bloc 65 d'une
         suspension. Taper les lignes à la main, ce serait refaire à la main
         ce que la loi impose de calculer. -->
    <div class="e-permanent" hidden>
      <div class="e-mois-paye">
        <label>Salaire mensuel brut
          <input type="number" step="0.01" min="0" class="e-salaire"
                 placeholder="celui du contrat signé"></label>
        <label title="la quotité de travail du contrat (S21.G00.40.013)">Quotité
          <input type="number" step="0.01" min="0" class="e-quotite"></label>
      </div>
      <div class="e-faits">
        <div class="e-fait-groupe">
          <div class="e-fait-tete">Congés pris
            <span class="discret">— en jours ouvrables, le compteur suit</span></div>
          <div class="e-conges"></div>
          <button class="ajouter-fait discret" data-quoi="conges">+ des congés</button>
        </div>
        <div class="e-fait-groupe">
          <div class="e-fait-tete">Absences
            <span class="discret">— ce qui suspend ou réduit le salaire</span></div>
          <div class="e-absences"></div>
          <button class="ajouter-fait discret" data-quoi="absences">+ une absence</button>
        </div>
        <div class="e-fait-groupe">
          <div class="e-fait-tete">Primes</div>
          <div class="e-primes"></div>
          <button class="ajouter-fait discret" data-quoi="primes">+ une prime</button>
        </div>
      </div>
    </div>
    <!-- LES TROIS NOMBRES D'UNE PAIE — ET ON ÉCRIT DANS LES TROIS.
         « J'aimerais voir pour chaque engagement le net pour le salarié, le
         brut et le coût entreprise. Et qu'une fois les cases remplies, on
         puisse mettre par exemple le coût pour l'entreprise et il recalcule
         le brut du cachet » (l'éditeur, 22/09/2026).

         Les voir, d'abord : un brut tout seul ne dit ni ce que le salarié
         touche, ni ce que ça coûte — et ce sont les deux nombres dont on a
         besoin pour décider. Les trois sont donc là, côte à côte, sous les
         lignes de paie.

         Y écrire, ensuite, et c'est la paie prise à l'envers : on connaît
         l'enveloppe (une subvention, une cession, ce qui reste en caisse) et
         on cherche le taux qui la remplit. Taper 500 dans « Coût entreprise »
         d'un engagement à deux cachets de 130 €, c'est demander le taux du
         cachet qui fait que l'employeur sort 500 € — 158,66 €, pas 250.

         CE N'EST PAS UNE DIVISION, et la page ne la fait pas : plafond de la
         Sécurité sociale, tranches de retraite, abattement, réduction
         générale — le taux effectif dépend du montant lui-même. C'est le
         moteur qui cherche, en rejouant la paie entière (route « ajuster »,
         paie/src/routes_ecritures.rs), et la note dit ce qui est ATTEINT,
         jamais ce qui a été demandé : deux cachets ne tombent pas toujours
         sur 500,00 € pile, et à égalité c'est le taux qui ne dépasse PAS
         l'enveloppe qui gagne. -->
    <!-- LA SAISIE, PENSÉE DANS L'ORDRE OÙ L'ON REMPLIT (23/09/2026). Qui et
         quel spectacle en tête ; les lignes de paie, jours d'abord ; puis le
         RÉSULTAT en une ligne — le net, ce qu'on vire. Viser un montant est
         un outil, pas une lecture : il se replie. Le métier, la case cadre,
         les bornes et le détail du contrat servent rarement : « Plus
         d'options », ouvert d'office quand l'un d'eux est déjà rempli. -->
    <div class="e-pied">
      <span class="e-net"></span>
      <span class="e-suite"></span>
      <button type="button" class="lien e-viser-btn">Viser un montant</button>
      <button type="button" class="lien e-options-btn">Plus d'options</button>
    </div>
    <div class="e-chiffres" hidden>
      <label title="ce que le salarié touche sur son compte">Net salarié
        <input type="number" step="0.01" min="0" class="e-vise" data-cible="net"></label>
      <label title="le brut du bulletin">Brut
        <input type="number" step="0.01" min="0" class="e-vise" data-cible="brut"></label>
      <label title="brut + cotisations patronales : ce que l'employeur sort">Coût entreprise
        <input type="number" step="0.01" min="0" class="e-vise" data-cible="cout"></label>
      <span class="e-chiffres-note discret">Écrire dans une case : les taux se
        recalculent pour y tomber.</span>
    </div>
    <div class="e-options" hidden>
      <div class="e-options-ligne">
      <!-- LE MÉTIER DE CE CONTRAT. Vide : celui de la fiche (le cas général).
           Choisi : le moteur pose d'un coup code emploi, PCS, libellé, statut
           et classement DSN (moteur/emplois.py). La case « cadre » suit le
           défaut du catalogue et se décoche. -->
      <label class="e-metier-bloc" title="le métier de ce contrat, s'il diffère de la fiche">Métier
        <select class="e-metier"></select></label>
      <label class="coche e-cadre-bloc" title="cadre pour la retraite complémentaire (DSN 40.003 = 01)">
        <input type="checkbox" class="e-cadre"> cadre</label>
      </div>
    <!-- LE CONTRAT, replié : « du 12/10/2026 au 20/12/2026 », préréglé sur
         le premier et le dernier jour joué. On l'ouvre pour une seule chose :
         allonger la date de fin quand le contrat se poursuit le mois suivant
         (contrats sur plusieurs mois, 15/09/2026). Le numéro y apparaît, en
         lecture seule, une fois le mois produit. -->
    <details class="e-contrat">
      <summary></summary>
      <div class="e-contrat-champs">
        <label class="e-borne">Début du contrat <input type="date" class="e-debut"></label>
        <label class="e-borne">Fin du contrat <input type="date" class="e-fin"></label>
        <span class="e-numero discret"></span>
      </div>
      <!-- LE MOTIF DE RECOURS (S21.G00.40.021). Seul un CDD ordinaire en a
           un, et il est obligatoire : c'est lui qui rend le contrat licite
           au regard de L1242-2, et la plate-forme le contrôle (SIG-11). Un
           CDD d'usage n'apparaît pas dans cette liste et c'est délibéré — il
           se saisit comme un CDD d'usage, avec tout ce qui va avec. -->
      <label class="e-recours-bloc" hidden>Motif de recours
        <select class="e-recours"></select></label>
      <!-- LA FIN D'UN CONTRAT QUI SE SIGNALE (19/09/2026). Trois faits que
           le moteur ne devine pas, et il a raison de ne pas les deviner :
           une date de notification ne se déduit pas d'un salaire, et le
           motif de rupture change les droits du salarié à l'assurance
           chômage. Le bloc S21.G00.63 est OBLIGATOIRE dans un signalement
           (cardinalité 1,*) : même sans préavis, il se déclare — c'est le
           type « 90 - pas de clause de préavis applicable », et ses deux
           dates deviennent alors interdites.

           Rien de tout cela sur un CDDU du spectacle : sa fin part dans la
           DSN mensuelle par le circuit dérogatoire, et le bloc reste caché. -->
      <div class="e-rupture" hidden>
        <div class="e-fait-tete">La fin de ce contrat
          <span class="discret">— ce que le signalement (nature 07) déclarera</span></div>
        <label>Motif de la rupture
          <select class="e-motif-rupture"></select></label>
        <!-- Les dates et la transaction selon le motif (30/09/2026,
             permanents.faits_de_rupture) : notifiée pour une rupture que
             l'un décide, engagée pour un licenciement, signée pour une
             rupture conventionnelle, la transaction après un litige. -->
        <label data-fait="engagement_licenciement" hidden
               title="la convocation à l'entretien préalable (L1232-2 ; L1332-2 pour une faute)">Procédure engagée le
          <input type="date" class="e-engagement-licenciement"></label>
        <label data-fait="notification_rupture" hidden>Notifiée le
          <input type="date" class="e-notification"></label>
        <label data-fait="signature_convention" hidden
               title="la date de signature de la convention de rupture (L1237-13)">Convention signée le
          <input type="date" class="e-signature-convention"></label>
        <label>Préavis
          <select class="e-preavis-type"></select></label>
        <label class="e-preavis-dates">du
          <input type="date" class="e-preavis-debut"></label>
        <label class="e-preavis-dates">au
          <input type="date" class="e-preavis-fin"></label>
        <label data-fait="transaction" hidden>Transaction
          <select class="e-transaction"></select></label>
        <label title="le dernier jour payé au salaire habituel — la fin du contrat, sauf préavis non effectué">Dernier jour payé
          <input type="date" class="e-dernier-paye" placeholder="la fin du contrat"></label>
        <!-- LES FAITS DU MOTIF (30/09/2026) : le moteur dit, motif par motif,
             ce qu'il doit savoir (permanents.faits_de_rupture) ; la page ne
             montre que ceux-là. Sans eux, une rupture conventionnelle était
             refusée sans qu'on puisse répondre d'ici. -->
        <label data-fait="en_droit_a_la_retraite" hidden
               title="CGI 80 duodecies 6° : l'indemnité n'est imposable que si le salarié est en droit de bénéficier d'une pension de retraite d'un régime obligatoire">En droit à une pension de retraite
          <select class="e-en-droit"><option value="">— à dire —</option>
            <option value="non">non</option><option value="oui">oui</option></select></label>
        <label data-fait="preavis_non_effectue" hidden class="case"
               title="L1234-5 : le préavis dont l'employeur dispense le salarié est payé en indemnité compensatrice">
          <input type="checkbox" class="e-preavis-non-effectue"> préavis non effectué, payé en indemnité</label>
        <label data-fait="preavis_non_effectue" hidden class="e-preavis-mois-l">durée du préavis, en mois
          <input type="number" class="e-preavis-mois" min="0" step="0.5" placeholder="celle de la loi et de la convention"></label>
        <label data-fait="precarite_due" hidden class="case"
               title="L1243-10 : deux cas ne se lisent pas dans le contrat — l'étudiant pendant ses vacances, le salarié qui refuse un CDI">
          <input type="checkbox" class="e-precarite-ecartee"> pas d'indemnité de fin de contrat</label>
        <label data-fait="precarite_due" hidden class="e-precarite-pourquoi-l">pourquoi
          <input class="e-precarite-pourquoi" placeholder="refus d'un CDI, emploi de vacances…"></label>
      </div>
      <!-- LES BORNES NE SE SAISISSENT PLUS POUR UN CONTRAT D'USAGE
           (22/09/2026). L'éditeur : « il y a marqué date de début et fin de
           contrat, mais en fait c'est plus nécessaire puisqu'on clique dans
           le calendrier les dates pour lesquelles on fait les heures ou les
           cachets » — et, sur le contrat qui déborde du mois : « on pourrait
           cliquer sur des jours du mois d'après ».

           Il a raison, et le moteur le fait déjà : Engagement.fin est le
           dernier jour coché, PLANNING COMPRIS (calcul.py : self.fin vaut le
           max du dernier jour joué et du dernier jour de planning). Un CDDU
           d'octobre à décembre se dit donc entièrement au calendrier. Deux
           cases qui ne servent à rien sont deux cases à relire, et une à se
           tromper.

           Elles restent pour les natures payées AU MOIS — un CDI, un CDD
           ordinaire n'ont aucun jour coché, et la date de fin d'un CDD est
           ce qui déclenche le signalement de rupture — et pour un engagement
           qui en porte DÉJÀ : ce qui a été saisi ne devient jamais invisible
           et non modifiable. -->
      <p class="note e-contrat-note"></p>
    </details>
    </div>
    <div class="resolu"></div>
    <!-- LA PAIE VALIDÉE, EN UNE LIGNE (23/09/2026) : quand, qui, pour
         quoi, ce qui reste à faire, le net. Voir peindreCarte(). -->
    <div class="e-resume"></div>
    <div class="avis"></div>
    <div class="etats"></div>`;

  // --- la nature du contrat, et la forme du bloc qu'elle décide
  const selNat = div.querySelector(".e-nature");
  selNat.innerHTML = (ETAT.natures || []).map(
    (n) => `<option value="${echapper(n.cle)}">${echapper(n.libelle)}</option>`).join("");
  selNat.value = e.nature || ETAT.nature_defaut || "";
  selNat.onchange = () => { majNature(div); rafraichirApercu(); };
  const selSpec = div.querySelector(".e-spectacle");
  selSpec.innerHTML = `<option value="">— à choisir —</option>`
    + (ETAT.spectacles || []).map(
      (s) => `<option value="${echapper(s.cle)}">${echapper(s.titre)}</option>`).join("");
  selSpec.value = e.spectacle || "";
  selSpec.onchange = rafraichirApercu;
  // --- le métier
  const selMet = div.querySelector(".e-metier");
  selMet.innerHTML = optionsMetiers(e.metier);
  selMet.value = e.metier || "";
  const cadre = div.querySelector(".e-cadre");
  const majCadre = (depuisCatalogue) => {
    const m = metierDe(selMet.value);
    div.querySelector(".e-cadre-bloc").hidden = !m;
    if (m && depuisCatalogue) cadre.checked = !!m.cadre_par_defaut;
  };
  cadre.checked = e.cadre === true || (e.cadre == null && !!(metierDe(e.metier) || {}).cadre_par_defaut);
  majCadre(false);
  selMet.onchange = () => { majCadre(true); rafraichirApercu(); };
  cadre.onchange = rafraichirApercu;
  // --- les lignes de paie
  const cible = div.querySelector(".rubriques");
  lignesDe(e).forEach((l) => cible.appendChild(ligneRubrique(l, natureDe(selNat.value))));
  div.querySelector(".ajouter-rubrique").onclick = (ev) => {
    ev.preventDefault();
    cible.appendChild(ligneRubrique({}, natureDe(selNat.value)));
    rafraichirApercu();
  };
  div.querySelectorAll(".ligne1 input").forEach((c) => {
    c.oninput = rafraichirApercu;
  });
  div.querySelectorAll(".e-qui-case").forEach((c) => {
    c.onchange = () => { majQui(div); rafraichirApercu(); };
  });
  majQui(div);
  // --- les trois nombres, et le total qu'on y vise. `onchange` et non
  // `oninput` : on ne relance pas un calcul de paie à chaque touche d'un
  // montant qu'on est en train de taper.
  div.querySelectorAll(".e-vise").forEach((c) => {
    c.onchange = () => ajusterBloc(div, c);
  });
  // --- le contrat
  div.querySelector(".e-debut").value = e.debut || "";
  div.querySelector(".e-fin").value = e.fin || "";
  div.dataset.numero = e.numero || "";
  div.querySelectorAll(".e-debut, .e-fin").forEach((c) => {
    c.onchange = () => { majContrat(div); majRupture(div); rafraichirApercu(); };
  });
  // --- le mois payé d'un permanent, et ses faits
  div.querySelector(".e-salaire").value = e.salaire_mensuel ?? "";
  div.querySelector(".e-quotite").value = e.quotite_contrat ?? "";
  remplirFaits(div, e);
  div.querySelectorAll(".ajouter-fait").forEach((b) => {
    b.onclick = (ev) => {
      ev.preventDefault();
      ajouterFait(div, b.dataset.quoi);
      rafraichirApercu();
    };
  });
  // --- la fin du contrat, quand elle se signale
  // Un déroulant sans valeur choisie montre sa PREMIÈRE option, et la page
  // l'écrirait comme si on l'avait choisie. Le préavis s'ouvre donc sur un
  // « à choisir » vide — le moteur dira qu'il manque —, et la transaction
  // sur le défaut de la norme (02, « non »), jamais sur la première venue.
  div.querySelector(".e-preavis-type").innerHTML =
    `<option value="">— à choisir —</option>`
    + (ETAT.types_preavis || []).map(
      (t) => `<option value="${echapper(t.code)}" data-dates="${t.dates ? 1 : 0}">${
        echapper(t.code)} — ${echapper(t.libelle)}</option>`).join("");
  div.querySelector(".e-transaction").innerHTML = (ETAT.transaction || []).map(
    (t) => `<option value="${echapper(t.code)}"${t.defaut ? " selected" : ""}>${
      echapper(t.libelle)}</option>`).join("");
  const preavis = e.preavis || {};
  div.dataset.motifRupture = e.motif_rupture || "";
  div.dataset.motifRecours = e.motif_recours || "";
  div.querySelector(".e-preavis-type").value = preavis.type || "";
  div.querySelector(".e-preavis-debut").value = preavis.debut || "";
  div.querySelector(".e-preavis-fin").value = preavis.fin || "";
  div.querySelector(".e-notification").value = e.notification_rupture || "";
  div.querySelector(".e-engagement-licenciement").value = e.engagement_licenciement || "";
  div.querySelector(".e-signature-convention").value = e.signature_convention || "";
  div.querySelector(".e-dernier-paye").value = e.dernier_jour_paye || "";
  if (e.transaction) div.querySelector(".e-transaction").value = e.transaction;
  div.querySelector(".e-en-droit").value = e.en_droit_a_la_retraite === true ? "oui"
    : e.en_droit_a_la_retraite === false ? "non" : "";
  div.querySelector(".e-preavis-non-effectue").checked = !!e.preavis_non_effectue;
  div.querySelector(".e-preavis-mois").value = e.preavis_mois ?? "";
  div.querySelector(".e-precarite-ecartee").checked = e.precarite_due === false;
  div.querySelector(".e-precarite-pourquoi").value = e.precarite_pourquoi || "";
  div.querySelector(".e-preavis-type").onchange = () => { majRupture(div); rafraichirApercu(); };
  div.querySelectorAll(".e-rupture input, .e-motif-rupture, .e-transaction, .e-recours, .e-en-droit")
    .forEach((c) => { c.onchange = () => { majRupture(div); rafraichirApercu(); }; });
  // UN CONTRAT EN COURS DEPUIS UN MOIS PRÉCÉDENT ne se modifie pas d'ici :
  // il a été signé et déclaré avec son premier mois. Salarié, spectacle,
  // métier et bornes sont verrouillés ; seules les lignes du mois se
  // saisissent. `verrou` : fermerEdition ne les rouvre pas.
  const mois = document.getElementById("mois").value;
  if (e.debut && mois && e.debut.slice(0, 7) < mois) {
    div.classList.add("en-cours");
    div.querySelectorAll(".e-debut, .e-fin, .e-spectacle, .e-metier, .e-cadre, .e-qui-case, .e-nature")
      .forEach((c) => { c.disabled = true; c.classList.add("verrou"); });
  }
  majContrat(div);
  majNature(div);
  // La Nature ne se montre que s'il y a un choix : sans permanents, la
  // compagnie n'a que le contrat d'usage, et une case à un seul choix n'en
  // est pas une.
  div.querySelector(".e-nature-bloc").hidden = (ETAT.natures || []).length <= 1;
  div.querySelector(".e-viser-btn").onclick = (ev) => {
    ev.preventDefault();
    const c = div.querySelector(".e-chiffres");
    c.hidden = !c.hidden;
  };
  div.querySelector(".e-options-btn").onclick = (ev) => {
    ev.preventDefault();
    const o = div.querySelector(".e-options");
    o.hidden = !o.hidden;
  };
  // Ouvert d'office quand ce qu'il cache est déjà rempli : rien de saisi ne
  // devient invisible.
  const nat = natureDe(selNat.value);
  div.querySelector(".e-options").hidden = !(e.metier || e.cadre != null
    || nat.mensuelle || e.debut && e.debut.slice(0, 7) < (document.getElementById("mois").value || "")
    || e.motif_recours || e.motif_rupture);
  return div;
}

/** La nature d'un engagement, telle que `contrats-base.json` la décrit.
 *  Un engagement muet est un CDDU du spectacle : c'est le défaut du moteur,
 *  et la page prend le même — elle ne le redéfinit pas. */
function natureDe(cle) {
  const natures = ETAT.natures || [];
  return natures.find((n) => n.cle === (cle || ETAT.nature_defaut))
      || natures.find((n) => n.cle === ETAT.nature_defaut)
      || { cle: "", libelle: "", mensuelle: false, spectacle: true,
           signalement_fctu: false, motifs_rupture: [] };
}

/** Ce que la nature change à l'écran. Un permanent n'a ni spectacle (le
 *  numéro d'objet lui est INTERDIT, CCH-11) ni cachets : il a un salaire au
 *  mois et des faits. Cacher plutôt que griser, parce qu'une case qui ne
 *  peut pas servir est une case qu'on essaie quand même de remplir. */
function majNature(div) {
  const nat = natureDe(div.querySelector(".e-nature").value);
  div.classList.toggle("bloc-permanent", !!nat.mensuelle);
  div.querySelector(".e-spectacle-bloc").hidden = !nat.spectacle;
  div.querySelector(".e-permanent").hidden = !nat.mensuelle;
  div.querySelector(".rubriques").hidden = !!nat.mensuelle;
  div.querySelector(".ajouter-rubrique").hidden = !!nat.mensuelle;
  // Le déroulant des rubriques suit la nature : ce qui ne s'applique pas à
  // ce contrat ne s'y propose plus (la rubrique choisie reste).
  div.querySelectorAll(".r-code").forEach((s) => {
    const v = s.value;
    s.innerHTML = optionsRubriques(v, nat);
    s.value = v;
  });
  // Les bornes : saisies pour un contrat payé au mois, déduites du
  // calendrier pour un contrat d'usage — sauf si elles sont déjà écrites.
  const ecrites = !!(div.querySelector(".e-debut").value
                     || div.querySelector(".e-fin").value);
  const bornes = !!nat.mensuelle || ecrites;
  div.querySelectorAll(".e-borne").forEach((l) => { l.hidden = !bornes; });
  div.querySelector(".e-contrat-note").textContent = bornes
    ? "Un contrat payé au mois n'a pas de jour coché : ses bornes se disent ici."
      + " La date de fin d'un CDD est celle qui déclenche le signalement de"
      + " fin de contrat (nature 07), dû dans les cinq jours ouvrés."
    : "Le contrat va du premier au dernier jour coché — planning compris,"
      + " quand on a coché des jours dans les mois suivants depuis le"
      + " calendrier d'une ligne. Ses cachets suivants se paient dans le mois"
      + " suivant (le mois venu, le contrat y est repris, ses jours cochés) ;"
      + " la DPAE et le contrat imprimé ne partent qu'avec ce mois-ci, le"
      + " certificat Congés Spectacles à la fin du contrat.";
  const quotite = div.querySelector(".e-quotite");
  quotite.placeholder = nat.quotite_defaut != null ? String(nat.quotite_defaut) : "";
  // Le motif de recours : proposé seulement par les natures qui en ont un.
  const recours = nat.motifs_recours || [];
  div.querySelector(".e-recours-bloc").hidden = !recours.length;
  const sel = div.querySelector(".e-recours");
  const voulu = sel.value || div.dataset.motifRecours || "";
  sel.innerHTML = `<option value="">— à choisir —</option>`
    + recours.map((m) => `<option value="${echapper(m.code)}">${echapper(m.code)} — ${
      echapper(m.libelle)}</option>`).join("");
  sel.value = recours.some((m) => m.code === voulu) ? voulu : "";
  majRupture(div);
}

/** La fin d'un contrat qui SE SIGNALE, et elle seule. Un CDDU du spectacle
 *  n'en fait pas partie : sa fin part dans la DSN mensuelle par le circuit
 *  dérogatoire, et lui demander un motif de rupture serait demander une
 *  saisie qui ne partirait nulle part.
 *
 *  Les dates de préavis suivent le type choisi : le « 90 - pas de clause de
 *  préavis applicable » les INTERDIT (CCH-11 de S21.G00.63.002), et le
 *  moteur refuserait le fichier. Autant ne pas les proposer. */
function majRupture(div) {
  const nat = natureDe(div.querySelector(".e-nature").value);
  const bloc = div.querySelector(".e-rupture");
  const fin = div.querySelector(".e-fin").value;
  bloc.hidden = !(nat.signalement_fctu && fin);
  // Les motifs sont ceux de CETTE nature : un CDD peut finir à son terme
  // (031), un CDI ne le peut pas — il ne finit jamais tout seul.
  const sel = div.querySelector(".e-motif-rupture");
  const voulu = sel.value || div.dataset.motifRupture || "";
  sel.innerHTML = `<option value="">— à choisir —</option>`
    + (nat.motifs_rupture || []).map(
      (m) => `<option value="${echapper(m.code)}">${echapper(m.code)} — ${echapper(m.libelle)}</option>`).join("");
  sel.value = (nat.motifs_rupture || []).some((m) => m.code === voulu) ? voulu : "";
  const faits = (nat.faits_de_rupture || {})[sel.value] || [];
  div.querySelectorAll(".e-rupture [data-fait]").forEach((l) => {
    l.hidden = !faits.includes(l.dataset.fait);
  });
  // La durée et le pourquoi ne se montrent qu'avec leur case.
  div.querySelector(".e-preavis-mois-l").hidden ||=
    !div.querySelector(".e-preavis-non-effectue").checked;
  div.querySelector(".e-precarite-pourquoi-l").hidden ||=
    !div.querySelector(".e-precarite-ecartee").checked;
  const type = div.querySelector(".e-preavis-type");
  const choisi = type.selectedOptions[0];
  const avecDates = !!(choisi && choisi.dataset.dates === "1");
  div.querySelectorAll(".e-preavis-dates").forEach((l) => { l.hidden = !avecDates; });
  if (!avecDates) {
    div.querySelector(".e-preavis-debut").value = "";
    div.querySelector(".e-preavis-fin").value = "";
  }
}

/* LES FAITS D'UN MOIS DE PERMANENT — congés, absences, primes. Trois listes
   de la même famille : une ligne se remplit, un « + » en ajoute une, une
   croix la retire. Ce qu'elles écrivent, ce sont les faits du mois, jamais
   des lignes de paie : le calcul appartient au moteur. */
function ligneFait(quoi, v = {}) {
  const div = document.createElement("div");
  div.className = "fait fait-" + quoi;
  if (quoi === "conges") {
    div.innerHTML = `
      <label>du <input type="date" class="f-debut" value="${echapper(v.debut || "")}"></label>
      <label>au <input type="date" class="f-fin" value="${echapper(v.fin || "")}"></label>
      <button class="retirer-fait lien" title="retirer">&#x2715;</button>`;
  } else if (quoi === "absences") {
    // Le motif décide de tout : « maladie » fait une absence maladie (bloc
    // 60 et son signalement, plus le maintien de salaire que la loi donne) ;
    // les autres font une suspension déclarée au bloc 65, qui EXIGE ses deux
    // dates. Un motif que le moteur ne connaît pas ne se déclare pas.
    div.innerHTML = `
      <label>du <input type="date" class="f-debut" value="${echapper(v.debut || "")}"></label>
      <label>au <input type="date" class="f-fin" value="${echapper(v.fin || "")}"></label>
      <label>motif <select class="f-motif">
        <option value="maladie">maladie — arrêt de travail</option>
        ${(ETAT.motifs_absence || []).map((m) =>
          `<option value="${echapper(m.code)}">${echapper(m.code)} — ${echapper(m.libelle)}</option>`).join("")}
      </select></label>
      <label title="laissé vide : au prorata des jours ouvrables du mois">heures
        <input type="number" step="0.01" min="0" class="f-heures" value="${echapper(v.heures ?? "")}"></label>
      <label class="f-maintien-bloc" title="le complément versé APRÈS déduction des indemnités journalières (D1226-5) — il ne se devine pas">maintien
        <input type="number" step="0.01" min="0" class="f-maintien" value="${echapper(v.maintien ?? "")}"></label>
      <!-- CE QUE LE MAINTIEN DE SALAIRE DEMANDE (30/09/2026) : l'origine de
           l'arrêt — pas de carence pour un accident du travail, mais un
           accident de trajet garde la sienne (D1226-3) — et les jours déjà
           indemnisés dans les douze mois (D1226-4). Seulement pour un arrêt. -->
      <label class="f-maintien-bloc">origine <select class="f-origine">
        <option value="">maladie</option>
        <option value="at">accident du travail ou maladie professionnelle</option>
        <option value="trajet">accident de trajet</option>
      </select></label>
      <label class="f-maintien-bloc" title="jours d'arrêt déjà indemnisés par l'employeur dans les douze mois précédents (D1226-4)">déjà indemnisés
        <input type="number" step="1" min="0" class="f-deja" value="${echapper(v.jours_deja_indemnises ?? "")}"></label>
      <button class="retirer-fait lien" title="retirer">&#x2715;</button>`;
  } else {
    div.innerHTML = `
      <label>rubrique <input type="text" class="f-rubrique"
        value="${echapper(v.rubrique || "")}" placeholder="prime"></label>
      <label>montant <input type="number" step="0.01" class="f-montant"
        value="${echapper(v.montant ?? "")}"></label>
      <button class="retirer-fait lien" title="retirer">&#x2715;</button>`;
  }
  if (quoi === "absences") {
    const motif = div.querySelector(".f-motif");
    motif.value = v.motif || "maladie";
    div.querySelector(".f-origine").value = v.accident_de_trajet ? "trajet"
      : v.accident_du_travail ? "at" : "";
    div.querySelector(".f-origine").onchange = rafraichirApercu;
    const majMotif = () => {
      div.querySelectorAll(".f-maintien-bloc").forEach((b) => { b.hidden = motif.value !== "maladie"; });
    };
    motif.onchange = () => { majMotif(); rafraichirApercu(); };
    majMotif();
  }
  div.querySelector(".retirer-fait").onclick = (ev) => {
    ev.preventDefault();
    div.remove();
    rafraichirApercu();
  };
  div.querySelectorAll("input").forEach((c) => { c.onchange = rafraichirApercu; });
  return div;
}

const FAITS = { conges: ".e-conges", absences: ".e-absences", primes: ".e-primes" };

function remplirFaits(div, e) {
  (e.conges_pris || []).forEach((c) => div.querySelector(FAITS.conges).appendChild(ligneFait("conges", c)));
  (e.absences || []).forEach((a) => div.querySelector(FAITS.absences).appendChild(ligneFait("absences", a)));
  (e.primes || []).forEach((p) => div.querySelector(FAITS.primes).appendChild(ligneFait("primes", p)));
}

function ajouterFait(div, quoi) {
  div.querySelector(FAITS[quoi]).appendChild(ligneFait(quoi));
}

/** Les faits tapés dans un bloc, tels qu'ils s'écrivent dans la saisie. Une
 *  ligne dont les deux dates manquent n'est pas un fait : on ne l'écrit pas.
 *  Ce qui est incomplet, en revanche, part tel quel — c'est le moteur qui
 *  dit ce qui manque, pas la page. */
function faitsDuBloc(div) {
  const val = (n, s) => (n.querySelector(s) || {}).value || "";
  const conges = [...div.querySelectorAll(".fait-conges")]
    .map((f) => ({ debut: val(f, ".f-debut"), fin: val(f, ".f-fin") }))
    .filter((c) => c.debut || c.fin);
  const absences = [...div.querySelectorAll(".fait-absences")].map((f) => {
    const a = { debut: val(f, ".f-debut"), fin: val(f, ".f-fin"),
                motif: val(f, ".f-motif") };
    if (val(f, ".f-heures")) a.heures = +val(f, ".f-heures");
    if (a.motif === "maladie" && val(f, ".f-maintien")) a.maintien = +val(f, ".f-maintien");
    if (a.motif === "maladie") {
      // L'accident de trajet est un accident du travail qui garde sa carence :
      // le moteur lit les deux cases (`permanents.jours_de_carence`).
      const origine = val(f, ".f-origine");
      if (origine) a.accident_du_travail = true;
      if (origine === "trajet") a.accident_de_trajet = true;
      if (val(f, ".f-deja")) a.jours_deja_indemnises = +val(f, ".f-deja");
    }
    return a;
  }).filter((a) => a.debut || a.fin);
  const primes = [...div.querySelectorAll(".fait-primes")].map((f) => {
    const p = { montant: +val(f, ".f-montant") };
    if (val(f, ".f-rubrique")) p.rubrique = val(f, ".f-rubrique");
    return p;
  }).filter((p) => p.montant);
  return { conges, absences, primes };
}

/** La ligne repliée du contrat : ses bornes, son numéro, et ce qu'il fait
 *  par rapport au mois — « se poursuit en novembre », « en cours depuis
 *  octobre ». Les bornes vides se lisent sur les jours joués, comme le
 *  moteur le fait (`Engagement.debut`/`fin`). */
function majContrat(div) {
  const d = div.querySelector(".e-contrat");
  if (!d) return;
  const mois = document.getElementById("mois").value;
  const jours = joursDuBloc(div, mois);
  const debut = div.querySelector(".e-debut").value || jours[0] || "";
  const fin = div.querySelector(".e-fin").value || jours[jours.length - 1] || "";
  const numero = div.dataset.numero || "";
  div.querySelector(".e-numero").textContent = numero
    ? "n° " + numero + " — attribué à la production, il ne change plus" : "";
  const s = d.querySelector("summary");
  const enCours = !!(debut && mois && debut.slice(0, 7) < mois);
  const sePoursuit = !!(fin && mois && fin.slice(0, 7) > mois);
  d.classList.toggle("a-cheval", enCours || sePoursuit);
  // Un contrat sur plusieurs mois se voit sans ouvrir « Plus d'options ».
  const suite = div.querySelector(".e-suite");
  if (suite) suite.textContent = enCours
    ? `contrat en cours depuis ${moisEnClair(debut.slice(0, 7))}`
    : sePoursuit ? `le contrat se poursuit en ${moisEnClair(moisSuivant(mois))}` : "";
  // UN CONTRAT SANS TERME (un CDI) n'a pas de dernier jour joué : il se
  // dit par son début (26/09/2026 — la phrase des cachets s'y affichait).
  if (debut && !fin && natureDe(div.querySelector(".e-nature")?.value).mensuelle) {
    s.textContent = `Contrat depuis le ${jjmmaaaa(debut)}, sans terme${
      numero ? ` · n° ${numero}` : ""}`;
    return;
  }
  if (!debut || !fin) {
    s.innerHTML = `Contrat <span class="discret">— du premier au dernier jour joué</span>`;
    return;
  }
  let texte = `Contrat du ${jjmmaaaa(debut)} au ${jjmmaaaa(fin)}`;
  if (numero) texte += ` · n° ${numero}`;
  if (enCours) texte += ` — en cours depuis ${moisEnClair(debut.slice(0, 7))}`;
  if (sePoursuit) texte += ` — se poursuit en ${moisEnClair(moisSuivant(mois))}`;
  s.textContent = texte;
}

function moisSuivant(mois) {
  const an = +mois.slice(0, 4), mo = +mois.slice(5, 7);
  return mo === 12 ? `${an + 1}-01` : `${an}-${String(mo + 1).padStart(2, "0")}`;
}

/** Les listes de salariés et de spectacles de TOUS les blocs, refaites sur
 *  l'ETAT courant, sans perdre ce qui est coché ou choisi. Appelé après
 *  qu'une fiche a été créée : le bloc d'où l'on est parti doit proposer le
 *  nouveau venu sans qu'on recharge le mois — recharger relirait le disque
 *  par-dessus une frappe pas encore enregistrée. */
function rafraichirReferentiels() {
  document.querySelectorAll(".engagement").forEach((div) => {
    const coches = new Set(salariesDuBloc(div));
    const modele = ligneEngagement({ salaries: [...coches] });
    div.querySelector(".e-qui-liste").innerHTML =
      modele.querySelector(".e-qui-liste").innerHTML;
    div.querySelectorAll(".e-qui-case").forEach((c) => {
      c.onchange = () => { majQui(div); rafraichirApercu(); };
    });
    majQui(div);
    const sel = div.querySelector(".e-spectacle");
    const v = sel.value;
    sel.innerHTML = modele.querySelector(".e-spectacle").innerHTML;
    sel.value = v;
  });
}

/** Une fiche neuve : le formulaire complet de Configuration, avec ses
 *  vérifications. Une seule façon de créer une fiche, et c'est là. */
function nouvelleFiche(nom) {
  // Les onglets redessinent APRES coup (leurs gestionnaires attendent
  // `quitterLaFiche`) : sans cette marque, `dessinerConfig` effacait la
  // fiche neuve qu'on venait d'ouvrir (23/09/2026).
  const onglet = document.querySelector('.onglets button[data-vue="configuration"]');
  const sous = document.querySelector(`.sous-onglets button[data-fiche="${nom}"]`);
  if (!onglet.classList.contains("actif")) onglet.click();
  if (!sous.classList.contains("actif")) sous.click();
  CLE_ACTIVE = null;
  FICHE_NEUVE = true;
  dessinerConfig();
  // L'anciennete d'une fiche neuve : aujourd'hui, a changer au besoin.
  const donnees = nom === "salarie"
    ? { actif: true, date_anciennete: new Date().toLocaleDateString("sv-SE") }
    : { actif: true };
  dessinerFormulaire({ nom, cle: null, donnees, anomalies: [] });
  document.getElementById("config-formulaire").scrollIntoView({ behavior: "smooth" });
}

/** Les salariés cochés d'un bloc, dans l'ordre de la liste. */
function salariesDuBloc(div) {
  return [...div.querySelectorAll(".e-qui-case:checked")].map((c) => c.value);
}

/** Le résumé de la liste refermée : les noms cochés, ou l'invitation. */
function majQui(div) {
  const resume = div.querySelector(".e-qui summary");
  const noms = [...div.querySelectorAll(".e-qui-case:checked")]
    .map((c) => c.parentNode.textContent.replace(/\s+/g, " ").trim());
  resume.textContent = noms.length ? noms.join(" + ") : "— cocher —";
  resume.classList.toggle("vide", !noms.length);
}

/** Une liste ouverte se referme quand on clique ailleurs — un <details> ne
 *  le fait pas tout seul. */
document.addEventListener("click", (ev) => {
  document.querySelectorAll(".e-qui[open]").forEach((d) => {
    if (!d.contains(ev.target)) d.open = false;
  });
});

/** Plusieurs salariés cochés : le bloc devient un bloc par salarié.
 *
 *  Appelé APRÈS la validation (validerPlusieurs), pas avant : tant qu'on
 *  saisit, un seul bloc pour tous — c'est ça qui va vite. Le moteur, lui, ne
 *  connaît qu'un salarié par engagement, un contrat, un bulletin ; ici on ne
 *  fait que montrer à l'écran ce que le fichier contient déjà. Rien à faire
 *  pour zéro ou une case. */
function dedoubler(div) {
  const cles = salariesDuBloc(div);
  if (cles.length < 2) return;
  // Les lignes voyagent telles quelles — lieux et jours compris : les
  // salariés jouent les mêmes dates aux mêmes endroits.
  const modele = {
    spectacle: div.querySelector(".e-spectacle").value,   // le meme spectacle
    lignes: lignesDuBloc(div),
    debut: div.querySelector(".e-debut").value || undefined,
    fin: div.querySelector(".e-fin").value || undefined,
  };
  const parent = div.parentNode;
  const suivant = div.nextSibling;
  div.remove();
  cles.forEach((cle) => {
    parent.insertBefore(ligneEngagement({ ...modele, salarie: cle }), suivant);
  });
}

/** Les lignes de paie d'un bloc, telles qu'elles sont saisies. */
/* VISER UN MONTANT SANS TAUX (24/09/2026). Une ligne sans taux ne part pas
 * dans la saisie -- elle est incomplete. Sauf pour « Viser un montant » :
 * le taux est justement ce qu'on cherche, et le moteur le trouve seul quand
 * il n'y a qu'une ligne de salaire (`_poser_taux_provisoires`). */
let GARDER_SANS_TAUX = false;
const ligneEnvoyee = (r) => r.querySelector(".r-quantite").value !== ""
  && (GARDER_SANS_TAUX || r.querySelector(".r-taux").value !== "");

function lignesDuBloc(div, mois) {
  mois = mois || document.getElementById("mois").value;
  return [...div.querySelectorAll(".rubrique")].map((r) => {
    const q = r.querySelector(".r-quantite").value;
    const t = r.querySelector(".r-taux").value;
    const h = r.querySelector(".r-heures").value;
    if (!ligneEnvoyee(r)) return null;
    const rr = rubriqueDe(r.querySelector(".r-code").value);
    // Une ligne en pourcentage s'écrit comme le moteur la lit : sa base et
    // son pourcentage (`calcul._ligne_en_pourcentage`).
    if (rr && rr.saisie.includes("taux_majoration")) {
      return { rubrique: rr.code, base: +q, taux_majoration: t === "" ? "" : +t };
    }
    const l = { rubrique: r.querySelector(".r-code").value, quantite: +q,
                taux: t === "" ? "" : +t };
    // Les heures s'écrivent quand la RUBRIQUE les demande — pas selon que le
    // champ est affiché : le 30/09/2026, un champ masqué a effacé sans un mot
    // les heures d'une paie validée. Une rubrique inconnue garde les siennes.
    if (h !== "" && (!rr || rr.saisie.includes("heures"))) l.heures = +h;
    // Le genre d'un avantage en nature, quand la rubrique en demande un et
    // qu'on en a choisi un : le moteur refuse un genre sur toute autre.
    const genre = r.querySelector(".r-genre").value;
    if (genre && rr && (rr.genres || []).length) l.genre = genre;
    // Le lieu et les jours de CETTE ligne. Absents du fichier quand ils sont
    // vides : une ligne qui ne dit rien de son lieu n'écrit pas `"lieu": ""`.
    const ou = r.querySelector(".r-lieu").value.trim();
    if (ou) l.lieu = ou;
    const jours = joursDe(r.querySelector(".r-jours"));
    if (jours.length) {
      l.dates = jours.map((j) => mois + "-" + String(j).padStart(2, "0"));
    }
    // Le planning de la ligne : les jours cochés dans les mois suivants.
    const plan = planningDe(r);
    if (plan.length) l.planning = plan;
    return l;
  }).filter(Boolean);
}

/** Les jours d'un engagement, toutes lignes confondues — c'est ce que le
 *  moteur appelle `dates_travail`, et il le recompose de la même façon
 *  (`operations.dates_engagement`). */
function joursDuBloc(div, mois) {
  const vus = new Set();
  lignesDuBloc(div, mois).forEach((l) => (l.dates || []).forEach((j) => vus.add(j)));
  return [...vus].sort();
}

document.getElementById("ajouter-engagement").onclick = () => {
  document.getElementById("engagements").appendChild(ligneEngagement());
  rafraichirApercu();
};

/* LES CONTRATS EN COURS SE POSENT D'EUX-MÊMES. Un CDDU signé en octobre
   pour une tournée jusqu'en décembre est UN contrat, déclaré une fois (DPAE,
   numéro) ; chaque mois n'en porte que les cachets joués. Le moteur sait
   lesquels courent encore (`contrats_en_cours`, lu dans les saisies des mois
   précédents). Ce n'était qu'un bouton, « + reprendre un contrat en cours » :
   l'éditeur, 01/10/2026 — « il faut le reprendre, il est annoncé et pas
   fermé, la reprise n'est pas une option ». Le mois ouvert les montre donc
   tout de suite, préremplis et verrouillés ; il reste à poser les jours, ou
   rien si aucun cachet ce mois-ci (la DSN porte le contrat, sans bulletin).
   Un mois fermé ne reçoit rien. */
let CONTRATS_EN_COURS = [];

async function poserContratsEnCours(mois) {
  try {
    const r = await api("contrats-en-cours", { mois });
    CONTRATS_EN_COURS = r.contrats || [];
  } catch (e) { CONTRATS_EN_COURS = []; return; }
  if (MOIS_AFFICHE !== mois) return;
  if (!!MOIS_FERME && MOIS_FORCE !== mois) return;
  const restants = CONTRATS_EN_COURS.filter((c) => !c.deja_repris);
  if (!restants.length) return;
  const cible = document.getElementById("engagements");
  restants.forEach((c) => {
    // L'engagement vient du moteur (`engagement_de_reprise`) : bornes,
    // numéro, métier, et les lignes déjà datées quand le premier mois a
    // coché son planning. Sinon une ligne de cachets, à dater.
    const e = { ...(c.engagement || {}), salarie: c.salarie, spectacle: c.spectacle,
                debut: c.debut, fin: c.fin, numero: c.numero };
    if (!e.lignes || !e.lignes.length) e.lignes = [{ rubrique: "cachet", taux: c.taux_cachet || DERNIER_TAUX }];
    e.lignes = e.lignes.map((l) => (l.quantite === 0 ? { ...l, quantite: "" } : l));
    cible.appendChild(ligneEngagement(e));
  });
  rafraichirApercu();
  dire(restants.length === 1
    ? `Contrat en cours repris : ${restants[0].nom} — poser ses jours de ${moisEnClair(mois)}.`
    : `${restants.length} contrats en cours repris (${restants.map((c) => c.nom).join(", ")})`
      + ` — poser leurs jours de ${moisEnClair(mois)}.`);
}

/** Ce qu'une paie dit d'elle-même en une ligne : son spectacle, ou — quand
 *  elle n'en a pas, parce que c'est un permanent — la nature de son contrat.
 *  « — » tout seul derrière un nom, c'est un écran qui a l'air cassé. */
function pourQuoi(ligne) {
  return ligne.spectacle || ligne.nature || "";
}

function spectacleEnClair(cle) {
  const s = (ETAT.spectacles || []).find((x) => x.cle === cle);
  return s ? s.titre : cle;
}

function saisieCourante() {
  const mois = document.getElementById("mois").value;
  const engagements = [...document.querySelectorAll(".engagement")].flatMap((div) => {
    // L'ENGAGEMENT N'ÉCRIT PLUS DE `dates` : chacune de ses lignes porte les
    // siennes, avec son lieu, et le moteur en fait la réunion
    // (`operations.dates_engagement`). Une seule source, donc pas de
    // divergence possible entre « les jours du contrat » et « les jours
    // payés ».
    //
    // UN ENGAGEMENT PAR SALARIÉ COCHÉ. Le bloc en porte plusieurs à l'écran
    // pour aller vite ; le fichier, lui, garde le format du moteur — un
    // salarié, un engagement. Chacun reçoit sa propre copie des lignes.
    // Un bloc sans salarié n'est pas une paie et n'écrit rien.
    const spectacle = div.querySelector(".e-spectacle").value;
    const lignes = lignesDuBloc(div, mois);
    const metier = div.querySelector(".e-metier").value;
    const cadre = div.querySelector(".e-cadre").checked;
    const debut = div.querySelector(".e-debut").value;
    const fin = div.querySelector(".e-fin").value;
    const numero = div.dataset.numero || "";
    const nat = natureDe(div.querySelector(".e-nature").value);
    const faits = faitsDuBloc(div);
    const salaire = div.querySelector(".e-salaire").value;
    const quotite = div.querySelector(".e-quotite").value;
    return salariesDuBloc(div).map((salarie) => {
      // UN PERMANENT N'A PAS DE SPECTACLE, et ce n'est pas un détail de
      // mise en page : le numéro d'objet lui est interdit (CCH-11). Écrire
      // la case vide, ce serait écrire un rattachement à rien.
      const e = nat.mensuelle ? { salarie } : { salarie, spectacle };
      // La nature ne s'écrit que si elle s'écarte du défaut : un engagement
      // muet est un CDDU du spectacle, et cinq ans de saisies le restent
      // sans qu'on y touche.
      if (nat.cle && nat.cle !== ETAT.nature_defaut) e.nature = nat.cle;
      // Le contrat, quand il est dit : ses bornes (un contrat qui déborde
      // du mois n'existe que par elles) et son numéro, figé à la production.
      if (debut) e.debut = debut;
      if (fin) e.fin = fin;
      if (numero) e.numero = numero;
      // UN MOIS DU CONTRAT SANS CACHET (15/09/2026) : un contrat aux bornes
      // dites, et aucune ligne remplie, s'écrit `lignes: []` — le moteur en
      // fait une DSN qui porte le contrat avec un versement à zéro, sans
      // bulletin. Sans bornes, on n'écrit rien : c'est une saisie incomplète,
      // et le moteur le dit.
      if (nat.mensuelle) {
        // LES FAITS, PAS LES LIGNES. `lignes_du_mois` en fait des lignes de
        // bulletin — le prorata d'un mois incomplet, l'indemnité de congés
        // et la retenue qui la couvre, le bloc 65 d'une suspension, le
        // solde de tout compte du dernier mois. Écrire `lignes` ici
        // couperait tout ce calcul : c'est la porte de sortie du moteur
        // (« une saisie qui écrit ses lignes elle-même les garde »), et
        // elle n'est pas pour cet écran.
        const recours = div.querySelector(".e-recours").value;
        if (recours) e.motif_recours = recours;
        if (salaire !== "") e.salaire_mensuel = +salaire;
        if (quotite !== "") e.quotite_contrat = +quotite;
        if (faits.conges.length) e.conges_pris = faits.conges;
        if (faits.absences.length) e.absences = faits.absences;
        if (faits.primes.length) e.primes = faits.primes;
        // Ce que la fin du contrat déclarera, quand elle se signale. Trois
        // faits que le moteur ne devine pas, et un quatrième qui ne s'écrit
        // que s'il s'écarte de la fin du contrat.
        if (fin && nat.signalement_fctu) {
          const dans = (s) => div.querySelector(s).value;
          if (dans(".e-motif-rupture")) e.motif_rupture = dans(".e-motif-rupture");
          // Les faits du motif, seulement ceux que le moteur a demandés.
          const faits = (nat.faits_de_rupture || {})[e.motif_rupture] || [];
          if (faits.includes("notification_rupture") && dans(".e-notification"))
            e.notification_rupture = dans(".e-notification");
          if (faits.includes("engagement_licenciement") && dans(".e-engagement-licenciement"))
            e.engagement_licenciement = dans(".e-engagement-licenciement");
          if (faits.includes("signature_convention") && dans(".e-signature-convention"))
            e.signature_convention = dans(".e-signature-convention");
          if (dans(".e-preavis-type")) {
            e.preavis = { type: dans(".e-preavis-type") };
            if (dans(".e-preavis-debut")) e.preavis.debut = dans(".e-preavis-debut");
            if (dans(".e-preavis-fin")) e.preavis.fin = dans(".e-preavis-fin");
          }
          if (faits.includes("transaction") && dans(".e-transaction")) e.transaction = dans(".e-transaction");
          if (dans(".e-dernier-paye")) e.dernier_jour_paye = dans(".e-dernier-paye");
          if (faits.includes("en_droit_a_la_retraite") && dans(".e-en-droit"))
            e.en_droit_a_la_retraite = dans(".e-en-droit") === "oui";
          if (faits.includes("preavis_non_effectue")
              && div.querySelector(".e-preavis-non-effectue").checked) {
            e.preavis_non_effectue = true;
            if (dans(".e-preavis-mois") !== "") e.preavis_mois = +dans(".e-preavis-mois");
          }
          if (faits.includes("precarite_due")
              && div.querySelector(".e-precarite-ecartee").checked) {
            e.precarite_due = false;
            if (dans(".e-precarite-pourquoi")) e.precarite_pourquoi = dans(".e-precarite-pourquoi");
          }
        }
      } else if (lignes.length) e.lignes = JSON.parse(JSON.stringify(lignes));
      else if (debut && fin) e.lignes = [];
      // Le métier ne s'écrit que s'il est choisi : un engagement sans
      // `metier` prend celui de la fiche, et toutes les saisies d'avant
      // restent lisibles telles quelles. `cadre` voyage avec lui, seulement
      // quand il s'écarte du défaut du catalogue.
      if (metier) {
        e.metier = metier;
        const m = metierDe(metier);
        if (!m || cadre !== !!m.cadre_par_defaut) e.cadre = cadre;
      }
      return e;
    });
  });
  // `taux_cachet` et `date_paiement` ne s'affichent plus mais restent ECRITS :
  // le moteur s'en sert -- l'un comme defaut d'un engagement qui ne dit pas
  // son taux, l'autre comme date de paiement du contrat. Ce qui a disparu,
  // c'est la saisie, pas la valeur. `lieu` ne s'ecrit plus du tout : il
  // appartient au cachet.
  return {
    mois,
    taux_cachet: DERNIER_TAUX,
    date_paiement: SAISIE_DATE_PAIEMENT || finDuMois(mois),
    engagements,
  };
}

function rafraichirApercu() {
  clearTimeout(MINUTEUR);
  MINUTEUR = setTimeout(calculerApercu, 350);   // on ne calcule pas a chaque frappe
  // Et on enregistre. C'est le seul point de passage de TOUTES les
  // modifications de la saisie -- y accrocher l'enregistrement, c'est
  // s'assurer qu'aucune frappe ne reste dans la page seulement.
  enregistrerPlusTard();
  // Les etats, eux, ne coutent rien : ils sont deja lus. On les repeint tout
  // de suite, parce que changer le salarie ou les jours change la paie que ce
  // bloc DESIGNE -- et laisser 350 ms l'ancien etat sous le nouveau nom, c'est
  // exactement le mensonge qu'on veut eviter.
  peindreEtats();
}

/** `lu` : l'aperçu tel que la lecture du mois le porte (la saisie enregistrée) ; sans lui, on le demande au moteur. */
async function calculerApercu(lu) {
  const saisie = saisieCourante();
  const cible = document.getElementById("apercu");
  // Les jours sont sur les lignes de paie : un engagement « a des jours » dès
  // qu'une de ses lignes en porte.
  const aDesJours = (e) => (e.lignes || []).some((l) => (l.dates || []).length);
  // UN PERMANENT N'A PAS DE JOURS, et c'est normal : il est payé au mois.
  // La première version de ce garde-fou ne connaissait que les cachets, et
  // un CDI saisi en entier restait devant « ajouter des jours joués »
  // pendant que sa paie, elle, était calculable.
  const aDeQuoiPayer = (e) => aDesJours(e) || e.salaire_mensuel != null;
  if (!saisie.engagements.length || !saisie.engagements.some(aDeQuoiPayer)) {
    // Le permanent ne se nomme qu'à une compagnie qui en emploie.
    const perm = !!(ETAT.configuration || {}).permanents;
    cible.innerHTML = `<p class="discret">Ajouter un engagement, une ligne de
      paie et ses jours joués${perm ? " — ou, pour un permanent, son salaire mensuel" : ""}.</p>`;
    return;
  }
  cible.classList.add("attente");
  try {
    const a = lu ? structuredClone(lireReponse(lu)) : await api("apercu", { saisie });
    cible.innerHTML = vueApercu(a);
    // Les dates resolues, sous chaque engagement : ce que le moteur a compris.
    const blocs = [...document.querySelectorAll(".engagement")];
    const parBloc = paiesParBloc(a, blocs);
    blocs.forEach((div, i) => {
      const part = parBloc[i];
      const p = part[0];
      // Les trois nombres du bloc — sommés quand il porte plusieurs salariés,
      // parce que l'enveloppe qu'on y vise est celle du bloc entier.
      peindreChiffres(div, part);
      div._paies = part;
      peindreCarte(div);
      // Ce qui a été numéroté : un contrat en cours garde le numéro de son
      // premier mois, et c'est ici qu'il revient à l'écran quand la saisie
      // ne le portait pas encore.
      if (p && p.numero_contrat && p.contrat && !p.contrat.premier_mois
          && !div.dataset.numero) {
        div.dataset.numero = p.numero_contrat;
        majContrat(div);
      }
      // Un mois du contrat sans cachet n'a pas de bulletin : on le dit à la
      // place du numéro, et le brut à zéro suit.
      div.querySelector(".resolu").innerHTML = p
        ? `${p.contrat && p.contrat.sans_paie
             ? `<b>aucun cachet ce mois-ci</b> — pas de bulletin, la DSN porte le contrat`
             : `bulletin <b>${echapper(p.numero_bulletin)}</b>`} · contrat ${echapper(p.numero_contrat)}
           · ${echapper(jjmmaaaa(p.debut))} → ${echapper(jjmmaaaa(p.fin))}${
             p.contrat && p.contrat.a_cheval
               ? ` <span class="discret">(paie du ${echapper(jjmmaaaa(p.contrat.periode.debut))} au ${echapper(jjmmaaaa(p.contrat.periode.fin))})</span>`
               : ""}
           · ${echapper(designation(p))}${p.emploi && p.emploi.libelle
             ? ` · ${echapper(p.emploi.libelle.toLowerCase())}${p.emploi.cadre ? " (cadre)" : ""}` : ""}
           · brut <b>${echapper(euros(p.brut))}</b>`
        : "";
      // Ce que le moteur a à dire de CETTE paie, en deux tons (24/09/2026,
      // moteur/avis.py) : en orange ce qui demande quelque chose -- un
      // taux sous le SMIC --, en gris ce qui renseigne seulement -- un
      // contrat qui se poursuit le mois suivant, ou le minimum que notre
      // lecture de la convention donne, avec son lien (journal §161). Rien
      // n'est bloquant.
      div.querySelector(".avis").innerHTML =
        avisDuBloc(part).map(
          (a) => `<div class="encart attention avis-paie">${echapper(a)}</div>`).join("")
        + avisDuBloc(part, "informations").map(
          (a) => `<div class="encart info avis-paie">${echapperLiens(a)}</div>`).join("");
    });
  } catch (e) {
    cible.innerHTML = `<div class="encart erreur">${erreurEnClair(e)}</div>`;
  } finally {
    cible.classList.remove("attente");
  }
}

/* UNE ERREUR DU MOTEUR, LISIBLE (30/09/2026). Le nom de l'exception
 * (« FileNotFoundError », « ErreurOperation ») s'affichait en gras, en tête :
 * il ne dit rien à qui fait la paie. La première ligne du message dit quoi
 * faire ; le reste — la règle, la commande — se déplie si on le veut. */
function erreurEnClair(e) {
  const lignes = String(e.message || e).split("\n").map((l) => l.trim()).filter(Boolean);
  const tete = lignes.shift() || "Erreur";
  return `${echapper(tete)}${lignes.length ? `<details class="discret"><summary>en savoir plus</summary>
    ${lignes.map((l) => `<div>${echapper(l)}</div>`).join("")}</details>` : ""}`;
}

/* UN BLOC PARLE D'UNE SEULE VOIX (24/09/2026). Deux salariés payés ensemble
 * recevaient chacun le même avis — « FAVART Célimène : contrat… » puis
 * « MARAIS Marin : contrat… », quatre encarts pour deux choses à dire.
 * Le moteur ouvre ses avis par le nom (`qui` : « NOM Prénom » suivi de
 * « : » ou de « , ») ; ce qui suit est comparé, et le même avis ne
 * s'affiche qu'une fois, pour tous ceux qu'il concerne. Un avis qui ne
 * commence pas par un nom du bloc reste tel quel. */
function avisDuBloc(part, liste = "avertissements") {
  const groupes = new Map();
  part.forEach((x) => {
    const s = x.salarie || {};
    const qui = `${s.nom || ""} ${s.prenom || ""}`.trim();
    (x[liste] || []).forEach((a) => {
      const sep = qui && [" : ", ", "].find((c) => a.startsWith(qui + c));
      const cle = sep ? sep + a.slice(qui.length + sep.length) : "\u0000" + a;
      if (!groupes.has(cle)) groupes.set(cle, { texte: a, noms: [] });
      if (sep && !groupes.get(cle).noms.includes(qui)) groupes.get(cle).noms.push(qui);
    });
  });
  return [...groupes.entries()].map(([cle, g]) => {
    if (g.noms.length < 2) return g.texte;
    const noms = g.noms.slice(0, -1).join(", ") + " et " + g.noms[g.noms.length - 1];
    return noms + cle;
  });
}

/* LES PAIES D'UN APERÇU, RENDUES À LEUR BLOC. Un bloc qui porte trois
 * salariés cochés a produit TROIS engagements — `saisieCourante` les
 * démultiplie, parce que le moteur ne connaît qu'un salarié par engagement.
 * Compter un par bloc décalait donc tout ce qui suit dès le deuxième, et
 * l'écran posait la ligne « bulletin … » du voisin sous le mauvais nom. */
function paiesParBloc(a, blocs) {
  let rang = 0;
  return blocs.map((div) => {
    const combien = salariesDuBloc(div).length;
    const part = (a.paies || []).slice(rang, rang + combien);
    rang += combien;
    return part;
  });
}

/* LA PAIE VALIDÉE, EN UNE LIGNE D'AGENDA (23/09/2026).
 *
 * Validée, une paie ne se remplit plus : elle se PARCOURT. On y cherche,
 * dans cet ordre, quand (les jours travaillés, le repère d'une paie), qui
 * et pour quoi, ce qui reste à faire (DPAE, contrat signé, documents), et
 * combien — le net seulement, ce qu'on vire ; brut et coût sont dans
 * l'aperçu à droite de l'écran, les répéter ici serait du bruit. Numéros
 * de bulletin et de contrat, date de validation : en infobulle.
 * « Modifier… » rouvre la saisie entière (et « Retirer » avec elle).
 *
 * Deux sources, qui n'arrivent pas au même moment : l'aperçu du moteur
 * (`div._paies` : jours, ce qui est payé, net) et l'état de la paie
 * (`div._ligne` : actes, validation). La ligne se repeint à l'arrivée de
 * chacune ; ce qui manque encore se tait. */
const MOIS_COURTS = ["janv.", "févr.", "mars", "avril", "mai", "juin", "juil.",
  "août", "sept.", "oct.", "nov.", "déc."];

/** Les jours d'un mois, en clair et au plus court : « 6 », « 21–23 »,
 *  « 14 · 15 · 17 · 18 ». Des jours qui se suivent font une plage. */
function joursEnClair(isos) {
  const j = [...new Set(isos)].sort().map((x) => parseInt(x.slice(8, 10), 10));
  if (!j.length) return "";
  const suivis = j.every((v, k) => k === 0 || v === j[k - 1] + 1);
  if (j.length === 1) return String(j[0]);
  if (suivis) return `${j[0]}–${j[j.length - 1]}`;
  return j.join(" · ");
}

function peindreCarte(div) {
  const cible = div.querySelector(".e-resume");
  if (!cible) return;
  const ligne = div._ligne, ps = div._paies || [];
  if (!div.classList.contains("validee") || !ligne) { cible.innerHTML = ""; return; }
  const p = ps[0];
  const mois = document.getElementById("mois").value;
  // QUAND. Les jours travaillés du mois ; un permanent n'en a pas : son mois.
  const dates = p ? (p.dates_travail || []).filter((d) => d.startsWith(mois)) : [];
  const jours = dates.length ? joursEnClair(dates)
    : (p && p.nature && p.nature.mensuelle ? "mois" : "");
  const moisCourt = MOIS_COURTS[parseInt(mois.slice(5, 7), 10) - 1] || "";
  // POUR QUOI. Le spectacle, puis ce qui est payé en mots.
  const paye = p ? designation(p).toLowerCase() : "";
  const suite = ligne.contrat && !ligne.contrat.dernier_mois
    ? ` · contrat jusqu'en ${moisEnClair(ligne.contrat.jusqu_a)}` : "";
  const net = ps.length
    ? euros(ps.reduce((t, x) => t + Number(x.net_a_payer || 0), 0))
    : "";
  const detail = [p && p.numero_bulletin ? `bulletin ${p.numero_bulletin}` : "",
                  p && p.numero_contrat ? `contrat ${p.numero_contrat}` : "",
                  `validée le ${quand(ligne.valide)}`].filter(Boolean).join(" · ");
  cible.innerHTML = `
    <div class="carte-quand" title="${echapper(dates.map(jjmmaaaa).join(", "))}">
      <b class="${jours.includes(" · ") ? "epars" : ""}">${echapper(jours)}</b><span>${echapper(jours === "mois" ? moisCourt : moisCourt)}</span>
    </div>
    <div class="carte-qui" title="${echapper(detail)}">
      <b>${echapper(ligne.nom)}</b>
      <span class="discret">${echapper(pourQuoi(ligne))}${paye ? " · " + echapper(paye) : ""}${echapper(suite)}</span>
    </div>
    <div class="carte-actes">${bandeauEtats(ligne)}</div>
    <div class="carte-net" title="net à payer, avant impôt">${echapper(net)}</div>
    <button class="secondaire carte-modifier">Voir le détail</button>`;
  // VOIR SANS MODIFIER (l'utilisateur, 29/09/2026) : relire les heures d'un
  // service de répétition ne doit pas demander de rouvrir la paie.
  // « Modifier » est dans la boîte du détail.
  cible.querySelector(".carte-modifier").onclick = (ev) => {
    ev.preventDefault();
    boiteDetail(ligne, ps);
  };
  brancherRecu(cible);
}

/** « du 17/03/2026 au 20/03/2026 », ou « depuis le 04/09/2023 » pour un
 *  CDI : sans fin, le moteur rend `None` ou rien, et l'écran disait
 *  « au None » (30/09/2026). */
function periodeEnClair(debut, fin) {
  return fin && fin !== "None"
    ? `du ${jjmmaaaa(debut)} au ${jjmmaaaa(fin)}`
    : `depuis le ${jjmmaaaa(debut)}`;
}

/** Le détail d'une paie validée, en lecture : ce qui est payé ligne par
 *  ligne, les jours, les montants. « Modifier… » dedans. */
function boiteDetail(ligne, ps) {
  const nombre = (x) => (x === null || x === undefined || x === "") ? ""
    : String(x).replace(".", ",");
  const bloc = (p) => {
    const lignes = (p.remuneration || []).map((r) => `<tr>
        <td>${echapper(r.designation)}</td>
        <td class="nombre">${echapper(nombre(r.quantite))}</td>
        <td class="nombre">${r.taux ? echapper(euros(r.taux)) : ""}</td>
        <td class="nombre">${echapper(euros(r.montant))}</td></tr>`).join("");
    const dates = (p.dates_travail || []).map(jjmmaaaa).join(", ");
    // CE QUI A ÉTÉ SAISI, ligne par ligne (30/09/2026 : « je vois 2 services
    // mais pas combien d'heures chaque service ; je veux tout voir sans avoir
    // à modifier »). Le moteur rend les heures par unité ET leur total.
    const h = (x) => nombre(x) + " h";
    const saisies = (p.lignes_saisies || []).map((l) => `
      <div class="detail-saisie">
        <b>${echapper(nombre(l.quantite))} × ${echapper(l.libelle || l.rubrique)}</b>
        à ${echapper(euros(l.taux))}
        ${l.heures_par_unite ? ` — <b>${echapper(h(l.heures_par_unite))}</b>
          ${l.unite === "heure" ? "" : `par ${echapper(l.unite || "unité")}`}` : ""}
        ${l.heures ? `, ${echapper(h(l.heures))} en tout` : ""}
        ${l.dates.length ? `<br><span class="discret">Jours :</span> ${echapper(l.dates.map(jjmmaaaa).join(", "))}` : ""}
        ${l.planning.length ? `<br><span class="discret">Prévu ensuite :</span> ${echapper(l.planning.map(jjmmaaaa).join(", "))}` : ""}
        ${l.lieu ? `<br><span class="discret">Lieu :</span> ${echapper(l.lieu)}` : ""}
      </div>`).join("");
    const refs = [p.numero_contrat ? `contrat n° ${p.numero_contrat}` : "",
                  p.numero_bulletin ? `bulletin n° ${p.numero_bulletin}` : "",
                  p.nature && p.nature.libelle ? p.nature.libelle : ""].filter(Boolean).join(" · ");
    return `
      ${refs ? `<p class="discret">${echapper(refs)}</p>` : ""}
      ${saisies}
      <p>${dates ? `<b>Jours travaillés :</b> ${echapper(dates)}<br>` : ""}
        ${p.heures ? `<b>Heures déclarées :</b> ${echapper(nombre(p.heures))}<br>` : ""}
        ${p.cachets ? `<b>Cachets :</b> ${echapper(nombre(p.cachets))}<br>` : ""}
        ${p.lieu && !saisies ? `<b>Lieu :</b> ${echapper(p.lieu)}<br>` : ""}
        ${p.emploi && p.emploi.libelle ? `<b>Emploi :</b> ${echapper(p.emploi.libelle)}` : ""}
        ${p.emploi && p.emploi.cadre ? " (cadre)" : ""}</p>
      <table class="tableau-detail">
        <thead><tr><th>Ce qui est payé</th><th class="nombre">Nombre</th>
          <th class="nombre">Taux</th><th class="nombre">Montant</th></tr></thead>
        <tbody>${lignes}</tbody>
        <tfoot>
          <tr><td colspan="3">Brut</td><td class="nombre">${echapper(euros(p.brut))}</td></tr>
          <tr><td colspan="3"><b>Net à payer</b></td><td class="nombre"><b>${echapper(euros(p.net_a_payer))}</b></td></tr>
          <tr><td colspan="3" class="discret">Coût employeur</td><td class="nombre discret">${echapper(euros(p.cout_employeur))}</td></tr>
        </tfoot>
      </table>`;
  };
  ouvrirBoite(`
    <h3>${echapper(ligne.nom)}</h3>
    <p class="discret">${echapper(pourQuoi(ligne))}, ${echapper(periodeEnClair(ligne.debut, ligne.fin))}
      · validée le ${echapper(quand(ligne.valide))}</p>
    ${ps.length ? ps.map(bloc).join("") : `<p class="discret">Le détail n'est pas encore calculé.</p>`}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      ${MOIS_FERME && MOIS_FORCE !== document.getElementById("mois").value ? "" : `<button class="modifier" id="d-modifier">${CRAYON}Modifier…</button>`}
    </div>`);
  const m = document.getElementById("d-modifier");
  if (m) m.onclick = () => { fermerBoite(); boiteRouvrir(ligne); };
}

/** Les trois nombres du bloc. Une case en cours de frappe ne se repeint pas :
 *  l'aperçu revient 350 ms après la dernière touche, et il écraserait le
 *  montant qu'on est justement en train de viser. */
function peindreChiffres(div, paies) {
  const champs = { net: "net_a_payer", brut: "brut", cout: "cout_employeur" };
  const net = div.querySelector(".e-net");
  if (net) {
    // Le net (ce qu'on vire) et le coût employeur (ce que la compagnie sort) :
    // les deux nombres qui décident d'une paie. Le brut reste dans l'aperçu.
    const somme = (k) => euros(paies.reduce((t, p) => t + Number(p[k] || 0), 0));
    net.innerHTML = paies.length
      ? `Net <b>${echapper(somme("net_a_payer"))}</b>
         <span class="e-cout">Coût employeur <b>${echapper(somme("cout_employeur"))}</b></span>${paies.length > 1
          ? ` <span class="discret">pour ${paies.length} salariés</span>` : ""}`
      : `<span class="discret">Le net s'affiche dès que la paie est complète.</span>`;
  }
  div.querySelectorAll(".e-vise").forEach((c) => {
    if (c === document.activeElement) return;
    c.value = paies.length
      ? paies.reduce((t, p) => t + Number(p[champs[c.dataset.cible]] || 0), 0).toFixed(2)
      : "";
  });
}

/* VISER UN TOTAL, ET EN DÉDUIRE LE TAUX (22/09/2026).
 *
 * L'enveloppe vient avant la paie : on sait qu'on a 500 € pour ce plateau,
 * et on cherche ce que ça fait de cachet. La page ne calcule rien elle-même
 * — le passage du brut au coût n'est pas un pourcentage — : elle envoie la
 * saisie telle quelle et le moteur rejoue la paie jusqu'à tomber juste.
 *
 * Le bloc entier est visé, tous ses salariés cochés compris : « 500 € pour
 * payer les gens », c'est 500 € en tout, répartis au prorata de ce qui est
 * déjà saisi. */
async function ajusterBloc(div, champ) {
  const note = div.querySelector(".e-chiffres-note");
  const montant = (champ.value || "").trim();
  // Vidée : on ne vise plus rien, et l'aperçu remettra le nombre calculé.
  if (montant === "") { rafraichirApercu(); return; }
  const blocs = [...document.querySelectorAll(".engagement")];
  let debut = 0;
  for (const b of blocs) {
    if (b === div) break;
    debut += salariesDuBloc(b).length;
  }
  const combien = salariesDuBloc(div).length;
  if (!combien) {
    note.innerHTML = `<span class="rouge">Cocher d'abord qui est payé.</span>`;
    return;
  }
  const engagements = [];
  for (let k = 0; k < combien; k++) engagements.push(debut + k);
  note.textContent = "calcul…";
  GARDER_SANS_TAUX = true;
  let saisie;
  try { saisie = saisieCourante(); } finally { GARDER_SANS_TAUX = false; }
  try {
    const r = await api("ajuster", {
      saisie, engagements,
      cible: champ.dataset.cible, montant: Number(montant),
    });
    appliquerAjustement(div, r);
    // LA CASE MONTRE CE QU'ON ATTEINT, PAS CE QU'ON A TAPÉ. Un montant visé
    // qu'on laisse à l'écran, c'est un chiffre faux de deux centimes qui
    // reste sous les yeux — et l'aperçu ne repeint pas une case où le curseur
    // est encore (on a tapé Entrée, rien n'a perdu le focus).
    champ.value = r.atteint;
    note.innerHTML = phraseAjustement(r);
  } catch (e) {
    note.innerHTML = `<span class="rouge">${echapper(e.message)}</span>`;
  }
}

/** Les taux que le moteur a trouvés, réécrits dans les cases. Les
 *  engagements d'un même bloc portent les mêmes lignes : le premier suffit. */
function appliquerAjustement(div, r) {
  const e = (r.engagements || [])[0];
  if (!e) return;
  // Les mêmes lignes que `lignesDuBloc` a envoyées pour viser, dans le même
  // ordre : une ligne sans quantité n'est pas partie, donc elle ne compte
  // pas dans les rangs ; une ligne sans taux, si.
  GARDER_SANS_TAUX = true;
  let rangs;
  try { rangs = [...div.querySelectorAll(".rubrique")].filter(ligneEnvoyee); }
  finally { GARDER_SANS_TAUX = false; }
  (e.lignes || []).forEach((l) => {
    const cible = rangs[l.rang];
    if (cible) cible.querySelector(".r-taux").value = l.taux;
  });
  if (e.salaire_mensuel != null) div.querySelector(".e-salaire").value = e.salaire_mensuel;
  rafraichirApercu();
}

/** Ce qui est ATTEINT, jamais ce qui a été demandé. Un taux se paie au
 *  centime : deux cachets ne tombent pas toujours sur 500,00 € pile, et la
 *  page qui afficherait le montant visé mentirait de deux centimes. */
function phraseAjustement(r) {
  const noms = { net: "Net salarié", brut: "Brut", cout: "Coût entreprise" };
  const ecart = Number(r.ecart || 0);
  return `${echapper(noms[r.cible] || r.cible)} visé ${echapper(euros(r.vise))}
    → <b>${echapper(euros(r.atteint))}</b> `
    + (ecart
        ? `<span class="discret">(${ecart > 0 ? "+" : ""}${echapper(euros(r.ecart))} —
           un taux se paie au centime)</span>`
        : `<span class="discret">— au centime près</span>`);
}

/* Ce que porte le contrat, en toutes lettres : « 2 Cachets », « 1 Journée de
 * travail, 6 h de Masterclass ». La phrase vient du MOTEUR (`remuneration`) ;
 * la page ne la fabrique pas depuis un nombre de cachets, sans quoi un contrat
 * sans cachet s'afficherait « 0 cachet(s) ». */
function designation(p) {
  const r = p.remuneration || [];
  return r.length ? r.map((l) => l.designation).join(", ") : "—";
}

/* L'APERCU NE PORTE PAS LE MONTANT URSSAF : il se CALCULE avec la DSN, au
 * centime, comme le bordereau (paie/src/bordereau.rs), et la boite
 * << Fermer le mois >> le montre. */
/* PAR SALARIÉ, UNE LIGNE. « C'est plus facile ensuite pour faire les paies :
 * j'ai juste à mettre le montant du net » ; puis, devant
 * le détail paie par paie : « pas de détail dans l'aperçu ! ». Donc une ligne
 * par salarié, sommée, et le net est ce qu'on vire. Les sommes se font ici,
 * sur les chaînes du moteur, à deux décimales — ce n'est qu'un aperçu, le
 * bulletin fait foi. */
function vueApercu(a) {
  /* LE MOIS, EN DEUX NOMBRES (23/09/2026). Ce qu'on tire de l'aperçu, c'est
     ce qu'on vire à chacun et ce que le mois coûte à la compagnie. Le brut
     et le détail des cachets sont dans les paies, les bulletins et les
     exports : les répéter ici faisait un tableau à cinq colonnes qu'on ne
     lisait qu'en partie. Une ligne par salarié, son net ; le coût au survol. */
  const somme = (xs) => xs.reduce((t, x) => t + Number(x || 0), 0);
  const eur = euros;
  const groupes = [];
  a.paies.forEach((p) => {
    const cle = p.salarie.nom + "|" + p.salarie.prenom;
    let g = groupes.find((x) => x.cle === cle);
    if (!g) { g = { cle, salarie: p.salarie, paies: [] }; groupes.push(g); }
    g.paies.push(p);
  });
  if (!groupes.length) return `<p class="discret">Aucune paie ce mois-ci.</p>`;
  const net = somme(a.paies.map((p) => p.net_a_payer));
  const cout = somme(a.paies.map((p) => p.cout_employeur));
  return `
    <div class="mois-chiffres">
      <div><span>Net à virer</span><b>${eur(net)}</b></div>
      <div><span>Coût employeur</span><b>${eur(cout)}</b></div>
    </div>
    <ul class="mois-salaries">${groupes.map((g) => `
      <li title="coût employeur ${echapper(eur(somme(g.paies.map((p) => p.cout_employeur))))} · brut ${echapper(eur(somme(g.paies.map((p) => p.brut))))}">
        <span>${echapper(g.salarie.nom)} ${echapper(g.salarie.prenom)}
          <span class="discret">· ${g.paies.length} paie${g.paies.length > 1 ? "s" : ""}</span></span>
        <b>${eur(somme(g.paies.map((p) => p.net_a_payer)))}</b>
      </li>`).join("")}
    </ul>`;
}

/* ------------------------------------------------------- charger un mois */
let MOIS_AFFICHE = null;        // le mois REELLEMENT charge dans l'ecran
let MOIS_FERME = null;          // la date limite depassee de ce mois, ou null
let MOIS_FORCE = null;          // le mois ferme que l'on a rouvert, en connaissance de cause

/** Le fichier en blocs : ce qui a été saisi d'un coup pour plusieurs
 *  salariés (saisieCourante) revient d'un coup — même spectacle, mêmes
 *  lignes, qui se suivent, et AUCUN validé. Une paie validée, elle, est
 *  déjà démultipliée : elle a son bloc, fermé, et n'absorbe rien. */
function regrouper(engagements) {
  const groupes = [];
  engagements.forEach((e) => {
    const empreinte = JSON.stringify({ spectacle: e.spectacle || "",
                                       metier: e.metier || "", cadre: e.cadre ?? null,
                                       debut: e.debut || "", fin: e.fin || "",
                                       // Un numéro figé est propre à UN
                                       // salarié : deux paies numérotées ne
                                       // se regroupent jamais.
                                       numero: e.numero || "",
                                       lignes: e.lignes || [],
                                       // UN PERMANENT NE SE REGROUPE QU'AVEC
                                       // SON JUMEAU. Deux CDI aux mêmes
                                       // bornes n'ont pas le même salaire, et
                                       // regrouper sur les seules lignes —
                                       // qu'ils n'ont pas — les aurait fondus
                                       // en un bloc, donc payés pareil.
                                       nature: e.nature || "",
                                       salaire_mensuel: e.salaire_mensuel ?? null,
                                       quotite_contrat: e.quotite_contrat ?? null,
                                       conges_pris: e.conges_pris || [],
                                       absences: e.absences || [],
                                       primes: e.primes || [],
                                       motif_rupture: e.motif_rupture || "",
                                       notification_rupture: e.notification_rupture || "",
                                       preavis: e.preavis || null,
                                       transaction: e.transaction || "",
                                       dernier_jour_paye: e.dernier_jour_paye || "" });
    const dernier = groupes[groupes.length - 1];
    if (dernier && !e.valide && !dernier.valide && dernier.empreinte === empreinte
        && !dernier.salaries.includes(e.salarie)) {
      dernier.salaries.push(e.salarie);
    } else {
      groupes.push({ ...e, salaries: [e.salarie], empreinte });
    }
  });
  return groupes;
}

function afficherRappelsMois() {
  document.getElementById("rappels-mois").innerHTML =
    `cachet à <b>${echapper(euros(DERNIER_TAUX))}</b> par défaut ·
     paiement le ${echapper(jjmmaaaa(SAISIE_DATE_PAIEMENT))} ·
     le lieu et les jours se posent sur chaque ligne de paie`;
}

let DEMANDE_MOIS = null;
async function chargerMois(mois) {
  DEMANDE_MOIS = mois;
  // TOUT LE MOIS D'UN COUP, lu (pas calculé) : les lectures ci-dessous le prennent dans `LU`.
  let lu;
  try { lu = await lireLeMois(mois); } catch (e) { if (DEMANDE_MOIS === mois) document.getElementById("engagements").classList.remove("en-lecture"); throw e; }
  if (DEMANDE_MOIS !== mois) return;
  const r = await api("saisie", { mois });
  // Un mois plus récent a été demandé pendant que celui-ci arrivait : on le
  // laisse tomber, sinon il repeindrait l'écran par-dessus le bon.
  if (DEMANDE_MOIS !== mois) return;
  SAISIE = r.saisie;
  MOIS_AFFICHE = mois;
  document.getElementById("mois").value = mois;
  afficherMoisChoisi();
  // Le taux du mois chargé devient « le dernier taux donné ». Un mois neuf
  // n'en a pas : on garde alors celui de l'écran, qui vient du mois d'avant.
  if (SAISIE.taux_cachet) DERNIER_TAUX = +SAISIE.taux_cachet;
  // Les taux que le mois porte vraiment font foi : le dernier cachet saisi
  // est le cachet par défaut, et chaque autre rubrique garde le sien. Un
  // `taux_cachet` enregistré peut venir d'un taux horaire tapé avant le
  // 25/09/2026 ; les lignes, elles, ne mentent pas.
  (SAISIE.engagements || []).forEach((e) => (e.lignes || []).forEach((l) => {
    if (!(+l.taux > 0)) return;
    if (l.rubrique === "cachet") DERNIER_TAUX = +l.taux;
    else if (l.rubrique) TAUX_PAR_RUBRIQUE[l.rubrique] = +l.taux;
  }));
  // La date de paiement d'une saisie existante fait foi -- on ne réécrit pas
  // le 30 sur un mois payé le 15. Un mois neuf prend la fin du mois.
  SAISIE_DATE_PAIEMENT = SAISIE.date_paiement || finDuMois(mois);
  afficherRappelsMois();
  const cible = document.getElementById("engagements");
  // ON PRÉCHARGE, PUIS ON AFFICHE (ticket #113, 02/10/2026) : « quand on
  // change de mois on arrive sur cette version toute ouverte alors que les
  // paies sont fermées en vert ». Un bloc naît ouvert ; il ne se replie
  // qu'à l'arrivée de l'état de sa paie (`etat-par-paie`). Le démarrage
  // l'attendait déjà sous son voile (22/09/2026) ; un changement de mois ne
  // l'attendait pas. Les blocs restent donc cachés jusque-là, et l'on
  // arrive directement sur les cartes. La page ne devine pas elle-même ce
  // qui est validé : une paie se lit validée aussi quand la DSN réelle du
  // mois est partie, et c'est le moteur qui le sait.
  cible.classList.add("en-lecture");
  cible.innerHTML = "";
  regrouper(SAISIE.engagements || []).forEach((g) => cible.appendChild(ligneEngagement(g)));
  // Ce qui vient d'etre charge est, par definition, ce qui est sur le disque :
  // on le note, pour que l'enregistrement automatique ne reecrive pas un
  // fichier identique a chaque fois qu'on effleure un champ.
  clearTimeout(MINUTEUR_SAISIE);
  DERNIERE_ECRITE = JSON.stringify(saisieCourante());
  // Un mois dont la DSN etait due (le 15 du mois suivant) ne se touche
  // plus : lecture seule, pas d'ajout, pas d'enregistrement automatique.
  MOIS_FERME = r.hors_delai || null;
  // Rouvrir ne vaut que pour LE mois rouvert : on change de mois, on
  // retrouve la lecture seule.
  if (MOIS_FORCE !== mois) MOIS_FORCE = null;
  // Les blocs se montrent quand leurs états sont posés -- ou, quoi qu'il
  // arrive, au bout de quelques secondes : une lecture qui traîne ne doit
  // pas cacher la saisie.
  const montrer = () => {
    if (DEMANDE_MOIS === mois) cible.classList.remove("en-lecture");
  };
  setTimeout(montrer, 5000);
  // Les contrats qui courent encore arrivent AVANT les etats des paies :
  // ceux-ci se posent sur les blocs, et un bloc absent n'aurait rien ou se
  // poser.
  try {
    await poserContratsEnCours(mois);
  } catch (e) {
    montrer();
    throw e;
  }
  if (DEMANDE_MOIS !== mois) return;
  majFermeture(mois, r.existe);
  dessinerDeclareAvant(mois, r.existe);
  document.getElementById("resultat").innerHTML = "";
  // L'aperçu de la saisie enregistrée est dans la lecture : il ne se recalcule que quand on modifie la saisie.
  calculerApercu(lu.lectures.apercu);
  // Ce qui est parti de ce mois-la se lit au meme moment que ce qu'il
  // contient : un ecran qui montrerait la saisie sans l'etat du journal
  // laisserait rejouer un depot deja fait.
  // Les lectures partent ensemble et on RENVOIE leur fin : le demarrage
  // l'attend pour ne montrer la page qu'une fois peinte (« je vois les paies
  // ouvertes qui se ferment », 22/09/2026). Les autres appelants l'ignorent.
  const lectures = [
    dessinerActions(mois),
    dessinerEmbauches(mois),
    dessinerReprise(),
    dessinerArrets(mois),
    dessinerFins(mois),
    // Ou en est CHAQUE paie. Se lit apres le chargement des blocs : les etats
    // se posent sur eux, et un bloc absent n'aurait rien ou se poser.
    dessinerEtatsDesPaies(mois).finally(montrer),
  ];
  return Promise.allSettled(lectures);
}

/** Ce que la fermeture d'un mois change à l'écran — et ce que sa réouverture
 *  rend. Un seul endroit : trois booléens éparpillés, c'est un écran qui se
 *  contredit. `MOIS_FERME` est la date limite dépassée ; `MOIS_FORCE` dit
 *  qu'on a répondu à l'avertissement pour ce mois-là. */
function majFermeture(mois, existe) {
  const ferme = !!MOIS_FERME && MOIS_FORCE !== mois;
  const rouvert = !!MOIS_FERME && MOIS_FORCE === mois;
  document.getElementById("ajouter-engagement").hidden = ferme;
  document.getElementById("engagements").classList.toggle("lecture-seule", ferme);
  // UN MOIS FERMÉ, TROIS CAS, UN SEUL BOUTON (30/09/2026). Le bouton disait
  // « le rouvrir (DSN en retard) » à un mois dont la DSN était passée, et
  // rouvrir un mois d'une année close finissait, quatre clics plus loin,
  // sur un refus. Désormais : année close, on le dit et rien d'autre ; DSN
  // passée, on corrige (la correction part dans la DSN suivante) ; sinon,
  // la DSN est en retard et on rouvre.
  const h = (ETAT.historique || []).find((x) => x.mois === mois) || {};
  const b = document.getElementById("rouvrir-mois");
  b.hidden = !ferme || !!h.clos || (["passee", "attente"].includes(h.dsn) && !h.corrigeable);
  if (["passee", "attente"].includes(h.dsn) && h.corrigeable) {
    b.textContent = "Corriger ce mois…";
    b.classList.remove("alerte");
    b.onclick = () => boiteCorriger(mois);
  } else {
    b.textContent = "Rouvrir ce mois (DSN en retard)";
    b.classList.add("alerte");
    b.onclick = () => boiteRouvrirMois(mois, MOIS_FERME);
  }
  noteSaisie(ferme
    ? h.clos
      ? `L'année ${mois.slice(0, 4)} est close : ce mois se lit. Pour le modifier, rouvrir l'année (Historique › L'année).`
      : ["passee", "attente"].includes(h.dsn)
        ? "Sa DSN est partie : ce mois se lit. Une correction part dans la DSN suivante."
        : `Sa DSN était due le ${jjmmaaaa(MOIS_FERME)} : ce mois se lit, et se rouvre pour la déposer en retard.`
    : rouvert
      ? `Mois rouvert — sa DSN était due le ${jjmmaaaa(MOIS_FERME)} : ce qui part d'ici part en retard.`
      : existe
        ? "Saisie chargée. L'enregistrement est automatique."
        : "Nouveau mois — l'enregistrement est automatique dès la première saisie.");
}

/** Un mois PASSÉ sans fichier de paie (avant PuppetPaie) : ce que la
 *  compagnie a déclaré ce mois-là, lu dans les attestations importées de
 *  CoolPaie — le calendrier du mois et la liste des contrats, en lecture
 *  seule, à la place du vide. « Je voulais que l'historique soit au même
 *  endroit que les paies » (16/09/2026). */
async function dessinerDeclareAvant(mois, existe) {
  const cible = document.getElementById("declare-avant");
  cible.hidden = true; cible.innerHTML = "";
  const courant = new Date().toISOString().slice(0, 7);
  if (existe || mois >= courant) return;
  let contrats = [];
  try { contrats = (await api("contrats-passes", { mois })).contrats || []; } catch (e) { return; }
  if (MOIS_AFFICHE !== mois || !contrats.length) return;
  const plusieurs = new Set(contrats.map((c) => c.salarie)).size > 1;
  const nCachets = contrats.reduce((n, c) => n + c.cachets, 0);
  cible.innerHTML = `
    <div class="declare-avant">
      <div class="da-tete"><b>Déclaré en ${echapper(moisEnClair(mois))}</b>
        <span class="discret">— avant PuppetPaie, d'après les attestations de CoolPaie ·
        ${contrats.length} contrat${contrats.length > 1 ? "s" : ""}, ${nCachets} cachet${nCachets > 1 ? "s" : ""} · lecture seule</span></div>
      <div class="da-corps">
        <div class="c-grille">${casesMoisPasse(mois, contrats, plusieurs)}</div>
        <div class="c-passes">${contrats.map((c) => ligneContratPasse(c, plusieurs)).join("")}</div>
      </div>
      <p class="note">Début, fin et nombre de cachets : c'est tout ce que l'attestation
        portait — les jours exacts ne sont connus que pour les mois produits ici. Les cachets
        chez d'autres employeurs n'y sont pas.</p>
    </div>`;
  cible.hidden = false;
}

/* Changer de mois enregistre d'abord CE QUI EST À L'ÉCRAN, et sous son vrai
 * mois. La case a déjà changé quand on arrive ici : on y remet l'ancien mois
 * le temps de l'écriture, sans quoi les engagements d'août partiraient dans le
 * fichier de septembre — la case du mois est ce qui date les jours joués. */
document.getElementById("mois").onchange = async (e) => {
  fermerCalendriers();
  const neuf = e.target.value;
  if (MOIS_AFFICHE && MOIS_AFFICHE !== neuf) {
    clearTimeout(MINUTEUR_SAISIE);
    e.target.value = MOIS_AFFICHE;
    await enregistrerSaisie(true);
    e.target.value = neuf;
  }
  chargerMois(neuf);
};

/* LE CHOIX DU MOIS (25/09/2026). « Un truc simple, qu'on puisse cliquer sur
 * toute la case pour arriver aux choix, et que le défilement soit plus
 * rapide. » Une case : ‹ Octobre 2026 ›. Les flèches changent le nom tout de
 * suite et ne chargent le mois qu'une fois qu'on s'arrête de cliquer —
 * trois clics rapides font UN chargement, pas trois. Un clic sur le nom
 * ouvre l'année : douze mois, un clic pour y aller. Un point marque les
 * mois qui ont une saisie.
 *
 * La valeur reste dans le champ caché #mois et passe par son événement
 * « change » : la saisie à l'écran s'enregistre d'abord sous son vrai mois. */
const CASE_MOIS_NOMS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
                   "août", "septembre", "octobre", "novembre", "décembre"];
const CASE_MOIS_COURTS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.",
                     "août", "sept.", "oct.", "nov.", "déc."];
let MINUTEUR_MOIS = null;
let ANNEE_GRILLE = null;

const moisEnTexte = (a, m) => `${a}-${String(m).padStart(2, "0")}`;
function moisLu(v) {
  const [a, m] = String(v || "").split("-").map(Number);
  return a && m ? [a, m] : null;
}

/** Le nom dans la case — appelé partout où la valeur change. */
function afficherMoisChoisi() {
  const x = moisLu(document.getElementById("mois").value);
  const nom = document.getElementById("mois-nom");
  nom.textContent = x ? `${CASE_MOIS_NOMS[x[1] - 1].replace(/^./, (c) => c.toUpperCase())} ${x[0]}` : "Choisir un mois";
}

/** Aller à un mois : le nom tout de suite, le chargement après `attente` ms. */
function allerAuMois(v, attente = 0) {
  const c = document.getElementById("mois");
  c.value = v;
  afficherMoisChoisi();
  // LE NOM ET LES CARTES DISENT LE MÊME MOIS (09/10/2026 : « quand je change de
  // mois on reste sur septembre ») : dès que le nom change, les cartes de
  // l'ancien mois s'effacent ; elles reviennent si l'on revient dessus.
  document.getElementById("engagements").classList.toggle("en-lecture", v !== MOIS_AFFICHE);
  clearTimeout(MINUTEUR_MOIS);
  MINUTEUR_MOIS = setTimeout(() => {
    if (c.value !== MOIS_AFFICHE) c.dispatchEvent(new Event("change"));
  }, attente);
}

function moisVoisin(pas) {
  const x = moisLu(document.getElementById("mois").value);
  if (!x) return;
  const d = new Date(x[0], x[1] - 1 + pas, 1);
  // 30 ms : de quoi faire d'un double clic UN chargement ; un mois se lit, il ne se calcule plus (09/10/2026).
  allerAuMois(moisEnTexte(d.getFullYear(), d.getMonth() + 1), 30);
}

function dessinerGrilleMois() {
  const grille = document.getElementById("mois-grille");
  const choisi = document.getElementById("mois").value;
  const aujourdhui = new Date();
  const ceMois = moisEnTexte(aujourdhui.getFullYear(), aujourdhui.getMonth() + 1);
  const saisis = new Set((ETAT.historique || []).map((h) => h.mois));
  grille.innerHTML = `
    <div class="choix-mois-annee">
      <button type="button" class="choix-mois-pas" data-annee="-1" aria-label="Année précédente">&lsaquo;</button>
      <b>${ANNEE_GRILLE}</b>
      <button type="button" class="choix-mois-pas" data-annee="1" aria-label="Année suivante">&rsaquo;</button>
    </div>
    <div class="choix-mois-douze">${CASE_MOIS_COURTS.map((n, i) => {
      const v = moisEnTexte(ANNEE_GRILLE, i + 1);
      const classes = [v === choisi ? "choisi" : "", v === ceMois ? "maintenant" : "",
                       saisis.has(v) ? "saisi" : ""].join(" ");
      return `<button type="button" class="${classes}" data-mois="${v}"
                title="${CASE_MOIS_NOMS[i]} ${ANNEE_GRILLE}${saisis.has(v) ? " — saisi" : ""}">${n}</button>`;
    }).join("")}</div>`;
  grille.querySelectorAll("[data-annee]").forEach((b) => {
    b.onclick = (e) => { e.stopPropagation(); ANNEE_GRILLE += +b.dataset.annee; dessinerGrilleMois(); };
  });
  grille.querySelectorAll("[data-mois]").forEach((b) => {
    b.onclick = () => { fermerGrilleMois(); allerAuMois(b.dataset.mois); };
  });
}

function ouvrirGrilleMois() {
  const x = moisLu(document.getElementById("mois").value);
  ANNEE_GRILLE = x ? x[0] : new Date().getFullYear();
  dessinerGrilleMois();
  document.getElementById("mois-grille").hidden = false;
  document.getElementById("mois-nom").setAttribute("aria-expanded", "true");
}
function fermerGrilleMois() {
  document.getElementById("mois-grille").hidden = true;
  document.getElementById("mois-nom").setAttribute("aria-expanded", "false");
}

document.getElementById("mois-avant").onclick = () => moisVoisin(-1);
document.getElementById("mois-apres").onclick = () => moisVoisin(1);
document.getElementById("mois-nom").onclick = () =>
  (document.getElementById("mois-grille").hidden ? ouvrirGrilleMois() : fermerGrilleMois());
// Les flèches du clavier sur la case font défiler, comme les boutons.
document.getElementById("mois-nom").onkeydown = (e) => {
  if (e.key === "ArrowLeft") { e.preventDefault(); moisVoisin(-1); }
  if (e.key === "ArrowRight") { e.preventDefault(); moisVoisin(1); }
};
document.addEventListener("click", (e) => {
  if (!e.target.closest("#choix-mois")) fermerGrilleMois();
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape") fermerGrilleMois(); });

/* UN CLIC SUR UNE DATE OUVRE LE CALENDRIER, PARTOUT (25/09/2026). Sans cela il
 * fallait viser la petite icône au bout de la case. */
document.addEventListener("click", (e) => {
  const c = e.target;
  if (!(c instanceof HTMLInputElement) || !/^(date|month|datetime-local)$/.test(c.type)) return;
  if (c.disabled || c.readOnly || typeof c.showPicker !== "function") return;
  try { c.showPicker(); } catch (err) { /* déjà ouvert, ou refusé : l'icône reste */ }
});

/* Quitter l'onglet ou fermer la fenêtre : on écrit ce qui attend encore. Une
 * seconde de battement suffit à perdre une frappe si on ferme juste après. */
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") {
    clearTimeout(MINUTEUR_SAISIE);
    enregistrerSaisie(true);
  }
});



/* ------------------------------------------- l'enregistrement automatique
   « Je comprends pas les boutons en bas produire le mois et enregistrer la
   saisie, tout est déjà dans les cases ».

   Il a raison, et le bouton est parti. Ce qui est tapé dans une case EST la
   saisie ; demander un clic pour le confirmer, c'était demander de tenir en
   tête un état — « est-ce que j'ai enregistré ? » — que la machine connaît
   mieux. Trois choses pour que ça reste honnête :

   1. UNE SECONDE APRÈS LA DERNIÈRE FRAPPE, pas à chaque touche. Écrire le
      fichier vingt fois pendant qu'on tape un nom ne sert personne.
   2. LA LIGNE D'ÉTAT DIT L'HEURE. « Enregistré à 14:32 » — sans quoi
      l'enregistrement automatique est un enregistrement dont on ne sait pas
      s'il a eu lieu, c'est-à-dire pire que le bouton.
   3. RIEN NE PART POUR AUTANT. Enregistrer, c'est écrire paies/AAAA-MM.json
      et rien d'autre. Produire consomme des numéros et écrit des fichiers qui
      partiront : ça reste un bouton, et ça le restera. */
let MINUTEUR_SAISIE = null;
let DERNIERE_ECRITE = null;      // le JSON tel qu'il a été enregistré

function noteSaisie(texte) {
  document.getElementById("note-saisie").textContent = texte;
}

/** Enregistre si quelque chose a changé. Rend true si le fichier a été écrit. */
async function enregistrerSaisie(silencieux) {
  const s = saisieCourante();
  if (!s.mois) return false;
  // Un mois ferme ne s'ecrit plus -- sauf celui qu'on a rouvert en repondant
  // a l'avertissement, et le moteur exige alors qu'on le redise (`forcer`).
  if (MOIS_FERME && MOIS_FORCE !== s.mois) return false;
  const empreinte = JSON.stringify(s);
  if (empreinte === DERNIERE_ECRITE) return false;
  try {
    await api("enregistrer-saisie", { mois: s.mois, saisie: s,
                                      forcer: MOIS_FORCE === s.mois });
    DERNIERE_ECRITE = empreinte;
    oublierCouts();
    const h = new Date().toTimeString().slice(0, 5);
    noteSaisie("Enregistré à " + h + ".");
    ETAT.historique = await api("etat").then((e) => e.historique);
    // Ce qui vient d'etre enregistre devient declarable : les blocs qui
    // disaient << pas dans la saisie enregistree >> doivent cesser de le dire,
    // et la colonne << ce qui part >> compte desormais cette paie (elle
    // disait << aucune paie ce mois-ci >> tant qu'on ne rechargeait pas).
    await rafraichirActions();
    // La fin d'un contrat se lit sur la saisie ENREGISTRÉE : tant qu'elle
    // n'était pas relue ici, on tapait le motif de rupture et le bloc
    // continuait d'annoncer qu'il manquait.
    await dessinerFins(s.mois);
    return true;
  } catch (e) {
    // Une paie dont on n'a pas encore choisi les jours n'est pas une faute :
    // c'est la saisie en cours. On le dit en une ligne, sans la règle du
    // fichier (« lignes: [] ») ni d'alerte (30/09/2026).
    if (e.detail?.type === "SaisieIncomplete") {
      noteSaisie(/spectacle/.test(e.message)
        ? "Pas encore enregistré : choisir le spectacle."
        : "Pas encore enregistré : choisir les jours travaillés.");
      return false;
    }
    // Un échec d'enregistrement ne peut pas rester discret : c'est du travail
    // qu'on croit posé et qui ne l'est pas.
    noteSaisie("PAS enregistré — " + e.message);
    if (!silencieux) dire(e.message, "erreur");
    return false;
  }
}

/** Appelée à chaque frappe. Enregistre une seconde après la dernière. */
function enregistrerPlusTard() {
  clearTimeout(MINUTEUR_SAISIE);
  noteSaisie("Modifié…");
  MINUTEUR_SAISIE = setTimeout(() => enregistrerSaisie(true), 1000);
}

/* ---------------------------------------------------------- production */
/** FERMER LE MOIS (29/09/2026) — bulletins, certificats, DSN. Plus de
 *  montant URSSAF à recopier : le moteur calcule le bordereau comme la DSN
 *  le porte (paie/src/bordereau.rs). Plus de contrats ni de DPAE :
 *  ils sont partis avant, et le moteur refuse de fermer sinon (MoisPasPret).
 *  `apres` enchaîne sur le dépôt, qui part d'abord en test. */
async function boiteProduire(mois, apres) {
  clearTimeout(MINUTEUR_SAISIE);
  await enregistrerSaisie(true);
  const saisie = saisieCourante();
  if (mois && saisie.mois !== mois) {
    dire("Le mois affiché n'est pas " + mois + "."); return;
  }
  let urssaf = null;
  try {
    urssaf = (await api("apercu", { saisie })).urssaf;
  } catch (e) { dire(e.message, "erreur"); return; }

  // Un mois dont la DSN réelle est partie se refait en ANNULE-ET-REMPLACE :
  // on le dit avant, avec l'ordre et la limite que le moteur a calculés.
  const ar = MOIS_ACTES && MOIS_ACTES.mois === saisie.mois
    && MOIS_ACTES.bilans?.dsn?.remplacement;
  const refaire = !!(ar && ar.deposee);
  ouvrirBoite(`
    <h3>${refaire ? "Refaire la DSN du mois ?" : "Fermer le mois ?"}</h3>
    ${moisEnGros(saisie.mois)}
    ${refaire ? `<div class="encart attention"><b>Annule-et-remplace intégral —
      ordre ${echapper(ar.prochain_ordre)}</b> Une DSN réelle est déjà partie
      pour ce mois. Celle-ci la remplace en entier, ordres de télépaiement
      compris. La norme l'admet jusqu'au ${echapper(jjmmaaaa(ar.limite))} à
      minuit ; au-delà, la correction passe par la DSN du mois suivant.</div>` : ""}
    <p>Le logiciel écrit les bulletins, les certificats Congés Spectacles et
      la DSN du mois. La DSN part aussitôt <b>en test</b> ; si le test passe,
      on vous propose de l'envoyer pour de vrai.</p>
    ${urssaf === null || urssaf === undefined ? "" : `<p class="note">Télépaiement
      URSSAF du mois : <b>${echapper(euros(urssaf))}</b>, calculé comme le
      bordereau de la DSN, code par code.</p>`}
    <div id="b-manques"></div>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="b-lancer">Fermer le mois</button>
    </div>`);

  document.getElementById("b-lancer").onclick = async () => {
    const charge = {
      mois: saisie.mois, saisie,
      // Un mois rouvert : le moteur refuserait sans ce mot-la.
      forcer: MOIS_FORCE === saisie.mois,
    };
    document.getElementById("b-lancer").disabled = true;
    try {
      const r = await api("produire", charge);
      fermerBoite();
      // La production a figé les numéros de contrat dans la saisie : on
      // recharge le mois pour que l'écran les porte (et les renvoie).
      await chargerMois(saisie.mois);
      afficherResultat(r);
      dire(r.fichiers.length + " fichier(s) écrits dans " + r.dossier);
      ETAT = await api("etat");
      await rafraichirActions();      // les fichiers a deposer viennent d'apparaitre
      if (apres) await apres();
    } catch (e) {
      if (e.detail?.type === "MoisPasPret") {
        // Ce qui manque, embauche par embauche : c'est une liste, pas un
        // refus sec. Le bouton reste éteint -- il n'y a rien à retenter ici.
        document.getElementById("b-manques").innerHTML = `
          <div class="encart attention"><b>Pas encore : il reste à envoyer</b>
          <ul>${e.detail.manques.map((m) => `<li>${echapper(m.phrase)}</li>`).join("")}</ul>
          DPAE et contrats partent aux étapes 1 et 2.</div>`;
        return;
      }
      document.getElementById("b-lancer").disabled = false;
      dire(e.message, "erreur");
    }
  };
}

function afficherResultat(r) {
  const fichiers = r.fichiers.map(
    (f) => `<li>${echapper(f.nom)} <span class="discret">(${f.octets} o)</span></li>`).join("");
  const etapes = r.etapes.map((e, i) => `
    <li><b>${echapper(e.titre)}</b> — ${echapper(e.detail)}
      ${e.commande ? `<br><code class="discret">${echapper(e.commande)}</code>` : ""}</li>`).join("");
  const avert = r.avertissements.map(
    (a) => `<div class="encart attention">${echapper(a)}</div>`).join("")
    + (r.informations || []).map(
    (a) => `<div class="encart info">${echapperLiens(a)}</div>`).join("");
  document.getElementById("resultat").innerHTML = `
    <div class="carte" style="margin-top:20px">
      <h2>${echapper(r.libelle)} — produit</h2>
      ${avert}
      <div class="encart bien">
        <b>Numéros consommés</b>
        ${r.numeros.bulletin_premier
          ? `bulletins ${r.numeros.bulletin_premier} à ${r.numeros.bulletin_dernier}`
          : "aucun bulletin (aucun cachet ce mois-ci)"}${
          // Plus d'AEM depuis le 01/06/2026 (France Travail l'edite depuis la
          // DSN) ; et pas de certificat CS un mois ou aucun contrat ne finit.
          r.numeros.cs_dernier >= r.numeros.cs_premier
            ? ` · certificats CS ${r.numeros.cs_premier} à ${r.numeros.cs_dernier}`
            : " · aucun certificat CS ce mois-ci (contrat en cours)"}
      </div>
      <div class="colonnes">
        <div><h2>Fichiers</h2><ul>${fichiers}</ul>
          <p class="note">Dans ${echapper(r.dossier)}</p></div>
        <div><h2>À faire ensuite</h2><ol>${etapes}</ol>
          <p class="note">Les dépôts et les envois restent manuels : une
             déclaration part sous la responsabilité de l'employeur.</p></div>
      </div>
    </div>`;
}

/* ---------------------------------------------------------- la boite */
/*  `auFermer` est appele QUOI QU'IL ARRIVE, y compris quand on clique a cote
 *  de la boite. Sans lui, une boite qui repond par une promesse resterait en
 *  attente pour toujours : le clic a cote passerait pour un « annuler » a
 *  l'ecran, et l'enregistrement qui attendait sa reponse ne viendrait jamais. */
let FERMETURE_BOITE = null;
/* LE CLIC À CÔTÉ ferme la boîte, sauf celle qui pose ici un autre geste
 * (ticket #102 : dans la boîte de signalement, « cliqué à côté ça doit faire
 * comme réduire » -- le message tapé ne doit pas se perdre). */
let CLIC_DEHORS = null;
function ouvrirBoite(html, auFermer) {
  document.getElementById("boite").innerHTML = html;
  document.getElementById("voile").classList.remove("cachee");
  FERMETURE_BOITE = auFermer || null;
  CLIC_DEHORS = null;
  ajouterToutCocher(document.getElementById("boite"));
}

/* METTRE DE CÔTÉ LA BOÎTE OUVERTE, le temps d'en ouvrir une autre par-dessus
 * (ticket #103 : « j'étais dans la dpae, j'ai cliqué sur signaler un
 * problème et ça a quitté la dpae »). Ses nœuds sortent de la page tels
 * quels -- cases cochées, champs tapés, gestes attachés --, et reviennent
 * quand la boîte du dessus se ferme. Rend la fonction qui les remet, ou
 * null s'il n'y avait rien d'ouvert. */
function mettreDeCote() {
  const voile = document.getElementById("voile"), boite = document.getElementById("boite");
  if (voile.classList.contains("cachee") || !boite.childNodes.length) return null;
  const noeuds = [...boite.childNodes];
  const fermeture = FERMETURE_BOITE, clic = CLIC_DEHORS;
  noeuds.forEach((n) => n.remove());
  FERMETURE_BOITE = null;
  return () => {
    document.getElementById("boite").innerHTML = "";
    document.getElementById("boite").append(...noeuds);
    voile.classList.remove("cachee");
    FERMETURE_BOITE = fermeture;
    CLIC_DEHORS = clic;
  };
}

/* TOUT COCHER, D'UN CLIC (l'éditeur, 30/09/2026 : « quand on clique sur
 * DPAE ou sur contrat, un truc tout sélectionné, plutôt que de cliquer à
 * la main » — renvoyer tous les contrats, par exemple). Chaque liste de
 * choix de plus d'une case reçoit en tête une case « Tout cocher ». Elle
 * passe par l'événement « change » de chaque case : ce que la boîte en
 * déduit (le libellé du bouton, un avenant) suit comme au clic. Une case
 * grisée (une DPAE déjà passée) n'est pas touchée. */
function ajouterToutCocher(racine) {
  racine.querySelectorAll(".liste-choix").forEach((liste) => {
    const cases = () => [...liste.querySelectorAll('.choix > input[type="checkbox"]:not(:disabled)')];
    if (cases().length < 2) return;
    const tete = document.createElement("label");
    tete.className = "coche tout-cocher";
    tete.innerHTML = `<input type="checkbox"> <b>Tout cocher</b>`;
    const maitre = tete.querySelector("input");
    const suivre = () => {
      const c = cases(), n = c.filter((x) => x.checked).length;
      maitre.checked = n === c.length;
      maitre.indeterminate = n > 0 && n < c.length;
    };
    maitre.onchange = () => {
      cases().forEach((x) => {
        if (x.checked !== maitre.checked) {
          x.checked = maitre.checked;
          x.dispatchEvent(new Event("change", { bubbles: true }));
        }
      });
      suivre();
    };
    liste.addEventListener("change", (e) => { if (e.target !== maitre) suivre(); });
    liste.before(tete);
    suivre();
  });
}
function fermerBoite() {
  document.getElementById("voile").classList.add("cachee");
  const f = FERMETURE_BOITE;
  FERMETURE_BOITE = null;
  if (f) f();
}
document.getElementById("voile").onclick = (e) => {
  if (e.target.id !== "voile") return;
  if (CLIC_DEHORS) CLIC_DEHORS();
  else fermerBoite();
};

/* =======================================================================
   LE MOIS : CE QUI PART D'ICI
   =======================================================================
   Quatre actes, un seul écran pour les quatre : déposer la DSN, déposer la
   DPAE, envoyer les documents aux salariés, demander la signature des
   contrats. Le moteur sait les faire depuis le 11/09/2026 ; ils n'avaient
   pas d'écran, et un bouton qui n'existe pas est une fonction qui n'existe
   pas.

   TROIS RÈGLES, ET AUCUNE N'EST TENUE ICI — c'est tout le sujet :

   1. La phrase d'état vient du JOURNAL, par le moteur (`journal.resume`).
      Elle distingue trois choses qu'un écran confondrait vite : jamais
      parti, parti sans réponse, parti et répondu. « En attente » affiché
      comme « conforme », c'est une déclaration qu'on croit faite.
   2. Rien ne part d'un clic. Chaque bouton ouvre un RÉCAPITULATIF, et le
      récapitulatif demande le mot de passe DU LOGICIEL — pas celui de
      l'organisme, que cette page ne voit jamais, ne demande jamais et ne
      reçoit jamais. Le moteur va le chercher lui-même au coffre.
   3. Le mois déclaré y est écrit EN GROS. Ce n'est pas de la décoration :
      recopier le mois était le seul geste qu'on ne peut pas faire sans
      regarder l'écran, et il a été retiré du parcours. Un mot de passe se
      tape de mémoire, les yeux ailleurs — donc c'est ce bloc-là qui porte
      désormais toute la lecture (docstring d'`operations.Preuve`).

   La séance se voit AVANT le clic, et pourtant les boutons restent actifs.
   Un garde-fou posé dans un front est un garde-fou qu'on contourne par
   l'autre face : c'est `operations` qui refuse, et lui seul. La page
   prévient, parce que découvrir un refus après avoir tapé son mot de passe
   est une mauvaise façon d'apprendre qu'il fallait ouvrir la séance.
*/
let MOIS_ACTES = null;          // le dernier /api/etat-du-mois lu

/* Trois états, trois couleurs, et surtout pas deux : « parti, pas de retour »
 * n'est pas « parti et conforme ». */
/** Les derniers envois d'un acte, tests compris, quand ils disent autre chose
 *  que l'état réel du dessus — « j'aimerais avoir les derniers retours ici »
 *. */
/** Le fil des envois d'un acte. Les dépôts de TEST n'y sont que dans la
 *  copie de développement (25/09/2026 : « garde les tests pour quand
 *  j'ouvre la compagnie dev ») ; chez la compagnie, le test d'un dépôt se
 *  lit dans sa boîte, et le fil ne dit que ce qui est parti. */
function envoisVisibles(e, cle) {
  const lignes = (e.derniers && e.derniers[cle]) || [];
  return document.body.dataset.copie ? lignes : lignes.filter((l) => l.mode !== "test");
}

function derniersEnvois(e, cle) {
  const lignes = envoisVisibles(e, cle);
  if (!lignes.length) return "";
  // Tous, réel compris, le plus récent en premier — l'état réel du dessus
  // reste la réponse à « est-ce fait ? », ceci est le fil des envois.
  return `<div class="acte-derniers">` + lignes.map((l) =>
    `<div class="acte-dernier ${l.mode === "test" ? "test" : "reel"}">${echapper(l.resume)}</div>`)
    .join("") + `</div>`;
}

/** La phrase d'un coup d'œil, dans la tête de la boîte : courte quand c'est
 *  fini, la phrase du bilan sinon (elle dit ce qui reste). */
function phraseCourte(cle, couleur, phrase, courte) {
  // Le bilan peut dire lui-même sa phrase courte : « rien ce mois-ci » pour
  // un contrat en cours, dont la DPAE et la signature relèvent d'un autre
  // mois — « toutes envoyées » serait une promesse que ce mois ne tient pas.
  if (courte) return courte;
  if (couleur === "bien") return {
    "dpae": "toutes envoyées", "contrat-signature": "envoyés et signés",
    "documents": "envoyés à tous", "dsn": "déposée et passée",
  }[cle] || phrase;
  if (couleur === "refus") return "REFUSÉ — à revoir";
  if (couleur === "alerte") return {
    "dpae": "en attente / à faire", "contrat-signature": "en attente / à faire",
    "documents": "en partie", "dsn": "retour attendu",
  }[cle] || phrase;
  return {
    "dpae": "à déposer", "contrat-signature": "à envoyer",
    "documents": "à envoyer", "dsn": "à déposer",
  }[cle] || phrase;
}

function couleurActe(ligne) {
  if (!ligne) return "";
  const retours = ligne.retours || [];
  // Un bilan KO sans certificat : c'est un refus, et ça se voit en rouge.
  if (retours.some((r) => r.verdict === "KO") && !retours.some((r) => String(r.nature) === "41")) return "refus";
  return retours.length ? "bien" : "alerte";
}

/* << d'aout >>, << de septembre >>. Une elision qui manque se lit comme une
 * faute de frappe, et une interface qui ecrit mal fait douter de ce qu'elle
 * compte. */
function deMois(iso) {
  const nom = moisEnClair(iso);
  return ("aeiouyâàéèêîôû".includes(nom[0]) ? "d'" : "de ") + nom;
}

function quand(iso) {
  // « 12/09/2026 à 18:18 » : on travaille en France, une date à l'américaine
  // dans une phrase se lit mal. L'ISO reste dans les
  // fichiers et les échanges ; ce qui s'affiche passe par ici.
  const s = String(iso || "");
  if (s.length < 10 || s[4] !== "-" || s[7] !== "-") return s;
  const jour = `${s.slice(8, 10)}/${s.slice(5, 7)}/${s.slice(0, 4)}`;
  const heure = s.length >= 16 ? s.slice(11, 16) : "";
  return heure ? `${jour} à ${heure}` : jour;
}

/* Le mois déclaré, EN GROS. Voir le point 3 ci-dessus. */
function moisEnGros(mois) {
  return `<div class="mois-gros">
    <span class="clair">${echapper(moisEnClair(mois))}</span>
    <span class="iso">${echapper(mois)}</span>
  </div>`;
}

/* IL N'Y A PLUS DE SÉANCE (16/09/2026). Il y avait ici un encart « Séance
 * fermée — un dépôt sera refusé » : la séance s'ouvrait avec la fenêtre et
 * valait tant qu'elle vivait, et le dépôt l'exigeait EN PLUS du mot de passe
 * retapé. Deux preuves pour un geste, dont une invisible. Depuis la fenêtre
 * unique, la seule preuve est le mot de passe du logiciel demandé dans
 * popup de l'acte (`demanderMotDePasse`) ; rien à annoncer entre les actes. */

/** La date limite de la DSN d'un mois, telle que l'échéancier la calcule
 *  (le jour se déduit de l'effectif) : « 15/10/2026 ». Lue une fois par
 *  séance ; sans elle, l'étape se tait sur sa date. */
let ECHEANCIER = null;
async function limiteDsn(mois) {
  try {
    if (!ECHEANCIER) ECHEANCIER = await api("echeancier");
  } catch (e) { return ""; }
  const x = [...(ECHEANCIER.ce_mois || []), ...(ECHEANCIER.a_venir || [])]
    .find((y) => y.cle === "dsn:" + mois);
  return x && x.date ? jjmmaaaa(x.date) : "";
}

/** LE CHEMIN D'UN DÉPÔT, DANS L'ORDRE OÙ IL SE FAIT (26/09/2026 : « pour
 *  la DPAE il faut cliquer sur fabriquer, ensuite la mettre en test, attendre
 *  les résultats du test, et envoyer »). Le moteur dit où en est le fichier
 *  (`bilan.etape`) ; le bouton de l'étape dit le geste suivant, et ouvre
 *  directement la boîte de dépôt de CE fichier quand il est déjà fabriqué. */
function cheminDuDepot(a, bilan) {
  if (a.cle !== "dpae" && a.cle !== "dsn") return;
  const nom = a.cle === "dsn" ? "la DSN" : "la DPAE";
  if (bilan && bilan.attente) {
    a.bouton = a.cle === "dsn" ? "Voir la DSN déposée…" : "Voir les DPAE…";
    return;
  }
  const etape = bilan && bilan.etape;
  if (!etape || !bilan.fichier) return;
  a.bouton = {
    ecrite: `Tester ${nom}…`,
    en_test: "Voir le test en cours…",
    testee: `Envoyer ${nom} testée…`,
    test_refuse: "Voir le refus du test…",
    paie_changee: `Réécrire ${nom} et la tester…`,
  }[etape] || a.bouton;
  const fichier = bilan.fichier;
  // UNE PAIE MODIFIÉE REPASSE PAR LE TEST (30/09/2026, l'éditeur : « si on
  // modifie une paie on doit passer en mode test à nouveau, simple et
  // efficace »). Le fichier testé ne déclare plus la paie : on réécrit le
  // mois, et la boîte de dépôt s'ouvre sur le test.
  if (etape === "paie_changee") {
    const mois = document.getElementById("mois").value;
    a.ouvrir = () => boiteProduire(mois, async () => {
      const e2 = await api("etat-du-mois", { mois });
      const d2 = (e2.fichiers[a.cle] || [])[0];
      if (d2) await boiteDepot(a.cle, d2.chemin, { testerDabord: true });
    });
    return;
  }
  a.ouvrir = () => boiteDepot(a.cle, fichier);
}

/* -------------------------------------------- la colonne des quatre actes */
async function dessinerActions(mois) {
  const cible = document.getElementById("actions-mois");
  if (!mois) { cible.innerHTML = ""; return; }
  cible.innerHTML = `<p class="discret">Lecture du journal…</p>`;
  let e;
  try {
    e = await api("etat-du-mois", { mois });
  } catch (err) {
    cible.innerHTML = `<p class="discret">${echapper(err.message)}</p>`;
    return;
  }
  MOIS_ACTES = e;

  // Quel fichier se dépose est tranché par le moteur (`fichiers_deposables`) :
  // un mois porte souvent deux DSN, et la bonne est la dernière écrite.
  const dsn = (e.fichiers.dsn || [])[0];
  const dpae = (e.fichiers.dpae || [])[0];

  /* DANS L'ORDRE OÙ ÇA SE FAIT, et non dans l'ordre où c'est important.
     « L'ordre à droite est absurde : c'est d'abord DPAE, puis contrat, puis
     DSN, puis documents ». Il décrit le calendrier réel
     d'un mois, et c'est le seul ordre qui vaille pour une colonne qu'on
     descend :

       la DPAE part AVANT le premier jour travaillé (c'est la loi) ;
       le contrat se signe autour de l'embauche ;
       la DSN part le 5 ou le 15 du mois suivant ;
       les documents partent une fois la paie faite.

     La DSN était en tête parce qu'elle est l'acte le plus lourd. Une colonne
     n'est pas un classement par gravité : c'est une liste qu'on descend. */
  const actes = [
    { cle: "dpae", titre: "DPAE", court: "DPAE", detail: "les déclarations préalables à l'embauche",
      bouton: "Envoyer les DPAE…", fichier: dpae, toujours: true,
      // La boîte des embauches, comme celle des signatures : chaque contrat
      // du mois, une case, cochée d'avance s'il reste à déclarer
      // (15/09/2026). Le fichier complet du mois ne se redépose jamais tel
      // quel — il redéclarerait ce qui est parti.
      ouvrir: () => boiteDpae(mois) },
    { cle: "contrat-signature", titre: "Contrats à signer", court: "CONTRATS",
      detail: "envoyés avec le bouton « Je signe » — la réponse est relevée toute seule",
      bouton: "Demander la signature…", toujours: true,
      ouvrir: () => boiteSignature(mois) },
    // « La DSN ne doit pas être liée à la sélection : elle fait
    // obligatoirement tout le mois, pas comme les DPAE » (12/09/2026). Elle
    // n'a jamais figuré dans la barre des actions groupées, et elle a quitté
    // les pastilles des blocs de paie le même jour. Le détail le dit ici, à
    // l'endroit où on clique.
    { cle: "dsn", titre: "DSN", court: "DSN",
      detail: "tout le mois d'un coup — une DSN ne se découpe pas",
      bouton: dsn ? "Déposer la DSN…" : "Fermer le mois…",
      fichier: dsn, toujours: true,
      // Rien d'écrit : la boîte ferme le mois (bulletins, certificats, DSN),
      // puis enchaîne sur le dépôt, en test d'abord. Un seul geste.
      ouvrir: () => dsn ? boiteDepot("dsn", dsn.chemin)
                        : boiteProduire(mois, async () => {
                            const e2 = await api("etat-du-mois", { mois });
                            const d2 = (e2.fichiers.dsn || [])[0];
                            if (d2) await boiteDepot("dsn", d2.chemin, { testerDabord: true });
                          }) },
    { cle: "documents", titre: "Documents aux salariés", court: "DOCUMENTS",
      detail: "bulletin, certificat Congés Spectacles, AER",
      bouton: "Envoyer les documents…", toujours: true,
      ouvrir: () => boiteEnvoi(mois) },
  ];

  // UNE LIGNE PAR ACTE, ET LA COULEUR EN UN COUP D'OEIL. La demande, le
  // 13/09/2026 : « un truc court que je vois en un coup d'œil, et si je
  // clique j'ai le reste avec les détails et le bouton » — puis, devant le
  // résultat : « c'est ça ». Quand l'acte est fini (vert), la boîte est
  // repliée sur sa phrase courte ; sinon elle est ouverte, avec le fil des
  // envois et le bouton. Le chevron rouvre toujours.
  /* LES ÉTAPES DU MOIS (23/09/2026). Un parcours, pas quatre boîtes : DPAE,
     contrats, DSN, documents, numérotées et reliées. Une étape faite tient en
     une ligne cochée ; seule L'ÉTAPE SUIVANTE — la première qui n'est pas
     faite — est dépliée, avec son bouton en principal. Les autres se
     déplient d'un clic. Le fil des envois (tests compris) se replie sous
     « voir les envois » : c'est un historique, pas un état. */
  const limite = await limiteDsn(mois);
  const lignes = actes.map((a) => {
    const bilan = (e.bilans && e.bilans[a.cle]) || null;
    const couleur = bilan ? bilan.couleur : couleurActe(e.actes[a.cle]);
    const phrase = bilan ? bilan.phrase : e.resumes[a.cle];
    cheminDuDepot(a, bilan);
    // L'ANNULE-ET-REMPLACE (30/09/2026). Une DSN réelle est partie : tant que
    // la norme l'admet (veille de l'échéance, minuit), la refaire reste à
    // portée de main — et c'est LE geste quand la paie a changé depuis. Après,
    // la correction passe par la DSN suivante (« Corriger ce mois »).
    const r = a.cle === "dsn" && bilan && bilan.remplacement;
    if (r && r.deposee) {
      const refaire = () => boiteProduire(mois, async () => {
        const e2 = await api("etat-du-mois", { mois });
        const d2 = (e2.fichiers.dsn || [])[0];
        if (d2) await boiteDepot("dsn", d2.chemin, { testerDabord: true });
      });
      const libelle = `Refaire la DSN (annule-et-remplace, ordre ${r.prochain_ordre})…`;
      if (bilan.etape) {
        // Un annule-et-remplace est déjà écrit : son chemin passe devant.
      } else if (r.a_envoyer) {
        a.bouton = libelle; a.ouvrir = refaire;
      } else if (r.saisie_modifiee && !r.admis) {
        a.bouton = "Corriger ce mois…"; a.ouvrir = () => boiteCorriger(mois);
      } else if (r.admis) {
        a.second = { bouton: libelle, ouvrir: refaire };
      }
    }
    return { a, couleur, phrase, fini: couleur === "bien", vide: !!(bilan && bilan.vide),
             // EN ATTENTE : il reste un retour ou une signature, rien que
             // nous puissions faire — l'étape ne passe pas devant la suivante.
             attente: !!(bilan && bilan.attente),
             courte: phraseCourte(a.cle, couleur, phrase, bilan && bilan.courte) };
  });
  const suivante = lignes.findIndex((l) => !l.fini && !l.attente);
  const NOMS = { "dpae": "DPAE", "contrat-signature": "Contrats",
                 "dsn": "DSN", "documents": "Documents" };
  cible.innerHTML = `<ol class="etapes">` + lignes.map((l, i) => {
    const a = l.a, dispo = a.toujours || !!a.fichier;
    const envois = derniersEnvois(e, a.cle);
    const nEnvois = envoisVisibles(e, a.cle).length;
    const echeance = a.cle === "dsn" && limite && !l.fini
      ? ` <span class="etape-limite">avant le ${echapper(limite)}</span>` : "";
    return `
      <li class="etape ${echapper(l.couleur)} ${l.fini ? "faite" : ""} ${i === suivante ? "suivante" : ""}">
        <details ${i === suivante ? "open" : ""}>
          <summary>
            <span class="etape-rond">${l.fini ? "✓" : i + 1}</span>
            <span class="etape-nom">${echapper(NOMS[a.cle] || a.titre)}</span>
            <span class="etape-court">${echapper(l.courte)}</span>${echeance}
          </summary>
          <div class="etape-corps">
            <div class="etape-phrase">${echapper(l.phrase)}</div>
            <div class="discret etape-detail">${echapper(a.detail)}</div>
            ${a.fichier ? `<div class="acte-fichier">${echapper(a.fichier.nom)}
               <span class="discret">écrit le ${echapper(quand(a.fichier.ecrit))}</span></div>` : ""}
            ${l.vide ? "" : `<button class="${i === suivante ? "primaire" : "secondaire"}" data-acte="${echapper(a.cle)}"
                    ${dispo ? "" : "disabled"}>${echapper(a.bouton)}</button>`}
            ${a.second ? `<button class="secondaire" data-second="${echapper(a.cle)}">${echapper(a.second.bouton)}</button>` : ""}
            ${dispo ? "" : `<p class="note">${echapper(a.absent)}</p>`}
            ${nEnvois ? `<details class="etape-envois"><summary>voir les envois (${nEnvois})</summary>${envois}</details>` : ""}
          </div>
        </details>
      </li>`;
  }).join("") + `</ol>`;

  cible.querySelectorAll("[data-acte]").forEach((b) => {
    b.onclick = () => actes.find((a) => a.cle === b.dataset.acte).ouvrir();
  });
  cible.querySelectorAll("[data-second]").forEach((b) => {
    b.onclick = () => actes.find((a) => a.cle === b.dataset.second).second.ouvrir();
  });
}

/* Ce qu'il faut relire après avoir déposé ou envoyé : l'état du mois affiché,
 * et la liste des embauches, qu'un dépôt de DPAE vient de raccourcir. */
async function rafraichirActions() {
  const mois = document.getElementById("mois").value;
  await dessinerActions(mois);
  await dessinerEmbauches(mois);
  await dessinerEtatsDesPaies(mois);
  await dessinerReprise();
}

/* La reprise ne depend pas du mois : elle balaie tout ce qui est archive. Elle
 * se dessine donc une fois a l'ouverture, et se refait apres un depot -- qui
 * vient justement d'ecrire une ligne, et donc de raccourcir ce qu'il reste a
 * reprendre. */

/* ---------------------------------------- le récapitulatif d'un dépôt */

/** CE QUE LA DSN DÉCLARE, contrat par contrat, LU DANS LE FICHIER
 *  (30/09/2026, l'éditeur : « ce que l'utilisateur veut voir et vérifier,
 *  c'est que tous les contrats sont dans la DSN »). Comparé aux contrats
 *  saisis du mois : un contrat absent du fichier, ou que la paie dit
 *  autrement, se dit en tête. */
function recapitulatifDsn(r) {
  if (!r) return "";
  if (r.erreur) return `<div class="encart attention"><b>Récapitulatif illisible</b>
    ${echapper(r.erreur)}</div>`;
  const nb = (x) => (x && x !== "0") ? x : "—";
  const ecarts = r.salaries.reduce((n, s) => n + s.contrats.filter((c) => c.ecarts.length).length, 0);
  const lignes = r.salaries.map((s) => s.contrats.map((c, i) => `
    <tr class="${c.ecarts.length ? "ecart" : ""}">
      <td>${i === 0 ? `<b>${echapper(s.nom)}</b> ${echapper(s.prenoms)}` : ""}</td>
      <td>${echapper(c.numero)}</td>
      <td>${echapper(jjmmaaaa(c.debut))}${c.fin && c.fin !== c.debut ? " → " + echapper(jjmmaaaa(c.fin)) : ""}</td>
      <td>${echapper(c.emploi)}</td>
      <td class="num">${nb(c.cachets)}</td>
      <td class="num">${nb(c.heures)}</td>
      <td class="num">${nb(c.jours)}</td>
      <td class="num">${c.remunere ? echapper(euros(c.brut)) : "—"}</td>
      <td>${c.fin_declaree ? "fin le " + echapper(jjmmaaaa(c.fin_declaree)) : "en cours"}</td>
    </tr>
    ${c.ecarts.length ? `<tr class="ecart"><td></td><td colspan="8">
      <span class="pastille alerte">${echapper(c.ecarts.join(" ; "))}</span></td></tr>` : ""}`).join("")).join("");
  return `
    <div class="encart ${r.conforme ? "bien" : r.compare ? "attention" : ""}">
      <b>${r.contrats} contrat${r.contrats > 1 ? "s" : ""} dans ce fichier${r.compare
        ? `, ${r.contrats_saisis} saisi${r.contrats_saisis > 1 ? "s" : ""} dans la paie du mois` : ""}</b>
      ${r.conforme ? "Tous les contrats de la paie sont dans la DSN, tels que la paie les dit."
        : r.compare ? `${r.absents.length ? r.absents.length + " contrat(s) de la paie manquent au fichier. " : ""}${ecarts
          ? ecarts + " contrat(s) du fichier ne disent pas ce que dit la paie : réécrire le mois." : ""}`
        : "Pas de paie saisie à comparer : le fichier se lit seul."}
    </div>
    ${r.absents.length ? `<ul class="absents">${r.absents.map((x) =>
      `<li><span class="pastille alerte">absent du fichier</span> ${echapper(x.nom)} — contrat
       ${echapper(x.numero)}, du ${echapper(jjmmaaaa(x.debut))}</li>`).join("")}</ul>` : ""}
    <table class="recap-dsn">
      <tr><th>Salarié</th><th>Contrat</th><th>Dates</th><th>Emploi</th>
        <th>Cachets</th><th>Heures</th><th>Jours</th><th>Brut</th><th>Fin</th></tr>
      ${lignes}
    </table>`;
}

function corpsDsn(a) {
  const v = a.versements || [];
  return `
    <p class="discret">${echapper(a.nom)} — ${echapper(a.libelle_type)}
      (type ${echapper(a.type_declaration)}), ordre ${echapper(a.ordre)},
      fraction ${echapper(a.fraction)}, constituée le ${echapper(a.constitution)}.
      ${a.salaries} salarié(s), ${a.lignes} lignes, SIREN ${echapper(a.siren)}.</p>
    ${a.remplace ? `<div class="encart"><b>Annule et remplace</b>
      Ce fichier remplace la déclaration ${echapper(a.remplace)}.</div>` : ""}
    ${a.remplacement?.fichier_remplace ? `<div class="encart attention">
      <b>Annule-et-remplace intégral — ordre ${echapper(a.ordre)}</b>
      Il remplace la DSN réelle déjà partie pour ce mois (ordre
      ${echapper(a.remplacement.dernier_ordre)}), ordres de télépaiement
      compris : c'est lui qui vaudra. Admis jusqu'au
      ${echapper(jjmmaaaa(a.remplacement.limite))} à minuit.</div>` : ""}
    ${a.pas_bareme ? `<div class="encart attention">
      <b>Prélèvement à la source : ${a.pas_bareme} versement(s) sur
      ${a.pas_versements} partent sur la grille par défaut</b>
      Faute de taux transmis par la DGFiP, c'est la grille de l'article 204 H
      du CGI qui s'applique — c'est ce que la loi prévoit, et le dépôt n'est
      pas bloqué. Mais elle prélève le plus souvent <b>plus</b> que le taux
      réel du salarié, qui ne récupère la différence qu'à sa déclaration de
      revenus l'année suivante. Relever les retours avant de déposer peut
      encore changer cela.</div>` : ""}
    ${recapitulatifDsn(a.recapitulatif)}
    <details class="replie">
      <summary>Ordres de télépaiement (${v.length}) — la conséquence de ce que
        la DSN déclare ; un dépôt réel les déclenche tous</summary>
      <div class="encart ${enDemonstration() ? "info" : "attention"}">
      ${v.length
        ? `<ul class="versements">${v.map((x) =>
             `<li class="num">${echapper(euros(x))}</li>`).join("")}</ul>
           L'organisme prélèvera ces montants. Ce ne sont pas des indications.`
        : "Aucun ordre de télépaiement dans ce fichier."}
      </div>
    </details>`;
}

/* LE MOT DE PASSE DU LOGICIEL : UN POPUP, TOUJOURS LE MÊME (17/09/2026).
   Chaque acte qui engage — dépôt réel, envoi, signature, écrire dans le
   coffre — passe par ici : on clique le bouton de l'acte, le popup demande
   le mot de passe, Entrée, et l'acte part. Plus de champ posé dans chaque
   écran (l'éditeur : « la logique c'est un popup, toujours, où je tape le
   mot de passe, pas des champs cachés »). Le popup vit dans index.html
   (`#voile-mdp`), au-dessus de la boîte courante, et rend une promesse :
   le mot de passe, ou null si on annule (Échap, Annuler, clic à côté).

   PLUS RIEN POUR CHROME. Le 15/09 on avait tout fait pour que Chrome garde
   le mot de passe (utilisateur figé, autocomplete, `memoriserMotDePasse`) ;
   la page vit dans la fenêtre unique, et vivra dans Tauri : « il n'y a plus
   Chrome, et il n'y aura pas Chrome ». Le mot de passe se tape, à chaque
   fois, et c'est le but. */
function demanderMotDePasse(pourquoi) {
  // LA DÉMONSTRATION (moteur/simulation.py) : rien ne part, rien à prouver.
  // L'acte suit son cours comme en vrai, sans le popup.
  if (enDemonstration()) return Promise.resolve("demonstration");
  return new Promise((resoudre) => {
    const voile = document.getElementById("voile-mdp");
    const forme = document.getElementById("forme-mdp");
    const champ = document.getElementById("mdp-valeur");
    document.getElementById("mdp-pourquoi").textContent = pourquoi ? "Pour " + pourquoi + "." : "";
    champ.value = "";
    voile.classList.remove("cachee");
    const finir = (valeur) => {
      voile.classList.add("cachee");
      forme.onsubmit = voile.onclick = champ.onkeydown = null;
      document.getElementById("mdp-annuler").onclick = null;
      resoudre(valeur);
    };
    forme.onsubmit = (e) => {
      e.preventDefault();
      if (!champ.value) { champ.focus(); return; }
      finir(champ.value);
    };
    document.getElementById("mdp-annuler").onclick = () => finir(null);
    voile.onclick = (e) => { if (e.target === voile) finir(null); };
    champ.onkeydown = (e) => { if (e.key === "Escape") finir(null); };
    setTimeout(() => champ.focus(), 30);
  });
}

/** Avant ce jour, la DPAE est plus tôt que ne le dit le texte (R1221-4 : au
 *  plus tôt huit jours avant l'embauche). L'Urssaf l'enregistre quand même
 *  (test du 02/10/2026) : on prévient, on ne bloque pas. */
function dpaeTropTot(a) {
  const ici = new Date(Date.now() - new Date().getTimezoneOffset() * 60000);
  return !!(a && a.pas_avant && a.pas_avant > ici.toISOString().slice(0, 10));
}

function corpsDpae(a) {
  const deja = (a.embauches || []).filter((x) => x.deja_declaree).length;
  return `
    ${dpaeTropTot(a) ? `<div class="encart attention"><b>Plus de huit jours avant
      l'embauche</b> Le code du travail dit « au plus tôt dans les huit jours
      précédant l'embauche » (art. R1221-4) : à la lettre, à partir du
      ${echapper(jjmmaaaa(a.pas_avant))}. L'Urssaf l'enregistre quand même —
      elle ne contrôle pas ce délai.</div>` : ""}
    <p class="discret">${echapper(a.nom)} — ${a.enregistrements}
      enregistrement(s), ${a.octets} octets, indicateur
      ${echapper(a.indicateur)}.</p>
    <table>
      <tr><th>Salarié</th><th>Contrat</th><th>Du</th><th>Au</th>
        <th>Trace d'envoi</th></tr>
      ${(a.embauches || []).map((x) => `
        <tr>
          <td>${echapper(x.nom)}</td>
          <td>${echapper(x.type_contrat || "")}</td>
          <td>${echapper(jjmmaaaa(x.debut))}</td>
          <td>${x.fin ? echapper(jjmmaaaa(x.fin))
                      : `<span class="discret">sans terme</span>`}</td>
          <td>${x.deja_declaree
                ? `<span class="pastille alerte">déjà déclarée</span>`
                : `<span class="pastille bien">à déclarer</span>`}</td>
        </tr>`).join("")}
    </table>
    ${deja ? `<div class="encart attention">
      <b>${deja} embauche(s) de ce fichier ont déjà une trace d'envoi</b>
      Le fichier porte TOUT le mois : le déposer les redéclare. Déclarer deux
      fois la même embauche n'est pas anodin — l'Urssaf reçoit deux
      déclarations pour un seul contrat.</div>` : ""}`;
}

async function boiteDepot(quoi, fichier, { testerDabord = false } = {}) {
  let a;
  try {
    a = await api("depot-apercu", { quoi, fichier });
  } catch (e) { dire(e.message, "erreur"); return; }

  ouvrirBoite(`
    <h3>Déposer ${quoi === "dsn" ? "la DSN" : "la DPAE"}</h3>
    ${moisEnGros(a.mois)}
    ${quoi === "dsn" ? corpsDsn(a) : corpsDpae(a)}
    ${a.deja_depose ? `<div class="encart attention">
      <b>Ce fichier a déjà été déposé</b>
      Le ${echapper(quand(a.deja_depose.quand))}, en mode
      ${echapper(a.deja_depose.mode)}. Redéposer le même fichier ne remplace
      rien : un annule-et-remplace se produit, il ne se redépose pas.</div>` : ""}
    <div id="d-bilan">${encartRepetition(a.repetition, quoi, a)}</div>
    ${enDemonstration() ? noteDemonstration(quoi === "dsn" ? "net-entreprises" : "l'Urssaf")
      : `<p class="note">Un dépôt réel demande le mot de passe <b>du logiciel</b>,
      qui ne sert qu'à prouver que quelqu'un est là. Celui de l'organisme ne
      passe pas par cette page : le moteur va le chercher au coffre.</p>`}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="d-test">Envoyer le test</button>
      <button class="secondaire" id="d-reel" disabled>
        Envoyer le réel — ${echapper(a.mois)}</button>
    </div>
    ${a.reel ? `<p class="discret"><button type="button" class="lien" id="d-sans-test">envoyer
      en réel sans attendre le test…</button></p>` : ""}
    ${a.reel ? "" : `<p class="note">Le fichier est codé <b>envoi de test</b> :
      déposé « pour de vrai », il ne déclarerait rien et rien ne serait
      conservé. Reproduire le mois sans l'option d'envoi de test pour pouvoir
      déclarer.</p>`}`);

  // Le mot de passe tapé pour le dépôt sert au renvoi (boiteRenvoiDsn) :
  // on ne le redemande pas. Une erreur l'oublie, un refus aussi.
  let mdpConnu = null;
  const lancer = async (reel, forcer = false, contournement = "") => {
    let mdp = "";
    if (reel) {
      mdp = mdpConnu || await demanderMotDePasse("le dépôt réel de " + (quoi === "dsn" ? "la DSN" : "la DPAE"));
      if (!mdp) return;
      mdpConnu = mdp;
    }
    document.getElementById("d-test").disabled = true;
    document.getElementById("d-reel").disabled = true;
    const rendre = occupe(document.getElementById(reel ? "d-reel" : "d-test"),
                          reel ? "Dépôt réel en cours…" : "Envoi du test en cours…");
    try {
      const r = await api("deposer", { quoi, fichier, reel, motdepasse: mdp,
                                       forcer, contournement });
      rendre();
      afficherDepot(r, a);
      if (!reel) {
        // LE TEST NE FERME PLUS LA BOÎTE (25/09/2026) : « ça a quitté la
        // fenêtre au lieu de rester et d'attendre les retours pour proposer
        // d'envoyer direct ». On reste, on attend le compte rendu, et le
        // bouton du réel s'allume ici même.
        dire("Dépôt de test envoyé — on attend son compte rendu.");
        attendreBilan();
        rafraichirActions();
        return;
      }
      fermerBoite();
      dire("Dépôt réel effectué — on relève ses retours.");
      if (quoi === "dsn") avisDocumentsApresDsn(r.mois);
      await rafraichirActions();
      suivreDepot(quoi, r.flux, r.mois);
    } catch (e) {
      rendre();
      const test = document.getElementById("d-test"), reelB = document.getElementById("d-reel");
      if (test) test.disabled = false;
      if (reelB) reelB.disabled = !a.reel;
      if (e.detail?.type === "RepetitionManquante") {
        // « Aucun acte irréversible sans une répétition réussie du même
        // contenu. » On ne renvoie pas l'utilisateur chercher une commande :
        // le dépôt de test est un bouton, ici, tout de suite.
        return boiteRepetition(e.detail.etat, quoi,
                               () => lancer(false),
                               (motif) => lancer(true, false, motif));
      }
      if (e.detail?.type === "DsnDejaDeposee") {
        // « On attend le retour, et si vraiment on y tient, après un
        // avertissement, on peut renvoyer ». Le mot de
        // passe déjà tapé sert au renvoi : on ne le redemande pas.
        return boiteRenvoiDsn(e.detail.etat, () => lancer(true, true));
      }
      mdpConnu = null;
      dire(e.message, "erreur");
    }
  };
  // LE COMPTE RENDU DU TEST, ATTENDU DANS LA BOÎTE. Toutes les dix secondes,
  // cinq minutes au plus : il arrive le plus souvent dans la minute. Le réel
  // reste éteint tant qu'on attend ; conforme, il devient LE bouton ; refusé,
  // on dit pourquoi et il reste éteint. Passé cinq minutes, le point de dépôt
  // a accepté le test : le réel s'ouvre, en le disant.
  const zone = () => document.getElementById("d-bilan");
  const boutonReel = (principal) => {
    const b = document.getElementById("d-reel"), t = document.getElementById("d-test");
    if (!b) return;
    b.disabled = !a.reel || !principal;
    b.className = principal ? "primaire" : "secondaire";
    if (t) t.className = principal ? "secondaire" : "primaire";
    if (principal && a.reel) b.focus();
    const sansTest = document.getElementById("d-sans-test");
    if (sansTest && principal) sansTest.hidden = true;
  };
  // La boîte peut se fermer pendant l'attente : l'écoute continue, et le dit
  // en bas de page quand le compte rendu arrive (« après un test aussi »).
  // `el` est CETTE boîte : une autre ouverte entre-temps n'est pas touchée.
  const attendreBilan = async () => {
    const el = zone();
    const ici = () => el && el.isConnected;
    const ecrire = (html) => { if (ici()) el.innerHTML = html; };
    const test = document.getElementById("d-test");
    boutonReel(false);
    if (test) test.disabled = true;
    const libre = () => { if (ici() && test) test.disabled = false; };
    const nom = quoi === "dsn" ? "La DSN" : "La DPAE";
    for (let tour = 0; tour < 30; tour++) {
      let r = null;
      try { r = await api("bilan-repetition", { quoi, fichier }); } catch (e) { /* on réessaie */ }
      if (r && r.conforme && r.compte_rendu === "ok") {
        ecrire(encartRepetition(r, quoi, a));
        libre();
        if (ici()) boutonReel(true);
        else dire(`${nom} est testée — conforme. Le dépôt réel est prêt.`);
        rafraichirActions();
        return;
      }
      if (r && !r.conforme && (r.ratees || []).length) {
        const l = r.ratees[r.ratees.length - 1];
        const anos = (l.retours || []).flatMap((x) => x.anomalies || []);
        const motif = anos.join(" ; ") || l.reponse || "motif non lu";
        ecrire(`<div class="encart attention"><b>Le test est refusé</b>
          ${echapper(motif)}
          Le même refus attendrait le dépôt réel : c'est cela qu'il faut corriger.</div>`);
        libre();
        if (!ici()) dire(`Le test de ${nom.toLowerCase()} est refusé : ${motif}`, "erreur");
        rafraichirActions();
        return;
      }
      ecrire((r && r.conforme ? encartRepetition(r, quoi, a)
        : `<div class="encart"><b>Test envoyé — on attend son compte rendu, il
            arrive bientôt</b> Restez sur cette fenêtre : le dépôt réel s'ouvrira ici.</div>`)
        + (r && r.incident ? `<p class="discret">${echapper(r.incident)}</p>` : ""));
      await new Promise((ok) => setTimeout(ok, enDemonstration() ? 3000 : 10000));
    }
    ecrire(`<div class="encart attention"><b>Le compte rendu n'est
      pas arrivé en cinq minutes</b> Le point de dépôt a accepté le test : le
      dépôt réel est ouvert. Le compte rendu se rangera au prochain relevé.</div>`);
    libre();
    if (ici()) boutonReel(true);
  };

  document.getElementById("d-test").onclick = () => lancer(false);
  document.getElementById("d-reel").onclick = () => lancer(true);
  // LE TEST D'ABORD, TOUJOURS (ticket #103, 02/10/2026 : « on propose d'abord
  // un test, on regarde si tout est ok et après on propose le réel »). Le
  // réel reste éteint tant que le test n'est pas revenu conforme. Passer
  // outre reste possible, mais c'est un petit lien, et le moteur demande
  // alors un motif écrit (RepetitionManquante → boiteRepetition).
  const sansTest = document.getElementById("d-sans-test");
  if (sansTest) sansTest.onclick = () => lancer(true);
  // Un test déjà fait pour ce contenu : s'il attend encore son compte rendu,
  // on l'attend ici ; s'il est arrivé, le réel est le bouton principal.
  const rep = a.repetition;
  if (rep && rep.conforme) {
    if (rep.compte_rendu === "ok") boutonReel(true);
    else attendreBilan();
  } else {
    // Pas de test pour ce contenu : c'est lui qui vient d'abord.
    document.getElementById("d-test").className = "primaire";
    document.getElementById("d-reel").className = "secondaire";
    // LE MOIS QU'ON VIENT DE FERMER PART EN TEST TOUT SEUL (29/09/2026) :
    // « on produit la DSN de test complète et on attend le retour du test,
    // ensuite on propose d'envoyer la DSN réelle ». Un test n'engage rien.
    if (testerDabord) lancer(false);
  }
}

/** APRÈS LA DSN RÉELLE, LES DOCUMENTS DES SALARIÉS (29/09/2026). France
 *  Travail édite l'AER à partir de la DSN : la DSN d'août 2026 a eu la
 *  sienne 2 h 50 après le dépôt, son annule-et-remplace 1 h 21 après (dates
 *  de publication des retours). On annonce donc quatre heures, et l'heure. */
function avisDocumentsApresDsn(mois) {
  const h = new Date(Date.now() + 4 * 3600 * 1000);
  const heure = h.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
  const demain = h.toDateString() !== new Date().toDateString() ? " demain" : "";
  ouvrirBoite(`
    <h3>DSN envoyée</h3>
    ${moisEnGros(mois)}
    <div class="encart info"><b>Les documents des salariés, dans quatre heures
      environ</b> France Travail édite l'attestation employeur (AER) à partir
      de la DSN, en général dans les trois heures. Vers ${echapper(heure)}${demain},
      bulletins, certificats Congés Spectacles et AER pourront partir ensemble :
      bouton « Envoyer les documents… » de l'étape 4.</div>
    <div class="actions">
      <button class="primaire" onclick="fermerBoite()">Compris</button>
    </div>`);
}

/** L'ÉCOUTE DES RETOURS, JUSTE APRÈS UN DÉPÔT RÉEL (25/09/2026 : « pour que
 *  ça devienne vert le plus vite possible »). Toutes les quinze secondes,
 *  dix minutes au plus, sans attendre la veille de vingt minutes ; l'écran
 *  se repeint dès que le dépôt est tranché. */
async function suivreDepot(quoi, flux, mois) {
  if (!flux) return;
  const nom = quoi === "dsn" ? "La DSN" : "La DPAE";
  for (let tour = 0; tour < 40; tour++) {
    await new Promise((ok) => setTimeout(ok, enDemonstration() ? 4000 : 15000));
    let r = null;
    try { r = await api("suivre-depot", { quoi, flux, mois }); } catch (e) { continue; }
    if (r && r.fini) {
      dire(r.passe ? `${nom} est passée — retour de l'organisme reçu.`
                   : `${nom} est refusée — voir le motif dans l'étape.`, r.passe ? "" : "erreur");
      await rafraichirActions();
      return;
    }
  }
}

/** Où en est la répétition de CE contenu — avant de proposer le dépôt réel.
 *  Un bouton qui refusera au clic est un bouton qui ment. */
/** Les embauches que porte une DPAE, nommées (ticket #105, 02/10/2026 :
 *  deux salariés partis dans un seul dépôt, et l'écran disait « Cette DPAE »
 *  au singulier, sans dire pour qui -- on a cru qu'une seule était partie). */
function embauchesDe(a) {
  const l = (a && a.embauches) || [];
  if (!l.length) return "";
  return ` (${l.length} embauche${l.length > 1 ? "s" : ""} : ${l.map((x) => x.nom).join(", ")})`;
}

/** Ce que le certificat de conformité (nature 41) dit de chaque personne. */
function certificatParPersonne(ligne) {
  const dpae = ((ligne && ligne.retours) || []).flatMap((x) => x.dpae || []);
  if (!dpae.length) return "";
  return `<ul class="liste-certificat">${dpae.map((x) => `
    <li>${echapper([x.nom, x.prenom].filter(Boolean).join(" "))} :
      ${x.enregistree ? `<span class="pastille bien">enregistrée${x.dossier
          ? ` — dossier ${echapper(x.dossier)}` : ""}</span>`
        : x.deja_existante ? `<span class="pastille">déjà existante</span>`
        : `<span class="pastille erreur">${echapper(x.libelle || x.code || "refusée")}</span>`}</li>`).join("")}</ul>`;
}

function encartRepetition(r, quoi, a) {
  if (!r) return "";
  const cette = (quoi === "dsn" ? "Cette DSN" : "Cette DPAE")
    + (quoi === "dsn" ? "" : echapper(embauchesDe(a)));
  // Les deux phrases de l'éditeur (25/09/2026) : « cette DPAE est déjà
  // testée, voulez-vous l'envoyer » — ou « elle est déjà envoyée en test,
  // on attend les retours, qui arrivent bientôt ».
  if (r.conforme && r.compte_rendu === "ok") {
    return `<div class="encart bien">
      <b>${cette} est testée — conforme. Voulez-vous l'envoyer ?</b>
      Testée le ${echapper(quand(r.conforme.quand))} : le même contenu est
      passé au bac à sable sans anomalie. Le dépôt réel est le bouton « Envoyer le réel ».
      ${certificatParPersonne(r.conforme)}</div>`;
  }
  if (r.conforme) {
    return `<div class="encart">
      <b>${cette} est en test — on attend son compte rendu, il arrive bientôt</b>
      Envoyée en test le ${echapper(quand(r.conforme.quand))}. Restez sur cette
      fenêtre : le dépôt réel s'ouvrira ici dès qu'il sera là.</div>`;
  }
  // Jamais essayé : ce n'est pas une mise en garde, c'est l'étape suivante
  // (26/09/2026 : l'orange se garde pour ce qui demande de corriger).
  const rate = (r.ratees || []).length || (r.perimees || []).length;
  return `<div class="encart ${rate ? "attention" : ""}">
    <b>${rate ? "Pas de test valable pour ce contenu" : "D'abord, le dépôt de test"}</b>
    ${echapper(situationRepetition(r))} Le dépôt réel s'ouvrira dès que le
    test sera revenu conforme.</div>`;
}

function situationRepetition(etat) {
  const ratees = etat.ratees || [], perimees = etat.perimees || [];
  if (ratees.length) {
    return `Ce contenu a été essayé en test le ${quand(ratees[ratees.length - 1].quand)}`
      + ` et l'essai a échoué : c'est cela qu'il faut corriger, le même refus attend en réel.`;
  }
  if (perimees.length) {
    return `Un fichier du même nom a bien été essayé le ${quand(perimees[perimees.length - 1].quand)},`
      + ` mais son contenu a changé depuis : un octet qui bouge rend le test caduc.`;
  }
  return "Ce contenu n'a jamais été déposé en test.";
}

/** Le verrou test → réel. Deux issues, et la première est la bonne : faire
 *  la répétition. La seconde existe parce que le service de test sera
 *  indisponible un 5 du mois à 23 h — et elle demande un motif écrit, qui
 *  part au journal des dépôts. */
function boiteRepetition(etat, quoi, repeter, quandMeme) {
  ouvrirBoite(`
    <h3>Ce contenu n'a pas été répété</h3>
    <div class="encart attention">
      <b>Aucun dépôt de test ne répond de ce fichier</b>
      ${echapper(situationRepetition(etat))}
    </div>
    <p class="note">Un dépôt de test exécute les mêmes contrôles et rend le
      même bilan, sans rien conserver et sans rien déclarer. C'est la seule
      façon de savoir qu'un dépôt réel passera — et une déclaration ne se
      rattrape pas, elle s'annule-et-remplace.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="r-tester">Faire le dépôt de test</button>
    </div>
    <p class="note" style="margin-top:18px"><a href="#" id="r-outre">Déposer
      sans répétition</a> — si le service de test est indisponible et que
      l'échéance ne peut pas attendre.</p>
    <div id="r-motif" class="cachee">
      <p class="note">Dire ce qui empêchait le test, en une phrase : c'est ce
        qu'on relira le jour où ce dépôt posera question. Le motif est inscrit
        au journal des dépôts.</p>
      <textarea id="r-raison" rows="2" placeholder="le service de test de net-entreprises répond 503 depuis ce matin"></textarea>
      <div class="actions">
        <button class="secondaire" id="r-quand-meme">Déposer sans répétition</button>
      </div>
    </div>`);
  document.getElementById("r-tester").onclick = () => { fermerBoite(); repeter(); };
  document.getElementById("r-outre").onclick = (e) => {
    e.preventDefault();
    document.getElementById("r-motif").classList.remove("cachee");
    document.getElementById("r-raison").focus();
  };
  document.getElementById("r-quand-meme").onclick = () => {
    const motif = document.getElementById("r-raison").value.trim();
    if (motif.length < 10) {
      dire("Le motif se lit en une phrase : dire ce qui empêchait le test.");
      return;
    }
    fermerBoite();
    quandMeme(motif);
  };
}

/** Une DSN réelle est déjà partie pour ce mois. Dire où elle en est, et ne
 *  renvoyer que si on le veut vraiment. */
function boiteRenvoiDsn(etat, renvoyer) {
  const quand = etat && etat.quand ? quand_(etat.quand) : "?";
  const situation = etat.passee
    ? `Le bilan de conformité est arrivé : <b>elle est passée</b>, il n'y a
       rien à faire de notre côté.`
    : `<b>Son retour n'est pas encore arrivé</b> : on attend, on ne renvoie pas.`;
  ouvrirBoite(`
    <h3>Une DSN est déjà partie pour ce mois</h3>
    <div class="encart attention">
      <b>Déposée le ${echapper(quand)}${etat.flux ? ` — flux ${echapper(etat.flux)}` : ""}</b>
      ${situation}
    </div>
    <p class="note">Renvoyer quand même fait un <b>annule-et-remplace</b> à
      net-entreprises : la nouvelle DSN remplace la précédente, avec ses ordres
      de télépaiement. À ne faire que si c'est voulu — une paie corrigée, par
      exemple — et jamais parce qu'on n'a pas encore vu le retour.</p>
    <div class="actions">
      <button class="primaire" onclick="fermerBoite()">Ne pas renvoyer</button>
      <button class="secondaire" id="d-renvoyer">Renvoyer quand même</button>
    </div>`);
  document.getElementById("d-renvoyer").onclick = () => { fermerBoite(); renvoyer(); };
}
const quand_ = (iso) => quand(iso);

/* La réponse de l'organisme, en entier et telle quelle. On n'en fait pas un
 * résumé : c'est la pièce, et c'est elle qu'on relira le jour où un retour
 * dira le contraire. */
function afficherDepot(r, a) {
  // CE QUE LE POINT DE DÉPÔT A DIT, EN CLAIR (ticket #105, 02/10/2026). Le
  // XML brut de l'accusé ne nomme que le DÉCLARANT -- celui qui dépose --,
  // et on l'a lu comme le seul salarié parti. On dit ce qui est parti, pour
  // qui ; le XML reste là, replié, pour qui veut le lire.
  const etat = /<envoi_etat>\s*([A-Z]+)/.exec(r.reponse || "");
  const qui = r.quoi === "dpae" && a && (a.embauches || []).length
    ? `<p>${a.embauches.length} embauche${a.embauches.length > 1 ? "s" : ""} dans ce dépôt :</p>
       <ul>${a.embauches.map((x) => `<li>${echapper(x.nom)} — embauche le
         ${echapper(jjmmaaaa(x.debut))}</li>`).join("")}</ul>` : "";
  document.getElementById("resultat").innerHTML = `
    <div class="carte" style="margin-top:20px">
      <h2>${echapper(r.quoi.toUpperCase())} ${echapper(r.mois || "")} —
        ${r.reel ? "dépôt réel" : "dépôt de test"}</h2>
      ${r.deja ? `<div class="encart attention"><b>Ce fichier avait déjà été
        déposé</b> Le ${echapper(quand(r.deja.quand))}.</div>` : ""}
      ${r.repetition?.contournement ? `<div class="encart attention">
        <b>Déposé sans répétition</b> Motif inscrit au journal des dépôts :
        ${echapper(r.repetition.contournement)}</div>` : ""}
      ${r.flux
        ? `<div class="encart bien"><b>Flux ${echapper(r.flux)}</b>
           C'est par ce numéro que les retours de l'organisme se rattacheront
           à ce dépôt.</div>`
        : `<div class="encart attention"><b>Pas d'identifiant de flux</b>
           La réponse n'en portait pas : les retours ne pourront pas se
           rattacher seuls à ce dépôt, et le diront.</div>`}
      ${etat ? `<p>Accusé de réception de l'organisme : <b>${etat[1] === "OK"
        ? "envoi reçu" : "envoi " + echapper(etat[1])}</b>. Le compte rendu de
        conformité suit, en général dans les dix minutes.</p>` : ""}
      ${qui}
      <details><summary class="discret">Réponse brute de l'organisme</summary>
        <pre class="reponse">${echapper(r.reponse || "")}</pre></details>
      ${r.trace ? `<p class="note">Réponse entière archivée dans
        ${echapper(r.trace)}</p>` : ""}
    </div>`;
}

/* ------------------------------------------ les documents aux salariés */
async function boiteEnvoi(mois) {
  let a;
  try {
    a = await api("envoi-apercu", { mois });
  } catch (e) { dire(e.message, "erreur"); return; }

  // LE MOTEUR DIT S'IL PEUT (documents_prets) : DSN déposée et passée, AER
  // revenue, documents écrits. Et une boîte courriel pour ENVOYER (le mot de
  // passe d'application dans Configuration > Mots de passe) — sans elle,
  // les documents se donnent à la main depuis le dossier du mois. Le compte
  // Google n'y est pour rien : il ne porte que le Drive (18/09/2026).
  const peut = a.pret && a.boite_liee;
  ouvrirBoite(`
    <h3>Envoyer les documents</h3>
    ${moisEnGros(mois)}
    ${a.boite_liee ? `<p class="discret">Depuis ${echapper(a.expediteur)}.</p>`
      : `<div class="encart"><b>Aucune boîte courriel</b>
         Posez le mot de passe d'application de la boîte de la compagnie
         (Configuration › Mots de passe) pour envoyer par courriel. En
         attendant, les documents s'ouvrent depuis le dossier du mois et se
         remettent à la main.</div>`}
    ${(a.empechements || []).map((x) =>
      `<div class="encart attention">${echapper(x)}</div>`).join("")}
    ${(a.avertissements || []).map((x) =>
      `<div class="encart info">${echapper(x)}</div>`).join("")}
    ${!a.produit ? "" : `<table>
      <tr><th>Salarié</th><th>Adresse</th><th>Pièces</th><th>Taille</th></tr>
      ${a.messages.map((m) => `
        <tr>
          <td>${echapper(m.nom)}</td>
          <td>${echapper(m.destinataire)}</td>
          <td>${echapper(m.pieces.join(", "))}</td>
          <td class="num">${Math.round(m.octets / 1024)} ko</td>
        </tr>`).join("")}
    </table>`}
    ${a.deja ? `<div class="encart attention"><b>Déjà envoyé</b>
      Le ${echapper(quand(a.deja.quand))} — ${echapper(a.deja.reponse || "")}.
      Renvoyer enverra une seconde fois.</div>` : ""}
    ${!peut ? "" : enDemonstration() ? noteDemonstration("les salariés", false)
      : `<p class="note">Un courriel n'engage pas l'employeur comme une
      déclaration — personne ne prélève rien — mais il part chez quelqu'un et
      ne revient pas. Le mot de passe du logiciel est demandé à l'envoi.</p>`}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      ${a.produit ? `<button class="secondaire" id="e-dossier">Ouvrir le dossier des documents</button>`
        : a.a_redecouper
          // LE MOIS EST PRODUIT, IL N'EST PAS DÉCOUPÉ. Proposer ici « écrire
          // le mois » serait proposer de reproduire une déclaration déjà
          // déposée : les numéros de contrat changeraient (règle 4 de
          // CLAUDE.md) et le mois est de toute façon hors délai. On propose
          // le redécoupage, qui lit les numéros dans le fichier archivé.
          ? `<button class="secondaire" id="e-pieces">Écrire les documents des salariés</button>`
          : `<button class="secondaire" id="e-ecrire">Écrire le mois…</button>`}
      <button class="primaire" id="e-envoyer" ${peut ? "" : "disabled"}
              title="${peut ? "" : echapper((a.empechements || []).concat(
                a.boite_liee ? [] : ["Aucune boîte courriel."]).join(" "))}">Envoyer à
        ${a.messages.length} salarié(s)</button>
    </div>`);

  const dossier = document.getElementById("e-dossier");
  if (dossier) dossier.onclick = () => ouvrirDossier(dossier, mois, "documents");
  const ecrire = document.getElementById("e-ecrire");
  if (ecrire) ecrire.onclick = () => boiteProduire(mois, () => boiteEnvoi(mois));
  const pieces = document.getElementById("e-pieces");
  if (pieces) pieces.onclick = async () => {
    pieces.disabled = true;
    try {
      const r = await api("ecrire-documents", { mois });
      // `dire` n'affiche qu'un message : les avertissements le suivent sur la
      // même ligne, sans quoi le dernier effacerait les autres.
      dire([r.fichiers.length + " pièce(s) écrite(s) — rien n'est parti."]
        .concat(r.avertissements || []).join("  ·  "));
      await boiteEnvoi(mois);
    } catch (e) {
      pieces.disabled = false;
      dire(e.message, "erreur");
    }
  };
  document.getElementById("e-envoyer").onclick = async () => {
    const mdp = await demanderMotDePasse("envoyer les documents à " + a.messages.length + " salarié(s)");
    if (!mdp) return;
    const rendre = occupe(document.getElementById("e-envoyer"),
                          "Envoi des documents en cours…");
    const repere = await repereCourrielsDemo();
    try {
      const r = await api("envoyer-documents", { mois, motdepasse: mdp });
      fermerBoite();
      dire(r.partis.length + " message(s) envoyé(s).");
      afficherEnvoi("Documents aux salariés", mois, r.partis, r.avertissements);
      fenetreCourrielsDemo("documents", repere);
      await rafraichirActions();
    } catch (e) {
      rendre();
      dire(e.message, "erreur");
    }
  };
}

/* --------------------------------------------- les contrats à faire signer */

/** « signé par courriel le … » ou « signé, reçu le … » : le journal sait
 *  d'où vient la mention (contrats_recus_comment), l'écran ne fait que
 *  l'écrire. */
function signeLe(quandRecu, par) {
  return (par === "courriel" ? "signé d'un clic le " : "signé, reçu le ") + quand(quandRecu);
}

async function boiteSignature(mois, seulement) {
  let a;
  try {
    a = await api("signature-apercu", { mois });
  } catch (e) { dire(e.message, "erreur"); return; }

  // Cochés d'avance : ceux dont aucune demande n'est partie. Redemander une
  // signature déjà demandée se fait — on relance quelqu'un — mais ça se
  // décide, ça ne se coche pas tout seul.
  //
  // `seulement` : la sélection venue des cases de la colonne de gauche. Elle
  // REMPLACE la règle du dessus — quelqu'un qui a coché trois paies a déjà
  // choisi, et lui recocher les autres serait défaire son geste. La liste
  // reste entière : on voit ce qu'on n'a pas pris, et on peut le reprendre.
  // Coché d'office : ce qui n'est ni demandé ni revenu signé. Un contrat
  // reçu ne repart pas, même dans une sélection.
  // Un contrat caduc (la paie a changé depuis son envoi) se recoche d'office :
  // celui qui est parti n'est plus le bon.
  // Un contrat SIGNÉ qui a changé ne repart pas en entier : il part en
  // AVENANT (30/09/2026, « sinon il peut réclamer tous les contrats »),
  // coché d'avance comme le reste de ce qui est à faire.
  const avenantAFaire = (c) => c.caduc && c.recu_le;
  const choisi = (c) => (seulement ? seulement.includes(c.salarie)
                                   : c.caduc || (!c.recu_le && !c.demande_le))
                        && (c.caduc || !c.recu_le);
  a.contrats.sort((x, y) => (y.caduc && y.recu_le ? 1 : 0) - (x.caduc && x.recu_le ? 1 : 0));
  ouvrirBoite(`
    <h3>Demander la signature des contrats</h3>
    ${moisEnGros(mois)}
    <div class="encart">
      <b>Signature d'un clic</b>
      Le contrat part par courriel avec un bouton « Je signe ». Le salarié
      appuie dessus, sa messagerie s'ouvre sur une réponse toute écrite avec
      un code unique, il l'envoie. Rien à faire ensuite : la réponse est
      relevée toute seule, à l'ouverture et avec la sauvegarde régulière —
      la signature passe au journal, le message est gardé comme preuve, et
      le salarié reçoit son contrat contresigné.${a.attendues ? ` <b>${a.attendues}
      réponse${a.attendues > 1 ? "s" : ""} attendue${a.attendues > 1 ? "s" : ""}.</b>` : ""}
      Un contrat signé à la main se note toujours d'un clic sur sa pastille.
    </div>
    ${enDemonstration() ? noteDemonstration("les salariés").replace("sa réponse arrive comme la vraie",
      "la signature revient comme la vraie") : ""}
    ${noteDpaeAvance()}
    <div class="liste-choix">
      ${a.contrats.map((c) => `
        <label class="choix">
          <input type="checkbox" class="s-qui" value="${echapper(c.salarie)}"
                 data-debut="${echapper(c.debut)}" data-numero="${echapper(c.numero || "")}" ${avenantAFaire(c) ? 'data-avenant="1"' : ""}
                 ${choisi(c) ? "checked" : ""}>
          <span><b>${echapper(c.nom)}</b> — ${echapper(c.spectacle)}, du
            ${echapper(jjmmaaaa(c.debut))} au ${echapper(jjmmaaaa(c.fin))}
            ${c.numero ? `<span class="discret">(contrat n° ${echapper(c.numero)})</span>` : ""}
            <br><span class="discret">${echapper(c.destinataire)
              || "aucun courriel dans la fiche — l'envoi sera refusé"}</span>
            ${c.caduc && c.recu_le ? `<br><span class="pastille alerte">${echapper(c.pourquoi
              || "la paie a changé depuis la signature")} — signé : partira en avenant</span>
              <button class="lien s-avenant" data-salarie="${echapper(c.salarie)}"
                data-debut="${echapper(c.debut)}" data-numero="${echapper(c.numero || "")}">voir l'avenant</button>`
              : c.avenant_attendu ? `<br><span class="pastille alerte">avenant n° ${echapper(String(c.avenant.numero))}
              envoyé le ${echapper(quand(c.avenant.quand))} — pas encore revenu signé</span>`
              : c.caduc ? `<br><span class="pastille alerte">${echapper(c.pourquoi
              || "la paie a changé depuis l'envoi")}${c.demande_le ? ` (envoyé le ${echapper(quand(c.demande_le))})` : ""} —
              ce contrat est à renvoyer</span>`
              : c.recu_le ? `<br><span class="pastille bien">${echapper(signeLe(c.recu_le, c.recu_par))}</span>`
              : c.demande_le ? `<br><span class="pastille alerte">demandé le
              ${echapper(quand(c.demande_le))} — pas encore revenu</span>
              ${a.boite_liee ? `<button class="secondaire petit s-relancer"
                data-salarie="${echapper(c.salarie)}" data-debut="${echapper(c.debut)}"
                data-numero="${echapper(c.numero || "")}"
                title="Renvoie le même contrat, avec un mot de rappel">Relancer</button>` : ""}` : ""}</span>
        </label>`).join("")}
    </div>
    ${a.boite_liee ? "" : `<div class="encart"><b>Aucune boîte courriel</b>
      Posez le mot de passe d'application de la boîte de la compagnie
      (Configuration › Mots de passe) pour envoyer les contrats par courriel.
      En attendant, ils s'ouvrent depuis le dossier du mois et se font signer
      à la main.</div>`}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      ${a.produit ? `<button class="secondaire" id="s-dossier">Ouvrir le dossier des contrats</button>`
                  : `<button class="secondaire" id="s-ecrire">Écrire le mois…</button>`}
      <button class="primaire" id="s-envoyer" ${a.boite_liee ? "" : "disabled"}
              title="${a.boite_liee ? "" : "Aucune boîte courriel."}">Envoyer à la signature</button>
    </div>`);

  const dossierS = document.getElementById("s-dossier");
  if (dossierS) dossierS.onclick = () => ouvrirDossier(dossierS, mois, "contrats");
  const ecrireS = document.getElementById("s-ecrire");
  if (ecrireS) ecrireS.onclick = () => boiteProduire(mois, () => boiteSignature(mois, seulement));
  // RELANCER (30/09/2026) : le MÊME contrat, redemandé parce que la
  // signature n'est pas revenue — distinct de « Envoyer », qui sert à un
  // contrat jamais parti ou changé depuis. Le journal le dit, et la
  // signature déjà donnée n'est jamais défaite par une relance.
  document.querySelectorAll(".s-avenant").forEach((b) => {
    b.onclick = (ev) => {
      ev.preventDefault();                 // le bouton est dans un <label>
      fermerBoite();
      boiteAvenant(mois, b.dataset.salarie, b.dataset.debut, b.dataset.numero);
    };
  });
  document.querySelectorAll(".s-relancer").forEach((b) => {
    b.onclick = async (ev) => {
      ev.preventDefault();                 // le bouton est dans un <label>
      const contrats = [{ salarie: b.dataset.salarie, debut: b.dataset.debut, numero: b.dataset.numero }];
      const mdp = await demanderMotDePasse("relancer la signature de ce contrat");
      if (!mdp) return;
      const rendre = occupe(b, "Relance…");
      try {
        const r = await api("demander-signature",
                            { mois, contrats, motdepasse: mdp, relance: true });
        fermerBoite();
        dire("Relance partie : " + r.partis.join(", ") + ".");
        await rafraichirActions();
      } catch (e) {
        rendre();
        dire(e.message, "erreur");
      }
    };
  });
  document.getElementById("s-envoyer").onclick = async () => {
    // Par CONTRAT : un salarié peut avoir un contrat coché et un autre non.
    const coches = [...document.querySelectorAll(".s-qui:checked")];
    // Les contrats signés qui ont changé partent en AVENANT, les autres en
    // contrat : un seul bouton, un seul mot de passe (30/09/2026).
    const avenants = coches.filter((c) => c.dataset.avenant)
      .map((c) => ({ salarie: c.value, debut: c.dataset.debut, numero: c.dataset.numero, mois }));
    // Le numéro distingue deux contrats du même salarié qui commencent le même jour (retours Windows, B).
    const contrats = coches.filter((c) => !c.dataset.avenant)
      .map((c) => ({ salarie: c.value, debut: c.dataset.debut, numero: c.dataset.numero }));
    if (!coches.length) { dire("Aucun contrat coché."); return; }
    const quoi = [contrats.length ? contrats.length + " contrat(s)" : "",
                  avenants.length ? avenants.length + " avenant(s)" : ""].filter(Boolean).join(" et ");
    const mdp = await demanderMotDePasse("envoyer " + quoi + " à la signature");
    if (!mdp) return;
    const rendre = occupe(document.getElementById("s-envoyer"), "Envoi de " + quoi + " en cours…");
    const repere = await repereCourrielsDemo();
    try {
      const r = contrats.length
        ? await api("demander-signature", { mois, contrats, motdepasse: mdp })
        : { partis: [], contrats: [] };
      // Les avenants d'un même salarié partent ensemble, dans un seul
      // courriel, comme ses contrats (30/09/2026).
      if (avenants.length) {
        const av = await api("avenants-envoyer", { avenants, motdepasse: mdp });
        r.partis.push(...av.partis);
        r.contrats.push(...av.avenants.map((a) => ({ fichier: a.fichier })));
      }
      fermerBoite();
      dire(quoi + " envoyé(s) à la signature.");
      afficherEnvoi("Contrats à signer", mois, [...new Set(r.partis)],
                    r.contrats.map((c) => c.fichier));
      if (enDemonstration()) {
        attendreSignaturesDemo();
        fenetreCourrielsDemo("signature", repere);
      }
      await rafraichirActions();
    } catch (e) {
      rendre();
      dire(e.message, "erreur");
    }
  };
}

/** L'AVENANT (30/09/2026). Le contrat parti se lit (son PDF), la paie
 *  d'aujourd'hui s'y compare, article par article : ce qui a changé se
 *  montre, l'ancien texte à côté du nouveau. L'avenant part à la signature
 *  par le même circuit « Je signe » que le contrat. Un contrat qui n'a pas
 *  commencé peut aussi être refait en entier (« annule et remplace »). */
async function boiteAvenant(mois, salarie, debut, numero) {
  let a;
  try {
    // Le numéro et le mois disent QUEL contrat, si le salarié en a deux qui commencent le même jour (retours Windows, B).
    a = await api("avenant-apercu", { salarie, debut, numero: numero || "", mois });
  } catch (e) { dire(e.message, "erreur"); return; }
  const mods = a.modifications || [];
  const cite = (textes) => textes.map((x) => `<p class="citation">« ${echapper(x)} »</p>`).join("");
  ouvrirBoite(`
    <h3>Avenant au contrat n° ${echapper(a.contrat || "")}</h3>
    <p class="discret">${echapper(a.nom)} — ${echapper(a.spectacle)}, du
      ${echapper(jjmmaaaa(a.debut))} au ${echapper(jjmmaaaa(a.fin))} ;
      ${a.signe ? "signé le " + echapper(quand(a.signe))
                : "envoyé le " + echapper(jjmmaaaa(a.date_contrat)) + ", pas encore signé"}</p>
    ${(a.avenants || []).map((x) => `<p class="discret">Avenant n° ${echapper(String(x.numero))}
      envoyé le ${echapper(quand(x.quand))} — ${x.signe ? "signé le " + echapper(quand(x.signe))
      : "pas encore revenu signé"}</p>`).join("")}
    ${mods.length ? `
      <div class="encart">Le contrat parti se compare à la paie d'aujourd'hui :
        ${mods.length > 1 ? mods.length + " articles ont changé" : "un article a changé"}.
        L'avenant n° ${a.numero} cite l'ancien texte et le nouveau ; le reste du
        contrat ne change pas.</div>
      ${mods.map((m) => `<div class="modif-avenant">
        <b>Article ${m.numero} — ${echapper(m.article)}</b>
        <div class="discret">Avant</div>${cite(m.avant)}
        <div class="discret">Désormais</div>${cite(m.apres)}
      </div>`).join("")}
      <label>Date d'effet de l'avenant
        <input type="date" id="av-effet" value="${echapper(a.effet)}"></label>`
    : `<div class="encart">Le contrat parti dit déjà tout ce que dit la paie :
        il n'y a rien à modifier.</div>`}
    ${mods.length && a.remplacable ? `<p class="discret">Le contrat n'a pas commencé : il peut aussi être
      refait en entier. Le nouveau porte en tête « annule et remplace le contrat
      n° ${echapper(a.contrat || "")} du ${echapper(jjmmaaaa(a.date_contrat))} ».</p>` : ""}
    <p class="discret"><a href="#" id="av-pieces">Voir ce qui est parti (contrat envoyé, signé, preuve)</a></p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      ${mods.length && a.remplacable ? `<button class="secondaire" id="av-remplace">Contrat qui annule et remplace…</button>` : ""}
      ${mods.length ? `<button class="primaire" id="av-envoyer">Envoyer l'avenant à la signature…</button>` : ""}
    </div>`);
  document.getElementById("av-pieces").onclick = (ev) => {
    ev.preventDefault();
    fermerBoite();
    boitePieces({ salarie, debut, numero, nom: a.nom, fin: a.fin, spectacle: a.spectacle,
                  etats: { signature: { fait: a.date_contrat, recu: a.signe } } }, "signature");
  };
  const envoyer = document.getElementById("av-envoyer");
  if (envoyer) envoyer.onclick = async () => {
    const effet = document.getElementById("av-effet").value || a.effet;
    const mdp = await demanderMotDePasse("envoyer l'avenant n° " + a.numero + " à " + a.nom);
    if (!mdp) return;
    const rendre = occupe(envoyer, "Envoi de l'avenant…");
    try {
      const r = await api("avenant-envoyer", { salarie, debut, numero: numero || "", mois, effet, motdepasse: mdp });
      fermerBoite();
      dire("Avenant n° " + r.numero + " envoyé à la signature : " + r.partis.join(", ") + ".");
      afficherEnvoi("Avenant à signer", a.mois, r.partis, [r.fichier]);
      await rafraichirActions();
    } catch (e) {
      rendre();
      dire(e.message, "erreur");
    }
  };
  const remplace = document.getElementById("av-remplace");
  if (remplace) remplace.onclick = async () => {
    const mdp = await demanderMotDePasse("envoyer le contrat qui annule et remplace le n° " + (a.contrat || ""));
    if (!mdp) return;
    const rendre = occupe(remplace, "Envoi du contrat…");
    try {
      const r = await api("demander-signature", { mois: a.mois, contrats: [{ salarie, debut, numero: numero || a.contrat || "" }],
                                                  motdepasse: mdp, remplace: true });
      fermerBoite();
      dire("Contrat qui annule et remplace le n° " + (a.contrat || "") + " envoyé : "
           + r.partis.join(", ") + ".");
      afficherEnvoi("Contrat à signer", a.mois, r.partis, r.contrats.map((c) => c.fichier));
      await rafraichirActions();
    } catch (e) {
      rendre();
      dire(e.message, "erreur");
    }
  };
}

/** LA DÉMONSTRATION : les salariés fictifs signent une vingtaine de secondes
 *  après l'envoi (moteur/simulation.py). La page relève à ce moment-là,
 *  comme la veille l'aurait fait à son passage. */
function attendreSignaturesDemo() {
  setTimeout(async () => {
    try { await api("veille-maintenant"); } catch (e) { return; }
    await rafraichirActions();
    dire("Démonstration : les contrats sont revenus signés.");
  }, 22000);
}

/* ---------------------------------------- LA DÉMONSTRATION QUI EXPLIQUE
   (27/09/2026, l'éditeur) : « il faut vraiment que ce soit une démo
   informative, qui nous renseigne aussi sur le fonctionnement de notre
   logiciel ». À chaque courriel joué, une petite fenêtre montre ce que le
   salarié reçoit — le vrai courriel, écrit par le moteur dans
   courriels-simules/ — et le circuit en trois bulles : ce qui part, ce que
   son clic prépare, ce qui revient. Rien n'y est inventé par la page : les
   messages sont ceux du moteur, la réponse est celle que le bouton du
   courriel prépare. */
async function repereCourrielsDemo() {
  if (!enDemonstration()) return null;
  try { return (await api("demonstration-courriels", { apres: "￿" })).dernier; }
  catch (e) { return null; }
}

const CIRCUITS_DEMO = {
  signature: {
    titre: "Ce que reçoit le salarié",
    bulles: ["Le contrat part", "Il appuie sur « Je signe »", "Le contrat signé lui revient"],
    notes: [
      "Un courriel par salarié, le contrat en pièce jointe et un bouton « Je signe ».",
      "Le bouton ouvre sa messagerie sur cette réponse toute écrite, avec son code unique : il n'a qu'à l'envoyer. Le logiciel la relève seul, à l'ouverture et avec la veille, et la garde comme preuve.",
      "Dès la signature relevée, le contrat contresigné part tout seul — le seul envoi sans clic du logiciel, puisque le clic est celui du salarié. La pastille du contrat passe au vert.",
    ],
    attente: "La signature du salarié fictif arrive une vingtaine de secondes après l'envoi.",
    retour: /signé/i,
  },
  fiche: {
    titre: "Ce que reçoit la personne",
    bulles: ["La demande part", "Elle appuie sur « Remplir ma fiche »", "Sa fiche se crée"],
    notes: [
      "Un courriel avec un bouton « Remplir ma fiche », et les questions recopiées dans le texte pour les messageries qui n'affichent pas le bouton.",
      "Le bouton ouvre sa messagerie sur les questions, une par ligne : elle écrit après chaque deux-points et envoie. Seul ce qu'elle sait lui est demandé — l'emploi reste à l'employeur.",
      "Sa réponse est relevée comme une signature : la fiche salarié se crée avec ce qu'elle a écrit, marquée « à compléter » pour l'emploi. Une réponse illisible laisse la case vide, et le dit.",
    ],
    attente: "La réponse de la personne fictive arrive une vingtaine de secondes après l'envoi.",
  },
  documents: {
    titre: "Ce que reçoit le salarié",
    bulles: ["Les documents partent"],
    notes: ["Un courriel par salarié, avec ses documents en pièces jointes. L'envoi est noté au journal, et un second envoi le signale avant de repartir."],
  },
  courriel: {
    titre: "Le courriel envoyé",
    bulles: ["Le courriel part"],
    notes: ["Voici le message tel qu'il serait parti. Dans la démonstration, il est écrit dans le dossier courriels-simules/ de la compagnie, et rien ne quitte le poste."],
  },
};

/* CE QUE LA DÉMONSTRATION NE FAIT PAS, DIT AU LIEU D'ÊTRE TU (27/09/2026).
   La sauvegarde et les mises à jour sont coupées dans la démo, et quatre
   salariés fictifs n'ont volontairement pas de taux de PAS : le visiteur
   doit savoir ce que fait la version complète, et pourquoi il voit ce qu'il
   voit. Les phrases disent le logiciel tel qu'il est (sauvegarde.py,
   maj.py, pas.py, operations_amorcage.py), rien de plus. */
const EXPLICATIONS_DEMO = {
  coulisses: {
    titre: "Les coulisses de la démonstration",
    sections: [
      ["La sauvegarde", `Dans la version complète, à l'ouverture puis toutes les vingt minutes
        quand quelque chose a changé, le dossier de la compagnie — saisies, bulletins,
        contrats, déclarations, retours, journal — part dans son propre Google Drive.
        Seul ce qui a changé repart, et rien de ce qui est effacé sur le poste ne l'est
        dans le Drive. Les mots de passe, eux, ne quittent jamais l'ordinateur. Le
        logiciel ne voit dans le Drive que ce qu'il y a lui-même créé.`],
      ["Les mises à jour", `À l'ouverture, le logiciel regarde si l'éditeur a publié une
        nouvelle version. Il la télécharge en arrière-plan, vérifie qu'elle est bien
        signée par l'éditeur, et l'installe au démarrage suivant, sans rien demander.
        Une version qui change un calcul attend que la DSN du mois en cours soit
        déposée ; une version marquée « exigée » (une norme DSN qui change) bloque les
        dépôts réels tant qu'elle n'est pas installée.`],
      ["Dans la démonstration", `Ni l'une ni l'autre ne tourne : aucun compte Google n'est
        lié, rien ne quitte le poste, et la version reste celle de la démonstration.
        Le bandeau dit « À jour » parce que la relève des retours, elle, est jouée.`],
      ["L'horloge de la démonstration", `La compagnie vit sans vous. À chaque ouverture,
        ce qui tombait depuis votre dernier passage a été fait par un administrateur
        fictif, chaque geste à sa date limite : le 1er du mois, le mois s'écrit ; le
        jour d'une embauche, sa DPAE part et son contrat revient signé ; le 15, la DSN
        du mois précédent part, puis les documents aux salariés ; fin janvier, l'année
        passée se clôt. Avant la date limite, c'est à vous : faites la DPAE deux jours
        avant, ou la DSN le 14, et l'horloge ne la refera pas. Ajoutez ou retirez un
        contrat : à votre retour, le mois est réécrit et tout est à jour.`],
    ],
  },
  pas: {
    titre: "Les taux de prélèvement à la source",
    sections: [
      ["D'où vient le taux", `Chaque salarié a un taux, que la DGFiP transmet dans un compte
        rendu (nature 94) après chaque DSN. Il vaut jusqu'à la fin du deuxième mois qui
        suit : un intermittent qui n'a pas travaillé depuis quelques mois n'en a donc
        plus de valide.`],
      ["Sans taux valide", `La loi impose la grille par défaut de l'article 204 H du code
        général des impôts, qui prélève le plus souvent plus que le vrai taux. La paie
        sort quand même ; le bandeau le signale des semaines avant la DSN, pour qu'on
        ait le temps d'agir.`],
      ["Comment l'éviter", `Quand la DPAE d'une embauche s'écrit, le logiciel écrit aussi,
        pour chaque salarié sans taux valide, une demande de taux à la DGFiP (signalement
        d'amorçage), à déposer comme une DSN. La DGFiP répond sous cinq jours ouvrés.`],
      ["Dans la démonstration", `Ces salariés fictifs n'ont volontairement aucun taux : leurs
        bulletins et leurs DSN montrent la grille par défaut, telle qu'elle s'applique.`],
    ],
  },
};

function fenetreExplicationDemo(quoi, apres = "") {
  const e = EXPLICATIONS_DEMO[quoi];
  ouvrirBoite(`
    <div class="demo-fenetre">
      <h3>Démonstration — ${echapper(e.titre)}</h3>
      ${apres ? `<p class="intro">${echapper(apres)}</p>` : ""}
      ${e.sections.map(([t, x]) => `<h4>${echapper(t)}</h4><p>${echapper(x.replace(/\s+/g, " "))}</p>`).join("")}
      <div class="actions"><button class="primaire" onclick="fermerBoite()">Compris</button></div>
    </div>`);
}

let ATTENTE_DEMO = null;
async function fenetreCourrielsDemo(genre, repere) {
  if (!enDemonstration() || repere === null) return;
  const c = CIRCUITS_DEMO[genre];
  let partis = [], retours = [], etape = 0, fiche = null;
  try {
    partis = (await api("demonstration-courriels", { apres: repere || "" })).courriels;
  } catch (e) { return; }
  if (!partis.length) return;
  const premier = partis[0];

  const apercu = (m) => `
    <div class="demo-courriel">
      <div class="demo-entete"><span>De</span> ${echapper(m.de)}<br>
        <span>À</span> ${echapper(m.a)}<br><span>Objet</span> <b>${echapper(m.sujet)}</b>
        ${m.pieces.length ? `<br><span>Pièce jointe</span> ${m.pieces.map((x, i) => x.pages
          ? `<button class="lien demo-piece" data-courriel="${echapper(m.nom)}" data-rang="${i}"
              data-pages="${x.pages}" title="L'ouvrir ici">📎 ${echapper(x.nom)}</button>`
          : `📎 ${echapper(x.nom)}`).join(" ")}` : ""}</div>
      <div class="demo-pdf" hidden></div>
      <iframe class="demo-corps" sandbox title="Le courriel"></iframe>
    </div>`;
  // LA PIÈCE JOINTE S'OUVRE ICI : le PDF affiché par le lecteur du
  // navigateur — le contrat tel que le salarié l'ouvre, et signé à l'étape 3.
  const brancherPieces = () => document.querySelectorAll(".demo-piece").forEach((b) => {
    b.onclick = () => {
      const zone = b.closest(".demo-courriel").querySelector(".demo-pdf");
      const corps = b.closest(".demo-courriel").querySelector(".demo-corps");
      if (!zone.hidden && zone.dataset.rang === b.dataset.rang) {
        zone.hidden = true; corps.hidden = false; return;
      }
      zone.dataset.rang = b.dataset.rang;
      const adresse = `/demonstration/page?c=${encodeURIComponent(b.dataset.courriel)}&p=${
        b.dataset.rang}&jeton=${encodeURIComponent(JETON)}`;
      zone.innerHTML = `<button class="lien demo-retour">← revenir au courriel</button>
        <a class="lien" href="${adresse}" target="_blank" rel="noopener">ouvrir le PDF</a>
        <iframe class="demo-pdf-cadre" title="${echapper(b.textContent.trim())}" src="${adresse}#page=1"></iframe>`;
      zone.hidden = false; corps.hidden = true;
      zone.querySelector(".demo-retour").onclick = () => { zone.hidden = true; corps.hidden = false; };
    };
  });
  const reponse = (b) => `
    <div class="demo-courriel demo-reponse">
      <div class="demo-entete"><span>De</span> ${echapper(premier.a)}<br>
        <span>À</span> ${echapper(premier.de)}<br><span>Objet</span> <b>${echapper(b.sujet)}</b></div>
      <pre class="demo-texte">${echapper(b.corps)}</pre>
    </div>`;

  const dessiner = () => {
    const b = document.getElementById("boite");
    if (!b || !b.querySelector(".demo-fenetre")) return;
    b.querySelectorAll(".demo-bulle").forEach((x, i) => {
      x.classList.toggle("actif", i === etape);
      x.classList.toggle("fait", i < etape || (i === 2 && (retours.length || fiche)));
    });
    let corps = "";
    if (etape === 0) corps = apercu(premier);
    else if (etape === 1) corps = premier.bouton ? reponse(premier.bouton)
      : `<p class="discret">Ce courriel n'a pas de bouton.</p>`;
    else if (retours.length) corps = apercu(retours[0]);
    else if (fiche) corps = `<div class="encart bien"><b>Fiche créée : ${echapper(fiche)}</b>
      Elle est dans Configuration › Salariés, avec ce que la personne a écrit ; il reste à
      choisir son emploi.</div>`;
    else corps = `<p class="discret">⏳ ${echapper(c.attente || "")}</p>`;
    b.querySelector(".demo-etape").innerHTML = `<p class="note">${echapper(c.notes[etape])}</p>${corps}`;
    const f = b.querySelector(".demo-corps");
    const m = etape === 0 ? premier : retours[0];
    if (f && m) f.srcdoc = m.html || `<pre style="font-family:sans-serif;white-space:pre-wrap">${echapper(m.texte)}</pre>`;
    brancherPieces();
  };

  ouvrirBoite(`
    <div class="demo-fenetre">
      <h3>Démonstration — ${echapper(c.titre)}</h3>
      <p class="intro">${partis.length} courriel${partis.length > 1 ? "s" : ""} joué${partis.length > 1 ? "s" : ""}
        — rien n'a quitté le poste.${partis.length > 1 ? ` Voici celui de ${echapper(premier.a)} ; les autres
        sont sur le même modèle.` : ""}</p>
      ${c.bulles.length > 1 ? `<ol class="demo-bulles">${c.bulles.map((t, i) => `
        <li><button class="demo-bulle" data-etape="${i}"><span>${i + 1}</span>${echapper(t)}</button></li>`).join("")}</ol>` : ""}
      <div class="demo-etape"></div>
      <div class="actions">
        ${c.bulles.length > 1 ? `<button class="secondaire" id="demo-suivant">Étape suivante</button>` : ""}
        <button class="primaire" onclick="fermerBoite()">Compris</button>
      </div>
    </div>`, () => { clearTimeout(ATTENTE_DEMO); });
  document.querySelectorAll(".demo-bulle").forEach((x) => {
    x.onclick = () => { etape = +x.dataset.etape; dessiner(); };
  });
  const suivant = document.getElementById("demo-suivant");
  if (suivant) suivant.onclick = () => { etape = (etape + 1) % c.bulles.length; dessiner(); };
  dessiner();

  // L'étape 3 arrive d'elle-même : on la guette tant que la fenêtre est là.
  if (c.bulles.length < 3) return;
  const depuis = Date.now();
  const guetter = async () => {
    if (!document.querySelector(".demo-fenetre") || Date.now() - depuis > 90000) return;
    try {
      if (genre === "signature") {
        const r = await api("demonstration-courriels", { apres: partis[partis.length - 1].nom });
        retours = r.courriels.filter((m) => c.retour.test(m.sujet) && m.a === premier.a);
      } else if (Date.now() - depuis > 21000) {
        const r = await api("fiches-relever", {});
        ETAT.configuration = await api("configuration", {});
        if (r.recues.length) fiche = r.recues.map((x) => x.nom).join(", ");
        // Déjà relevée par la veille : plus rien n'attend, la fiche est là.
        else if (!r.attendues) fiche = premier.a;
      }
    } catch (e) { /* on réessaie */ }
    if (retours.length || fiche) {
      if (etape === 2) dessiner();
      else document.querySelectorAll(".demo-bulle")[2].classList.add("fait");
      return;
    }
    ATTENTE_DEMO = setTimeout(guetter, 3000);
  };
  ATTENTE_DEMO = setTimeout(guetter, 3000);
}

/** Ouvre le dossier du mois dans l'explorateur, et le DIT dans la boîte :
 *  le bandeau du haut est sous la boîte, on ne le voit pas d'ici. Une
 *  fenêtre de l'explorateur peut s'ouvrir derrière PuppetPaie — le chemin
 *  écrit ici permet de la retrouver. */
async function ouvrirDossier(bouton, mois, quoi) {
  let note = bouton.parentNode.querySelector(".note-dossier");
  if (!note) {
    note = document.createElement("p");
    note.className = "note note-dossier";
    bouton.parentNode.appendChild(note);
  }
  try {
    await api("ouvrir-dossier", { mois, quoi });
    note.textContent = "";                 // l'explorateur passe devant
  } catch (e) {
    note.textContent = e.message;
    note.classList.add("erreur");
  }
}

function afficherEnvoi(titre, mois, partis, details) {
  document.getElementById("resultat").innerHTML = `
    <div class="carte" style="margin-top:20px">
      <h2>${echapper(titre)} — ${echapper(moisEnClair(mois))}</h2>
      <div class="encart bien"><b>${partis.length} message(s) parti(s)</b>
        ${echapper(partis.join(", "))}</div>
      ${(details || []).length
        ? `<p class="note">${echapper(details.join(" · "))}</p>` : ""}
    </div>`;
}

/* ------------------------------------------- la reprise du journal
   Le journal des dépôts est né le 11/09/2026 au soir. Tout ce qui est parti
   avant — par CoolPaie, par le site, ou par nos propres dépôts de la veille —
   n'y figure pas, et l'écran affiche donc « rien n'est parti » sur des actes
   qui ont bel et bien eu lieu. Devant la liste des embauches :

     « je comprends pas pourquoi il veut que je renvoie ça alors qu'on l'a
       déjà envoyé et on a les traces de dépôt il me semble »

   Ce bloc lui rend ce qu'il savait. Il n'apparaît QUE s'il y a quelque chose
   à reprendre : une fois le journal à jour, il disparaît et ne revient que si
   un nouveau dépôt atteste d'un chemin qui n'est pas passé par ici.

   DEUX TEMPS, comme partout ailleurs : on montre d'abord ce qui serait écrit,
   ligne par ligne, et on n'écrit que sur un second clic. Une reprise qui part
   au premier appel est une reprise qu'on lance « pour voir » et qui laisse
   des lignes que personne n'a relues. */
/* ------------------------------------------------- LES ARRÊTS DE TRAVAIL
   Un intermittent tombe malade pendant ses dates. Le contrat est signé, il
   est suspendu, et DEUX déclarations le disent :

     - le SIGNALEMENT d'arrêt de travail (nature 04), dû dans les cinq jours
       qui suivent la prise de connaissance par l'employeur ;
     - le REPORT dans la DSN mensuelle, obligatoire (cahier technique §2.5.2),
       qui se fait tout seul à la production du mois.

   L'écran montre les deux, parce qu'un écran qui n'en montrerait qu'une
   laisserait croire que l'autre est faite. Rien ne part d'ici : produire
   écrit un fichier, et c'est la boîte de dépôt — avec son mot de passe —
   qui l'envoie, exactement comme une DSN. */
let ARRETS = null;          // le dernier /api/arrets lu

/* Le mois principal déclaré présente-t-il une période commune avec l'arrêt ?
   La même règle que le moteur (`signalement.Arret.couvre`), parce que
   l'écran doit montrer d'un mois ce que sa DSN portera — ni plus, ni moins. */
function croiseLeMois(a, mois) {
  if (!mois) return true;
  const derniere = a.reprise || a.fin_previsionnelle;
  return a.dernier_jour_travaille <= mois + "-31" && derniere >= mois + "-01";
}

async function dessinerArrets(mois) {
  const cible = document.getElementById("arrets");
  if (!cible) return;
  try { ARRETS = await api("arrets"); }
  catch (e) { cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`; return; }
  const duMois = (ARRETS.arrets || []).filter((a) => croiseLeMois(a, mois));
  cible.innerHTML = `
    ${duMois.length ? duMois.map((a) => `
      <div class="rang">
        <span class="rang-nom">${echapper(a.salarie)}</span>
        <span class="pastille ${a.signale ? "bien" : "alerte"}">${a.signale ? "signalé" : "à signaler"}</span>
        <span class="rang-infos">${echapper(a.motif_libelle)} —
          dernier jour travaillé le ${echapper(jjmmaaaa(a.dernier_jour_travaille))},
          ${a.reprise ? `reprise le ${echapper(jjmmaaaa(a.reprise))}`
                      : `fin prévue le ${echapper(jjmmaaaa(a.fin_previsionnelle))}`}
          · contrat ${echapper(a.contrat)}${a.subrogation === "01" ? " · subrogation" : ""}
          ${a.reporte_par.length ? ` · reporté par la DSN ${a.reporte_par.map(deMois).join(", ")}`
                                 : " · à reporter dans la DSN du mois"}</span>
        <button class="secondaire" data-signaler="${echapper(a.salarie)}:${echapper(a.dernier_jour_travaille)}">Signaler…</button>
        <button class="lien" data-reprise="${echapper(a.salarie)}:${echapper(a.dernier_jour_travaille)}">Reprise…</button>
        ${a.signale ? "" : `<button class="lien" data-oublier="${echapper(a.salarie)}:${echapper(a.dernier_jour_travaille)}">Retirer</button>`}
      </div>`).join("")
      : ""}
    <button class="lien" id="ajouter-arret">+ un arrêt de travail</button>`;
  // Le titre ne parle que s'il y a un arrêt : un bloc qui dit « aucun »
  // tous les mois finit par ne plus se lire.
  const titre = document.getElementById("titre-arrets");
  if (titre) titre.hidden = !duMois.length;

  document.getElementById("ajouter-arret").onclick = () => boiteArret(mois);
  cible.querySelectorAll("[data-signaler]").forEach((b) => {
    const [salarie, jour] = b.dataset.signaler.split(":");
    b.onclick = () => boiteSignalement(salarie, jour);
  });
  cible.querySelectorAll("[data-reprise]").forEach((b) => {
    const [salarie, jour] = b.dataset.reprise.split(":");
    b.onclick = () => boiteReprise(salarie, jour);
  });
  cible.querySelectorAll("[data-oublier]").forEach((b) => {
    b.onclick = async () => {
      const [salarie, jour] = b.dataset.oublier.split(":");
      try {
        await api("arret-oublier", { salarie, dernier_jour: jour });
        dire("Arrêt retiré — il n'avait jamais été déclaré.");
        await dessinerArrets(MOIS_AFFICHE);
      } catch (e) { dire(e.message, "erreur"); }
    };
  });
}

/** Saisir un arrêt. Le contrat suspendu n'est pas choisi par la page : elle
 *  demande au moteur ceux qui couvrent ce jour-là, et n'en propose pas
 *  d'autre. Sans contrat, il n'y a rien à suspendre, et on le dit. */
async function boiteArret(mois) {
  const motifs = (ARRETS && ARRETS.motifs) || [];
  const salaries = (ETAT && ETAT.salaries) || [];
  ouvrirBoite(`
    <h3>Un arrêt de travail</h3>
    <p class="note">Il suspend un contrat en cours. Deux déclarations
      suivront : le <b>signalement</b>, dû dans les cinq jours, et le report
      dans la <b>DSN du mois</b>, qui se fait à la production.</p>
    <label class="champ-boite">Salarié
      <select id="ar-salarie">
        ${salaries.map((s) => `<option value="${echapper(s.cle)}">${echapper(s.libelle)}</option>`).join("")}
      </select></label>
    <label class="champ-boite">Dernier jour travaillé
      <input type="date" id="ar-dernier"></label>
    <div id="ar-contrats" class="note"></div>
    <label class="champ-boite">Fin prévisionnelle <span class="discret">— celle
      que le médecin a prescrite ; elle est due même sans reprise</span>
      <input type="date" id="ar-fin"></label>
    <label class="champ-boite">Motif
      <select id="ar-motif">
        ${motifs.map((m) => `<option value="${echapper(m.code)}"${m.date_accident ? ' data-accident="1"' : ""}>${echapper(m.libelle)}</option>`).join("")}
      </select></label>
    <label class="champ-boite" id="ar-bloc-accident" hidden>Date de l'accident
      ou de la première constatation
      <input type="date" id="ar-accident"></label>
    <label class="champ-boite">Subrogation
      <select id="ar-subrogation">
        <option value="02">non — le salarié touche ses indemnités journalières</option>
        <option value="01">oui — la compagnie les perçoit et maintient le salaire</option>
      </select></label>
    <div id="ar-bloc-subrogation" hidden>
      <label class="champ-boite">Subrogation du
        <input type="date" id="ar-sub-debut"></label>
      <label class="champ-boite">au
        <input type="date" id="ar-sub-fin"></label>
      <p class="note">L'IBAN et le BIC de la compagnie partiront avec : ils se
        lisent dans la fiche entreprise, ils ne se saisissent pas ici.</p>
    </div>
    <label class="champ-boite">Note <span class="discret">— pour vous, ne part nulle part</span>
      <input type="text" id="ar-note"></label>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="ar-ok">Enregistrer</button>
    </div>
    <p class="note">Rien ne part : l'arrêt est écrit, et le signalement se
      produit ensuite.</p>`);

  const motif = document.getElementById("ar-motif");
  const sub = document.getElementById("ar-subrogation");
  const majMotif = () => {
    const choisi = motif.selectedOptions[0];
    document.getElementById("ar-bloc-accident").hidden = !(choisi && choisi.dataset.accident);
  };
  const majSub = () => {
    document.getElementById("ar-bloc-subrogation").hidden = sub.value !== "01";
  };
  motif.onchange = majMotif;
  sub.onchange = majSub;
  majMotif(); majSub();

  // Les contrats que cet arrêt suspendrait : relus à chaque changement de
  // salarié ou de date, parce que ce sont eux qui décident si l'arrêt peut
  // exister.
  let contrats = [];
  const relire = async () => {
    const salarie = document.getElementById("ar-salarie").value;
    const jour = document.getElementById("ar-dernier").value;
    const bloc = document.getElementById("ar-contrats");
    if (!salarie || !jour) { bloc.innerHTML = ""; return; }
    try {
      const r = await api("arret-contrats", { salarie, jour });
      contrats = r.contrats || [];
    } catch (e) { bloc.innerHTML = `<span class="erreur">${echapper(e.message)}</span>`; return; }
    bloc.innerHTML = contrats.length
      ? (contrats.length === 1
          ? `Contrat suspendu : <b>${echapper(contrats[0].numero)}</b>, du
             ${echapper(jjmmaaaa(contrats[0].debut))} au ${echapper(jjmmaaaa(contrats[0].fin))}.`
          : `Deux contrats couvrent ce jour-là — dire lequel :
             <select id="ar-contrat">${contrats.map((c) =>
               `<option value="${echapper(c.numero)}">${echapper(c.numero)}, du ${echapper(jjmmaaaa(c.debut))} au ${echapper(jjmmaaaa(c.fin))}</option>`).join("")}</select>`)
      : `<span class="erreur">Aucun contrat ne couvre ce jour-là : il n'y a rien
         à suspendre. Vérifier la date, ou saisir le contrat d'abord.</span>`;
  };
  document.getElementById("ar-salarie").onchange = relire;
  document.getElementById("ar-dernier").onchange = relire;
  relire();

  document.getElementById("ar-ok").onclick = async () => {
    const choisi = document.getElementById("ar-contrat");
    try {
      await api("arret-enregistrer", {
        salarie: document.getElementById("ar-salarie").value,
        dernier_jour: document.getElementById("ar-dernier").value,
        fin: document.getElementById("ar-fin").value,
        motif: document.getElementById("ar-motif").value,
        subrogation: document.getElementById("ar-subrogation").value,
        subrogation_debut: document.getElementById("ar-sub-debut").value,
        subrogation_fin: document.getElementById("ar-sub-fin").value,
        date_accident: document.getElementById("ar-accident").value,
        contrat: choisi ? choisi.value : (contrats[0] && contrats[0].numero) || "",
        note: document.getElementById("ar-note").value,
      });
      fermerBoite();
      dire("Arrêt enregistré. Le signalement reste à produire.");
      await dessinerArrets(MOIS_AFFICHE);
    } catch (e) { dire(e.message, "erreur"); }
  };
}

/** La reprise. Elle ne se signale que si elle est ANTICIPÉE ; sinon elle part
 *  avec la DSN du mois, et le moteur le dit plutôt que de laisser produire un
 *  signalement qui n'a pas lieu d'être. */
function boiteReprise(salarie, jour) {
  const motifs = (ARRETS && ARRETS.motifs_reprise) || [];
  ouvrirBoite(`
    <h3>La reprise</h3>
    <p class="note">La date de reprise <b>réelle</b> — le premier jour
      retravaillé. Un signalement de reprise ne s'émet que si elle est
      <b>anticipée</b> par rapport à la fin prévue de l'arrêt ; sinon la DSN
      du mois suffit.</p>
    <label class="champ-boite">Reprise le
      <input type="date" id="re-date"></label>
    <label class="champ-boite">Motif
      <select id="re-motif">
        ${motifs.map((m) => `<option value="${echapper(m.code)}">${echapper(m.libelle)}</option>`).join("")}
      </select></label>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="re-ok">Noter la reprise</button>
    </div>`);
  document.getElementById("re-ok").onclick = async () => {
    try {
      await api("arret-reprise", {
        salarie, dernier_jour: jour,
        reprise: document.getElementById("re-date").value,
        motif_reprise: document.getElementById("re-motif").value,
      });
      fermerBoite();
      dire("Reprise notée.");
      await dessinerArrets(MOIS_AFFICHE);
    } catch (e) { dire(e.message, "erreur"); }
  };
}

/** Produire le signalement, puis le déposer. Deux gestes et deux boîtes :
 *  écrire un fichier n'engage rien, le déposer engage tout. */
function boiteSignalement(salarie, jour) {
  const a = ((ARRETS && ARRETS.arrets) || []).find(
    (x) => x.salarie === salarie && x.dernier_jour_travaille === jour) || {};
  const dejaSignale = (a.signalements || []).length;
  ouvrirBoite(`
    <h3>Signaler l'arrêt de ${echapper(salarie)}</h3>
    <p class="discret">${echapper(a.motif_libelle || "")} — dernier jour travaillé le
      ${echapper(jjmmaaaa(jour))}, fin prévue le ${echapper(jjmmaaaa(a.fin_previsionnelle))}.</p>
    <div class="encart">
      <b>Le signalement est dû dans les cinq jours</b>
      Il informe l'Assurance Maladie au plus près de l'événement, pour les
      indemnités journalières. La DSN du mois le répétera : ce n'est pas la
      même déclaration, et l'une ne remplace pas l'autre.
    </div>
    ${a.reprise ? `<label class="champ-boite">
      <input type="checkbox" id="si-reprise"> Signaler la <b>reprise anticipée</b>
      (nature 05) plutôt que l'arrêt</label>` : ""}
    ${dejaSignale ? `<div class="encart attention">
      <b>Déjà signalé ${dejaSignale} fois</b>
      Un nouveau signalement normal ne remplace rien : pour corriger ce qui est
      parti, il faut un annule-et-remplace, qui vise l'identifiant rendu par le
      point de dépôt (il est sur le certificat de conformité).
      <label class="champ-boite">Identifiant de la déclaration remplacée
        <input type="text" id="si-remplace" placeholder="vide pour un signalement normal"></label>
    </div>` : ""}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="si-ok">Écrire le signalement</button>
    </div>`);
  document.getElementById("si-ok").onclick = async () => {
    const remplace = document.getElementById("si-remplace");
    const reprise = document.getElementById("si-reprise");
    let r;
    try {
      r = await api("arret-signaler", {
        salarie, dernier_jour: jour,
        nature: reprise && reprise.checked ? "05" : "04",
        remplace: remplace ? remplace.value.trim() : "",
      });
    } catch (e) { dire(e.message, "erreur"); return; }
    fermerBoite();
    // Les avis du signalement suivent le message, sur la même ligne : un
    // par un en rouge, le suivant effaçait le précédent (24/09/2026).
    dire(["Signalement écrit : " + r.nom + ". Rien n'est parti."]
      .concat(r.avertissements || []).join("  ·  "));
    await dessinerArrets(MOIS_AFFICHE);
    boiteDepot("dsn", r.fichier);
  };
}

/* ------------------------------------------ LA FIN D'UN CONTRAT (nature 07)
   Un CDI ou un CDD ordinaire se termine : sa fin ne part pas dans la DSN du
   mois, elle fait un SIGNALEMENT à part, dû dans les cinq jours ouvrés. Un
   CDD d'usage du spectacle, lui, n'en émet jamais — le circuit dérogatoire
   porte sa fin dans la mensuelle. Les deux chemins ne se croisent pas, et
   c'est `operations.fins_a_signaler` qui tranche, jamais cet écran.

   Ce bloc ne fait pas saisir : il MONTRE ce qui manque et renvoie au bloc
   d'engagement, où les faits se tapent. Un signalement qui partirait sans
   motif de rupture serait refusé, et proposer un bouton qui refuse est pire
   que ne rien proposer. */
async function dessinerFins(mois) {
  const cible = document.getElementById("fins-de-contrat");
  if (!cible) return;
  let r;
  try { r = await api("fins-de-contrat", { mois }); }
  catch (e) { cible.innerHTML = ""; return; }
  if (MOIS_AFFICHE !== mois) return;          // on a changé de mois entre-temps
  const fins = r.fins || [];
  if (!fins.length) { cible.innerHTML = ""; return; }
  cible.innerHTML = `
    <h2>Fin de contrat <span class="discret">— à signaler sous 5 jours ouvrés</span></h2>
    ${fins.map((f) => `
      <div class="rang">
        <span class="rang-nom">${echapper(f.salarie)}</span>
        <span class="pastille ${f.a_saisir.length ? "alerte" : "bien"}">${
          f.a_saisir.length ? "saisie incomplète" : "prêt"}</span>
        <span class="rang-infos">${echapper(f.nature)} — contrat ${echapper(f.numero || "?")},
          fin le ${echapper(jjmmaaaa(f.fin))}</span>
        ${f.a_saisir.length ? `<div class="encart attention">
          <b>Ce que le signalement exige et que la saisie ne dit pas</b>
          ${f.a_saisir.map((m) => `<div>${echapper(m)}</div>`).join("")}
          Ça se tape sous « Contrat », dans le bloc de cet engagement.
        </div>` : ""}
        <button class="secondaire" data-signaler-fin="${echapper(f.salarie)}"
          ${f.a_saisir.length ? "disabled" : ""}>Signaler…</button>
        <button class="lien" data-papiers="${echapper(f.salarie)}">Les deux papiers…</button>
      </div>`).join("")}
    <p class="note">Le signalement informe France Travail au plus près de la
      rupture — c'est lui qui ouvre les droits. Rien ne part d'ici : le
      fichier s'écrit, et le dépôt est un acte à part.</p>`;

  cible.querySelectorAll("[data-signaler-fin]").forEach((b) => {
    b.onclick = () => boiteSignalerFin(mois, b.dataset.signalerFin,
                                       fins.find((f) => f.salarie === b.dataset.signalerFin));
  });
  cible.querySelectorAll("[data-papiers]").forEach((b) => {
    b.onclick = () => boitePapiersDeFin(mois, b.dataset.papiers);
  });
}

/** Écrire le signalement, puis le déposer. Deux gestes, comme pour un
 *  arrêt : écrire un fichier n'engage rien, le déposer engage tout. */
function boiteSignalerFin(mois, salarie, f = {}) {
  ouvrirBoite(`
    <h3>Signaler la fin du contrat de ${echapper(salarie)}</h3>
    <p class="discret">${echapper(f.nature || "")} — contrat ${echapper(f.numero || "?")},
      fin le ${echapper(jjmmaaaa(f.fin))}.</p>
    <div class="encart">
      <b>Le signalement est dû dans les cinq jours ouvrés</b>
      Il est adressé à France Travail, qui en tire l'attestation employeur du
      salarié : c'est ce document-là qui ouvre ses droits. La DSN du mois ne
      le remplace pas — elle ne porte pas la fin d'un contrat qui se signale.
    </div>
    <label class="champ-boite">Identifiant de la déclaration remplacée
      <input type="text" id="fi-remplace" placeholder="vide pour un signalement normal"></label>
    <p class="note">Un annule-et-remplace vise l'identifiant du signalement
      déjà valide : <b>JJMMAAAA suivi du rang de l'envoi</b>, lu sur son
      certificat de conformité. Ce n'est pas l'identifiant de flux.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="fi-ok">Écrire le signalement</button>
    </div>`);
  document.getElementById("fi-ok").onclick = async () => {
    let r;
    try {
      r = await api("fin-contrat-signaler", {
        mois, salarie,
        remplace: document.getElementById("fi-remplace").value.trim(),
      });
    } catch (e) { dire(e.message, "erreur"); return; }
    fermerBoite();
    dire(["Signalement écrit : " + r.nom + " (préavis : " + r.preavis + "). Rien n'est parti."]
      .concat(r.avertissements || []).join("  ·  "));
    await dessinerFins(MOIS_AFFICHE);
    boiteDepot("dsn", r.fichier);
  };
}

/** Les deux papiers dus au salarié qui part. Ils ne partent nulle part :
 *  ils se REMETTENT, et le reçu se signe à la main. */
async function boitePapiersDeFin(mois, salarie) {
  let r;
  try { r = await api("fin-contrat-documents", { mois, salarie }); }
  catch (e) { dire(e.message, "erreur"); return; }
  ouvrirBoite(`
    <h3>Le certificat de travail et le reçu pour solde de tout compte</h3>
    <p class="discret">Écrits pour ${echapper(salarie)} :
      ${r.noms.map((n) => echapper(n)).join(", ")}.</p>
    ${(r.avertissements || []).map((m) => `<div class="encart attention">${echapper(m)}</div>`).join("")}
    <div class="actions">
      <button class="secondaire" id="fp-dossier">Ouvrir le dossier</button>
      <button class="primaire" onclick="fermerBoite()">Fermer</button>
    </div>`);
  document.getElementById("fp-dossier").onclick = async () => {
    try { await api("ouvrir-dossier", { mois }); }
    catch (e) { dire(e.message, "erreur"); }
  };
}

async function dessinerReprise() {
  const cible = document.getElementById("reprise");
  if (!cible) return;
  let r;
  try {
    r = await api("journal-reprise", {});
  } catch (e) {
    cible.innerHTML = "";
    return;
  }
  if (!r.ajoutes.length) { cible.innerHTML = ""; return; }

  const reels = r.ajoutes.filter((v) => v.mode === "reel" && v.accepte);
  // Replié en une ligne, sauf s'il y a un dépôt RÉEL accepté à reprendre :
  // des essais retrouvés sont un historique à ranger, pas une urgence.
  cible.innerHTML = `
    <details class="reprise" ${reels.length ? "open" : ""}>
    <summary>${r.ajoutes.length} dépôt${r.ajoutes.length > 1 ? "s" : ""} retrouvé${r.ajoutes.length > 1 ? "s" : ""}
      dans les retours, absent${r.ajoutes.length > 1 ? "s" : ""} du journal${reels.length
        ? ` — <b>dont ${reels.length} réel${reels.length > 1 ? "s" : ""}</b>` : ""}</summary>
    <div class="encart">
      <b>${r.ajoutes.length} dépôt(s) attestés par les retours, absents du journal</b>
      Le journal des dépôts est né le 11/09/2026 ; ce qui est parti avant ne
      s'y est pas écrit. Les accusés d'enregistrement reçus des organismes,
      eux, s'en souviennent. Les reprendre ne dépose
      rien et n'envoie rien : ça remet au journal ce qui a déjà eu lieu.
      ${reels.length ? `<br><b>${reels.length} sont des dépôts RÉELS acceptés.</b>` : ""}
    </div>
    <div class="liste-choix">
      ${r.ajoutes.map((v) => `
        <div class="choix"><span>
          <b>${echapper(quand(v.quand))}</b>
          — ${echapper(v.mois ? moisEnClair(v.mois) : "mois inconnu")}
          <span class="pastille ${v.mode === "reel" ? (v.accepte ? "bien" : "erreur") : "alerte"}">
            ${v.mode === "reel" ? "dépôt réel" : "test"}${v.accepte ? "" : " — refusé"}</span>
          <br><span class="discret">déposé par ${echapper(v.logiciel || "logiciel inconnu")}
            · flux ${echapper(v.flux)}</span>
        </span></div>`).join("")}
    </div>
    <button class="secondaire" id="reprendre">Reprendre ces ${r.ajoutes.length} dépôt(s)</button>
    <p class="note">Le nom du logiciel n'est pas une annotation : il est lu
      dans le certificat de conformité. C'est lui qui distingue un dépôt
      CoolPaie d'un dépôt PuppetPaie.</p>
    </details>`;

  document.getElementById("reprendre").onclick = async () => {
    document.getElementById("reprendre").disabled = true;
    try {
      const f = await api("journal-reprise", { ecrire: true });
      dire(f.ajoutes.length + " dépôt(s) remis au journal"
           + (f.rattaches ? ", " + f.rattaches + " retour(s) rattachés." : "."));
      await rafraichirActions();
      await dessinerReprise();
    } catch (e) {
      document.getElementById("reprendre").disabled = false;
      dire(e.message, "erreur");
    }
  };
}

/* --------------------------------- les embauches sans trace d'envoi
   La demande était « un bouton qui envoie les DPAE des contrats pas encore
   envoyés ». Ce qu'on peut faire honnêtement aujourd'hui, c'est la LISTE et
   le chemin vers le dépôt : le fichier DPAE d'un mois porte tout le mois, et
   il n'existe pas encore de production qui ne reprendrait qu'une partie des
   engagements. Le récapitulatif du dépôt dit alors, ligne par ligne, ce qui a
   déjà une trace — c'est là que la nuance se joue, pas ici.

   DU MOIS AFFICHÉ, ET DE LUI SEUL, depuis le 12/09/2026 :

     « je vois octobre dans septembre »
     « chaque mois doit être autonome »

   La liste balayait tous les mois connus. Une saisie d'essai laissée en
   octobre s'affichait donc dans la colonne de septembre, avec son bouton
   « Voir la DPAE d'octobre… » — un dépôt d'un autre mois à un clic, dans une
   colonne qui ne parle que de celui-ci. Le moteur savait déjà filtrer
   (`embauches_a_declarer(ctx, mois)`) ; on lui passe enfin le mois. */
async function dessinerEmbauches(mois) {
  const cible = document.getElementById("embauches");
  const titre = document.getElementById("titre-embauches");
  // Plus de bloc dans la page depuis le 13/09/2026 : la pastille DPAE de
  // chaque paie et la boîte DPAE disent déjà tout. Le code reste pour le
  // jour où on voudrait la liste ailleurs.
  if (!cible) return;
  if (titre) {
    titre.innerHTML = `Embauches sans trace d'envoi
      <span class="discret">${mois ? "— " + echapper(moisEnClair(mois)) : ""}</span>`;
  }
  if (!mois) { cible.innerHTML = ""; return; }
  let liste;
  try {
    liste = (await api("embauches-a-declarer", { mois })).embauches;
  } catch (e) {
    cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`;
    return;
  }
  if (!liste.length) {
    cible.innerHTML = `<p class="discret">Toutes les embauches de
      ${echapper(moisEnClair(mois))} ont une trace d'envoi.</p>`;
    return;
  }
  cible.innerHTML = `
    <div class="encart info">
      <b>« Pas de trace d'envoi », et non « pas déclarée »</b>
      Ce journal ne connaît que ce que <i>ce</i> logiciel a déposé. Une
      embauche déclarée par CoolPaie, ou à la main sur le site de l'Urssaf,
      figure ici quand même — et déclarer deux fois la même embauche n'est pas
      anodin.
    </div>
    <div class="acte">
      <ul class="embauches-liste">
        ${liste.map((x) => `
          <li>${echapper(x.nom)} — ${echapper(x.spectacle)}, du
            ${echapper(jjmmaaaa(x.debut))} au
            ${echapper(jjmmaaaa(x.fin))}</li>`).join("")}
      </ul>
      <button class="secondaire" data-embauche="${echapper(mois)}">
        Voir la DPAE ${echapper(deMois(mois))}…</button>
    </div>
    <p class="note">Le fichier DPAE d'un mois porte <b>tout</b> le mois.
      Le récapitulatif du dépôt dit, pour chaque embauche, si elle a déjà une
      trace.</p>`;
  cible.querySelectorAll("[data-embauche]").forEach((b) => {
    b.onclick = () => ouvrirDpaeDuMois(b.dataset.embauche);
  });
}

async function ouvrirDpaeDuMois(mois) {
  return boiteDpae(mois);
}

/* =======================================================================
   L'ÉCRAN PAR PAIE
   =======================================================================
   Demandé en regardant l'écran :

     « pour les contrats à signer, il pourrait y avoir plusieurs cases dans
       chaque paie, pour voir en un coup d'œil si la DPAE est faite, si le
       contrat est envoyé… »
     « et une case pour sélectionner, pour pouvoir en sélectionner plusieurs
       pour envoyer plusieurs contrats d'un coup, ou plusieurs DPAE d'un coup »

   Le moteur sait répondre depuis le 11/09 au soir (`operations.etat_par_paie`,
   `produire_dpae(paies=[…])`) ; ces deux fonctions n'avaient pas d'écran, et
   une fonction sans écran est une fonction que personne n'utilise.

   TROIS RÈGLES, ET LA PREMIÈRE EST TOUT LE SUJET :

   1. CHAQUE PASTILLE DIT À QUELLE MAILLE ELLE EST CONNUE. Les quatre actes ne
      se déclarent pas au même grain : une DPAE déclare une embauche, un
      contrat se signe par engagement, les documents partent par salarié, et
      une DSN est mensuelle — il n'existe pas de DSN d'une paie. Écrire « DSN
      déposée » sur un bloc de paie sans dire qu'on parle du mois promettrait
      une précision que le journal n'a pas. D'où le « du mois », le « de
      <nom> », sous la pastille — et la maille vient du moteur, pas d'ici.
   2. L'ÉTAT EST CELUI DE LA SAISIE ENREGISTRÉE, pas de ce qui est à l'écran.
      `etat_par_paie` lit `paies/AAAA-MM.json`. Un engagement qu'on vient
      d'ajouter ou de changer n'a donc pas d'état, et le bloc le DIT au lieu
      de montrer celui d'à côté. Une pastille verte sur une paie modifiée
      serait le pire mensonge possible ici.
   3. RIEN NE PART D'UN CLIC. Les deux actions groupées ouvrent les mêmes
      récapitulatifs que la colonne de droite, avec le même mot de passe du
      logiciel. Elles ne font que RESTREINDRE ce qui part à ce qui est coché.

   Ce qui n'est pas là, et qu'il ne faut pas croire oublié : le bouton
   « valider » par paie, et le bloc qui devient vert. « Valider » est un état
   de la SAISIE, pas un acte — rien ne part — et le moteur ne sait pas encore
   l'écrire. Le dessiner d'abord aurait fait une case à cocher qui ne se
   souvient de rien. Voir ETAT.md §19.12.
*/
let ETATS_PAIES = null;      // "clé|début" → les quatre actes ; null = pas lu

const clePaie = (salarie, debut) => salarie + "|" + debut;

/** Le (salarié, premier jour) d'un bloc, tel qu'il est SAISI à l'écran.
 *  Le moteur trie les dates et prend la première (`Engagement.debut`) : on
 *  fait pareil, sans quoi une paie saisie « 12 3 » ne se retrouverait pas. */
function paiesDuBloc(div) {
  // Les jours sont sur les lignes de paie depuis le 12/09/2026 : le premier
  // jour de la paie est le plus petit de TOUTES ses lignes -- sauf si le
  // contrat dit son début (un contrat en cours depuis octobre s'identifie
  // par le 12/10, pas par son premier cachet de novembre).
  const dates = joursDuBloc(div);
  const debut = div.querySelector(".e-debut")?.value || dates[0];
  if (!debut) return [];
  return salariesDuBloc(div).map((salarie) => ({ salarie, debut }));
}

/* LES TROIS ACTES D'UNE PAIE. Ils étaient quatre — la DSN en faisait partie,
   avec un « du mois » sous la pastille pour prévenir du contresens. La demande : « la DSN, elle ne doit pas être liée à la sélection, elle
   fait obligatoirement tout le mois, pas comme les DPAE ». Une mention sous
   une pastille ne rattrape pas une pastille mal placée : posée dans un bloc de
   paie, à côté d'une case à cocher qui sert à restreindre ce qui part, elle se
   lisait comme « la DSN de cette paie-ci ». Il n'existe pas de DSN d'une paie.
   Elle vit désormais dans la colonne du mois, et là seulement. */
const ACTES_PAIE = [
  { cle: "dpae", titre: "DPAE" },
  { cle: "signature", titre: "Contrat" },
  { cle: "documents", titre: "Documents" },
];

/** « de Favart » : ce que la pastille couvre AU JUSTE, quand ce n'est pas
 *  cette paie-ci. Reste utile pour les documents, qui partent par salarié. */
function ditLaMaille(maille, ligne) {
  if (maille === "mois") return "du mois";
  if (maille === "salarie") {
    return "de " + String(ligne.nom || "ce salarié").split(" ")[0];
  }
  return "";
}

/* TROIS COULEURS, ET UN PETIT CARRÉ. La demande, devant les
   anciennes vignettes : « j'imaginais ça en petit, juste un petit carré qui
   est gris, qui passe au vert ou orange si problème ou pas encore arrivé — ça
   prend trop de place comme ça ».

   Elles prenaient en effet quatre encadrés sur toute la largeur du bloc, alors
   qu'on ne leur demande qu'un coup d'œil. Une ligne, trois carrés, trois
   libellés. Le détail — la date, la maille, l'état du retour — passe dans
   l'infobulle : il se lit quand on le cherche, et il ne se lit que là.

     gris     rien n'est parti ;
     orange   parti, mais l'accusé n'est pas arrivé (ou a refusé) ;
     vert     parti, et attesté.

   L'orange n'est pas décoratif : « envoyé » et « accepté » sont deux choses,
   et les confondre fait tenir pour faite une déclaration en attente. Pour les
   contrats et les documents, il n'existe pas d'accusé — un envoi est un envoi,
   et le vert est alors la vérité entière. */
function couleurPastille(cle, e) {
  // Le contrat a son accusé à lui : le papier signé qui revient, et c'est un
  // humain qui le dit d'un clic (contrat-recu). « Envoyé on passe à orange,
  // signé on passe au vert ». Un contrat signé sur
  // place, jamais envoyé, se marque reçu quand même : vert.
  if (cle === "signature") {
    // Un CDI en cours (30/09/2026) : signé à l'embauche, rien à envoyer ni à
    // comparer chaque mois — la pastille dit « CDI, signé en <mois> ».
    if (e && e.cdi_en_cours) return "vert";
    // La paie a changé depuis que le contrat est parti : il n'est plus le
    // bon, signé ou non. Rouge, comme une DPAE refusée : il faut le refaire.
    // Signé, mais il ne dit plus ce que dit la paie : orange, un avenant
    // est à faire (30/09/2026). Rouge reste pour un contrat pas signé qui a
    // changé : c'est lui qu'il faut renvoyer.
    if (e && e.caduc && e.recu) return "orange";
    if (e && e.caduc) return "rouge";
    // Un avenant parti, pas encore revenu signé : le contrat est signé, sa
    // modification non (30/09/2026).
    if (e && e.avenant_attendu) return "orange";
    if (e && e.recu) return "vert";
    return (e && e.fait) ? "orange" : "gris";
  }
  if (!e || !e.fait) return "gris";
  if (cle !== "dpae") return "vert";          // pas d'accusé pour ces envois-là
  // La DPAE, elle, reçoit un certificat de conformité — et le moteur le dit
  // PAR PAIE (`passee`), sur le dépôt qui porte cette embauche-là. Refusée :
  // rouge, et c'est la seule pastille qui demande de REFAIRE quelque chose.
  if (e.refusee) return "rouge";
  return e.passee ? "vert" : "orange";
}

function infobulle(cle, titre, e, ligne) {
  // Un contrat en cours depuis un mois précédent : sa DPAE et sa signature
  // sont celles de ce mois-là. La pastille les montre (le journal les
  // connaît par salarié et début de contrat), et dit d'où elles viennent.
  // Les documents, eux, partent chaque mois : la mention ne les concerne pas.
  const enCours = cle !== "documents" && ligne && ligne.contrat && !ligne.contrat.premier_mois
    ? " (contrat en cours depuis " + moisEnClair(ligne.contrat.depuis) + ")" : "";
  if (cle === "signature") {
    if (e && e.cdi_en_cours) {
      return titre + " — " + libelleCdiEnCours(e) + " — en cours depuis "
        + moisEnClair(e.cdi_en_cours.depuis) + ", sans terme : rien à envoyer ce mois-ci";
    }
    const envoi = (e && e.fait) ? "envoyé le " + quand(e.fait) : "pas envoyé";
    if (e && e.caduc && e.recu) {
      return titre + " — " + signeLe(e.recu, e.recu_par) + enCours + " — "
        + (e.pourquoi || "la paie a changé depuis") + " : cliquer pour faire l'avenant";
    }
    if (e && e.caduc) {
      return titre + " — " + envoi + enCours + " — " + (e.pourquoi || "la paie a changé depuis")
        + " : ce contrat n'est plus le bon, à renvoyer au salarié";
    }
    if (e && e.avenant_attendu) {
      return titre + " — " + envoi + enCours + " — avenant n° " + e.avenant.numero
        + " envoyé le " + quand(e.avenant.quand) + ", pas encore revenu signé";
    }
    if (e && e.recu) {
      return titre + " — " + envoi + enCours + " — " + signeLe(e.recu, e.recu_par)
        + (e.avenant && e.avenant.signe ? " — avenant n° " + e.avenant.numero
           + " signé le " + quand(e.avenant.signe) : "");
    }
    return titre + " — " + envoi + enCours
      + (e && e.fait ? " — pas encore revenu signé" : "");
  }
  if (!e || !e.fait) return titre + " — rien n'est parti" + enCours;
  const maille = ditLaMaille(e.maille, ligne);
  const couleur = couleurPastille(cle, e);
  if (couleur === "rouge") {
    return titre + " — envoyé le " + quand(e.fait) + " — REFUSÉ : "
      + ((e.anomalies || []).join(" ; ") || "motif non lu")
      + " — à corriger et à renvoyer";
  }
  return titre + " — envoyé le " + quand(e.fait) + enCours
    + (maille ? " (" + maille + ")" : "")
    + (couleur === "orange" ? " — accusé pas encore arrivé, on attend"
       : cle === "dpae" ? " — passée, rien à faire" + dossierUrssaf(e) : "");
}

/** La référence sous laquelle l'Urssaf a enregistré la DPAE (certificat de
 *  conformité, R_DOSSIER), quand elle est arrivée ; ou « déjà existante »
 *  quand l'Urssaf n'a rien créé parce qu'une DPAE identique était là. */
function dossierUrssaf(e) {
  if (!e) return "";
  if (e.deja_existante) return " (déjà existante à l'Urssaf, rien de créé)";
  return e.dossier ? " (dossier " + e.dossier + ")" : "";
}

/** « CDI, signé en septembre 2026 » : ce que la pastille Contrat écrit d'un
 *  CDI en cours à la place de « Contrat » (le moteur donne le mois). */
function libelleCdiEnCours(e) {
  return "CDI, signé en " + moisEnClair(e.cdi_en_cours.signe_en);
}

/** Le bandeau d'un bloc : une ligne, un carré par acte. */
function bandeauEtats(ligne) {
  return `<div class="etats-actes">` + ACTES_PAIE.map((a) => {
    const e = ligne.etats[a.cle] || {};
    // DPAE et Contrat se cliquent : on voit CE QUI EST PARTI, les fichiers
    // eux-mêmes (29/09/2026), et c'est là qu'on dit « reçu signé ».
    const clic = a.cle !== "documents"
      ? ` cliquable" data-acte="${a.cle}"`
      : `"`;
    return `<span class="etat-acte ${couleurPastille(a.cle, e)}${clic}
        title="${echapper(infobulle(a.cle, a.titre, e, ligne)
          + (a.cle !== "documents" ? " — cliquer pour voir ce qui est parti" : ""))}">
      <i class="carre"></i>${echapper(a.cle === "signature" && e.cdi_en_cours
        ? libelleCdiEnCours(e) : a.titre)}${e.recu && !e.caduc ? " ✓" : ""}</span>`;
  }).join("") + `</div>`;
}

/** Le clic sur la pastille DPAE ou Contrat : VOIR CE QUI EST PARTI
 *  (l'utilisateur, 29/09/2026 : « on voit le journal, pas ce qui est parti »).
 *  Les fichiers eux-mêmes — la DPAE déposée, le contrat envoyé, le contrat
 *  revenu signé — chacun s'ouvre dans le lecteur du poste. La mention
 *  « reçu signé » se pose ici, réversible d'un second clic ; le journal
 *  garde les deux. */
function brancherRecu(div) {
  div.querySelectorAll(".etat-acte.cliquable").forEach((s) => {
    s.onclick = (ev) => {
      ev.preventDefault();
      const ligne = (s.closest(".engagement") || div)._ligne;
      if (!ligne) return;
      // Un contrat signé qui ne dit plus ce que dit la paie : le clic
      // propose tout de suite l'avenant (30/09/2026, « simple »).
      const e = (ligne.etats || {})[s.dataset.acte] || {};
      if (s.dataset.acte === "signature" && e.caduc && e.recu) {
        boiteAvenant(document.getElementById("mois").value, ligne.salarie, ligne.debut, ligne.numero);
        return;
      }
      boitePieces(ligne, s.dataset.acte);
    };
  });
}

async function boitePieces(ligne, acte) {
  const mois = document.getElementById("mois").value;
  let r;
  try {
    r = await api("pieces-parties", { salarie: ligne.salarie, debut: ligne.debut });
  } catch (e) { dire(e.message, "erreur"); return; }
  const e = ligne.etats[acte] || {};
  const titre = acte === "dpae" ? "DPAE" : "Contrat";
  const pieces = (acte === "dpae" ? r.dpae : r.contrat) || [];
  const liste = pieces.length
    ? `<ul class="liste-pieces">${pieces.map((p, i) => `<li>
        <span><b>${echapper(p.quoi)}</b> — ${echapper(quand(p.quand))}
          <br><span class="discret">${echapper(p.fichier)}${p.existe ? ""
            : " — n'est plus dans le dossier du mois"}</span></span>
        <button class="secondaire p-ouvrir" data-i="${i}" ${p.existe ? "" : "disabled"}>Ouvrir</button>
      </li>`).join("")}</ul>`
    : `<p class="discret">${acte === "dpae"
        ? "Aucune DPAE déposée pour cette embauche."
        : e.recu ? "Le contrat a été noté signé à la main : aucun fichier n'est passé par le logiciel."
        : "Aucun contrat n'est parti à la signature pour cet engagement."}</p>`;
  const signature = acte === "signature";
  ouvrirBoite(`
    <h3>${titre} — ${echapper(ligne.nom)}</h3>
    <p class="discret">${echapper(pourQuoi(ligne))}, du ${echapper(jjmmaaaa(ligne.debut))}
      au ${echapper(jjmmaaaa(ligne.fin))}</p>
    <p>${echapper(infobulle(acte, titre, e, ligne))}</p>
    ${e.caduc ? `<div class="encart attention"><b>Ce contrat n'est plus le bon</b>
      ${echapper(e.pourquoi ? e.pourquoi.charAt(0).toUpperCase() + e.pourquoi.slice(1) + "."
                            : "La paie a changé depuis qu'il est parti.")}
      ${e.recu ? "Il est signé : il se modifie par un avenant, que le salarié signe à son tour."
               : "Le salarié doit recevoir le contrat à jour, et le signer à nouveau."}</div>` : ""}
    ${liste}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      ${signature && (e.fait || e.recu) ? `<button class="secondaire" id="p-recu">${e.recu
        ? "Retirer la mention « signé »" : "Noter le contrat signé reçu"}</button>` : ""}
      ${signature && e.fait ? `<button class="${e.caduc && e.recu ? "primaire" : "secondaire"}" id="p-avenant"
        title="Modifier le contrat parti : l'ancien texte et le nouveau, article par article">Avenant…</button>` : ""}
      ${signature && (e.caduc || !e.fait) && !(e.caduc && e.recu) && !(MOIS_FERME && MOIS_FORCE !== mois) ? `<button class="primaire" id="p-signer">${e.caduc
        ? "Renvoyer le contrat à jour…" : "Envoyer à la signature…"}</button>` : ""}
    </div>`);
  const avenantB = document.getElementById("p-avenant");
  if (avenantB) avenantB.onclick = () => { fermerBoite(); boiteAvenant(mois, ligne.salarie, ligne.debut, ligne.numero); };
  document.querySelectorAll(".p-ouvrir").forEach((b) => {
    b.onclick = async () => {
      try {
        await api("ouvrir-piece", { salarie: ligne.salarie, debut: ligne.debut,
                                    fichier: pieces[+b.dataset.i].fichier });
      } catch (err) { dire(err.message, "erreur"); }
    };
  });
  const recu = document.getElementById("p-recu");
  if (recu) recu.onclick = async () => {
    const oui = !e.recu;
    try {
      await api("contrat-recu", { mois, salarie: ligne.salarie, debut: ligne.debut, numero: ligne.numero || "", recu: oui });
      fermerBoite();
      dire(oui ? "Contrat signé reçu — noté au journal."
               : "Mention retirée : le contrat signé n'est pas là.");
      await dessinerEtatsDesPaies(mois);
      await rafraichirActions();
    } catch (err) { dire(err.message, "erreur"); }
  };
  const signer = document.getElementById("p-signer");
  if (signer) signer.onclick = () => { fermerBoite(); boiteSignature(mois, [ligne.salarie]); };
}

/** Peint les états sur les blocs. Rappelée après chaque frappe : changer le
 *  salarié ou les jours change la paie que le bloc désigne. */
function peindreEtats() {
  let refaire = false;
  document.querySelectorAll(".engagement").forEach((div) => {
    const cible = div.querySelector(".etats");
    if (!cible) return;
    const ps = paiesDuBloc(div);
    const lignes = ETATS_PAIES
      ? ps.map((p) => ETATS_PAIES[clePaie(p.salarie, p.debut)]).filter(Boolean)
      : [];
    avisDpaeDeplacee(div, ps, lignes.length === 1 ? lignes[0] : null);
    const connue = ps.length > 0 && lignes.length === ps.length;
    div.classList.toggle("enregistree", connue);
    if (!ETATS_PAIES) { cible.innerHTML = ""; return; }
    if (!connue) {
      fermerEdition(div, false);
      if (!salariesDuBloc(div).length) {
        // Sans salarié, ce bloc n'est pas une paie : il n'est même pas
        // enregistré. Le dire, plutôt que de laisser un bloc muet qu'on
        // ne peut ni valider ni faire partir.
        cible.innerHTML = `<p class="etats-absent">Choisir qui est engagé.</p>
           <div class="validation"><span class="boutons">${BOUTON_RETIRER}</span></div>`;
        brancherRetirer(div);
        return;
      }
      // Le cas courant et normal : une paie qu'on vient d'ajouter ou de
      // changer. Pas de pastille grise — une pastille, même grise, se lit
      // comme un état connu. Le message ne dit plus « Enregistrer la saisie
      // d'abord » : le bouton n'existe plus, l'enregistrement se fait tout
      // seul une seconde après la frappe, et il n'y a donc rien à faire —
      // seulement à attendre que l'écran se rattrape.
      // Plus de message ici (30/09/2026) : « Pas encore dans la saisie
      // enregistrée… » s'affichait en orange sur chaque carte à l'ouverture,
      // le temps d'un aller-retour, et se lisait comme un souci.
      cible.innerHTML = `<div class="validation"><span class="boutons">${BOUTON_RETIRER}</span></div>`;
      brancherRetirer(div);
      return;
    }
    if (lignes.length === 1) {
      const ligne = lignes[0];
      const contrat = ligne.contrat && !ligne.contrat.premier_mois
        ? ` <span class="discret">· contrat en cours depuis ${echapper(moisEnClair(ligne.contrat.depuis))}</span>`
        : ligne.contrat && !ligne.contrat.dernier_mois
          ? ` <span class="discret">· se poursuit jusqu'en ${echapper(moisEnClair(ligne.contrat.jusqu_a))}</span>`
          : "";
      div._ligne = ligne;
      const dp = ligne.etats.dpae || {};
      if (dp.fait && !dp.refusee) {
        div._dpaeFaite = { salarie: ligne.salarie, debut: ligne.debut,
                           nom: ligne.nom, quand: dp.fait };
      }
      cible.innerHTML = `<span class="etats-qui">${echapper(ligne.nom)}
          <span class="discret">— ${echapper(pourQuoi(ligne))}</span>${contrat}</span>`
        + bandeauEtats(ligne) + bandeauValidation(ligne);
      brancherValidation(div, ligne);
      brancherRecu(div);
      fermerEdition(div, !!ligne.valide);
      return;
    }
    // PLUSIEURS PAIES DANS UN BLOC : pas encore validées, sinon le bloc
    // aurait été démultiplié. Si l'une l'a été ailleurs (un autre onglet),
    // on démultiplie maintenant et on repeint.
    if (lignes.some((l) => l.valide)) { dedoubler(div); refaire = true; return; }
    cible.innerHTML = lignes.map((l) =>
      `<span class="etats-qui">${echapper(l.nom)}
         <span class="discret">— ${echapper(pourQuoi(l))}</span></span>` + bandeauEtats(l))
      .join("")
      + `<div class="validation">
           <span class="discret">${lignes.length} salariés dans cet engagement</span>
           <span class="boutons">
             ${BOUTON_RETIRER}
             <button class="secondaire v-valider-tout">Valider pour les ${lignes.length}</button>
           </span>
         </div>`;
    cible.querySelector(".v-valider-tout").onclick = (ev) => {
      ev.preventDefault();
      validerPlusieurs(div, lignes);
    };
    brancherRetirer(div);
    brancherRecu(div);
    fermerEdition(div, false);
  });
  if (refaire) return peindreEtats();
}

/** Valide chaque paie du bloc, PUIS le démultiplie : « il faut le bouton
 *  valider, et une fois validé ça se démultiplie ».
 *  Chaque bloc né ici se repeint validé, fermé, avec son propre
 *  « Modifier… ». Si une validation échoue, on s'arrête là : ce qui est
 *  validé l'est, le reste se voit au repeint. */
async function validerPlusieurs(div, lignes) {
  const mois = document.getElementById("mois").value;
  let faites = 0;
  try {
    for (const l of lignes) {
      await api("valider-paie", { mois, salarie: l.salarie, debut: l.debut,
                                  valide: true, forcer: MOIS_FORCE === mois });
      faites += 1;
    }
    dire(`${faites} engagements validés.`);
  } catch (e) {
    dire(e.message + (faites ? ` (${faites} validé(s) avant)` : ""),
         "erreur");
  }
  if (faites) dedoubler(div);
  await dessinerEtatsDesPaies(mois);
}

/** Lit `etat-par-paie` et repeint. */
async function dessinerEtatsDesPaies(mois) {
  ETATS_PAIES = null;
  if (!mois) { peindreEtats(); return; }
  try {
    const r = await api("etat-par-paie", { mois });
    ETATS_PAIES = {};
    r.paies.forEach((l) => { ETATS_PAIES[clePaie(l.salarie, l.debut)] = l; });
  } catch (e) {
    // Mois jamais enregistré, spectacle manquant, saisie en cours : il n'y a
    // rien à peindre, et rien d'alarmant à dire. La saisie, elle, marche.
    ETATS_PAIES = {};
  }
  peindreEtats();
}

/* ------------------------------------------------ valider une paie
   « On valide, c'est vert, normalement on n'y revient pas, édition bloquée
   temporairement avec un bouton pour modifier avec avertissement » —
   11 et 12/09/2026.

   Trois choses, et la troisième est celle qui compte.

   1. VERT, et sur le bloc entier. Une pastille de plus se serait perdue au
      milieu des quatre autres ; c'est le bloc qui change d'état, pas un
      détail dedans.
   2. ÉDITION FERMÉE. Les champs passent en lecture seule pour de vrai
      (`disabled`), pas seulement grisés : une paie validée qu'on peut encore
      modifier par distraction n'est pas validée.
   3. L'AVERTISSEMENT DIT CE QUE L'ÉDITEUR A DIT. Pas « êtes-vous sûr ? », qui
      ne renseigne personne — mais la conséquence exacte qu'il a lui-même
      nommée : modifier une paie validée peut obliger à refaire la DPAE. Et
      quand la DPAE est DÉJÀ partie pour cette paie, l'écran le sait
      (`etat_par_paie`) et le dit avec sa date. C'est la différence entre un
      avertissement qu'on lit et un avertissement qu'on clique. */

/** Ferme ou rouvre les champs d'un bloc. Le bouton de validation, lui, reste
 *  actif — sinon on ne pourrait plus rouvrir. */
function fermerEdition(div, ferme) {
  div.classList.toggle("validee", ferme);
  peindreCarte(div);
  div.querySelectorAll("input, select, button").forEach((c) => {
    if (c.classList.contains("v-basculer") || c.classList.contains("retirer-paie")) return;
    if (c.classList.contains("verrou")) return;    // un contrat en cours
    if (c.closest(".e-resume")) return;            // la ligne de la paie validée
    c.disabled = ferme;
  });
}

/* RETIRER UNE PAIE : un vrai bouton, en bas à droite, à côté de « Valider »
   — et non plus une petite croix à côté du métier (l'éditeur, 15/09/2026 :
   « plus clair, une case comme valider la paie, avec un avertissement »).
   L'avertissement n'est là que quand il y a quelque chose à perdre : une
   paie validée, un contrat envoyé à la signature ou revenu signé, une DPAE
   partie. Sinon le bloc s'en va, et l'enregistrement suit. */
const BOUTON_RETIRER = `<button class="lien retirer-paie" title="retirer cet engagement de la saisie">Retirer cet engagement</button>`;

/** Le bandeau de validation d'un bloc, sous les quatre pastilles. */
function bandeauValidation(ligne) {
  if (ligne.valide) {
    return `<div class="validation faite">
      <span><b>Engagement validé</b> le ${echapper(quand(ligne.valide))}</span>
      <span class="boutons">
        ${BOUTON_RETIRER}
        <button class="modifier v-basculer" data-valide="0">${CRAYON}Modifier…</button>
      </span>
    </div>`;
  }
  return `<div class="validation">
    <span class="boutons">
      ${BOUTON_RETIRER}
      <button class="primaire v-basculer" data-valide="1">Valider l'engagement</button>
    </span>
  </div>`;
}

/** Branche le bouton d'un bloc, une fois le bandeau posé. */
function brancherValidation(div, ligne) {
  const b = div.querySelector(".v-basculer");
  if (b) b.onclick = (ev) => {
    ev.preventDefault();
    if (b.dataset.valide === "1") return basculerValidation(ligne, true);
    boiteRouvrir(ligne);
  };
  brancherRetirer(div);
}

/** Le bouton « Retirer cette paie » d'un bloc, quel que soit son état. */
function brancherRetirer(div) {
  const b = div.querySelector(".retirer-paie");
  if (!b) return;
  b.onclick = (ev) => {
    ev.preventDefault();
    const lignes = paiesDuBloc(div)
      .map((p) => ETATS_PAIES && ETATS_PAIES[clePaie(p.salarie, p.debut)])
      .filter(Boolean);
    const risques = [];
    lignes.forEach((l) => {
      const qui = l.nom;
      if (l.valide) risques.push(`${qui} : paie validée le ${quand(l.valide)}`);
      const s = l.etats.signature || {};
      if (s.recu) risques.push(`${qui} : contrat ${signeLe(s.recu, s.recu_par)}`);
      else if (s.fait) risques.push(`${qui} : contrat envoyé à la signature le ${quand(s.fait)}`);
      const d = l.etats.dpae || {};
      if (d.fait && !d.refusee) risques.push(`${qui} : DPAE déposée le ${quand(d.fait)}`);
    });
    const retirer = () => { div.remove(); rafraichirApercu(); dire("Engagement retiré."); };
    if (!risques.length) return retirer();
    ouvrirBoite(`
      <h3>Retirer cet engagement ?</h3>
      <div class="encart attention">
        <b>Quelque chose est déjà parti ou acté pour cet engagement</b>
        <ul>${risques.map((r) => `<li>${echapper(r)}</li>`).join("")}</ul>
      </div>
      <p class="note">Retirer l'engagement ne défait rien de tout cela : une DPAE
        déposée reste déposée à l'Urssaf, un contrat envoyé reste envoyé. Si
        l'embauche n'a pas lieu, c'est une annulation de DPAE qu'il faut faire,
        pas un retrait à l'écran. Le journal garde ce qui est parti.</p>
      <div class="actions">
        <button class="secondaire" onclick="fermerBoite()">Garder la paie</button>
        <button class="primaire" id="r-retirer">Retirer quand même</button>
      </div>`);
    document.getElementById("r-retirer").onclick = () => { fermerBoite(); retirer(); };
  };
}

async function basculerValidation(ligne, valide) {
  const mois = document.getElementById("mois").value;
  try {
    await api("valider-paie", { mois, salarie: ligne.salarie,
                                debut: ligne.debut, valide,
                                forcer: MOIS_FORCE === mois });
    dire(valide ? "Engagement validé." : "Engagement rouvert.");
    await dessinerEtatsDesPaies(mois);
  } catch (e) { dire(e.message, "erreur"); }
}

/* LES PAIES VALIDÉES ENSEMBLE SE ROUVRENT ENSEMBLE (24/09/2026). « Valider
 * ces 2 paies » les valide d'un geste, au même instant, puis l'écran les
 * sépare en un bloc par salarié. Les rouvrir demandait autant de boîtes que
 * de salariés, pour la même paie. Sœurs : même spectacle, mêmes bornes,
 * validées à la même seconde. */
function paiesSoeurs(ligne) {
  const toutes = Object.values(ETATS_PAIES || {});
  const soeurs = toutes.filter((l) => l.valide && l.valide === ligne.valide
    && l.spectacle === ligne.spectacle && l.debut === ligne.debut && l.fin === ligne.fin);
  return soeurs.length ? soeurs : [ligne];
}

async function rouvrirPaies(lignes) {
  const mois = document.getElementById("mois").value;
  try {
    for (const l of lignes) {
      await api("valider-paie", { mois, salarie: l.salarie, debut: l.debut, valide: false,
                                  forcer: MOIS_FORCE === mois });
    }
    dire(lignes.length > 1 ? `Ces ${lignes.length} engagements sont rouverts.`
                           : "Engagement rouvert.");
  } catch (e) { dire(e.message, "erreur"); }
  await dessinerEtatsDesPaies(mois);
}

/* Rouvrir demande un mot, pas un clic — QUAND IL Y A QUELQUE CHOSE À DIRE.
 * Depuis le 24/09/2026, une paie dont rien n'est parti se rouvre
 * directement. Depuis le 30/09/2026, la boîte ne parle plus de la DPAE
 * (l'utilisateur : « seulement quand on change les DATES ») : changer le cachet ou
 * les heures ne touche pas la DPAE, c'est LE CONTRAT qui devient caduc, et
 * qu'il faut renvoyer au salarié. La boîte n'est donc là que pour un contrat
 * parti ; la DPAE se dit au moment où l'on change vraiment le premier jour
 * ou le salarié (`avisDpaeDeplacee`). */
function boiteRouvrir(ligne) {
  const lignes = paiesSoeurs(ligne);
  const partis = lignes.filter((l) => l.etats && l.etats.signature
    && (l.etats.signature.fait || l.etats.signature.recu));
  if (!partis.length) return rouvrirPaies(lignes);
  const noms = lignes.map((l) => l.nom).join(", ");
  const etat = (l) => {
    const s = l.etats.signature;
    return s.recu ? signeLe(s.recu, s.recu_par) : "envoyé le " + quand(s.fait);
  };
  ouvrirBoite(`
    <h3>Modifier ${lignes.length > 1 ? `ces ${lignes.length} engagements` : "cet engagement"}</h3>
    <p class="discret">${echapper(noms)} — ${echapper(ligne.spectacle)},
      du ${echapper(jjmmaaaa(ligne.debut))} au ${echapper(jjmmaaaa(ligne.fin))}
      · validée${lignes.length > 1 ? "s" : ""} le ${echapper(quand(ligne.valide))}</p>
    <div class="encart attention">
      <b>${partis.length > 1 ? "Les contrats sont déjà partis" : "Le contrat est déjà parti"}</b>
      ${partis.map((l) => `${lignes.length > 1 ? echapper(l.nom) + " : c" : "C"}ontrat ${echapper(etat(l))}.`).join(" ")}
      Il porte les dates, les heures, les cachets et la rémunération : si
      l'un d'eux change, ce contrat n'est plus le bon. Sa pastille passera au
      rouge, et il faudra renvoyer le contrat à jour au salarié.
    </div>
    <p class="note">Modifier n'annule rien et ne défait rien : ça remet les
      champs en écriture. On revalide ensuite.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="v-rouvrir">Modifier ${lignes.length > 1 ? "les paies" : "la paie"}</button>
    </div>`);
  document.getElementById("v-rouvrir").onclick = async () => {
    fermerBoite();
    await rouvrirPaies(lignes);
  };
}

/* LA DPAE NE SE DIT QUE SUR CE QU'ELLE DÉCLARE (30/09/2026). L'utilisateur :
 * l'avertissement doit correspondre aux vraies attentes de la DPAE, rien
 * d'inventé. Ce qu'elle déclare, c'est R1221-1 du code du travail : le
 * salarié, la date et l'heure d'embauche, la nature et la durée du contrat
 * (sa date de fin, pour un CDD) — ni la rémunération, ni les heures, ni les
 * cachets. L'encart ne paraît donc que si l'une de ces données s'écarte de
 * la DPAE déposée : premier jour ou salarié (le bloc retient l'embauche
 * déclarée la dernière fois qu'il l'a lue), ou fin du contrat
 * (`fin_declaree`, lue au journal du dépôt). Et il dit ce que dit l'Urssaf,
 * page « DPAE » d'urssaf.fr, mise à jour le 15/07/2026 : les informations
 * relatives au contrat de travail se modifient dans l'espace en ligne
 * (Compte › Embauche › Modifier une DPAE) ; pour toute autre modification,
 * une nouvelle DPAE, ou les services de l'Urssaf (3957). Rien de plus : ni
 * délai, ni annulation, qu'aucune source officielle lue ne pose. */
const URSSAF_DPAE = "https://www.urssaf.fr/accueil/employeur/embaucher-gerer-salaries/embaucher/declaration-prealable-embauche.html";

function avisDpaeDeplacee(div, ps, ligne) {
  const cible = div.querySelector(".etats");
  let avis = div.querySelector(".avis-dpae");
  const d = div._dpaeFaite;
  const ecarts = [];
  if (d && !ps.some((p) => p.salarie === d.salarie && p.debut === d.debut)) {
    ecarts.push(ps.some((p) => p.salarie === d.salarie)
      ? `premier jour : la DPAE déclare le ${jjmmaaaa(d.debut)}`
      : `salarié : la DPAE déclare ${d.nom}`);
  }
  const dp = ligne && ligne.etats && ligne.etats.dpae;
  if (dp && dp.fait && !dp.refusee && dp.fin_declaree && dp.fin_declaree !== ligne.fin) {
    ecarts.push(`fin du contrat : la DPAE déclare le ${jjmmaaaa(dp.fin_declaree)},
      la paie dit le ${jjmmaaaa(ligne.fin)}`);
  }
  if (!ecarts.length) { if (avis) avis.remove(); return; }
  if (!avis) {
    avis = document.createElement("div");
    avis.className = "encart attention avis-dpae";
    cible.parentNode.insertBefore(avis, cible);
  }
  const quandDpae = d ? d.quand : dp.fait;
  avis.innerHTML = `<b>La paie ne correspond plus à la DPAE déposée le ${echapper(quand(quandDpae))}</b>
    <ul>${ecarts.map((x) => `<li>${echapper(x)}</li>`).join("")}</ul>
    Selon l'Urssaf, les informations relatives au contrat de travail se
    modifient dans son espace en ligne (Compte › Embauche › Modifier une
    DPAE) ; pour toute autre modification, on dépose une nouvelle DPAE ou on
    contacte l'Urssaf (3957).
    <a href="${URSSAF_DPAE}" target="_blank" rel="noopener">La page de l'Urssaf</a>`;
}

/* PLUS DE CASE DE SÉLECTION NI DE BARRE D'ACTIONS GROUPÉES (15/09/2026) :
 * « on pourrait enlever la petite coche de sélection, tout se fait
 * directement quand on clique sur le bouton déposer DPAE ou demander les
 * signatures ». Les deux boîtes de la colonne de droite listent chaque
 * contrat du mois avec sa case, cochée d'avance sur ce qui reste à faire :
 * c'est là que l'on choisit, et rien ne part sans y être passé. */

/* LA BOÎTE DPAE, comme celle des signatures (l'éditeur, 15/09/2026 : « qu'il
 * y ait la liste déroulante et que soient déjà sélectionnés les contrats qui
 * n'ont pas de DPAE »). Chaque contrat du mois enregistré, une case ; cochée
 * d'avance si aucune DPAE n'est partie, ou si elle a été refusée. Un contrat
 * en cours depuis un mois précédent n'a pas de DPAE ce mois-ci : il se voit,
 * grisé, avec le mois où elle a été faite.
 *
 * DEUX TEMPS, ET C'EST VOULU : on ÉCRIT le fichier des embauches cochées,
 * puis on ouvre le récapitulatif de dépôt habituel. Écrire n'envoie rien et
 * ne consomme aucun compteur ; le dépôt reste le même geste, avec la même
 * relecture ligne à ligne et le même mot de passe. Le fichier prend un nom
 * horodaté, à côté du fichier complet du mois, jamais par-dessus. */
async function boiteDpae(mois) {
  if (!mois) { dire("Choisir un mois."); return; }
  // LA SAISIE À L'ÉCRAN D'ABORD (ticket #105, 02/10/2026). Cette boîte lit la
  // saisie ENREGISTRÉE : une paie tapée il y a moins d'une seconde, ou qu'un
  // spectacle manquant empêche d'enregistrer, n'y figurerait pas -- et sa
  // DPAE ne partirait pas, sans que rien ne le dise.
  let pasEnregistre = "";
  const ecran = document.getElementById("mois");
  if (ecran && ecran.value === mois && typeof enregistrerSaisie === "function") {
    clearTimeout(MINUTEUR_SAISIE);
    await enregistrerSaisie(true);
    if (JSON.stringify(saisieCourante()) !== DERNIERE_ECRITE) {
      pasEnregistre = document.getElementById("note-saisie").textContent
        || "La saisie à l'écran n'est pas enregistrée.";
    }
  }
  let r;
  try {
    r = await api("etat-par-paie", { mois });
  } catch (e) {
    dire("Rien d'enregistré pour " + moisEnClair(mois) + " : saisir une paie d'abord.");
    return;
  }
  const lignes = r.paies || [];
  if (!lignes.length) { dire("Aucune paie enregistrée en " + moisEnClair(mois) + "."); return; }
  const embauche = (l) => !l.contrat || l.contrat.premier_mois;
  // Déjà partie ET pas refusée : elle ne repart pas. Une refusée, si — c'est
  // même la seule raison de redéposer.
  const aFaire = (l) => embauche(l) && (!l.etats.dpae.fait || l.etats.dpae.refusee);

  ouvrirBoite(`
    <h3>Envoyer les DPAE</h3>
    ${moisEnGros(mois)}
    ${pasEnregistre ? `<div class="encart attention"><b>Une partie de l'écran
      n'est pas enregistrée</b> ${echapper(pasEnregistre)} Les paies qui ne
      figurent pas ci-dessous n'auront pas leur DPAE : compléter la saisie,
      puis rouvrir cette fenêtre.</div>` : ""}
    <p class="note">Cochées d'avance : les embauches sans DPAE, ou dont la
      DPAE a été refusée. Une DPAE déjà passée ne se redéclare pas : l'Urssaf
      recevrait deux déclarations pour un seul contrat.</p>
    <div class="liste-choix">
      ${lignes.map((l, i) => {
        const e = l.etats.dpae;
        const etat = !embauche(l)
          ? `<br><span class="pastille">contrat en cours depuis
               ${echapper(moisEnClair(l.contrat.depuis))} — sa DPAE a été faite ce mois-là</span>`
          : !e.fait ? `<br><span class="pastille alerte">à déclarer</span>`
          : e.refusee
          ? `<br><span class="pastille erreur">refusée le ${echapper(quand(e.fait))}
               — ${echapper((e.anomalies || []).join(" ; ") || "motif non lu")}
               — à redéclarer</span>`
          : e.passee
          ? `<br><span class="pastille bien">déclarée le ${echapper(quand(e.fait))}
               — passée${echapper(dossierUrssaf(e))}</span>`
          : `<br><span class="pastille alerte">déclarée le ${echapper(quand(e.fait))}
               — retour pas encore arrivé : on attend, on ne renvoie pas</span>`;
        return `<label class="choix ${embauche(l) ? "" : "grise"}">
          <input type="checkbox" class="d-qui" data-i="${i}" ${aFaire(l) ? "checked" : ""}
                 ${embauche(l) ? "" : "disabled"}>
          <span><b>${echapper(l.nom)}</b> — ${echapper(l.spectacle)}, embauche le
            ${echapper(jjmmaaaa(l.debut))}${l.numero
              ? ` <span class="discret">(contrat n° ${echapper(l.numero)})</span>` : ""}
            ${etat}</span></label>`;
      }).join("")}
    </div>
    <p class="note">Heure d'embauche déclarée : 08h00. Toutes les embauches
      cochées partent ensemble, dans un seul dépôt. D'abord le test, qui ne
      déclare rien ; une fois le test revenu conforme, l'envoi réel.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      <button class="primaire" id="d-ecrire">Envoyer le test…</button>
    </div>`);

  const bouton = document.getElementById("d-ecrire");
  const majBouton = () => {
    const n = document.querySelectorAll(".d-qui:checked").length;
    bouton.disabled = !n;
    bouton.textContent = n ? `Envoyer le test (${n} embauche${n > 1 ? "s" : ""})…` : "Rien de coché";
  };
  document.querySelectorAll(".d-qui").forEach((c) => { c.onchange = majBouton; });
  majBouton();
  bouton.onclick = async () => {
    const choisies = [...document.querySelectorAll(".d-qui:checked")]
      .map((c) => lignes[+c.dataset.i]);
    if (!choisies.length) return;
    const rendre = occupe(bouton, "Fabrication du fichier en cours…");
    try {
      const w = await api("dpae", {
        mois, paies: choisies.map((l) => ({ salarie: l.salarie, debut: l.debut })),
      });
      fermerBoite();
      // Le dossier porte le fichier à déposer et son récapitulatif ; c'est le
      // premier qui se dépose.
      const f = (w.fichiers || []).find(
        (x) => /\.txt$/i.test(x.nom) && !/recapitulatif/i.test(x.nom));
      dire("Fichier écrit : " + (f ? f.nom : w.dossier));
      await rafraichirActions();
      if (f) boiteDepot("dpae", f.chemin, { testerDabord: true });
    } catch (e) {
      rendre();
      dire(e.message, "erreur");
    }
  };
}

/* =======================================================================
   CONFIGURATION
   ===================================================================== */
let FICHE_ACTIVE = "salarie";
let CLE_ACTIVE = null;
/* Une fiche neuve est ouverte : `dessinerConfig` ne l'efface pas. */
let FICHE_NEUVE = false;

document.querySelectorAll(".sous-onglets button").forEach((b) => {
  b.onclick = async () => {
    if (!(await quitterLaFiche())) return;
    document.querySelectorAll(".sous-onglets button").forEach((x) => x.classList.remove("actif"));
    b.classList.add("actif");
    if (FICHE_ACTIVE !== b.dataset.fiche) FICHE_NEUVE = false;
    FICHE_ACTIVE = b.dataset.fiche;
    CLE_ACTIVE = null;
    dessinerConfig();
  };
});

const ARCHIVES_VISIBLES = { salarie: false, spectacle: false };
/* Ce qu'on cherche dans chaque liste ; gardé quand la liste se redessine. */
const RECHERCHE = { salarie: "", spectacle: "" };

function fichesDe(nom) {
  const c = ETAT.configuration;
  if (nom === "entreprise") return [c.entreprise];
  return nom === "salarie" ? c.salaries : c.spectacles;
}

function dessinerConfig() {
  const liste = document.getElementById("config-liste");
  if (FICHE_ACTIVE === "importer") {
    document.getElementById("config-formulaire").innerHTML = "";
    dessinerImportation(liste);
    return;
  }
  if (FICHE_ACTIVE === "coffre") {
    document.getElementById("config-formulaire").innerHTML = "";
    dessinerCoffre(liste);
    return;
  }
  if (FICHE_ACTIVE === "identite") {
    document.getElementById("config-formulaire").innerHTML = "";
    dessinerIdentite(liste);
    return;
  }
  if (FICHE_ACTIVE === "metiers") {
    document.getElementById("config-formulaire").innerHTML = "";
    dessinerMetiers(liste);
    return;
  }
  if (FICHE_ACTIVE === "organismes") {
    document.getElementById("config-formulaire").innerHTML = "";
    dessinerOrganismes(liste);
    return;
  }
  const fiches = fichesDe(FICHE_ACTIVE);
  if (FICHE_ACTIVE === "entreprise") {
    liste.innerHTML = "";
    peindreDemarrage(liste);
    CLE_ACTIVE = null;
    dessinerFormulaire(fiches[0]);
    return;
  }
  // Les archives en dernier, jamais melangees aux courantes. Elles restent
  // trouvables : une fiche qu'on ne voit plus passe pour perdue, et on la
  // ressaisit -- avec un deuxieme code salarie, ce qui serait pire.
  const courantes = fiches.filter((f) => f.donnees.actif !== false);
  // Les spectacles par titre.
  if (FICHE_ACTIVE === "spectacle") {
    courantes.sort((a, b) => String(a.donnees.titre || "").localeCompare(
      String(b.donnees.titre || ""), "fr", { sensitivity: "base" }));
  }
  // Les numéros d'objet archivés, du plus récent au plus ancien.
  const archivees = fiches.filter((f) => f.donnees.actif === false)
    .sort((a, b) => String(b.donnees.numero_objet || "").localeCompare(
      String(a.donnees.numero_objet || "")));
  const rangees = [...courantes, ...archivees];
  const salarie = FICHE_ACTIVE === "salarie";

  // UN SPECTACLE, PAS UNE FICHE PAR NUMÉRO (§94). Une fiche archivée du
  // même titre qu'un spectacle actif (un ancien numéro) se montre sous lui,
  // pas dans les archives.
  const titreDe = (d) => String(d.titre || "").normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\s+/g, " ").trim();
  const sansTitre = (d) => titreDe(d) === "a completer";
  const passees = {};
  const sousUnActif = new Set();
  if (!salarie) {
    const titresActifs = new Set(courantes.map((f) => titreDe(f.donnees)));
    archivees.forEach((f) => {
      const t = titreDe(f.donnees);
      if (sansTitre(f.donnees) || !titresActifs.has(t)) return;
      (passees[t] = passees[t] || []).push(f);
      sousUnActif.add(f.cle);
    });
  }
  // Les archives qui restent : les spectacles qui ne se jouent plus, par
  // titre ; puis les numéros sans titre, groupés -- à nommer si on le sait.
  const archiveesSeules = archivees.filter((f) => !sousUnActif.has(f.cle))
    .sort((a, b) => (sansTitre(a.donnees) - sansTitre(b.donnees))
      || titreDe(a.donnees).localeCompare(titreDe(b.donnees))
      || String(b.donnees.numero_objet || "").localeCompare(String(a.donnees.numero_objet || "")));

  // UNE LIGNE PAR FICHE (l'éditeur, 24/09/2026 : « j'aime bien les lignes pour
  // les salariés »). Elle remplace la grille de cartes : le nom, ce qui
  // l'identifie, son état, puis les gestes -- « Archiver » dit en toutes
  // lettres, là où le clic sur toute la carte archivait sans prévenir.
  const rangHtml = (f, trouve) => {
    const d = f.donnees;
    const err = f.anomalies.filter((a) => a.gravite === "erreur").length;
    const av = f.anomalies.length - err;
    const archive = d.actif === false;
    const titre = salarie
      ? `${d.nom || ""} ${d.prenom_affichage || d.prenom || ""}`.trim()
      : String(d.titre || "").trim();
    // Un numero d'objet importe de CoolPaie n'a pas de titre : le moteur
    // pose « A COMPLETER », que la ligne dit en minuscules.
    const aCompleter = !salarie && titre.toUpperCase() === "A COMPLETER";
    const quoi = salarie
      ? [d.emploi_affichage || d.emploi || "", d.code_salarie ? "matricule " + d.code_salarie : ""]
      : [d.numero_objet || "", d.code_analytique ? "analytique " + d.code_analytique : ""];
    const autresNumeros = !salarie && !archive && !trouve ? (passees[titreDe(d)] || [])
      .slice().sort((a, b) => String(b.donnees.numero_objet || "").localeCompare(
        String(a.donnees.numero_objet || ""))) : [];
    const etat = archive ? `<span class="pastille archive">archivé</span>`
      : err ? `<span class="pastille erreur">${err} erreur${err > 1 ? "s" : ""}</span>`
      : av ? `<span class="pastille alerte">${av} à vérifier</span>`
      : `<span class="pastille bien">complet</span>`;
    return `<div class="rang fiche${archive ? " archivee" : ""}${f.cle === CLE_ACTIVE ? " selectionnee" : ""}"
        data-cle="${echapper(f.cle)}">
      <div class="rang-infos">
        <b class="rang-nom">${aCompleter ? `<span class="a-completer">titre à compléter</span>`
          : echapper(titre || f.cle)}</b>
        ${echapper(quoi.filter(Boolean).join(" · "))}
        ${trouve ? `<span class="trouve">trouvé dans ${echapper(trouve.ou)} : « ${echapper(trouve.quoi)} »</span>` : ""}
        ${autresNumeros.length ? `<span class="annees">anciens numéros :
          ${autresNumeros.map((p) => `<button class="lien" data-ouvrir="${echapper(p.cle)}">${
            echapper(p.donnees.numero_objet || p.cle)}</button>`).join(" · ")}</span>` : ""}
      </div>
      <div class="rang-etat">${etat}</div>
      <div class="rang-actions">
        <button class="lien" data-activer="${archive ? "oui" : "non"}">${archive ? "Réactiver" : "Archiver"}</button>
        <button class="modifier" title="Modifier la fiche">${CRAYON}Modifier</button>
      </div>
    </div>`;
  };

  // CACHÉES PAR DÉFAUT (l'éditeur, 23/09/2026) : un spectacle archivé ne
  // se joue plus. Une case les montre ; elle reste
  // cochée tant qu'on ne la décoche pas, et une fiche archivée ouverte les
  // montre d'office.
  const voirArchives = ARCHIVES_VISIBLES[FICHE_ACTIVE]
    || archivees.some((f) => f.cle === CLE_ACTIVE);
  // UNE BARRE, DEUX GESTES : chercher, ajouter. Le titre qui répétait le
  // sous-onglet (« SALARIÉS » sous Salariés) est parti (24/09/2026).
  liste.innerHTML = `<div class="barre-liste">
      <input type="search" id="config-recherche" class="recherche" autocomplete="off"
        value="${echapper(RECHERCHE[FICHE_ACTIVE] || "")}"
        placeholder="${salarie
          ? "Rechercher dans toutes les fiches : nom, NIR, adresse, courriel, emploi…"
          : "Rechercher : titre, numéro d'objet, code analytique…"}">
      <button class="secondaire" id="config-nouvelle">+ ${salarie
        ? "un salarié" : "un spectacle"}</button>
    </div>
    <div id="config-rangs"></div>`
    + (salarie ? fichesAttenduesHtml() : "");

  // LA RECHERCHE DANS TOUS LES CHAMPS (l'éditeur, 24/09/2026). Chaque valeur
  // de la fiche, les anciennes valeurs datées comprises (un courriel changé
  // retrouve encore la personne), sans accents, sans majuscules, sans
  // espaces (« 2 93 08 » trouve le NIR) ; une date se cherche aussi comme
  // on l'écrit (23/07/1990). Plusieurs mots : chacun doit se trouver
  // quelque part dans la fiche. Elle fouille les archivées aussi -- c'est
  // souvent là qu'on cherche.
  const libelles = {};
  (ETAT.configuration.description[FICHE_ACTIVE] || []).forEach((c) => { libelles[c.cle] = c.libelle; });
  const libelleDe = (cle) => libelles[cle] || libelles[cle.replace(/_affichage$/, "")]
    || cle.replace(/_/g, " ");
  const plat = (t) => String(t).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  const valeurs = (f) => {
    const out = [];
    const ajouter = (ou, v) => {
      if (v === null || v === undefined || v === "" || typeof v === "boolean") return;
      if (typeof v === "object") {
        Object.entries(v).forEach(([k, x]) => { if (!k.startsWith("_")) ajouter(ou, x); });
        return;
      }
      const t = String(v);
      out.push({ ou, quoi: t });
      if (/^\d{4}-\d{2}-\d{2}$/.test(t)) out.push({ ou, quoi: jjmmaaaa(t) });
    };
    // La forme lisible d'abord (« Avallon »), la forme déclarée ensuite
    // (« AVALLON ») : c'est la première trouvée que la ligne cite.
    Object.entries(f.donnees)
      .sort(([a], [b]) => b.endsWith("_affichage") - a.endsWith("_affichage"))
      .forEach(([k, v]) => {
        if (k.startsWith("_") || k === "historique" || k === "actif") return;
        ajouter(libelleDe(k), v);
      });
    (f.donnees.historique || []).forEach((h) =>
      ajouter(libelleDe(h.champ) + " (ancienne valeur)", h.valeur));
    return out.map((x) => ({ ...x, cle: plat(x.quoi), serre: plat(x.quoi).replace(/\s+/g, "") }));
  };
  const chercher = (f, mots) => {
    const vs = valeurs(f);
    let premier = null;
    for (const m of mots) {
      const serre = m.replace(/\s+/g, "");
      const v = vs.find((x) => x.cle.includes(m) || x.serre.includes(serre));
      if (!v) return null;
      premier = premier || v;
    }
    return premier || {};
  };

  // Les numéros sans titre (importés des DSN, « A COMPLETER ») en un groupe,
  // sous une phrase qui dit d'où ils viennent et ce qu'on peut en faire.
  const archivesHtml = () => {
    const nommees = archiveesSeules.filter((f) => salarie || !sansTitre(f.donnees));
    const anonymes = salarie ? [] : archiveesSeules.filter((f) => sansTitre(f.donnees));
    const ans = anonymes.map((f) => anDe(f.donnees)).filter(Boolean);
    return `${nommees.length ? `<div class="rangs">${nommees.map((f) => rangHtml(f)).join("")}</div>` : ""}
      ${anonymes.length ? `<p class="note">${anonymes.length} numéro${anonymes.length > 1 ? "s" : ""}
        sans titre, trouvé${anonymes.length > 1 ? "s" : ""} dans les DSN${ans.length
          ? ` de ${Math.min(...ans)}${Math.max(...ans) !== Math.min(...ans) ? "–" + Math.max(...ans) : ""}` : ""}
        — les nommer si vous savez à quel spectacle ils étaient (« Modifier »).</p>
        <div class="rangs">${anonymes.map((f) => rangHtml(f)).join("")}</div>` : ""}`;
  };

  const peindre = () => {
    const q = plat(RECHERCHE[FICHE_ACTIVE] || "").trim();
    const cible = document.getElementById("config-rangs");
    if (q) {
      const mots = q.split(/\s+/);
      const trouvees = rangees.map((f) => ({ f, t: chercher(f, mots) })).filter((x) => x.t);
      // Où l'on a trouvé, sauf si c'est le nom même qu'on lit sur la ligne.
      cible.innerHTML = trouvees.length
        ? `<div class="rangs">${trouvees.map(({ f, t }) =>
            rangHtml(f, t.ou && !/^(nom|prénom|titre)/i.test(t.ou) ? t : null)).join("")}</div>
          <p class="note">${trouvees.length} fiche${trouvees.length > 1 ? "s" : ""} sur ${rangees.length},
            archivées comprises.</p>`
        : `<p class="discret">Aucune fiche ne contient « ${echapper(RECHERCHE[FICHE_ACTIVE])} »,
            archivées comprises.</p>`;
    } else {
      cible.innerHTML = `${courantes.length
          ? `<div class="rangs">${courantes.map((f) => rangHtml(f)).join("")}</div>`
          : `<p class="discret">${salarie ? "Aucun salarié actif." : "Aucun spectacle actif."}</p>`}
        ${archiveesSeules.length ? `<label class="coche montrer-archives">
            <input type="checkbox" id="config-archives"${voirArchives ? " checked" : ""}>
            ${salarie ? "Afficher les salariés archivés" : "Afficher les spectacles archivés"}
            <span class="discret">(${archiveesSeules.length}) — ${salarie ? "partis ; leurs documents restent"
              : "ceux qui ne se jouent plus ; les AEM déposées portent leurs numéros"}</span></label>
          ${voirArchives ? archivesHtml() : ""}` : ""}`;
      const caseArchives = document.getElementById("config-archives");
      if (caseArchives) caseArchives.onchange = () => {
        ARCHIVES_VISIBLES[FICHE_ACTIVE] = caseArchives.checked;
        dessinerConfig();
      };
    }
    cible.querySelectorAll(".rang.fiche").forEach((r) => {
      const cle = r.dataset.cle;
      const nom = r.querySelector(".rang-nom").textContent.trim();
      r.querySelector("[data-activer]").onclick = async (e) => {
        const activer = e.currentTarget.dataset.activer === "oui";
        try {
          await api("activer-fiche", { nom: FICHE_ACTIVE, cle, actif: activer });
          ETAT = await api("etat");
          dire(`${nom} : ${activer ? "réactivé" : "archivé"}.`);
          dessinerConfig();
        } catch (err) { dire(err.message, "erreur"); }
      };
      const ouvrir = async (c) => {
        if (c !== CLE_ACTIVE && !(await quitterLaFiche())) return;
        CLE_ACTIVE = c;
        FICHE_NEUVE = false;
        dessinerConfig();
        dessinerFormulaire(rangees.find((f) => f.cle === c));
        document.getElementById("config-formulaire").scrollIntoView({ behavior: "smooth" });
      };
      r.querySelector(".modifier").onclick = () => ouvrir(cle);
      r.querySelectorAll("[data-ouvrir]").forEach((b) => { b.onclick = () => ouvrir(b.dataset.ouvrir); });
    });
  };
  peindre();
  const recherche = document.getElementById("config-recherche");
  recherche.oninput = () => { RECHERCHE[FICHE_ACTIVE] = recherche.value; peindre(); };
  document.getElementById("config-nouvelle").onclick = () => nouvelleFiche(FICHE_ACTIVE);
  brancherFichesAttendues();
  if (!CLE_ACTIVE && !FICHE_NEUVE) document.getElementById("config-formulaire").innerHTML = "";
}

/* ---------------------------------------------------- l'import CoolPaie
   Deux temps, et jamais un seul : l'aperçu dit ce qui serait créé et ce que
   les DSN disaient autrement que les fiches ; le bouton n'écrit qu'après.
   Une fiche existante n'est jamais modifiée par l'import — la fiche fait
   foi, un changement se date à la main (operations_fiches). */
let IMPORT_EXPORT = "";

/* REPRENDRE L'HISTORIQUE (24/09/2026). La page ne sert qu'une fois : le jour
   où une compagnie arrive d'un autre logiciel. Elle disait « Importer de
   CoolPaie » -- mais l'import lit les DSN de n'importe quel logiciel
   depuis le 23/09 -- et reproposait son formulaire comme si rien n'avait eu
   lieu. Maintenant : si l'historique est repris, elle le dit (quand, combien,
   de quand à quand) et garde « Relire un dossier » pour ce qui manquait ;
   sinon, elle explique en une phrase et demande le dossier. */
async function dessinerImportation(cible) {
  let e = null;
  try { e = await api("importation-etat"); } catch (err) { e = null; }
  const formulaire = `<div class="e-contrat-champs">
      <label style="flex:1">Le dossier où l'ancien logiciel garde ses DSN
        <span class="discret">— pour CoolPaie, son dossier <code>export/</code></span>
        <span style="display:flex;gap:6px">
          <input type="text" id="import-export" style="flex:1" placeholder="vide : celui trouvé à côté des données"
                 value="${echapper(IMPORT_EXPORT)}">
          <button type="button" class="secondaire" id="import-parcourir">Parcourir…</button>
        </span>
      </label>
      <button class="secondaire" id="import-apercu">Voir ce qui serait repris</button>
    </div>
    <div id="import-resultat"></div>`;
  const deja = e && e.contrats;
  cible.innerHTML = `
    <p class="intro">Ce qu'un autre logiciel de paie a déjà déclaré ne se ressaisit pas :
      les salariés, les numéros d'objet des spectacles, et chaque contrat attesté à
      France Travail — c'est cet historique qui compte pour les droits (507 heures).</p>
    <div class="carte">
      ${deja ? `<div class="rang">
          <div class="rang-infos"><b class="rang-nom">Historique repris le ${echapper(jjmmaaaa(e.importe_le))}</b>
            ${e.contrats} contrats attestés, ${e.salaries} salarié${e.salaries > 1 ? "s" : ""},
            ${e.objets} numéro${e.objets > 1 ? "s" : ""} d'objet —
            du ${echapper(jjmmaaaa(e.du))} au ${echapper(jjmmaaaa(e.au))}</div>
          <div class="rang-etat"><span class="pastille bien">fait</span></div>
        </div>
        <details class="relire"><summary>Relire un dossier — un salarié ou une année
          qui manquait</summary>
          <p class="note">Les fiches qui existent déjà ne sont pas touchées ; ce que les
            DSN disaient autrement est seulement signalé.</p>
          ${formulaire}
        </details>`
      : `<p class="note">Les fiches qui existent déjà ne sont pas touchées ; ce que les
          DSN disaient autrement est seulement signalé. Rien n'est écrit avant
          « Reprendre ».</p>
        ${formulaire}`}
    </div>`;
  document.getElementById("import-apercu").onclick = () => apercuImportation();
  // L'EXPLORATEUR (08/10/2026) : la boîte du système, ouverte par le poste.
  document.getElementById("import-parcourir").onclick = async () => {
    try {
      const r = await api("choisir-dossier", { titre: "Le dossier des DSN de l'ancien logiciel" });
      if (r.dossier) document.getElementById("import-export").value = r.dossier;
    } catch (err) { dire(err.message, "erreur"); }
  };
}

function fichesImportees(fiches, titre) {
  const lignes = fiches.filter((f) => f).map((f) => {
    const etat = f.etat === "existante" ? `<span class="pastille bien">existe déjà</span>`
      : f.etat === "creee" ? `<span class="pastille bien">créée (${echapper(f.cle)})</span>`
      : `<span class="pastille alerte">à créer</span>`;
    const ecarts = Object.entries(f.ecarts || {}).map(([champ, e]) =>
      `<div class="acte-dernier">la DSN de ${echapper(moisEnClair(e.mois))} disait
         <b>${echapper(champ)}</b> = « ${echapper(e.dsn)} », la fiche dit
         « ${echapper(e.fiche)} » — la fiche fait foi</div>`).join("");
    const erreurs = (f.anomalies || []).filter((a) => a.gravite === "erreur").map((a) =>
      `<div class="acte-dernier faute">${echapper(a.champ)} : ${echapper(a.message)}</div>`).join("");
    return `<div class="rang import">
      <span class="rang-nom">${echapper(f.libelle)}</span>
      ${etat}
      <span class="rang-infos">${ecarts}${erreurs}</span></div>`;
  });
  if (!lignes.length) return "";
  return `<h3>${titre}</h3>${lignes.join("")}`;
}

function vueImportation(r) {
  const periode = r.premier_mois ? ` (${moisEnClair(r.premier_mois)} → ${moisEnClair(r.dernier_mois)})` : "";
  const contrats = r.contrats
    ? `${r.contrats} contrat(s) attesté(s) du ${jjmmaaaa(r.contrats_du)} au ${jjmmaaaa(r.contrats_au)} :
       <b>${r.contrats_nouveaux} ${r.ecrit ? "ajouté(s)" : "à ajouter"}</b> à l'historique,
       ${r.contrats - r.contrats_nouveaux - r.contrats_sans_fiche} déjà connu(s)${
         r.contrats_sans_fiche ? `, ${r.contrats_sans_fiche} sans fiche` : ""}`
    : "aucun contrat attesté (pas d'AEM)";
  const avert = r.avertissements.map((a) => `<div class="encart attention">${echapper(a)}</div>`).join("");
  const nb = [r.entreprise, ...r.salaries, ...r.spectacles].filter((f) => f && f.etat === "a_creer").length;
  const bouton = r.ecrit
    ? `<div class="encart bien"><b>Repris.</b> ${r.fichiers.map((f) => echapper(f)).join("<br>")}</div>`
    : r.rien_a_faire
      ? `<div class="encart bien"><b>Rien à reprendre</b> : tout est déjà là.</div>`
      : `<p><button class="primaire" id="import-ecrire">Reprendre ${nb} fiche${nb > 1 ? "s" : ""}
           et ${r.contrats_nouveaux} contrat${r.contrats_nouveaux > 1 ? "s" : ""}</button>
         <span class="note">Rien n'est écrit avant ce clic.</span></p>`;
  return `<div class="encart"><b>${echapper(r.source)}</b>
      ${r.dsn} DSN${periode}, ${r.aem} fichier(s) AEM — ${contrats}</div>
    ${avert}
    ${fichesImportees([r.entreprise], "Entreprise")}
    ${fichesImportees(r.salaries, "Salariés")}
    ${fichesImportees(r.spectacles, "Spectacles")}
    ${bouton}`;
}

async function apercuImportation() {
  IMPORT_EXPORT = document.getElementById("import-export").value.trim();
  const cible = document.getElementById("import-resultat");
  cible.innerHTML = `<p class="discret">Lecture des déclarations…</p>`;
  try {
    const r = await api("importation-apercu", { export: IMPORT_EXPORT });
    cible.innerHTML = vueImportation(r);
    const b = document.getElementById("import-ecrire");
    if (b) b.onclick = () => ecrireImportation();
  } catch (e) {
    cible.innerHTML = `<div class="encart erreur">${echapper(e.message)}</div>`;
  }
}

async function ecrireImportation() {
  const cible = document.getElementById("import-resultat");
  cible.classList.add("attente");
  try {
    const r = await api("importer", { export: IMPORT_EXPORT });
    cible.innerHTML = vueImportation(r);
    // Les fiches créées doivent apparaître dans Salariés et Spectacles, et
    // dans les déroulants de la saisie, sans recharger la page.
    ETAT = await api("etat");
    rafraichirReferentiels();
    dire(`Repris : ${r.contrats_nouveaux} contrat(s), ${
      [r.entreprise, ...r.salaries, ...r.spectacles].filter((f) => f && f.etat === "creee").length} fiche(s).`, "ok");
  } catch (e) {
    cible.innerHTML = `<div class="encart erreur">${echapper(e.message)}</div>`;
  } finally {
    cible.classList.remove("attente");
  }
}

/*  LA FICHE ENTREPRISE SE LIT (22/09/2026)
 *
 *  Elle etait une liste plate de trente cases, des accolades JSON a taper
 *  pour le signataire et la banque, une etiquette « DÉCLARÉ » sous chacune,
 *  et le SIREN, le NIC et le SIRET demandes trois fois de suite. L'editeur :
 *  « tout est un peu mélangé (...) pas très friendly pour ceux qui
 *  comprennent pas le code ».
 *
 *  Quatre decisions, et aucune ne touche au moteur :
 *
 *   - des SECTIONS (SECTIONS_FICHE) : on cherche « ma banque », pas « le
 *     champ 27 » ;
 *   - les structures se saisissent en SOUS-CHAMPS (SOUS_CHAMPS), une case
 *     par valeur, un « + » pour une liste. Les clefs qu'on ne montre pas
 *     (`_note`, `nom_aem`...) sont relues telles quelles a l'enregistrement
 *     — voir `lireFormulaire` : on ne perd pas ce qu'on n'affiche pas ;
 *   - ce que la machine DEDUIT ne se saisit pas : le SIREN et le NIC sont
 *     les 9 et les 5 chiffres du SIRET, poses en cases cachees (CACHES) ;
 *   - l'aide tient derriere un « ? » : presente pour qui la cherche,
 *     absente pour qui ne la cherche pas. Et l'etiquette « déclaré » ne
 *     s'affiche plus : savoir ce qui part en DSN est le travail du moteur.
 *
 *  `moteur/champs.py` reste la seule description des champs : ces tables ne
 *  disent que l'ORDRE et la MISE EN PAGE. Un champ nouveau qui n'y figure
 *  pas s'affiche quand meme, dans la derniere section.
 */
const SECTIONS_FICHE = {
  // LA FICHE ENTREPRISE, RELUE LE 23/09/2026. L'editeur : « on demande le
  // minimum d'information aux gens, après on traite l'information pour que
  // ça rentre dans la DSN ». Six blocs, dans l'ordre ou l'on cherche : qui
  // l'on est, ou l'on est, sous quelle convention, ses numeros, qui signe,
  // le compte. Les cases que le moteur deduit sont nommees ici pour que
  // leur case cachee soit posee dans le bloc de la valeur dont elles
  // viennent (voir CACHES).
  entreprise: [
    // La date de la première embauche sort de l'« Avancé » (30/09/2026) :
    // pour une compagnie de moins de cinq ans, sans elle l'effectif est
    // inconnu et le premier mois ne se calcule pas.
    ["La compagnie", ["nom_affichage", "siret", "siren", "nic", "naf",
                      "licence_spectacle", "premiere_embauche"]],
    ["Adresse", ["adresse_affichage", "code_postal", "commune_affichage"]],
    ["Convention collective", ["idcc", "convention_collective",
                               "code_convention_dsn", "annexe_convention",
                               "jauge_annexe_1", "type_radio_1922",
                               "cinquante_salaries_3241"]],
    // Le taux AT/MP se pose en tête de ce bloc (`ATMP_HTML`).
    ["Vos numéros chez les organismes",
     ["urssaf_compte", "congesspectacles_adherent",
      "congesspectacles_affiliation",
      "affiliation_france_travail", "code_employeur_france_travail",
      "france_travail_dossier_recouvrement"], { atmp: true }],
    ["Qui signe, qui répond", ["signataire", "declarant_dsn"]],
    ["Paiement des cotisations", ["banque"]],
    // L'AVANCE (23/09/2026). L'editeur : « si on peut deviner que c'est le
    // truc de base, on le met en truc de base ; si les gens veulent changer,
    // ils cliquent sur avancé ». Chacun de ces champs a une valeur par
    // defaut qui est le cas ordinaire d'une compagnie : pas de salarie au
    // mois, pas de syndicat, pas de CSE, pas d'exemption, et un effectif lu
    // dans les retours de l'Urssaf plutot qu'une date de premiere embauche.
    // Le bloc s'ouvre de lui-meme si l'un d'eux s'ecarte du cas ordinaire.
    // Chaque case suit ce qui la commande (26/09/2026) : les fériés chômés
    // et la prévoyance ne se montrent qu'avec des permanents, la date
    // d'adhésion qu'avec un syndicat, le CSE qu'en CCNEAC, l'exemption
    // CASC-SVP qu'en 3090, l'article 45 qu'au cinéma.
    ["Avancé — cas particuliers", ["emploie_des_permanents",
      "jours_feries_chomes", "prevoyance_permanents", "sante_permanents",
      "organisation_patronale", "organisation_patronale_depuis",
      "representation_personnel", "casc_svp_exemptee",
      "prevoyance_techniciens_3097",
      "code_urssaf", "retraite_complementaire", "etablissements"],
     { avance: true }],
    // Sans titre : l'historique se replie derriere un lien (`histoireDuChamp`).
    ["", ["historique"]],
  ],
  // LA FICHE SALARIE, RELUE LE 23/09/2026 sur le modele de l'entreprise.
  // Dans l'ordre ou on la remplit, papiers en main : la carte Vitale, la
  // piece d'identite, l'adresse ; puis ce que l'employeur decide, l'emploi.
  // Chaque champ a ete confronte a ce qui le lit dans le moteur : le taux de
  // PAS de la fiche n'etait lu par personne, il ne se montre plus ; le sexe
  // ne sert que sans NIR, il ne se montre que dans ce cas (`brancherSexe`).
  salarie: [
    // Le numero et sa cle cote a cote, comme sur la carte Vitale.
    ["Identité", ["prenom_affichage", "nom_affichage", "nir", "nir_cle",
                  "date_naissance", "sexe"]],
    ["Naissance et nationalité", ["lieu_naissance_affichage",
      "departement_naissance", "pays_naissance", "code_nationalite_dsn"]],
    ["Coordonnées", ["adresse_affichage", "code_postal", "commune_affichage",
                     "email"]],
    // LE MÉTIER SE CHOISIT, SES CODES SE DÉDUISENT (30/09/2026). La liste
    // des métiers cochés (Configuration › Métiers) se pose en tête du bloc
    // (`METIER_HTML`) ; l'intitulé reste à portée de main — c'est lui que
    // lit le contrat. Statut, cadre, PCS-ESE et code France Travail se
    // remplissent au choix du métier : ils passent dans l'« Avancé ».
    ["Emploi", ["emploi_affichage"], { metier: true }],
    ["Intermittence", ["num_conges_spectacles", "anniversaire_droits"]],
    // Rien a remplir tant que la compagnie n'emploie pas de salarie au mois.
    ["Salarié au mois", ["sante_dispense", "prevoyance_branche_depuis",
                         "categorie_conventionnelle", "conges_reprise",
                         "forfait_jours"],
     { sante: true }],
    // L'avance : ce qui a une valeur par defaut juste pour presque tout le
    // monde. Le tiroir s'ouvre seul si l'une s'en ecarte (`ORDINAIRE`).
    ["Avancé — cas particuliers", ["statut", "statut_categoriel_rc",
      "pcs_ese", "code_emploi_ft", "date_anciennete", "code_salarie",
      "initiales_contrat", "statut_conventionnel", "deduction_forfaitaire",
      "statut_boeth", "echelon_ccneac", "classement_conventionnel",
      "poste_depuis", "experimente_3241", "stagiaire_ccneac",
      "etablissement", "actif"], { avance: true }],
    ["", ["historique"]],
  ],
};

/* Ce qui, dans le tiroir « Avancé », vaut le cas ordinaire et ne l'ouvre
 * donc pas. Une case absente d'ici ouvre le tiroir des qu'elle est remplie. */
const ORDINAIRE = {
  code_urssaf: (v) => String(v) === String(ETAT.urssaf_deduit || ""),
  retraite_complementaire: (v) => String(v).trim().toUpperCase() === "AUDIENS",
  // Toujours remplis, et c'est normal : un matricule, un prefixe, une date.
  code_salarie: () => true,
  initiales_contrat: () => true,
  date_anciennete: () => true,
  actif: (v) => v !== false,
  statut_conventionnel: (v) => String(v) === "05",
  // Ce que le métier remplit : toujours là, et l'« Avancé » n'a pas à
  // s'ouvrir pour eux.
  statut: () => true,
  statut_categoriel_rc: () => true,
  pcs_ese: () => true,
  code_emploi_ft: () => true,
};

/* Les champs qu'on peut laisser vides : l'ecran le dit a cote du libelle,
 * plutot que de laisser croire qu'il manque quelque chose. L'editeur,
 * 23/09/2026 : « il y a des champs facultatifs, par exemple la date
 * anniversaire ». */
const FACULTATIFS = {
  salarie: ["num_conges_spectacles", "anniversaire_droits", "sante_dispense",
            "prevoyance_branche_depuis", "echelon_ccneac",
            "classement_conventionnel", "conges_reprise",
            "categorie_conventionnelle", "poste_depuis"],
};

/* Les champs que la machine deduit d'un autre, ou qu'elle connait sans
 * qu'on les lui dise : ils restent dans le formulaire — donc ils repartent
 * a l'enregistrement avec leur valeur — mais en case cachee.
 *
 *  - `siren`, `nic` : le SIRET ; `convention_collective`,
 *    `code_convention_dsn` : l'IDCC (`brancherDeduits`, `brancherConvention`) ;
 *  - `congesspectacles_affiliation` : le numero d'adherent precede de 97,
 *    `code_employeur_france_travail` : l'affiliation sans sa cle ;
 *  - `etablissements` (le moteur n'en declare qu'un) : garde tel quel,
 *    jamais demande.
 *
 *  Le code Urssaf et la caisse de retraite, eux, sont de VRAIS choix : ils
 *  vont dans l'avance, vides par defaut -- le moteur prend alors l'Urssaf
 *  du code postal et Audiens. L'editeur : « il ne faut pas enlever de
 *  l'interface les choix que peut faire l'entreprise ». */
const CACHES = {
  entreprise: ["siren", "nic", "convention_collective", "code_convention_dsn",
               "congesspectacles_affiliation", "code_employeur_france_travail",
               "etablissements"],
  // `sante_svp` se remplit par les trois cases de la complementaire sante ;
  // `taux_pas` n'est plus lu par personne (il vit dans config/pas.json) :
  // gardes tels quels, jamais demandes.
  salarie: ["sante_svp", "taux_pas"],
};

/* Une structure, case par case. `liste: true` = plusieurs lignes, avec un
 * « + ». Ce qui n'est pas nomme ici est CONSERVE tel quel.
 *
 * LES PERSONNES SE SAISISSENT COMME ON LES ECRIT (23/09/2026). Le nom et le
 * prenom en capitales sans accents, c'est la forme de l'AEM et de la DSN :
 * le moteur la fabrique (`champs.deriver_personnes`), on ne la demande plus. */
const SOUS_CHAMPS = {
  // Le solde de congés d'un salarié au mois arrivé d'un autre logiciel
  // (§111) : ce que son dernier bulletin disait.
  conges_reprise: { champs: [
    ["date", "PuppetPaie compte à partir du", "AAAA-MM-JJ : le premier jour du premier mois produit par PuppetPaie"],
    ["report", "Reste N-1 (jours)", "Les jours de l'année de référence précédente qui restent à prendre"],
    ["acquis_report", "Acquis N-1 en tout (jours)", "Souvent 30 : il sert à payer un jour au dixième"],
    ["remuneration_report", "Brut de la période N-1 (€)", "L'assiette du dixième des jours N-1"],
    ["acquis", "Acquis N (jours)", "Les jours acquis sur la période en cours, avant cette date"],
    ["pris", "Pris sur N (jours)", "Les jours de la période en cours déjà pris avant cette date"],
    ["remuneration_periode", "Brut de la période N (€)", "Le brut versé sur la période en cours, avant cette date"],
  ] },
  signataire: { champs: [
    ["prenom_affichage", "Prénom", ""],
    ["nom_affichage", "Nom", ""],
    ["fonction", "Fonction", "Président, présidente, gérant, directrice…"],
    ["tel", "Téléphone", ""],
    ["email", "Courriel", ""],
  ] },
  // LA QUALITE DU DECLARANT NE S'AFFICHE PAS (22/09/2026). C'est
  // S20.G00.07.004, et elle vaut 04 : << la personne qui etablit la paie
  // dans l'entreprise >>. La valeur reste dans la fiche et repart telle
  // quelle (STRUCTURES_ORIGINE) ; `moteur/dsn.py` la lit comme avant.
  declarant_dsn: { champs: [
    ["prenom_affichage", "Prénom", ""],
    ["nom_affichage", "Nom", ""],
    ["tel", "Téléphone", ""],
    ["email", "Courriel", ""],
  ] },
  banque: { champs: [
    ["iban", "IBAN", "Sur votre relevé d'identité bancaire (RIB) : 27 caractères commençant par FR."],
    ["bic", "BIC", "Sur le même RIB, 8 ou 11 caractères."],
  ] },
  // LA PREVOYANCE ET LA SANTE DES PERMANENTS (24/09/2026, journal §129).
  // Elles se saisissaient en JSON dans une zone de texte : un administrateur
  // n'avait pas a lire des accolades. Une case vide est RETIREE a
  // l'enregistrement, et le moteur applique alors la convention. Le format
  // des donnees ne change pas : « taux.t1_cadre » est la case `t1_cadre` du
  // bloc `taux`.
  prevoyance_permanents: { champs: [
    ["regime", "Régime", "Le cas ordinaire : celui de la convention, que le logiciel applique seul. Un contrat d'entreprise ne se choisit que s'il a été réellement souscrit, et plus favorable.",
     { choix: { "": "Celui de la convention (le cas ordinaire)",
                "contrat": "Un contrat d'entreprise plus favorable" } }],
    ["taux.t1_non_cadre", "Taux non-cadres (%)", "Seulement pour un contrat d'entreprise : son taux sur la tranche A, pour les non-cadres.", { nombre: true }],
    ["taux.t1_cadre", "Taux cadres (%)", "Seulement pour un contrat d'entreprise : son taux sur la tranche A, pour les cadres (au moins 1,50 %).", { nombre: true }],
    ["taux.part_patronale", "Part employeur (%)", "Seulement pour un contrat d'entreprise. 100 % pour les cadres, obligatoirement.", { nombre: true }],
    ["extension_t2", "Extension sur la tranche 2", "Facultative, si elle a été souscrite.",
     { choix: { "": "Aucune (le cas ordinaire)", "tous": "Pour tous les permanents",
                "cadres": "Pour les cadres seulement" } }],
    ["adhesion", "Organisme et numéro d'adhésion", "Pour mémoire : il ne part dans aucun calcul."],
  ] },
  sante_permanents: { champs: [
    ["taux_contrat", "Taux du contrat (% du plafond mensuel)", "Seulement pour une convention sans régime de santé (production audiovisuelle 2642) : le taux de votre contrat, pour le salarié seul. Il est sur votre contrat ou votre appel de cotisation.", { nombre: true }],
    ["part_patronale", "Part employeur (%)", "Au moins 50 %. Vide : 50 %.", { nombre: true }],
  ] },
  etablissements: { liste: true, ligne: "établissement", champs: [
    ["nic", "NIC", ""],
    ["siret", "SIRET", ""],
    ["libelle", "Nom de l'établissement", ""],
  ] },
};

/* Les valeurs d'une liste de choix, dites en clair. Le moteur garde ses
 * codes (`cse_adherent_fnas`), l'ecran montre une phrase. */
const LIBELLES_CHOIX = {
  annexe_convention: {
    "1": "Annexe 1 — lieux, production ou diffusion de théâtre, danse, lyrique, musique classique",
    "2": "Annexe 2 — chanson, variétés, jazz, musiques actuelles",
    "3": "Annexe 3 — cabarets",
    "4": "Annexe 4 — production ou diffusion de spectacles en tournée",
    "5": "Annexe 5 — cirque",
    "6": "Annexe 6 — bals",
  },
  representation_personnel: {
    "aucune": "Pas de CSE (carence constatée)",
    "csec": "CSE conventionnel (11 à 49 salariés)",
    "cse_adherent_fnas": "CSE de 50 salariés et plus, adhérent au FNAS",
    "cse": "CSE qui n'adhère pas au FNAS",
  },
  sexe: { "1": "Homme", "2": "Femme" },
  code_nationalite_dsn: {
    "01": "Française",
    "02": "D'un pays de l'Union européenne ou de l'EEE",
    "03": "D'un autre pays",
  },
  statut: {
    "artiste": "Artiste",
    "technicien": "Technicien, ou autre emploi non artistique",
  },
  statut_categoriel_rc: {
    "04": "Non cadre",
    "01": "Cadre",
    "02": "Code 02 de la DSN",
    "03": "Code 03 de la DSN",
  },
  statut_conventionnel: {
    "05": "Profession intermédiaire, technicien, agent de maîtrise — les artistes",
    "04": "Cadre au sens de la convention",
    "06": "Employé administratif",
    "07": "Ouvrier ou employé technique",
  },
  deduction_forfaitaire: {
    "": "Aucun — le cas ordinaire",
    "20": "20 % — musiciens, choristes, chefs d'orchestre, régisseurs de théâtre",
    "25": "25 % — artistes dramatiques, lyriques, chorégraphiques, de cinéma",
  },
};

/* Ou aller chercher une valeur qu'on n'a pas sous la main : une phrase et
 * un lien, derriere le « ? » du champ. VIDE DEPUIS LE 23/09/2026 : les
 * liens menaient a la page d'accueil d'un organisme, ce qui n'apprend rien.
 * L'aide de chaque champ (`moteur/champs.py`) dit maintenant ou lire la
 * valeur. Un lien ne revient ici que s'il mene a la page qui la donne. */
const OU_TROUVER = {};

/* Les structures telles qu'elles etaient AVANT la saisie : `lireFormulaire`
 * en repart pour ne pas perdre les clefs qu'on n'affiche pas. */
let STRUCTURES_ORIGINE = {};

/* L'aide derriere un « ? » : le bouton dans le libelle, le texte dessous,
 * replie. `OU_TROUVER` y ajoute une phrase et un lien quand la valeur se
 * demande a quelqu'un d'autre qu'a soi-meme. */
function aideHtml(cle, aide) {
  return (aide || OU_TROUVER[cle])
    ? `<button type="button" class="aide-bouton" data-aide="${echapper(cle)}"
         title="à quoi sert ce champ, où le trouver">?</button>` : "";
}

function aideCorps(cle, aide) {
  const ou = OU_TROUVER[cle];
  if (!aide && !ou) return "";
  return `<div class="aide" data-aide-corps="${echapper(cle)}" hidden>
    ${ou ? `<p class="ou-trouver">${echapper(ou[0])}
        <a href="${echapper(ou[1])}" target="_blank" rel="noopener">${echapper(ou[1])}</a></p>` : ""}
    ${aide ? `<p>${echapper(aide)}</p>` : ""}
  </div>`;
}

/*  UNE STRUCTURE SE SAISIT CASE PAR CASE, PAS EN ACCOLADES.
 *
 *  Deux formes : un objet (le signataire, la banque) rendu en une rangee de
 *  cases ; une liste (les licences, les etablissements) rendue en lignes,
 *  avec un « + » pour en ajouter une et une croix pour en retirer une. Ce
 *  que la table ne nomme pas n'est pas affiche, et n'est pas perdu.
 */
function structureHtml(c, v, sous, a, avecPermanents) {
  const cache = c.si_permanents && !avecPermanents;
  const tete = `<label class="titre-structure">${echapper(c.libelle)}
      ${c.obligatoire ? '<span class="obligatoire">*</span>' : ""}
      ${aideHtml(c.cle, c.aide)}</label>
    ${aideCorps(c.cle, c.aide)}`;
  let corps;
  if (sous.liste) {
    const lignes = Array.isArray(v) ? v : (v ? [v] : []);
    corps = `<div class="liste-structure" data-liste="${echapper(c.cle)}">
        ${lignes.map((l, i) => ligneStructure(c.cle, sous, l, i)).join("")}
      </div>
      <button type="button" class="secondaire ajouter-ligne"
        data-ajouter="${echapper(c.cle)}">+ Ajouter un ${echapper(sous.ligne || "élément")}</button>`;
  } else {
    const o = (v && typeof v === "object" && !Array.isArray(v)) ? v : {};
    corps = `<div class="sous-champs">${sous.champs.map(([k, lib, aide, genre = {}]) => `
      <div class="sous-champ">
        <label>${echapper(lib)}
          ${aide ? `<button type="button" class="aide-bouton"
             data-aide="${echapper(c.cle + "." + k)}" title="aide">?</button>` : ""}
          ${caseSousChamp(c.cle, k, valeurEn(o, k), genre)}</label>
        ${aide ? `<div class="aide" data-aide-corps="${echapper(c.cle + "." + k)}" hidden>
            <p>${echapper(aide)}</p></div>` : ""}
      </div>`).join("")}</div>`;
  }
  return `<div class="champ pleine structure${c.si_permanents ? " champ-permanents" : ""}"${
      cache ? " hidden" : ""}>
    ${tete}
    ${corps}
    ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
  </div>`;
}

/* Une valeur dans un objet, par son chemin : « taux.t1_cadre ». */
function valeurEn(o, chemin) {
  return chemin.split(".").reduce((x, k) => (x && typeof x === "object") ? x[k] : undefined, o);
}

/* La case d'un sous-champ : une liste de choix, un nombre ou du texte. Les
 * deux premiers portent `data-sous-type` : vides, ils sont retires a
 * l'enregistrement (`lireFormulaire`). */
function caseSousChamp(parent, k, val, genre) {
  const attrs = `data-sous-de="${echapper(parent)}" data-sous-cle="${echapper(k)}"`;
  if (genre.choix) {
    return `<select ${attrs} data-sous-type="choix">${Object.entries(genre.choix).map(([v, lib]) =>
      `<option value="${echapper(v)}" ${String(val ?? "") === v ? "selected" : ""}>${echapper(lib)}</option>`).join("")}</select>`;
  }
  if (genre.nombre) {
    return `<input type="number" step="0.01" min="0" ${attrs} data-sous-type="nombre"
      value="${echapper(val ?? "")}">`;
  }
  return `<input ${attrs} value="${echapper(val ?? "")}">`;
}

function ligneStructure(cle, sous, ligne, i) {
  const o = ligne && typeof ligne === "object" ? ligne : {};
  return `<div class="ligne-structure" data-index="${i}">
    ${sous.champs.map(([k, lib]) => `
      <label>${echapper(lib)}
        <input data-liste-de="${echapper(cle)}" data-liste-index="${i}"
          data-sous-cle="${echapper(k)}" value="${echapper(o[k] ?? "")}"></label>`).join("")}
    <button type="button" class="retirer-ligne" title="retirer cette ligne">✕</button>
  </div>`;
}

/* La fiche que le formulaire montre en ce moment : `quitterLaFiche` en a
 * besoin pour pouvoir l'enregistrer avant de partir. */
let FICHE_COURANTE = null;

/* La mention « facultatif », a cote du libelle d'un champ qu'on peut
 * laisser vide (FACULTATIFS). */
function facultatif(c) {
  return (FACULTATIFS[FICHE_ACTIVE] || []).includes(c.cle)
    ? ' <span class="facultatif">facultatif</span>' : "";
}

/* LE MÉTIER, en tête du bloc « Emploi » (revu le 30/09/2026). Un seul
 * déroulant, qui montre le métier de la fiche (son code France Travail) —
 * il affichait « — celui de la fiche — », emprunté à l'engagement, et ne
 * disait jamais ce qui était choisi. La liste est celle des métiers cochés ;
 * on en ajoute dans l'onglet Métiers, pas ici. */
function METIER_HTML(fiche) {
  const code = ((fiche || {}).donnees || {}).code_emploi_ft || "";
  return `<div class="champ" id="config-metier">
    <label>Métier <span class="obligatoire">*</span>
      <select id="config-metier-choix">${optionsMetiers(code, "— choisir —")}</select></label>
    <div class="discret petit">Un métier manque ? L'ajouter dans
      <button type="button" class="lien" id="aller-metiers">Configuration › Métiers</button>.</div>
  </div>`;
}

/* CE QU'UN SPECTACLE, OU UN SALARIÉ, A COÛTÉ DANS L'ANNÉE (30/09/2026).
 * L'éditeur : « si un administrateur veut savoir combien un de ses
 * spectacles lui a coûté dans l'année, il faut qu'il le trouve
 * facilement ». La réponse était dans Exports, un état parmi vingt-deux ;
 * elle est désormais en tête de la fiche. Le calcul est celui du livre de
 * paie (route « couts ») : une fois par année et par séance, oublié dès
 * qu'une saisie s'enregistre. */
const COUTS = {};
function coutsDe(annee) {
  if (!COUTS[annee]) COUTS[annee] = api("couts", { annee }).catch(() => null);
  return COUTS[annee];
}
function oublierCouts() { Object.keys(COUTS).forEach((k) => delete COUTS[k]); }

async function peindreCoutAnnee() {
  const el = document.querySelector("#config-formulaire .cout-annee");
  if (!el) return;
  const an = new Date().getFullYear();
  const ligne = (r, annee) => {
    const d = r && (r[el.dataset.cote] || {})[el.dataset.cle];
    if (!d || (!d.bulletins && !Number(d.prevu))) return "";
    const prevu = Number(d.prevu) ? ` · <span class="discret">+ ${echapper(euros(d.prevu))} déjà saisis pour la suite de l'année</span>` : "";
    return `<div><b>${annee}</b> : coût employeur <b>${echapper(euros(d.cout))}</b>
      <span class="discret">— brut ${echapper(euros(d.brut))}, charges ${echapper(euros(d.charges))},
      ${d.bulletins} bulletin${d.bulletins > 1 ? "s" : ""}${d.incomplet ? ", coût incomplet avant PuppetPaie" : ""}</span>${prevu}</div>`;
  };
  el.innerHTML = `<span class="discret">Coût de l'année…</span>`;
  const [cette, avant] = await Promise.all([coutsDe(an), coutsDe(an - 1)]);
  if (!el.isConnected) return;
  el.innerHTML = ligne(cette, an) + ligne(avant, an - 1);
}

/* L'ONGLET MÉTIERS (30/09/2026). L'éditeur : « les métiers, c'est vraiment
 * un onglet à part : on a les métiers de base de notre convention, on peut
 * en rajouter » — et les cocher ou les décocher. Ce qui est coché se
 * propose dans la fiche d'un salarié et dans un engagement ; rien d'autre
 * ne change, aucun calcul. Par famille, repliée, avec son compte ; la
 * recherche ouvre ce qu'elle trouve. Les métiers des autres conventions ne
 * se montrent que si on le demande. */
let METIERS_TOUS = false;
let METIERS_FILTRE = "";

async function dessinerMetiers(cible) {
  let r;
  try { r = await api("metiers-catalogue"); }
  catch (e) { cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`; return; }
  const sansAccent = (t) => String(t || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const peindre = () => {
    const filtre = sansAccent(METIERS_FILTRE.trim());
    const vus = r.metiers.filter((m) => (METIERS_TOUS || m.de_la_convention || m.retenu)
      && (!filtre || sansAccent(m.libelle).includes(filtre) || sansAccent(m.code).includes(filtre)));
    const familles = [...new Set(vus.map((m) => m.famille))];
    const retenus = r.metiers.filter((m) => m.retenu).length;
    document.getElementById("metiers-compte").textContent =
      `${retenus} métier${retenus > 1 ? "s" : ""} coché${retenus > 1 ? "s" : ""}`;
    document.getElementById("metiers-liste").innerHTML = familles.length ? familles.map((f) => {
      const dedans = vus.filter((m) => m.famille === f);
      const n = dedans.filter((m) => m.retenu).length;
      return `<details class="metiers-famille"${filtre ? " open" : ""}>
        <summary><b>${echapper(f)}</b> <span class="discret">${n} coché${n > 1 ? "s" : ""} sur ${dedans.length}</span></summary>
        <div class="metiers-colonnes">${dedans.map((m) => `
          <label class="coche" title="${echapper(m.code)}${m.de ? " — " + echapper(m.de) : ""}">
            <input type="checkbox" data-code="${echapper(m.code)}"${m.retenu ? " checked" : ""}>
            ${echapper(m.libelle)}${m.de ? ` <span class="discret">· autre convention</span>` : ""}
          </label>`).join("")}</div>
      </details>`;
    }).join("") : `<p class="discret">Aucun métier ne correspond.</p>`;
    document.querySelectorAll("#metiers-liste input[data-code]").forEach((c) => {
      c.onchange = async () => {
        try {
          const x = await api("metier-retenu", { code: c.dataset.code, retenu: c.checked });
          ETAT.emplois = x.emplois;
          ETAT.emplois_autres = x.emplois_autres;
          const m = r.metiers.find((y) => y.code === c.dataset.code);
          if (m) m.retenu = c.checked;
          const garde = [...document.querySelectorAll("#metiers-liste details[open] summary b")].map((b) => b.textContent);
          peindre();
          document.querySelectorAll("#metiers-liste details").forEach((d) => {
            if (garde.includes(d.querySelector("summary b").textContent)) d.open = true;
          });
        } catch (e) { c.checked = !c.checked; dire(e.message, "erreur"); }
      };
    });
  };
  cible.innerHTML = `
    <div class="carte">
      <h2>Les métiers de la compagnie</h2>
      <p class="note">Ceux qui sont cochés se proposent dans la fiche d'un
        salarié et dans un engagement. Ceux de votre convention collective
        le sont d'office.</p>
      <div class="metiers-outils">
        <input type="search" id="metiers-filtre" placeholder="Chercher un métier…"
               value="${echapper(METIERS_FILTRE)}">
        <label class="coche"><input type="checkbox" id="metiers-tous"${METIERS_TOUS ? " checked" : ""}>
          montrer aussi les autres conventions</label>
        <span id="metiers-compte" class="discret"></span>
      </div>
      <div id="metiers-liste"></div>
    </div>`;
  document.getElementById("metiers-filtre").oninput = (e) => { METIERS_FILTRE = e.target.value; peindre(); };
  document.getElementById("metiers-tous").onchange = (e) => { METIERS_TOUS = e.target.checked; peindre(); };
  peindre();
}

/* LES ORGANISMES ET LES CONTRATS DE LA DSN (09/10/2026). Une ligne par
 * contrat que la convention exige ; le moteur (`organismes-contrats`) dit ce
 * qui est fixé par la branche et ce que la compagnie saisit. Enregistrer
 * compose config/organismes.json (`organismes-enregistrer`) : la page ne
 * décide rien. */
async function dessinerOrganismes(cible) {
  let r;
  try { r = await api("organismes-contrats"); }
  catch (e) { cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`; return; }
  const champ = (c, k, fixe, place) => fixe
    ? `<span>${echapper(c[k]) || "—"}</span>`
    : `<input type="text" data-contrat="${echapper(c.cle)}" data-champ="${k}" value="${echapper(c[k])}"
         placeholder="${place}" maxlength="${k === "libelle" ? 30 : 9}">`;
  const ligne = (c) => `
    <tr>
      <td><b>${echapper(c.quoi)}</b>
        ${c.si_permanents ? `<div class="note">Seulement si vous employez des permanents : sans lui, la DSN refuse un permanent.</div>` : ""}
        ${c.depuis ? `<div class="note">Depuis le ${echapper(dateCourte(c.depuis))}.</div>` : ""}
        ${c.note ? `<div class="note">${echapper(c.note)}</div>` : ""}</td>
      <td>${echapper(c.beneficiaires)}</td>
      <td>${champ(c, "organisme", c.organisme_fixe, "P0983")}</td>
      <td>${champ(c, "libelle", c.libelle_fixe, "référence du contrat")}</td>
    </tr>`;
  cible.innerHTML = `
    <div class="carte">
      <h2>Les organismes et les contrats de la DSN</h2>
      <p class="note">Ce que la DSN déclare de vos adhésions de prévoyance et de santé.
        La référence du contrat et le code de l'organisme se lisent sur le certificat
        d'adhésion et sur la fiche de paramétrage DSN de l'organisme. Le reste
        (organismes payés, Urssaf, taux AT/MP, compte France Travail) vient de la loi,
        de la convention et de la fiche Entreprise.</p>
      ${r.compose ? "" : `<p class="rappel retard">Pas encore enregistré : la DSN est refusée tant que ces contrats ne le sont pas.</p>`}
      <table class="tableau">
        <thead><tr><th>Contrat</th><th>Bénéficiaires</th><th>Organisme</th><th>Référence du contrat</th></tr></thead>
        <tbody>${r.contrats.map(ligne).join("")}</tbody>
      </table>
      <div class="actions"><button id="organismes-enregistrer">Enregistrer</button></div>
    </div>`;
  document.getElementById("organismes-enregistrer").onclick = async () => {
    const contrats = {};
    cible.querySelectorAll("input[data-contrat]").forEach((i) => {
      (contrats[i.dataset.contrat] ||= {})[i.dataset.champ] = i.value.trim();
    });
    try {
      await api("organismes-enregistrer", { contrats });
      dire("Organismes et contrats enregistrés.");
      dessinerOrganismes(cible);
    } catch (e) { dire(e.message, "erreur"); }
  };
}

/* LES METIERS DES AUTRES CONVENTIONS (29/09/2026), groupés par la
 * convention qui les nomme : on les ajoute à sa liste, un à un. */
function optionsMetiersAutres() {
  const parConvention = {};
  (ETAT.emplois_autres || []).forEach((m) => { (parConvention[m.de] ||= []).push(m); });
  return `<option value="">— choisir —</option>` + Object.keys(parConvention).map((c) =>
    `<optgroup label="${echapper(c)}">` + parConvention[c].map((m) =>
      `<option value="${echapper(m.code)}">${echapper(m.libelle)}</option>`).join("")
    + `</optgroup>`).join("");
}

async function ajouterMetierAutre(code) {
  if (!code) return;
  const r = await api("metiers-ajoutes", { codes: [code] });
  ETAT.emplois = r.emplois;
  ETAT.emplois_autres = r.emplois_autres;
  const choix = document.getElementById("config-metier-choix");
  if (choix) { choix.innerHTML = optionsMetiers(code); choix.value = code; remplirDepuisMetier(code); }
  const autre = document.getElementById("config-metier-autre");
  if (autre) autre.innerHTML = optionsMetiersAutres();
}

/* LE TAUX AT/MP (30/09/2026), en tête du bloc « Vos numéros chez les
 * organismes ». Il n'est pas un champ de la fiche : il vit dans le barème
 * de la compagnie (`config/baremes/<année>.json`), s'enregistre seul, à la
 * sortie de la case, et ne marque pas la fiche « modifiée ». Sans lui, le
 * premier mois d'une compagnie neuve ne se calculait pas. */
function ATMP_HTML() {
  const an = new Date().getFullYear();
  return `<div class="encart" id="config-atmp" data-annee="${an}">
    <div class="ligne-champs">
      <label>Taux accident du travail (AT/MP) ${an}
        <input id="atmp-valeur" class="hors-fiche" inputmode="decimal" placeholder="1,25"></label>
      <label>Code risque
        <input id="atmp-code" class="hors-fiche" placeholder="923AD" maxlength="5"></label>
    </div>
    <div class="aide">En pourcentage, tel que l'Assurance Maladie le notifie
      chaque année (compte AT/MP sur net-entreprises). Nécessaire pour
      calculer la paie. <span id="atmp-etat"></span></div>
  </div>`;
}

async function brancherAtmp() {
  const bloc = document.getElementById("config-atmp");
  if (!bloc) return;
  const annee = Number(bloc.dataset.annee);
  const valeur = document.getElementById("atmp-valeur");
  const code = document.getElementById("atmp-code");
  const etat = document.getElementById("atmp-etat");
  // Repeindre n'efface jamais ce qu'on est en train de taper : la réponse
  // d'un premier enregistrement (le taux) arrivait pendant qu'on tapait le
  // code risque, et le vidait.
  const peindre = (t) => {
    if (!t) return;
    if (document.activeElement !== valeur) valeur.value = String(t.valeur).replace(".", ",");
    if (t.code_risque && document.activeElement !== code) code.value = t.code_risque;
  };
  // Ces deux cases ne sont pas la fiche : elles ne la marquent pas modifiée.
  [valeur, code].forEach((c) => { c.oninput = null; });
  try { peindre((await api("taux-atmp", { annee })).taux); } catch (e) { /* rien à montrer */ }
  const poser = async () => {
    if (!valeur.value.trim()) return;
    try {
      peindre((await api("taux-atmp", { annee, valeur: valeur.value,
                                        code_risque: code.value })).taux);
      etat.textContent = "Enregistré.";
      valeur.classList.remove("faute");
    } catch (e) {
      etat.textContent = e.message;
      valeur.classList.add("faute");
    }
  };
  valeur.onchange = poser;
  code.onchange = poser;
}

/* LA COMPLÉMENTAIRE SANTÉ D'UN PERMANENT (19/09/2026), en tete du bloc
 * « Salarié au mois ». Elle n'est pas un taux de barème : c'est un forfait
 * en pourcentage du PMSS, et il dépend de deux choses que seul le bulletin
 * d'adhésion du salarié dit. Trois cases plutôt qu'un JSON à taper ; le
 * champ `sante_svp` reste dans la fiche, en case cachée, et ces cases
 * l'écrivent (`brancherSante`). */
function SANTE_HTML() {
  return `<div class="encart" id="config-sante">
    <label>Complémentaire santé — le contrat souscrit par ce salarié
      <select id="config-sante-niveau">
        <option value="">— aucune (intermittent) —</option>
        ${(ETAT.niveaux_sante || []).map((n) =>
          `<option value="${echapper(n.niveau)}">niveau ${echapper(n.niveau)}
             — ${echapper(n.assure)} % du PMSS pour l'assuré seul</option>`).join("")}
      </select></label>
    <label class="coche"><input type="checkbox" id="config-sante-conjoint"> conjoint couvert</label>
    <label>Enfants couverts
      <input type="number" min="0" step="1" id="config-sante-enfants" value="0"></label>
    <div class="aide">Obligatoire pour un salarié au mois (art. L911-7) : sans
      elle, le logiciel refuse de le payer plutôt que de cotiser moins que le
      contrat. Elle se lit sur son bulletin d'adhésion.</div>
  </div>`;
}

/* LE HAUT D'UNE FICHE SALARIE (23/09/2026) : son nom en clair, et deux
 * gestes. « Exporter ses documents » mene a l'onglet Exports, le dossier de
 * ce salarie deja choisi ; une fiche neuve propose de la faire remplir par
 * la personne elle-meme, par courriel (`demanderFiche`). */
function enteteSalarie(fiche) {
  const d = fiche.donnees || {};
  const nom = `${d.prenom_affichage || d.prenom || ""} ${d.nom_affichage || d.nom || ""}`.trim();
  if (fiche.cle) {
    return `<div class="entete-fiche">
      <h2>${echapper(nom || fiche.cle)}
        ${d.code_salarie ? `<span class="discret">— matricule ${echapper(d.code_salarie)}</span>` : ""}</h2>
      <button type="button" class="secondaire petit" id="config-exporter"
        title="Bulletins, contrats, certificats de l'année : l'onglet Exports, ce salarié déjà choisi"
        >Exporter ses documents</button>
    </div>
    <div class="cout-annee" data-cote="salaries" data-cle="${echapper(fiche.cle)}"></div>
    ${d.fiche_recue && fiche.anomalies.some((a) => a.gravite === "erreur")
      ? `<div class="encart">${echapper(d.fiche_recue)}</div>` : ""}`;
  }
  const lie = !!(ETAT.configuration || {}).boite_liee;
  return `<h2>Nouveau salarié</h2>
    <div class="encart invitation">
      <h3>La faire remplir par la personne</h3>
      <p class="aide">Elle reçoit un courriel avec un bouton : une réponse
        s'ouvre avec les questions (identité, naissance, numéro de sécurité
        sociale, adresse), elle y répond et l'envoie. Sa fiche se crée
        seule à l'arrivée de la réponse ; il vous restera l'emploi à
        choisir.</p>
      ${lie ? `<div class="champs">
        <div class="champ"><label>Son courriel
          <input type="email" id="invitation-courriel" placeholder="prenom.nom@exemple.fr"></label></div>
        <div class="champ"><label>Son prénom <span class="facultatif">facultatif</span>
          <input id="invitation-prenom" placeholder="pour dire bonjour"></label></div>
      </div>
      <div class="actions">
        <button type="button" class="primaire" id="invitation-envoyer">Envoyer la demande</button>
      </div>` : `<p class="note">Il faut d'abord lier la boîte courriel de la
        compagnie (Configuration › Mots de passe).</p>`}
    </div>
    <p class="note">Ou remplissez la fiche vous-même ci-dessous. Le matricule
      se donne à l'enregistrement.</p>`;
}

/* Ce que vaut la ligne vide d'une liste de choix, quand elle vaut quelque
 * chose : le moteur prend alors le cas ordinaire. */
const ORDINAIRE_VIDE = {
  statut_conventionnel: "vide : profession intermédiaire",
  statut_categoriel_rc: "vide : non cadre",
};

function dessinerFormulaire(fiche) {
  if (!fiche) return;
  FICHE_COURANTE = fiche;
  const desc = ETAT.configuration.description[FICHE_ACTIVE];
  // CE QUE LA CASE « Emploie des permanents » OUVRE (22/09/2026). Les
  // champs qui ne servent qu'aux permanents restent dans le formulaire —
  // avec leur valeur, qui repart à l'enregistrement — mais ne se montrent
  // qu'à qui a dit en employer. Une case affichée est une case à remplir, à
  // relire et à ne pas se tromper : celle de la complémentaire santé d'un
  // cachetier n'a jamais rien à dire.
  const avecPermanents = !!(ETAT.configuration || {}).permanents;
  // Une compagnie à un seul établissement ne voit pas la case « Établissement »
  // du salarié (25/09/2026) : la question ne se pose pas.
  const avecEtablissements = !!(ETAT.configuration || {}).etablissements;
  // Une case obligatoire encore vide n'est pas une faute tant qu'on n'a pas
  // essayé d'enregistrer : l'astérisque le dit (`aRemplir`).
  const anomalie = (cle) => fiche.anomalies.find((a) => a.champ === cle && !aRemplir(a));

  // Les champs CALCULES ne sont pas proposes a la saisie : c'est le
  // programme qui les fabrique. ET ILS NE SE MONTRENT PLUS (23/09/2026) :
  // `COMPAGNIE DU FIL` sous « Compagnie du Fil », c'etait faire lire a
  // l'utilisateur la forme de la DSN. L'editeur : « ça, les gens s'en
  // fichent ». Le moteur la fabrique, et ne revient vers l'humain que si
  // elle ne peut pas partir.

  // CE QU'ON N'AFFICHE PAS, ON LE GARDE. Le signataire porte un `nom_aem` et
  // une note ; la banque porte un avertissement de diffusion. Ces clefs ne
  // sont pas des cases a remplir, mais les effacer serait perdre une valeur
  // que quelqu'un a posee exprès. `lireFormulaire` repart de ces originaux.
  STRUCTURES_ORIGINE = {};
  desc.forEach((c) => {
    const v = fiche.donnees[c.cle];
    if (SOUS_CHAMPS[c.cle] && v && typeof v === "object") STRUCTURES_ORIGINE[c.cle] = v;
  });

  const caches = CACHES[FICHE_ACTIVE] || [];
  // UN CHAMP QUI DÉPEND D'UN AUTRE (`si`, 25/09/2026) se replie quel que soit
  // le chemin qui l'a dessiné — liste de choix, convention, champ simple :
  // la marque se pose ici, sur ce que chacun rend, et `brancherConditions`
  // la fait suivre à l'écran.
  // UN CHAMP QUI DÉPEND DE L'ENTREPRISE (`si_entreprise`, 26/09/2026) : la
  // convention décide, et elle ne change pas pendant qu'on remplit la fiche
  // d'un salarié. Le champ est posé, replié — il garde sa valeur.
  const entreprise = ((ETAT.configuration || {}).entreprise || {}).donnees || {};
  // TOUTES LES CONDITIONS AU MÊME ENDROIT (26/09/2026) : les chemins de
  // dessin (liste de choix, case, structure, champ simple) ne posaient pas
  // tous la marque des permanents — « Jours fériés chômés » se montrait à
  // une compagnie sans salarié au mois. Elle se pose ici, sur ce que chacun
  // rend, avec celles des établissements, de l'entreprise et du `si`.
  const champHtml = (c) => {
    const html = champHtmlBrut(c);
    if (!html) return html;
    const horsEntreprise = c.si_entreprise && FICHE_ACTIVE !== "entreprise"
      && !conditionRemplie(c.si_entreprise, (k) => entreprise[k]);
    if (!c.si && !horsEntreprise && !c.si_permanents && !c.si_etablissements) return html;
    const ok = !horsEntreprise && conditionRemplie(c.si, (k) => fiche.donnees[k])
      && !(c.si_permanents && !avecPermanents)
      && !(c.si_etablissements && !avecEtablissements);
    return html.replace(/^(\s*<div class="champ)([^"]*)"([^>]*)>/, (m, debut, classes, reste) => {
      const cl = classes + (c.si_permanents && !/champ-permanents/.test(classes)
        ? " champ-permanents" : "");
      return `${debut}${cl}"${reste.replace(/\s+hidden\b/g, "")}${
        c.si ? ` data-si="${echapper(JSON.stringify(c.si))}"` : ""}${
        horsEntreprise ? " data-hors-entreprise" : ""}${ok ? "" : " hidden"}>`;
    });
  };
  const champHtmlBrut = (c) => {
    const v = fiche.donnees[c.cle];
    const a = anomalie(c.cle);
    // L'histoire de la fiche se LIT, elle ne se tape pas : elle dit ce qui
    // est reellement parti aux organismes, et on ne reecrit pas une
    // declaration deposee. La montrer en JSON editable inviterait a la
    // corriger, ce qui est exactement ce qu'il ne faut pas.
    if (c.forme === "histoire") return histoireDuChamp(v, desc, fiche.donnees);
    // Ce que la machine deduit : present, mais pas a l'ecran.
    if (caches.includes(c.cle)) {
      // Une structure cachee repart telle quelle : en JSON, relu par
      // `lireFormulaire` comme une structure.
      if (c.forme === "structure" || (v !== null && typeof v === "object")) {
        return `<input type="hidden" data-cle="${c.cle}" data-structure="1"
                  value="${echapper(JSON.stringify(v ?? null))}">`;
      }
      return `<input type="hidden" data-cle="${c.cle}" data-forme="${c.forme}"
                value="${echapper(v ?? "")}">`;
    }
    const sous = SOUS_CHAMPS[c.cle];
    if (sous) return structureHtml(c, v, sous, a, avecPermanents);
    // LA CONVENTION SE CHOISIT, ELLE NE SE TAPE PAS (22/09/2026). Le 3090
    // etait demande trois fois : l'IDCC, son libelle, et le code convention
    // DSN -- la meme information sous trois noms. Un seul choix les remplit
    // tous les trois (`brancherConvention`). La liste vient du moteur
    // (`web._conventions`, section `par_convention` du socle) : l'ecran
    // n'invente ni un numero ni un libelle, et il DIT quand une convention
    // existe sans que ses taux soient releves -- le calcul la refuse.
    // LE CODE URSSAF SE CHOISIT (22/09/2026). Trois chiffres a taper, dont
    // personne ne sait ou ils se trouvent, et qu'un rejet de DPAE signale
    // des jours plus tard. La liste est celle de la Table des Urssaf, relevee
    // et datee (`moteur/urssaf.py`). Elle ne dit PAS quel organisme couvre
    // quel territoire : l'ecran ne le devine donc pas depuis le code postal,
    // il propose, et l'aide dit ou lire le code.
    // LA SIGNATURE DES COURRIELS SE COLLE (08/10/2026) : un cadre qui garde la
    // mise en forme copiee depuis une messagerie, son poids sous le cadre. Le
    // HTML part dans un champ cache ; le moteur le nettoie encore a l'envoi.
    if (c.cle === "courriel_signature") {
      const html = nettoyerHtmlColle(String(v ?? ""));
      return `<div class="champ pleine">
        <label>${echapper(c.libelle)}
          ${aideHtml(c.cle, c.aide)}</label>
        <div id="signature-cadre" contenteditable="true"
          style="min-height:4em;border:1px solid #ccc;border-radius:4px;padding:8px;background:#fff"
          >${html}</div>
        <textarea data-cle="${c.cle}" data-forme="${c.forme}" hidden
          >${echapper(html)}</textarea>
        <div style="display:flex;gap:12px;align-items:center;margin-top:6px">
          <span id="signature-poids" class="discret"></span>
          <button type="button" class="secondaire" id="signature-vider"
            >Revenir à la signature habituelle</button>
        </div>
        ${aideCorps(c.cle, c.aide)}
        ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
      </div>`;
    }
    if (c.cle === "code_urssaf" && (ETAT.organismes_urssaf || []).length) {
      const org = ETAT.organismes_urssaf;
      const v3 = String(v ?? "");
      const connu = org.some((o) => o.code === v3);
      return `<div class="champ pleine">
        <label>${echapper(c.libelle)}
          ${aideHtml(c.cle, c.aide)}
          <select data-cle="${c.cle}" data-forme="chiffres">
            <option value=""${v3 ? "" : " selected"}>— celle de votre code postal (${
              echapper(ETAT.urssaf_deduit || "")}) —</option>
            ${org.map((o) => `<option value="${echapper(o.code)}"${
                o.code === v3 ? " selected" : ""}
              >${echapper(o.code)} — ${echapper(o.nom)}</option>`).join("")}
            ${connu || !v3 ? "" : `<option value="${echapper(v3)}" selected
              >${echapper(v3)} — inconnu de la table : la DPAE serait rejetée</option>`}
          </select></label>
        ${aideCorps(c.cle, c.aide)}
        ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
      </div>`;
    }
    if (c.cle === "idcc" && (ETAT.conventions || []).length) {
      const cv = ETAT.conventions;
      const connue = cv.some((x) => String(x.idcc) === String(v ?? ""));
      return `<div class="champ pleine">
        <label>Convention collective
          ${c.obligatoire ? '<span class="obligatoire">*</span>' : ""}
          ${aideHtml(c.cle, c.aide)}
          <select data-cle="${c.cle}" data-forme="chiffres">
            ${cv.map((x) => `<option value="${echapper(x.idcc)}"${
                String(x.idcc) === String(v ?? "") ? " selected" : ""}
              >IDCC ${echapper(x.idcc)} — ${echapper(x.libelle)}${
                x.applicable ? "" : " (taux non relevés : le calcul refuse)"}</option>`).join("")}
            ${connue ? "" : `<option value="${echapper(v ?? "")}" selected
              >IDCC ${echapper(v ?? "(vide)")} — non servie par le barème</option>`}
          </select></label>
        ${aideCorps(c.cle, c.aide)}
        ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
      </div>`;
    }
    // UNE LISTE DE CHOIX SE CHOISIT (23/09/2026) : l'annexe s'ecrivait « 4 »
    // a la main, le CSE « cse_adherent_fnas ».
    // La fiche salarie a suivi le meme jour : le sexe s'ecrivait « 2 », la
    // nationalite « 01 », le statut cadre « 04 ».
    if (["entreprise", "salarie"].includes(FICHE_ACTIVE) && c.forme === "choix"
        && (c.choix || []).length) {
      const lib = LIBELLES_CHOIX[c.cle] || {};
      const v1 = String(v ?? "");
      // L'ordre de la table des libelles (le cas ordinaire d'abord), puis ce
      // qu'elle ne nomme pas ; un choix vide prevu par le moteur (« aucun »)
      // tient lieu de premiere ligne.
      const ordre = [...(c.choix.includes("") ? [""] : []),
        ...Object.keys(lib).filter((x) => x && c.choix.includes(x)),
        ...c.choix.filter((x) => x && !(x in lib))];
      return `<div class="champ${FICHE_ACTIVE === "entreprise" ? " pleine" : ""}">
        <label>${echapper(c.libelle)}${facultatif(c)}
          ${c.obligatoire ? '<span class="obligatoire">*</span>' : ""}
          ${aideHtml(c.cle, c.aide)}
          <select data-cle="${c.cle}" data-forme="choix">
            ${c.choix.includes("") ? "" : `<option value=""${v1 ? "" : " selected"}>— ${
              c.cle in ORDINAIRE_VIDE ? echapper(ORDINAIRE_VIDE[c.cle]) : "à choisir"} —</option>`}
            ${ordre.map((x) => `<option value="${echapper(x)}"${
                x === v1 ? " selected" : ""}>${echapper(lib[x] || x)}</option>`).join("")}
            ${!v1 || c.choix.includes(v1) ? "" : `<option value="${echapper(v1)}" selected
              >${echapper(v1)}</option>`}
          </select></label>
        ${aideCorps(c.cle, c.aide)}
        ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
      </div>`;
    }
    // LES AUTRES NOMS D'UN SPECTACLE (23/09/2026) : une liste de mots, qui
    // s'affichait en JSON, crochets et guillemets compris. Une ligne, les
    // noms separes par des virgules ; `lireFormulaire` refait la liste.
    if (c.cle === "alias" && FICHE_ACTIVE === "spectacle"
        && (v == null || (Array.isArray(v) && v.every((x) => typeof x === "string")))) {
      return `<div class="champ pleine">
        <label>${echapper(c.libelle)}${facultatif(c)} ${aideHtml(c.cle, c.aide)}
          <input data-cle="${c.cle}" data-liste-textes="1" value="${echapper((v || []).join(", "))}"
                 placeholder="ex. zerbinette, aaah">
        </label>
        ${aideCorps(c.cle, c.aide)}
        ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
      </div>`;
    }
    // UNE CASE A COCHER SE LIT COMME UNE PHRASE : la case, puis ce qu'elle dit.
    if (c.forme === "booleen") {
      const coche = v == null ? c.booleen_defaut !== false : v !== false;
      return `<div class="champ pleine case${c.si_permanents ? " champ-permanents" : ""}"${
          c.si_permanents && !avecPermanents ? " hidden" : ""}>
        <label class="coche"><input type="checkbox" data-cle="${c.cle}"
            data-forme="booleen"${coche ? " checked" : ""}>
          ${echapper(c.libelle)} ${aideHtml(c.cle, c.aide)}</label>
        ${aideCorps(c.cle, c.aide)}
        ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
      </div>`;
    }
    const structure = c.forme === "structure" || (v !== null && typeof v === "object");
    // Un booleen se coche. Ecrit en toutes lettres, il partait en texte : et
    // « false » est une chaine VRAIE, donc la fiche serait restee active en
    // paraissant archivee.
    // Un booléen ABSENT ne vaut pas la même chose partout : `actif` absent
    // vaut vrai (aucune fiche existante n'a à être modifiée pour rester
    // active), `emploie_des_permanents` absent vaut faux. C'est le champ qui
    // le dit — la page cochait d'office, et écrivait donc l'inverse de ce que
    // le moteur lisait.
    const controle = c.forme === "booleen"
      ? `<input type="checkbox" data-cle="${c.cle}" data-forme="booleen"
            ${(v == null ? c.booleen_defaut !== false : v !== false) ? "checked" : ""}>`
      : structure
      ? `<textarea rows="4" data-cle="${c.cle}" data-structure="1">${echapper(JSON.stringify(v ?? null, null, 1))}</textarea>`
      : `<input data-cle="${c.cle}" data-forme="${c.forme}" value="${echapper(v ?? "")}"${
            // Une date de la fiche salarie se choisit dans un calendrier
            // (23/09/2026) ; la valeur reste AAAA-MM-JJ, celle du moteur.
            FICHE_ACTIVE === "salarie" && c.forme === "date"
              && /^(\d{4}-\d{2}-\d{2})?$/.test(String(v ?? "")) ? ' type="date"' : ""}${
            c.exemple ? ` placeholder="ex. ${echapper(c.exemple)}"` : ""}
            class="${a ? (a.gravite === "erreur" ? "faute" : "suspect") : ""}">`;
    // L'adresse et le nom prennent la ligne entiere : le code postal et la
    // commune tiennent ensuite cote a cote, comme sur une enveloppe.
    const large = structure || (FICHE_ACTIVE === "entreprise"
      && ["adresse_affichage", "nom_affichage"].includes(c.cle))
      || (FICHE_ACTIVE === "salarie" && ["adresse_affichage", "emploi_affichage"].includes(c.cle));
    return `<div class="champ ${large ? "pleine" : ""}${
        c.si_permanents ? " champ-permanents" : ""}"${
        (c.si_permanents && !avecPermanents)
          || (c.si_etablissements && !avecEtablissements) ? " hidden" : ""}>
      <label>${echapper(c.libelle)}${facultatif(c)}
        ${c.obligatoire ? '<span class="obligatoire">*</span>' : ""}
        ${aideHtml(c.cle, c.aide)}
        ${controle}
      </label>
      ${aideCorps(c.cle, c.aide)}
      ${a ? `<div class="anomalie ${a.gravite}">${echapper(a.message)}</div>` : ""}
    </div>`;
  };

  // LES SECTIONS. Une fiche qui n'en declare pas garde sa liste plate ;
  // un champ oublie d'une table de sections s'affiche dans la derniere.
  // `ecran` faux : le champ garde sa valeur, la fiche ne le montre pas (§94).
  const saisissables = desc.filter((c) => !c.calcule && c.ecran !== false);
  const sections = SECTIONS_FICHE[FICHE_ACTIVE];
  let champs;
  if (!sections) {
    champs = saisissables.map(champHtml).join("");
  } else {
    const parCle = {};
    saisissables.forEach((c) => { parCle[c.cle] = c; });
    const places = new Set();
    sections.forEach(([, cles]) => cles.forEach((k) => places.add(k)));
    const reste = saisissables.filter((c) => !places.has(c.cle));
    // Un champ oublie des tables va dans la derniere section TITREE : la
    // derniere tout court peut etre l'historique, qui n'a pas de titre.
    const derniereTitree = sections.map(([t]) => !!t).lastIndexOf(true);
    champs = sections.map(([titre, cles, options], i) => {
      let dedans = cles.map((k) => parCle[k]).filter(Boolean);
      if (i === derniereTitree) dedans = dedans.concat(reste);
      if (!dedans.length) return "";
      // Une section vide ne s'affiche pas : « Ce qui a changé » n'a de titre
      // que le jour ou une valeur declaree a change (`histoireDuChamp` ne
      // rend rien avant).
      const dedansHtml = dedans.map(champHtml).join("");
      if (!dedansHtml.trim()) return "";
      // La section des permanents suit la case : rien a remplir tant que la
      // compagnie n'a pas dit en employer.
      const toute = dedans.every((c) => c.si_permanents);
      if ((options || {}).avance) {
        // Ce qui vaut le cas ordinaire n'ouvre pas le tiroir : l'Urssaf du
        // code postal, Audiens.
        // code postal, Audiens ; pour un salarie, le matricule et le reste
        // de ce qui est toujours rempli (ORDINAIRE).
        const ecart = dedans.some((c) => {
          const v = fiche.donnees[c.cle];
          return !caches.includes(c.cle) && v !== null && v !== undefined
            && v !== "" && v !== false && !(ORDINAIRE[c.cle] || (() => false))(v);
        });
        return `<details class="bloc avance"${ecart ? " open" : ""}>
          <summary>${echapper(titre)}</summary>
          <div class="champs">${dedansHtml}</div>
        </details>`;
      }
      // Le bloc de l'emploi s'ouvre sur la liste des metiers, celui du
      // salarie au mois sur sa complementaire sante : chacun a sa place,
      // et non plus en tete de fiche.
      const opt = options || {};
      const entete = opt.metier ? METIER_HTML(fiche) : opt.sante ? SANTE_HTML()
        : opt.atmp ? ATMP_HTML() : "";
      const permanents = toute || opt.sante;
      // LE BLOC DU SALARIÉ AU MOIS NE S'OUVRE QU'À LUI (26/09/2026). Dans une
      // compagnie qui emploie aussi des permanents, la fiche d'une comédienne
      // au cachet déroulait sa complémentaire santé et sa prévoyance. Replié
      // pour qui n'a jamais eu de contrat au mois — sauf s'il y a déjà une
      // valeur : rien de saisi ne devient invisible.
      if (opt.sante && avecPermanents && FICHE_ACTIVE === "salarie") {
        const auMois = ((ETAT.configuration || {}).salaries_au_mois || []).includes(fiche.cle);
        const rempli = dedans.some((c) => {
          const v = fiche.donnees[c.cle];
          return v !== null && v !== undefined && v !== "";
        }) || !!fiche.donnees.sante_svp;
        return `<details class="bloc avance" data-bloc-permanents="1"${auMois || rempli ? " open" : ""}>
          <summary>${echapper(titre)}${auMois ? "" : ` <span class="discret">— s'il est payé au mois</span>`}</summary>
          ${entete}
          <div class="champs">${dedansHtml}</div>
        </details>`;
      }
      return `<section class="bloc"${permanents && !avecPermanents ? ' hidden' : ''}${
          permanents ? ' data-bloc-permanents="1"' : ''}>
        ${titre ? `<h3>${echapper(titre)}</h3>` : ""}
        ${entete}
        <div class="champs">${dedansHtml}</div>
      </section>`;
    }).join("");
  }

  const err = fiche.anomalies.filter((a) => a.gravite === "erreur" && !aRemplir(a)).length;
  document.getElementById("config-formulaire").innerHTML = `
    <div class="carte" style="margin-top:16px">
      ${FICHE_ACTIVE === "salarie" ? enteteSalarie(fiche)
        : FICHE_ACTIVE === "entreprise" ? "" : `<h2>${fiche.cle
          // Le titre, pas la cle : `aaah-zerbinette` est un identifiant interne.
          ? `${echapper(String(fiche.donnees.titre || "").toUpperCase() === "A COMPLETER"
              ? "Spectacle à nommer" : fiche.donnees.titre || fiche.cle)}
             <span class="discret">— ${echapper(fiche.donnees.numero_objet || fiche.cle)}</span>`
          : "Nouveau spectacle"}</h2>
        ${fiche.cle && fiche.donnees.titre ? `<div class="cout-annee" data-cote="spectacles"
          data-cle="${echapper(fiche.donnees.titre)}"></div>` : ""}`}
      ${!fiche.cle && FICHE_ACTIVE === "spectacle" ? `<p class="note">La clé de la
        fiche se fabrique à l'enregistrement.</p>` : ""}
      ${err ? `<div class="encart erreur"><b>${err > 1 ? `${err} champs à corriger` : "Un champ à corriger"}</b>
        — marqué${err > 1 ? "s" : ""} ci-dessous.</div>` : ""}
      ${sections ? champs : `<div class="champs">${champs}</div>`}
      <div class="actions">
        <button class="primaire" id="config-enregistrer">Enregistrer</button>
        <span class="note" id="config-modifie" hidden>modifications non enregistrées</span>
      </div>
    </div>`;

  // LA VERIFICATION EST EN DIRECT, ET ELLE EST SEULE (22/09/2026). Il y
  // avait un bouton « Vérifier sans enregistrer » a cote d'« Enregistrer ».
  // Il appelait la MEME fonction que la frappe, a 400 ms pres : un bouton
  // qui ne fait rien de plus que ce qui se fait deja tout seul. L'editeur :
  // « je comprends pas à quoi il sert ». Aucun champ ne demande d'appel
  // exterieur — tout se verifie sur le poste, dans `moteur/champs.py` —,
  // donc rien ne justifie un declenchement a la main. Le jour ou un champ
  // ira interroger un service (l'annuaire des entreprises pour un SIRET),
  // c'est CE champ-la qui portera son bouton, pas le formulaire entier.
  document.querySelectorAll(
    "#config-formulaire input, #config-formulaire textarea, #config-formulaire select")
    .forEach((c) => { c.oninput = () => { marquerModifie();
      clearTimeout(verifierFormulaire._t);
      verifierFormulaire._t = setTimeout(verifierFormulaire, 400); }; });
  document.getElementById("config-enregistrer").onclick = () => enregistrerFiche(fiche);
  const choixMetier = document.getElementById("config-metier-choix");
  if (choixMetier) {
    choixMetier.value = (fiche.donnees || {}).code_emploi_ft || "";
    choixMetier.onchange = async () => { await remplirDepuisMetier(choixMetier.value); marquerModifie(); };
  }
  const allerMetiers = document.getElementById("aller-metiers");
  if (allerMetiers) allerMetiers.onclick = () =>
    document.querySelector('.sous-onglets button[data-fiche="metiers"]').click();
  brancherAide();
  brancherAtmp();
  peindreCoutAnnee();
  brancherListes(fiche);
  brancherDeduits();
  brancherConvention();
  brancherUrssaf();
  brancherSignatureCourriel();
  brancherNumeros();
  brancherSante(fiche);
  brancherPermanents();
  brancherConditions();       // après : c'est lui qui a le dernier mot
  brancherNir();
  brancherSalarie(fiche);
  FICHE_MODIFIEE = false;
  try { FICHE_INITIALE = JSON.stringify(lireFormulaire()); }
  catch (e) { FICHE_INITIALE = null; }
  const t = document.getElementById("config-modifie");
  if (t) t.hidden = true;
}

/* Le HTML colle, sans ce qui s'executerait dans la page : scripts, cadres,
 * objets, formulaires, gestionnaires `on...`, liens `javascript:`. Le moteur
 * refait ce menage a l'envoi ; ici, c'est la page qu'on protege. */
const SIGNATURE_LIMITE = 150 * 1024;
function nettoyerHtmlColle(html) {
  const doc = new DOMParser().parseFromString(`<body>${html}</body>`, "text/html");
  doc.body.querySelectorAll(
    "script,style,iframe,object,embed,form,noscript,template,svg,math,meta,link,base,input,button,textarea,select")
    .forEach((n) => n.remove());
  doc.body.querySelectorAll("*").forEach((n) => {
    [...n.attributes].forEach((at) => {
      if (/^on/i.test(at.name) || /^\s*(java|vb)script:/i.test(at.value)) n.removeAttribute(at.name);
    });
  });
  return doc.body.innerHTML.trim();
}

function brancherSignatureCourriel() {
  const cadre = document.getElementById("signature-cadre");
  const champ = document.querySelector('#config-formulaire [data-cle="courriel_signature"]');
  if (!cadre || !champ) return;
  const poids = document.getElementById("signature-poids");
  const peser = () => {
    const n = new Blob([champ.value]).size;
    poids.textContent = n ? `${Math.ceil(n / 1024)} Ko sur 150 Ko` : "signature habituelle";
    poids.style.color = n > SIGNATURE_LIMITE ? "#B22222" : "";
    if (n > SIGNATURE_LIMITE) poids.textContent += " — trop lourde : une image collée pèse tout son poids, préférez une image en ligne";
  };
  const relire = () => {
    // Un cadre vide garde souvent un <br> : c'est vide.
    const propre = cadre.textContent.trim() || cadre.querySelector("img") ? nettoyerHtmlColle(cadre.innerHTML) : "";
    champ.value = propre;
    peser();
    marquerModifie();
    clearTimeout(verifierFormulaire._t);
    verifierFormulaire._t = setTimeout(verifierFormulaire, 400);
  };
  cadre.addEventListener("input", relire);
  // Le collage garde la mise en forme, mais passe par le menage avant d'entrer.
  cadre.addEventListener("paste", (e) => {
    const html = e.clipboardData && e.clipboardData.getData("text/html");
    if (!html) return;               // du texte seul : le cadre le colle lui-meme
    e.preventDefault();
    document.execCommand("insertHTML", false, nettoyerHtmlColle(html));
    relire();
  });
  document.getElementById("signature-vider").onclick = () => {
    cadre.innerHTML = "";
    relire();
  };
  peser();
}

/* CHANGER D'URSSAF SE CONFIRME (08/10/2026). Celle du code postal est
 * celle qui recoit les declarations ; en choisir une autre sans un mot
 * passait inapercu jusqu'au rejet. On demande, et « non » remet l'ancienne. */
function brancherUrssaf() {
  const choix = document.querySelector('#config-formulaire select[data-cle="code_urssaf"]');
  if (!choix) return;
  let avant = choix.value;
  choix.addEventListener("change", () => {
    const deduit = String(ETAT.urssaf_deduit || "");
    const neuf = choix.value;
    if (!neuf || !deduit || neuf === deduit) { avant = neuf; return; }
    const nom = (code) => {
      const o = (ETAT.organismes_urssaf || []).find((x) => x.code === code);
      return o ? `${code} — ${o.nom}` : code;
    };
    let repondu = false;
    const repondre = (garder) => {
      if (repondu) return;
      repondu = true;
      if (garder) avant = neuf;
      else { choix.value = avant; marquerModifie(); }
    };
    ouvrirBoite(`<h3>Changer d'Urssaf ?</h3>
      <p>D'après l'adresse de l'entreprise, vos déclarations vont à
        <strong>${echapper(nom(deduit))}</strong>. C'est elle qui reçoit
        normalement DPAE et DSN.</p>
      <p>Vous avez choisi <strong>${echapper(nom(neuf))}</strong>.
        Une Urssaf qui ne vous gère pas peut faire rejeter vos déclarations.
        Voulez-vous vraiment la changer ?</p>
      <div class="actions">
        <button class="secondaire" id="u-garder-ancienne">Non, revenir en arrière</button>
        <button class="primaire" id="u-changer">Oui, changer</button>
      </div>`, () => repondre(false));
    document.getElementById("u-changer").onclick = () => { repondre(true); fermerBoite(); };
    document.getElementById("u-garder-ancienne").onclick = () => { repondre(false); fermerBoite(); };
  });
}

/* Le « ? » de chaque champ : il ouvre et referme son aide, et rien d'autre. */
function brancherAide() {
  document.querySelectorAll("#config-formulaire .aide-bouton").forEach((b) => {
    b.onclick = () => {
      const corps = document.querySelector(
        `#config-formulaire [data-aide-corps="${CSS.escape(b.dataset.aide)}"]`);
      if (!corps) return;
      corps.hidden = !corps.hidden;
      b.classList.toggle("ouvert", !corps.hidden);
    };
  });
}

/* Le « + » et la croix des listes (licences, etablissements). On redessine
 * la liste seule, a partir de ce qui est tape : rien n'est perdu en route. */
function brancherListes(fiche) {
  const lire = (cle) => {
    const l = [];
    document.querySelectorAll(
      `#config-formulaire [data-liste-de="${CSS.escape(cle)}"]`).forEach((c) => {
      const i = +c.dataset.listeIndex;
      l[i] = l[i] || {};
      l[i][c.dataset.sousCle] = c.value;
    });
    return l.filter(Boolean);
  };
  const redessiner = (cle, lignes) => {
    const sous = SOUS_CHAMPS[cle];
    const boite = document.querySelector(
      `#config-formulaire [data-liste="${CSS.escape(cle)}"]`);
    boite.innerHTML = lignes.map((l, i) => ligneStructure(cle, sous, l, i)).join("");
    boite.querySelectorAll("input").forEach((c) => {
      c.oninput = () => { marquerModifie();
        clearTimeout(verifierFormulaire._t);
        verifierFormulaire._t = setTimeout(verifierFormulaire, 400); };
    });
    brancherListes(fiche);
    marquerModifie();
  };
  document.querySelectorAll("#config-formulaire .ajouter-ligne").forEach((b) => {
    b.onclick = () => redessiner(b.dataset.ajouter, lire(b.dataset.ajouter).concat([{}]));
  });
  document.querySelectorAll("#config-formulaire .retirer-ligne").forEach((b) => {
    b.onclick = () => {
      const boite = b.closest(".liste-structure");
      const cle = boite.dataset.liste;
      const i = +b.closest(".ligne-structure").dataset.index;
      redessiner(cle, lire(cle).filter((_, n) => n !== i));
    };
  });
}

/*  LE SIREN ET LE NIC NE SE TAPENT PAS (22/09/2026)
 *
 *  Ils SONT le SIRET : ses neuf premiers chiffres et ses cinq derniers. La
 *  page en demandait trois saisies, dont deux qui ne peuvent que se
 *  contredire. Elles restent dans le formulaire — le moteur les lit, et le
 *  NIC dit quel etablissement on declare —, mais en cases cachees, remplies
 *  d'ici. Tant que le SIRET n'a pas ses quatorze chiffres, on ne touche a
 *  rien : une saisie en cours n'a pas a effacer ce que la fiche portait.
 */
function brancherDeduits() {
  const siret = document.querySelector('#config-formulaire [data-cle="siret"]');
  const siren = document.querySelector('#config-formulaire [data-cle="siren"]');
  const nic = document.querySelector('#config-formulaire [data-cle="nic"]');
  if (!siret || !siren || !nic) return;
  const poser = () => {
    const v = (siret.value || "").replace(/\D/g, "");
    if (v.length !== 14) return;
    siren.value = v.slice(0, 9);
    nic.value = v.slice(9);
  };
  siret.addEventListener("input", poser);
  poser();
}

/*  UN SEUL CHOIX POUR LA CONVENTION (22/09/2026)
 *
 *  L'IDCC remplit ses deux doubles, qui restent dans la fiche en cases
 *  cachees : le LIBELLE (il s'imprime sur le bulletin) et le CODE CONVENTION
 *  DSN (rubrique S21.G00.11.022, sur l'etablissement, la meme valeur que
 *  l'IDCC du contrat en S21.G00.40.017).
 *
 *  Et l'ANNEXE ne se montre que pour la 3090 : les six annexes sont les
 *  siennes, elles ne veulent rien dire ailleurs. Elle ne se declare nulle
 *  part -- elle sert aux minima conventionnels.
 */
function brancherConvention() {
  const idcc = document.querySelector('#config-formulaire [data-cle="idcc"]');
  if (!idcc) return;
  const libelle = document.querySelector('#config-formulaire [data-cle="convention_collective"]');
  const codeDsn = document.querySelector('#config-formulaire [data-cle="code_convention_dsn"]');
  const annexe = document.querySelector('#config-formulaire [data-cle="annexe_convention"]');
  // Le libelle ne se reecrit que si l'on CHANGE de convention : au
  // chargement, celui que la fiche porte (« Spectacle vivant du secteur
  // privé ») valait mieux que celui du catalogue, sans accents, qui
  // l'ecrasait a chaque enregistrement.
  const idccDepart = String(idcc.value || "");
  const poser = () => {
    const v = String(idcc.value || "");
    const cv = (ETAT.conventions || []).find((x) => String(x.idcc) === v);
    if (cv && libelle && (v !== idccDepart || !libelle.value)) libelle.value = cv.libelle;
    if (codeDsn) codeDsn.value = v;
    const champAnnexe = annexe && annexe.closest(".champ");
    if (champAnnexe) champAnnexe.hidden = v !== "3090";
    // CE QUI NE CONCERNE QU'UNE CONVENTION, ET QU'UNE GRANDE STRUCTURE
    // (23/09/2026). Le CSE decide du FNAS de la CCNEAC ; l'exemption de la
    // CASC-SVP n'existe que dans la 3090, et seulement a cinquante salaries
    // avec un CSE -- qui se dit alors dans le meme champ. Une petite
    // compagnie ne voit ni l'un ni l'autre, sauf s'ils sont deja remplis.
    const casc = document.querySelector('#config-formulaire [data-cle="casc_svp_exemptee"]');
    const cse = document.querySelector('#config-formulaire [data-cle="representation_personnel"]');
    const champCasc = casc && casc.closest(".champ");
    const champCse = cse && cse.closest(".champ");
    if (champCasc) champCasc.hidden = v !== "3090";
    if (champCse) {
      champCse.hidden = !(v === "1285" || (v === "3090" && casc && casc.checked)
                          || String(cse.value || "").trim());
    }
  };
  idcc.addEventListener("change", poser);
  const casc = document.querySelector('#config-formulaire [data-cle="casc_svp_exemptee"]');
  if (casc) casc.addEventListener("change", poser);
  poser();
}

/*  LES NUMEROS QUI SE DEDUISENT D'UN AUTRE (23/09/2026)
 *
 *  Congés Spectacles : l'affiliation de la DSN (S21.G00.40.022) est le
 *  numero d'adherent precede de 97 -- c'est ce que la fiche de la compagnie
 *  montre (`970123450001F` pour `0123450001F`). France Travail : le code
 *  employeur est le numero d'affiliation sans sa cle, son dernier chiffre.
 *  On ne recalcule que si la case cachee etait vide ou suivait deja la
 *  regle : une valeur posee a la main, qui la contredit, n'est pas ecrasee.
 */
function brancherNumeros() {
  const lier = (source, cible, regle) => {
    const s = document.querySelector(`#config-formulaire [data-cle="${source}"]`);
    const c = document.querySelector(`#config-formulaire [data-cle="${cible}"]`);
    if (!s || !c) return;
    const suit = !c.value || c.value === regle(s.value || "");
    s.addEventListener("input", () => {
      if (!suit) return;
      c.value = regle(s.value || "");
    });
  };
  lier("congesspectacles_adherent", "congesspectacles_affiliation",
       (v) => { const n = v.replace(/\s/g, ""); return n ? "97" + n : ""; });
  lier("affiliation_france_travail", "code_employeur_france_travail",
       (v) => { const n = v.replace(/\D/g, ""); return n.length > 1 ? n.slice(0, -1) : ""; });
}

/*  LE NUMERO DE SECURITE SOCIALE SE COLLE D'UN COUP (23/09/2026)
 *
 *  Il s'ecrit en quinze chiffres sur la carte Vitale ; la fiche le garde en
 *  deux cases, le numero et sa cle, parce que la cle VERIFIE le numero (le
 *  moteur la recalcule). Coller les quinze dans la premiere les repartit.
 *  Et le SEXE ne se montre que sans numero : c'est le seul cas ou il sert.
 */
function brancherNir() {
  const nir = document.querySelector('#config-formulaire [data-cle="nir"]');
  const cle = document.querySelector('#config-formulaire [data-cle="nir_cle"]');
  if (!nir) return;
  const sexe = document.querySelector('#config-formulaire [data-cle="sexe"]');
  const champSexe = sexe && sexe.closest(".champ");
  const poser = () => {
    const v = (nir.value || "").replace(/[\s.\-]/g, "");
    if (cle && /^\d{15}$/.test(v)) {
      nir.value = v.slice(0, 13);
      cle.value = v.slice(13);
    }
    if (champSexe) champSexe.hidden = !!nir.value.trim() && !String(sexe.value || "").trim();
  };
  nir.addEventListener("input", poser);
  poser();
}

/*  CE QUE LA FICHE SALARIE BRANCHE DE PLUS (23/09/2026)
 *
 *  - l'echelon CCNEAC ne se montre que pour une compagnie de la CCNEAC ;
 *  - « Exporter ses documents » mene a l'onglet Exports, le dossier de ce
 *    salarie deja choisi, sur l'annee la plus recente ;
 *  - une fiche neuve peut partir chez la personne, par courriel.
 */
function brancherSalarie(fiche) {
  if (FICHE_ACTIVE !== "salarie") return;
  const idcc = String((((ETAT.configuration || {}).entreprise || {}).donnees || {}).idcc || "");
  const echelon = document.querySelector('#config-formulaire [data-cle="echelon_ccneac"]');
  if (echelon && idcc !== "1285" && !String(echelon.value || "").trim()) {
    echelon.closest(".champ").hidden = true;
  }
  const exporter = document.getElementById("config-exporter");
  if (exporter) exporter.onclick = () => exporterSalarie(fiche.cle);
  const inviter = document.getElementById("invitation-envoyer");
  if (inviter) inviter.onclick = () => demanderFiche(inviter);
}

/* Le salarie a choisir dans « Le dossier d'un salarié », a l'arrivee dans
 * l'onglet Exports (`dessinerDossier` le lit, puis l'oublie). */
let DOSSIER_PRECHOIX = null;

async function exporterSalarie(cle) {
  if (!(await quitterLaFiche())) return;
  DOSSIER_PRECHOIX = cle;
  // L'onglet se dessine a son arrivee, et `dessinerDossier` y pose le choix.
  document.querySelector('.onglets button[data-vue="exports"]').click();
}

async function demanderFiche(bouton) {
  const adresse = (document.getElementById("invitation-courriel").value || "").trim();
  const prenom = (document.getElementById("invitation-prenom").value || "").trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(adresse)) {
    dire("Il faut son adresse de courriel.");
    return;
  }
  const mdp = await demanderMotDePasse(`envoyer la demande de fiche à ${adresse}`);
  if (!mdp) return;
  bouton.disabled = true;
  const repere = await repereCourrielsDemo();
  try {
    const r = await api("fiche-demander", { adresse, prenom, motdepasse: mdp });
    // La réponse ne porte plus la configuration (ni NIR ni IBAN) : la page la relit.
    ETAT.configuration = await api("configuration", {});
    FICHE_MODIFIEE = false;
    CLE_ACTIVE = null;
    FICHE_NEUVE = false;
    dessinerConfig();
    dire(`Demande envoyée à ${r.adresse}. Sa fiche se créera à l'arrivée de sa réponse.`);
    fenetreCourrielsDemo("fiche", repere);
  } catch (e) {
    bouton.disabled = false;
    dire(e.message, "erreur");
  }
}

/* Les demandes parties et pas revenues, sous la liste des salaries. */
function fichesAttenduesHtml() {
  const l = (ETAT.configuration || {}).fiches_attendues || [];
  if (!l.length) return "";
  return `<div class="encart attente-fiches">
    <b>${l.length} fiche(s) demandée(s), en attente de réponse</b>
    <button class="lien" id="fiches-relever">relever maintenant</button>
    <ul>${l.map((a) => `<li>${echapper(a.prenom ? a.prenom + " — " : "")}${
        echapper(a.adresse)} <span class="discret">demandée le ${
        echapper(jjmmaaaa(String(a.quand || "").slice(0, 10)))}</span>
      <button class="lien" data-oublier-fiche="${echapper(a.code)}">ne plus attendre</button></li>`).join("")}</ul>
  </div>`;
}

function brancherFichesAttendues() {
  const relever = document.getElementById("fiches-relever");
  if (relever) relever.onclick = async () => {
    relever.disabled = true;
    try {
      const r = await api("fiches-relever", {});
      ETAT.configuration = await api("configuration", {});
      dessinerConfig();
      dire(r.recues.length ? `${r.recues.length} fiche(s) reçue(s) : ${
        r.recues.map((x) => x.nom).join(", ")}.`
        : (r.incidents[0] || "Aucune réponse pour l'instant."),
        undefined);
    } catch (e) { relever.disabled = false; dire(e.message, "erreur"); }
  };
  document.querySelectorAll("[data-oublier-fiche]").forEach((b) => {
    b.onclick = async () => {
      try {
        await api("fiche-oublier-demande", { code: b.dataset.oublierFiche });
        // La réponse ne porte plus la configuration (ni NIR ni IBAN) : la page la relit.
        ETAT.configuration = await api("configuration", {});
        dessinerConfig();
      } catch (e) { dire(e.message, "erreur"); }
    };
  });
}

/** LA CASE OUVRE LES CHAMPS TOUT DE SUITE, sans attendre l'enregistrement.
 *  La cocher et ne rien voir apparaître, ce serait laisser croire qu'elle ne
 *  fait rien — alors que c'est elle qui décide de ce qu'il reste à remplir.
 *  Le déroulant « Nature » d'un engagement, lui, suit à l'enregistrement :
 *  il vient du serveur, qui ne propose que ce que le moteur accepterait. */
function brancherPermanents() {
  const case_ = document.querySelector(
    '#config-formulaire [data-cle="emploie_des_permanents"]');
  if (!case_) return;
  const montrer = () => {
    const oui = case_.checked;
    // Un champ qui dépend AUSSI d'autre chose (`si`, l'entreprise) suit
    // `brancherConditions`, qui écoute cette case comme les autres.
    document.querySelectorAll("#config-formulaire .champ-permanents")
      .forEach((c) => {
        if (c.hasAttribute("data-si") || c.hasAttribute("data-hors-entreprise")) return;
        c.hidden = !oui;
      });
    // La section entiere avec, sinon son titre reste seul au-dessus du vide.
    document.querySelectorAll("#config-formulaire [data-bloc-permanents]")
      .forEach((s) => { s.hidden = !oui; });
    const sante = document.getElementById("config-sante");
    if (sante) sante.hidden = !oui;
  };
  case_.addEventListener("change", montrer);
  montrer();
}

/** La condition d'un champ (`si`, `si_entreprise` du moteur) : chaque clé
 *  doit valoir l'une des valeurs dites ; "*" veut dire « remplie ». */
function conditionRemplie(si, lire) {
  return Object.entries(si || {}).every(([k, vals]) => {
    const v = String(lire(k) ?? "").trim();
    return vals.includes(v) || (vals.includes("*") && v !== "" && v !== "false");
  });
}

/** LES CHAMPS QUI DÉPENDENT D'UN AUTRE (`si` du moteur) : ils suivent la
 *  valeur à l'écran, tout de suite, comme la case des permanents. */
function brancherConditions() {
  const form = document.getElementById("config-formulaire");
  if (!form) return;
  const valeur = (k) => {
    const c = form.querySelector(`[data-cle="${CSS.escape(k)}"]`);
    return c ? (c.type === "checkbox" ? String(c.checked) : String(c.value ?? "")) : "";
  };
  const appliquer = () => {
    const perm = form.querySelector('[data-cle="emploie_des_permanents"]');
    form.querySelectorAll("[data-si]").forEach((el) => {
      let si = {};
      try { si = JSON.parse(el.dataset.si); } catch (e) { return; }
      const ok = conditionRemplie(si, valeur) && !el.hasAttribute("data-hors-entreprise");
      const permOk = !el.classList.contains("champ-permanents") || !perm || perm.checked;
      el.hidden = !(ok && permOk);
    });
  };
  const cles = new Set();
  form.querySelectorAll("[data-si]").forEach((el) => {
    try { Object.keys(JSON.parse(el.dataset.si)).forEach((k) => cles.add(k)); } catch (e) { /* rien */ }
  });
  cles.add("emploie_des_permanents");
  cles.forEach((k) => {
    const c = form.querySelector(`[data-cle="${CSS.escape(k)}"]`);
    if (c) c.addEventListener("change", appliquer);
  });
  appliquer();
}

/** Les trois cases de la complémentaire santé, dans les deux sens : elles se
 *  remplissent de ce que la fiche porte, et elles réécrivent le champ
 *  `sante_svp` à chaque changement. Le champ reste là, et c'est voulu — il
 *  est la vérité, et un cas non prévu doit pouvoir s'y taper à la main. */
function brancherSante(fiche) {
  const niveau = document.getElementById("config-sante-niveau");
  if (!niveau) return;
  const conjoint = document.getElementById("config-sante-conjoint");
  const enfants = document.getElementById("config-sante-enfants");
  const champ = document.querySelector('#config-formulaire [data-cle="sante_svp"]');
  const choix = (fiche.donnees || {}).sante_svp || null;
  if (choix) {
    niveau.value = choix.niveau || "";
    conjoint.checked = !!choix.conjoint;
    enfants.value = choix.enfants || 0;
  }
  const ecrire = () => {
    if (!champ) return;
    // Pas de niveau : pas de mutuelle. `null` et non un objet vide — une
    // fiche qui porterait {"niveau": ""} ferait croire à un choix fait.
    champ.value = JSON.stringify(
      niveau.value ? { niveau: niveau.value, conjoint: conjoint.checked,
                       enfants: +enfants.value || 0 } : null, null, 1);
    champ.classList.remove("faute");
    verifierFormulaire();
  };
  [niveau, conjoint, enfants].forEach((c) => { c.onchange = ecrire; });
}

/** Les six champs d'emploi d'une fiche salarié, depuis un métier du
 *  catalogue. La page ne calcule rien : elle recopie ce que le moteur rend
 *  (route « emploi »), qui applique les mêmes règles qu'un engagement. */
async function remplirDepuisMetier(code) {
  if (!code) return;
  let r;
  try { r = await api("emploi", { metier: code }); }
  catch (e) { dire(e.message, "erreur"); return; }
  const poser = (cle, v) => {
    const c = document.querySelector(`#config-formulaire [data-cle="${cle}"]`);
    if (c && v != null) c.value = v;
  };
  poser("emploi_affichage", r.emploi_affichage);
  poser("pcs_ese", r.pcs_ese || "");
  poser("code_emploi_ft", r.code_emploi_ft);
  poser("statut", r.statut);
  poser("statut_conventionnel", r.statut_conventionnel || "");
  poser("statut_categoriel_rc", r.statut_categoriel_rc);
  verifierFormulaire();
}

/*  L'HISTOIRE D'UNE FICHE
 *
 *  Une fiche n'est pas un etat, c'est une suite d'etats : on demenage, on
 *  change de telephone, et une valeur declaree se corrige. Chaque ligne dit
 *  ce qu'un champ valait et jusqu'a quel jour -- au-dela, la valeur courante
 *  du formulaire reprend la main.
 *
 *  C'est ce qui permet de rejouer une declaration deja deposee : la DSN de
 *  juillet est partie avec l'adresse de juillet, et elle doit pouvoir se
 *  recalculer a l'identique apres un demenagement en septembre.
 */
function histoireDuChamp(lignes, desc, donnees) {
  if (!Array.isArray(lignes) || !lignes.length) return "";
  const libelle = (cle) => (desc.find((c) => c.cle === cle) || {}).libelle || cle;
  const rangees = [...lignes].sort((a, b) =>
    a.champ === b.champ ? b.jusqu_au.localeCompare(a.jusqu_au)
                        : a.champ.localeCompare(b.champ));
  // Ce qui a remplace une valeur : la ligne suivante du meme champ, ou la
  // valeur courante de la fiche pour la plus recente.
  const remplacante = (e) => {
    const plus_tard = rangees.filter((x) => x.champ === e.champ
      && x.jusqu_au > e.jusqu_au).sort((a, b) => a.jusqu_au.localeCompare(b.jusqu_au));
    return plus_tard.length ? plus_tard[0].valeur : (donnees || {})[e.champ];
  };
  // REPLIEE DEPUIS LE 23/09/2026 : elle sert a qui la cherche, et elle
  // montrait a tout le monde, en bas de chaque fiche, les formes declarees.
  return `<details class="champ pleine historique-fiche">
    <summary>Historique des modifications (${rangees.length})</summary>
    <div class="aide">Les valeurs remplacées, et jusqu'à quand elles ont
       servi. Elles restent pour les déclarations déjà envoyées.</div>
    <div class="histoire">${rangees.map((e) => `
      <div class="histoire-ligne">
        <span class="histoire-champ">${echapper(libelle(e.champ))}</span>
        <span class="histoire-valeur">${echapper(valeurHistorique(e.champ, e.valeur, remplacante(e)))}</span>
        <span class="histoire-date">jusqu'au ${echapper(jjmmaaaa(e.jusqu_au))}</span>
        ${e.note ? `<div class="histoire-note">${echapper(e.note)}</div>` : ""}
      </div>`).join("")}</div>
  </details>`;
}

/* MODIFIER, C'EST TOUJOURS LE MEME BOUTON (24/09/2026) : un crayon et le
   mot. Il y en avait trois formes -- un lien rouge « Modifier… » sur les
   paies, un bouton vert au crayon sur les fiches, « Remplacer… » ou
   « Changer… » sur les mots de passe et la signature. Les points de
   suspension disent qu'une boite s'ouvre avant. Voir `.modifier`. */
const CRAYON = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16v4z"/><path d="M13.5 6.5l4 4"/></svg>`;

/* UN MONTANT S'ECRIT D'UNE SEULE FACON (24/09/2026) : « 1 053,08 € ». Le
   moteur envoie des nombres (« 210.80 ») ; la page en avait trois mises en
   forme locales, et une dizaine d'endroits montraient le nombre tel quel --
   la boite de depot DSN disait « 210.80 € » a cote d'un apercu en
   « 1 053,08 € ». Ce qui n'est pas un nombre repart tel quel. */
function euros(v) {
  const n = typeof v === "number" ? v : Number(String(v ?? "").trim());
  if (v === null || v === undefined || String(v).trim() === "" || !isFinite(n)) {
    return String(v ?? "");
  }
  return n.toLocaleString("fr-FR", { minimumFractionDigits: 2,
                                      maximumFractionDigits: 2 }) + " €";
}

function jjmmaaaa(iso) {
  if (!iso || iso.length !== 10) return iso || "";
  return `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}`;
}

const MOIS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
                 "août", "septembre", "octobre", "novembre", "décembre"];
/* « juillet 2021 » et non « 2021-07 » : on lit une phrase, pas un tri. */
function moisEnClair(iso) {
  if (!iso || iso.length !== 7) return iso || "";
  return `${MOIS_FR[Number(iso.slice(5, 7)) - 1]} ${iso.slice(0, 4)}`;
}

function lireFormulaire() {
  const d = {};
  document.querySelectorAll("#config-formulaire [data-cle]").forEach((c) => {
    if (c.dataset.listeTextes) {
      d[c.dataset.cle] = c.value.split(",").map((x) => x.trim()).filter(Boolean);
    } else if (c.dataset.structure) {
      try { d[c.dataset.cle] = JSON.parse(c.value); }
      catch (e) { c.classList.add("faute"); }
    } else if (c.dataset.forme === "booleen") {
      d[c.dataset.cle] = c.checked;      // un vrai booleen, pas « true »
    } else {
      d[c.dataset.cle] = c.value;
    }
  });
  // LES STRUCTURES SAISIES CASE PAR CASE. On repart de l'objet d'origine :
  // le signataire porte un `nom_aem` et une note que l'ecran ne montre pas,
  // la banque un avertissement de diffusion. Ne relire que les cases
  // affichees, ce serait les effacer au premier enregistrement.
  const types = new Set();
  document.querySelectorAll("#config-formulaire [data-sous-de]").forEach((c) => {
    const p = c.dataset.sousDe;
    if (!d[p] || typeof d[p] !== "object" || Array.isArray(d[p])) {
      d[p] = JSON.parse(JSON.stringify(STRUCTURES_ORIGINE[p] || {}));
    }
    const chemin = c.dataset.sousCle.split(".");
    let o = d[p];
    chemin.slice(0, -1).forEach((k) => {
      if (!o[k] || typeof o[k] !== "object") o[k] = {};
      o = o[k];
    });
    const k = chemin[chemin.length - 1];
    // Une case typee (choix, nombre) vide est RETIREE : le moteur applique
    // alors son defaut, celui de la convention. Un texte garde sa valeur.
    if (c.dataset.sousType) {
      types.add(p);
      if (String(c.value).trim() === "") delete o[k];
      else o[k] = c.dataset.sousType === "nombre" ? Number(c.value) : c.value;
    } else {
      o[k] = c.value;
    }
  });
  // Un bloc dont il ne reste rien (sous-blocs vides compris) vaut « rien ».
  const vide = (x) => x === "" || x == null ||
    (typeof x === "object" && !Array.isArray(x) && Object.values(x).every(vide));
  types.forEach((p) => {
    if (d[p] && typeof d[p] === "object") {
      Object.keys(d[p]).forEach((k) => { if (vide(d[p][k])) delete d[p][k]; });
      if (!Object.keys(d[p]).length) d[p] = null;
    }
  });
  // LES LISTES (licences, etablissements). Une ligne entierement vide ne
  // compte pas : le « + » en pose une avant qu'on la remplisse, et une liste
  // sans rien dedans vaut « rien », pas « une ligne vide ».
  const listes = {};
  document.querySelectorAll("#config-formulaire [data-liste-de]").forEach((c) => {
    const p = c.dataset.listeDe, i = +c.dataset.listeIndex;
    listes[p] = listes[p] || [];
    // Pas de reprise de l'original ici, contrairement aux objets : une ligne
    // ajoutee ou retiree decale les index, et on recopierait la valeur cachee
    // de la ligne d'a cote. Ces listes n'ont pas de clef masquee.
    listes[p][i] = listes[p][i] || {};
    listes[p][i][c.dataset.sousCle] = c.value;
  });
  Object.keys(listes).forEach((p) => {
    const propres = listes[p].filter((l) => l &&
      Object.values(l).some((v) => String(v ?? "").trim() !== ""));
    d[p] = propres.length ? propres : null;
  });
  return d;
}

/*  CE QUE LE MOTEUR PROPOSE POUR UNE CASE VIDE (22/09/2026)
 *
 *  Le code Urssaf se déduit du code postal — deux tables relevées, les 101
 *  départements couverts. Mais le rattachement d'une entreprise à une
 *  Urssaf est un fait ADMINISTRATIF : versement en lieu unique, pôle
 *  grandes entreprises, GUSO. On POSE donc la valeur (ne pas la poser
 *  reviendrait à faire chercher ce qu'on sait déjà), et on DIT qu'elle est
 *  déduite, avec ce qui la ferait changer.
 *
 *  Deux règles, et elles tiennent tout :
 *   - on ne touche jamais une case que quelqu'un a remplie. C'est le
 *     serveur qui le garantit : `suggestions_fiche` ne propose que pour un
 *     champ vide ;
 *   - la mention reste tant que la valeur est celle qu'on a proposée. Elle
 *     disparaît dès qu'on la change : ce n'est alors plus une déduction,
 *     c'est un choix.
 */
function appliquerSuggestions(suggestions) {
  Object.entries(suggestions).forEach(([cle, s]) => {
    const champ = document.querySelector(`#config-formulaire [data-cle="${CSS.escape(cle)}"]`);
    // Le code Urssaf vide vaut deja « celui du code postal » (23/09/2026) :
    // le remplir ici l'ecrirait dans la fiche, et un demenagement ne le
    // suivrait plus.
    if (cle === "code_urssaf") return;
    if (!champ || champ.type === "hidden" || String(champ.value || "").trim()) return;
    champ.value = s.valeur;
    const boite = champ.closest(".champ");
    if (!boite || boite.querySelector(".suggere")) return;
    const note = document.createElement("div");
    note.className = "suggere";
    note.textContent = "Rempli pour vous : " + s.pourquoi;
    boite.appendChild(note);
    // Elle ne vaut que tant qu'on n'a pas choisi soi-même.
    champ.addEventListener("change", () => note.remove(), { once: true });
  });
}

/*  CE QU'ON A TAPÉ ET PAS ENREGISTRÉ (22/09/2026)
 *
 *  La page disait, sous les boutons, que l'ancienne version est copiee dans
 *  `config/avant/` — de la plomberie, affichee a quelqu'un qui n'a rien
 *  demande. Elle ne disait pas, en revanche, ce qui compte vraiment :
 *  quitter l'onglet perdait la saisie, en silence. C'est l'inverse
 *  maintenant. Rien si on n'a rien touche.
 */
let FICHE_MODIFIEE = false;
// LA FICHE TELLE QU'ELLE S'EST OUVERTE (08/10/2026). Taper un « a » puis
// l'effacer demandait d'enregistrer une fiche identique : on compare
// maintenant ce qui est dans les cases a ce qui y etait a l'ouverture.
let FICHE_INITIALE = null;

function ficheIdentique() {
  if (FICHE_INITIALE === null) return false;
  try { return JSON.stringify(lireFormulaire()) === FICHE_INITIALE; }
  catch (e) { return false; }
}

function marquerModifie() {
  if (ficheIdentique()) {
    FICHE_MODIFIEE = false;
    const t = document.getElementById("config-modifie");
    if (t) t.hidden = true;
    return;
  }
  FICHE_MODIFIEE = true;
  const t = document.getElementById("config-modifie");
  if (t) { t.hidden = false; t.textContent = "modifications non enregistrées"; }
}

/** Appelee avant de quitter la fiche en cours. Rend `true` si on peut
 *  partir. Trois issues : enregistrer et partir, partir quand meme, rester. */
async function quitterLaFiche() {
  if (!FICHE_MODIFIEE || ficheIdentique()) return true;
  const fiche = FICHE_COURANTE;
  const choix = await new Promise((resoudre) => {
    let repondu = false;
    const repondre = (v) => { if (!repondu) { repondu = true; resoudre(v); } };
    ouvrirBoite(`<h3>Vous avez modifié cette fiche</h3>
      <p>Vos changements ne sont pas encore enregistrés.</p>
      <div class="actions">
        <button class="primaire" id="q-enregistrer">Enregistrer</button>
        <button class="secondaire" id="q-jeter">Abandonner les modifications</button>
        <button class="secondaire" id="q-rester">Rester sur la fiche</button>
      </div>`, () => repondre("rester"));
    // REPONDRE D'ABORD, FERMER ENSUITE (22/09/2026). Dans l'autre ordre,
    // `fermerBoite` appelait le rappel de fermeture -- « rester » -- avant le
    // bouton : les trois boutons valaient « Rester sur la fiche ».
    document.getElementById("q-enregistrer").onclick = () => { repondre("enregistrer"); fermerBoite(); };
    document.getElementById("q-jeter").onclick = () => { repondre("jeter"); fermerBoite(); };
    document.getElementById("q-rester").onclick = () => { repondre("rester"); fermerBoite(); };
  });
  if (choix === "rester") return false;
  if (choix === "jeter") {
    // La fiche redevient celle de l'entree : on la redessine depuis ce qui
    // est enregistre, sinon la saisie abandonnee resterait dans les cases.
    if (fiche) dessinerFormulaire(fiche);
    FICHE_MODIFIEE = false;
    return true;
  }
  if (fiche) await enregistrerFiche(fiche);
  // Enregistrer peut avoir ete annule (la boite des valeurs datees) : dans
  // ce cas la fiche est toujours modifiee, et on ne part pas.
  return !FICHE_MODIFIEE;
}

/* LA VÉRIFICATION PENDANT LA FRAPPE (revue le 30/09/2026). Le texte sous
 * chaque case suit désormais ce qu'on tape : « obligatoire » restait sous un
 * SIRET valide, et un SIRET faux se colorait sans dire pourquoi. Plus de
 * message volant « N point(s) à regarder » à chaque frappe : la case parle. */
async function verifierFormulaire() {
  const r = await api("verifier-fiche",
    { nom: FICHE_ACTIVE, donnees: lireFormulaire() });
  const anomalies = r.anomalies;
  document.querySelectorAll("#config-formulaire [data-cle]").forEach((c) => {
    const a = anomalies.find((x) => x.champ === c.dataset.cle && !aRemplir(x));
    c.classList.toggle("faute", !!a && a.gravite === "erreur");
    c.classList.toggle("suspect", !!a && a.gravite === "avertissement");
    const champ = c.closest(".champ");
    if (!champ || c.type === "hidden") return;
    let note = champ.querySelector(":scope > .anomalie");
    if (!a) { if (note) note.remove(); return; }
    if (!note) { note = document.createElement("div"); champ.appendChild(note); }
    note.className = `anomalie ${a.gravite}`;
    note.textContent = a.message;
  });
  appliquerSuggestions(r.suggestions || {});
  return anomalies;
}

/** Une case obligatoire laissée vide : l'astérisque suffit à l'écran, le
 *  refus d'enregistrer la nommera. */
function aRemplir(a) {
  return !!a && a.gravite === "erreur" && a.message === "obligatoire";
}

/*  ENREGISTRER UNE FICHE : DATER CE QUI CHANGE
 *
 *  Le §18.12 du journal raconte ce qui arrive quand on ne le fait pas. Une
 *  commune de naissance a ete corrigee depuis cet ecran ; l'avertissement
 *  disait bien « enregistrer declarera PARIS 12E », et il etait juste. Ce
 *  qu'il ne disait pas, c'est que 55 DSN etaient deja parties avec l'autre
 *  forme, et que l'identite est ce sur quoi France Travail et la DGFiP
 *  rapprochent un salarie.
 *
 *  D'ou cette etape, et les deux choses qu'elle demande :
 *
 *   - A PARTIR DE QUAND la nouvelle valeur vaut. Par defaut aujourd'hui,
 *     modifiable : si une declaration est partie ce matin avec l'ancienne,
 *     la nouvelle ne vaut qu'a partir de demain. C'est l'humain qui sait.
 *   - POURQUOI. Une correction et un demenagement se datent pareil ; seule
 *     la note dira, dans deux ans, laquelle des deux c'etait.
 *
 *  Et elle MONTRE ce que l'ancienne valeur a deja servi a declarer, parce
 *  que c'est cette information-la qui fait decider.
 */
async function enregistrerFiche(fiche) {
  const donnees = lireFormulaire();
  const { changements } = await api("changements-declares",
    { nom: FICHE_ACTIVE, cle: fiche.cle, donnees });
  // Ce que le moteur a seul remis en forme ne se demande pas : il le date
  // au jour de l'enregistrement (voir `changements_declares`).
  // Et une valeur qui n'est jamais partie dans une déclaration n'a rien à
  // dater non plus : la boîte « à partir de quand » s'ouvrait sur une fiche
  // qu'on venait de créer (30/09/2026). Elle se date au jour, en silence.
  const aDemander = changements.filter((c) => !c.silencieux
    && ((c.deja_declare || {}).declarations || 0) > 0);
  if (aDemander.length) {
    const daté = await demanderDateDEffet(aDemander);
    if (!daté) return;                       // annulé : rien n'est écrit
    return ecrireFiche(fiche, donnees, daté);
  }
  return ecrireFiche(fiche, donnees, {});
}

/* Une valeur declaree n'est pas toujours un mot : `signataire` et `banque`
 * sont des structures. `echapper(objet)` donnait « [object Object] → [object
 * Object] », c'est-a-dire un changement qu'on ne peut ni lire ni juger --
 * alors que c'est precisement ce que cette boite demande de juger. */
function valeurLisible(v) {
  if (v === null || v === undefined) return "—";
  if (typeof v === "object") {
    return Array.isArray(v) ? v.map(valeurLisible).join(" · ")
      : Object.entries(v).map(([k, x]) => `${k} : ${valeurLisible(x)}`).join(" · ");
  }
  return String(v);
}

/* L'HISTORIQUE D'UN BLOC (24/09/2026). `declarant_dsn` est une structure :
 * l'historique affichait « [object Object] » quand on avait seulement passe
 * le courriel en minuscules. On ne montre que ce qui a CHANGE, avec le
 * libelle de la case -- « Courriel : CONTACT@EXEMPLE.FR ». Une cle que
 * l'ancienne valeur ne portait pas n'est pas un changement : elle est nee
 * depuis. Les cles `_…` sont des notes, pas des valeurs. */
const LIBELLES_CACHES = { nom_prenom: "Nom déclaré", qualite: "Qualité",
                          bic: "BIC", iban: "IBAN", taux: "Taux du contrat" };
function valeurHistorique(champ, avant, apres) {
  if (avant === null || typeof avant !== "object" || Array.isArray(avant)) {
    return valeurLisible(avant);
  }
  const libelles = Object.fromEntries(
    ((SOUS_CHAMPS[champ] || {}).champs || []).map(([k, l]) => [k, l]));
  const courant = apres && typeof apres === "object" ? apres : {};
  const cles = Object.keys(avant).filter((k) => !k.startsWith("_"));
  const changees = cles.filter((k) =>
    JSON.stringify(avant[k]) !== JSON.stringify(courant[k]));
  return (changees.length ? changees : cles)
    .map((k) => `${libelles[k] || LIBELLES_CACHES[k] || k} : ${valeurLisible(avant[k])}`)
    .join(" · ");
}

/* RIEN DE ROUGE (25/09/2026). « On a le droit de changer de métier, je ne sais
 * même pas pourquoi on mettrait un avertissement. » Un changement de fiche est
 * un geste normal : la boîte ne demande que la date d'effet — c'est elle qui
 * garde aux déclarations déjà faites leur ancienne valeur (fiches datées) —,
 * sur un ton neutre. Le métier se dit en UNE ligne : emploi, PCS-ESE et code
 * France Travail changent ensemble, ce sont trois écritures d'un seul fait. */
const CHAMPS_DU_METIER = ["emploi_affichage", "emploi", "pcs_ese", "code_emploi_ft", "statut"];

function demanderDateDEffet(changements) {
  const aujourdHui = new Date().toISOString().slice(0, 10);
  const metier = changements.filter((c) => CHAMPS_DU_METIER.includes(c.champ));
  const autres = changements.filter((c) => !CHAMPS_DU_METIER.includes(c.champ));
  const lisible = (c, cote) => valeurLisible(c[cote + "_lisible"] ?? c[cote]);
  const ligne = (titre, avant, apres, detail = "") => `<div class="changement">
      <div class="changement-titre">${echapper(titre)}</div>
      <div class="changement-valeurs">
        <span class="avant">${echapper(avant)}</span>
        <span class="fleche">→</span>
        <span class="apres">${echapper(apres)}</span>
      </div>${detail ? `<div class="changement-prix">${detail}</div>` : ""}
    </div>`;
  let blocs = "";
  if (metier.length) {
    const emploi = metier.find((c) => c.champ === "emploi_affichage")
      || metier.find((c) => c.champ === "emploi") || metier[0];
    const codes = metier.filter((c) => c !== emploi)
      .map((c) => `${c.libelle} : ${lisible(c, "apres")}`).join(" · ");
    blocs += ligne("Métier", lisible(emploi, "avant"), lisible(emploi, "apres"),
                   codes ? `<span class="discret">${echapper(codes)}</span>` : "");
  }
  blocs += autres.map((c) => ligne(c.libelle, lisible(c, "avant"), lisible(c, "apres"))).join("");
  const titre = metier.length && !autres.length ? "Nouveau métier" : "Ce qui change";
  return new Promise((resoudre) => {
    let repondu = false;
    const repondre = (v) => { if (!repondu) { repondu = true; resoudre(v); } };
    ouvrirBoite(`<h3>${titre}</h3>
      <div class="changements">${blocs}</div>
      <label class="champ-boite">À partir du
        <input type="date" id="b-depuis" value="${aujourdHui}">
      </label>
      <p class="note">Ce qui est déjà déclaré garde l'ancienne valeur ; la
         nouvelle vaut à partir de cette date.</p>
      <details class="b-note-bloc"><summary class="discret">ajouter une note</summary>
        <input type="text" id="b-note" placeholder="correction, déménagement…">
      </details>
      <div class="actions">
        <button class="secondaire" id="b-annuler">Annuler</button>
        <button class="primaire" id="b-dater">Enregistrer</button>
      </div>`,
      // Fermer la boite sans repondre -- clic a cote -- vaut annuler : c'est
      // ce que l'ecran montre, et rien ne doit s'ecrire en douce.
      () => repondre(null));
    document.getElementById("b-annuler").onclick = fermerBoite;
    document.getElementById("b-dater").onclick = () => {
      repondre({ depuis: document.getElementById("b-depuis").value,
                 note: document.getElementById("b-note").value });
      fermerBoite();
    };
  });
}

/* `forcer` : l'utilisateur a passé outre un refus, dans la boîte qui le
 * lui propose. Un seul chemin d'écriture, forcé ou non (30/09/2026) : le
 * chemin forcé se contentait de redessiner, et la fiche restait « modifiée »
 * -- quitter l'onglet demandait d'enregistrer ce qui l'était déjà. */
async function ecrireFiche(fiche, donnees, daté, forcer = false) {
  try {
    const r = await api("enregistrer-fiche",
      { nom: FICHE_ACTIVE, cle: fiche.cle, donnees, ...daté, ...(forcer ? { forcer: true } : {}) });
    ETAT = await api("etat");
    // Une fiche neuve : le moteur a fabriqué sa clé, c'est elle qu'on ouvre.
    if (!fiche.cle && r.fiche && r.fiche.cle) { CLE_ACTIVE = r.fiche.cle; FICHE_NEUVE = false; }
    // « Fiche créée : null. » pour l'entreprise, la clé technique pour un
    // spectacle : le mot suffit.
    dire(forcer ? "Enregistré malgré les erreurs." : fiche.cle ? "Enregistré." : "Fiche créée.");
    FICHE_MODIFIEE = false;
    // ENREGISTRER REFERME LA FICHE (24/09/2026). Elle se redessinait ouverte,
    // identique : rien ne distinguait une fiche enregistree d'une fiche qui
    // ne l'etait pas, et l'editeur attendait qu'elle se ferme. Un salarie ou un
    // spectacle revient a la liste, sa ligne marquee un instant ; la fiche
    // Entreprise, qui n'a pas de liste, reste et dit l'heure.
    const enregistree = CLE_ACTIVE;
    if (FICHE_ACTIVE !== "entreprise") { CLE_ACTIVE = null; FICHE_NEUVE = false; }
    dessinerConfig();
    if (FICHE_ACTIVE === "entreprise") {
      const heure = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
      const note = document.getElementById("config-modifie");
      if (note) { note.hidden = false; note.textContent = `enregistré à ${heure}`; }
    } else if (enregistree) {
      const rang = document.querySelector(`#config-liste .rang.fiche[data-cle="${CSS.escape(enregistree)}"]`);
      if (rang) {
        rang.classList.add("vient-d-etre-enregistree");
        rang.scrollIntoView({ behavior: "smooth", block: "nearest" });
        setTimeout(() => rang.classList.remove("vient-d-etre-enregistree"), 2500);
      }
    }
    if (!fiche.cle) {
      // Une fiche neuve : les listes des blocs de paie doivent la proposer
      // sans qu'on recharge le mois.
      rafraichirReferentiels();
    }
  } catch (e) {
    if (e.detail?.type === "FicheRefusee") {
      // On propose de forcer, mais on ne force jamais tout seul : une regle
      // peut se tromper, l'utilisateur en sait parfois plus qu'elle.
      // Le libellé du champ, pas sa clé technique (« numero_objet »).
      const libelles = {};
      (ETAT.configuration.description[FICHE_ACTIVE] || []).forEach((c) => { libelles[c.cle] = c.libelle; });
      let erreurs = e.detail.anomalies.filter((a) => a.gravite === "erreur");
      // Les codes d'un métier qu'on n'a pas choisi manquent tous ensemble :
      // une ligne, « Métier : à choisir », plutôt que quatre codes.
      const duMetier = erreurs.filter((a) => CHAMPS_DU_METIER.includes(a.champ) && aRemplir(a));
      if (duMetier.length > 1) {
        erreurs = erreurs.filter((a) => !duMetier.includes(a));
        erreurs.unshift({ champ: "Métier", message: "à choisir dans la liste" });
      }
      ouvrirBoite(`<h3>Enregistrement refusé</h3>
        <div class="encart erreur"><b>${erreurs.length > 1 ? `${erreurs.length} erreurs` : "Une erreur"}</b>
          ${erreurs.map((a) => `<div><b>${echapper(libelles[a.champ] || a.champ)}</b> : ${echapper(a.message)}</div>`).join("")}</div>
        <p class="note">Ces champs partent dans des déclarations. Si la règle
           se trompe et que la valeur est juste, on peut passer outre — mais il
           faut le vouloir.</p>
        <div class="actions">
          <button class="secondaire" onclick="fermerBoite()">Corriger</button>
          <button class="primaire" id="b-forcer">Enregistrer quand même</button>
        </div>`);
      // La date d'effet deja saisie voyage avec : passer outre une erreur
      // ne doit pas faire perdre au passage ce qu'on venait de dater.
      document.getElementById("b-forcer").onclick = () => {
        fermerBoite(); ecrireFiche(fiche, donnees, daté, true);
      };
    } else { dire(e.message, "erreur"); }
  }
}

/* =======================================================================
   HISTORIQUE
   ===================================================================== */
function dessinerHistorique() {
  dessinerExercices();
  dessinerRegularisation();
  const cible = document.getElementById("historique");
  if (!ETAT.historique.length) {
    cible.innerHTML = `<p class="discret">Aucun mois pour l'instant.</p>`;
    return;
  }
  // L'état de la DSN, en mots : c'est ce qu'on cherche en premier dans un
  // mois passé. La décision est au moteur (`bilan_des_mois`).
  const DSN_ETATS = {
    passee: ["bien", "DSN passée"], attente: ["alerte", "DSN partie, bilan attendu"],
    refusee: ["erreur", "DSN refusée"], a_deposer: ["alerte", "DSN à déposer"],
    a_ecrire: ["", "saisi, pas encore écrit"], en_retard: ["erreur", "DSN en retard"],
  };
  const majuscule = (t) => t.charAt(0).toUpperCase() + t.slice(1);
  cible.innerHTML = ETAT.historique.map((m) => {
    const [couleur, mots] = DSN_ETATS[m.dsn] || ["", m.produit ? "écrit" : "saisi"];
    const depose = m.depose_le && m.dsn !== "a_deposer" ? ` le ${quand(m.depose_le).slice(0, 10)}` : "";
    return `
    <div class="rang mois">
      <span class="rang-nom">${echapper(majuscule(moisEnClair(m.mois)))}</span>
      <span class="rang-etat"><span class="pastille ${couleur}">${echapper(mots)}${echapper(depose)}</span>${
        m.clos ? ` <span class="pastille">clos</span>` : ""}</span>
      <span class="rang-infos" title="${echapper((m.fichiers || []).join("\n"))}">${
        (m.sortes || []).length ? echapper(m.sortes.join(" · ")) : "aucun document"}</span>
      <span class="rang-actions">
        ${m.corrigeable && !m.clos ? `<button class="secondaire" data-corriger-mois="${echapper(m.mois)}"
          title="la correction partira dans la DSN du mois courant, datée de ce mois">Corriger…</button>` : ""}
        <button class="secondaire" data-ouvrir="${echapper(m.mois)}" data-retard="${m.dsn === "en_retard" ? 1 : 0}">Ouvrir</button>
      </span>
    </div>`;
  }).join("");
  cible.querySelectorAll("[data-ouvrir]").forEach((b) => {
    b.onclick = async () => {
      document.querySelector('.onglets button[data-vue="paie"]').click();
      await chargerMois(b.dataset.ouvrir);
      // Un mois en retard s'ouvre en le sachant : la boîte dit les pénalités.
      if (b.dataset.retard === "1") boiteRouvrirMois(b.dataset.ouvrir, MOIS_FERME);
    };
  });
  cible.querySelectorAll("[data-corriger-mois]").forEach((b) => {
    b.onclick = () => boiteCorriger(b.dataset.corrigerMois);
  });
}

/* =======================================================================
   LES RAPPELS DE L'OUVERTURE, ET L'EXERCICE
   =======================================================================
   « Quand le mois est fini, le logiciel s'ouvre sur le mois suivant, et là
   il faut un pop-up : il est temps d'envoyer la DSN du mois précédent. Avez-
   vous bien fini les paies du mois précédent ? Et un bouton vérifier et
   envoyer. » (16/09/2026). Puis, en janvier : clôturer l'exercice, exporter
   les chiffres pour la compta, saisir les numéros d'objet de l'année.

   La page ne décide de rien : /api/rappels rend la liste, déjà dans l'ordre,
   et chaque rappel dit où en est le mois (à saisir, à écrire, à déposer, à
   corriger). « Vérifier et envoyer » ne fait qu'ouvrir le mois et enchaîner
   les boîtes qui existent déjà — écrire le mois, puis le récapitulatif de
   dépôt avec son mot de passe. Rien ne part d'ici. « Plus tard » ferme la
   boîte ; elle reviendra à la prochaine ouverture, tant que le journal des
   dépôts ne dit pas que c'est fait. */
async function montrerRappels() {
  let r, ech = null;
  try { r = await api("rappels"); } catch (e) { return; }
  try { ech = await api("echeancier"); } catch (e) { ech = null; }
  let manques = [];
  try { manques = (await api("pour-demarrer")).manques || []; } catch (e) { manques = []; }
  const liste = r.rappels || [];
  // L'ÉCHÉANCIER (23/09/2026) : « un pop-up au démarrage : on est le…,
  // bienvenue sur PuppetPaie, n'oublie pas de faire la DSN ». Elle s'ouvrait
  // aussi une fois par jour quand rien n'attendait ; l'éditeur, 01/10/2026 :
  // « elle apparaît seulement s'il y a des trucs à faire ».
  if (!liste.length && !(ech && ech.a_faire) && !manques.length) return;
  boiteRappels(liste, ech, manques);
}

/* POUR DÉMARRER (09/10/2026). Une compagnie neuve découvrait ce qui lui
 * manquait un refus après l'autre. Le moteur (`pour-demarrer`) rend tout
 * d'un coup : ce que chaque manque bloque, où il se saisit, où la compagnie
 * trouve la valeur. La page ne fait que l'afficher. */
function htmlDemarrage(manques) {
  if (!manques || !manques.length) return "";
  const ligne = (m) => `
    <li>
      <b>${echapper(m.libelle)}</b> <span class="discret">— bloque ${echapper(m.bloque)}</span>
      <div class="note">À saisir dans ${echapper(m.ou)}.</div>
      ${m.trouver ? `<details><summary>Où le trouver</summary><p class="note">${echapper(m.trouver)}</p></details>` : ""}
    </li>`;
  return `
    <div class="rappel retard demarrage">
      <h3>Pour démarrer, il manque encore ${manques.length === 1 ? "une chose" : manques.length + " choses"}</h3>
      <p class="note">Tant qu'elles manquent, ce qu'elles bloquent sera refusé. Elles se trouvent toutes sur les courriers des organismes.</p>
      <ul class="rappel-liste">${manques.map(ligne).join("")}</ul>
      <div class="actions"><button class="petit" data-aller-configuration>Ouvrir la configuration</button></div>
    </div>`;
}

/** La liste « Pour démarrer », en tête de Configuration › Entreprise. */
async function peindreDemarrage(conteneur) {
  let manques = [];
  try { manques = (await api("pour-demarrer")).manques || []; } catch (e) { return; }
  conteneur.innerHTML = htmlDemarrage(manques);
  const b = conteneur.querySelector("[data-aller-configuration]");
  if (b) b.remove();
}

/* L'en-tête de la boîte : la date, la bienvenue, ce qui est à faire ce
 * mois-ci, et l'année qui vient repliée. Tout vient du moteur
 * (`operations_echeancier`) : la page ne sait pas ce qu'est une échéance. */
function htmlEcheancier(ech) {
  if (!ech) return "";
  const pastille = (x) => ({
    en_retard: `<span class="pastille alerte">en retard</span>`,
    a_faire: `<span class="pastille alerte">à faire</span>`,
    fait: `<span class="pastille bien">fait</span>`,
    information: `<span class="pastille">pour info</span>`,
  }[x.etat] || "");
  const avant = (x) => x.date && x.etat !== "fait"
    ? ` <span class="discret">— avant le ${echapper(dateCourte(x.date))}</span>` : "";
  const ligne = (x) => `
    <li class="echeance ${echapper(x.etat)}">
      <div class="echeance-titre">${pastille(x)} ${echapper(x.titre)}${avant(x)}</div>
      ${x.etat === "fait" ? "" : `<div class="note">${echapper(x.detail)}</div>`}
      ${x.cochable ? `<button class="secondaire petit" data-echeance="${echapper(x.cle)}"
        data-fait="${x.etat === "fait" ? "non" : "oui"}">${x.etat === "fait" ? "Pas encore fait" : "C'est fait"}</button>` : ""}
    </li>`;
  const parMois = {};
  (ech.a_venir || []).forEach((x) => { (parMois[x.mois] = parMois[x.mois] || []).push(x); });
  const annee = Object.keys(parMois).map((m) => `
    <li><b>${echapper(moisEnClair(m))}</b>
      <ul>${parMois[m].map((x) => `<li>${echapper(x.titre)}${x.etat === "fait" ? " ✓" : ""}</li>`).join("")}</ul>
    </li>`).join("");
  // CE QUI EST FAIT NE SE RAPPELLE PAS (01/10/2026, « pourquoi il me dit
  // ça alors que je l'ai déjà fait, pas besoin ») : la DSN de septembre,
  // déposée, s'affichait encore « fait ». Une échéance cochable reste, pour
  // pouvoir la décocher ; les autres faites se taisent.
  const ceMois = (ech.ce_mois || []).filter((x) => x.etat !== "fait" || x.cochable);
  return `
    <div class="accueil">
      <p class="accueil-date">Nous sommes le ${echapper(ech.date)}</p>
      <h2 class="accueil-titre">${echapper(ech.bienvenue)}</h2>
      <h3>Ce mois-ci</h3>
      ${ceMois.length
        ? `<ul class="echeances">${ceMois.map(ligne).join("")}</ul>`
        : `<p class="discret">Rien à faire ce mois-ci.</p>`}
      ${annee ? `<details class="accueil-annee"><summary>L'année qui vient</summary>
        <ul class="echeances-annee">${annee}</ul></details>` : ""}
    </div>`;
}

function moisEnClair(m) {
  const noms = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
    "août", "septembre", "octobre", "novembre", "décembre"];
  return noms[parseInt(m.slice(5, 7), 10) - 1] + " " + m.slice(0, 4);
}

function dateCourte(iso) {
  return iso.slice(8, 10) + "/" + iso.slice(5, 7) + "/" + iso.slice(0, 4);
}

function boiteRappels(liste, ech, manques = []) {
  const html = htmlDemarrage(manques) + htmlEcheancier(ech) + liste.map((r, i) => `
    <div class="rappel ${r.en_retard ? "retard" : ""}">
      <h3>${echapper(r.titre)}${r.en_retard ? ` <span class="pastille alerte">en retard</span>` : ""}</h3>
      <p class="rappel-question">${echapper(r.question)}</p>
      ${r.detail ? `<p class="note">${echapper(r.detail)}</p>` : ""}
      ${r.spectacles && r.spectacles.length ? `<ul class="rappel-liste">${r.spectacles.map((s) =>
        `<li>${echapper(s.titre)} <span class="discret">— ${echapper(s.numero_objet || "aucun numéro")}</span></li>`).join("")}</ul>` : ""}
      <div class="actions">${boutonRappel(r, i)}</div>
    </div>`).join("");
  ouvrirBoite(`
    ${html}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">${liste.length ? "Plus tard" : "Fermer"}</button>
    </div>`);
  liste.forEach((r, i) => {
    const b = document.getElementById("rappel-" + i);
    if (b) b.onclick = () => agirSurRappel(r);
  });
  const conf = document.querySelector("[data-aller-configuration]");
  if (conf) conf.onclick = () => {
    fermerBoite();
    document.querySelector('.onglets button[data-vue="configuration"]').click();
    const sous = document.querySelector('.sous-onglets button[data-fiche="entreprise"]');
    if (sous && !sous.classList.contains("actif")) sous.click();
  };
  document.querySelectorAll("[data-echeance]").forEach((b) => {
    b.onclick = async () => {
      try {
        await api("echeance-faite", { cle: b.dataset.echeance, fait: b.dataset.fait === "oui" });
        const ech2 = await api("echeancier");
        boiteRappels(liste, ech2, manques);
      } catch (e) { dire(e.message, "erreur"); }
    };
  });
}

function boutonRappel(r, i) {
  const libelle = {
    "dsn": "Vérifier et envoyer",
    "cloture": "Clôturer " + (r.annee || ""),
    "export-compta": "Exporter pour la compta",
    "revue-spectacles": "Choisir les spectacles",
    "dpae": r.fichier ? "Envoyer la DPAE" : "Préparer la DPAE",
  }[r.quoi] || "Voir";
  return `<button class="primaire" id="rappel-${i}">${echapper(libelle)}</button>`;
}

async function agirSurRappel(r) {
  fermerBoite();
  if (r.quoi === "dsn") {
    // On va sur le mois, on le regarde, et le dépôt s'enchaîne : c'est la
    // même suite que le bouton DSN de la colonne de droite. Un mois pas
    // encore écrit s'écrit d'abord (boiteProduire), même vide — la DSN
    // « néant » d'un mois sans cachet passe par là aussi.
    document.querySelector('.onglets button[data-vue="paie"]').click();
    await chargerMois(r.mois);
    const e = await api("etat-du-mois", { mois: r.mois });
    const d = (e.fichiers.dsn || [])[0];
    if (d) return boiteDepot("dsn", d.chemin);
    return boiteProduire(r.mois, async () => {
      const e2 = await api("etat-du-mois", { mois: r.mois });
      const d2 = (e2.fichiers.dsn || [])[0];
      if (d2) await boiteDepot("dsn", d2.chemin);
    });
  }
  if (r.quoi === "dpae") {
    // LA DPAE PRÉPARÉE D'AVANCE (27/09/2026) : son test est passé, le bouton
    // ouvre le dépôt de CE fichier — le réel, avec le mot de passe. Sans
    // fichier testé, on va au mois et à la boîte des embauches.
    if (r.fichier) return boiteDepot("dpae", r.fichier);
    document.querySelector('.onglets button[data-vue="paie"]').click();
    await chargerMois(r.mois);
    return boiteDpae(r.mois);
  }
  if (r.quoi === "cloture") return boiteCloture(r.annee);
  if (r.quoi === "export-compta") return lancerExportCompta(r.annee);
  if (r.quoi === "revue-spectacles") return boiteRevueSpectacles(r);
}

/* ---- La revue des spectacles, en début d'année (l'éditeur, 30/09/2026,
 * journal §167). Un numéro d'objet vaut tant que le spectacle se joue : on
 * demande seulement lesquels continuent. Tout est coché ; décocher archive,
 * et une fiche archivée se réactive d'un clic dans Configuration. */
function boiteRevueSpectacles(r) {
  const lignes = (r.spectacles || []).map((s, i) => `
    <label class="coche"><input type="checkbox" class="rv-garde" data-cle="${echapper(s.cle)}" checked>
      ${echapper(s.titre)}${s.numero_objet ? ` <span class="discret">${echapper(s.numero_objet)}</span>` : ""}</label>`).join("");
  ouvrirBoite(`
    <h3>Les spectacles de ${echapper(r.annee)}</h3>
    <p>${echapper(r.question)}</p>
    ${lignes}
    <p class="note">Décochés, ils s'archivent : ils restent lisibles et se réactivent
      d'un clic (Configuration › Spectacles). Ceux qui continuent gardent leur numéro d'objet.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Plus tard</button>
      <button class="primaire" id="rv-valider">Enregistrer</button>
    </div>`);
  document.getElementById("rv-valider").onclick = async () => {
    const bouton = document.getElementById("rv-valider");
    bouton.disabled = true;
    const continuent = [...document.querySelectorAll(".rv-garde")]
      .filter((c) => c.checked).map((c) => c.dataset.cle);
    try {
      const res = await api("revue-spectacles", { annee: r.annee, continuent });
      ETAT = await api("etat");
      fermerBoite();
      dire(res.archives.length
        ? `${res.archives.length} spectacle${res.archives.length > 1 ? "s" : ""} archivé${res.archives.length > 1 ? "s" : ""} ; ${res.continuent.length} continue${res.continuent.length > 1 ? "nt" : ""}.`
        : "Tous les spectacles continuent.");
    } catch (e) {
      bouton.disabled = false;
      dire(e.message, "erreur");
    }
  };
}

/* ---- L'exercice, dans l'Historique : par année, ce qui est fait, ce qui
 * se fait. Clôturer fige l'année et écrit le zip ; l'export compta écrit le
 * CSV du journal de paie. Les deux sont locaux — rien ne part. */
async function dessinerExercices() {
  const cible = document.getElementById("exercices");
  let r;
  try { r = await api("exercices"); }
  catch (e) { cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`; return; }
  if (!r.exercices.length) { cible.innerHTML = `<p class="discret">Aucune année pour l'instant.</p>`; return; }
  cible.innerHTML = r.exercices.map((x) => {
    const clos = x.clos;
    return `
    <div class="rang exercice">
      <span class="rang-nom">${echapper(x.annee)}</span>
      <span class="pastille ${clos ? "bien" : "alerte"}">${clos ? "clos" : "ouvert"}</span>
      <span class="rang-infos">
        ${x.mois.length} mois · ${x.dsn_acceptees.length} DSN acceptée${x.dsn_acceptees.length === 1 ? "" : "s"}
        ${clos ? ` · clos le ${echapper(quand(clos.le))}, ${echapper(clos.archive)}` : ""}
        ${x.export ? ` · export compta du ${echapper(quand(x.export.ecrit))}` : " · pas d'export compta"}
      </span>
      <button class="secondaire" data-export="${echapper(x.annee)}">Export compta</button>
      ${clos
        ? `<button class="secondaire" data-rouvrir="${echapper(x.annee)}">Rouvrir</button>`
        : `<button class="secondaire" data-cloturer="${echapper(x.annee)}">Clôturer…</button>`}
    </div>`;
  }).join("") + `<p class="note"><button class="lien" id="ouvrir-exercices"
    title="${echapper(r.dossier)}">Ouvrir le dossier des archives</button></p>`;
  cible.querySelectorAll("[data-export]").forEach((b) => {
    b.onclick = () => lancerExportCompta(b.dataset.export);
  });
  cible.querySelectorAll("[data-cloturer]").forEach((b) => {
    b.onclick = () => boiteCloture(b.dataset.cloturer);
  });
  cible.querySelectorAll("[data-rouvrir]").forEach((b) => {
    b.onclick = async () => {
      try {
        const x = await api("cloture", { annee: b.dataset.rouvrir, rouvrir: true });
        dire("L'année " + x.annee + " est rouverte — son archive reste.");
        await dessinerExercices();
      } catch (e) { dire(e.message, "erreur"); }
    };
  });
  const o = document.getElementById("ouvrir-exercices");
  if (o) o.onclick = async () => {
    try { await api("ouvrir-exercices"); } catch (e) { dire(e.message, "erreur"); }
  };
}

/* =======================================================================
   EXPORTS  (22/09/2026)
   -----------------------------------------------------------------------
   « Il faut vraiment un endroit où on peut faire des exports, pour les
   trucs comptables. » Le voici, et il ne porte que quatre questions :
   QUOI (l'état), QUAND (un mois, une année, toutes les années), COMMENT
   (le regroupement et le format), et un APERÇU avant d'écrire.

   Tout ce qui s'affiche ici vient du moteur : les états, les formats, les
   regroupements et les périodes sont rendus par `exports-periodes`. Un état
   ajouté demain dans `operations_exports.ETATS` apparaît dans ce menu sans
   qu'on touche à ce fichier — c'est la règle 2 vue depuis la page : elle
   n'affiche pas ce qu'elle croit savoir, elle affiche ce que le moteur dit.

   Rien ne part d'ici. Pas de mot de passe, donc, et pas de confirmation :
   un export lit, et le pire qu'il puisse faire est d'écrire un fichier de
   plus dans `exports/`.
   ===================================================================== */
let EXPORTS = null;          // ce que `exports-periodes` a rendu

async function dessinerExports() {
  const cible = document.getElementById("exports-formulaire");
  try { EXPORTS = await api("exports-periodes"); }
  catch (e) { cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`; return; }
  const p = EXPORTS;
  if (!p.mois.length) {
    cible.innerHTML = `<p class="discret">Aucune paie saisie : il n'y a rien à
      exporter pour l'instant.</p>`;
    document.getElementById("exports-resultat").innerHTML = "";
    return;
  }
  const opt = (v, t, sel) =>
    `<option value="${echapper(v)}"${sel ? " selected" : ""}>${echapper(t)}</option>`;
  // Un format dont la brique manque se choisit quand même — le moteur écrit
  // alors le CSV et le dit —, mais l'étiquette prévient avant le clic.
  // D'ABORD LA CATEGORIE, PUIS L'ETAT, PUIS SES QUESTIONS (Leandre,
  // 08/10/2026) : rien n'est choisi d'office, et chaque choix deroule le
  // suivant. Une categorie d'un seul etat le choisit d'elle-meme.
  const fams = familles(p.etats);
  cible.innerHTML = `
    <div class="champs">
      <div class="champ">
        <label for="x-famille">Quoi</label>
        <select id="x-famille">
          <option value="" selected disabled>— choisir —</option>
          ${fams.map(([f], i) => opt(String(i), f)).join("")}
        </select>
      </div>
      <div class="champ cachee" id="x-etat-champ">
        <label for="x-etat">Lequel</label>
        <select id="x-etat"></select>
      </div>
    </div>
    <div id="x-suite"></div>`;
  const choixEtat = document.getElementById("x-etat");
  document.getElementById("x-famille").onchange = () => {
    const [, liste] = fams[Number(document.getElementById("x-famille").value)];
    document.getElementById("x-etat-champ").classList.remove("cachee");
    choixEtat.innerHTML = (liste.length > 1 ? `<option value="" selected disabled>— choisir —</option>` : "")
      + liste.map((e) => opt(e.etat, e.quoi)).join("");
    document.getElementById("x-suite").innerHTML = "";
    document.getElementById("exports-resultat").innerHTML = "";
    if (liste.length === 1) dessinerQuestions(opt);
  };
  choixEtat.onchange = () => dessinerQuestions(opt);
  dessinerDossier();
}

/* ------------------------------------------- le dossier d'un salarié */

/** TOUS SES DOCUMENTS, EN UNE FOIS (l'éditeur, 23/09/2026). On coche ce qu'on
 *  sort : une catégorie donne un PDF, plusieurs un ZIP d'un PDF par
 *  catégorie. Le moteur réédite ce qui se recrée — aux numéros lus, jamais
 *  neufs — et prend tel quel ce qui ne se recrée pas (contrat signé, AER,
 *  CoolPaie). La page ne décide rien : elle coche, le moteur répond. */
let DOSSIER = null;
async function dessinerDossier() {
  const cible = document.getElementById("dossier-formulaire");
  if (!cible) return;
  try { DOSSIER = await api("dossier-formes"); }
  catch (e) { cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`; return; }
  const f = DOSSIER;
  const opt = (v, t) => `<option value="${echapper(v)}">${echapper(t)}</option>`;
  cible.innerHTML = `
    <div class="champs">
      <div class="champ">
        <!-- QUI SE COCHE, COMME DANS LES PAIES (Leandre, 08/10/2026) : une
             case par salarié, et une case « Tous ». Un dossier chacun. -->
        <label>Qui</label>
        <div class="d-qui-liste" style="display:flex;flex-direction:column;gap:2px;max-height:12em;overflow:auto">
          <label class="coche"><input type="checkbox" id="d-tous" checked> <b>Tous</b></label>
          ${[...f.salaries.filter((s) => s.actif), ...f.salaries.filter((s) => !s.actif)].map((s) => `<label class="coche">
            <input type="checkbox" class="d-sal" value="${echapper(s.cle)}" checked>
            ${echapper(s.nom)}${s.actif ? "" : ' <span class="discret">— archivé</span>'}</label>`).join("")}
        </div>
      </div>
      <div class="champ">
        <label for="d-quand">Quand</label>
        <select id="d-quand">
          ${opt("toutes", "Toute la période")}${opt("annee", "Une année")}${opt("mois", "Un mois")}
        </select>
        <select id="d-periode" class="cachee"></select>
      </div>
      <div class="champ pleine">
        <label>Quoi <button type="button" class="lien d-tout">tout décocher</button></label>
        <div class="d-cats">${f.categories.map((c) => `<label class="coche">
          <input type="checkbox" class="d-cat" value="${echapper(c.categorie)}" checked>
          ${echapper(c.quoi)}</label>`).join("")}</div>
        <div class="aide">Une seule case : un PDF. Plusieurs : un ZIP, un PDF par catégorie.</div>
      </div>
      <div class="champ pleine">
        <label class="coche"><input type="checkbox" id="d-ensemble">
          Tous les salariés dans le même fichier <span class="discret">(ne s'envoie à personne)</span></label>
      </div>
    </div>
    <div class="actions">
      <button class="secondaire" id="d-apercu">Aperçu</button>
      <button class="primaire" id="d-ecrire">Écrire le dossier</button>
      ${f.boite_liee ? `<button class="secondaire" id="d-envoyer">L'envoyer à chaque salarié</button>` : ""}
      <button class="lien" id="d-ouvrir" title="${echapper(f.dossier)}">Ouvrir le dossier</button>
    </div>`;
  // « Tous » coche ou décoche chacun ; chacun remet « Tous » d'accord.
  const tous = document.getElementById("d-tous");
  const sals = [...cible.querySelectorAll(".d-sal")];
  tous.onchange = () => sals.forEach((c) => { c.checked = tous.checked; });
  sals.forEach((c) => { c.onchange = () => { tous.checked = sals.every((x) => x.checked); }; });
  const tout = cible.querySelector(".d-tout");
  tout.onclick = () => {
    const cases = [...cible.querySelectorAll(".d-cat")];
    const cocher = cases.every((c) => !c.checked);
    cases.forEach((c) => { c.checked = cocher; });
    tout.textContent = cocher ? "tout décocher" : "tout cocher";
  };
  document.getElementById("d-quand").onchange = () => {
    const quand = document.getElementById("d-quand").value;
    const sel = document.getElementById("d-periode");
    sel.classList.toggle("cachee", quand === "toutes");
    const liste = quand === "mois" ? f.mois.slice().reverse() : f.annees;
    sel.innerHTML = liste.map((v) => opt(v, quand === "mois" ? libelleMois(v) : v)).join("");
  };
  // VENU D'UNE FICHE SALARIE (« Exporter ses documents », 23/09/2026) : ce
  // salarie, l'annee la plus recente, toutes les categories cochees.
  if (DOSSIER_PRECHOIX && f.salaries.some((s) => s.cle === DOSSIER_PRECHOIX)) {
    sals.forEach((c) => { c.checked = c.value === DOSSIER_PRECHOIX; });
    tous.checked = sals.every((x) => x.checked);
    if (f.annees.length) {
      document.getElementById("d-quand").value = "annee";
      document.getElementById("d-quand").onchange();
      document.getElementById("d-periode").value = [...f.annees].map(String).sort().pop();
    }
    document.getElementById("carte-dossier").open = true;
    cible.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  DOSSIER_PRECHOIX = null;
  document.getElementById("d-apercu").onclick = () => lancerDossier("dossier-salarie", true);
  document.getElementById("d-ecrire").onclick = () => lancerDossier("dossier-salarie", false);
  if (f.boite_liee) document.getElementById("d-envoyer").onclick = () => lancerDossier("dossier-envoyer", false);
  document.getElementById("d-ouvrir").onclick = async () => {
    try { await api("ouvrir-exports", { sous: "dossiers" }); } catch (e) { dire(e.message, "erreur"); }
  };
}

async function lancerDossier(route, apercu) {
  const coches = [...document.querySelectorAll(".d-sal:checked")].map((c) => c.value);
  if (!coches.length) { dire("Cochez au moins un salarié.", "erreur"); return; }
  // Tous cochés : la liste vide, qui veut dire « chaque salarié » pour le moteur.
  const qui = document.getElementById("d-tous").checked ? [] : coches;
  const quand = document.getElementById("d-quand").value;
  const periode = document.getElementById("d-periode").value;
  const charge = {
    salaries: qui,
    categories: [...document.querySelectorAll(".d-cat:checked")].map((c) => c.value),
    ensemble: document.getElementById("d-ensemble").checked,
    apercu,
  };
  if (quand === "mois") charge.mois = periode;
  else if (quand === "annee") charge.annee = periode;
  else charge.toutes_les_annees = true;
  if (route === "dossier-envoyer") {
    const mdp = await demanderMotDePasse("envoyer leur dossier aux salariés");
    if (!mdp) return;
    charge.motdepasse = mdp;
  }
  const cible = document.getElementById("dossier-resultat");
  cible.innerHTML = `<p class="discret">…</p>`;
  const repere = route === "dossier-envoyer" ? await repereCourrielsDemo() : null;
  let r;
  try { r = await api(route, charge); }
  catch (e) { cible.innerHTML = `<div class="encart erreur">${echapper(e.message)}</div>`; return; }
  if (r.envoi) fenetreCourrielsDemo("documents", repere);
  const lignes = r.salaries.map((c) => `<tr><td>${echapper(c)}</td><td>${
    Object.entries(r.pages[c] || {}).map(([k, n]) => echapper(r.libelles[k]) + " : " + n + " p.").join(" · ")
  }</td></tr>`).join("");
  cible.innerHTML = `
    <h3>Dossier — ${echapper(r.periode)}</h3>
    ${r.refus.map((a) => `<div class="encart alerte">${echapper(a)}</div>`).join("")}
    ${r.avertissements.map((a) => `<div class="encart">${echapper(a)}</div>`).join("")}
    <table class="tableau"><tr><th>Salarié</th><th>Pages</th></tr>${lignes}</table>
    ${r.fichiers.length ? `<p class="note">Écrit : ${r.fichiers.map((x) => `<code>${echapper(x)}</code>`).join(", ")}</p>` : ""}
    ${r.envoi ? `<div class="encart ok">${r.envoi.messages} dossier(s) envoyé(s) à
      ${echapper(r.envoi.partis.join(", "))}.</div>` : ""}`;
}

/** Les états rangés par famille, dans l'ordre que le moteur donne : une
 *  vingtaine d'états ne se lisent pas en vrac (23/09/2026). */
function familles(etats) {
  const out = [];
  for (const e of etats) {
    const f = e.famille || "Autres";
    if (!out.length || out[out.length - 1][0] !== f) out.push([f, []]);
    out[out.length - 1][1].push(e);
  }
  return out;
}

/** LES QUESTIONS DE L'ÉTAT CHOISI, et rien d'autre (23/09/2026). L'éditeur :
 *  « quand on arrive sur les exports on n'a qu'une case, et selon ce qu'on
 *  choisit on arrive sur ce qui est pertinent ». Quelles questions, quel
 *  bouton, un aperçu ou non : c'est le moteur qui le dit (`FORMES`). */
function dessinerQuestions(opt) {
  const p = EXPORTS;
  const forme = p.etats.find((e) => e.etat === document.getElementById("x-etat").value);
  const q = new Set(forme.questions);
  const manque = { xlsx: !p.xlsx, pdf: !p.pdf };
  document.getElementById("exports-resultat").innerHTML = "";
  document.getElementById("x-suite").innerHTML = `
    <div class="champs">
      ${q.has("periode") ? `<div class="champ pleine">
        <label>Quand <span class="discret" id="x-quand-dit"></span></label>
        <input type="hidden" id="x-quand"><input type="hidden" id="x-periode">
        <div class="calendrier" id="x-calendrier"></div>
      </div>` : ""}
      ${q.has("regroupement") ? `<div class="champ">
        <label for="x-par">Regroupement</label>
        <select id="x-par">
          ${p.regroupements.filter((r) => (forme.regroupements || []).includes(r.regroupement))
              .map((r) => opt(r.regroupement, r.quoi,
                              r.regroupement === forme.regroupements[0])).join("")}
        </select>
        <div class="aide">${forme.etat === "livre-de-paie"
          ? `Par salarié, ce qu'on envoie au comptable ; par mois, ce
          qu'on rapproche de la banque ; par spectacle, ce qui justifie une
          subvention. Les trois disent la même chose, et le total ne bouge pas.`
          : "Le total ne bouge pas : seule la répartition des lignes change."}</div>
      </div>` : ""}
      ${q.has("logiciel") ? `<div class="champ pleine">
        <label for="x-logiciel">Logiciel du comptable</label>
        <select id="x-logiciel">
          ${p.compta.logiciels.map((l) => opt(l.logiciel,
            `${l.nom} — ${l.format_lisible}`,
            l.logiciel === p.compta.logiciel)).join("")}
          ${opt("", "Aucun : je choisis le format", !p.compta.logiciel)}
        </select>
        <div class="aide" id="x-logiciel-aide"></div>
        <label class="choix" id="x-analytique-champ">
          <input type="checkbox" id="x-analytique"${p.compta.analytique ? " checked" : ""}>
          <span>Ventiler les salaires bruts par spectacle (analytique)</span>
        </label>
        <div class="aide">Le code de chaque spectacle se règle sur sa fiche :
          Configuration › Spectacles, case « Code analytique ». Vide, il est
          tiré du titre.</div>
        <div id="x-controle"></div>
      </div>` : ""}
      ${q.has("format") ? `<div class="champ" id="x-format-champ">
        <label for="x-format">Format</label>
        <select id="x-format">
          ${p.formats.filter((f) => (forme.formats || []).includes(f.format)).map((f) => opt(f.format,
            f.quoi + (manque[f.format] ? " — brique absente, le CSV sera écrit" : ""),
            f.format === "csv")).join("")}
        </select>
      </div>` : ""}
      ${q.has("coordonnees") ? `<div class="champ pleine">
        <label class="coche" title="Sans la case, rien de tout cela ne sort. Un fichier qui les porte ne s'envoie qu'à qui en a besoin.">
          <input type="checkbox" id="x-coordonnees">
          Avec les coordonnées des salariés (NIR, naissance, adresse)
        </label>
      </div>` : ""}
    </div>
    <div class="actions">
      ${forme.apercu ? `<button class="secondaire" id="x-apercu">Aperçu</button>` : ""}
      <button class="primaire" id="x-ecrire">${echapper(forme.bouton)}</button>
      <button class="lien" id="x-dossier" title="${echapper(p.dossier)} — et nulle part ailleurs : un export emporte des salaires">Ouvrir le dossier</button>
    </div>`;
  if (q.has("periode")) dessinerCalendrier(forme.periodes || ["annee", "mois", "toutes"]);
  if (q.has("logiciel")) {
    const retenir = async () => {
      document.getElementById("exports-resultat").innerHTML = "";
      try {
        EXPORTS.compta = await api("retenir-logiciel", {
          logiciel: document.getElementById("x-logiciel").value,
          analytique: document.getElementById("x-analytique").checked });
      } catch (e) { dire(e.message, "erreur"); }
      montrerLogiciel();
    };
    document.getElementById("x-logiciel").onchange = retenir;
    document.getElementById("x-analytique").onchange = retenir;
    const f = document.getElementById("x-format");
    if (f) f.addEventListener("change", montrerLogiciel);
    montrerLogiciel();
  }
  if (forme.apercu) document.getElementById("x-apercu").onclick = () => lancerExport(true);
  document.getElementById("x-ecrire").onclick = () => lancerExport(false);
  document.getElementById("x-dossier").onclick = async () => {
    try { await api("ouvrir-exports"); } catch (e) { dire(e.message, "erreur"); }
  };
}

/** LE LOGICIEL DU COMPTABLE (23/09/2026). Choisi une fois, retenu par le
 *  moteur (config/compta.json) : il fixe le format, et le menu des formats
 *  s'efface. La case d'analytique ne vaut que pour les formats qui la
 *  portent. Ce que le plan comptable ne tiendrait pas dans ce format est dit
 *  ici, avant d'exporter — c'est le moteur qui le dit. */
function montrerLogiciel() {
  const c = EXPORTS.compta;
  const choisi = c.logiciels.find((l) => l.logiciel === document.getElementById("x-logiciel").value);
  const fmt = document.getElementById("x-format-champ");
  if (fmt) fmt.classList.toggle("cachee", !!choisi);
  document.getElementById("x-logiciel-aide").textContent = choisi
    ? `Fichier ${choisi.format_lisible} : ${choisi.pourquoi}. Retenu pour les prochaines fois.`
    : "Le format se choisit ci-dessous.";
  // Sans logiciel, la case suit le format choisi à la main.
  const f = document.getElementById("x-format");
  const porte = choisi ? choisi.analytique
    : c.logiciels.some((l) => l.analytique && f && l.format === f.value);
  document.getElementById("x-analytique-champ").classList.toggle("cachee", !porte);
  document.getElementById("x-controle").innerHTML = (c.controle || []).map((m) =>
    `<div class="encart alerte">${echapper(m)}</div>`).join("");
}

/** LE CALENDRIER DES EXPORTS (Leandre, 08/10/2026). Une ligne par année,
 *  ses douze mois ; on clique une année, un mois, ou « Tout ». Seuls les
 *  mois saisis ou déclarés se cliquent, et ce que l'état admet (`periodes`,
 *  dit par le moteur) : un état annuel n'offre pas les mois. Le moteur prend
 *  UNE période ; le choix se range dans `x-quand` / `x-periode`. */
function dessinerCalendrier(periodes) {
  const cal = document.getElementById("x-calendrier");
  const dispo = new Set(EXPORTS.mois);
  const src = EXPORTS.sources || {};
  const noms = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  const annees = [...new Set(EXPORTS.mois.map((m) => m.slice(0, 4)))].sort().reverse();
  const peutMois = periodes.includes("mois");
  const peutAn = periodes.includes("annee");
  cal.innerHTML = `
    ${periodes.includes("toutes") ? `<div class="rangee"><button type="button" data-quand="toutes" data-periode="">Tout</button></div>` : ""}
    ${annees.map((a) => `<div class="rangee">
      <button type="button" class="an" data-quand="annee" data-periode="${a}"${peutAn ? "" : " disabled"}>${a}</button>
      ${noms.map((n, i) => {
        const m = `${a}-${String(i + 1).padStart(2, "0")}`;
        const ok = peutMois && dispo.has(m);
        return `<button type="button" data-quand="mois" data-periode="${m}"${ok ? "" : " disabled"}
          title="${echapper(libelleMois(m) + (src[m] ? " — " + src[m] : ""))}">${n}</button>`;
      }).join("")}
    </div>`).join("")}`;
  const choisir = (quand, periode) => {
    document.getElementById("x-quand").value = quand;
    document.getElementById("x-periode").value = periode;
    cal.querySelectorAll("button").forEach((b) => {
      const d = b.dataset;
      const pris = quand === "toutes" ? d.quand === "toutes" || (d.quand === "mois" && !b.disabled)
        : quand === "annee" ? (d.quand === "annee" && d.periode === periode) || (d.quand === "mois" && d.periode.startsWith(periode + "-") && dispo.has(d.periode))
        : d.quand === "mois" && d.periode === periode;
      b.classList.toggle("pris", !!pris);
    });
    document.getElementById("x-quand-dit").textContent = "— " + (quand === "toutes" ? "toutes les années"
      : quand === "annee" ? "l'année " + periode : libelleMois(periode));
    document.getElementById("exports-resultat").innerHTML = "";
  };
  cal.querySelectorAll("button").forEach((b) => {
    b.onclick = () => choisir(b.dataset.quand, b.dataset.periode);
  });
  // Par défaut, le plus récent que l'état admet : le dernier mois, sinon la dernière année, sinon tout.
  const dernier = EXPORTS.mois[EXPORTS.mois.length - 1];
  if (peutMois && dernier) choisir("mois", dernier);
  else if (peutAn && annees.length) choisir("annee", annees[0]);
  else choisir("toutes", "");
}

function libelleMois(m) {
  const noms = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet",
                "août", "septembre", "octobre", "novembre", "décembre"];
  return noms[Number(m.slice(5, 7)) - 1] + " " + m.slice(0, 4);
}

async function lancerExport(apercu) {
  const val = (id) => { const e = document.getElementById(id); return e ? e.value : undefined; };
  const quand = val("x-quand");
  const periode = val("x-periode");
  const coord = document.getElementById("x-coordonnees");
  const charge = {
    etat: val("x-etat"),
    regroupement: val("x-par"),
    format: val("x-format"),
    coordonnees: coord ? coord.checked : false,
    apercu,
  };
  const logiciel = val("x-logiciel");
  if (logiciel !== undefined) {
    if (logiciel) charge.logiciel = logiciel;
    const champ = document.getElementById("x-analytique-champ");
    charge.analytique = !champ.classList.contains("cachee")
      && document.getElementById("x-analytique").checked;
  }
  if (quand === "mois") charge.mois = periode;
  else if (quand === "annee") charge.annee = periode;
  else charge.toutes_les_annees = true;
  const cible = document.getElementById("exports-resultat");
  cible.innerHTML = `<p class="discret">…</p>`;
  let r;
  try { r = await api("exporter", charge); }
  catch (e) { cible.innerHTML = `<div class="encart erreur">${echapper(e.message)}</div>`; return; }
  if (r.etat === "regularisation-casc-svp") { dessinerCasc(r); return; }
  if (r.colonnes && r.sections) { dessinerTableau(r, apercu); return; }
  dessinerLivre(r, apercu);
}

/** LA RÉGULARISATION CASC-SVP. Deux étapes, dans l'ordre où on les vit
 *  (l'éditeur, 23/09/2026) : faire les virements, puis envoyer — par la boîte
 *  de la compagnie si elle est posée, c'est le premier choix et il se voit ;
 *  sinon à la main, les fichiers sont là. Le détail des mois se déplie. */
function dessinerCasc(r) {
  const cible = document.getElementById("exports-resultat");
  const lignes = r.mois.map((m) => `<tr><td>${echapper(m.libelle)}</td>
      <td class="r">${echapper(m.masse)}</td><td class="r">${echapper(m.taux)} %</td>
      <td class="r">${echapper(m.cotisation)}</td></tr>`).join("");
  const annees = r.annees.map((a) => `<tr class="sous-total"><td><b>${echapper(a.annee)}</b></td>
      <td class="r">${echapper(a.masse)}</td><td></td><td class="r"><b>${echapper(a.cotisation)}</b></td></tr>`).join("");
  const courriel = (c, titre) => `<details><summary>${titre} — à ${echapper(c.a)}, objet ${echapper(c.objet)}</summary>
      <pre class="courriel">${echapper(c.corps)}</pre></details>`;
  const n = r.annees.length;
  cible.innerHTML = `
    <h3>Régularisation CASC-SVP — ${echapper(r.periode)} — ${echapper(euros(r.total))}</h3>
    ${r.avertissements.map((a) => `<div class="encart alerte">${echapper(a)}</div>`).join("")}
    <div class="casc-etape">
      <h4>1. Faire ${n > 1 ? "les " + n + " virements" : "le virement"}</h4>
      <ul>${r.annees.map((a) => `<li><b>${echapper(euros(a.cotisation))}</b>, libellé
        « ${echapper(a.libelle_virement)} »</li>`).join("")}</ul>
      <p class="discret">Vers Audiens Santé Prévoyance – Encaissement. L'IBAN se lit dans
        l'espace employeur Audiens ou sur la page employeurs du CASC-SVP.</p>
    </div>
    <div class="casc-etape">
      <h4>2. Envoyer les deux courriels</h4>
      <div class="casc-choix">
        <div class="casc-option principale">
          <h5>Automatiquement, depuis la boîte de la compagnie</h5>
          ${r.boite_liee ? `
          <div class="e-contrat-champs">
            ${r.annees.map((a) => `<label>Virement ${echapper(a.annee)} fait le
              <input type="date" class="casc-date" data-annee="${echapper(a.annee)}"></label>`).join("")}
          </div>
          <button class="primaire" id="casc-envoyer">Envoyer les 2 courriels</button>
          <p class="discret">Audiens reçoit les masses et les dates des virements ; le CASC-SVP,
            la liste nominative. Une copie reste dans le dossier, et les années sont notées
            régularisées.</p>` : `
          <p>La boîte courriel n'est pas posée : Configuration › Courriel. Une fois posée,
            l'envoi se fait d'ici en un clic.</p>`}
        </div>
        <div class="casc-option">
          <h5>À la main</h5>
          <p>Joindre la liste nominative au courriel du CASC-SVP, recopier les deux courriels
            ci-dessous, puis noter la régularisation.</p>
          <button class="secondaire" id="casc-dossier">Ouvrir les fichiers (liste nominative .xlsx)</button>
          ${courriel(r.courriel_audiens, "Courriel à Audiens")}
          ${courriel(r.courriel_casc, "Courriel au CASC-SVP")}
          <div class="e-contrat-champs">
            <label>Année <select id="casc-annee">${r.annees.map((a) =>
              `<option>${echapper(a.annee)}</option>`).join("")}</select></label>
            <label>Virée le <input type="date" id="casc-vire-le"></label>
            <label>Montant <input type="text" id="casc-montant" size="8"></label>
            <button class="secondaire" id="casc-noter">Noter comme régularisé</button>
          </div>
        </div>
      </div>
    </div>
    <details><summary>Le détail, mois par mois</summary>
      <table class="livre"><thead><tr><th>mois</th><th class="r">masse</th><th class="r">taux</th>
        <th class="r">CASC</th></tr></thead><tbody>${lignes}${annees}</tbody></table>
    </details>`;
  document.getElementById("casc-dossier").onclick = async () => {
    try { await api("ouvrir-exports", { sous: "casc-svp" }); } catch (e) { dire(e.message, "erreur"); }
  };
  const choixAnnee = document.getElementById("casc-annee");
  const montant = document.getElementById("casc-montant");
  const preremplir = () => {
    const a = r.annees.find((x) => x.annee === choixAnnee.value);
    montant.value = a ? a.cotisation : "";
  };
  choixAnnee.onchange = preremplir;
  preremplir();
  document.getElementById("casc-noter").onclick = async () => {
    const vire = document.getElementById("casc-vire-le").value;
    if (!vire) { dire("La date du virement d'abord : on note ce qui est payé."); return; }
    try {
      const e = await api("casc-regularise",
        { annee: choixAnnee.value, vire_le: vire, montant: montant.value });
      dire(`CASC-SVP ${e.annee} notée régularisée (${e.mois.length} mois).`);
    } catch (x) { dire(x.message, "erreur"); }
  };
  const envoyer = document.getElementById("casc-envoyer");
  if (envoyer) envoyer.onclick = async () => {
    const vire_le = {};
    for (const c of document.querySelectorAll(".casc-date")) if (c.value) vire_le[c.dataset.annee] = c.value;
    const liste = Object.keys(vire_le);
    if (!liste.length) { dire("La date d'au moins un virement d'abord : les courriels annoncent des virements faits."); return; }
    const mdp = await demanderMotDePasse("envoyer à Audiens et au CASC-SVP la régularisation " + liste.join(" et "));
    if (!mdp) return;
    envoyer.disabled = true;
    const repere = await repereCourrielsDemo();
    try {
      const e = await api("casc-envoyer", { vire_le, motdepasse: mdp });
      dire(`${e.partis.length} courriel(s) envoyé(s) à ${e.partis.join(" et ")} — ` +
           `${e.annees.map((a) => a.annee).join(" et ")} notée(s) régularisée(s).`);
      cible.innerHTML = `<p>CASC-SVP ${echapper(e.periode)} : ${echapper(euros(e.total))}, envoyé depuis
        ${echapper(e.expediteur)}. Copie des courriels dans ${echapper(e.dossier)}.</p>`;
      fenetreCourrielsDemo("courriel", repere);
    } catch (x) {
      envoyer.disabled = false;
      dire(x.message, "erreur");
    }
  };
}

/** UN ÉTAT DE LA MACHINERIE COMMUNE (23/09/2026) : ses colonnes, ses
 *  sections et ses totaux viennent du moteur (`tableaux.Tableau`). La page ne
 *  sait rien de chaque état : un état neuf s'affiche sans qu'on touche ici. */
function dessinerTableau(r, apercu) {
  const cible = document.getElementById("exports-resultat");
  const droite = (c) => ["montant", "nombre", "taux"].includes(c.type);
  const cel = (c, v) => {
    const t = v === null || v === undefined ? "" : String(v);
    return `<td${droite(c) ? ' class="r"' : ""}>${echapper(droite(c) ? t.replace(".", ",") : t)}</td>`;
  };
  const rang = (d, classe) => `<tr${classe ? ` class="${classe}"` : ""}>${
    r.colonnes.map((c) => cel(c, d[c.cle])).join("")}</tr>`;
  const plusieurs = r.sections.length > 1;
  const corps = r.sections.map((s) =>
    (plusieurs && s.libelle ? `<tr class="sous-total"><td colspan="${r.colonnes.length}"><b>${
      echapper(s.libelle)}</b></td></tr>` : "")
    + s.lignes.map((l) => rang(l, "")).join("")
    + (plusieurs && s.total ? rang(s.total, "sous-total") : "")).join("");
  const n = r.sections.reduce((a, s) => a + s.lignes.length, 0);
  cible.innerHTML = `
    <h2>${echapper(r.titre)} — ${echapper(r.periode)}</h2>
    <p class="discret">${n} ligne${n === 1 ? "" : "s"}${r.fichier
        ? ` — écrit : <b>${echapper(r.fichier)}</b>`
        : " — aperçu, rien n'a été écrit"}.</p>
    ${r.donnees_personnelles ? `<div class="encart alerte">Cet état porte des données
      personnelles : il reste dans prive/, et ne s'envoie qu'à qui en a besoin.</div>` : ""}
    ${(r.avertissements || []).map((a) =>
        `<div class="encart info">${echapperLiens(a)}</div>`).join("")}
    <div class="tableau-compta"><table class="compta">
      <tr>${r.colonnes.map((c) => `<th${droite(c) ? ' class="r"' : ""}>${echapper(c.libelle)}</th>`).join("")}</tr>
      ${corps}
      ${r.total ? rang(r.total, "total-general") : ""}
    </table></div>
    ${(r.sources || []).length ? `<details><summary>Sources</summary><ul>${
      r.sources.map((x) => `<li class="discret">${echapper(x)}</li>`).join("")}</ul></details>` : ""}
    ${r.fichier ? `<div class="actions">
      <button class="lien" id="x-dossier-2">Ouvrir le dossier</button></div>` : ""}`;
  const o = document.getElementById("x-dossier-2");
  if (o) o.onclick = async () => {
    try { await api("ouvrir-exports"); } catch (e) { dire(e.message, "erreur"); }
  };
  if (!apercu) dire("Export écrit.");
}

/** L'état rendu, tel quel : les groupes, leurs sous-totaux, le pied. */
function dessinerLivre(r, apercu) {
  const cible = document.getElementById("exports-resultat");
  const eur = (v) => (v === null || v === undefined ? "—" : echapper(v));
  const ligne = (l) => `
    <tr>
      <td>${echapper(l.mois)}</td>
      <td>${echapper(l.salarie)}</td>
      <td class="discret">${echapper(l.spectacle || l.nature)}</td>
      <td class="discret">${echapper(l.source)}</td>
      <td class="r">${eur(l.brut)}</td>
      <td class="r">${eur(l.cotisations_salariales)}</td>
      <td class="r">${eur(l.cotisations_patronales)}</td>
      <td class="r">${eur(l.net_imposable)}</td>
      <td class="r">${eur(l.net_a_payer)}</td>
      <td class="r">${eur(l.pas)}</td>
      <td class="r">${eur(l.cout_employeur)}</td>
    </tr>`;
  const total = (t, titre, classe) => `
    <tr class="${classe}">
      <td></td><td><b>${echapper(titre)}</b></td>
      <td class="discret">${t.bulletins} bulletin${t.bulletins === 1 ? "" : "s"}</td>
      <td></td>
      <td class="r"><b>${eur(t.brut)}</b></td>
      <td class="r"><b>${eur(t.cotisations_salariales)}</b></td>
      <td class="r"><b>${eur(t.cotisations_patronales)}</b></td>
      <td class="r"><b>${eur(t.net_imposable)}</b></td>
      <td class="r"><b>${eur(t.net_a_payer)}</b></td>
      <td class="r"><b>${eur(t.pas)}</b></td>
      <td class="r"><b>${eur(t.cout_employeur)}</b></td>
    </tr>`;
  const corps = r.groupes.map((g) =>
    g.lignes.map(ligne).join("") + total(g.totaux, "Total " + g.libelle, "sous-total")
  ).join("");
  cible.innerHTML = `
    <h2>${echapper(r.periode)}</h2>
    <p class="discret">${r.totaux.bulletins} bulletin${r.totaux.bulletins === 1 ? "" : "s"},
      ${echapper(r.mois.length)} mois${r.fichier
        ? ` — écrit : <b>${echapper(r.fichier)}</b>`
        : " — aperçu, rien n'a été écrit"}.</p>
    ${Object.keys(r.totaux.inconnus || {}).length
      ? `<div class="encart info">Totaux partiels :
         ${Object.entries(r.totaux.inconnus).sort().map(([c, n]) =>
           `${echapper(c.replace(/_/g, " "))} sur ${r.totaux.bulletins - n}
            bulletin${r.totaux.bulletins - n === 1 ? "" : "s"} sur ${r.totaux.bulletins}`)
           .join(" ; ")}.</div>`
      : ""}
    ${(r.avertissements || []).map((a) =>
        `<div class="encart info">${echapperLiens(a)}</div>`).join("")}
    <div class="tableau-compta"><table class="compta">
      <tr><th>Mois</th><th>Salarié</th><th>Spectacle</th><th>Source</th><th>Brut</th>
          <th>Cot. sal.</th><th>Cot. pat.</th><th>Net imposable</th>
          <th>Net à payer</th><th>PAS</th><th>Coût employeur</th></tr>
      ${corps}
      ${total(r.totaux, "TOTAL GÉNÉRAL", "total-general")}
    </table></div>
    ${r.fichier ? `<div class="actions">
      <button class="lien" id="x-dossier-2">Ouvrir le dossier</button></div>` : ""}`;
  const o = document.getElementById("x-dossier-2");
  if (o) o.onclick = async () => {
    try { await api("ouvrir-exports"); } catch (e) { dire(e.message, "erreur"); }
  };
  if (!apercu) dire("Export écrit.");
}

function boiteCloture(annee) {
  ouvrirBoite(`
    <h3>Clôturer l'exercice ${echapper(annee)}</h3>
    <div class="encart">
      <b>L'année se fige</b>
      Les saisies et les sorties de ${echapper(annee)} ne se modifieront plus
      (rouvrir reste possible, depuis l'Historique). Tout ce qu'il faut garder —
      saisies, bulletins, contrats signés, DPAE, DSN, certificats, retours des
      organismes, journal des dépôts, fiches, export compta — est réuni dans
      <b>Exercice_${echapper(annee)}.zip</b>.
    </div>
    <p class="note">La clôture vient après la dernière DSN de l'année : elle est
      refusée si un mois avec des paies n'a pas de DSN acceptée au journal.</p>
    <label class="coche"><input type="checkbox" id="c-forcer">
      Clôturer quand même si une DSN manque au journal (déposée ailleurs, par exemple)</label>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Annuler</button>
      <button class="primaire" id="c-lancer">Clôturer ${echapper(annee)}</button>
    </div>`);
  document.getElementById("c-lancer").onclick = async () => {
    document.getElementById("c-lancer").disabled = true;
    try {
      const r = await api("cloture", { annee, forcer: document.getElementById("c-forcer").checked });
      fermerBoite();
      dire("Exercice " + r.annee + " clos : " + r.archive + " (" + r.fichiers + " fichiers).");
      if (r.manques && r.manques.length) dire(r.manques.join(" · "));
      if (document.getElementById("exercices")) await dessinerExercices();
    } catch (e) {
      document.getElementById("c-lancer").disabled = false;
      dire(e.message, "erreur");
    }
  };
}

async function lancerExportCompta(annee) {
  let r;
  try { r = await api("export-compta", { annee }); }
  catch (e) { dire(e.message, "erreur"); return; }
  const lignes = r.ecritures.map((e) => `
    <tr><td>${echapper(e.date.slice(5, 7))}</td><td>${echapper(e.compte)}</td>
        <td>${echapper(e.libelle)}</td>
        <td class="r">${e.debit !== "0.00" ? echapper(e.debit) : ""}</td>
        <td class="r">${e.credit !== "0.00" ? echapper(e.credit) : ""}</td>
        <td class="discret">${echapper(e.analytique)}</td></tr>`).join("");
  ouvrirBoite(`
    <h3>Export compta ${echapper(r.annee)}</h3>
    <p class="discret">Mois ${r.mois.map((m) => m.slice(5)).join(", ")} — ${r.ecritures.length}
      écritures, débit ${echapper(euros(r.total_debit))} = crédit ${echapper(euros(r.total_credit))}.
      ${r.fichier ? `Écrit : <b>${echapper(r.fichier)}</b>` : ""}</p>
    ${(r.avertissements || []).map((a) => `<div class="encart info">${echapperLiens(a)}</div>`).join("")}
    <div class="tableau-compta"><table class="compta">
      <tr><th>Mois</th><th>Compte</th><th>Libellé</th><th>Débit</th><th>Crédit</th><th>Analytique</th></tr>
      ${lignes}
    </table></div>
    <div class="actions">
      <button class="secondaire" id="x-ouvrir">Ouvrir le dossier</button>
      <button class="primaire" onclick="fermerBoite()">Fermer</button>
    </div>`);
  document.getElementById("x-ouvrir").onclick = async () => {
    try { await api("ouvrir-exercices"); } catch (e) { dire(e.message, "erreur"); }
  };
  if (document.getElementById("exercices")) dessinerExercices();
}

/* =======================================================================
   CORRIGER UN MOIS DÉPOSÉ, ET ROUVRIR UN MOIS EN RETARD   (18/09/2026)
   =======================================================================
   « Dans un endroit spécial, avec un gros avertissement si l'échéance est
   passée, sur les mois suivants. » D'où cet écran, dans l'Historique et non
   dans la saisie : ce qu'on écrit ici ne modifie AUCUNE déclaration partie.
   La correction est un objet à part ; c'est la DSN du mois courant qui
   l'emporte, datée du mois d'origine (cahier technique 2026.1 §2.2.2.5).

   Rien ne part de cet écran, donc rien n'y demande le mot de passe : écrire
   une correction n'engage pas l'employeur. Le dépôt de la DSN qui la portera,
   lui, le demandera comme tous les autres.

   La page ne décide de rien, une fois de plus : quel mois se corrige, ce que
   la correction change, ce qu'elle refuse — tout vient d'`operations`, et la
   ligne de commande (`python -m moteur corriger`) lit exactement les mêmes
   réponses. */
async function dessinerRegularisation() {
  const cible = document.getElementById("regularisation");
  const titre = document.getElementById("titre-corrections");
  let r;
  try { r = await api("regularisations"); }
  catch (e) { cible.innerHTML = `<p class="discret">${echapper(e.message)}</p>`; return; }
  // Les mois qui se corrigent et ceux en retard se disent sur leur ligne,
  // dans « Les mois » : il ne reste ici que les corrections ÉCRITES, et le
  // titre se tait quand il n'y en a pas.
  const ecrites = r.corrections || [];
  if (titre) titre.hidden = !ecrites.length;
  cible.innerHTML = ecrites.map((m) => `
      <div class="corrections-mois">
        <b>${echapper(moisEnClair(m.mois))}</b>
        ${m.corrections.map((c) => `
          <div class="rang">
            <span class="rang-nom">n° ${c.numero}</span>
            <span class="pastille ${c.etat === "portee" ? "bien" : c.etat === "annulee" ? "" : "alerte"}">${echapper(c.etat)}</span>
            <span class="rang-infos">${echapper(c.salarie)}, ${echapper(jjmmaaaa(c.debut))} —
              ${echapper(c.motif)} <span class="discret">(${echapper(c.decidee_le)}, ${echapper(c.qui)})</span>
              ${c.portee_par ? ` · portée par la DSN ${echapper(deMois(c.portee_par.mois))}` : ""}
              ${!c.portee_par && c.preparee_par ? ` · dans la DSN ${echapper(deMois(c.preparee_par.mois))}, pas encore déposée` : ""}</span>
            ${c.portee_par || c.annulee_le ? ""
              : `<button class="secondaire" data-annuler="${echapper(m.mois)}:${c.numero}">Annuler</button>`}
          </div>`).join("")}
      </div>`).join("");
  cible.querySelectorAll("[data-corriger-mois]").forEach((b) => {
    b.onclick = () => boiteCorriger(b.dataset.corrigerMois);
  });
  cible.querySelectorAll("[data-annuler]").forEach((b) => {
    b.onclick = async () => {
      const [mois, numero] = b.dataset.annuler.split(":");
      const preuve = r.mot_de_passe_pose === false
        ? null : await demanderMotDePasse("annuler la correction n° " + numero);
      if (r.mot_de_passe_pose !== false && !preuve) return;
      try {
        await api("regularisation-annuler", { mois, numero: +numero, motdepasse: preuve });
        dire("Correction n° " + numero + " annulée — la prochaine DSN ne l'embarque plus.");
        await dessinerRegularisation();
      } catch (e) { dire(e.message, "erreur"); }
    };
  });
}

/** L'avertissement, en tête de chaque boîte de correction. C'est LA phrase
 *  de l'écran : elle dit que la déclaration partie ne bouge pas, et où la
 *  correction s'en va. Le mois porteur vient du moteur (`etat.mois_courant`),
 *  la page ne le calcule pas. */
function encartRegularisation(etat) {
  return `
    <div class="encart">
      <b>Ce mois est déposé, et son échéance est passée.</b>
      Ce que vous corrigez ici ne modifie pas la DSN déposée : la correction
      partira dans la DSN ${echapper(deMois(etat.mois_courant))},
      datée ${echapper(deMois(etat.mois))}. La saisie ${echapper(deMois(etat.mois))}
      reste telle qu'elle a été déclarée.
    </div>`;
}

/** Le mois d'origine : ses engagements déclarés, tels que la dernière
 *  correction portée les a laissés. On en choisit un. */
async function boiteCorriger(mois) {
  let r;
  try { r = await api("regularisation-mois", { mois }); }
  catch (e) { dire(e.message, "erreur"); return; }
  if (!r.etat.regularisable) { dire(r.etat.raison); return; }
  // L'etat qu'on promene porte aussi ce que la boite doit savoir demander :
  // un poste sans mot de passe pose (un bac d'essai) ne se voit pas offrir
  // un popup qui ne prouverait rien.
  const etat = { ...r.etat, mot_de_passe_pose: r.mot_de_passe_pose };
  ouvrirBoite(`
    <h3>Corriger ${echapper(moisEnClair(mois))}</h3>
    ${encartRegularisation(etat)}
    ${r.engagements.length ? r.engagements.map((e, i) => `
      <div class="rang">
        <span class="rang-nom">${echapper(e.nom)}</span>
        <span class="rang-infos">contrat ${echapper(e.numero)} · ${echapper(e.spectacle)} ·
          ${echapper(periodeEnClair(e.debut, e.fin))} ·
          brut ${echapper(euros(e.brut))}, net ${echapper(euros(e.net_a_payer))}
          ${e.deja_corrige ? " · déjà corrigé par une DSN partie" : ""}
          ${e.correction_en_cours ? ` · <b>correction n° ${e.correction_en_cours.numero} en attente</b>` : ""}</span>
        <button class="secondaire" data-eng="${i}">Corriger…</button>
      </div>`).join("")
      : `<p class="discret">Aucun engagement dans la saisie de ce mois.</p>`}
    <p class="note">Un engagement oublié en entier n'est pas une correction :
      c'est un contrat en retard, avec sa DPAE — il se saisit dans son mois.</p>
    <div class="actions">
      <button class="primaire" onclick="fermerBoite()">Fermer</button>
    </div>`);
  document.getElementById("boite").querySelectorAll("[data-eng]").forEach((b) => {
    b.onclick = () => boiteCorrigerEngagement(mois, r.engagements[+b.dataset.eng], etat);
  });
}

/** Une correction : les lignes de paie de l'engagement déclaré, telles
 *  qu'elles ont été déclarées, qu'on modifie. Le contrat ne bouge pas —
 *  numéro, bornes, spectacle identifient la déclaration d'origine, et le
 *  moteur refuse une correction qui les déplacerait.
 *
 *  Les lignes sont celles de la saisie (`ligneRubrique`), calendrier compris :
 *  un cachet se coche dans le mois d'ORIGINE, d'où le mois passé à
 *  `ouvrirCalendrier`. L'aperçu vient du moteur à chaque frappe, comme
 *  l'aperçu d'un mois — la page ne calcule aucune paie. */
function boiteCorrigerEngagement(mois, e, etat) {
  const tauxAvant = DERNIER_TAUX;     // taper un taux ici ne décide pas du prochain mois
  const rendre = () => { DERNIER_TAUX = tauxAvant; };
  ouvrirBoite(`
    <h3>Corriger le contrat ${echapper(e.numero)}</h3>
    ${encartRegularisation(etat)}
    <p class="discret">${echapper(e.nom)} — ${echapper(e.spectacle)},
      du ${echapper(jjmmaaaa(e.debut))} au ${echapper(jjmmaaaa(e.fin))}.
      Le contrat garde son numéro et ses dates : seules ses lignes se corrigent.</p>
    <div id="cor-lignes"></div>
    <button class="secondaire" id="cor-ajouter">+ une ligne</button>
    <label>Ce qui était faux
      <input id="cor-motif" placeholder="un cachet oublié, un taux erroné…"
             value="${echapper((e.correction_en_cours || {}).motif || "")}">
    </label>
    <div id="cor-apercu" class="note">L'aperçu arrive…</div>
    <p class="note">Écrire demande le mot de passe du logiciel : rien ne part
      maintenant, mais cette correction repartira d'elle-même dans la
      prochaine DSN.</p>
    <div class="actions">
      <button class="secondaire" id="cor-retour">Retour</button>
      <button class="primaire" id="cor-ecrire" disabled>Écrire la correction…</button>
    </div>`, rendre);

  const zone = document.getElementById("cor-lignes");
  const vue = document.getElementById("cor-apercu");
  const bouton = document.getElementById("cor-ecrire");
  let minuteur = null, dernier = null;

  const poser = (l) => {
    const div = ligneRubrique(l);
    // Le calendrier du mois d'ORIGINE, et non celui de l'écran de paie.
    div.querySelector(".r-jours-btn").onclick = (ev) => { ev.preventDefault(); ouvrirCalendrier(div, mois); };
    // `new Event("input")` ne remonte pas : on s'accroche aux deux endroits
    // que le calendrier et la suppression touchent directement.
    const jours = div.querySelector(".r-jours");
    const avant = jours.oninput;
    jours.oninput = (ev) => { if (avant) avant(ev); plusTard(); };
    const sup = div.querySelector(".supprimer");
    const avantSup = sup.onclick;
    sup.onclick = (ev) => { if (avantSup) avantSup(ev); plusTard(); };
    zone.appendChild(div);
  };
  const plusTard = () => { clearTimeout(minuteur); minuteur = setTimeout(calculer, 350); };

  const calculer = async () => {
    const lignes = lignesDuBloc(zone, mois);
    let a;
    try {
      a = await api("regularisation-apercu", {
        mois, salarie: e.salarie, debut: e.debut, engagement: { lignes },
      });
    } catch (err) {
      dernier = null; bouton.disabled = true;
      vue.innerHTML = `<div class="encart attention">${echapper(err.message)}</div>`;
      return;
    }
    dernier = a;
    vue.innerHTML = vueApercuCorrection(a);
    majBoutonCorrection();
  };
  const majBoutonCorrection = () => {
    const motif = document.getElementById("cor-motif").value.trim();
    bouton.disabled = !dernier || dernier.rien_ne_change || !motif;
  };

  (e.engagement.lignes || []).forEach(poser);
  if (!(e.engagement.lignes || []).length) poser({});
  zone.addEventListener("input", plusTard);
  zone.addEventListener("change", plusTard);
  document.getElementById("cor-motif").oninput = majBoutonCorrection;
  document.getElementById("cor-ajouter").onclick = (ev) => { ev.preventDefault(); poser({}); plusTard(); };
  document.getElementById("cor-retour").onclick = () => { rendre(); boiteCorriger(mois); };
  bouton.onclick = async () => {
    // LE POPUP, ET PAS UN CLIC SEC (18/09/2026). « Je m'attendais pas à ce
    // que ça clique facilement, je m'attendais au mot de passe, c'est quand
    // même une action risquée. » Ecrire une correction n'envoie rien, mais
    // arme la prochaine DSN sur un mois deja declare : c'est un acte, et
    // tout acte passe par le meme popup. Le moteur l'exige de toute facon.
    const preuve = etat.mot_de_passe_pose === false
      ? null : await demanderMotDePasse("corriger " + moisEnClair(mois) + ", déjà déclaré");
    if (etat.mot_de_passe_pose !== false && !preuve) return;
    bouton.disabled = true;
    try {
      const r = await api("regularisation-ecrire", {
        mois, salarie: e.salarie, debut: e.debut,
        engagement: { lignes: lignesDuBloc(zone, mois) },
        motif: document.getElementById("cor-motif").value,
        motdepasse: preuve,
      });
      rendre();
      fermerBoite();
      dire("Correction n° " + r.correction.numero + " écrite — elle partira dans la DSN "
           + deMois(etat.mois_courant) + ".");
      await dessinerRegularisation();
    } catch (err) {
      bouton.disabled = false;
      dire(err.message, "erreur");
    }
  };
  calculer();
}

function vueApercuCorrection(a) {
  const ligne = (titre, cle) => `
    <tr><td>${titre}</td><td class="r">${echapper(a.avant[cle])}</td>
        <td class="r">${echapper(a.apres[cle])}</td>
        <td class="r">${a.delta[cle] === undefined ? "" : echapper(a.delta[cle])}</td></tr>`;
  return `
    <table class="compta">
      <tr><th></th><th>avant</th><th>après</th><th>différence</th></tr>
      ${ligne("cachets", "cachets")}
      ${ligne("heures", "heures")}
      ${ligne("brut", "brut")}
      ${ligne("cot. salariales", "cotisations_salariales")}
      ${ligne("cot. patronales", "cotisations_patronales")}
      ${ligne("net imposable", "net_imposable")}
      ${ligne("net à payer", "net_a_payer")}
      ${ligne("coût employeur", "cout_employeur")}
    </table>
    ${(a.avertissements || []).map((x) => `<div class="encart attention">${echapper(x)}</div>`).join("")}
    ${a.rien_ne_change
      ? `<p class="note">Rien ne change : il n'y a pas de correction à écrire.</p>`
      : `<p class="note">Cette différence partira dans la DSN
           ${echapper(deMois(a.etat.mois_courant))}, datée
           ${echapper(deMois(a.mois))} — l'ancienne paie en négatif, la
           nouvelle en positif.</p>`}`;
}

/** UN MOIS FERMÉ QUI SE ROUVRE. Passé le 15 du mois suivant, le mois est en
 *  lecture seule : sa DSN était due. Mais une DSN oubliée doit partir — en
 *  retard, et en le sachant. Le moteur exige alors qu'on le redise
 *  (`forcer_delai`) ; ici, c'est cette boîte qui le fait dire. Elle ne
 *  rouvre que le mois affiché, et seulement jusqu'au prochain chargement. */
function boiteRouvrirMois(mois, limite) {
  ouvrirBoite(`
    <h3>Rouvrir ${echapper(moisEnClair(mois))}</h3>
    <div class="encart attention">
      <b>La DSN ${echapper(deMois(mois))} était due le ${echapper(jjmmaaaa(limite))}.</b>
      La déposer maintenant reste ce qu'il faut faire — une DSN en retard vaut
      mieux qu'une DSN absente — mais le retard est connu des organismes et
      peut être pénalisé.
    </div>
    <p class="note">Rouvrir n'envoie rien : le mois redevient modifiable, et il
      se produit puis se dépose comme d'habitude. Si sa DSN est déjà partie et
      qu'il faut en corriger le contenu, ce n'est pas ici : c'est
      Historique › Corriger un mois déposé.</p>
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Laisser fermé</button>
      <button class="primaire" id="rm-ok">Rouvrir ${echapper(moisEnClair(mois))}</button>
    </div>`);
  document.getElementById("rm-ok").onclick = () => {
    MOIS_FORCE = mois;
    fermerBoite();
    if (MOIS_AFFICHE === mois) majFermeture(mois, true);
    dire("Mois rouvert — ce qui part d'ici part en retard.");
  };
}

/* =======================================================================
   LA VEILLE
   =======================================================================
   Ce que le serveur fait sans qu'on le lui demande : sauvegarder le dossier
   prive dans le Drive, relever les retours. La page ne declenche rien
   d'elle-meme au chargement -- le serveur a deja lance le premier tour a
   l'ouverture. Elle ne fait que demander ou ca en est.

   Elle ne calcule rien non plus : tout ce qui s'affiche ici est rendu par
   /api/veille, comme le reste. */
let VEILLE = null;

/** Un passage de veille a pu changer ce que la page montre : un contrat
 *  signé d'un clic (pastille, colonne de droite, fiche), un retour rattaché
 *  à un dépôt. « Il devrait se mettre à jour tout en même temps » : quand
 *  le dernier passage n'est plus celui qu'on a vu, on repeint les états et
 *  la colonne des actes — ce sont des lectures locales, elles ne coûtent
 *  rien. */
async function rafraichirApresVeille(v) {
  const avant = VEILLE?.dernier?.quand;
  const apres = v?.dernier?.quand;
  if (!apres || apres === avant || v.en_cours) return;
  const mois = document.getElementById("mois").value;
  try {
    await dessinerEtatsDesPaies(mois);
    await rafraichirActions();
  } catch (e) { /* le bandeau dit déjà l'essentiel */ }
}

/* LE BANDEAU, REPENSÉ (24/09/2026). On y cherche trois choses, dans cet
   ordre : est-ce que tout va bien ? est-ce qu'il est arrivé quelque chose ?
   est-ce qu'il y a quelque chose à FAIRE ? Il enfilait tout à la suite
   (« dernier passage … — 285 retour(s), dont 2 nouveau(x), 1 archive(s). —
   Mot de passe Urssaf (DPAE) absent du coffre […] `python -m moteur coffre
   poser urssaf` »), en orange dès qu'une ligne manquait.

   Maintenant : une phrase calme quand tout va (« À jour — relevé à 16:28 »,
   le détail au survol) ; les nouvelles en clair (retours, signatures,
   version) ; ce qui est à faire en orange, dit en mots, avec le lien vers
   l'endroit où le faire. Jamais une commande de terminal : une fenêtre
   n'en a pas. */
const A_POSER = {
  "net-entreprises": ["Les retours de DSN ne se relèvent pas seuls : le mot de passe net-entreprises n'est pas posé.", "Poser le mot de passe"],
  urssaf: ["Les retours de DPAE ne se relèvent pas seuls : le mot de passe Urssaf (DPAE) n'est pas posé.", "Poser le mot de passe"],
  google: ["La sauvegarde ne part pas : aucun Drive n'est lié.", "Lier le Drive"],
};

/** « à 16:28 » aujourd'hui, « le 23/09 à 16:28 » un autre jour. */
function heureDuPassage(q) {
  const m = String(q || "").match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}:\d{2})/)
    || String(q || "").match(/^(\d{2})\/(\d{2})\/(\d{4}) (\d{2}:\d{2})/);
  if (!m) return q ? `le ${q}` : "";
  const [an, mo, jo] = m[1].length === 4 ? [m[1], m[2], m[3]] : [m[3], m[2], m[1]];
  const auj = new Date();
  const memeJour = +an === auj.getFullYear() && +mo === auj.getMonth() + 1 && +jo === auj.getDate();
  return memeJour ? `à ${m[4]}` : `le ${jo}/${mo} à ${m[4]}`;
}

/** Aller aux mots de passe, d'où qu'on soit -- et y ouvrir la ligne de ce
 *  qui manque, le curseur dans la case : il ne reste qu'à taper. */
let OUVRIR_SERVICE = null;
function allerAuxMotsDePasse(service) {
  OUVRIR_SERVICE = service || null;
  document.querySelector('.onglets button[data-vue="configuration"]').click();
  document.querySelector('.sous-onglets button[data-fiche="coffre"]').click();
}

function dessinerVeille(v) {
  VEILLE = v;
  const zone = document.getElementById("veille");
  const texte = document.getElementById("veille-texte");
  if (!v || (!v.minutes && !v.dernier?.quand && !v.en_cours)) { zone.hidden = true; return; }
  zone.hidden = false;
  zone.classList.remove("souci", "neuf");

  if (v.en_cours) {
    texte.innerHTML = "Relevé des retours en cours…";
    return;
  }
  const d = v.dernier || {};

  // 1. L'ÉTAT, en une phrase. Le détail des relevés passe au survol : on
  //    le cherche rarement, et il reste à portée.
  const detail = [d.sauvegarde, d.retours, d.signatures, d.fiches, d.sources,
                  d.maj_exigee ? "" : d.maj].filter(Boolean).join("\n");
  const morceaux = [`<span class="veille-etat" title="${echapper(detail)}">${d.hors_ligne
    ? "<b>Hors connexion</b> — sauvegarde et retours au prochain passage"
    : `À jour — relevé ${echapper(heureDuPassage(d.quand))}${v.sauvegarde_en_cours
        ? " · sauvegarde en cours…" : ""}`}</span>${enDemonstration()
    ? ` · <button class="lien" data-demo-explique="coulisses">démonstration : ni sauvegarde
        ni mise à jour — pourquoi ?</button>` : ""}`];

  // 2. LES NOUVELLES : ce qui est arrivé depuis le dernier regard.
  const nouvelles = [];
  if (d.nouveaux) nouvelles.push(`${d.nouveaux} retour${d.nouveaux > 1 ? "s" : ""} nouveau${d.nouveaux > 1 ? "x" : ""}`);
  (d.signatures_recues || []).forEach((x) => nouvelles.push(`contrat signé par ${x.nom}`));
  if (d.maj && !d.maj_exigee) nouvelles.push(d.maj);
  // L'HORLOGE DE LA DÉMONSTRATION : ce que l'administrateur fictif a fait
  // pendant l'absence du visiteur, chaque geste à sa date limite.
  const horloge = enDemonstration() && (d.horloge || []).length
    ? ` <button class="lien" id="demo-horloge">pendant votre absence, la compagnie a
        travaillé (${d.horloge.length}) — voir</button>` : "";
  if (nouvelles.length) morceaux.push(`<b>${nouvelles.map(echapper).join(" · ")}</b>`);
  if (horloge) morceaux.push(horloge);
  if (d.maj_note) morceaux.push(`<b>${echapper(d.maj_note)}</b>`);
  // La version prete qui attend une DSN : la page laisse passer outre,
  // en le disant. La bascule reste au prochain demarrage, fenetre fermee.
  if (d.maj_attend && d.maj_attend.length) {
    morceaux.push(`<button class="lien" id="maj-malgre-calcul">Appliquer quand
      même au prochain démarrage</button>`);
    setTimeout(() => {
      const b = document.getElementById("maj-malgre-calcul");
      if (!b) return;
      b.onclick = async () => {
        if (!confirm("Cette version change un calcul. Les bulletins déjà produits "
          + "pour " + d.maj_attend.join(", ") + " pourraient différer de la DSN "
          + "qui sera déposée. L'appliquer quand même au prochain démarrage ?")) return;
        try { await api("maj-malgre-calcul"); b.replaceWith("s'appliquera au prochain démarrage"); }
        catch (e) { alert(e.message); }
      };
    }, 0);
  }

  // 3. CE QUI EST À FAIRE : en mots, avec le chemin. Le premier se lit, les
  //    suivants se déplient.
  const afaire = [];
  if (d.maj_exigee) afaire.push(`<b>${echapper(d.maj)}</b>`);
  (d.a_poser || []).forEach((code) => {
    const [phrase, geste] = A_POSER[code] || [code, "Mots de passe"];
    afaire.push(`${echapper(phrase)} <button class="lien" data-aller="${echapper(code)}">${echapper(geste)}</button>`);
  });
  // LES TAUX DE PAS QUI MANQUENT. Ni incident ni panne : la paie sortira, et
  // la loi dit quoi déclarer sans eux (la grille de l'article 204 H). C'est
  // un travail à faire, et le bandeau est le seul endroit où il arrive à
  // temps — trois semaines avant la DSN, pas cinq minutes avant le dépôt.
  if (d.taux_pas && d.taux_pas.length) {
    afaire.push(`<span title="${echapper(d.taux_pas.join(" · "))}">${d.taux_pas.length}
      salarié${d.taux_pas.length > 1 ? "s" : ""} sans taux de PAS valide : la grille
      par défaut s'appliquera</span>${enDemonstration()
      ? ` <button class="lien" data-demo-explique="pas">pourquoi ?</button>` : ""}`);
  }
  [...(d.manquants || []), ...(d.incidents || []), ...(v.erreur ? [v.erreur] : [])]
    .forEach((x) => afaire.push(echapper(x)));
  if (afaire.length) {
    zone.classList.add("souci");
    morceaux.push(afaire.length === 1 ? afaire[0]
      : `<details class="ennuis"><summary>${afaire[0]}
           <b>+ ${afaire.length - 1} autre${afaire.length > 2 ? "s" : ""}</b></summary>
           ${afaire.slice(1).map((x) => `<div>${x}</div>`).join("")}</details>`);
  } else if (nouvelles.length) {
    zone.classList.add("neuf");
  }
  texte.innerHTML = morceaux.join(" — ");
  texte.querySelectorAll("[data-aller]").forEach((b) => {
    b.onclick = () => allerAuxMotsDePasse(b.dataset.aller);
  });
  const bh = texte.querySelector("#demo-horloge");
  if (bh) bh.onclick = () => ouvrirBoite(`
    <div class="demo-fenetre">
      <h3>Démonstration — Pendant votre absence</h3>
      <p class="intro">L'administrateur fictif a fait ce qui tombait, chacun à sa date
        limite : le 1er du mois, le mois s'écrit ; le jour d'une embauche, sa DPAE part ;
        à l'échéance, la DSN. Tout est joué, rien n'a quitté le poste — et le journal
        de chaque mois le montre.</p>
      <ul>${d.horloge.map((x) => `<li>${echapper(x)}</li>`).join("")}</ul>
      <div class="actions"><button class="primaire" onclick="fermerBoite()">Compris</button></div>
    </div>`);
  texte.querySelectorAll("[data-demo-explique]").forEach((b) => {
    b.onclick = (ev) => { ev.preventDefault(); fenetreExplicationDemo(b.dataset.demoExplique); };
  });
}

async function suivreVeille() {
  if (SERVEUR_PERDU) return;          // le bandeau dit déjà l'essentiel
  try {
    const v = await api("veille");
    await rafraichirApresVeille(v);
    dessinerVeille(v);
    dessinerPastilleReponses();
  } catch (e) { /* déjà signalé */ }
}

document.getElementById("veille-maintenant").onclick = async () => {
  dessinerVeille({ ...(VEILLE || {}), en_cours: true });
  try {
    const v = await api("veille-maintenant");
    // Le relevé manuel repeint TOUJOURS : c'est ce qu'on vient demander.
    VEILLE = { ...(VEILLE || {}), dernier: {} };
    await rafraichirApresVeille(v);
    dessinerVeille(v);
    dire("Relevé terminé.");
  } catch (e) { dire("Relevé impossible : " + e.message, "erreur"); }
};

/* =======================================================================
   DEMARRAGE
   ===================================================================== */
async function demarrer() {
  ETAT = await api("etat");

  // Une option VIDE en tete, et c'est elle le defaut. Un deroulant montre
  // toujours quelque chose : sans elle, le premier spectacle de la liste a
  // l'air choisi alors que personne ne l'a choisi -- et il porte le numero
  // d'objet qui part en DSN. Un mois porte d'ailleurs plusieurs spectacles :
  // c'est l'engagement qui dit le sien, pas le mois.
  const c = ETAT.configuration;
  const err = [c.entreprise, ...c.salaries, ...c.spectacles]
    .reduce((n, f) => n + f.anomalies.filter((a) => a.gravite === "erreur" && !aRemplir(a)).length, 0);
  const annees = Object.entries(c.compteurs).filter(([k]) => /^\d{4}$/.test(k));
  const compteurs = annees.slice(-1)[0];
  document.getElementById("etat-global").innerHTML = `
    ${err ? `<span class="pastille erreur">${err} erreur(s) de configuration</span>` : ""}
    ${compteurs ? `<div>compteurs ${echapper(compteurs[0])} :
       bulletin <b>${compteurs[1].bulletin ?? "?"}</b> ·
       AEM <b>${compteurs[1].aem ?? "?"}</b> ·
       CS <b>${compteurs[1].certificat_cs ?? "?"}</b></div>` : ""}`;

  // LE MOIS EN COURS, et rien d'autre. « Le mois doit être le mois en cours de
  // base quand j'ouvre l'app ». La version d'avant
  // ouvrait sur « le premier mois non produit », ce qui paraissait serviable
  // et ne l'était pas : une saisie d'essai laissée en octobre faisait ouvrir
  // le logiciel en octobre, en septembre. On ouvre sur aujourd'hui ; le mois
  // se change d'une case, et l'Historique liste les autres.
  // SAUF UN MOIS PAS FINI (01/10/2026) : « on doit attendre que tout soit
  // vert pour passer au mois suivant, pour éviter d'oublier la DSN ou
  // l'envoi des documents ». Le moteur rend le plus ancien mois passé dont
  // une étape n'est pas verte ; seuls les mois saisis et passés comptent,
  // une saisie d'essai en avance n'y change rien.
  let ouvrir = moisCourant();
  try { ouvrir = (await api("mois-a-ouvrir")).mois || ouvrir; } catch (e) { /* le calendrier, alors */ }
  await chargerMois(ouvrir);
  finirChargement();

  // Ce qui attend : la DSN du mois d'avant, la clôture en janvier. Une
  // boîte, tout de suite, tant que ce n'est pas fait.
  await montrerRappels();

  // Le travail de fond : on le regarde toutes les minutes. C'est une lecture
  // d'etat en memoire cote serveur, elle ne coute rien -- surtout pas un
  // appel a Google ou a net-entreprises, qui n'ont lieu que dans le fil de
  // la veille, a son rythme a lui.
  suivreVeille();
  setInterval(suivreVeille, 60000);
}

/** Le voile du demarrage (index.html, #chargement) : une roue tant que la
 *  page se peint, puis la page d'un coup. Retire aussi en cas d'echec -- un
 *  voile qui resterait cacherait le message qui dit pourquoi -- et au bout de
 *  vingt secondes quoi qu'il arrive : une lecture qui traine ne doit pas
 *  bloquer l'ecran. */
function finirChargement() {
  const v = document.getElementById("chargement");
  if (!v || v.classList.contains("fini")) return;
  v.classList.add("fini");
  setTimeout(() => v.remove(), 300);
}
setTimeout(finirChargement, 20000);

demarrer().catch((e) => {
  finirChargement();
  dire("Démarrage impossible : " + e.message, "erreur");
});

/* ------------------------------------------------------- les mots de passe */
/* Configuration → Mots de passe. Trois choses, et une règle.
 *
 * Le mot de passe DU LOGICIEL : celui de la fenêtre et de chaque dépôt. On
 * le pose, on le change (l'actuel est exigé), on le retire. Les mots de
 * passe DES ORGANISMES (net-entreprises, Urssaf) vont au coffre : on les
 * pose, on les vérifie (UNE tentative, jamais de boucle : l'organisme bloque
 * le compte au bout de quelques échecs), on les oublie. La boîte courriel
 * (17/09/2026) s'y pose aussi, avec son adresse : c'est un mot de passe
 * d'application, la seule boîte qui envoie et qui lit. Et le COMPTE GOOGLE
 * (18/09/2026), qui ne porte que le Drive : « Lier le Drive » ouvre la
 * page de consentement dans le navigateur du système et attend qu'on y
 * accepte ; « Oublier » efface le jeton local.
 *
 * La règle : la page ne reçoit JAMAIS une valeur posée — seulement qu'elle
 * l'est, et depuis quand. Et si un mot de passe du logiciel est posé, il
 * est demandé pour écrire dans le coffre comme pour lier ou oublier le
 * compte Google, comme pour un dépôt : c'est `operations` qui l'exige, pas
 * ce fichier. */
/** Le compte qu'ouvre un mot de passe (§94) : sans lui, un mot de passe
 *  juste sur un identifiant faux échoue pareil, et rien ne le montrait.
 *  net-entreprises : le déclarant de la fiche Entreprise, qui se change
 *  là-bas ; l'Urssaf (DPAE) : un autre compte, qui se saisit sur la ligne. */
function compteDuService(s) {
  const id = s.identifiant || {};
  if (id.texte) return `<span class="compte">${echapper(id.texte)}</span>`;
  if (!id.manque || !id.manque.length) return "";
  const manque = id.manque.map((m) => ({ nom: "le nom", prenom: "le prénom", siret: "le SIRET" }[m] || m)).join(", ");
  return id.ici
    ? `<span class="compte a-completer">le compte Urssaf n'est pas dit (${echapper(manque)}) : la DPAE ne partira pas</span>`
    : `<span class="compte a-completer">identifiant incomplet (${echapper(manque)}) —
        <button class="lien" data-aller-fiche="entreprise">${echapper(id.ou || "fiche Entreprise")}</button></span>`;
}

/** CE QUI EST PARTI CHEZ L'ÉDITEUR (30/09/2026). Le journal des incidents,
 *  regroupé (`operations_filet.diagnostic_etat`) : ce qui est parti, ce qui
 *  attend, et pour chaque groupe le contenu EXACT qui quitte le poste. */
async function dessinerDiagnostic(rang) {
  if (!rang) return;
  const etat = rang.querySelector(".k-diag-etat"), compte = rang.querySelector(".k-diag-compte");
  let d;
  try { d = await api("diagnostic-etat"); } catch (e) { etat.textContent = e.message; return; }
  // L'ENVOI SE COUPE (Leandre, 08/10/2026) : avec un avertissement, et il se
  // rallume d'un clic. Coupé, rien ne part ; le journal reste sur le poste.
  const couper = rang.querySelector("#k-diag-couper");
  couper.hidden = false;
  couper.textContent = d.envoi === false ? "Réactiver" : "Désactiver";
  couper.onclick = async () => {
    if (d.envoi !== false) {
      const oui = await new Promise((resoudre) => {
        let repondu = false;
        const repondre = (v) => { if (!repondu) { repondu = true; resoudre(v); } };
        ouvrirBoite(`<h3>Désactiver le signalement des dysfonctionnements ?</h3>
          <p>Si vous le désactivez, l'éditeur ne verra plus les problèmes de votre
            logiciel, et risque de ne pas pouvoir les corriger avant qu'ils vous
            arrivent — ou qu'ils arrivent à d'autres compagnies.</p>
          <p class="note">Ce qui part ne contient ni nom, ni NIR, ni montant. Les
            incidents resteront notés sur cet ordinateur, et vous pourrez réactiver
            l'envoi à tout moment.</p>
          <p>Voulez-vous vraiment continuer ?</p>
          <div class="actions">
            <button class="secondaire" id="dg-garder">Non, garder l'envoi</button>
            <button class="primaire" id="dg-couper">Oui, désactiver</button>
          </div>`, () => repondre(false));
        document.getElementById("dg-garder").onclick = () => { repondre(false); fermerBoite(); };
        document.getElementById("dg-couper").onclick = () => { repondre(true); fermerBoite(); };
      });
      if (!oui) return;
    }
    try {
      await api("diagnostic-regler", { actif: d.envoi === false });
      dire(d.envoi === false ? "Le signalement des dysfonctionnements est réactivé."
        : "Le signalement des dysfonctionnements est désactivé : rien ne part plus chez l'éditeur.");
    } catch (e) { dire(e.message, "erreur"); return; }
    dessinerDiagnostic(rang);
  };
  etat.innerHTML = d.envoi === false ? `<span class="pastille alerte">désactivé</span>`
    : !d.total ? `<span class="pastille bien">rien à signaler</span>`
    : d.en_attente ? `<span class="pastille alerte">${d.en_attente} en attente</span>`
    : `<span class="pastille bien">tout est parti</span>`;
  compte.textContent = d.envoi === false ? "désactivé : les incidents restent sur cet ordinateur, rien ne part"
    : !d.serveur ? "aucun serveur de l'éditeur connu : rien ne part"
    : d.dernier_envoi ? `${d.partis} incident(s) parti(s), le dernier le ${quand(d.dernier_envoi)}`
    : d.total ? "rien n'est encore parti" : "";
  let signales = [];
  try { signales = (await api("signalements")).signalements; } catch (e) { /* la liste est un plus */ }
  rang.querySelector("#k-diag-voir").onclick = () => boiteDiagnostic(d, rang, signales);
}

function boiteDiagnostic(d, rang, signales = []) {
  const NOMS = { logiciel: "plantage", refus: "refus du moteur", dpae: "DPAE rejetée",
                 dsn: "DSN rejetée" };
  ouvrirBoite(`
    <h3>Ce qui est parti chez l'éditeur</h3>
    <p class="note">Quand quelque chose casse, PuppetPaie le note et l'envoie au serveur
      de l'éditeur, pour qu'il le corrige. Ce qui part est affiché ici tel quel :
      ni nom, ni NIR, ni montant ; le poste est désigné par un numéro tiré au hasard.
      ${d.serveur ? `Serveur : <b>${echapper(d.serveur)}</b>.` : "<b>Aucun serveur connu : rien ne part.</b>"}</p>
    ${!d.groupes.length ? `<p>Rien n'a été noté.</p>` : `<div class="liste-choix">
      ${d.groupes.map((g, i) => `
        <div class="choix"><span>
          <b>${echapper(NOMS[g.quoi] || g.quoi)}</b>
          ${g.combien > 1 ? `<span class="discret">× ${g.combien}</span>` : ""}
          — ${echapper(g.resume || g.genre || "")}
          <br><span class="discret">${echapper(g.ou || "")} · dernier le ${echapper(quand(g.derniere))}</span>
          <br>${g.en_attente
            ? `<span class="pastille alerte">${g.en_attente} en attente</span>`
            : `<span class="pastille bien">parti le ${echapper(quand(g.parti_le))}</span>`}
          <button class="lien d-contenu" data-i="${i}">voir le contenu exact</button>
          <pre class="d-pre" data-i="${i}" hidden></pre></span>
        </div>`).join("")}</div>`}
    ${listeSignalements(signales)}
    <div class="actions">
      <button class="secondaire" onclick="fermerBoite()">Fermer</button>
      ${d.en_attente && d.serveur ? `<button class="primaire" id="d-envoyer">Envoyer maintenant</button>` : ""}
    </div>`);
  document.querySelectorAll(".d-contenu").forEach((b) => {
    b.onclick = () => {
      const pre = document.querySelector(`.d-pre[data-i="${b.dataset.i}"]`);
      pre.textContent = JSON.stringify(d.groupes[+b.dataset.i].contenu, null, 2);
      pre.hidden = !pre.hidden;
    };
  });
  const envoyer = document.getElementById("d-envoyer");
  if (envoyer) envoyer.onclick = async () => {
    const rendre = occupe(envoyer, "Envoi…");
    try {
      const r = await api("diagnostic-envoyer");
      fermerBoite();
      dire(r.bilan.erreur ? "Envoi impossible : " + r.bilan.erreur
                          : r.bilan.envoyes + " incident(s) envoyé(s).",
           r.bilan.erreur ? "erreur" : undefined);
      dessinerDiagnostic(rang);
    } catch (e) { rendre(); dire(e.message, "erreur"); }
  };
}

/* SIGNALER UN PROBLÈME. Le bouton du bandeau, sur tous les écrans.
 *
 * PAS SEULEMENT UN PROBLÈME (l'éditeur, 01/10/2026 : « ils peuvent aussi
 * émettre une envie, une idée ») : le bouton s'appelle « Un problème, une
 * idée ? ».
 *
 * L'UTILISATEUR ÉCRIT, JOINT SES CAPTURES ET ENVOIE (ticket #98, 01/10/2026 :
 * « les gens veulent que l'on règle leur problème »). Cinq captures au plus,
 * collées ou choisies. « Réduire » range la boîte dans une pastille, le temps
 * de prendre une capture de l'écran qu'elle cachait, sans rien perdre.
 * « Voir ce qui part » reste là pour qui veut regarder, mais n'est plus une
 * étape : l'aperçu est le corps exact de l'envoi
 * (`operations_filet.signalement_apercu`), la page ne décide de rien. */
const CAPTURE_MAX = 1536 * 1024;           // 1,5 Mo, comme le moteur
const CAPTURES_MAX = 5;
let SIGNALEMENT_REDUIT = null;             // rouvre la boîte rangée dans sa pastille

function ecranCourant() {
  const b = document.querySelector(".onglets button.actif");
  const nom = b ? b.textContent.trim() : "";
  const mois = document.getElementById("mois");
  return nom === "Paie" && mois && mois.value ? `${nom} > ${mois.value}` : nom;
}

function boiteSignalement() {
  if (SIGNALEMENT_REDUIT) return SIGNALEMENT_REDUIT();
  // Déjà ouverte. Fermée, elle reste dans le nid de la boîte sous le voile
  // caché : ce n'est pas « ouverte » (02/10/2026 : « quand je clique sur
  // signaler il ne se rouvre pas »).
  if (document.getElementById("sg-boite")
      && !document.getElementById("voile").classList.contains("cachee")) return;
  const ecran = ecranCourant();
  const captures = [];                      // { type, donnees (data URL), octets }
  // La boîte déjà ouverte (une DPAE, un dépôt) attend dessous, et revient
  // quand celle-ci se ferme ou se réduit.
  let dessous = mettreDeCote();
  const rendreDessous = () => { const d = dessous; dessous = null; if (d) d(); };
  ouvrirBoite(`<div id="sg-boite">
    <h3>Un problème, une idée ?</h3>
    <label class="champ-boite">Ce qui ne va pas, ce qui vous manque, ce que vous aimeriez
      <textarea id="sg-texte" rows="6" maxlength="5000"></textarea></label>
    <div class="sg-vignettes" id="sg-vignettes"></div>
    <p class="discret" id="sg-ajout">Captures d'écran (${CAPTURES_MAX} au plus) : collez-les
      (Ctrl+V), <label class="lien">choisissez des images<input type="file" id="sg-fichier"
      accept="image/png,image/jpeg" multiple hidden></label>, ou
      <button type="button" class="lien" id="sg-capturer"
        title="Photographier l'écran de PuppetPaie tel qu'il est derrière cette boîte">capturez
        l'écran</button>.</p>
    <p class="encart erreur" id="sg-erreur" hidden></p>
    <p id="sg-resultat" hidden></p>
    <div class="actions">
      <button type="button" class="lien sg-voir" id="sg-voir" disabled>voir ce qui part</button>
      <button class="secondaire" id="sg-fermer">Fermer</button>
      <button class="secondaire" id="sg-reduire"
        title="Ranger la boîte le temps de faire une capture d'écran">Réduire</button>
      <button class="primaire" id="sg-envoyer" disabled>Envoyer</button>
    </div>
    <pre class="d-pre" id="sg-pre" hidden></pre>
    <div id="sg-messages"></div></div>`);
  // Les éléments se tiennent par la boîte, pas par le document : réduite,
  // elle est hors de la page, et ses gestes en cours doivent la trouver.
  const boite = document.getElementById("sg-boite");
  const $ = (id) => boite.querySelector("#" + id);
  const texte = $("sg-texte"), envoyer = $("sg-envoyer");
  const montrerErreur = (m) => { $("sg-erreur").textContent = m || ""; $("sg-erreur").hidden = !m; };
  const charge = () => ({ texte: texte.value, ecran,
    captures: captures.map((c) => ({ type: c.type, donnees: c.donnees })) });
  const changement = () => {
    envoyer.disabled = !texte.value.trim();
    $("sg-voir").disabled = !texte.value.trim();
    $("sg-pre").hidden = true;              // l'aperçu montré n'est plus le bon
  };

  const dessinerVignettes = () => {
    $("sg-vignettes").innerHTML = captures.map((c, i) => `
      <span class="sg-vignette"><img src="${c.donnees}" alt="Capture ${i + 1}">
        <button type="button" class="sg-retirer" data-i="${i}" title="Retirer cette capture">×</button></span>`).join("");
    $("sg-vignettes").querySelectorAll(".sg-retirer").forEach((b) => {
      b.onclick = () => { captures.splice(+b.dataset.i, 1); dessinerVignettes(); };
    });
    $("sg-ajout").hidden = captures.length >= CAPTURES_MAX;
    changement();
  };
  const poser = (fichier) => {
    montrerErreur("");
    if (captures.length >= CAPTURES_MAX) {
      return montrerErreur(`${CAPTURES_MAX} captures au plus.`);
    }
    if (!/^image\/(png|jpeg)$/.test(fichier.type)) {
      return montrerErreur("Une capture doit être une image PNG ou JPEG.");
    }
    if (fichier.size > CAPTURE_MAX) {
      return montrerErreur("Une capture dépasse 1,5 Mo : réduisez-la, ou découpez-la.");
    }
    const lecteur = new FileReader();
    lecteur.onload = () => {
      if (captures.length >= CAPTURES_MAX) return montrerErreur(`${CAPTURES_MAX} captures au plus.`);
      captures.push({ type: fichier.type, donnees: lecteur.result, octets: fichier.size });
      dessinerVignettes();
    };
    lecteur.readAsDataURL(fichier);
  };
  $("sg-fichier").onchange = () => {
    [...$("sg-fichier").files].forEach(poser);
    $("sg-fichier").value = "";
  };
  // Sur le contenu de CETTE boite : il disparait avec elle, l'ecouteur aussi.
  boite.addEventListener("paste", (e) => {
    const images = [...(e.clipboardData ? e.clipboardData.items : [])]
      .filter((i) => i.type.startsWith("image/"));
    if (!images.length) return;
    e.preventDefault();
    images.forEach((i) => poser(i.getAsFile()));
  });
  texte.addEventListener("input", changement);

  // VOS MESSAGES, et leurs réponses : ouvrir la boîte les rend lues.
  (async () => {
    try {
      const l = (await api("signalements")).signalements;
      $("sg-messages").innerHTML = vosMessages(l);
      if (l.some((s) => s.reponse && !s.lu)) {
        await api("signalements-lus");
        dessinerPastilleReponses();
      }
    } catch (e) { /* la liste est un plus */ }
  })();

  // RÉDUIRE : la boîte sort de la page, intacte, et une pastille la rappelle.
  // Le bouton « Un problème, une idée ? » du bandeau la rappelle aussi.
  const surCetteBoite = () => {
    FERMETURE_BOITE = rendreDessous;
    // Un clic à côté range la boîte ; une fois le message parti, il la ferme.
    // Rien d'écrit ni de capturé : rien à garder, il la ferme aussi
    // (02/10/2026 : « si on n'a rien modifié, on laisse partir »).
    const vide = () => !texte.value.trim() && !captures.length;
    CLIC_DEHORS = () => ($("sg-reduire").hidden || vide() ? fermerBoite() : $("sg-reduire").click());
  };
  $("sg-fermer").onclick = () => fermerBoite();

  // CAPTURER L'ÉCRAN, PAR LE LOGICIEL (ticket #102, 02/10/2026 : « un bouton,
  // capturer l'écran actuel, une espèce d'imprime-écran »). La boîte s'efface
  // le temps de la photo -- et la fenêtre qu'elle recouvrait (une DPAE, un
  // dépôt) revient pour y figurer --, puis tout se remet en place. La photo
  // est celle de la PAGE, dessinée par html2canvas : ce qui est hors de
  // PuppetPaie (une autre fenêtre, le bureau) n'y est pas.
  $("sg-capturer").onclick = async () => {
    montrerErreur("");
    if (captures.length >= CAPTURES_MAX) return montrerErreur(`${CAPTURES_MAX} captures au plus.`);
    boite.remove();
    const d = dessous;
    dessous = null;
    if (d) d(); else document.getElementById("voile").classList.add("cachee");
    let fichier = null, erreur = "";
    try {
      fichier = await photographierLaPage();
    } catch (e) { erreur = "La capture n'a pas pu se faire : " + e.message; }
    dessous = mettreDeCote();
    ouvrirBoite("");
    document.getElementById("boite").appendChild(boite);
    surCetteBoite();
    if (erreur) montrerErreur(erreur);
    else if (fichier) poser(fichier);
  };
  $("sg-reduire").onclick = () => {
    const pastille = document.createElement("button");
    pastille.type = "button";
    pastille.className = "sg-pastille";
    pastille.textContent = "Message en cours"
      + (captures.length ? ` (${captures.length} capture${captures.length > 1 ? "s" : ""})` : "")
      + " — reprendre";
    SIGNALEMENT_REDUIT = () => {
      SIGNALEMENT_REDUIT = null;
      pastille.remove();
      dessous = mettreDeCote();
      ouvrirBoite("");
      document.getElementById("boite").appendChild(boite);
      surCetteBoite();
      texte.focus();
    };
    pastille.onclick = SIGNALEMENT_REDUIT;
    boite.remove();
    fermerBoite();                          // rend la boîte de dessous, s'il y en a une
    document.body.appendChild(pastille);
  };
  surCetteBoite();

  $("sg-voir").onclick = async () => {
    if (!$("sg-pre").hidden) { $("sg-pre").hidden = true; return; }
    montrerErreur("");
    try {
      const a = await api("signalement-apercu", charge());
      $("sg-pre").textContent = JSON.stringify(a.corps, null, 2);
      $("sg-pre").hidden = false;
    } catch (e) { montrerErreur(e.message); }
  };
  envoyer.onclick = async () => {
    montrerErreur("");
    const rendre = occupe(envoyer, "Envoi…");
    try {
      const r = await api("signalement-envoyer", charge());
      $("sg-pre").hidden = true;
      $("sg-resultat").hidden = false;
      // D'ABORD MERCI (01/10/2026). Le ticket est dans un dépôt privé : son
      // lien ne servirait à rien ici. La réponse revient dans « Vos messages ».
      $("sg-resultat").innerHTML = `<b>Merci, c'est bien arrivé.</b>
        La réponse viendra ici, dans « Vos messages ».`;
      $("sg-messages").innerHTML = vosMessages(r.signalements || []);
      ["sg-voir", "sg-reduire", "sg-ajout"].forEach((id) => { $(id).hidden = true; });
      envoyer.hidden = true;
      texte.readOnly = true;
      $("sg-vignettes").querySelectorAll(".sg-retirer").forEach((b) => { b.hidden = true; });
    } catch (e) { rendre(); montrerErreur(e.message); }
  };
  texte.focus();
}
document.getElementById("signaler").onclick = boiteSignalement;
document.getElementById("signaler-voile").onclick = boiteSignalement;

/** html2canvas, chargé au premier usage seulement (servi par le moteur). */
let HTML2CANVAS = null;
function chargerHtml2canvas() {
  if (window.html2canvas) return Promise.resolve(window.html2canvas);
  if (!HTML2CANVAS) {
    HTML2CANVAS = new Promise((ok, ko) => {
      const sc = document.createElement("script");
      sc.src = "/html2canvas.min.js";
      sc.onload = () => ok(window.html2canvas);
      sc.onerror = () => { HTML2CANVAS = null; ko(new Error("outil de capture introuvable")); };
      document.head.appendChild(sc);
    });
  }
  return HTML2CANVAS;
}

/** La page telle qu'on la voit (la partie affichée), en JPEG sous 1,5 Mo. */
async function photographierLaPage() {
  const h2c = await chargerHtml2canvas();
  await new Promise((ok) => requestAnimationFrame(() => requestAnimationFrame(ok)));
  const essais = [[1, 0.85], [1, 0.6], [0.75, 0.6], [0.5, 0.6]];
  for (const [echelle, qualite] of essais) {
    const toile = await h2c(document.body, {
      scale: echelle, logging: false, backgroundColor: "#ffffff",
      x: window.scrollX, y: window.scrollY,
      width: window.innerWidth, height: window.innerHeight,
      windowWidth: document.documentElement.clientWidth,
      ignoreElements: (el) => el.id === "signaler-voile"
        || (el.classList && el.classList.contains("sg-pastille")),
    });
    const blob = await new Promise((ok) => toile.toBlob(ok, "image/jpeg", qualite));
    if (blob && blob.size <= CAPTURE_MAX) {
      const quand = new Date().toTimeString().slice(0, 8).replace(/:/g, "");
      return new File([blob], `ecran-${quand}.jpg`, { type: "image/jpeg" });
    }
  }
  throw new Error("l'image dépasse 1,5 Mo même réduite");
}

/* LES RÉPONSES DE L'ÉDITEUR (01/10/2026 : « chaque ticket a le droit à une
 * réponse »). Le moteur les relève à chaque veille (`relever_reponses`) ; une
 * réponse non lue se voit sur le bouton du bandeau, et se lit dans la boîte. */
function vosMessages(liste) {
  if (!liste.length) return "";
  return `<h4 class="sg-titre-messages">Vos messages</h4><ul class="sg-messages">${liste.map((s) => `
    <li${s.reponse && !s.lu ? ' class="nouveau"' : ""}><span class="discret">${echapper(quand(s.quand))}</span>
      ${echapper(s.debut)}${s.debut && s.debut.length >= 80 ? "…" : ""}
      ${s.reponse ? `<p class="sg-reponse">${echapper(s.reponse)}</p>`
                  : ` <span class="discret">— en attente de réponse</span>`}</li>`).join("")}</ul>`;
}

async function dessinerPastilleReponses() {
  let n = 0;
  try { n = (await api("signalements")).non_lues || 0; } catch (e) { return; }
  document.getElementById("signaler").innerHTML = "Un problème, une idée ?"
    + (n ? ` <span class="sg-nouvelles">· ${n} réponse${n > 1 ? "s" : ""}</span>` : "");
}
dessinerPastilleReponses();

function listeSignalements(liste) {
  if (!liste.length) return "";
  return `<h4>Vos signalements</h4><ul class="sg-liste">${liste.map((s) => `
    <li><span class="discret">${echapper(quand(s.quand))}</span> <b>${echapper(s.numero)}</b>
      — ${echapper(s.debut)}${s.ticket
        ? ` <a href="${echapper(s.ticket)}" target="_blank" rel="noopener">ticket n° ${echapper(String(s.ticket_numero ?? ""))}</a>` : ""}</li>`).join("")}</ul>`;
}

/** La ligne du filet de sécurité DPAE (27/09/2026). L'état vient du moteur
 *  (`operations_filet.etat_filet`) ; la clé du compte ne vient jamais ici. */
let ATTENTE_FILET = null;      // la minuterie qui guette la confirmation

async function dessinerFilet(rang, exige) {
  if (!rang) return;
  clearTimeout(ATTENTE_FILET);
  const etat = rang.querySelector(".k-filet-etat"), compte = rang.querySelector(".k-filet-compte");
  const verdict = rang.querySelector(".k-verdict");
  const arreter = rang.querySelector("#k-filet-arreter"), ouvrir = rang.querySelector("#k-filet-ouvrir");
  let f;
  try { f = await api("filet-etat"); } catch (e) { etat.textContent = e.message; return; }
  if (f.actif && !f.confirme) {
    try { f = await api("filet-verifier"); } catch (e) { /* le serveur dira plus tard */ }
  }
  etat.innerHTML = !f.actif ? `<span class="pastille">désactivé</span>`
    : f.confirme ? `<span class="pastille bien">actif</span>`
    : `<span class="pastille alerte">adresse à confirmer</span>`;
  compte.textContent = !f.actif ? "" : f.confirme ? f.adresse
    : `un courriel est parti à ${f.adresse} : cliquez sur le lien qu'il contient —
       cette ligne passera d'elle-même à « actif »`;
  // LA CONFIRMATION SE VOIT SANS RIEN FAIRE (27/09/2026) : tant que l'adresse
  // attend son clic, on redemande au serveur toutes les dix secondes, dix
  // minutes au plus, et on s'arrête dès qu'on quitte l'écran.
  if (f.actif && !f.confirme) guetterConfirmation(rang, exige, Date.now());
  if (f.erreur) verdict.textContent = f.erreur;
  arreter.hidden = !f.actif;
  ouvrir.innerHTML = f.actif ? `${CRAYON}Modifier…` : "Activer…";
  ouvrir.className = (f.actif ? "modifier" : "secondaire") + " k-ouvrir";
  const champ = rang.querySelector("#k-filet-adresse");
  if (!champ.value) champ.value = f.adresse || "";
  const preuve = async (quoi) => {
    if (!exige) return { motdepasse: null };
    const m = await demanderMotDePasse(quoi);
    return m ? { motdepasse: m } : null;
  };
  rang.querySelector("#k-filet-activer").onclick = async () => {
    const adresse = champ.value.trim();
    if (!adresse) { dire("L'adresse qui recevra le rappel."); champ.focus(); return; }
    const p = await preuve("activer le filet de sécurité DPAE");
    if (!p) return;
    try {
      await api("filet-activer", { adresse, ...p });
      dire("Un courriel de confirmation est parti à " + adresse + ".");
      rang.querySelector(".rang-forme").hidden = true;
      dessinerFilet(rang, exige);
    } catch (e) { dire(e.message, "erreur"); }
  };
  arreter.onclick = async () => {
    if (!confirm("Désactiver le filet ? Plus aucun courriel ne préviendra d'une DPAE oubliée.")) return;
    const p = await preuve("désactiver le filet de sécurité DPAE");
    if (!p) return;
    try {
      await api("filet-desactiver", p);
      dire("Filet de sécurité DPAE désactivé.");
      dessinerFilet(rang, exige);
    } catch (e) { dire(e.message, "erreur"); }
  };
}

function guetterConfirmation(rang, exige, depuis) {
  ATTENTE_FILET = setTimeout(async () => {
    if (!rang.isConnected || Date.now() - depuis > 10 * 60 * 1000) return;
    let f;
    try { f = await api("filet-verifier"); } catch (e) { f = null; }
    if (f && f.confirme) {
      dire("Adresse confirmée : le filet de sécurité DPAE est actif.");
      return dessinerFilet(rang, exige);
    }
    guetterConfirmation(rang, exige, depuis);
  }, 10000);
}

async function dessinerCoffre(cible) {
  // LA DÉMONSTRATION (27/09/2026, l'éditeur) : le même écran, tout grisé —
  // on voit ce qui se pose et où, sans rien pouvoir y écrire. Rien ne part,
  // il n'y a donc rien à poser ; la page ne branche aucun geste.
  const demo = enDemonstration();
  const c = await api("coffre-etat");
  const exige = c.mot_de_passe_pose;
  // UNE LIGNE PAR SECRET (23/09/2026), comme les mois de l'Historique : ce
  // qu'il sert à faire, où il en est, et les gestes. Les cases de saisie ne
  // s'ouvrent que sur « Poser… » ou « Modifier… » -- cinq formulaires ouverts
  // d'office faisaient croire qu'il y avait cinq choses à remplir.
  const etatService = (s) => demo ? `<span class="pastille">simulé</span>`
    : s.environnement
    ? `<span class="pastille alerte" title="Il passe devant le coffre.">fourni par l'environnement</span>`
    : s.pose ? `<span class="pastille bien" title="${echapper(s.pose_le)}">posé le ${echapper(jjmmaaaa(String(s.pose_le || "").slice(0, 10)))}</span>${
        s.compte ? ` <span class="discret">${echapper(s.compte)}</span>` : ""}`
    : `<span class="pastille alerte">absent</span>`;
  cible.innerHTML = `
    <p class="intro">Les mots de passe dont le logiciel a besoin pour déposer, relever et
      envoyer. La page ne voit jamais un mot de passe, seulement s'il est posé.</p>
    ${demo ? `<div class="encart info"><b>Démonstration — les champs sont grisés</b>
      Les dépôts de DPAE et de DSN, leurs retours, les courriels et les
      signatures sont simulés : aucun mot de passe n'est demandé, et rien ne
      quitte le poste. Dans la version complète, c'est ici que se posent les
      accès à net-entreprises, à l'Urssaf et à la boîte courriel — et que
      s'active le filet de sécurité DPAE, un courriel de rappel si une DPAE
      n'est pas partie la veille d'une embauche.</div>`
    : c.cle_poste ? "" : `<div class="encart"><b>Cet ordinateur n'a pas encore sa clé du coffre</b>
      Rien n'est perdu : elle se refait toute seule la prochaine fois que le mot de passe du
      logiciel est tapé (ou posé, ci-dessous). Elle vit à part des données, pour qu'une
      sauvegarde n'emporte jamais de quoi ouvrir le coffre.</div>`}
    <div class="rangs">
      <div class="rang">
        <div class="rang-infos"><b class="rang-nom">Le mot de passe du logiciel</b>
          <span class="discret">${exige || demo
            ? "demandé à l'ouverture et à chaque dépôt réel, envoi ou signature"
            : "rien ne peut partir en réel tant qu'il n'est pas posé"}</span></div>
        <div class="rang-etat">${demo ? `<span class="pastille">simulé</span>`
          : exige ? `<span class="pastille bien">posé</span>`
          : `<span class="pastille alerte">aucun</span>`}</div>
        <div class="rang-actions">
          ${exige ? `<button class="modifier k-ouvrir">${CRAYON}Modifier…</button>`
            : `<button class="secondaire k-ouvrir">Poser…</button>`}</div>
        <form class="rang-forme" id="k-logiciel" onsubmit="return false" autocomplete="off" hidden>
          ${exige ? `<label>Mot de passe actuel
            <input type="password" id="k-actuel" autocomplete="current-password"></label>` : ""}
          <label>Nouveau <span class="discret">— six caractères au moins</span>
            <input type="password" id="k-nouveau" autocomplete="new-password"></label>
          <label>Le retaper <input type="password" id="k-confirmation" autocomplete="new-password"></label>
          <div class="barre-boutons">
            <button class="primaire" id="k-changer">${exige ? "Enregistrer" : "Poser"}</button>
            ${exige ? `<button class="lien" id="k-retirer">retirer le mot de passe</button>` : ""}
          </div>
        </form>
      </div>
      ${c.services.map((s) => `
      <div class="rang" data-service="${echapper(s.service)}">
        <div class="rang-infos"><b class="rang-nom">${echapper(s.libelle)}</b>
          <span class="discret">${echapper(s.sert_a)}</span>${demo ? "" : compteDuService(s)}</div>
        <div class="rang-etat">${etatService(s)}</div>
        <div class="rang-actions">
          ${!demo && (s.pose || s.environnement) ? `<button class="lien k-verifier"
            title="Une tentative de connexion chez l'organisme, une seule">Vérifier</button>` : ""}
          ${s.pose ? `<button class="lien k-oublier">Oublier</button>` : ""}
          ${s.pose ? `<button class="modifier k-ouvrir">${CRAYON}Modifier…</button>`
            : `<button class="secondaire k-ouvrir">Poser…</button>`}
        </div>
        <div class="k-verdict discret"></div>
        <form class="rang-forme" onsubmit="return false" autocomplete="off"
          ${s.identifiant?.ici && s.identifiant.manque.length ? "" : "hidden"}>
          ${s.identifiant?.ici ? `<label>Prénom du compte Urssaf
            <input type="text" class="k-prenom" autocomplete="off" value="${echapper(s.identifiant.prenom)}"></label>
          <label>Nom du compte Urssaf
            <input type="text" class="k-nom" autocomplete="off" value="${echapper(s.identifiant.nom)}"></label>` : ""}
          ${s.avec_compte ? `<label>Adresse de la boîte
            <input type="email" class="k-compte" autocomplete="off" value="${echapper(s.compte || "")}"></label>` : ""}
          <label>Mot de passe${s.identifiant?.ici && s.pose
              ? ` <span class="discret">— vide : on garde celui qui est posé</span>` : ""}
            <input type="password" class="k-valeur" autocomplete="off"></label>
          <div class="barre-boutons"><button class="primaire k-poser">${s.identifiant?.ici ? "Enregistrer" : "Poser"}</button></div>
          ${s.identifiant?.ici ? `<p class="note">Le compte ouvert sur urssaf.fr pour la DPAE (service
            « DPAE Service plus ») : ce n'est pas celui de net-entreprises. Les accents sont
            retirés, la DPAE les refuse.</p>` : ""}
          ${s.avec_compte ? `<p class="note">Pour Gmail : validation en deux étapes activée,
            puis myaccount.google.com › Sécurité › Mots de passe des applications. C'est ce
            mot de passe-là, pas celui du compte.</p>` : ""}
        </form>
      </div>`).join("")}
      <div class="rang" id="k-google">
        <div class="rang-infos"><b class="rang-nom">Compte Google</b>
          <span class="discret">la sauvegarde du dossier privé et l'archivage des mois,
            dans son Drive — rien d'autre</span>${VEILLE?.dernier?.sauvegarde
            ? `<span class="compte">${echapper(VEILLE.dernier.sauvegarde)}</span>` : ""}</div>
        <div class="rang-etat k-google-etat"><span class="discret">lecture…</span></div>
        <div class="rang-actions">
          <button class="lien" id="k-google-oublier" hidden>Oublier</button>
          <button class="secondaire" id="k-google-lier" disabled>Lier le Drive</button>
        </div>
        <div class="k-verdict discret"></div>
      </div>
      <div class="rang" id="k-filet">
        <div class="rang-infos"><b class="rang-nom">Filet de sécurité DPAE</b>
          <span class="discret">un courriel, et un seul, si une DPAE n'est pas partie la
            veille d'une embauche — jamais rien quand elle est partie</span>
          <span class="compte k-filet-compte"></span></div>
        <div class="rang-etat k-filet-etat"><span class="discret">lecture…</span></div>
        <div class="rang-actions">
          <button class="lien" id="k-filet-arreter" hidden>Désactiver</button>
          <button class="secondaire k-ouvrir" id="k-filet-ouvrir">Activer…</button>
        </div>
        <div class="k-verdict discret"></div>
        <form class="rang-forme" onsubmit="return false" autocomplete="off" hidden>
          <label>Adresse qui recevra le rappel
            <input type="email" id="k-filet-adresse" autocomplete="off"></label>
          <div class="barre-boutons"><button class="primaire" id="k-filet-activer">Activer</button></div>
          <p class="note">PuppetPaie tourne sur cet ordinateur : éteint, il ne peut prévenir
            personne. Le filet confie donc un réveil au serveur de PuppetPaie, pour la veille
            de chaque embauche dont le contrat est parti, et le désarme dès que la DPAE part.
            S'il n'a pas été désarmé, il sonne : un courriel à cette adresse. Le serveur ne
            reçoit ni nom, ni salarié, ni contrat — seulement cette adresse, un code tiré au
            hasard et le jour de l'embauche, effacés dès que le réveil sonne ou se désarme.
            Un lien de confirmation part d'abord à l'adresse : sans lui, rien ne sera envoyé.
            La DPAE reste obligatoire avant la première heure de travail ; le filet ne la
            fait pas, il rappelle qu'elle manque.</p>
        </form>
      </div>
      <div class="rang" id="k-diagnostic">
        <div class="rang-infos"><b class="rang-nom">Signalement des dysfonctionnements</b>
          <span class="discret">ce qui casse part chez l'éditeur, sans nom, sans NIR, sans
            montant — des codes et des messages qui nomment un champ</span>
          <span class="compte k-diag-compte"></span></div>
        <div class="rang-etat k-diag-etat"><span class="discret">lecture…</span></div>
        <div class="rang-actions">
          <button class="lien" id="k-diag-couper" hidden>Désactiver</button>
          <button class="secondaire" id="k-diag-voir">Voir ce qui est parti…</button>
        </div>
      </div>
    </div>`;

  if (demo) {
    // Les lignes ouvertes, pour voir leurs champs ; tout est grisé, sauf les
    // liens vers la fiche Entreprise, qui ne font que naviguer.
    cible.querySelectorAll(".rang-forme").forEach((f) => { f.hidden = false; });
    cible.querySelectorAll("input, button:not([data-aller-fiche])").forEach((x) => {
      x.disabled = true;
    });
    cible.querySelector(".k-filet-etat").innerHTML = `<span class="pastille">désactivé</span>`;
    cible.querySelector(".k-google-etat").innerHTML = `<span class="pastille">non lié</span>`;
    cible.querySelectorAll("[data-aller-fiche]").forEach((b) => {
      b.onclick = () => document.querySelector(
        `.sous-onglets button[data-fiche="${b.dataset.allerFiche}"]`).click();
    });
    return;
  }

  dessinerFilet(cible.querySelector("#k-filet"), exige);
  dessinerDiagnostic(cible.querySelector("#k-diagnostic"));

  // Venu du bandeau : la ligne de ce qui manque, ouverte et montrée.
  if (OUVRIR_SERVICE) {
    const rang = OUVRIR_SERVICE === "google" ? cible.querySelector("#k-google")
      : cible.querySelector(`[data-service="${OUVRIR_SERVICE}"]`);
    OUVRIR_SERVICE = null;
    if (rang) {
      rang.classList.add("montre");
      rang.scrollIntoView({ block: "center" });
      const forme = rang.querySelector(".rang-forme");
      if (forme) { forme.hidden = false; forme.querySelector("input").focus(); }
    }
  }
  cible.querySelectorAll("[data-aller-fiche]").forEach((b) => {
    b.onclick = () => document.querySelector(
      `.sous-onglets button[data-fiche="${b.dataset.allerFiche}"]`).click();
  });
  // « Poser… » / « Modifier… » ouvre la ligne, et met le curseur dans la
  // première case ; un second clic la referme.
  cible.querySelectorAll(".k-ouvrir").forEach((b) => {
    b.onclick = () => {
      const forme = b.closest(".rang").querySelector(".rang-forme");
      forme.hidden = !forme.hidden;
      if (!forme.hidden) forme.querySelector("input").focus();
    };
  });

  // La preuve, si elle est exigée : le popup. Null = annulé, on ne fait rien.
  const preuve = async (quoi) => {
    if (!exige) return { motdepasse: null };
    const m = await demanderMotDePasse(quoi);
    return m ? { motdepasse: m } : null;
  };
  // L'ACTUEL EST UN CHAMP, PAS UN POPUP, et seulement ici (21/09/2026,
  // l'editeur). La regle du 17/09 vaut pour un acte qui ENGAGE : deposer,
  // envoyer, signer, poser un secret d'organisme -- et elle ne bouge pas, le
  // popup reste pour tout cela. Changer le mot de passe du logiciel n'est pas
  // de cette famille : l'ancien n'autorise pas l'acte, il est ce que l'acte
  // remplace. Le taper au-dessus du nouveau, c'est la forme que tout le monde
  // connait, et elle se lit d'un coup d'oeil.
  const actuelSaisi = (quoi) => {
    if (!exige) return { motdepasse: null };
    const champ = document.getElementById("k-actuel");
    const v = champ ? champ.value : "";
    if (!v) {
      dire("Tapez le mot de passe actuel pour " + quoi + ".");
      if (champ) champ.focus();
      return null;
    }
    return { motdepasse: v };
  };
  const ok = (texte) => { dire(texte); dessinerCoffre(cible); };
  const raté = (e) => dire(e.message, "erreur");

  document.getElementById("k-changer").onclick = async () => {
    const nouveau = document.getElementById("k-nouveau").value;
    const confirmation = document.getElementById("k-confirmation").value;
    if (!nouveau) { dire("Tapez le nouveau mot de passe."); return; }
    const p = actuelSaisi("changer");
    if (!p) return;
    try {
      await api("mot-de-passe-changer", { nouveau, confirmation, ...p });
      ok(exige ? "Mot de passe du logiciel changé." : "Mot de passe du logiciel posé : il sera demandé à la prochaine ouverture.");
    } catch (e) { raté(e); }
  };
  const retirer = document.getElementById("k-retirer");
  if (retirer) retirer.onclick = async () => {
    if (!confirm("Retirer le mot de passe du logiciel ? La fenêtre s'ouvrira sans rien demander et le coffre ne sera plus protégé.")) return;
    const p = actuelSaisi("retirer");
    if (!p) return;
    try {
      await api("mot-de-passe-retirer", p);
      ok("Mot de passe du logiciel retiré.");
    } catch (e) { raté(e); }
  };
  for (const carte of cible.querySelectorAll("[data-service]")) {
    const service = carte.dataset.service, verdict = carte.querySelector(".k-verdict");
    carte.querySelector(".k-poser").onclick = async () => {
      const valeur = carte.querySelector(".k-valeur").value;
      const nom = carte.querySelector(".k-nom"), prenom = carte.querySelector(".k-prenom");
      const s = c.services.find((x) => x.service === service);
      const compteChange = nom && (nom.value !== s.identifiant.nom
        || prenom.value !== s.identifiant.prenom);
      if (!valeur && !compteChange) {
        dire(nom ? "Rien n'a changé : ni le compte, ni le mot de passe."
          : "Tapez le mot de passe " + service + " à poser.", "erreur");
        return;
      }
      if (!valeur && !s.pose && !s.environnement) {
        dire("Le compte est à enregistrer avec son mot de passe : tapez-le aussi.");
        return;
      }
      const compte = carte.querySelector(".k-compte");
      const p = await preuve(valeur ? "poser le mot de passe " + service
        : "changer le compte qui dépose les DPAE");
      if (!p) return;
      let etat;
      try {
        if (compteChange) {
          etat = await api("coffre-compte-dpae", { nom: nom.value, prenom: prenom.value, ...p });
        }
        if (valeur) {
          etat = await api("coffre-poser", { service, valeur, compte: compte ? compte.value : null, ...p });
        }
      } catch (e) { raté(e); return; }
      // PUIS UNE TENTATIVE, UNE SEULE (§94) : le message d'après disait « le
      // vérifier maintenant évite de le découvrir faux au dépôt ». Autant le
      // faire. Pas si l'identifiant est incomplet : l'échec serait certain,
      // et chaque échec rapproche du blocage du compte.
      const apres = (etat?.services || []).find((x) => x.service === service);
      const quoi = compteChange && !valeur ? "Compte " : "Mot de passe ";
      if (apres?.identifiant?.manque?.length) {
        ok(quoi + service + " enregistré. Identifiant incomplet : pas de vérification.");
        return;
      }
      dire(quoi + service + " enregistré. Vérification chez l'organisme…");
      try {
        const v = await api("coffre-verifier", { service });
        await dessinerCoffre(cible);
        dire(v.ok ? quoi + service + " enregistré, et vérifié : la connexion passe."
          : quoi + service + " enregistré, mais la connexion est REFUSÉE : " + v.message
            + (v.conseil ? " — " + v.conseil : ""), v.ok ? undefined : "erreur");
      } catch (e) {
        await dessinerCoffre(cible);
        dire(quoi + service + " enregistré ; la vérification n'a pas pu se faire : " + e.message, "erreur");
      }
    };
    const verifier = carte.querySelector(".k-verifier");
    if (verifier) verifier.onclick = async (ev) => {
      ev.target.disabled = true; verdict.textContent = "Connexion…";
      try {
        const v = await api("coffre-verifier", { service });
        verdict.innerHTML = v.ok ? `<span class="pastille bien">OK</span> ${echapper(v.message || "session ouverte chez l'organisme.")}`
          : `<span class="pastille erreur">refusé</span> ${echapper(v.message)}${v.conseil ? "<br>" + echapper(v.conseil) : ""}`;
      } catch (e) { verdict.textContent = e.message; }
      ev.target.disabled = false;
    };
    const oublierService = carte.querySelector(".k-oublier");
    if (oublierService) oublierService.onclick = async () => {
      if (!confirm("Oublier le mot de passe " + service + " ? Les retours et les dépôts ne seront plus possibles jusqu'à ce qu'il soit reposé.")) return;
      const p = await preuve("oublier le mot de passe " + service);
      if (!p) return;
      try {
        await api("coffre-oublier", { service, ...p });
        ok("Mot de passe " + service + " oublié.");
      } catch (e) { raté(e); }
    };
  }
  dessinerCompteGoogle(cible, preuve, ok, raté);
}

/* Le compte Google, dans la même grille. L'état fait un vrai
 * rafraîchissement du jeton côté serveur (google-etat), donc il arrive
 * après le reste de la page — la carte se remplit quand il est là, et dit
 * « sans réseau » plutôt que de casser la page.
 *
 * « Lier le Drive » : l'appel reste suspendu le temps du consentement dans
 * le navigateur du système (jusqu'à cinq minutes, google.DELAI_AUTORISATION).
 * La carte le dit, et le bouton reste grisé jusqu'au retour. */
async function dessinerCompteGoogle(cible, preuve, ok, raté) {
  const carte = cible.querySelector("#k-google");
  if (!carte) return;
  const etat = carte.querySelector(".k-google-etat");
  const verdict = carte.querySelector(".k-verdict");
  const lier = carte.querySelector("#k-google-lier");
  const oublier = carte.querySelector("#k-google-oublier");
  let g = null;
  try { g = await api("google-etat"); }
  catch (e) { etat.innerHTML = `<span class="pastille alerte">état inconnu</span> ${echapper(e.message)}`; }
  if (!carte.isConnected) return;       // la page a été redessinée entre-temps
  if (g) {
    etat.innerHTML = !g.compte
      ? `<span class="pastille alerte" title="La sauvegarde ne peut pas partir tant qu'un Drive n'est pas lié.">aucun Drive lié</span>`
      : g.verifie
        ? `<span class="pastille bien" title="L'autorisation tient${g.accordees?.length ? " (" + g.accordees.map(echapper).join(", ") + ")" : ""}.">lié</span> <span class="discret">${echapper(g.compte)}</span>`
        : `<span class="pastille alerte">lié, mais</span> <span class="discret">${echapper(g.compte)} : ${echapper(g.probleme || "l'autorisation ne répond pas")}</span>`;
    lier.textContent = g.compte ? "Relier le Drive" : "Lier le Drive";
  }
  lier.disabled = false;
  oublier.disabled = !(g && g.compte);
  oublier.hidden = oublier.disabled;

  lier.onclick = async () => {
    const p = await preuve("lier le compte Google");
    if (!p) return;
    lier.disabled = oublier.disabled = true;
    verdict.innerHTML = `<b>La fenêtre Google est ouverte dans votre navigateur.</b>
      Choisissez le compte, acceptez, puis revenez ici — cette ligne se met à jour
      toute seule. Si Google dit que l'application n'est pas validée : Paramètres
      avancés › Accéder à PuppetPaie.`;
    try {
      const r = await api("google-autoriser", p);
      ok("Drive lié : " + r.compte + ". La prochaine ouverture sauvegarde.");
    } catch (e) { verdict.textContent = ""; lier.disabled = false; oublier.disabled = !(g && g.compte); raté(e); }
  };
  oublier.onclick = async () => {
    if (!confirm("Oublier le compte Google ? Le jeton local est effacé : plus de sauvegarde ni d'archivage jusqu'à ce qu'un Drive soit relié. L'accès accordé côté Google, lui, se retire sur myaccount.google.com › Sécurité › Vos connexions à des applications tierces.")) return;
    const p = await preuve("oublier le compte Google");
    if (!p) return;
    try {
      await api("google-oublier", p);
      ok("Compte Google oublié. Pensez à retirer l'accès sur myaccount.google.com.");
    } catch (e) { raté(e); }
  };
}

/* ------------------------------------------------- la fenêtre PuppetPaie */
/* Quand la page tourne dans la fenêtre pywebview (lanceur_interface.pyw),
 * `window.pywebview.api` existe et porte reduire / agrandir / fermer /
 * redimensionner. Le bandeau devient la barre de titre : les éléments
 * marqués `pywebview-drag-region` se tirent (c'est pywebview qui déplace la
 * fenêtre), un double-clic agrandit, et la poignée en bas à droite
 * redimensionne — une fenêtre sans bordure n'a pas de bord à tirer. Dans un
 * navigateur, rien de ceci ne s'active. */
function fenetreNative() {
  const api = window.pywebview && window.pywebview.api;
  if (!api || document.body.classList.contains("fenetre") || document.body.classList.contains("accueil-possible")) return;
  // La fenetre Rust (lot J3) a sa propre barre de titre : elle ne porte que le retour aux compagnies.
  if (!api.reduire) {
    if (typeof api.accueil === "function") boutonAccueil(api);
    return;
  }
  document.body.classList.add("fenetre");
  document.getElementById("fenetre-reduire").onclick = () => api.reduire();
  document.getElementById("fenetre-agrandir").onclick = () => api.agrandir();
  document.getElementById("fenetre-fermer").onclick = () => api.fermer();
  // L'ACCUEIL DES COMPAGNIES (ticket #113). Un lanceur d'avant ce bouton
  // (une mise à jour s'applique au lanceur au démarrage suivant) n'a pas
  // `accueil` : le bouton ne se montre pas. Ce qui est à l'écran
  // s'enregistre d'abord, comme quand on change de mois ; le serveur de
  // la compagnie s'arrête ensuite, côté lanceur.
  if (typeof api.accueil === "function") boutonAccueil(api);
  // Tout le bandeau se tire (pywebview remonte du point cliqué jusqu'à
  // l'élément marqué) ; ses boutons arrêtent le mousedown avant qu'il
  // n'atteigne le corps, où pywebview l'écoute, et restent des boutons.
  const bandeau = document.querySelector(".bandeau");
  bandeau.classList.add("pywebview-drag-region");
  for (const el of bandeau.querySelectorAll("button, a, input")) {
    el.addEventListener("mousedown", (e) => e.stopPropagation());
  }
  bandeau.addEventListener("dblclick", (e) => {
    if (e.target.closest("button, a, input")) return;
    api.agrandir();
  });
  const poignee = document.getElementById("fenetre-poignee");
  poignee.addEventListener("mousedown", (e) => {
    e.preventDefault();
    const x0 = e.screenX, y0 = e.screenY, w0 = window.innerWidth, h0 = window.innerHeight;
    let attente = false;
    const bouger = (ev) => {
      if (attente) return;
      attente = true;
      api.redimensionner(Math.max(700, w0 + ev.screenX - x0), Math.max(500, h0 + ev.screenY - y0))
        .finally(() => { attente = false; });
    };
    const lacher = () => {
      window.removeEventListener("mousemove", bouger);
      window.removeEventListener("mouseup", lacher);
    };
    window.addEventListener("mousemove", bouger);
    window.addEventListener("mouseup", lacher);
  });
}
function boutonAccueil(api) {
  document.body.classList.add("accueil-possible");
  document.getElementById("fenetre-accueil").onclick = async () => {
    clearTimeout(MINUTEUR_SAISIE);
    await enregistrerSaisie(false);
    // Un enregistrement refusé : on reste, le message est à l'écran.
    // Partir perdrait ce qu'on vient de taper.
    const s = saisieCourante();
    const ecrivable = s.mois && !(MOIS_FERME && MOIS_FORCE !== s.mois);
    if (ecrivable && JSON.stringify(s) !== DERNIERE_ECRITE) return;
    api.accueil();
  };
}
window.addEventListener("pywebviewready", fenetreNative);
fenetreNative();

/* Configuration → Signature & tampon (22/09/2026).

   L'éditeur : « je peux pas ajouter la signature dans l'interface, pourquoi ? ».
   Parce qu'il n'y avait AUCUNE route de fichier dans le logiciel. C'est la
   première, et elle sert la règle 0 : une compagnie qui installe PuppetPaie
   doit pouvoir poser SA signature, pas hériter de celle d'une autre.

   TROIS PARTIS PRIS, ET ILS TIENNENT ENSEMBLE :

   - ON MONTRE TOUJOURS CE QUI EST EN PLACE. « les gens doivent voir ce qu'ils
     ont mis » : poser une signature à l'aveugle, c'est ne jamais savoir ce
     qui part sur les attestations.
   - LE TAMPON EST DESSINÉ PAR DÉFAUT, et on le montre AUSSI — « que les gens
     le trouvent beau et ne passent pas trop de temps à faire le leur ». Il
     vient de la fiche Entreprise et la suit ; il n'y a rien à fournir.
   - RETIRER, C'EST REVENIR AU DÉFAUT. Un tampon importé qu'on retire rend la
     main au dessin. Rien à reconfigurer, rien à se rappeler. */
async function dessinerIdentite(cible) {
  const etat = (await api("identite")).identite;
  const t = Date.now();          // l'image vient d'être remplacée : pas de cache

  const apercu = (src, alt) => `<div class="identite-apercu">
    <img src="${src}" alt="${alt}"></div>`;

  // UNE LIGNE CHACUN (23/09/2026), comme les mots de passe : l'image en
  // place à gauche -- on voit toujours ce qui part --, ce qu'elle est et
  // d'où elle vient, puis les gestes. Le champ de fichier du navigateur
  // (« Choisir un fichier — aucun fichier choisi ») se cache derrière un
  // bouton qui dit ce qu'il fait.
  const rang = (quoi, titre, quoiDit) => {
    const e = etat[quoi] || { pose: false };
    // Le tampon a une image même quand rien n'est posé : celle que le
    // logiciel dessine. C'est tout l'objet de la case « automatique ».
    const vue = e.pose
      ? apercu(`/identite/${quoi}?t=${t}`, titre)
      : e.automatique ? apercu(`/identite/cachet-automatique?t=${t}`, titre)
      : `<div class="identite-apercu vide">rien de posé</div>`;
    const dit = e.pose
      ? `<span class="pastille bien">le vôtre</span> <span class="discret">${e.format.toUpperCase()},
           ${Math.round((e.octets || 0) / 1024)} Ko, posé le ${jjmmaaaa((e.quand || "").slice(0, 10))}</span>`
      : e.automatique
        ? `<span class="pastille bien">celui du logiciel</span> <span class="discret">dessiné
             depuis la fiche Entreprise, il la suit : rien à faire</span>`
        : `<span class="pastille alerte">rien de posé</span>`;
    return `<div class="rang rang-image">
      ${vue}
      <div class="rang-infos">
        <b class="rang-nom">${titre}</b>
        <span class="discret">${quoiDit}</span>
        <div>${dit}</div>
      </div>
      <div class="rang-actions">
        ${e.pose ? `<button class="lien" data-retirer="${quoi}">${
          e.automatique ? "Revenir à celui du logiciel" : "Retirer"}</button>` : ""}
        <label class="${e.pose ? "modifier" : "bouton-fichier"}" title="PNG, JPEG ou SVG, 2 Mo au plus">${
          e.pose ? CRAYON + "Modifier…" : e.automatique ? "Importer le vôtre…" : "Importer…"}
          <input type="file" accept="image/png,image/jpeg,image/svg+xml"
                 data-quoi="${quoi}"></label>
      </div>
    </div>`;
  };

  // OÙ VA CHAQUE IMAGE, en toutes lettres (§110) : le moteur en tient la
  // liste (`DOCUMENTS_IDENTITE`). La page disait de la signature
  // « l'attestation et le certificat » ; elle part aussi sur chaque contrat.
  const ou = (quoi) => {
    const docs = (etat[quoi] || {}).documents || [];
    return docs.length ? `Sur ${docs.map(echapper).join(", ")}` : "";
  };
  // LA SIGNATURE EST CELLE D'UNE PERSONNE : celle que la fiche Entreprise
  // nomme sous « Qui signe ». Posée pour quelqu'un d'autre, la page le dit.
  const sig = etat.signature || {};
  const qui = sig.signataire || {};
  const titreSignature = qui.nom
    ? `La signature de ${echapper(qui.nom)}${qui.fonction ? ", " + echapper(qui.fonction) : ""}`
    : "La signature";
  const ditSignature = `${ou("signature")}. Elle engage la personne qui signe au nom de
      la compagnie${qui.nom ? "" : ` — <span class="a-completer">la fiche Entreprise ne dit pas
      qui signe</span>`}.${sig.autre_personne ? `<span class="compte a-completer">Cette image a été
      posée pour ${echapper(sig.posee_pour)} ; la personne qui signe est maintenant
      ${echapper(qui.nom)}. Importer sa signature à elle, ou corriger la fiche Entreprise.</span>` : ""}
      <button class="lien" data-aller-fiche="entreprise">Qui signe (fiche Entreprise)</button>`;

  cible.innerHTML = `
    <p class="intro">Ce qui se pose sur les documents de la compagnie. PNG, JPEG ou
      SVG, 2 Mo au plus.</p>
    <div class="rangs">
      ${rang("signature", titreSignature, ditSignature)}
      ${rang("cachet", "Le tampon", `${ou("cachet")}. Il identifie la compagnie, il
        n'engage personne.`)}
      ${rang("logo", "Le logo", `${ou("logo")}, en haut à droite. Facultatif.`)}
    </div>`;
  cible.querySelectorAll("[data-aller-fiche]").forEach((b) => {
    b.onclick = () => document.querySelector(
      `.sous-onglets button[data-fiche="${b.dataset.allerFiche}"]`).click();
  });

  cible.querySelectorAll('input[type="file"]').forEach((ch) => {
    ch.onchange = async () => {
      const f = ch.files && ch.files[0];
      if (!f) return;
      ch.disabled = true;
      try {
        // On envoie les octets tels quels : le moteur reconnaît le format sur
        // l'en-tête du fichier, pas sur son extension — qui ne prouve rien.
        const contenu = await new Promise((ok, non) => {
          const l = new FileReader();
          l.onload = () => ok(String(l.result).split(",").pop());
          l.onerror = () => non(l.error);
          l.readAsDataURL(f);
        });
        await api("poser-identite", { quoi: ch.dataset.quoi, contenu });
        await dessinerIdentite(cible);
      } catch (e) {
        // Un format refusé se dit : il partait en exception, sans un mot.
        ch.disabled = false;
        ch.value = "";
        dire(e.message, "erreur");
      }
    };
  });

  cible.querySelectorAll("[data-retirer]").forEach((b) => {
    b.onclick = async () => {
      b.disabled = true;
      try {
        await api("retirer-identite", { quoi: b.dataset.retirer });
        await dessinerIdentite(cible);
      } catch (e) { b.disabled = false; dire(e.message, "erreur"); }
    };
  });
}
